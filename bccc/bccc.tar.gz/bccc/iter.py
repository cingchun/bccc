#!/usr/bin/env python 
# -*- coding: utf-8 -*- 
# 
# Author: Qingchun Wang @ NJU 
# E-mail: qingchun720@foxmail.com 
# 


from copy import deepcopy
from datetime import datetime
from numpy import zeros,ones,array,matrix,ctypeslib,linalg,uint32,float64
from ctypes import c_uint


def iter(t, r, h, g, p, nt=4, nc=0, thd=1.0e-7, ncyc=200, xE=0.015):
    # fun list
    # ground state
    # from bccc.ta.ta_ import ta_ # Ecorr
    # ftl = (ta_,)
    ftl = ()
    from bccc.ta.ta_ import h0_
    f0l = (h0_,)
    ful = ()
    # 2-block excited types
    from bccc.ta.ta_A1B1 import ta_A1B1
    from bccc.ta.ta_A1B2 import ta_A1B2
    from bccc.ta.ta_A1B3 import ta_A1B3
    from bccc.ta.ta_A2B2 import ta_A2B2
    from bccc.ta.ta_A2B3 import ta_A2B3
    from bccc.ta.ta_A3B3 import ta_A3B3
    from bccc.ta.ta_A4B5 import ta_A4B5
    from bccc.ta.ta_A6B15 import ta_A6B15
    from bccc.ta.ta_A7B13 import ta_A7B13
    from bccc.ta.ta_A7B14 import ta_A7B14
    from bccc.ta.ta_A8B13 import ta_A8B13
    from bccc.ta.ta_A8B14 import ta_A8B14
    from bccc.ta.ta_A9B11 import ta_A9B11
    from bccc.ta.ta_A9B12 import ta_A9B12
    from bccc.ta.ta_A10B11 import ta_A10B11
    from bccc.ta.ta_A10B12 import ta_A10B12
    ftl += (
            ta_A1B1,ta_A1B2,ta_A1B3,ta_A2B2,ta_A2B3,ta_A3B3,ta_A4B5,ta_A6B15,ta_A7B13,ta_A7B14,
            ta_A8B13,ta_A8B14,ta_A9B11,ta_A9B12,ta_A10B11,ta_A10B12,
            )
    from bccc.ta.ta_A1B1 import h0_A1B1
    from bccc.ta.ta_A1B2 import h0_A1B2
    from bccc.ta.ta_A1B3 import h0_A1B3
    from bccc.ta.ta_A2B2 import h0_A2B2
    from bccc.ta.ta_A2B3 import h0_A2B3
    from bccc.ta.ta_A3B3 import h0_A3B3
    from bccc.ta.ta_A4B5 import h0_A4B5
    from bccc.ta.ta_A6B15 import h0_A6B15
    from bccc.ta.ta_A7B13 import h0_A7B13
    from bccc.ta.ta_A7B14 import h0_A7B14
    from bccc.ta.ta_A8B13 import h0_A8B13
    from bccc.ta.ta_A8B14 import h0_A8B14
    from bccc.ta.ta_A9B11 import h0_A9B11
    from bccc.ta.ta_A9B12 import h0_A9B12
    from bccc.ta.ta_A10B11 import h0_A10B11
    from bccc.ta.ta_A10B12 import h0_A10B12
    f0l += (
            h0_A1B1,h0_A1B2,h0_A1B3,h0_A2B2,h0_A2B3,h0_A3B3,h0_A4B5,h0_A6B15,h0_A7B13,h0_A7B14,
            h0_A8B13,h0_A8B14,h0_A9B11,h0_A9B12,h0_A10B11,h0_A10B12,
            )
    from bccc.ta.ta_A1B1 import hu_A1B1
    from bccc.ta.ta_A1B2 import hu_A1B2
    from bccc.ta.ta_A1B3 import hu_A1B3
    from bccc.ta.ta_A2B2 import hu_A2B2
    from bccc.ta.ta_A2B3 import hu_A2B3
    from bccc.ta.ta_A3B3 import hu_A3B3
    from bccc.ta.ta_A4B5 import hu_A4B5
    from bccc.ta.ta_A6B15 import hu_A6B15
    from bccc.ta.ta_A7B13 import hu_A7B13
    from bccc.ta.ta_A7B14 import hu_A7B14
    from bccc.ta.ta_A8B13 import hu_A8B13
    from bccc.ta.ta_A8B14 import hu_A8B14
    from bccc.ta.ta_A9B11 import hu_A9B11
    from bccc.ta.ta_A9B12 import hu_A9B12
    from bccc.ta.ta_A10B11 import hu_A10B11
    from bccc.ta.ta_A10B12 import hu_A10B12
    ful += (
            hu_A1B1,hu_A1B2,hu_A1B3,hu_A2B2,hu_A2B3,hu_A3B3,hu_A4B5,hu_A6B15,hu_A7B13,hu_A7B14,
            hu_A8B13,hu_A8B14,hu_A9B11,hu_A9B12,hu_A10B11,hu_A10B12,
            )
    # 3-block excited types
    from bccc.ta.ta_A1B1C1 import ta_A1B1C1
    from bccc.ta.ta_A1B1C2 import ta_A1B1C2
    from bccc.ta.ta_A1B1C3 import ta_A1B1C3
    from bccc.ta.ta_A1B2C2 import ta_A1B2C2
    from bccc.ta.ta_A1B2C3 import ta_A1B2C3
    from bccc.ta.ta_A1B3C3 import ta_A1B3C3
    from bccc.ta.ta_A1B4C5 import ta_A1B4C5
    from bccc.ta.ta_A1B6C15 import ta_A1B6C15
    from bccc.ta.ta_A1B7C13 import ta_A1B7C13
    from bccc.ta.ta_A1B7C14 import ta_A1B7C14
    from bccc.ta.ta_A1B8C13 import ta_A1B8C13
    from bccc.ta.ta_A1B8C14 import ta_A1B8C14
    from bccc.ta.ta_A1B9C11 import ta_A1B9C11
    from bccc.ta.ta_A1B9C12 import ta_A1B9C12
    from bccc.ta.ta_A1B10C11 import ta_A1B10C11
    from bccc.ta.ta_A1B10C12 import ta_A1B10C12
    from bccc.ta.ta_A2B2C2 import ta_A2B2C2
    from bccc.ta.ta_A2B2C3 import ta_A2B2C3
    from bccc.ta.ta_A2B3C3 import ta_A2B3C3
    from bccc.ta.ta_A2B4C5 import ta_A2B4C5
    from bccc.ta.ta_A2B6C15 import ta_A2B6C15
    from bccc.ta.ta_A2B7C13 import ta_A2B7C13
    from bccc.ta.ta_A2B7C14 import ta_A2B7C14
    from bccc.ta.ta_A2B8C13 import ta_A2B8C13
    from bccc.ta.ta_A2B8C14 import ta_A2B8C14
    from bccc.ta.ta_A2B9C11 import ta_A2B9C11
    from bccc.ta.ta_A2B9C12 import ta_A2B9C12
    from bccc.ta.ta_A2B10C11 import ta_A2B10C11
    from bccc.ta.ta_A2B10C12 import ta_A2B10C12
    from bccc.ta.ta_A3B3C3 import ta_A3B3C3
    from bccc.ta.ta_A3B4C5 import ta_A3B4C5
    from bccc.ta.ta_A3B6C15 import ta_A3B6C15
    from bccc.ta.ta_A3B7C13 import ta_A3B7C13
    from bccc.ta.ta_A3B7C14 import ta_A3B7C14
    from bccc.ta.ta_A3B8C13 import ta_A3B8C13
    from bccc.ta.ta_A3B8C14 import ta_A3B8C14
    from bccc.ta.ta_A3B9C11 import ta_A3B9C11
    from bccc.ta.ta_A3B9C12 import ta_A3B9C12
    from bccc.ta.ta_A3B10C11 import ta_A3B10C11
    from bccc.ta.ta_A3B10C12 import ta_A3B10C12
    from bccc.ta.ta_A4B9C13 import ta_A4B9C13
    from bccc.ta.ta_A4B9C14 import ta_A4B9C14
    from bccc.ta.ta_A4B10C13 import ta_A4B10C13
    from bccc.ta.ta_A4B10C14 import ta_A4B10C14
    from bccc.ta.ta_A5B7C11 import ta_A5B7C11
    from bccc.ta.ta_A5B7C12 import ta_A5B7C12
    from bccc.ta.ta_A5B8C11 import ta_A5B8C11
    from bccc.ta.ta_A5B8C12 import ta_A5B8C12
    from bccc.ta.ta_A6B11C13 import ta_A6B11C13
    from bccc.ta.ta_A6B11C14 import ta_A6B11C14
    from bccc.ta.ta_A6B12C13 import ta_A6B12C13
    from bccc.ta.ta_A6B12C14 import ta_A6B12C14
    from bccc.ta.ta_A7B9C15 import ta_A7B9C15
    from bccc.ta.ta_A7B10C15 import ta_A7B10C15
    from bccc.ta.ta_A8B9C15 import ta_A8B9C15
    from bccc.ta.ta_A8B10C15 import ta_A8B10C15
    ftl += (
            ta_A1B1C1,ta_A1B1C2,ta_A1B1C3,ta_A1B2C2,ta_A1B2C3,ta_A1B3C3,ta_A1B4C5,ta_A1B6C15,ta_A1B7C13,ta_A1B7C14,
            ta_A1B8C13,ta_A1B8C14,ta_A1B9C11,ta_A1B9C12,ta_A1B10C11,ta_A1B10C12,ta_A2B2C2,ta_A2B2C3,ta_A2B3C3,ta_A2B4C5,
            ta_A2B6C15,ta_A2B7C13,ta_A2B7C14,ta_A2B8C13,ta_A2B8C14,ta_A2B9C11,ta_A2B9C12,ta_A2B10C11,ta_A2B10C12,ta_A3B3C3,
            ta_A3B4C5,ta_A3B6C15,ta_A3B7C13,ta_A3B7C14,ta_A3B8C13,ta_A3B8C14,ta_A3B9C11,ta_A3B9C12,ta_A3B10C11,ta_A3B10C12,
            ta_A4B9C13,ta_A4B9C14,ta_A4B10C13,ta_A4B10C14,ta_A5B7C11,ta_A5B7C12,ta_A5B8C11,ta_A5B8C12,ta_A6B11C13,ta_A6B11C14,
            ta_A6B12C13,ta_A6B12C14,ta_A7B9C15,ta_A7B10C15,ta_A8B9C15,ta_A8B10C15,
            )
    from bccc.ta.ta_A1B1C1 import h0_A1B1C1
    from bccc.ta.ta_A1B1C2 import h0_A1B1C2
    from bccc.ta.ta_A1B1C3 import h0_A1B1C3
    from bccc.ta.ta_A1B2C2 import h0_A1B2C2
    from bccc.ta.ta_A1B2C3 import h0_A1B2C3
    from bccc.ta.ta_A1B3C3 import h0_A1B3C3
    from bccc.ta.ta_A1B4C5 import h0_A1B4C5
    from bccc.ta.ta_A1B6C15 import h0_A1B6C15
    from bccc.ta.ta_A1B7C13 import h0_A1B7C13
    from bccc.ta.ta_A1B7C14 import h0_A1B7C14
    from bccc.ta.ta_A1B8C13 import h0_A1B8C13
    from bccc.ta.ta_A1B8C14 import h0_A1B8C14
    from bccc.ta.ta_A1B9C11 import h0_A1B9C11
    from bccc.ta.ta_A1B9C12 import h0_A1B9C12
    from bccc.ta.ta_A1B10C11 import h0_A1B10C11
    from bccc.ta.ta_A1B10C12 import h0_A1B10C12
    from bccc.ta.ta_A2B2C2 import h0_A2B2C2
    from bccc.ta.ta_A2B2C3 import h0_A2B2C3
    from bccc.ta.ta_A2B3C3 import h0_A2B3C3
    from bccc.ta.ta_A2B4C5 import h0_A2B4C5
    from bccc.ta.ta_A2B6C15 import h0_A2B6C15
    from bccc.ta.ta_A2B7C13 import h0_A2B7C13
    from bccc.ta.ta_A2B7C14 import h0_A2B7C14
    from bccc.ta.ta_A2B8C13 import h0_A2B8C13
    from bccc.ta.ta_A2B8C14 import h0_A2B8C14
    from bccc.ta.ta_A2B9C11 import h0_A2B9C11
    from bccc.ta.ta_A2B9C12 import h0_A2B9C12
    from bccc.ta.ta_A2B10C11 import h0_A2B10C11
    from bccc.ta.ta_A2B10C12 import h0_A2B10C12
    from bccc.ta.ta_A3B3C3 import h0_A3B3C3
    from bccc.ta.ta_A3B4C5 import h0_A3B4C5
    from bccc.ta.ta_A3B6C15 import h0_A3B6C15
    from bccc.ta.ta_A3B7C13 import h0_A3B7C13
    from bccc.ta.ta_A3B7C14 import h0_A3B7C14
    from bccc.ta.ta_A3B8C13 import h0_A3B8C13
    from bccc.ta.ta_A3B8C14 import h0_A3B8C14
    from bccc.ta.ta_A3B9C11 import h0_A3B9C11
    from bccc.ta.ta_A3B9C12 import h0_A3B9C12
    from bccc.ta.ta_A3B10C11 import h0_A3B10C11
    from bccc.ta.ta_A3B10C12 import h0_A3B10C12
    from bccc.ta.ta_A4B9C13 import h0_A4B9C13
    from bccc.ta.ta_A4B9C14 import h0_A4B9C14
    from bccc.ta.ta_A4B10C13 import h0_A4B10C13
    from bccc.ta.ta_A4B10C14 import h0_A4B10C14
    from bccc.ta.ta_A5B7C11 import h0_A5B7C11
    from bccc.ta.ta_A5B7C12 import h0_A5B7C12
    from bccc.ta.ta_A5B8C11 import h0_A5B8C11
    from bccc.ta.ta_A5B8C12 import h0_A5B8C12
    from bccc.ta.ta_A6B11C13 import h0_A6B11C13
    from bccc.ta.ta_A6B11C14 import h0_A6B11C14
    from bccc.ta.ta_A6B12C13 import h0_A6B12C13
    from bccc.ta.ta_A6B12C14 import h0_A6B12C14
    from bccc.ta.ta_A7B9C15 import h0_A7B9C15
    from bccc.ta.ta_A7B10C15 import h0_A7B10C15
    from bccc.ta.ta_A8B9C15 import h0_A8B9C15
    from bccc.ta.ta_A8B10C15 import h0_A8B10C15
    f0l += (
            h0_A1B1C1,h0_A1B1C2,h0_A1B1C3,h0_A1B2C2,h0_A1B2C3,h0_A1B3C3,h0_A1B4C5,h0_A1B6C15,h0_A1B7C13,h0_A1B7C14,
            h0_A1B8C13,h0_A1B8C14,h0_A1B9C11,h0_A1B9C12,h0_A1B10C11,h0_A1B10C12,h0_A2B2C2,h0_A2B2C3,h0_A2B3C3,h0_A2B4C5,
            h0_A2B6C15,h0_A2B7C13,h0_A2B7C14,h0_A2B8C13,h0_A2B8C14,h0_A2B9C11,h0_A2B9C12,h0_A2B10C11,h0_A2B10C12,h0_A3B3C3,
            h0_A3B4C5,h0_A3B6C15,h0_A3B7C13,h0_A3B7C14,h0_A3B8C13,h0_A3B8C14,h0_A3B9C11,h0_A3B9C12,h0_A3B10C11,h0_A3B10C12,
            h0_A4B9C13,h0_A4B9C14,h0_A4B10C13,h0_A4B10C14,h0_A5B7C11,h0_A5B7C12,h0_A5B8C11,h0_A5B8C12,h0_A6B11C13,h0_A6B11C14,
            h0_A6B12C13,h0_A6B12C14,h0_A7B9C15,h0_A7B10C15,h0_A8B9C15,h0_A8B10C15,
            )
    from bccc.ta.ta_A1B1C1 import hu_A1B1C1
    from bccc.ta.ta_A1B1C2 import hu_A1B1C2
    from bccc.ta.ta_A1B1C3 import hu_A1B1C3
    from bccc.ta.ta_A1B2C2 import hu_A1B2C2
    from bccc.ta.ta_A1B2C3 import hu_A1B2C3
    from bccc.ta.ta_A1B3C3 import hu_A1B3C3
    from bccc.ta.ta_A1B4C5 import hu_A1B4C5
    from bccc.ta.ta_A1B6C15 import hu_A1B6C15
    from bccc.ta.ta_A1B7C13 import hu_A1B7C13
    from bccc.ta.ta_A1B7C14 import hu_A1B7C14
    from bccc.ta.ta_A1B8C13 import hu_A1B8C13
    from bccc.ta.ta_A1B8C14 import hu_A1B8C14
    from bccc.ta.ta_A1B9C11 import hu_A1B9C11
    from bccc.ta.ta_A1B9C12 import hu_A1B9C12
    from bccc.ta.ta_A1B10C11 import hu_A1B10C11
    from bccc.ta.ta_A1B10C12 import hu_A1B10C12
    from bccc.ta.ta_A2B2C2 import hu_A2B2C2
    from bccc.ta.ta_A2B2C3 import hu_A2B2C3
    from bccc.ta.ta_A2B3C3 import hu_A2B3C3
    from bccc.ta.ta_A2B4C5 import hu_A2B4C5
    from bccc.ta.ta_A2B6C15 import hu_A2B6C15
    from bccc.ta.ta_A2B7C13 import hu_A2B7C13
    from bccc.ta.ta_A2B7C14 import hu_A2B7C14
    from bccc.ta.ta_A2B8C13 import hu_A2B8C13
    from bccc.ta.ta_A2B8C14 import hu_A2B8C14
    from bccc.ta.ta_A2B9C11 import hu_A2B9C11
    from bccc.ta.ta_A2B9C12 import hu_A2B9C12
    from bccc.ta.ta_A2B10C11 import hu_A2B10C11
    from bccc.ta.ta_A2B10C12 import hu_A2B10C12
    from bccc.ta.ta_A3B3C3 import hu_A3B3C3
    from bccc.ta.ta_A3B4C5 import hu_A3B4C5
    from bccc.ta.ta_A3B6C15 import hu_A3B6C15
    from bccc.ta.ta_A3B7C13 import hu_A3B7C13
    from bccc.ta.ta_A3B7C14 import hu_A3B7C14
    from bccc.ta.ta_A3B8C13 import hu_A3B8C13
    from bccc.ta.ta_A3B8C14 import hu_A3B8C14
    from bccc.ta.ta_A3B9C11 import hu_A3B9C11
    from bccc.ta.ta_A3B9C12 import hu_A3B9C12
    from bccc.ta.ta_A3B10C11 import hu_A3B10C11
    from bccc.ta.ta_A3B10C12 import hu_A3B10C12
    from bccc.ta.ta_A4B9C13 import hu_A4B9C13
    from bccc.ta.ta_A4B9C14 import hu_A4B9C14
    from bccc.ta.ta_A4B10C13 import hu_A4B10C13
    from bccc.ta.ta_A4B10C14 import hu_A4B10C14
    from bccc.ta.ta_A5B7C11 import hu_A5B7C11
    from bccc.ta.ta_A5B7C12 import hu_A5B7C12
    from bccc.ta.ta_A5B8C11 import hu_A5B8C11
    from bccc.ta.ta_A5B8C12 import hu_A5B8C12
    from bccc.ta.ta_A6B11C13 import hu_A6B11C13
    from bccc.ta.ta_A6B11C14 import hu_A6B11C14
    from bccc.ta.ta_A6B12C13 import hu_A6B12C13
    from bccc.ta.ta_A6B12C14 import hu_A6B12C14
    from bccc.ta.ta_A7B9C15 import hu_A7B9C15
    from bccc.ta.ta_A7B10C15 import hu_A7B10C15
    from bccc.ta.ta_A8B9C15 import hu_A8B9C15
    from bccc.ta.ta_A8B10C15 import hu_A8B10C15
    ful += (
            hu_A1B1C1,hu_A1B1C2,hu_A1B1C3,hu_A1B2C2,hu_A1B2C3,hu_A1B3C3,hu_A1B4C5,hu_A1B6C15,hu_A1B7C13,hu_A1B7C14,
            hu_A1B8C13,hu_A1B8C14,hu_A1B9C11,hu_A1B9C12,hu_A1B10C11,hu_A1B10C12,hu_A2B2C2,hu_A2B2C3,hu_A2B3C3,hu_A2B4C5,
            hu_A2B6C15,hu_A2B7C13,hu_A2B7C14,hu_A2B8C13,hu_A2B8C14,hu_A2B9C11,hu_A2B9C12,hu_A2B10C11,hu_A2B10C12,hu_A3B3C3,
            hu_A3B4C5,hu_A3B6C15,hu_A3B7C13,hu_A3B7C14,hu_A3B8C13,hu_A3B8C14,hu_A3B9C11,hu_A3B9C12,hu_A3B10C11,hu_A3B10C12,
            hu_A4B9C13,hu_A4B9C14,hu_A4B10C13,hu_A4B10C14,hu_A5B7C11,hu_A5B7C12,hu_A5B8C11,hu_A5B8C12,hu_A6B11C13,hu_A6B11C14,
            hu_A6B12C13,hu_A6B12C14,hu_A7B9C15,hu_A7B10C15,hu_A8B9C15,hu_A8B10C15,
            )
    
    from multiprocessing import Pool
    from bccc.pub import sign,prodl,phiu,lowTri0
    # h0_
    h0d = {}
    pool = Pool()
    l = tuple(pool.apply_async(f0, (r, h, g, p, nc)) for f0 in f0l)
    pool.close()
    pool.join()
    for h0 in l: h0d.update(h0.get())
    # hu_
    hud = {}
    pool = Pool()
    l = tuple(pool.apply_async(fu, (r, h, g, p, nc)) for fu in ful)
    pool.close()
    pool.join()
    for hu in l: hud.update(hu.get())
    
    print(F'threshold,max_cycle,dEshift = {thd},{ncyc},{xE}')
    print('initial from LCC')
    from itertools import permutations,product
    Eref,Ecorr=h0d[()],sum(h0d.get(u, 0.0)*sum(s*prodl([t[v] for v in vl]) for s,vl in tu) for u,(_,tu) in hud.items()); E0=Eref+Ecorr
    print(F'Ecorr = {Ecorr}')
    
    udd = {u:{u:1.0} for u in t}  # all actiove t
    for u,ud in udd.items():
        for v in list(permutations(u))[1:]:
            ud[v] = sign([b for b,s in v if 6<s<15])
    t0 = {v:s*t[u] for u,ud in udd.items() for v,s in ud.items()}  # unordered t
    print('    it          Ecorr              dE               dt               time/s')
    ndiis=6; idiis = [*list(range(1,ndiis)), 0, ndiis]
    objl,errl = [],[]
    A = zeros((ndiis+1,ndiis+1))-1; A[ndiis,ndiis] = 0
    b=zeros((ndiis+1, )); b[ndiis]=-1
    for it in range(ncyc):
        # ta_
        t1 = datetime.now()
        pool = Pool()
        l = tuple(pool.apply_async(ft, (t0, r, h, g, p, nc)) for ft in ftl)
        pool.close()
        pool.join()
        td = {u: t for e in l for u,t in e.get().items()}
        t2 = datetime.now()
        
        dd = {u: (h0d.get(u, 0.0)+td[u]+(hu-E0)*sum(s*prodl([t[v] for v in vl]) for s,vl in tu))/(xE+hu-E0) for u,(hu,tu) in hud.items()}
        t,dt = {u:t0[u]-du for u,du in dd.items()},sum([abs(du) for du in dd.values()])
        if dt>thd:
            objl.append(t); errl.append(dd)
            if it+1>=ndiis:
                if it+1>ndiis:
                    objl.remove(objl[0]); errl.remove(errl[0])
                    A[:,:] = A[:,idiis]; A[:,:] = A[idiis,:]
                    for i in range(ndiis):
                        A[ndiis-1,i] = A[i,ndiis-1] = sum(errl[i][u]*du for u,du in dd.items())
                else:
                    for i in range(ndiis):
                        for j in range(i,ndiis):
                            A[i,j] = A[j,i] = sum(errl[i][u]*errl[j][u] for u in errl[i])
                x=linalg.solve(A,b)
                t = {u:sum(x[i]*objl[i][u] for i in range(ndiis)) for u in t.keys()}
        Ecorr=sum(h0d.get(u, 0.0)*sum(s*prodl([t[v] for v in vl]) for s,vl in tu) for u,(_,tu) in hud.items())
        E=Eref+Ecorr; dE=E-E0
        print(F'    {it+1:3d}      {Ecorr:.8f}      {dE:13.10f}    {dt:13.10f}     {t2-t1}', flush=True)
        if dt<thd: 
            print(F'Successfully converged: Ecorr = {Ecorr}')
            break
        else: E0,t0 = E,{v:s*t[u] for u,ud in udd.items() for v,s in ud.items()}
        
    else: print('Error: Convergence failed ')
    
    return Ecorr,t
    

