#!/usr/bin/env python 
# -*- coding: utf-8 -*- 
# 
# Author: Qingchun Wang @ NJU 
# E-mail: qingchun720@foxmail.com 
# 


import numpy
from bccc.pub import sign,dei


def _A1B9C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,9),(C,11)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += sum(h[p[I,0],p[I,0]]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(h[p[I,0],p[I,0]]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(h[p[I,1],p[I,1]]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(h[p[I,1],p[I,1]]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[I,0],p[I,0])]*r[I][194][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,1],p[I,0],p[I,1])]*r[I][199][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,0],p[I,1],p[I,0])]*r[I][274][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[I,1],p[I,1])]*r[I][279][0,0] for I in range(np) if I not in {A,B,C})
    hv += h[p[A,0],p[A,0]]*r[A][9][1,1]
    hv += h[p[A,0],p[A,0]]*r[A][24][1,1]
    hv += h[p[A,1],p[A,1]]*r[A][39][1,1]
    hv += h[p[A,1],p[A,1]]*r[A][54][1,1]
    hv += g[dei(p[A,0],p[A,0],p[A,0],p[A,0])]*r[A][194][1,1]
    hv += g[dei(p[A,0],p[A,1],p[A,0],p[A,1])]*r[A][199][1,1]
    hv += g[dei(p[A,1],p[A,0],p[A,1],p[A,0])]*r[A][274][1,1]
    hv += g[dei(p[A,1],p[A,1],p[A,1],p[A,1])]*r[A][279][1,1]
    hv += h[p[B,0],p[B,0]]*r[B][24][9,9]
    hv += h[p[C,0],p[C,0]]*r[C][9][11,11]
    hv += h[p[C,0],p[C,0]]*r[C][24][11,11]
    hv += h[p[C,1],p[C,1]]*r[C][39][11,11]
    hv += g[dei(p[C,0],p[C,0],p[C,0],p[C,0])]*r[C][194][11,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[C,1],p[C,1])]*r[C][204][11,11]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[C,1],p[C,0])]*r[C][201][11,11]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[C,0],p[C,1])]*r[C][252][11,11]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[C,0],p[C,0])]*r[C][249][11,11]
    hv += g[dei(p[C,1],p[C,1],p[C,0],p[C,0])]*r[C][259][11,11]
    hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][9][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][24][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][9][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][9][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][24][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][9][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][39][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][54][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][39][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][39][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][54][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][39][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,0])]*r[I][9][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,0])]*r[I][24][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,0])]*r[I][9][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,0])]*r[I][24][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,1])]*r[I][39][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,1])]*r[I][54][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,1])]*r[I][39][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,1])]*r[I][54][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,0],p[J,0])]*r[I][9][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,0],p[J,0])]*r[I][24][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,1],p[J,0])]*r[I][39][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,1],p[J,0])]*r[I][54][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,0],p[J,1])]*r[I][9][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,0],p[J,1])]*r[I][24][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,1],p[J,1])]*r[I][39][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,1],p[J,1])]*r[I][54][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[I][9][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[I][24][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[I][24][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[I][39][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[I][54][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[I][54][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[I][9][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[I][24][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[I][24][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[I][39][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[I][54][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[I][54][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][9][1,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][24][1,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][9][1,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][9][1,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][24][1,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][9][1,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,0],p[I,0])]*r[A][39][1,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,0],p[I,0])]*r[A][54][1,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,1],p[I,0],p[I,0])]*r[A][39][1,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,1],p[I,1])]*r[A][39][1,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,1],p[I,1])]*r[A][54][1,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,1],p[I,1],p[I,1])]*r[A][39][1,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,0])]*r[A][9][1,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,0])]*r[A][24][1,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,0])]*r[A][9][1,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,0])]*r[A][24][1,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,1])]*r[A][39][1,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,1])]*r[A][54][1,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,1])]*r[A][39][1,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,1])]*r[A][54][1,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,0])]*r[A][9][1,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,0])]*r[A][24][1,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,1],p[I,0])]*r[A][39][1,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,1],p[I,0])]*r[A][54][1,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,1])]*r[A][9][1,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,1])]*r[A][24][1,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,1],p[I,1])]*r[A][39][1,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,1],p[I,1])]*r[A][54][1,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][9][1,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,1])]*r[A][39][1,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][9][1,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,1])]*r[A][39][1,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[B,0],p[I,0],p[I,0])]*r[B][24][9,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[B,0],p[I,1],p[I,1])]*r[B][24][9,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,0],p[I,0],p[B,0])]*r[B][24][9,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,1],p[I,1],p[B,0])]*r[B][24][9,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,0],p[B,0],p[I,0])]*r[B][24][9,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,0],p[B,0],p[I,1])]*r[B][24][9,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,0],p[B,0])]*r[B][24][9,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[B,0],p[B,0])]*r[B][24][9,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,0],p[B,0])]*r[B][24][9,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[B,0],p[B,0])]*r[B][24][9,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[C,0],p[I,0],p[I,0])]*r[C][9][11,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[C,0],p[I,0],p[I,0])]*r[C][24][11,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[C,0],p[C,0],p[I,0],p[I,0])]*r[C][9][11,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[C,0],p[I,1],p[I,1])]*r[C][9][11,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[C,0],p[I,1],p[I,1])]*r[C][24][11,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[C,0],p[C,0],p[I,1],p[I,1])]*r[C][9][11,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[C,1],p[I,0],p[I,0])]*r[C][39][11,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[C,1],p[C,1],p[I,0],p[I,0])]*r[C][39][11,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[C,1],p[I,1],p[I,1])]*r[C][39][11,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[C,1],p[C,1],p[I,1],p[I,1])]*r[C][39][11,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,0],p[I,0],p[C,0])]*r[C][9][11,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,0],p[I,0],p[C,0])]*r[C][24][11,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,1],p[I,1],p[C,0])]*r[C][9][11,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,1],p[I,1],p[C,0])]*r[C][24][11,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,0],p[I,0],p[C,1])]*r[C][39][11,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,1],p[I,1],p[C,1])]*r[C][39][11,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,0],p[C,0],p[I,0])]*r[C][9][11,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,0],p[C,0],p[I,0])]*r[C][24][11,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,1],p[C,1],p[I,0])]*r[C][39][11,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,0],p[C,0],p[I,1])]*r[C][9][11,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,0],p[C,0],p[I,1])]*r[C][24][11,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,1],p[C,1],p[I,1])]*r[C][39][11,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,0],p[C,0])]*r[C][9][11,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,0],p[C,0])]*r[C][24][11,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[C,0],p[C,0])]*r[C][24][11,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,1],p[C,1])]*r[C][39][11,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,0],p[C,0])]*r[C][9][11,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,0],p[C,0])]*r[C][24][11,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[C,0],p[C,0])]*r[C][24][11,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,1],p[C,1])]*r[C][39][11,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[B,0])]*r[A][24][1,1]*r[B][24][9,9]
    hv += g[dei(p[A,0],p[A,0],p[B,0],p[B,0])]*r[A][9][1,1]*r[B][24][9,9]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[B,0])]*r[A][54][1,1]*r[B][24][9,9]
    hv += g[dei(p[A,1],p[A,1],p[B,0],p[B,0])]*r[A][39][1,1]*r[B][24][9,9]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[A,0])]*r[A][24][1,1]*r[B][24][9,9]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[A,1])]*r[A][54][1,1]*r[B][24][9,9]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[B,0])]*r[A][24][1,1]*r[B][24][9,9]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[B,0])]*r[A][54][1,1]*r[B][24][9,9]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][24][9,9]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][24][9,9]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[C,0])]*r[A][9][1,1]*r[C][9][11,11]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[C,0])]*r[A][24][1,1]*r[C][24][11,11]
    hv += g[dei(p[A,0],p[A,0],p[C,0],p[C,0])]*r[A][9][1,1]*r[C][24][11,11]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[C,1])]*r[A][9][1,1]*r[C][39][11,11]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[C,0])]*r[A][39][1,1]*r[C][9][11,11]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[C,0])]*r[A][54][1,1]*r[C][24][11,11]
    hv += g[dei(p[A,1],p[A,1],p[C,0],p[C,0])]*r[A][39][1,1]*r[C][24][11,11]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[C,1])]*r[A][39][1,1]*r[C][39][11,11]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,0])]*r[A][9][1,1]*r[C][9][11,11]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,0])]*r[A][24][1,1]*r[C][24][11,11]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,0])]*r[A][9][1,1]*r[C][39][11,11]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,1])]*r[A][39][1,1]*r[C][9][11,11]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,1])]*r[A][54][1,1]*r[C][24][11,11]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,1])]*r[A][39][1,1]*r[C][39][11,11]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[C,0])]*r[A][9][1,1]*r[C][9][11,11]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[C,0])]*r[A][24][1,1]*r[C][24][11,11]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[C,0])]*r[A][39][1,1]*r[C][9][11,11]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[C,0])]*r[A][54][1,1]*r[C][24][11,11]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[C,1])]*r[A][9][1,1]*r[C][39][11,11]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[C,1])]*r[A][39][1,1]*r[C][39][11,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,0])]*r[A][9][1,1]*r[C][9][11,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[C][24][11,11]
    hv += g[dei(p[C,0],p[C,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[C][9][11,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,1])]*r[A][39][1,1]*r[C][9][11,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[C][24][11,11]
    hv += g[dei(p[C,0],p[C,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[C][9][11,11]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,0])]*r[A][9][1,1]*r[C][39][11,11]
    hv += g[dei(p[C,1],p[C,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[C][39][11,11]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,1])]*r[A][39][1,1]*r[C][39][11,11]
    hv += g[dei(p[C,1],p[C,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[C][39][11,11]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,0],p[C,0])]*r[B][24][9,9]*r[C][24][11,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,0],p[B,0])]*r[B][24][9,9]*r[C][24][11,11]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,0],p[C,0])]*r[B][24][9,9]*r[C][24][11,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,0],p[B,0])]*r[B][24][9,9]*r[C][24][11,11]
    hv += g[dei(p[C,0],p[C,0],p[B,0],p[B,0])]*r[B][24][9,9]*r[C][9][11,11]
    hv += g[dei(p[C,1],p[C,1],p[B,0],p[B,0])]*r[B][24][9,9]*r[C][39][11,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B9C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,9),(C,11)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += h[p[A,0],p[A,0]]*r[A][9][0,1]
    hv += h[p[A,0],p[A,0]]*r[A][24][0,1]
    hv += h[p[A,1],p[A,1]]*r[A][39][0,1]
    hv += h[p[A,1],p[A,1]]*r[A][54][0,1]
    hv += g[dei(p[A,0],p[A,0],p[A,0],p[A,0])]*r[A][194][0,1]
    hv += g[dei(p[A,0],p[A,1],p[A,0],p[A,1])]*r[A][199][0,1]
    hv += g[dei(p[A,1],p[A,0],p[A,1],p[A,0])]*r[A][274][0,1]
    hv += g[dei(p[A,1],p[A,1],p[A,1],p[A,1])]*r[A][279][0,1]
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][9][0,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][24][0,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][9][0,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][9][0,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][24][0,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][9][0,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,0],p[I,0])]*r[A][39][0,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,0],p[I,0])]*r[A][54][0,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,1],p[I,0],p[I,0])]*r[A][39][0,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,1],p[I,1])]*r[A][39][0,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,1],p[I,1])]*r[A][54][0,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,1],p[I,1],p[I,1])]*r[A][39][0,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,0])]*r[A][9][0,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,0])]*r[A][24][0,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,0])]*r[A][9][0,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,0])]*r[A][24][0,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,1])]*r[A][39][0,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,1])]*r[A][54][0,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,1])]*r[A][39][0,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,1])]*r[A][54][0,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,0])]*r[A][9][0,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,0])]*r[A][24][0,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,1],p[I,0])]*r[A][39][0,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,1],p[I,0])]*r[A][54][0,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,1])]*r[A][9][0,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,1])]*r[A][24][0,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,1],p[I,1])]*r[A][39][0,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,1],p[I,1])]*r[A][54][0,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[B,0])]*r[A][24][0,1]*r[B][24][9,9]
    hv += g[dei(p[A,0],p[A,0],p[B,0],p[B,0])]*r[A][9][0,1]*r[B][24][9,9]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[B,0])]*r[A][54][0,1]*r[B][24][9,9]
    hv += g[dei(p[A,1],p[A,1],p[B,0],p[B,0])]*r[A][39][0,1]*r[B][24][9,9]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[A,0])]*r[A][24][0,1]*r[B][24][9,9]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[A,1])]*r[A][54][0,1]*r[B][24][9,9]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[B,0])]*r[A][24][0,1]*r[B][24][9,9]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[B,0])]*r[A][54][0,1]*r[B][24][9,9]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][24][9,9]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][24][9,9]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[C,0])]*r[A][9][0,1]*r[C][9][11,11]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[C,0])]*r[A][24][0,1]*r[C][24][11,11]
    hv += g[dei(p[A,0],p[A,0],p[C,0],p[C,0])]*r[A][9][0,1]*r[C][24][11,11]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[C,1])]*r[A][9][0,1]*r[C][39][11,11]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[C,0])]*r[A][39][0,1]*r[C][9][11,11]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[C,0])]*r[A][54][0,1]*r[C][24][11,11]
    hv += g[dei(p[A,1],p[A,1],p[C,0],p[C,0])]*r[A][39][0,1]*r[C][24][11,11]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[C,1])]*r[A][39][0,1]*r[C][39][11,11]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,0])]*r[A][9][0,1]*r[C][9][11,11]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,0])]*r[A][24][0,1]*r[C][24][11,11]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,0])]*r[A][9][0,1]*r[C][39][11,11]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,1])]*r[A][39][0,1]*r[C][9][11,11]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,1])]*r[A][54][0,1]*r[C][24][11,11]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,1])]*r[A][39][0,1]*r[C][39][11,11]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[C,0])]*r[A][9][0,1]*r[C][9][11,11]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[C,0])]*r[A][24][0,1]*r[C][24][11,11]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[C,0])]*r[A][39][0,1]*r[C][9][11,11]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[C,0])]*r[A][54][0,1]*r[C][24][11,11]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[C,1])]*r[A][9][0,1]*r[C][39][11,11]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[C,1])]*r[A][39][0,1]*r[C][39][11,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[C][9][11,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][24][11,11]
    hv += g[dei(p[C,0],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][9][11,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[C][9][11,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][24][11,11]
    hv += g[dei(p[C,0],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][9][11,11]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[C][39][11,11]
    hv += g[dei(p[C,1],p[C,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][39][11,11]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[C][39][11,11]
    hv += g[dei(p[C,1],p[C,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][39][11,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B9C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,9),(C,11)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += h[p[A,0],p[A,1]]*r[A][15][2,1]
    hv += h[p[A,0],p[A,1]]*r[A][30][2,1]
    hv += h[p[A,1],p[A,0]]*r[A][33][2,1]
    hv += h[p[A,1],p[A,0]]*r[A][48][2,1]
    hv += g[dei(p[A,0],p[A,0],p[A,1],p[A,0])]*r[A][210][2,1]
    hv += g[dei(p[A,0],p[A,1],p[A,1],p[A,1])]*r[A][215][2,1]
    hv += g[dei(p[A,1],p[A,0],p[A,0],p[A,0])]*r[A][258][2,1]
    hv += g[dei(p[A,1],p[A,1],p[A,0],p[A,1])]*r[A][263][2,1]
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,0],p[I,0])]*r[A][15][2,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,0],p[I,0])]*r[A][30][2,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,1],p[I,0],p[I,0])]*r[A][15][2,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,1],p[I,1])]*r[A][15][2,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,1],p[I,1])]*r[A][30][2,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,1],p[I,1],p[I,1])]*r[A][15][2,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][33][2,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][48][2,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][33][2,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][33][2,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][48][2,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][33][2,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,1])]*r[A][15][2,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,1])]*r[A][30][2,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,1])]*r[A][15][2,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,1])]*r[A][30][2,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,0])]*r[A][33][2,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,0])]*r[A][48][2,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,0])]*r[A][33][2,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,0])]*r[A][48][2,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,0],p[I,0])]*r[A][15][2,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,0],p[I,0])]*r[A][30][2,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,0])]*r[A][33][2,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,0])]*r[A][48][2,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,0],p[I,1])]*r[A][15][2,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,0],p[I,1])]*r[A][30][2,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,1])]*r[A][33][2,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,1])]*r[A][48][2,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,1])]*r[A][15][2,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][33][2,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,1])]*r[A][15][2,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][33][2,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[B,0])]*r[A][30][2,1]*r[B][24][9,9]
    hv += g[dei(p[A,0],p[A,1],p[B,0],p[B,0])]*r[A][15][2,1]*r[B][24][9,9]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[B,0])]*r[A][48][2,1]*r[B][24][9,9]
    hv += g[dei(p[A,1],p[A,0],p[B,0],p[B,0])]*r[A][33][2,1]*r[B][24][9,9]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[A,1])]*r[A][30][2,1]*r[B][24][9,9]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[A,0])]*r[A][48][2,1]*r[B][24][9,9]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[B,0])]*r[A][30][2,1]*r[B][24][9,9]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[B,0])]*r[A][48][2,1]*r[B][24][9,9]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][24][9,9]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][24][9,9]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,0],p[C,0])]*r[A][15][2,1]*r[C][9][11,11]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,0],p[C,0])]*r[A][30][2,1]*r[C][24][11,11]
    hv += g[dei(p[A,0],p[A,1],p[C,0],p[C,0])]*r[A][15][2,1]*r[C][24][11,11]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,1],p[C,1])]*r[A][15][2,1]*r[C][39][11,11]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,0],p[C,0])]*r[A][33][2,1]*r[C][9][11,11]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,0],p[C,0])]*r[A][48][2,1]*r[C][24][11,11]
    hv += g[dei(p[A,1],p[A,0],p[C,0],p[C,0])]*r[A][33][2,1]*r[C][24][11,11]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,1],p[C,1])]*r[A][33][2,1]*r[C][39][11,11]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,1])]*r[A][15][2,1]*r[C][9][11,11]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,1])]*r[A][30][2,1]*r[C][24][11,11]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,1])]*r[A][15][2,1]*r[C][39][11,11]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,0])]*r[A][33][2,1]*r[C][9][11,11]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,0])]*r[A][48][2,1]*r[C][24][11,11]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,0])]*r[A][33][2,1]*r[C][39][11,11]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,0],p[C,0])]*r[A][15][2,1]*r[C][9][11,11]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,0],p[C,0])]*r[A][30][2,1]*r[C][24][11,11]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,1],p[C,0])]*r[A][33][2,1]*r[C][9][11,11]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,1],p[C,0])]*r[A][48][2,1]*r[C][24][11,11]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,0],p[C,1])]*r[A][15][2,1]*r[C][39][11,11]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,1],p[C,1])]*r[A][33][2,1]*r[C][39][11,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,1])]*r[A][15][2,1]*r[C][9][11,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[C][24][11,11]
    hv += g[dei(p[C,0],p[C,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[C][9][11,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,0])]*r[A][33][2,1]*r[C][9][11,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[C][24][11,11]
    hv += g[dei(p[C,0],p[C,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[C][9][11,11]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,1])]*r[A][15][2,1]*r[C][39][11,11]
    hv += g[dei(p[C,1],p[C,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[C][39][11,11]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,0])]*r[A][33][2,1]*r[C][39][11,11]
    hv += g[dei(p[C,1],p[C,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[C][39][11,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B9C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,9),(C,11)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += h[p[A,0],p[A,1]]*r[A][15][3,1]
    hv += h[p[A,0],p[A,1]]*r[A][30][3,1]
    hv += h[p[A,1],p[A,0]]*r[A][33][3,1]
    hv += h[p[A,1],p[A,0]]*r[A][48][3,1]
    hv += g[dei(p[A,0],p[A,0],p[A,1],p[A,0])]*r[A][210][3,1]
    hv += g[dei(p[A,0],p[A,1],p[A,1],p[A,1])]*r[A][215][3,1]
    hv += g[dei(p[A,1],p[A,0],p[A,0],p[A,0])]*r[A][258][3,1]
    hv += g[dei(p[A,1],p[A,1],p[A,0],p[A,1])]*r[A][263][3,1]
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,0],p[I,0])]*r[A][15][3,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,0],p[I,0])]*r[A][30][3,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,1],p[I,0],p[I,0])]*r[A][15][3,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,1],p[I,1])]*r[A][15][3,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,1],p[I,1])]*r[A][30][3,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,1],p[I,1],p[I,1])]*r[A][15][3,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][33][3,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][48][3,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][33][3,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][33][3,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][48][3,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][33][3,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,1])]*r[A][15][3,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,1])]*r[A][30][3,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,1])]*r[A][15][3,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,1])]*r[A][30][3,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,0])]*r[A][33][3,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,0])]*r[A][48][3,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,0])]*r[A][33][3,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,0])]*r[A][48][3,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,0],p[I,0])]*r[A][15][3,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,0],p[I,0])]*r[A][30][3,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,0])]*r[A][33][3,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,0])]*r[A][48][3,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,0],p[I,1])]*r[A][15][3,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,0],p[I,1])]*r[A][30][3,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,1])]*r[A][33][3,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,1])]*r[A][48][3,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,1])]*r[A][15][3,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][33][3,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,1])]*r[A][15][3,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][33][3,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[B,0])]*r[A][30][3,1]*r[B][24][9,9]
    hv += g[dei(p[A,0],p[A,1],p[B,0],p[B,0])]*r[A][15][3,1]*r[B][24][9,9]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[B,0])]*r[A][48][3,1]*r[B][24][9,9]
    hv += g[dei(p[A,1],p[A,0],p[B,0],p[B,0])]*r[A][33][3,1]*r[B][24][9,9]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[A,1])]*r[A][30][3,1]*r[B][24][9,9]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[A,0])]*r[A][48][3,1]*r[B][24][9,9]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[B,0])]*r[A][30][3,1]*r[B][24][9,9]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[B,0])]*r[A][48][3,1]*r[B][24][9,9]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][24][9,9]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][24][9,9]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,0],p[C,0])]*r[A][15][3,1]*r[C][9][11,11]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,0],p[C,0])]*r[A][30][3,1]*r[C][24][11,11]
    hv += g[dei(p[A,0],p[A,1],p[C,0],p[C,0])]*r[A][15][3,1]*r[C][24][11,11]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,1],p[C,1])]*r[A][15][3,1]*r[C][39][11,11]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,0],p[C,0])]*r[A][33][3,1]*r[C][9][11,11]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,0],p[C,0])]*r[A][48][3,1]*r[C][24][11,11]
    hv += g[dei(p[A,1],p[A,0],p[C,0],p[C,0])]*r[A][33][3,1]*r[C][24][11,11]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,1],p[C,1])]*r[A][33][3,1]*r[C][39][11,11]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,1])]*r[A][15][3,1]*r[C][9][11,11]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,1])]*r[A][30][3,1]*r[C][24][11,11]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,1])]*r[A][15][3,1]*r[C][39][11,11]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,0])]*r[A][33][3,1]*r[C][9][11,11]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,0])]*r[A][48][3,1]*r[C][24][11,11]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,0])]*r[A][33][3,1]*r[C][39][11,11]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,0],p[C,0])]*r[A][15][3,1]*r[C][9][11,11]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,0],p[C,0])]*r[A][30][3,1]*r[C][24][11,11]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,1],p[C,0])]*r[A][33][3,1]*r[C][9][11,11]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,1],p[C,0])]*r[A][48][3,1]*r[C][24][11,11]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,0],p[C,1])]*r[A][15][3,1]*r[C][39][11,11]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,1],p[C,1])]*r[A][33][3,1]*r[C][39][11,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,1])]*r[A][15][3,1]*r[C][9][11,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[C][24][11,11]
    hv += g[dei(p[C,0],p[C,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[C][9][11,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,0])]*r[A][33][3,1]*r[C][9][11,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[C][24][11,11]
    hv += g[dei(p[C,0],p[C,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[C][9][11,11]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,1])]*r[A][15][3,1]*r[C][39][11,11]
    hv += g[dei(p[C,1],p[C,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[C][39][11,11]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,0])]*r[A][33][3,1]*r[C][39][11,11]
    hv += g[dei(p[C,1],p[C,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[C][39][11,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B10C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,10),(C,11)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += h[p[B,1],p[B,0]]*r[B][48][10,9]
    hv += sum(1/2*g[dei(p[B,1],p[B,0],p[I,0],p[I,0])]*r[B][48][10,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[B,0],p[I,1],p[I,1])]*r[B][48][10,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,0],p[I,0],p[B,0])]*r[B][48][10,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,1],p[I,1],p[B,0])]*r[B][48][10,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,0],p[B,1],p[I,0])]*r[B][48][10,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,0],p[B,1],p[I,1])]*r[B][48][10,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,1],p[B,0])]*r[B][48][10,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[B,1],p[B,0])]*r[B][48][10,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,1],p[B,0])]*r[B][48][10,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[B,1],p[B,0])]*r[B][48][10,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[B,0])]*r[A][24][1,1]*r[B][48][10,9]
    hv += g[dei(p[A,0],p[A,0],p[B,1],p[B,0])]*r[A][9][1,1]*r[B][48][10,9]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[B,0])]*r[A][54][1,1]*r[B][48][10,9]
    hv += g[dei(p[A,1],p[A,1],p[B,1],p[B,0])]*r[A][39][1,1]*r[B][48][10,9]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[A,0])]*r[A][24][1,1]*r[B][48][10,9]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[A,1])]*r[A][54][1,1]*r[B][48][10,9]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[B,0])]*r[A][24][1,1]*r[B][48][10,9]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[B,0])]*r[A][54][1,1]*r[B][48][10,9]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][48][10,9]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][48][10,9]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,0],p[C,0])]*r[B][48][10,9]*r[C][24][11,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,0],p[B,0])]*r[B][48][10,9]*r[C][24][11,11]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,1],p[C,0])]*r[B][48][10,9]*r[C][24][11,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,1],p[B,0])]*r[B][48][10,9]*r[C][24][11,11]
    hv += g[dei(p[C,0],p[C,0],p[B,1],p[B,0])]*r[B][48][10,9]*r[C][9][11,11]
    hv += g[dei(p[C,1],p[C,1],p[B,1],p[B,0])]*r[B][48][10,9]*r[C][39][11,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B9C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,9),(C,12)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += h[p[C,1],p[C,0]]*r[C][48][12,11]
    hv += g[dei(p[C,0],p[C,0],p[C,1],p[C,0])]*r[C][210][12,11]
    hv += g[dei(p[C,1],p[C,1],p[C,1],p[C,0])]*r[C][275][12,11]
    hv += sum(1/2*g[dei(p[C,1],p[C,0],p[I,0],p[I,0])]*r[C][48][12,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[C,0],p[I,1],p[I,1])]*r[C][48][12,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,0],p[I,0],p[C,0])]*r[C][48][12,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,1],p[I,1],p[C,0])]*r[C][48][12,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,0],p[C,1],p[I,0])]*r[C][48][12,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,0],p[C,1],p[I,1])]*r[C][48][12,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,1],p[C,0])]*r[C][48][12,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[C,1],p[C,0])]*r[C][48][12,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,1],p[C,0])]*r[C][48][12,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[C,1],p[C,0])]*r[C][48][12,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[C,0])]*r[A][24][1,1]*r[C][48][12,11]
    hv += g[dei(p[A,0],p[A,0],p[C,1],p[C,0])]*r[A][9][1,1]*r[C][48][12,11]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[C,0])]*r[A][54][1,1]*r[C][48][12,11]
    hv += g[dei(p[A,1],p[A,1],p[C,1],p[C,0])]*r[A][39][1,1]*r[C][48][12,11]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[A,0])]*r[A][24][1,1]*r[C][48][12,11]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[A,1])]*r[A][54][1,1]*r[C][48][12,11]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[C,0])]*r[A][24][1,1]*r[C][48][12,11]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[C,0])]*r[A][54][1,1]*r[C][48][12,11]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[C][48][12,11]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[C][48][12,11]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,1],p[C,0])]*r[B][24][9,9]*r[C][48][12,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,1],p[B,0])]*r[B][24][9,9]*r[C][48][12,11]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,0],p[C,0])]*r[B][24][9,9]*r[C][48][12,11]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,0],p[B,0])]*r[B][24][9,9]*r[C][48][12,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B9C11I1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,9),(C,11),(I,1)]))
        hv = 0.0
        sket = sign([B,C])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][9][0,1]*r[I][9][1,0]
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][24][0,1]*r[I][24][1,0]
        hv += g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][9][0,1]*r[I][24][1,0]
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][9][0,1]*r[I][39][1,0]
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][24][0,1]*r[I][54][1,0]
        hv += g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][9][0,1]*r[I][54][1,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,0],p[I,0])]*r[A][39][0,1]*r[I][9][1,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,0],p[I,0])]*r[A][54][0,1]*r[I][24][1,0]
        hv += g[dei(p[A,1],p[A,1],p[I,0],p[I,0])]*r[A][39][0,1]*r[I][24][1,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,1],p[I,1])]*r[A][39][0,1]*r[I][39][1,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,1],p[I,1])]*r[A][54][0,1]*r[I][54][1,0]
        hv += g[dei(p[A,1],p[A,1],p[I,1],p[I,1])]*r[A][39][0,1]*r[I][54][1,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,0])]*r[A][9][0,1]*r[I][9][1,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,0])]*r[A][24][0,1]*r[I][24][1,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,0])]*r[A][9][0,1]*r[I][39][1,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,0])]*r[A][24][0,1]*r[I][54][1,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,1])]*r[A][39][0,1]*r[I][9][1,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,1])]*r[A][54][0,1]*r[I][24][1,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,1])]*r[A][39][0,1]*r[I][39][1,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,1])]*r[A][54][0,1]*r[I][54][1,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,0])]*r[A][9][0,1]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,0])]*r[A][24][0,1]*r[I][24][1,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,1],p[I,0])]*r[A][39][0,1]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,1],p[I,0])]*r[A][54][0,1]*r[I][24][1,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,1])]*r[A][9][0,1]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,1])]*r[A][24][0,1]*r[I][54][1,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,1],p[I,1])]*r[A][39][0,1]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,1],p[I,1])]*r[A][54][0,1]*r[I][54][1,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][24][1,0]
        hv += g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][24][1,0]
        hv += g[dei(p[I,0],p[I,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][54][1,0]
        hv += g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][54][1,0]
        hv += g[dei(p[I,1],p[I,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B9C11I2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,9),(C,11),(I,2)]))
        hv = 0.0
        sket = sign([B,C])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,1])]*r[A][9][0,1]*r[I][15][2,0]
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,1])]*r[A][24][0,1]*r[I][30][2,0]
        hv += g[dei(p[A,0],p[A,0],p[I,0],p[I,1])]*r[A][9][0,1]*r[I][30][2,0]
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,0])]*r[A][9][0,1]*r[I][33][2,0]
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,0])]*r[A][24][0,1]*r[I][48][2,0]
        hv += g[dei(p[A,0],p[A,0],p[I,1],p[I,0])]*r[A][9][0,1]*r[I][48][2,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,0],p[I,1])]*r[A][39][0,1]*r[I][15][2,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,0],p[I,1])]*r[A][54][0,1]*r[I][30][2,0]
        hv += g[dei(p[A,1],p[A,1],p[I,0],p[I,1])]*r[A][39][0,1]*r[I][30][2,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,1],p[I,0])]*r[A][39][0,1]*r[I][33][2,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,1],p[I,0])]*r[A][54][0,1]*r[I][48][2,0]
        hv += g[dei(p[A,1],p[A,1],p[I,1],p[I,0])]*r[A][39][0,1]*r[I][48][2,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[I,0],p[A,0])]*r[A][9][0,1]*r[I][15][2,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[I,0],p[A,0])]*r[A][24][0,1]*r[I][30][2,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[I,1],p[A,0])]*r[A][9][0,1]*r[I][33][2,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[I,1],p[A,0])]*r[A][24][0,1]*r[I][48][2,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[I,0],p[A,1])]*r[A][39][0,1]*r[I][15][2,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[I,0],p[A,1])]*r[A][54][0,1]*r[I][30][2,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[I,1],p[A,1])]*r[A][39][0,1]*r[I][33][2,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[I,1],p[A,1])]*r[A][54][0,1]*r[I][48][2,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,1])]*r[A][9][0,1]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,1])]*r[A][24][0,1]*r[I][30][2,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,1],p[I,1])]*r[A][39][0,1]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,1],p[I,1])]*r[A][54][0,1]*r[I][30][2,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,0])]*r[A][9][0,1]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,0])]*r[A][24][0,1]*r[I][48][2,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,1],p[I,0])]*r[A][39][0,1]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,1],p[I,0])]*r[A][54][0,1]*r[I][48][2,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][30][2,0]
        hv += g[dei(p[I,0],p[I,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][30][2,0]
        hv += g[dei(p[I,0],p[I,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][48][2,0]
        hv += g[dei(p[I,1],p[I,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][48][2,0]
        hv += g[dei(p[I,1],p[I,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B9C11I3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,9),(C,11),(I,3)]))
        hv = 0.0
        sket = sign([B,C])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,1])]*r[A][9][0,1]*r[I][15][3,0]
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,1])]*r[A][24][0,1]*r[I][30][3,0]
        hv += g[dei(p[A,0],p[A,0],p[I,0],p[I,1])]*r[A][9][0,1]*r[I][30][3,0]
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,0])]*r[A][9][0,1]*r[I][33][3,0]
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,0])]*r[A][24][0,1]*r[I][48][3,0]
        hv += g[dei(p[A,0],p[A,0],p[I,1],p[I,0])]*r[A][9][0,1]*r[I][48][3,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,0],p[I,1])]*r[A][39][0,1]*r[I][15][3,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,0],p[I,1])]*r[A][54][0,1]*r[I][30][3,0]
        hv += g[dei(p[A,1],p[A,1],p[I,0],p[I,1])]*r[A][39][0,1]*r[I][30][3,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,1],p[I,0])]*r[A][39][0,1]*r[I][33][3,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,1],p[I,0])]*r[A][54][0,1]*r[I][48][3,0]
        hv += g[dei(p[A,1],p[A,1],p[I,1],p[I,0])]*r[A][39][0,1]*r[I][48][3,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[I,0],p[A,0])]*r[A][9][0,1]*r[I][15][3,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[I,0],p[A,0])]*r[A][24][0,1]*r[I][30][3,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[I,1],p[A,0])]*r[A][9][0,1]*r[I][33][3,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[I,1],p[A,0])]*r[A][24][0,1]*r[I][48][3,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[I,0],p[A,1])]*r[A][39][0,1]*r[I][15][3,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[I,0],p[A,1])]*r[A][54][0,1]*r[I][30][3,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[I,1],p[A,1])]*r[A][39][0,1]*r[I][33][3,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[I,1],p[A,1])]*r[A][54][0,1]*r[I][48][3,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,1])]*r[A][9][0,1]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,1])]*r[A][24][0,1]*r[I][30][3,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,1],p[I,1])]*r[A][39][0,1]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,1],p[I,1])]*r[A][54][0,1]*r[I][30][3,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,0])]*r[A][9][0,1]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,0])]*r[A][24][0,1]*r[I][48][3,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,1],p[I,0])]*r[A][39][0,1]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,1],p[I,0])]*r[A][54][0,1]*r[I][48][3,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][30][3,0]
        hv += g[dei(p[I,0],p[I,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][30][3,0]
        hv += g[dei(p[I,0],p[I,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][48][3,0]
        hv += g[dei(p[I,1],p[I,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][48][3,0]
        hv += g[dei(p[I,1],p[I,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C11I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,11),(I,9)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += h[p[B,0],p[I,0]]*r[B][0][0,9]*r[I][1][9,0]
        hv += g[dei(p[B,0],p[I,0],p[B,0],p[B,0])]*r[B][66][0,9]*r[I][1][9,0]
        hv += g[dei(p[B,1],p[I,0],p[B,1],p[B,0])]*r[B][146][0,9]*r[I][1][9,0]
        hv += g[dei(p[B,0],p[I,0],p[I,0],p[I,0])]*r[B][0][0,9]*r[I][97][9,0]
        hv += g[dei(p[B,0],p[I,1],p[I,0],p[I,1])]*r[B][0][0,9]*r[I][117][9,0]
        hv += sum(-1/4*g[dei(p[B,0],p[J,0],p[J,0],p[I,0])]*r[B][0][0,9]*r[J][9][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[B,0],p[J,1],p[J,1],p[I,0])]*r[B][0][0,9]*r[J][39][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[B,0],p[I,0],p[J,0],p[J,0])]*r[B][0][0,9]*r[J][9][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[B,0],p[I,0],p[J,0],p[J,0])]*r[B][0][0,9]*r[J][24][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[B,0],p[I,0],p[J,1],p[J,1])]*r[B][0][0,9]*r[J][39][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[B,0],p[I,0],p[J,1],p[J,1])]*r[B][0][0,9]*r[J][54][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[B,0],p[I,0])]*r[B][0][0,9]*r[J][9][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[B,0],p[I,0])]*r[B][0][0,9]*r[J][39][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[B,0],p[J,0])]*r[B][0][0,9]*r[J][9][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[B,0],p[J,1])]*r[B][0][0,9]*r[J][39][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[B,0],p[I,0],p[J,0],p[J,0])]*r[B][0][0,9]*r[I][1][9,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[B,0],p[I,0],p[J,0],p[J,0])]*r[B][0][0,9]*r[I][1][9,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[B,0],p[I,0],p[J,1],p[J,1])]*r[B][0][0,9]*r[I][1][9,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[B,0],p[I,0],p[J,1],p[J,1])]*r[B][0][0,9]*r[I][1][9,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[B,0],p[J,0],p[J,0],p[I,0])]*r[B][0][0,9]*r[I][1][9,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[B,0],p[J,1],p[J,1],p[I,0])]*r[B][0][0,9]*r[I][1][9,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[B,0],p[J,0])]*r[B][0][0,9]*r[I][1][9,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[B,0],p[J,1])]*r[B][0][0,9]*r[I][1][9,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[B,0],p[I,0])]*r[B][0][0,9]*r[I][1][9,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[B,0],p[I,0])]*r[B][0][0,9]*r[I][1][9,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[I,0])]*r[A][9][1,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[I,0])]*r[A][39][1,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,0],p[A,0])]*r[A][9][1,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,0],p[A,1])]*r[A][39][1,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[I,0])]*r[A][9][1,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[I,0])]*r[A][39][1,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += g[dei(p[B,0],p[I,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += g[dei(p[B,0],p[I,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[C,0],p[I,0])]*r[B][0][0,9]*r[C][9][11,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[C,1],p[C,1],p[I,0])]*r[B][0][0,9]*r[C][39][11,11]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[C,0],p[C,0])]*r[B][0][0,9]*r[C][9][11,11]*r[I][1][9,0]
        hv += g[dei(p[B,0],p[I,0],p[C,0],p[C,0])]*r[B][0][0,9]*r[C][24][11,11]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[C,1],p[C,1])]*r[B][0][0,9]*r[C][39][11,11]*r[I][1][9,0]
        hv += 1/2*g[dei(p[C,0],p[C,0],p[B,0],p[I,0])]*r[B][0][0,9]*r[C][9][11,11]*r[I][1][9,0]
        hv += 1/2*g[dei(p[C,1],p[C,1],p[B,0],p[I,0])]*r[B][0][0,9]*r[C][39][11,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[C,0],p[I,0],p[B,0],p[C,0])]*r[B][0][0,9]*r[C][9][11,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[C,1],p[I,0],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][39][11,11]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C11I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,11),(I,10)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += h[p[B,0],p[I,1]]*r[B][0][0,9]*r[I][5][10,0]
        hv += g[dei(p[B,0],p[I,1],p[B,0],p[B,0])]*r[B][66][0,9]*r[I][5][10,0]
        hv += g[dei(p[B,1],p[I,1],p[B,1],p[B,0])]*r[B][146][0,9]*r[I][5][10,0]
        hv += g[dei(p[B,0],p[I,0],p[I,1],p[I,0])]*r[B][0][0,9]*r[I][161][10,0]
        hv += g[dei(p[B,0],p[I,1],p[I,1],p[I,1])]*r[B][0][0,9]*r[I][181][10,0]
        hv += sum(-1/4*g[dei(p[B,0],p[J,0],p[J,0],p[I,1])]*r[B][0][0,9]*r[J][9][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[B,0],p[J,1],p[J,1],p[I,1])]*r[B][0][0,9]*r[J][39][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[B,0],p[I,1],p[J,0],p[J,0])]*r[B][0][0,9]*r[J][9][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[B,0],p[I,1],p[J,0],p[J,0])]*r[B][0][0,9]*r[J][24][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[B,0],p[I,1],p[J,1],p[J,1])]*r[B][0][0,9]*r[J][39][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[B,0],p[I,1],p[J,1],p[J,1])]*r[B][0][0,9]*r[J][54][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[B,0],p[I,1])]*r[B][0][0,9]*r[J][9][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[B,0],p[I,1])]*r[B][0][0,9]*r[J][39][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[B,0],p[J,0])]*r[B][0][0,9]*r[J][9][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[B,0],p[J,1])]*r[B][0][0,9]*r[J][39][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[B,0],p[I,1],p[J,0],p[J,0])]*r[B][0][0,9]*r[I][5][10,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[B,0],p[I,1],p[J,0],p[J,0])]*r[B][0][0,9]*r[I][5][10,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[B,0],p[I,1],p[J,1],p[J,1])]*r[B][0][0,9]*r[I][5][10,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[B,0],p[I,1],p[J,1],p[J,1])]*r[B][0][0,9]*r[I][5][10,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[B,0],p[J,0],p[J,0],p[I,1])]*r[B][0][0,9]*r[I][5][10,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[B,0],p[J,1],p[J,1],p[I,1])]*r[B][0][0,9]*r[I][5][10,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[B,0],p[J,0])]*r[B][0][0,9]*r[I][5][10,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[B,0],p[J,1])]*r[B][0][0,9]*r[I][5][10,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[B,0],p[I,1])]*r[B][0][0,9]*r[I][5][10,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[B,0],p[I,1])]*r[B][0][0,9]*r[I][5][10,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[I,1])]*r[A][9][1,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[I,1])]*r[A][39][1,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,0],p[A,0])]*r[A][9][1,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,0],p[A,1])]*r[A][39][1,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[I,1])]*r[A][9][1,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[I,1])]*r[A][39][1,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += g[dei(p[B,0],p[I,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += g[dei(p[B,0],p[I,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[C,0],p[I,1])]*r[B][0][0,9]*r[C][9][11,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[C,1],p[C,1],p[I,1])]*r[B][0][0,9]*r[C][39][11,11]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[C,0],p[C,0])]*r[B][0][0,9]*r[C][9][11,11]*r[I][5][10,0]
        hv += g[dei(p[B,0],p[I,1],p[C,0],p[C,0])]*r[B][0][0,9]*r[C][24][11,11]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[C,1],p[C,1])]*r[B][0][0,9]*r[C][39][11,11]*r[I][5][10,0]
        hv += 1/2*g[dei(p[C,0],p[C,0],p[B,0],p[I,1])]*r[B][0][0,9]*r[C][9][11,11]*r[I][5][10,0]
        hv += 1/2*g[dei(p[C,1],p[C,1],p[B,0],p[I,1])]*r[B][0][0,9]*r[C][39][11,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[C,0],p[I,1],p[B,0],p[C,0])]*r[B][0][0,9]*r[C][9][11,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[C,1],p[I,1],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][39][11,11]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B9I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,9),(I,12)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += h[p[I,0],p[C,1]]*r[C][5][0,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[C,0],p[C,0],p[I,0],p[C,1])]*r[C][73][0,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[C,0],p[C,1],p[I,0],p[C,0])]*r[C][61][0,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[C,0],p[C,1])]*r[C][73][0,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[C,0],p[C,0])]*r[C][61][0,11]*r[I][0][12,0]
        hv += g[dei(p[I,0],p[C,1],p[C,0],p[C,0])]*r[C][101][0,11]*r[I][0][12,0]
        hv += g[dei(p[I,0],p[C,0],p[C,1],p[C,0])]*r[C][161][0,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[I,1],p[I,1])]*r[C][5][0,11]*r[I][76][12,0]
        hv += g[dei(p[I,0],p[C,1],p[I,1],p[I,1])]*r[C][5][0,11]*r[I][86][12,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[I,0],p[I,1])]*r[C][5][0,11]*r[I][124][12,0]
        hv += g[dei(p[I,1],p[C,1],p[I,1],p[I,0])]*r[C][5][0,11]*r[I][146][12,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[I,1],p[C,1])]*r[C][5][0,11]*r[I][76][12,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[I,0],p[C,1])]*r[C][5][0,11]*r[I][124][12,0]
        hv += sum(-1/4*g[dei(p[J,0],p[C,1],p[I,0],p[J,0])]*r[C][5][0,11]*r[J][9][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[J,1],p[C,1],p[I,0],p[J,1])]*r[C][5][0,11]*r[J][39][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[C,1])]*r[C][5][0,11]*r[J][9][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[C,1])]*r[C][5][0,11]*r[J][39][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[I,0],p[C,1],p[J,0],p[J,0])]*r[C][5][0,11]*r[J][9][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[I,0],p[C,1],p[J,0],p[J,0])]*r[C][5][0,11]*r[J][24][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[I,0],p[C,1],p[J,1],p[J,1])]*r[C][5][0,11]*r[J][39][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[I,0],p[C,1],p[J,1],p[J,1])]*r[C][5][0,11]*r[J][54][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[C,1])]*r[C][5][0,11]*r[J][9][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[C,1])]*r[C][5][0,11]*r[J][39][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[I,0],p[C,1],p[J,0],p[J,0])]*r[C][5][0,11]*r[I][0][12,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[I,0],p[C,1],p[J,0],p[J,0])]*r[C][5][0,11]*r[I][0][12,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[I,0],p[C,1],p[J,1],p[J,1])]*r[C][5][0,11]*r[I][0][12,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[I,0],p[C,1],p[J,1],p[J,1])]*r[C][5][0,11]*r[I][0][12,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[C,1])]*r[C][5][0,11]*r[I][0][12,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[C,1])]*r[C][5][0,11]*r[I][0][12,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[J,0],p[C,1],p[I,0],p[J,0])]*r[C][5][0,11]*r[I][0][12,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[J,1],p[C,1],p[I,0],p[J,1])]*r[C][5][0,11]*r[I][0][12,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[C,1])]*r[C][5][0,11]*r[I][0][12,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[C,1])]*r[C][5][0,11]*r[I][0][12,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,0],p[C,1])]*r[A][9][1,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,0],p[C,1])]*r[A][39][1,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[A,0],p[C,1],p[I,0],p[A,0])]*r[A][9][1,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[A,1],p[C,1],p[I,0],p[A,1])]*r[A][39][1,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,0],p[C,1])]*r[A][9][1,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,1],p[C,1])]*r[A][39][1,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[A,0],p[A,0])]*r[A][9][1,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += g[dei(p[I,0],p[C,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[A,1],p[A,1])]*r[A][39][1,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += g[dei(p[I,0],p[C,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += g[dei(p[I,0],p[C,1],p[B,0],p[B,0])]*r[B][24][9,9]*r[C][5][0,11]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B9I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,9),(I,11)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += h[p[I,1],p[C,1]]*r[C][5][0,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[C,0],p[C,0],p[I,1],p[C,1])]*r[C][73][0,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[C,0],p[C,1],p[I,1],p[C,0])]*r[C][61][0,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[C,0],p[C,1])]*r[C][73][0,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[C,0],p[C,0])]*r[C][61][0,11]*r[I][4][11,0]
        hv += g[dei(p[I,1],p[C,1],p[C,0],p[C,0])]*r[C][101][0,11]*r[I][4][11,0]
        hv += g[dei(p[I,1],p[C,0],p[C,1],p[C,0])]*r[C][161][0,11]*r[I][4][11,0]
        hv += g[dei(p[I,0],p[C,1],p[I,0],p[I,1])]*r[C][5][0,11]*r[I][70][11,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[I,1],p[I,0])]*r[C][5][0,11]*r[I][72][11,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[I,0],p[I,0])]*r[C][5][0,11]*r[I][120][11,0]
        hv += g[dei(p[I,1],p[C,1],p[I,0],p[I,0])]*r[C][5][0,11]*r[I][130][11,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[I,1],p[C,1])]*r[C][5][0,11]*r[I][72][11,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[I,0],p[C,1])]*r[C][5][0,11]*r[I][120][11,0]
        hv += sum(-1/4*g[dei(p[J,0],p[C,1],p[I,1],p[J,0])]*r[C][5][0,11]*r[J][9][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[J,1],p[C,1],p[I,1],p[J,1])]*r[C][5][0,11]*r[J][39][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[C,1])]*r[C][5][0,11]*r[J][9][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[C,1])]*r[C][5][0,11]*r[J][39][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[I,1],p[C,1],p[J,0],p[J,0])]*r[C][5][0,11]*r[J][9][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[I,1],p[C,1],p[J,0],p[J,0])]*r[C][5][0,11]*r[J][24][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[I,1],p[C,1],p[J,1],p[J,1])]*r[C][5][0,11]*r[J][39][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[I,1],p[C,1],p[J,1],p[J,1])]*r[C][5][0,11]*r[J][54][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[C,1])]*r[C][5][0,11]*r[J][9][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[C,1])]*r[C][5][0,11]*r[J][39][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[I,1],p[C,1],p[J,0],p[J,0])]*r[C][5][0,11]*r[I][4][11,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[I,1],p[C,1],p[J,0],p[J,0])]*r[C][5][0,11]*r[I][4][11,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[I,1],p[C,1],p[J,1],p[J,1])]*r[C][5][0,11]*r[I][4][11,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[I,1],p[C,1],p[J,1],p[J,1])]*r[C][5][0,11]*r[I][4][11,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[C,1])]*r[C][5][0,11]*r[I][4][11,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[C,1])]*r[C][5][0,11]*r[I][4][11,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[J,0],p[C,1],p[I,1],p[J,0])]*r[C][5][0,11]*r[I][4][11,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[J,1],p[C,1],p[I,1],p[J,1])]*r[C][5][0,11]*r[I][4][11,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[C,1])]*r[C][5][0,11]*r[I][4][11,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[C,1])]*r[C][5][0,11]*r[I][4][11,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,1],p[C,1])]*r[A][9][1,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,1],p[C,1])]*r[A][39][1,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[A,0],p[C,1],p[I,1],p[A,0])]*r[A][9][1,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[A,1],p[C,1],p[I,1],p[A,1])]*r[A][39][1,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,0],p[C,1])]*r[A][9][1,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,1],p[C,1])]*r[A][39][1,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[A,0],p[A,0])]*r[A][9][1,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += g[dei(p[I,1],p[C,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[A,1],p[A,1])]*r[A][39][1,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += g[dei(p[I,1],p[C,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += g[dei(p[I,1],p[C,1],p[B,0],p[B,0])]*r[B][24][9,9]*r[C][5][0,11]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B6C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,6),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += h[p[A,0],p[B,0]]*r[A][2][14,1]*r[B][3][6,9]
    hv += -1/2*g[dei(p[A,0],p[A,1],p[A,1],p[B,0])]*r[A][118][14,1]*r[B][3][6,9]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[A,0],p[B,0])]*r[A][166][14,1]*r[B][3][6,9]
    hv += -1*g[dei(p[A,1],p[A,1],p[A,0],p[B,0])]*r[A][132][14,1]*r[B][3][6,9]
    hv += -1*g[dei(p[A,1],p[A,0],p[A,1],p[B,0])]*r[A][144][14,1]*r[B][3][6,9]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[A,1],p[A,1])]*r[A][118][14,1]*r[B][3][6,9]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[A,0],p[A,1])]*r[A][166][14,1]*r[B][3][6,9]
    hv += sum(1/2*g[dei(p[A,0],p[B,0],p[I,0],p[I,0])]*r[A][2][14,1]*r[B][3][6,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[B,0],p[I,1],p[I,1])]*r[A][2][14,1]*r[B][3][6,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[B,0])]*r[A][2][14,1]*r[B][3][6,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[B,0])]*r[A][2][14,1]*r[B][3][6,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,0],p[A,0],p[I,0])]*r[A][2][14,1]*r[B][3][6,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,0],p[A,0],p[I,1])]*r[A][2][14,1]*r[B][3][6,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][3][6,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][3][6,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][3][6,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][3][6,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,0],p[C,0])]*r[A][2][14,1]*r[B][3][6,9]*r[C][24][11,11]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[B,0])]*r[A][2][14,1]*r[B][3][6,9]*r[C][24][11,11]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][3][6,9]*r[C][24][11,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][3][6,9]*r[C][24][11,11]
    hv += g[dei(p[C,0],p[C,0],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][3][6,9]*r[C][9][11,11]
    hv += g[dei(p[C,1],p[C,1],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][3][6,9]*r[C][39][11,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B6C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,6),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += h[p[A,1],p[B,0]]*r[A][6][13,1]*r[B][3][6,9]
    hv += -1*g[dei(p[A,0],p[A,1],p[A,0],p[B,0])]*r[A][68][13,1]*r[B][3][6,9]
    hv += -1/2*g[dei(p[A,0],p[A,0],p[A,1],p[B,0])]*r[A][114][13,1]*r[B][3][6,9]
    hv += -1*g[dei(p[A,0],p[A,0],p[A,1],p[B,0])]*r[A][80][13,1]*r[B][3][6,9]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[A,0],p[B,0])]*r[A][162][13,1]*r[B][3][6,9]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[A,1],p[A,0])]*r[A][114][13,1]*r[B][3][6,9]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[A,0],p[A,0])]*r[A][162][13,1]*r[B][3][6,9]
    hv += sum(1/2*g[dei(p[A,1],p[B,0],p[I,0],p[I,0])]*r[A][6][13,1]*r[B][3][6,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[B,0],p[I,1],p[I,1])]*r[A][6][13,1]*r[B][3][6,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[B,0])]*r[A][6][13,1]*r[B][3][6,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[B,0])]*r[A][6][13,1]*r[B][3][6,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,0],p[A,1],p[I,0])]*r[A][6][13,1]*r[B][3][6,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,0],p[A,1],p[I,1])]*r[A][6][13,1]*r[B][3][6,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][3][6,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][3][6,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][3][6,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][3][6,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,0],p[C,0])]*r[A][6][13,1]*r[B][3][6,9]*r[C][24][11,11]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[B,0])]*r[A][6][13,1]*r[B][3][6,9]*r[C][24][11,11]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][3][6,9]*r[C][24][11,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][3][6,9]*r[C][24][11,11]
    hv += g[dei(p[C,0],p[C,0],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][3][6,9]*r[C][9][11,11]
    hv += g[dei(p[C,1],p[C,1],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][3][6,9]*r[C][39][11,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[B,0],p[A,0]]*r[A][1][9,1]*r[B][0][0,9]
    hv += -1*g[dei(p[B,0],p[A,0],p[A,0],p[A,0])]*r[A][97][9,1]*r[B][0][0,9]
    hv += -1*g[dei(p[B,0],p[A,1],p[A,0],p[A,1])]*r[A][117][9,1]*r[B][0][0,9]
    hv += -1*g[dei(p[B,0],p[A,0],p[B,0],p[B,0])]*r[A][1][9,1]*r[B][66][0,9]
    hv += -1*g[dei(p[B,1],p[A,0],p[B,1],p[B,0])]*r[A][1][9,1]*r[B][146][0,9]
    hv += sum(-1/2*g[dei(p[B,0],p[A,0],p[I,0],p[I,0])]*r[A][1][9,1]*r[B][0][0,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[A,0],p[I,0],p[I,0])]*r[A][1][9,1]*r[B][0][0,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[A,0],p[I,1],p[I,1])]*r[A][1][9,1]*r[B][0][0,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[A,0],p[I,1],p[I,1])]*r[A][1][9,1]*r[B][0][0,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,0],p[B,0],p[I,0])]*r[A][1][9,1]*r[B][0][0,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,0],p[B,0],p[I,1])]*r[A][1][9,1]*r[B][0][0,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,0],p[A,0],p[C,0],p[C,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][9][11,11]
    hv += -1*g[dei(p[B,0],p[A,0],p[C,0],p[C,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][24][11,11]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[C,1],p[C,1])]*r[A][1][9,1]*r[B][0][0,9]*r[C][39][11,11]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[C,0],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][9][11,11]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,1],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][39][11,11]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[B,0],p[C,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][9][11,11]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[B,0],p[C,1])]*r[A][1][9,1]*r[B][0][0,9]*r[C][39][11,11]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][9][11,11]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][39][11,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B1C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,1),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[B,0],p[A,0]]*r[A][1][9,1]*r[B][0][1,9]
    hv += -1*g[dei(p[B,0],p[A,0],p[A,0],p[A,0])]*r[A][97][9,1]*r[B][0][1,9]
    hv += -1*g[dei(p[B,0],p[A,1],p[A,0],p[A,1])]*r[A][117][9,1]*r[B][0][1,9]
    hv += -1*g[dei(p[B,0],p[A,0],p[B,0],p[B,0])]*r[A][1][9,1]*r[B][66][1,9]
    hv += -1*g[dei(p[B,1],p[A,0],p[B,1],p[B,0])]*r[A][1][9,1]*r[B][146][1,9]
    hv += sum(-1/2*g[dei(p[B,0],p[A,0],p[I,0],p[I,0])]*r[A][1][9,1]*r[B][0][1,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[A,0],p[I,0],p[I,0])]*r[A][1][9,1]*r[B][0][1,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[A,0],p[I,1],p[I,1])]*r[A][1][9,1]*r[B][0][1,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[A,0],p[I,1],p[I,1])]*r[A][1][9,1]*r[B][0][1,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[A,0])]*r[A][1][9,1]*r[B][0][1,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[A,0])]*r[A][1][9,1]*r[B][0][1,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,0],p[B,0],p[I,0])]*r[A][1][9,1]*r[B][0][1,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,0],p[B,0],p[I,1])]*r[A][1][9,1]*r[B][0][1,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][1,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][1,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,0],p[A,0],p[C,0],p[C,0])]*r[A][1][9,1]*r[B][0][1,9]*r[C][9][11,11]
    hv += -1*g[dei(p[B,0],p[A,0],p[C,0],p[C,0])]*r[A][1][9,1]*r[B][0][1,9]*r[C][24][11,11]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[C,1],p[C,1])]*r[A][1][9,1]*r[B][0][1,9]*r[C][39][11,11]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[C,0],p[A,0])]*r[A][1][9,1]*r[B][0][1,9]*r[C][9][11,11]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,1],p[A,0])]*r[A][1][9,1]*r[B][0][1,9]*r[C][39][11,11]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[B,0],p[C,0])]*r[A][1][9,1]*r[B][0][1,9]*r[C][9][11,11]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[B,0],p[C,1])]*r[A][1][9,1]*r[B][0][1,9]*r[C][39][11,11]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][1,9]*r[C][9][11,11]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][1,9]*r[C][39][11,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[B,0],p[A,1]]*r[A][5][10,1]*r[B][0][0,9]
    hv += -1*g[dei(p[B,0],p[A,0],p[A,1],p[A,0])]*r[A][161][10,1]*r[B][0][0,9]
    hv += -1*g[dei(p[B,0],p[A,1],p[A,1],p[A,1])]*r[A][181][10,1]*r[B][0][0,9]
    hv += -1*g[dei(p[B,0],p[A,1],p[B,0],p[B,0])]*r[A][5][10,1]*r[B][66][0,9]
    hv += -1*g[dei(p[B,1],p[A,1],p[B,1],p[B,0])]*r[A][5][10,1]*r[B][146][0,9]
    hv += sum(-1/2*g[dei(p[B,0],p[A,1],p[I,0],p[I,0])]*r[A][5][10,1]*r[B][0][0,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[A,1],p[I,0],p[I,0])]*r[A][5][10,1]*r[B][0][0,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[A,1],p[I,1],p[I,1])]*r[A][5][10,1]*r[B][0][0,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[A,1],p[I,1],p[I,1])]*r[A][5][10,1]*r[B][0][0,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,1],p[B,0],p[I,0])]*r[A][5][10,1]*r[B][0][0,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,1],p[B,0],p[I,1])]*r[A][5][10,1]*r[B][0][0,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,0],p[A,1],p[C,0],p[C,0])]*r[A][5][10,1]*r[B][0][0,9]*r[C][9][11,11]
    hv += -1*g[dei(p[B,0],p[A,1],p[C,0],p[C,0])]*r[A][5][10,1]*r[B][0][0,9]*r[C][24][11,11]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[C,1],p[C,1])]*r[A][5][10,1]*r[B][0][0,9]*r[C][39][11,11]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[C,0],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[C][9][11,11]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,1],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[C][39][11,11]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[B,0],p[C,0])]*r[A][5][10,1]*r[B][0][0,9]*r[C][9][11,11]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[B,0],p[C,1])]*r[A][5][10,1]*r[B][0][0,9]*r[C][39][11,11]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[C][9][11,11]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[C][39][11,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B1C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,1),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[B,0],p[A,1]]*r[A][5][10,1]*r[B][0][1,9]
    hv += -1*g[dei(p[B,0],p[A,0],p[A,1],p[A,0])]*r[A][161][10,1]*r[B][0][1,9]
    hv += -1*g[dei(p[B,0],p[A,1],p[A,1],p[A,1])]*r[A][181][10,1]*r[B][0][1,9]
    hv += -1*g[dei(p[B,0],p[A,1],p[B,0],p[B,0])]*r[A][5][10,1]*r[B][66][1,9]
    hv += -1*g[dei(p[B,1],p[A,1],p[B,1],p[B,0])]*r[A][5][10,1]*r[B][146][1,9]
    hv += sum(-1/2*g[dei(p[B,0],p[A,1],p[I,0],p[I,0])]*r[A][5][10,1]*r[B][0][1,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[A,1],p[I,0],p[I,0])]*r[A][5][10,1]*r[B][0][1,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[A,1],p[I,1],p[I,1])]*r[A][5][10,1]*r[B][0][1,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[A,1],p[I,1],p[I,1])]*r[A][5][10,1]*r[B][0][1,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[A,1])]*r[A][5][10,1]*r[B][0][1,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[A,1])]*r[A][5][10,1]*r[B][0][1,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,1],p[B,0],p[I,0])]*r[A][5][10,1]*r[B][0][1,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,1],p[B,0],p[I,1])]*r[A][5][10,1]*r[B][0][1,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][1,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][1,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,0],p[A,1],p[C,0],p[C,0])]*r[A][5][10,1]*r[B][0][1,9]*r[C][9][11,11]
    hv += -1*g[dei(p[B,0],p[A,1],p[C,0],p[C,0])]*r[A][5][10,1]*r[B][0][1,9]*r[C][24][11,11]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[C,1],p[C,1])]*r[A][5][10,1]*r[B][0][1,9]*r[C][39][11,11]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[C,0],p[A,1])]*r[A][5][10,1]*r[B][0][1,9]*r[C][9][11,11]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,1],p[A,1])]*r[A][5][10,1]*r[B][0][1,9]*r[C][39][11,11]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[B,0],p[C,0])]*r[A][5][10,1]*r[B][0][1,9]*r[C][9][11,11]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[B,0],p[C,1])]*r[A][5][10,1]*r[B][0][1,9]*r[C][39][11,11]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][1,9]*r[C][9][11,11]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][1,9]*r[C][39][11,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B2C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,2),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[B,1],p[A,0]]*r[A][1][9,1]*r[B][4][2,9]
    hv += -1*g[dei(p[B,1],p[A,0],p[A,0],p[A,0])]*r[A][97][9,1]*r[B][4][2,9]
    hv += -1*g[dei(p[B,1],p[A,1],p[A,0],p[A,1])]*r[A][117][9,1]*r[B][4][2,9]
    hv += -1*g[dei(p[B,0],p[A,0],p[B,1],p[B,0])]*r[A][1][9,1]*r[B][82][2,9]
    hv += -1*g[dei(p[B,1],p[A,0],p[B,0],p[B,0])]*r[A][1][9,1]*r[B][130][2,9]
    hv += sum(-1/2*g[dei(p[B,1],p[A,0],p[I,0],p[I,0])]*r[A][1][9,1]*r[B][4][2,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,1],p[A,0],p[I,0],p[I,0])]*r[A][1][9,1]*r[B][4][2,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[A,0],p[I,1],p[I,1])]*r[A][1][9,1]*r[B][4][2,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,1],p[A,0],p[I,1],p[I,1])]*r[A][1][9,1]*r[B][4][2,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[A,0])]*r[A][1][9,1]*r[B][4][2,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[A,0])]*r[A][1][9,1]*r[B][4][2,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,0],p[B,1],p[I,0])]*r[A][1][9,1]*r[B][4][2,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,0],p[B,1],p[I,1])]*r[A][1][9,1]*r[B][4][2,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][4][2,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][4][2,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,1],p[A,0],p[C,0],p[C,0])]*r[A][1][9,1]*r[B][4][2,9]*r[C][9][11,11]
    hv += -1*g[dei(p[B,1],p[A,0],p[C,0],p[C,0])]*r[A][1][9,1]*r[B][4][2,9]*r[C][24][11,11]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[C,1],p[C,1])]*r[A][1][9,1]*r[B][4][2,9]*r[C][39][11,11]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,0],p[A,0])]*r[A][1][9,1]*r[B][4][2,9]*r[C][9][11,11]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[C,1],p[A,0])]*r[A][1][9,1]*r[B][4][2,9]*r[C][39][11,11]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[B,1],p[C,0])]*r[A][1][9,1]*r[B][4][2,9]*r[C][9][11,11]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[B,1],p[C,1])]*r[A][1][9,1]*r[B][4][2,9]*r[C][39][11,11]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][4][2,9]*r[C][9][11,11]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][4][2,9]*r[C][39][11,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B3C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,3),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[B,1],p[A,0]]*r[A][1][9,1]*r[B][4][3,9]
    hv += -1*g[dei(p[B,1],p[A,0],p[A,0],p[A,0])]*r[A][97][9,1]*r[B][4][3,9]
    hv += -1*g[dei(p[B,1],p[A,1],p[A,0],p[A,1])]*r[A][117][9,1]*r[B][4][3,9]
    hv += -1*g[dei(p[B,0],p[A,0],p[B,1],p[B,0])]*r[A][1][9,1]*r[B][82][3,9]
    hv += -1*g[dei(p[B,1],p[A,0],p[B,0],p[B,0])]*r[A][1][9,1]*r[B][130][3,9]
    hv += sum(-1/2*g[dei(p[B,1],p[A,0],p[I,0],p[I,0])]*r[A][1][9,1]*r[B][4][3,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,1],p[A,0],p[I,0],p[I,0])]*r[A][1][9,1]*r[B][4][3,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[A,0],p[I,1],p[I,1])]*r[A][1][9,1]*r[B][4][3,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,1],p[A,0],p[I,1],p[I,1])]*r[A][1][9,1]*r[B][4][3,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[A,0])]*r[A][1][9,1]*r[B][4][3,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[A,0])]*r[A][1][9,1]*r[B][4][3,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,0],p[B,1],p[I,0])]*r[A][1][9,1]*r[B][4][3,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,0],p[B,1],p[I,1])]*r[A][1][9,1]*r[B][4][3,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][4][3,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][4][3,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,1],p[A,0],p[C,0],p[C,0])]*r[A][1][9,1]*r[B][4][3,9]*r[C][9][11,11]
    hv += -1*g[dei(p[B,1],p[A,0],p[C,0],p[C,0])]*r[A][1][9,1]*r[B][4][3,9]*r[C][24][11,11]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[C,1],p[C,1])]*r[A][1][9,1]*r[B][4][3,9]*r[C][39][11,11]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,0],p[A,0])]*r[A][1][9,1]*r[B][4][3,9]*r[C][9][11,11]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[C,1],p[A,0])]*r[A][1][9,1]*r[B][4][3,9]*r[C][39][11,11]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[B,1],p[C,0])]*r[A][1][9,1]*r[B][4][3,9]*r[C][9][11,11]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[B,1],p[C,1])]*r[A][1][9,1]*r[B][4][3,9]*r[C][39][11,11]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][4][3,9]*r[C][9][11,11]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][4][3,9]*r[C][39][11,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B5C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,5),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[B,1],p[A,0]]*r[A][3][7,1]*r[B][6][5,9]
    hv += g[dei(p[A,0],p[A,0],p[B,1],p[A,0])]*r[A][65][7,1]*r[B][6][5,9]
    hv += g[dei(p[A,0],p[A,1],p[B,1],p[A,1])]*r[A][85][7,1]*r[B][6][5,9]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[B,1],p[B,0])]*r[A][3][7,1]*r[B][114][5,9]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[B,0],p[B,0])]*r[A][3][7,1]*r[B][162][5,9]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][114][5,9]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][162][5,9]
    hv += sum(-1/2*g[dei(p[B,1],p[A,0],p[I,0],p[I,0])]*r[A][3][7,1]*r[B][6][5,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[A,0],p[I,1],p[I,1])]*r[A][3][7,1]*r[B][6][5,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[A,0])]*r[A][3][7,1]*r[B][6][5,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[A,0])]*r[A][3][7,1]*r[B][6][5,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,0],p[B,1],p[I,0])]*r[A][3][7,1]*r[B][6][5,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,0],p[B,1],p[I,1])]*r[A][3][7,1]*r[B][6][5,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][6][5,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][6][5,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][6][5,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][6][5,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,1],p[A,0],p[C,0],p[C,0])]*r[A][3][7,1]*r[B][6][5,9]*r[C][24][11,11]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,0],p[A,0])]*r[A][3][7,1]*r[B][6][5,9]*r[C][24][11,11]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[B,1],p[C,0])]*r[A][3][7,1]*r[B][6][5,9]*r[C][24][11,11]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][6][5,9]*r[C][24][11,11]
    hv += -1*g[dei(p[C,0],p[C,0],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][6][5,9]*r[C][9][11,11]
    hv += -1*g[dei(p[C,1],p[C,1],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][6][5,9]*r[C][39][11,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B2C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,2),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[B,1],p[A,1]]*r[A][5][10,1]*r[B][4][2,9]
    hv += -1*g[dei(p[B,1],p[A,0],p[A,1],p[A,0])]*r[A][161][10,1]*r[B][4][2,9]
    hv += -1*g[dei(p[B,1],p[A,1],p[A,1],p[A,1])]*r[A][181][10,1]*r[B][4][2,9]
    hv += -1*g[dei(p[B,0],p[A,1],p[B,1],p[B,0])]*r[A][5][10,1]*r[B][82][2,9]
    hv += -1*g[dei(p[B,1],p[A,1],p[B,0],p[B,0])]*r[A][5][10,1]*r[B][130][2,9]
    hv += sum(-1/2*g[dei(p[B,1],p[A,1],p[I,0],p[I,0])]*r[A][5][10,1]*r[B][4][2,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,1],p[A,1],p[I,0],p[I,0])]*r[A][5][10,1]*r[B][4][2,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[A,1],p[I,1],p[I,1])]*r[A][5][10,1]*r[B][4][2,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,1],p[A,1],p[I,1],p[I,1])]*r[A][5][10,1]*r[B][4][2,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[A,1])]*r[A][5][10,1]*r[B][4][2,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[A,1])]*r[A][5][10,1]*r[B][4][2,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,1],p[B,1],p[I,0])]*r[A][5][10,1]*r[B][4][2,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,1],p[B,1],p[I,1])]*r[A][5][10,1]*r[B][4][2,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][4][2,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][4][2,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,1],p[A,1],p[C,0],p[C,0])]*r[A][5][10,1]*r[B][4][2,9]*r[C][9][11,11]
    hv += -1*g[dei(p[B,1],p[A,1],p[C,0],p[C,0])]*r[A][5][10,1]*r[B][4][2,9]*r[C][24][11,11]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[C,1],p[C,1])]*r[A][5][10,1]*r[B][4][2,9]*r[C][39][11,11]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,0],p[A,1])]*r[A][5][10,1]*r[B][4][2,9]*r[C][9][11,11]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[C,1],p[A,1])]*r[A][5][10,1]*r[B][4][2,9]*r[C][39][11,11]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[B,1],p[C,0])]*r[A][5][10,1]*r[B][4][2,9]*r[C][9][11,11]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[B,1],p[C,1])]*r[A][5][10,1]*r[B][4][2,9]*r[C][39][11,11]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][4][2,9]*r[C][9][11,11]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][4][2,9]*r[C][39][11,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B3C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,3),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[B,1],p[A,1]]*r[A][5][10,1]*r[B][4][3,9]
    hv += -1*g[dei(p[B,1],p[A,0],p[A,1],p[A,0])]*r[A][161][10,1]*r[B][4][3,9]
    hv += -1*g[dei(p[B,1],p[A,1],p[A,1],p[A,1])]*r[A][181][10,1]*r[B][4][3,9]
    hv += -1*g[dei(p[B,0],p[A,1],p[B,1],p[B,0])]*r[A][5][10,1]*r[B][82][3,9]
    hv += -1*g[dei(p[B,1],p[A,1],p[B,0],p[B,0])]*r[A][5][10,1]*r[B][130][3,9]
    hv += sum(-1/2*g[dei(p[B,1],p[A,1],p[I,0],p[I,0])]*r[A][5][10,1]*r[B][4][3,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,1],p[A,1],p[I,0],p[I,0])]*r[A][5][10,1]*r[B][4][3,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[A,1],p[I,1],p[I,1])]*r[A][5][10,1]*r[B][4][3,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,1],p[A,1],p[I,1],p[I,1])]*r[A][5][10,1]*r[B][4][3,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[A,1])]*r[A][5][10,1]*r[B][4][3,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[A,1])]*r[A][5][10,1]*r[B][4][3,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,1],p[B,1],p[I,0])]*r[A][5][10,1]*r[B][4][3,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,1],p[B,1],p[I,1])]*r[A][5][10,1]*r[B][4][3,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][4][3,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][4][3,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,1],p[A,1],p[C,0],p[C,0])]*r[A][5][10,1]*r[B][4][3,9]*r[C][9][11,11]
    hv += -1*g[dei(p[B,1],p[A,1],p[C,0],p[C,0])]*r[A][5][10,1]*r[B][4][3,9]*r[C][24][11,11]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[C,1],p[C,1])]*r[A][5][10,1]*r[B][4][3,9]*r[C][39][11,11]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,0],p[A,1])]*r[A][5][10,1]*r[B][4][3,9]*r[C][9][11,11]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[C,1],p[A,1])]*r[A][5][10,1]*r[B][4][3,9]*r[C][39][11,11]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[B,1],p[C,0])]*r[A][5][10,1]*r[B][4][3,9]*r[C][9][11,11]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[B,1],p[C,1])]*r[A][5][10,1]*r[B][4][3,9]*r[C][39][11,11]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][4][3,9]*r[C][9][11,11]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][4][3,9]*r[C][39][11,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B5C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,5),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[B,1],p[A,1]]*r[A][7][8,1]*r[B][6][5,9]
    hv += g[dei(p[A,1],p[A,0],p[B,1],p[A,0])]*r[A][129][8,1]*r[B][6][5,9]
    hv += g[dei(p[A,1],p[A,1],p[B,1],p[A,1])]*r[A][149][8,1]*r[B][6][5,9]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[B,1],p[B,0])]*r[A][7][8,1]*r[B][114][5,9]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[B,0],p[B,0])]*r[A][7][8,1]*r[B][162][5,9]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][114][5,9]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][162][5,9]
    hv += sum(-1/2*g[dei(p[B,1],p[A,1],p[I,0],p[I,0])]*r[A][7][8,1]*r[B][6][5,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[A,1],p[I,1],p[I,1])]*r[A][7][8,1]*r[B][6][5,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[A,1])]*r[A][7][8,1]*r[B][6][5,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[A,1])]*r[A][7][8,1]*r[B][6][5,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,1],p[B,1],p[I,0])]*r[A][7][8,1]*r[B][6][5,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,1],p[B,1],p[I,1])]*r[A][7][8,1]*r[B][6][5,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][6][5,9]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][6][5,9]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][6][5,9]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][6][5,9]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,1],p[A,1],p[C,0],p[C,0])]*r[A][7][8,1]*r[B][6][5,9]*r[C][24][11,11]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,0],p[A,1])]*r[A][7][8,1]*r[B][6][5,9]*r[C][24][11,11]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[B,1],p[C,0])]*r[A][7][8,1]*r[B][6][5,9]*r[C][24][11,11]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][6][5,9]*r[C][24][11,11]
    hv += -1*g[dei(p[C,0],p[C,0],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][6][5,9]*r[C][9][11,11]
    hv += -1*g[dei(p[C,1],p[C,1],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][6][5,9]*r[C][39][11,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B10C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,10),(C,11)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[B,0])]*r[A][24][0,1]*r[B][48][10,9]
    hv += g[dei(p[A,0],p[A,0],p[B,1],p[B,0])]*r[A][9][0,1]*r[B][48][10,9]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[B,0])]*r[A][54][0,1]*r[B][48][10,9]
    hv += g[dei(p[A,1],p[A,1],p[B,1],p[B,0])]*r[A][39][0,1]*r[B][48][10,9]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[A,0])]*r[A][24][0,1]*r[B][48][10,9]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[A,1])]*r[A][54][0,1]*r[B][48][10,9]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[B,0])]*r[A][24][0,1]*r[B][48][10,9]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[B,0])]*r[A][54][0,1]*r[B][48][10,9]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][48][10,9]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][48][10,9]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B10C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,10),(C,11)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[B,0])]*r[A][30][2,1]*r[B][48][10,9]
    hv += g[dei(p[A,0],p[A,1],p[B,1],p[B,0])]*r[A][15][2,1]*r[B][48][10,9]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[B,0])]*r[A][48][2,1]*r[B][48][10,9]
    hv += g[dei(p[A,1],p[A,0],p[B,1],p[B,0])]*r[A][33][2,1]*r[B][48][10,9]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[A,1])]*r[A][30][2,1]*r[B][48][10,9]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[A,0])]*r[A][48][2,1]*r[B][48][10,9]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[B,0])]*r[A][30][2,1]*r[B][48][10,9]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[B,0])]*r[A][48][2,1]*r[B][48][10,9]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][48][10,9]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][48][10,9]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B10C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,10),(C,11)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[B,0])]*r[A][30][3,1]*r[B][48][10,9]
    hv += g[dei(p[A,0],p[A,1],p[B,1],p[B,0])]*r[A][15][3,1]*r[B][48][10,9]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[B,0])]*r[A][48][3,1]*r[B][48][10,9]
    hv += g[dei(p[A,1],p[A,0],p[B,1],p[B,0])]*r[A][33][3,1]*r[B][48][10,9]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[A,1])]*r[A][30][3,1]*r[B][48][10,9]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[A,0])]*r[A][48][3,1]*r[B][48][10,9]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[B,0])]*r[A][30][3,1]*r[B][48][10,9]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[B,0])]*r[A][48][3,1]*r[B][48][10,9]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][48][10,9]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][48][10,9]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5B7C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,5),(B,7),(C,11)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[B,0],p[A,1],p[A,0],p[B,0])]*r[A][27][5,1]*r[B][12][7,9]
    hv += -1*g[dei(p[B,0],p[A,0],p[A,1],p[B,0])]*r[A][45][5,1]*r[B][12][7,9]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5B8C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,5),(B,8),(C,11)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[B,1],p[A,1],p[A,0],p[B,0])]*r[A][27][5,1]*r[B][36][8,9]
    hv += -1*g[dei(p[B,1],p[A,0],p[A,1],p[B,0])]*r[A][45][5,1]*r[B][36][8,9]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6B13C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,6),(B,13),(C,11)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[B,0],p[A,0],p[B,1],p[A,0])]*r[A][22][6,1]*r[B][17][13,9]
    hv += g[dei(p[B,0],p[A,1],p[B,1],p[A,1])]*r[A][52][6,1]*r[B][17][13,9]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6B14C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,6),(B,14),(C,11)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[B,1],p[A,0],p[B,1],p[A,0])]*r[A][22][6,1]*r[B][41][14,9]
    hv += g[dei(p[B,1],p[A,1],p[B,1],p[A,1])]*r[A][52][6,1]*r[B][41][14,9]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B9C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,9),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[A,0],p[C,0]]*r[A][0][12,1]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[A,1],p[C,0])]*r[A][76][12,1]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[A,0],p[C,0])]*r[A][124][12,1]*r[C][1][2,11]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[A,1],p[A,1])]*r[A][76][12,1]*r[C][1][2,11]
    hv += -1*g[dei(p[A,0],p[C,0],p[A,1],p[A,1])]*r[A][86][12,1]*r[C][1][2,11]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[A,0],p[A,1])]*r[A][124][12,1]*r[C][1][2,11]
    hv += -1*g[dei(p[A,1],p[C,0],p[A,1],p[A,0])]*r[A][146][12,1]*r[C][1][2,11]
    hv += -1*g[dei(p[A,0],p[C,0],p[C,0],p[C,0])]*r[A][0][12,1]*r[C][97][2,11]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[C,1])]*r[A][0][12,1]*r[C][137][2,11]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[C,0])]*r[A][0][12,1]*r[C][125][2,11]
    hv += -1*g[dei(p[A,0],p[C,1],p[C,1],p[C,0])]*r[A][0][12,1]*r[C][165][2,11]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[C,1])]*r[A][0][12,1]*r[C][137][2,11]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[C,0])]*r[A][0][12,1]*r[C][125][2,11]
    hv += sum(-1/2*g[dei(p[A,0],p[C,0],p[I,0],p[I,0])]*r[A][0][12,1]*r[C][1][2,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[A,0],p[C,0],p[I,0],p[I,0])]*r[A][0][12,1]*r[C][1][2,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[C,0],p[I,1],p[I,1])]*r[A][0][12,1]*r[C][1][2,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[A,0],p[C,0],p[I,1],p[I,1])]*r[A][0][12,1]*r[C][1][2,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[I,0],p[I,0],p[C,0])]*r[A][0][12,1]*r[C][1][2,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[I,1],p[I,1],p[C,0])]*r[A][0][12,1]*r[C][1][2,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,0],p[A,0],p[I,0])]*r[A][0][12,1]*r[C][1][2,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,0],p[A,0],p[I,1])]*r[A][0][12,1]*r[C][1][2,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,0],p[C,0])]*r[A][0][12,1]*r[C][1][2,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,0],p[C,0])]*r[A][0][12,1]*r[C][1][2,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1*g[dei(p[A,0],p[C,0],p[B,0],p[B,0])]*r[A][0][12,1]*r[B][24][9,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B9C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,9),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[A,0],p[C,0]]*r[A][0][12,1]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[A,1],p[C,0])]*r[A][76][12,1]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[A,0],p[C,0])]*r[A][124][12,1]*r[C][1][3,11]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[A,1],p[A,1])]*r[A][76][12,1]*r[C][1][3,11]
    hv += -1*g[dei(p[A,0],p[C,0],p[A,1],p[A,1])]*r[A][86][12,1]*r[C][1][3,11]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[A,0],p[A,1])]*r[A][124][12,1]*r[C][1][3,11]
    hv += -1*g[dei(p[A,1],p[C,0],p[A,1],p[A,0])]*r[A][146][12,1]*r[C][1][3,11]
    hv += -1*g[dei(p[A,0],p[C,0],p[C,0],p[C,0])]*r[A][0][12,1]*r[C][97][3,11]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[C,1])]*r[A][0][12,1]*r[C][137][3,11]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[C,0])]*r[A][0][12,1]*r[C][125][3,11]
    hv += -1*g[dei(p[A,0],p[C,1],p[C,1],p[C,0])]*r[A][0][12,1]*r[C][165][3,11]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[C,1])]*r[A][0][12,1]*r[C][137][3,11]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[C,0])]*r[A][0][12,1]*r[C][125][3,11]
    hv += sum(-1/2*g[dei(p[A,0],p[C,0],p[I,0],p[I,0])]*r[A][0][12,1]*r[C][1][3,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[A,0],p[C,0],p[I,0],p[I,0])]*r[A][0][12,1]*r[C][1][3,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[C,0],p[I,1],p[I,1])]*r[A][0][12,1]*r[C][1][3,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[A,0],p[C,0],p[I,1],p[I,1])]*r[A][0][12,1]*r[C][1][3,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[I,0],p[I,0],p[C,0])]*r[A][0][12,1]*r[C][1][3,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[I,1],p[I,1],p[C,0])]*r[A][0][12,1]*r[C][1][3,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,0],p[A,0],p[I,0])]*r[A][0][12,1]*r[C][1][3,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,0],p[A,0],p[I,1])]*r[A][0][12,1]*r[C][1][3,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,0],p[C,0])]*r[A][0][12,1]*r[C][1][3,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,0],p[C,0])]*r[A][0][12,1]*r[C][1][3,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1*g[dei(p[A,0],p[C,0],p[B,0],p[B,0])]*r[A][0][12,1]*r[B][24][9,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B9C4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,9),(C,4)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[A,0],p[C,0]]*r[A][2][14,1]*r[C][3][4,11]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[A,1],p[C,0])]*r[A][118][14,1]*r[C][3][4,11]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[A,0],p[C,0])]*r[A][166][14,1]*r[C][3][4,11]
    hv += g[dei(p[A,1],p[A,1],p[A,0],p[C,0])]*r[A][132][14,1]*r[C][3][4,11]
    hv += g[dei(p[A,1],p[A,0],p[A,1],p[C,0])]*r[A][144][14,1]*r[C][3][4,11]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[A,1],p[A,1])]*r[A][118][14,1]*r[C][3][4,11]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[A,0],p[A,1])]*r[A][166][14,1]*r[C][3][4,11]
    hv += g[dei(p[C,0],p[C,0],p[A,0],p[C,0])]*r[A][2][14,1]*r[C][65][4,11]
    hv += g[dei(p[C,1],p[C,1],p[A,0],p[C,0])]*r[A][2][14,1]*r[C][133][4,11]
    hv += sum(-1/2*g[dei(p[A,0],p[C,0],p[I,0],p[I,0])]*r[A][2][14,1]*r[C][3][4,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[C,0],p[I,1],p[I,1])]*r[A][2][14,1]*r[C][3][4,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[I,0],p[I,0],p[C,0])]*r[A][2][14,1]*r[C][3][4,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[I,1],p[I,1],p[C,0])]*r[A][2][14,1]*r[C][3][4,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,0],p[A,0],p[I,0])]*r[A][2][14,1]*r[C][3][4,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,0],p[A,0],p[I,1])]*r[A][2][14,1]*r[C][3][4,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,0],p[C,0])]*r[A][2][14,1]*r[C][3][4,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[A,0],p[C,0])]*r[A][2][14,1]*r[C][3][4,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,0],p[C,0])]*r[A][2][14,1]*r[C][3][4,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[A,0],p[C,0])]*r[A][2][14,1]*r[C][3][4,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[B,0],p[B,0],p[C,0])]*r[A][2][14,1]*r[B][24][9,9]*r[C][3][4,11]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[B,0],p[B,0])]*r[A][2][14,1]*r[B][24][9,9]*r[C][3][4,11]
    hv += -1/2*g[dei(p[B,0],p[B,0],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][24][9,9]*r[C][3][4,11]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][24][9,9]*r[C][3][4,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,9)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[A,0],p[C,1]]*r[A][0][12,1]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[A,1],p[C,1])]*r[A][76][12,1]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[A,0],p[C,1])]*r[A][124][12,1]*r[C][5][0,11]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[A,1],p[A,1])]*r[A][76][12,1]*r[C][5][0,11]
    hv += -1*g[dei(p[A,0],p[C,1],p[A,1],p[A,1])]*r[A][86][12,1]*r[C][5][0,11]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[A,0],p[A,1])]*r[A][124][12,1]*r[C][5][0,11]
    hv += -1*g[dei(p[A,1],p[C,1],p[A,1],p[A,0])]*r[A][146][12,1]*r[C][5][0,11]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[C,1])]*r[A][0][12,1]*r[C][73][0,11]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[C,0])]*r[A][0][12,1]*r[C][61][0,11]
    hv += -1*g[dei(p[A,0],p[C,1],p[C,0],p[C,0])]*r[A][0][12,1]*r[C][101][0,11]
    hv += -1*g[dei(p[A,0],p[C,0],p[C,1],p[C,0])]*r[A][0][12,1]*r[C][161][0,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[C,1])]*r[A][0][12,1]*r[C][73][0,11]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[C,0])]*r[A][0][12,1]*r[C][61][0,11]
    hv += sum(-1/2*g[dei(p[A,0],p[C,1],p[I,0],p[I,0])]*r[A][0][12,1]*r[C][5][0,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[A,0],p[C,1],p[I,0],p[I,0])]*r[A][0][12,1]*r[C][5][0,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[C,1],p[I,1],p[I,1])]*r[A][0][12,1]*r[C][5][0,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[A,0],p[C,1],p[I,1],p[I,1])]*r[A][0][12,1]*r[C][5][0,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[I,0],p[I,0],p[C,1])]*r[A][0][12,1]*r[C][5][0,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[I,1],p[I,1],p[C,1])]*r[A][0][12,1]*r[C][5][0,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,1],p[A,0],p[I,0])]*r[A][0][12,1]*r[C][5][0,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,1],p[A,0],p[I,1])]*r[A][0][12,1]*r[C][5][0,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,0],p[C,1])]*r[A][0][12,1]*r[C][5][0,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,0],p[C,1])]*r[A][0][12,1]*r[C][5][0,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1*g[dei(p[A,0],p[C,1],p[B,0],p[B,0])]*r[A][0][12,1]*r[B][24][9,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B9C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,9),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[A,0],p[C,1]]*r[A][0][12,1]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[A,1],p[C,1])]*r[A][76][12,1]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[A,0],p[C,1])]*r[A][124][12,1]*r[C][5][1,11]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[A,1],p[A,1])]*r[A][76][12,1]*r[C][5][1,11]
    hv += -1*g[dei(p[A,0],p[C,1],p[A,1],p[A,1])]*r[A][86][12,1]*r[C][5][1,11]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[A,0],p[A,1])]*r[A][124][12,1]*r[C][5][1,11]
    hv += -1*g[dei(p[A,1],p[C,1],p[A,1],p[A,0])]*r[A][146][12,1]*r[C][5][1,11]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[C,1])]*r[A][0][12,1]*r[C][73][1,11]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[C,0])]*r[A][0][12,1]*r[C][61][1,11]
    hv += -1*g[dei(p[A,0],p[C,1],p[C,0],p[C,0])]*r[A][0][12,1]*r[C][101][1,11]
    hv += -1*g[dei(p[A,0],p[C,0],p[C,1],p[C,0])]*r[A][0][12,1]*r[C][161][1,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[C,1])]*r[A][0][12,1]*r[C][73][1,11]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[C,0])]*r[A][0][12,1]*r[C][61][1,11]
    hv += sum(-1/2*g[dei(p[A,0],p[C,1],p[I,0],p[I,0])]*r[A][0][12,1]*r[C][5][1,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[A,0],p[C,1],p[I,0],p[I,0])]*r[A][0][12,1]*r[C][5][1,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[C,1],p[I,1],p[I,1])]*r[A][0][12,1]*r[C][5][1,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[A,0],p[C,1],p[I,1],p[I,1])]*r[A][0][12,1]*r[C][5][1,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[I,0],p[I,0],p[C,1])]*r[A][0][12,1]*r[C][5][1,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[I,1],p[I,1],p[C,1])]*r[A][0][12,1]*r[C][5][1,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,1],p[A,0],p[I,0])]*r[A][0][12,1]*r[C][5][1,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,1],p[A,0],p[I,1])]*r[A][0][12,1]*r[C][5][1,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,0],p[C,1])]*r[A][0][12,1]*r[C][5][1,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,0],p[C,1])]*r[A][0][12,1]*r[C][5][1,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1*g[dei(p[A,0],p[C,1],p[B,0],p[B,0])]*r[A][0][12,1]*r[B][24][9,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B9C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,9),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[A,1],p[C,0]]*r[A][4][11,1]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[A,1],p[C,0])]*r[A][72][11,1]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[A,0],p[C,0])]*r[A][120][11,1]*r[C][1][2,11]
    hv += -1*g[dei(p[A,0],p[C,0],p[A,0],p[A,1])]*r[A][70][11,1]*r[C][1][2,11]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[A,1],p[A,0])]*r[A][72][11,1]*r[C][1][2,11]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[A,0],p[A,0])]*r[A][120][11,1]*r[C][1][2,11]
    hv += -1*g[dei(p[A,1],p[C,0],p[A,0],p[A,0])]*r[A][130][11,1]*r[C][1][2,11]
    hv += -1*g[dei(p[A,1],p[C,0],p[C,0],p[C,0])]*r[A][4][11,1]*r[C][97][2,11]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[C,1])]*r[A][4][11,1]*r[C][137][2,11]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[C,0])]*r[A][4][11,1]*r[C][125][2,11]
    hv += -1*g[dei(p[A,1],p[C,1],p[C,1],p[C,0])]*r[A][4][11,1]*r[C][165][2,11]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[C,1])]*r[A][4][11,1]*r[C][137][2,11]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[C,0])]*r[A][4][11,1]*r[C][125][2,11]
    hv += sum(-1/2*g[dei(p[A,1],p[C,0],p[I,0],p[I,0])]*r[A][4][11,1]*r[C][1][2,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[A,1],p[C,0],p[I,0],p[I,0])]*r[A][4][11,1]*r[C][1][2,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[C,0],p[I,1],p[I,1])]*r[A][4][11,1]*r[C][1][2,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[A,1],p[C,0],p[I,1],p[I,1])]*r[A][4][11,1]*r[C][1][2,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[I,0],p[I,0],p[C,0])]*r[A][4][11,1]*r[C][1][2,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[I,1],p[I,1],p[C,0])]*r[A][4][11,1]*r[C][1][2,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,0],p[A,1],p[I,0])]*r[A][4][11,1]*r[C][1][2,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,0],p[A,1],p[I,1])]*r[A][4][11,1]*r[C][1][2,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,1],p[C,0])]*r[A][4][11,1]*r[C][1][2,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,1],p[C,0])]*r[A][4][11,1]*r[C][1][2,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1*g[dei(p[A,1],p[C,0],p[B,0],p[B,0])]*r[A][4][11,1]*r[B][24][9,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B9C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,9),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[A,1],p[C,0]]*r[A][4][11,1]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[A,1],p[C,0])]*r[A][72][11,1]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[A,0],p[C,0])]*r[A][120][11,1]*r[C][1][3,11]
    hv += -1*g[dei(p[A,0],p[C,0],p[A,0],p[A,1])]*r[A][70][11,1]*r[C][1][3,11]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[A,1],p[A,0])]*r[A][72][11,1]*r[C][1][3,11]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[A,0],p[A,0])]*r[A][120][11,1]*r[C][1][3,11]
    hv += -1*g[dei(p[A,1],p[C,0],p[A,0],p[A,0])]*r[A][130][11,1]*r[C][1][3,11]
    hv += -1*g[dei(p[A,1],p[C,0],p[C,0],p[C,0])]*r[A][4][11,1]*r[C][97][3,11]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[C,1])]*r[A][4][11,1]*r[C][137][3,11]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[C,0])]*r[A][4][11,1]*r[C][125][3,11]
    hv += -1*g[dei(p[A,1],p[C,1],p[C,1],p[C,0])]*r[A][4][11,1]*r[C][165][3,11]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[C,1])]*r[A][4][11,1]*r[C][137][3,11]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[C,0])]*r[A][4][11,1]*r[C][125][3,11]
    hv += sum(-1/2*g[dei(p[A,1],p[C,0],p[I,0],p[I,0])]*r[A][4][11,1]*r[C][1][3,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[A,1],p[C,0],p[I,0],p[I,0])]*r[A][4][11,1]*r[C][1][3,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[C,0],p[I,1],p[I,1])]*r[A][4][11,1]*r[C][1][3,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[A,1],p[C,0],p[I,1],p[I,1])]*r[A][4][11,1]*r[C][1][3,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[I,0],p[I,0],p[C,0])]*r[A][4][11,1]*r[C][1][3,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[I,1],p[I,1],p[C,0])]*r[A][4][11,1]*r[C][1][3,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,0],p[A,1],p[I,0])]*r[A][4][11,1]*r[C][1][3,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,0],p[A,1],p[I,1])]*r[A][4][11,1]*r[C][1][3,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,1],p[C,0])]*r[A][4][11,1]*r[C][1][3,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,1],p[C,0])]*r[A][4][11,1]*r[C][1][3,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1*g[dei(p[A,1],p[C,0],p[B,0],p[B,0])]*r[A][4][11,1]*r[B][24][9,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B9C4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,9),(C,4)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[A,1],p[C,0]]*r[A][6][13,1]*r[C][3][4,11]
    hv += g[dei(p[A,0],p[A,1],p[A,0],p[C,0])]*r[A][68][13,1]*r[C][3][4,11]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[A,1],p[C,0])]*r[A][114][13,1]*r[C][3][4,11]
    hv += g[dei(p[A,0],p[A,0],p[A,1],p[C,0])]*r[A][80][13,1]*r[C][3][4,11]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[A,0],p[C,0])]*r[A][162][13,1]*r[C][3][4,11]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[A,1],p[A,0])]*r[A][114][13,1]*r[C][3][4,11]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[A,0],p[A,0])]*r[A][162][13,1]*r[C][3][4,11]
    hv += g[dei(p[C,0],p[C,0],p[A,1],p[C,0])]*r[A][6][13,1]*r[C][65][4,11]
    hv += g[dei(p[C,1],p[C,1],p[A,1],p[C,0])]*r[A][6][13,1]*r[C][133][4,11]
    hv += sum(-1/2*g[dei(p[A,1],p[C,0],p[I,0],p[I,0])]*r[A][6][13,1]*r[C][3][4,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[C,0],p[I,1],p[I,1])]*r[A][6][13,1]*r[C][3][4,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[I,0],p[I,0],p[C,0])]*r[A][6][13,1]*r[C][3][4,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[I,1],p[I,1],p[C,0])]*r[A][6][13,1]*r[C][3][4,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,0],p[A,1],p[I,0])]*r[A][6][13,1]*r[C][3][4,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,0],p[A,1],p[I,1])]*r[A][6][13,1]*r[C][3][4,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,1],p[C,0])]*r[A][6][13,1]*r[C][3][4,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[A,1],p[C,0])]*r[A][6][13,1]*r[C][3][4,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,1],p[C,0])]*r[A][6][13,1]*r[C][3][4,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[A,1],p[C,0])]*r[A][6][13,1]*r[C][3][4,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,1],p[B,0],p[B,0],p[C,0])]*r[A][6][13,1]*r[B][24][9,9]*r[C][3][4,11]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[B,0],p[B,0])]*r[A][6][13,1]*r[B][24][9,9]*r[C][3][4,11]
    hv += -1/2*g[dei(p[B,0],p[B,0],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][24][9,9]*r[C][3][4,11]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][24][9,9]*r[C][3][4,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,9)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[A,1],p[C,1]]*r[A][4][11,1]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[A,1],p[C,1])]*r[A][72][11,1]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[A,0],p[C,1])]*r[A][120][11,1]*r[C][5][0,11]
    hv += -1*g[dei(p[A,0],p[C,1],p[A,0],p[A,1])]*r[A][70][11,1]*r[C][5][0,11]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[A,1],p[A,0])]*r[A][72][11,1]*r[C][5][0,11]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[A,0],p[A,0])]*r[A][120][11,1]*r[C][5][0,11]
    hv += -1*g[dei(p[A,1],p[C,1],p[A,0],p[A,0])]*r[A][130][11,1]*r[C][5][0,11]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[C,1])]*r[A][4][11,1]*r[C][73][0,11]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[C,0])]*r[A][4][11,1]*r[C][61][0,11]
    hv += -1*g[dei(p[A,1],p[C,1],p[C,0],p[C,0])]*r[A][4][11,1]*r[C][101][0,11]
    hv += -1*g[dei(p[A,1],p[C,0],p[C,1],p[C,0])]*r[A][4][11,1]*r[C][161][0,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[C,1])]*r[A][4][11,1]*r[C][73][0,11]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[C,0])]*r[A][4][11,1]*r[C][61][0,11]
    hv += sum(-1/2*g[dei(p[A,1],p[C,1],p[I,0],p[I,0])]*r[A][4][11,1]*r[C][5][0,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[A,1],p[C,1],p[I,0],p[I,0])]*r[A][4][11,1]*r[C][5][0,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[C,1],p[I,1],p[I,1])]*r[A][4][11,1]*r[C][5][0,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[A,1],p[C,1],p[I,1],p[I,1])]*r[A][4][11,1]*r[C][5][0,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[I,0],p[I,0],p[C,1])]*r[A][4][11,1]*r[C][5][0,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[I,1],p[I,1],p[C,1])]*r[A][4][11,1]*r[C][5][0,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,1],p[A,1],p[I,0])]*r[A][4][11,1]*r[C][5][0,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,1],p[A,1],p[I,1])]*r[A][4][11,1]*r[C][5][0,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,1],p[C,1])]*r[A][4][11,1]*r[C][5][0,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,1],p[C,1])]*r[A][4][11,1]*r[C][5][0,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1*g[dei(p[A,1],p[C,1],p[B,0],p[B,0])]*r[A][4][11,1]*r[B][24][9,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B9C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,9),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[A,1],p[C,1]]*r[A][4][11,1]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[A,1],p[C,1])]*r[A][72][11,1]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[A,0],p[C,1])]*r[A][120][11,1]*r[C][5][1,11]
    hv += -1*g[dei(p[A,0],p[C,1],p[A,0],p[A,1])]*r[A][70][11,1]*r[C][5][1,11]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[A,1],p[A,0])]*r[A][72][11,1]*r[C][5][1,11]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[A,0],p[A,0])]*r[A][120][11,1]*r[C][5][1,11]
    hv += -1*g[dei(p[A,1],p[C,1],p[A,0],p[A,0])]*r[A][130][11,1]*r[C][5][1,11]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[C,1])]*r[A][4][11,1]*r[C][73][1,11]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[C,0])]*r[A][4][11,1]*r[C][61][1,11]
    hv += -1*g[dei(p[A,1],p[C,1],p[C,0],p[C,0])]*r[A][4][11,1]*r[C][101][1,11]
    hv += -1*g[dei(p[A,1],p[C,0],p[C,1],p[C,0])]*r[A][4][11,1]*r[C][161][1,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[C,1])]*r[A][4][11,1]*r[C][73][1,11]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[C,0])]*r[A][4][11,1]*r[C][61][1,11]
    hv += sum(-1/2*g[dei(p[A,1],p[C,1],p[I,0],p[I,0])]*r[A][4][11,1]*r[C][5][1,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[A,1],p[C,1],p[I,0],p[I,0])]*r[A][4][11,1]*r[C][5][1,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[C,1],p[I,1],p[I,1])]*r[A][4][11,1]*r[C][5][1,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[A,1],p[C,1],p[I,1],p[I,1])]*r[A][4][11,1]*r[C][5][1,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[I,0],p[I,0],p[C,1])]*r[A][4][11,1]*r[C][5][1,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[I,1],p[I,1],p[C,1])]*r[A][4][11,1]*r[C][5][1,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,1],p[A,1],p[I,0])]*r[A][4][11,1]*r[C][5][1,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,1],p[A,1],p[I,1])]*r[A][4][11,1]*r[C][5][1,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,1],p[C,1])]*r[A][4][11,1]*r[C][5][1,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,1],p[C,1])]*r[A][4][11,1]*r[C][5][1,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1*g[dei(p[A,1],p[C,1],p[B,0],p[B,0])]*r[A][4][11,1]*r[B][24][9,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B9C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,9),(C,15)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += h[p[C,1],p[A,0]]*r[A][3][7,1]*r[C][6][15,11]
    hv += -1*g[dei(p[A,0],p[A,0],p[C,1],p[A,0])]*r[A][65][7,1]*r[C][6][15,11]
    hv += -1*g[dei(p[A,0],p[A,1],p[C,1],p[A,1])]*r[A][85][7,1]*r[C][6][15,11]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[C,1],p[C,0])]*r[A][3][7,1]*r[C][114][15,11]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[C,0],p[C,0])]*r[A][3][7,1]*r[C][162][15,11]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[C,1],p[A,0])]*r[A][3][7,1]*r[C][114][15,11]
    hv += -1*g[dei(p[C,0],p[C,0],p[C,1],p[A,0])]*r[A][3][7,1]*r[C][80][15,11]
    hv += -1/2*g[dei(p[C,1],p[C,0],p[C,0],p[A,0])]*r[A][3][7,1]*r[C][162][15,11]
    hv += -1*g[dei(p[C,1],p[C,1],p[C,1],p[A,0])]*r[A][3][7,1]*r[C][148][15,11]
    hv += sum(1/2*g[dei(p[C,1],p[A,0],p[I,0],p[I,0])]*r[A][3][7,1]*r[C][6][15,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[A,0],p[I,1],p[I,1])]*r[A][3][7,1]*r[C][6][15,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,0],p[I,0],p[A,0])]*r[A][3][7,1]*r[C][6][15,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,1],p[I,1],p[A,0])]*r[A][3][7,1]*r[C][6][15,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[C,1],p[I,0])]*r[A][3][7,1]*r[C][6][15,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[C,1],p[I,1])]*r[A][3][7,1]*r[C][6][15,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,1],p[A,0])]*r[A][3][7,1]*r[C][6][15,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[C,1],p[A,0])]*r[A][3][7,1]*r[C][6][15,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,1],p[A,0])]*r[A][3][7,1]*r[C][6][15,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[C,1],p[A,0])]*r[A][3][7,1]*r[C][6][15,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,0],p[A,0],p[C,1],p[B,0])]*r[A][3][7,1]*r[B][24][9,9]*r[C][6][15,11]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][24][9,9]*r[C][6][15,11]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[B,0],p[B,0])]*r[A][3][7,1]*r[B][24][9,9]*r[C][6][15,11]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][24][9,9]*r[C][6][15,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B9C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,9),(C,15)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += h[p[C,1],p[A,1]]*r[A][7][8,1]*r[C][6][15,11]
    hv += -1*g[dei(p[A,1],p[A,0],p[C,1],p[A,0])]*r[A][129][8,1]*r[C][6][15,11]
    hv += -1*g[dei(p[A,1],p[A,1],p[C,1],p[A,1])]*r[A][149][8,1]*r[C][6][15,11]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[C,1],p[C,0])]*r[A][7][8,1]*r[C][114][15,11]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[C,0],p[C,0])]*r[A][7][8,1]*r[C][162][15,11]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[C,1],p[A,1])]*r[A][7][8,1]*r[C][114][15,11]
    hv += -1*g[dei(p[C,0],p[C,0],p[C,1],p[A,1])]*r[A][7][8,1]*r[C][80][15,11]
    hv += -1/2*g[dei(p[C,1],p[C,0],p[C,0],p[A,1])]*r[A][7][8,1]*r[C][162][15,11]
    hv += -1*g[dei(p[C,1],p[C,1],p[C,1],p[A,1])]*r[A][7][8,1]*r[C][148][15,11]
    hv += sum(1/2*g[dei(p[C,1],p[A,1],p[I,0],p[I,0])]*r[A][7][8,1]*r[C][6][15,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[A,1],p[I,1],p[I,1])]*r[A][7][8,1]*r[C][6][15,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,0],p[I,0],p[A,1])]*r[A][7][8,1]*r[C][6][15,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,1],p[I,1],p[A,1])]*r[A][7][8,1]*r[C][6][15,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[C,1],p[I,0])]*r[A][7][8,1]*r[C][6][15,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[C,1],p[I,1])]*r[A][7][8,1]*r[C][6][15,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,1],p[A,1])]*r[A][7][8,1]*r[C][6][15,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[C,1],p[A,1])]*r[A][7][8,1]*r[C][6][15,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,1],p[A,1])]*r[A][7][8,1]*r[C][6][15,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[C,1],p[A,1])]*r[A][7][8,1]*r[C][6][15,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,0],p[A,1],p[C,1],p[B,0])]*r[A][7][8,1]*r[B][24][9,9]*r[C][6][15,11]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][24][9,9]*r[C][6][15,11]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[B,0],p[B,0])]*r[A][7][8,1]*r[B][24][9,9]*r[C][6][15,11]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][24][9,9]*r[C][6][15,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A15B9C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,15),(B,9),(C,8)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[A,0],p[C,0],p[A,0],p[C,0])]*r[A][11][15,1]*r[C][22][8,11]
    hv += g[dei(p[A,1],p[C,0],p[A,1],p[C,0])]*r[A][41][15,1]*r[C][22][8,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A15B9C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,15),(B,9),(C,7)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[A,0],p[C,1],p[A,0],p[C,0])]*r[A][11][15,1]*r[C][28][7,11]
    hv += g[dei(p[A,1],p[C,1],p[A,1],p[C,0])]*r[A][41][15,1]*r[C][28][7,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B9C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,9),(C,12)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[C,0])]*r[A][24][0,1]*r[C][48][12,11]
    hv += g[dei(p[A,0],p[A,0],p[C,1],p[C,0])]*r[A][9][0,1]*r[C][48][12,11]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[C,0])]*r[A][54][0,1]*r[C][48][12,11]
    hv += g[dei(p[A,1],p[A,1],p[C,1],p[C,0])]*r[A][39][0,1]*r[C][48][12,11]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[A,0])]*r[A][24][0,1]*r[C][48][12,11]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[A,1])]*r[A][54][0,1]*r[C][48][12,11]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[C,0])]*r[A][24][0,1]*r[C][48][12,11]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[C,0])]*r[A][54][0,1]*r[C][48][12,11]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][48][12,11]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][48][12,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B9C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,9),(C,12)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,1],p[C,0])]*r[A][30][2,1]*r[C][48][12,11]
    hv += g[dei(p[A,0],p[A,1],p[C,1],p[C,0])]*r[A][15][2,1]*r[C][48][12,11]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,1],p[C,0])]*r[A][48][2,1]*r[C][48][12,11]
    hv += g[dei(p[A,1],p[A,0],p[C,1],p[C,0])]*r[A][33][2,1]*r[C][48][12,11]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[A,1])]*r[A][30][2,1]*r[C][48][12,11]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[A,0])]*r[A][48][2,1]*r[C][48][12,11]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,0],p[C,0])]*r[A][30][2,1]*r[C][48][12,11]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,1],p[C,0])]*r[A][48][2,1]*r[C][48][12,11]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[C][48][12,11]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[C][48][12,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B9C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,9),(C,12)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,1],p[C,0])]*r[A][30][3,1]*r[C][48][12,11]
    hv += g[dei(p[A,0],p[A,1],p[C,1],p[C,0])]*r[A][15][3,1]*r[C][48][12,11]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,1],p[C,0])]*r[A][48][3,1]*r[C][48][12,11]
    hv += g[dei(p[A,1],p[A,0],p[C,1],p[C,0])]*r[A][33][3,1]*r[C][48][12,11]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[A,1])]*r[A][30][3,1]*r[C][48][12,11]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[A,0])]*r[A][48][3,1]*r[C][48][12,11]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,0],p[C,0])]*r[A][30][3,1]*r[C][48][12,11]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,1],p[C,0])]*r[A][48][3,1]*r[C][48][12,11]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[C][48][12,11]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[C][48][12,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A4B9C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,4),(B,9),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[A,0],p[C,0],p[C,1],p[A,1])]*r[A][18][4,1]*r[C][45][14,11]
    hv += -1*g[dei(p[A,1],p[C,0],p[C,1],p[A,0])]*r[A][36][4,1]*r[C][45][14,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A4B9C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,4),(B,9),(C,13)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[A,0],p[C,1],p[C,1],p[A,1])]*r[A][18][4,1]*r[C][51][13,11]
    hv += -1*g[dei(p[A,1],p[C,1],p[C,1],p[A,0])]*r[A][36][4,1]*r[C][51][13,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(C,2)]))
    hv = 0.0
    
    hv += -1*h[p[B,0],p[C,0]]*r[B][0][0,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[B,0],p[B,0])]*r[B][66][0,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[B,1],p[B,0])]*r[B][146][0,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[C,0],p[C,0])]*r[B][0][0,9]*r[C][97][2,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,1],p[C,1])]*r[B][0][0,9]*r[C][137][2,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,1],p[C,0])]*r[B][0][0,9]*r[C][125][2,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[C,1],p[C,0])]*r[B][0][0,9]*r[C][165][2,11]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][137][2,11]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,0],p[C,0])]*r[B][0][0,9]*r[C][125][2,11]
    hv += sum(-1/2*g[dei(p[B,0],p[C,0],p[I,0],p[I,0])]*r[B][0][0,9]*r[C][1][2,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[C,0],p[I,0],p[I,0])]*r[B][0][0,9]*r[C][1][2,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[C,0],p[I,1],p[I,1])]*r[B][0][0,9]*r[C][1][2,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[C,0],p[I,1],p[I,1])]*r[B][0][0,9]*r[C][1][2,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[C,0])]*r[B][0][0,9]*r[C][1][2,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[C,0])]*r[B][0][0,9]*r[C][1][2,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,0],p[B,0],p[I,0])]*r[B][0][0,9]*r[C][1][2,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,0],p[B,0],p[I,1])]*r[B][0][0,9]*r[C][1][2,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[C,0])]*r[B][0][0,9]*r[C][1][2,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[C,0])]*r[B][0][0,9]*r[C][1][2,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][9][1,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][39][1,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,0])]*r[A][9][1,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,1])]*r[A][39][1,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,0])]*r[A][9][1,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,0])]*r[A][39][1,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][0][0,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(C,3)]))
    hv = 0.0
    
    hv += -1*h[p[B,0],p[C,0]]*r[B][0][0,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[B,0],p[B,0])]*r[B][66][0,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[B,1],p[B,0])]*r[B][146][0,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[C,0],p[C,0])]*r[B][0][0,9]*r[C][97][3,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,1],p[C,1])]*r[B][0][0,9]*r[C][137][3,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,1],p[C,0])]*r[B][0][0,9]*r[C][125][3,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[C,1],p[C,0])]*r[B][0][0,9]*r[C][165][3,11]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][137][3,11]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,0],p[C,0])]*r[B][0][0,9]*r[C][125][3,11]
    hv += sum(-1/2*g[dei(p[B,0],p[C,0],p[I,0],p[I,0])]*r[B][0][0,9]*r[C][1][3,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[C,0],p[I,0],p[I,0])]*r[B][0][0,9]*r[C][1][3,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[C,0],p[I,1],p[I,1])]*r[B][0][0,9]*r[C][1][3,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[C,0],p[I,1],p[I,1])]*r[B][0][0,9]*r[C][1][3,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[C,0])]*r[B][0][0,9]*r[C][1][3,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[C,0])]*r[B][0][0,9]*r[C][1][3,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,0],p[B,0],p[I,0])]*r[B][0][0,9]*r[C][1][3,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,0],p[B,0],p[I,1])]*r[B][0][0,9]*r[C][1][3,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[C,0])]*r[B][0][0,9]*r[C][1][3,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[C,0])]*r[B][0][0,9]*r[C][1][3,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][9][1,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][39][1,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,0])]*r[A][9][1,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,1])]*r[A][39][1,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,0])]*r[A][9][1,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,0])]*r[A][39][1,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][0][0,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B1C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,1),(C,2)]))
    hv = 0.0
    
    hv += -1*h[p[B,0],p[C,0]]*r[B][0][1,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[B,0],p[B,0])]*r[B][66][1,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[B,1],p[B,0])]*r[B][146][1,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[C,0],p[C,0])]*r[B][0][1,9]*r[C][97][2,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,1],p[C,1])]*r[B][0][1,9]*r[C][137][2,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,1],p[C,0])]*r[B][0][1,9]*r[C][125][2,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[C,1],p[C,0])]*r[B][0][1,9]*r[C][165][2,11]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,0],p[C,1])]*r[B][0][1,9]*r[C][137][2,11]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,0],p[C,0])]*r[B][0][1,9]*r[C][125][2,11]
    hv += sum(-1/2*g[dei(p[B,0],p[C,0],p[I,0],p[I,0])]*r[B][0][1,9]*r[C][1][2,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[C,0],p[I,0],p[I,0])]*r[B][0][1,9]*r[C][1][2,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[C,0],p[I,1],p[I,1])]*r[B][0][1,9]*r[C][1][2,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[C,0],p[I,1],p[I,1])]*r[B][0][1,9]*r[C][1][2,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[C,0])]*r[B][0][1,9]*r[C][1][2,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[C,0])]*r[B][0][1,9]*r[C][1][2,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,0],p[B,0],p[I,0])]*r[B][0][1,9]*r[C][1][2,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,0],p[B,0],p[I,1])]*r[B][0][1,9]*r[C][1][2,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[C,0])]*r[B][0][1,9]*r[C][1][2,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[C,0])]*r[B][0][1,9]*r[C][1][2,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][9][1,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][39][1,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,0])]*r[A][9][1,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,1])]*r[A][39][1,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,0])]*r[A][9][1,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,0])]*r[A][39][1,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][0][1,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B1C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,1),(C,3)]))
    hv = 0.0
    
    hv += -1*h[p[B,0],p[C,0]]*r[B][0][1,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[B,0],p[B,0])]*r[B][66][1,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[B,1],p[B,0])]*r[B][146][1,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[C,0],p[C,0])]*r[B][0][1,9]*r[C][97][3,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,1],p[C,1])]*r[B][0][1,9]*r[C][137][3,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,1],p[C,0])]*r[B][0][1,9]*r[C][125][3,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[C,1],p[C,0])]*r[B][0][1,9]*r[C][165][3,11]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,0],p[C,1])]*r[B][0][1,9]*r[C][137][3,11]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,0],p[C,0])]*r[B][0][1,9]*r[C][125][3,11]
    hv += sum(-1/2*g[dei(p[B,0],p[C,0],p[I,0],p[I,0])]*r[B][0][1,9]*r[C][1][3,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[C,0],p[I,0],p[I,0])]*r[B][0][1,9]*r[C][1][3,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[C,0],p[I,1],p[I,1])]*r[B][0][1,9]*r[C][1][3,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[C,0],p[I,1],p[I,1])]*r[B][0][1,9]*r[C][1][3,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[C,0])]*r[B][0][1,9]*r[C][1][3,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[C,0])]*r[B][0][1,9]*r[C][1][3,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,0],p[B,0],p[I,0])]*r[B][0][1,9]*r[C][1][3,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,0],p[B,0],p[I,1])]*r[B][0][1,9]*r[C][1][3,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[C,0])]*r[B][0][1,9]*r[C][1][3,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[C,0])]*r[B][0][1,9]*r[C][1][3,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][9][1,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][39][1,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,0])]*r[A][9][1,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,1])]*r[A][39][1,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,0])]*r[A][9][1,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,0])]*r[A][39][1,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][0][1,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1)]))
    hv = 0.0
    
    hv += -1*h[p[B,0],p[C,1]]*r[B][0][0,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[B,0],p[B,0])]*r[B][66][0,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[B,1],p[B,0])]*r[B][146][0,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,0],p[C,1])]*r[B][0][0,9]*r[C][73][0,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,0],p[C,0])]*r[B][0][0,9]*r[C][61][0,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[C,0],p[C,0])]*r[B][0][0,9]*r[C][101][0,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[C,1],p[C,0])]*r[B][0][0,9]*r[C][161][0,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][73][0,11]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,0],p[C,0])]*r[B][0][0,9]*r[C][61][0,11]
    hv += sum(-1/2*g[dei(p[B,0],p[C,1],p[I,0],p[I,0])]*r[B][0][0,9]*r[C][5][0,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[C,1],p[I,0],p[I,0])]*r[B][0][0,9]*r[C][5][0,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[C,1],p[I,1],p[I,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[C,1],p[I,1],p[I,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,1],p[B,0],p[I,0])]*r[B][0][0,9]*r[C][5][0,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,1],p[B,0],p[I,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][9][1,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][39][1,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,0])]*r[A][9][1,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,1])]*r[A][39][1,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,1])]*r[A][9][1,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,1])]*r[A][39][1,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][0][0,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(C,1)]))
    hv = 0.0
    
    hv += -1*h[p[B,0],p[C,1]]*r[B][0][0,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[B,0],p[B,0])]*r[B][66][0,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[B,1],p[B,0])]*r[B][146][0,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,0],p[C,1])]*r[B][0][0,9]*r[C][73][1,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,0],p[C,0])]*r[B][0][0,9]*r[C][61][1,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[C,0],p[C,0])]*r[B][0][0,9]*r[C][101][1,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[C,1],p[C,0])]*r[B][0][0,9]*r[C][161][1,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][73][1,11]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,0],p[C,0])]*r[B][0][0,9]*r[C][61][1,11]
    hv += sum(-1/2*g[dei(p[B,0],p[C,1],p[I,0],p[I,0])]*r[B][0][0,9]*r[C][5][1,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[C,1],p[I,0],p[I,0])]*r[B][0][0,9]*r[C][5][1,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[C,1],p[I,1],p[I,1])]*r[B][0][0,9]*r[C][5][1,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[C,1],p[I,1],p[I,1])]*r[B][0][0,9]*r[C][5][1,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[C,1])]*r[B][0][0,9]*r[C][5][1,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[C,1])]*r[B][0][0,9]*r[C][5][1,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,1],p[B,0],p[I,0])]*r[B][0][0,9]*r[C][5][1,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,1],p[B,0],p[I,1])]*r[B][0][0,9]*r[C][5][1,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][5][1,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][5][1,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][9][1,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][39][1,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,0])]*r[A][9][1,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,1])]*r[A][39][1,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,1])]*r[A][9][1,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,1])]*r[A][39][1,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][0][0,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,1)]))
    hv = 0.0
    
    hv += -1*h[p[B,0],p[C,1]]*r[B][0][1,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[B,0],p[B,0])]*r[B][66][1,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[B,1],p[B,0])]*r[B][146][1,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,0],p[C,1])]*r[B][0][1,9]*r[C][73][0,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,0],p[C,0])]*r[B][0][1,9]*r[C][61][0,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[C,0],p[C,0])]*r[B][0][1,9]*r[C][101][0,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[C,1],p[C,0])]*r[B][0][1,9]*r[C][161][0,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,0],p[C,1])]*r[B][0][1,9]*r[C][73][0,11]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,0],p[C,0])]*r[B][0][1,9]*r[C][61][0,11]
    hv += sum(-1/2*g[dei(p[B,0],p[C,1],p[I,0],p[I,0])]*r[B][0][1,9]*r[C][5][0,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[C,1],p[I,0],p[I,0])]*r[B][0][1,9]*r[C][5][0,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[C,1],p[I,1],p[I,1])]*r[B][0][1,9]*r[C][5][0,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[C,1],p[I,1],p[I,1])]*r[B][0][1,9]*r[C][5][0,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[C,1])]*r[B][0][1,9]*r[C][5][0,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[C,1])]*r[B][0][1,9]*r[C][5][0,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,1],p[B,0],p[I,0])]*r[B][0][1,9]*r[C][5][0,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,1],p[B,0],p[I,1])]*r[B][0][1,9]*r[C][5][0,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[C,1])]*r[B][0][1,9]*r[C][5][0,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[C,1])]*r[B][0][1,9]*r[C][5][0,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][9][1,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][39][1,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,0])]*r[A][9][1,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,1])]*r[A][39][1,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,1])]*r[A][9][1,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,1])]*r[A][39][1,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][0][1,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B1C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,1),(C,1)]))
    hv = 0.0
    
    hv += -1*h[p[B,0],p[C,1]]*r[B][0][1,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[B,0],p[B,0])]*r[B][66][1,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[B,1],p[B,0])]*r[B][146][1,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,0],p[C,1])]*r[B][0][1,9]*r[C][73][1,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,0],p[C,0])]*r[B][0][1,9]*r[C][61][1,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[C,0],p[C,0])]*r[B][0][1,9]*r[C][101][1,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[C,1],p[C,0])]*r[B][0][1,9]*r[C][161][1,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,0],p[C,1])]*r[B][0][1,9]*r[C][73][1,11]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,0],p[C,0])]*r[B][0][1,9]*r[C][61][1,11]
    hv += sum(-1/2*g[dei(p[B,0],p[C,1],p[I,0],p[I,0])]*r[B][0][1,9]*r[C][5][1,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[C,1],p[I,0],p[I,0])]*r[B][0][1,9]*r[C][5][1,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[C,1],p[I,1],p[I,1])]*r[B][0][1,9]*r[C][5][1,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[C,1],p[I,1],p[I,1])]*r[B][0][1,9]*r[C][5][1,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[C,1])]*r[B][0][1,9]*r[C][5][1,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[C,1])]*r[B][0][1,9]*r[C][5][1,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,1],p[B,0],p[I,0])]*r[B][0][1,9]*r[C][5][1,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,1],p[B,0],p[I,1])]*r[B][0][1,9]*r[C][5][1,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[C,1])]*r[B][0][1,9]*r[C][5][1,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[C,1])]*r[B][0][1,9]*r[C][5][1,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][9][1,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][39][1,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,0])]*r[A][9][1,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,1])]*r[A][39][1,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,1])]*r[A][9][1,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,1])]*r[A][39][1,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][0][1,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B2C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,2),(C,2)]))
    hv = 0.0
    
    hv += -1*h[p[B,1],p[C,0]]*r[B][4][2,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[B,1],p[B,0])]*r[B][82][2,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[B,0],p[B,0])]*r[B][130][2,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[C,0],p[C,0])]*r[B][4][2,9]*r[C][97][2,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,1],p[C,1])]*r[B][4][2,9]*r[C][137][2,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,1],p[C,0])]*r[B][4][2,9]*r[C][125][2,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[C,1],p[C,0])]*r[B][4][2,9]*r[C][165][2,11]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,1],p[C,1])]*r[B][4][2,9]*r[C][137][2,11]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,1],p[C,0])]*r[B][4][2,9]*r[C][125][2,11]
    hv += sum(-1/2*g[dei(p[B,1],p[C,0],p[I,0],p[I,0])]*r[B][4][2,9]*r[C][1][2,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,1],p[C,0],p[I,0],p[I,0])]*r[B][4][2,9]*r[C][1][2,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[C,0],p[I,1],p[I,1])]*r[B][4][2,9]*r[C][1][2,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,1],p[C,0],p[I,1],p[I,1])]*r[B][4][2,9]*r[C][1][2,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[C,0])]*r[B][4][2,9]*r[C][1][2,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[C,0])]*r[B][4][2,9]*r[C][1][2,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,0],p[B,1],p[I,0])]*r[B][4][2,9]*r[C][1][2,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,0],p[B,1],p[I,1])]*r[B][4][2,9]*r[C][1][2,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[C,0])]*r[B][4][2,9]*r[C][1][2,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[C,0])]*r[B][4][2,9]*r[C][1][2,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][9][1,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][39][1,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,0])]*r[A][9][1,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,1])]*r[A][39][1,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,0])]*r[A][9][1,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,0])]*r[A][39][1,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][4][2,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B2C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,2),(C,3)]))
    hv = 0.0
    
    hv += -1*h[p[B,1],p[C,0]]*r[B][4][2,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[B,1],p[B,0])]*r[B][82][2,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[B,0],p[B,0])]*r[B][130][2,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[C,0],p[C,0])]*r[B][4][2,9]*r[C][97][3,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,1],p[C,1])]*r[B][4][2,9]*r[C][137][3,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,1],p[C,0])]*r[B][4][2,9]*r[C][125][3,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[C,1],p[C,0])]*r[B][4][2,9]*r[C][165][3,11]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,1],p[C,1])]*r[B][4][2,9]*r[C][137][3,11]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,1],p[C,0])]*r[B][4][2,9]*r[C][125][3,11]
    hv += sum(-1/2*g[dei(p[B,1],p[C,0],p[I,0],p[I,0])]*r[B][4][2,9]*r[C][1][3,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,1],p[C,0],p[I,0],p[I,0])]*r[B][4][2,9]*r[C][1][3,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[C,0],p[I,1],p[I,1])]*r[B][4][2,9]*r[C][1][3,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,1],p[C,0],p[I,1],p[I,1])]*r[B][4][2,9]*r[C][1][3,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[C,0])]*r[B][4][2,9]*r[C][1][3,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[C,0])]*r[B][4][2,9]*r[C][1][3,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,0],p[B,1],p[I,0])]*r[B][4][2,9]*r[C][1][3,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,0],p[B,1],p[I,1])]*r[B][4][2,9]*r[C][1][3,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[C,0])]*r[B][4][2,9]*r[C][1][3,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[C,0])]*r[B][4][2,9]*r[C][1][3,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][9][1,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][39][1,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,0])]*r[A][9][1,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,1])]*r[A][39][1,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,0])]*r[A][9][1,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,0])]*r[A][39][1,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][4][2,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B3C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,3),(C,2)]))
    hv = 0.0
    
    hv += -1*h[p[B,1],p[C,0]]*r[B][4][3,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[B,1],p[B,0])]*r[B][82][3,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[B,0],p[B,0])]*r[B][130][3,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[C,0],p[C,0])]*r[B][4][3,9]*r[C][97][2,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,1],p[C,1])]*r[B][4][3,9]*r[C][137][2,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,1],p[C,0])]*r[B][4][3,9]*r[C][125][2,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[C,1],p[C,0])]*r[B][4][3,9]*r[C][165][2,11]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,1],p[C,1])]*r[B][4][3,9]*r[C][137][2,11]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,1],p[C,0])]*r[B][4][3,9]*r[C][125][2,11]
    hv += sum(-1/2*g[dei(p[B,1],p[C,0],p[I,0],p[I,0])]*r[B][4][3,9]*r[C][1][2,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,1],p[C,0],p[I,0],p[I,0])]*r[B][4][3,9]*r[C][1][2,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[C,0],p[I,1],p[I,1])]*r[B][4][3,9]*r[C][1][2,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,1],p[C,0],p[I,1],p[I,1])]*r[B][4][3,9]*r[C][1][2,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[C,0])]*r[B][4][3,9]*r[C][1][2,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[C,0])]*r[B][4][3,9]*r[C][1][2,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,0],p[B,1],p[I,0])]*r[B][4][3,9]*r[C][1][2,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,0],p[B,1],p[I,1])]*r[B][4][3,9]*r[C][1][2,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[C,0])]*r[B][4][3,9]*r[C][1][2,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[C,0])]*r[B][4][3,9]*r[C][1][2,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][9][1,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][39][1,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,0])]*r[A][9][1,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,1])]*r[A][39][1,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,0])]*r[A][9][1,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,0])]*r[A][39][1,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][4][3,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B3C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,3),(C,3)]))
    hv = 0.0
    
    hv += -1*h[p[B,1],p[C,0]]*r[B][4][3,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[B,1],p[B,0])]*r[B][82][3,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[B,0],p[B,0])]*r[B][130][3,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[C,0],p[C,0])]*r[B][4][3,9]*r[C][97][3,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,1],p[C,1])]*r[B][4][3,9]*r[C][137][3,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,1],p[C,0])]*r[B][4][3,9]*r[C][125][3,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[C,1],p[C,0])]*r[B][4][3,9]*r[C][165][3,11]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,1],p[C,1])]*r[B][4][3,9]*r[C][137][3,11]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,1],p[C,0])]*r[B][4][3,9]*r[C][125][3,11]
    hv += sum(-1/2*g[dei(p[B,1],p[C,0],p[I,0],p[I,0])]*r[B][4][3,9]*r[C][1][3,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,1],p[C,0],p[I,0],p[I,0])]*r[B][4][3,9]*r[C][1][3,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[C,0],p[I,1],p[I,1])]*r[B][4][3,9]*r[C][1][3,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,1],p[C,0],p[I,1],p[I,1])]*r[B][4][3,9]*r[C][1][3,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[C,0])]*r[B][4][3,9]*r[C][1][3,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[C,0])]*r[B][4][3,9]*r[C][1][3,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,0],p[B,1],p[I,0])]*r[B][4][3,9]*r[C][1][3,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,0],p[B,1],p[I,1])]*r[B][4][3,9]*r[C][1][3,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[C,0])]*r[B][4][3,9]*r[C][1][3,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[C,0])]*r[B][4][3,9]*r[C][1][3,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][9][1,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][39][1,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,0])]*r[A][9][1,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,1])]*r[A][39][1,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,0])]*r[A][9][1,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,0])]*r[A][39][1,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][4][3,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B5C4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,5),(C,4)]))
    hv = 0.0
    
    hv += -1*h[p[B,1],p[C,0]]*r[B][6][5,9]*r[C][3][4,11]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[B,1],p[C,0])]*r[B][114][5,9]*r[C][3][4,11]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[B,0],p[C,0])]*r[B][162][5,9]*r[C][3][4,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[B,1],p[B,0])]*r[B][114][5,9]*r[C][3][4,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[B,0],p[B,0])]*r[B][162][5,9]*r[C][3][4,11]
    hv += g[dei(p[C,0],p[C,0],p[B,1],p[C,0])]*r[B][6][5,9]*r[C][65][4,11]
    hv += g[dei(p[C,1],p[C,1],p[B,1],p[C,0])]*r[B][6][5,9]*r[C][133][4,11]
    hv += sum(-1/2*g[dei(p[B,1],p[C,0],p[I,0],p[I,0])]*r[B][6][5,9]*r[C][3][4,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[C,0],p[I,1],p[I,1])]*r[B][6][5,9]*r[C][3][4,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[C,0])]*r[B][6][5,9]*r[C][3][4,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[C,0])]*r[B][6][5,9]*r[C][3][4,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,0],p[B,1],p[I,0])]*r[B][6][5,9]*r[C][3][4,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,0],p[B,1],p[I,1])]*r[B][6][5,9]*r[C][3][4,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[C,0])]*r[B][6][5,9]*r[C][3][4,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,1],p[C,0])]*r[B][6][5,9]*r[C][3][4,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[C,0])]*r[B][6][5,9]*r[C][3][4,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,1],p[C,0])]*r[B][6][5,9]*r[C][3][4,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][24][1,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][9][1,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][54][1,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][39][1,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,0])]*r[A][24][1,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,1])]*r[A][54][1,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,0])]*r[A][24][1,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,0])]*r[A][54][1,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][6][5,9]*r[C][3][4,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,2)]))
    hv = 0.0
    
    hv += -1*h[p[B,1],p[C,1]]*r[B][4][2,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[B,1],p[B,0])]*r[B][82][2,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[B,0],p[B,0])]*r[B][130][2,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,0],p[C,1])]*r[B][4][2,9]*r[C][73][0,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,0],p[C,0])]*r[B][4][2,9]*r[C][61][0,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[C,0],p[C,0])]*r[B][4][2,9]*r[C][101][0,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[C,1],p[C,0])]*r[B][4][2,9]*r[C][161][0,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,1],p[C,1])]*r[B][4][2,9]*r[C][73][0,11]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,1],p[C,0])]*r[B][4][2,9]*r[C][61][0,11]
    hv += sum(-1/2*g[dei(p[B,1],p[C,1],p[I,0],p[I,0])]*r[B][4][2,9]*r[C][5][0,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,1],p[C,1],p[I,0],p[I,0])]*r[B][4][2,9]*r[C][5][0,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[C,1],p[I,1],p[I,1])]*r[B][4][2,9]*r[C][5][0,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,1],p[C,1],p[I,1],p[I,1])]*r[B][4][2,9]*r[C][5][0,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[C,1])]*r[B][4][2,9]*r[C][5][0,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[C,1])]*r[B][4][2,9]*r[C][5][0,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,1],p[B,1],p[I,0])]*r[B][4][2,9]*r[C][5][0,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,1],p[B,1],p[I,1])]*r[B][4][2,9]*r[C][5][0,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[C,1])]*r[B][4][2,9]*r[C][5][0,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[C,1])]*r[B][4][2,9]*r[C][5][0,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][9][1,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][39][1,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,0])]*r[A][9][1,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,1])]*r[A][39][1,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,1])]*r[A][9][1,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,1])]*r[A][39][1,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][4][2,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B2C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,2),(C,1)]))
    hv = 0.0
    
    hv += -1*h[p[B,1],p[C,1]]*r[B][4][2,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[B,1],p[B,0])]*r[B][82][2,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[B,0],p[B,0])]*r[B][130][2,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,0],p[C,1])]*r[B][4][2,9]*r[C][73][1,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,0],p[C,0])]*r[B][4][2,9]*r[C][61][1,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[C,0],p[C,0])]*r[B][4][2,9]*r[C][101][1,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[C,1],p[C,0])]*r[B][4][2,9]*r[C][161][1,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,1],p[C,1])]*r[B][4][2,9]*r[C][73][1,11]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,1],p[C,0])]*r[B][4][2,9]*r[C][61][1,11]
    hv += sum(-1/2*g[dei(p[B,1],p[C,1],p[I,0],p[I,0])]*r[B][4][2,9]*r[C][5][1,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,1],p[C,1],p[I,0],p[I,0])]*r[B][4][2,9]*r[C][5][1,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[C,1],p[I,1],p[I,1])]*r[B][4][2,9]*r[C][5][1,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,1],p[C,1],p[I,1],p[I,1])]*r[B][4][2,9]*r[C][5][1,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[C,1])]*r[B][4][2,9]*r[C][5][1,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[C,1])]*r[B][4][2,9]*r[C][5][1,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,1],p[B,1],p[I,0])]*r[B][4][2,9]*r[C][5][1,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,1],p[B,1],p[I,1])]*r[B][4][2,9]*r[C][5][1,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[C,1])]*r[B][4][2,9]*r[C][5][1,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[C,1])]*r[B][4][2,9]*r[C][5][1,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][9][1,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][39][1,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,0])]*r[A][9][1,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,1])]*r[A][39][1,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,1])]*r[A][9][1,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,1])]*r[A][39][1,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][4][2,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,3)]))
    hv = 0.0
    
    hv += -1*h[p[B,1],p[C,1]]*r[B][4][3,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[B,1],p[B,0])]*r[B][82][3,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[B,0],p[B,0])]*r[B][130][3,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,0],p[C,1])]*r[B][4][3,9]*r[C][73][0,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,0],p[C,0])]*r[B][4][3,9]*r[C][61][0,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[C,0],p[C,0])]*r[B][4][3,9]*r[C][101][0,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[C,1],p[C,0])]*r[B][4][3,9]*r[C][161][0,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,1],p[C,1])]*r[B][4][3,9]*r[C][73][0,11]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,1],p[C,0])]*r[B][4][3,9]*r[C][61][0,11]
    hv += sum(-1/2*g[dei(p[B,1],p[C,1],p[I,0],p[I,0])]*r[B][4][3,9]*r[C][5][0,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,1],p[C,1],p[I,0],p[I,0])]*r[B][4][3,9]*r[C][5][0,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[C,1],p[I,1],p[I,1])]*r[B][4][3,9]*r[C][5][0,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,1],p[C,1],p[I,1],p[I,1])]*r[B][4][3,9]*r[C][5][0,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[C,1])]*r[B][4][3,9]*r[C][5][0,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[C,1])]*r[B][4][3,9]*r[C][5][0,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,1],p[B,1],p[I,0])]*r[B][4][3,9]*r[C][5][0,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,1],p[B,1],p[I,1])]*r[B][4][3,9]*r[C][5][0,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[C,1])]*r[B][4][3,9]*r[C][5][0,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[C,1])]*r[B][4][3,9]*r[C][5][0,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][9][1,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][39][1,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,0])]*r[A][9][1,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,1])]*r[A][39][1,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,1])]*r[A][9][1,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,1])]*r[A][39][1,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][4][3,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B3C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,3),(C,1)]))
    hv = 0.0
    
    hv += -1*h[p[B,1],p[C,1]]*r[B][4][3,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[B,1],p[B,0])]*r[B][82][3,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[B,0],p[B,0])]*r[B][130][3,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,0],p[C,1])]*r[B][4][3,9]*r[C][73][1,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,0],p[C,0])]*r[B][4][3,9]*r[C][61][1,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[C,0],p[C,0])]*r[B][4][3,9]*r[C][101][1,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[C,1],p[C,0])]*r[B][4][3,9]*r[C][161][1,11]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,1],p[C,1])]*r[B][4][3,9]*r[C][73][1,11]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,1],p[C,0])]*r[B][4][3,9]*r[C][61][1,11]
    hv += sum(-1/2*g[dei(p[B,1],p[C,1],p[I,0],p[I,0])]*r[B][4][3,9]*r[C][5][1,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,1],p[C,1],p[I,0],p[I,0])]*r[B][4][3,9]*r[C][5][1,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[C,1],p[I,1],p[I,1])]*r[B][4][3,9]*r[C][5][1,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,1],p[C,1],p[I,1],p[I,1])]*r[B][4][3,9]*r[C][5][1,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[C,1])]*r[B][4][3,9]*r[C][5][1,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[C,1])]*r[B][4][3,9]*r[C][5][1,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,1],p[B,1],p[I,0])]*r[B][4][3,9]*r[C][5][1,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,1],p[B,1],p[I,1])]*r[B][4][3,9]*r[C][5][1,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[C,1])]*r[B][4][3,9]*r[C][5][1,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[C,1])]*r[B][4][3,9]*r[C][5][1,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][9][1,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][39][1,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,0])]*r[A][9][1,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,1])]*r[A][39][1,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,1])]*r[A][9][1,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,1])]*r[A][39][1,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][4][3,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B6C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,6),(C,15)]))
    hv = 0.0
    
    hv += h[p[C,1],p[B,0]]*r[B][3][6,9]*r[C][6][15,11]
    hv += 1/2*g[dei(p[C,0],p[B,0],p[C,1],p[C,0])]*r[B][3][6,9]*r[C][114][15,11]
    hv += 1/2*g[dei(p[C,1],p[B,0],p[C,0],p[C,0])]*r[B][3][6,9]*r[C][162][15,11]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[C,1],p[B,0])]*r[B][3][6,9]*r[C][114][15,11]
    hv += -1*g[dei(p[C,0],p[C,0],p[C,1],p[B,0])]*r[B][3][6,9]*r[C][80][15,11]
    hv += -1/2*g[dei(p[C,1],p[C,0],p[C,0],p[B,0])]*r[B][3][6,9]*r[C][162][15,11]
    hv += -1*g[dei(p[C,1],p[C,1],p[C,1],p[B,0])]*r[B][3][6,9]*r[C][148][15,11]
    hv += sum(1/2*g[dei(p[C,1],p[B,0],p[I,0],p[I,0])]*r[B][3][6,9]*r[C][6][15,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[B,0],p[I,1],p[I,1])]*r[B][3][6,9]*r[C][6][15,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,0],p[I,0],p[B,0])]*r[B][3][6,9]*r[C][6][15,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,1],p[I,1],p[B,0])]*r[B][3][6,9]*r[C][6][15,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,0],p[C,1],p[I,0])]*r[B][3][6,9]*r[C][6][15,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,0],p[C,1],p[I,1])]*r[B][3][6,9]*r[C][6][15,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,1],p[B,0])]*r[B][3][6,9]*r[C][6][15,11]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[C,1],p[B,0])]*r[B][3][6,9]*r[C][6][15,11]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,1],p[B,0])]*r[B][3][6,9]*r[C][6][15,11]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[C,1],p[B,0])]*r[B][3][6,9]*r[C][6][15,11]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[B,0])]*r[A][24][1,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += g[dei(p[A,0],p[A,0],p[C,1],p[B,0])]*r[A][9][1,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[B,0])]*r[A][54][1,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += g[dei(p[A,1],p[A,1],p[C,1],p[B,0])]*r[A][39][1,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[C,1],p[A,0])]*r[A][24][1,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[C,1],p[A,1])]*r[A][54][1,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[B,0])]*r[A][24][1,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[B,0])]*r[A][54][1,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += 1/2*g[dei(p[C,1],p[B,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += 1/2*g[dei(p[C,1],p[B,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][3][6,9]*r[C][6][15,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B13C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,13),(C,8)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[B,0],p[C,0],p[B,1],p[C,0])]*r[B][17][13,9]*r[C][22][8,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B11C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,11),(C,9)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[B,0],p[C,0],p[B,1],p[C,1])]*r[B][14][11,9]*r[C][34][9,11]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[B,1],p[C,0])]*r[B][14][11,9]*r[C][16][9,11]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[B,0],p[C,1])]*r[B][32][11,9]*r[C][34][9,11]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[B,0],p[C,0])]*r[B][32][11,9]*r[C][16][9,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B13C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,13),(C,7)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[B,0],p[C,1],p[B,1],p[C,0])]*r[B][17][13,9]*r[C][28][7,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B14C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,14),(C,8)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[B,1],p[C,0],p[B,1],p[C,0])]*r[B][41][14,9]*r[C][22][8,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B14C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,14),(C,7)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[B,1],p[C,1],p[B,1],p[C,0])]*r[B][41][14,9]*r[C][28][7,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B10C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,10),(C,12)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,1],p[C,0])]*r[B][48][10,9]*r[C][48][12,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,1],p[B,0])]*r[B][48][10,9]*r[C][48][12,11]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,1],p[C,0])]*r[B][48][10,9]*r[C][48][12,11]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,1],p[B,0])]*r[B][48][10,9]*r[C][48][12,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B7C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,7),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[B,0],p[C,0],p[C,1],p[B,0])]*r[B][12][7,9]*r[C][45][14,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B7C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,7),(C,13)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[B,0],p[C,1],p[C,1],p[B,0])]*r[B][12][7,9]*r[C][51][13,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B8C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,8),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[B,1],p[C,0],p[C,1],p[B,0])]*r[B][36][8,9]*r[C][45][14,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B8C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,8),(C,13)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[B,1],p[C,1],p[C,1],p[B,0])]*r[B][36][8,9]*r[C][51][13,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _C11I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(C,11),(I,9)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[I,0])]*r[A][9][0,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[I,0])]*r[A][39][0,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,0],p[A,0])]*r[A][9][0,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,0],p[A,1])]*r[A][39][0,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[I,0])]*r[A][9][0,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[I,0])]*r[A][39][0,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += g[dei(p[B,0],p[I,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += g[dei(p[B,0],p[I,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][0][0,9]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1C11I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,1),(C,11),(I,9)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[I,0])]*r[A][9][0,1]*r[B][0][1,9]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[I,0])]*r[A][39][0,1]*r[B][0][1,9]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,0],p[A,0])]*r[A][9][0,1]*r[B][0][1,9]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,0],p[A,1])]*r[A][39][0,1]*r[B][0][1,9]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[I,0])]*r[A][9][0,1]*r[B][0][1,9]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[I,0])]*r[A][39][0,1]*r[B][0][1,9]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][0][1,9]*r[I][1][9,0]
        hv += g[dei(p[B,0],p[I,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][0][1,9]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][0][1,9]*r[I][1][9,0]
        hv += g[dei(p[B,0],p[I,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][0][1,9]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _C11I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(C,11),(I,10)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[I,1])]*r[A][9][0,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[I,1])]*r[A][39][0,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,0],p[A,0])]*r[A][9][0,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,0],p[A,1])]*r[A][39][0,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[I,1])]*r[A][9][0,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[I,1])]*r[A][39][0,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += g[dei(p[B,0],p[I,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += g[dei(p[B,0],p[I,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][0][0,9]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1C11I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,1),(C,11),(I,10)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[I,1])]*r[A][9][0,1]*r[B][0][1,9]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[I,1])]*r[A][39][0,1]*r[B][0][1,9]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,0],p[A,0])]*r[A][9][0,1]*r[B][0][1,9]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,0],p[A,1])]*r[A][39][0,1]*r[B][0][1,9]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[I,1])]*r[A][9][0,1]*r[B][0][1,9]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[I,1])]*r[A][39][0,1]*r[B][0][1,9]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][0][1,9]*r[I][5][10,0]
        hv += g[dei(p[B,0],p[I,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][0][1,9]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][0][1,9]*r[I][5][10,0]
        hv += g[dei(p[B,0],p[I,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][0][1,9]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2C11I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,2),(C,11),(I,9)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[I,0])]*r[A][15][2,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[I,0])]*r[A][33][2,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,0],p[A,1])]*r[A][15][2,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,0],p[A,0])]*r[A][33][2,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[I,0])]*r[A][15][2,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[I,0])]*r[A][33][2,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += g[dei(p[B,0],p[I,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += g[dei(p[B,0],p[I,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][0][0,9]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C11I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,11),(I,9)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[I,0])]*r[A][15][3,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[I,0])]*r[A][33][3,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,0],p[A,1])]*r[A][15][3,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,0],p[A,0])]*r[A][33][3,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[I,0])]*r[A][15][3,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[I,0])]*r[A][33][3,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += g[dei(p[B,0],p[I,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][0][0,9]*r[I][1][9,0]
        hv += g[dei(p[B,0],p[I,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][0][0,9]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2C11I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,2),(C,11),(I,10)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[I,1])]*r[A][15][2,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[I,1])]*r[A][33][2,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,0],p[A,1])]*r[A][15][2,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,0],p[A,0])]*r[A][33][2,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[I,1])]*r[A][15][2,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[I,1])]*r[A][33][2,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += g[dei(p[B,0],p[I,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += g[dei(p[B,0],p[I,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][0][0,9]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C11I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,11),(I,10)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[I,1])]*r[A][15][3,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[I,1])]*r[A][33][3,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,0],p[A,1])]*r[A][15][3,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,0],p[A,0])]*r[A][33][3,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[I,1])]*r[A][15][3,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[I,1])]*r[A][33][3,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += g[dei(p[B,0],p[I,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][0][0,9]*r[I][5][10,0]
        hv += g[dei(p[B,0],p[I,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][0][0,9]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2C11I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,2),(C,11),(I,9)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[I,0])]*r[A][9][0,1]*r[B][4][2,9]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[I,0])]*r[A][39][0,1]*r[B][4][2,9]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,1],p[A,0])]*r[A][9][0,1]*r[B][4][2,9]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,1],p[A,1])]*r[A][39][0,1]*r[B][4][2,9]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[I,0])]*r[A][9][0,1]*r[B][4][2,9]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[I,0])]*r[A][39][0,1]*r[B][4][2,9]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][4][2,9]*r[I][1][9,0]
        hv += g[dei(p[B,1],p[I,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][4][2,9]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][4][2,9]*r[I][1][9,0]
        hv += g[dei(p[B,1],p[I,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][4][2,9]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3C11I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,3),(C,11),(I,9)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[I,0])]*r[A][9][0,1]*r[B][4][3,9]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[I,0])]*r[A][39][0,1]*r[B][4][3,9]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,1],p[A,0])]*r[A][9][0,1]*r[B][4][3,9]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,1],p[A,1])]*r[A][39][0,1]*r[B][4][3,9]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[I,0])]*r[A][9][0,1]*r[B][4][3,9]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[I,0])]*r[A][39][0,1]*r[B][4][3,9]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][4][3,9]*r[I][1][9,0]
        hv += g[dei(p[B,1],p[I,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][4][3,9]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][4][3,9]*r[I][1][9,0]
        hv += g[dei(p[B,1],p[I,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][4][3,9]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B5C11I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,5),(C,11),(I,7)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[I,0])]*r[A][24][0,1]*r[B][6][5,9]*r[I][3][7,0]
        hv += g[dei(p[A,0],p[A,0],p[B,1],p[I,0])]*r[A][9][0,1]*r[B][6][5,9]*r[I][3][7,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[I,0])]*r[A][54][0,1]*r[B][6][5,9]*r[I][3][7,0]
        hv += g[dei(p[A,1],p[A,1],p[B,1],p[I,0])]*r[A][39][0,1]*r[B][6][5,9]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,1],p[A,0])]*r[A][24][0,1]*r[B][6][5,9]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,1],p[A,1])]*r[A][54][0,1]*r[B][6][5,9]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[I,0])]*r[A][24][0,1]*r[B][6][5,9]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[I,0])]*r[A][54][0,1]*r[B][6][5,9]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][6][5,9]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][6][5,9]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2C11I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,2),(C,11),(I,10)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[I,1])]*r[A][9][0,1]*r[B][4][2,9]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[I,1])]*r[A][39][0,1]*r[B][4][2,9]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,1],p[A,0])]*r[A][9][0,1]*r[B][4][2,9]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,1],p[A,1])]*r[A][39][0,1]*r[B][4][2,9]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[I,1])]*r[A][9][0,1]*r[B][4][2,9]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[I,1])]*r[A][39][0,1]*r[B][4][2,9]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][4][2,9]*r[I][5][10,0]
        hv += g[dei(p[B,1],p[I,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][4][2,9]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][4][2,9]*r[I][5][10,0]
        hv += g[dei(p[B,1],p[I,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][4][2,9]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3C11I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,3),(C,11),(I,10)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[I,1])]*r[A][9][0,1]*r[B][4][3,9]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[I,1])]*r[A][39][0,1]*r[B][4][3,9]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,1],p[A,0])]*r[A][9][0,1]*r[B][4][3,9]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,1],p[A,1])]*r[A][39][0,1]*r[B][4][3,9]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[I,1])]*r[A][9][0,1]*r[B][4][3,9]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[I,1])]*r[A][39][0,1]*r[B][4][3,9]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][4][3,9]*r[I][5][10,0]
        hv += g[dei(p[B,1],p[I,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][4][3,9]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][4][3,9]*r[I][5][10,0]
        hv += g[dei(p[B,1],p[I,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][4][3,9]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B5C11I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,5),(C,11),(I,8)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[I,1])]*r[A][24][0,1]*r[B][6][5,9]*r[I][7][8,0]
        hv += g[dei(p[A,0],p[A,0],p[B,1],p[I,1])]*r[A][9][0,1]*r[B][6][5,9]*r[I][7][8,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[I,1])]*r[A][54][0,1]*r[B][6][5,9]*r[I][7][8,0]
        hv += g[dei(p[A,1],p[A,1],p[B,1],p[I,1])]*r[A][39][0,1]*r[B][6][5,9]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,1],p[A,0])]*r[A][24][0,1]*r[B][6][5,9]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,1],p[A,1])]*r[A][54][0,1]*r[B][6][5,9]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[I,1])]*r[A][24][0,1]*r[B][6][5,9]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[I,1])]*r[A][54][0,1]*r[B][6][5,9]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][6][5,9]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][6][5,9]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B6C11I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,6),(C,11),(I,14)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,0],p[I,0],p[B,0])]*r[A][24][0,1]*r[B][3][6,9]*r[I][2][14,0]
        hv += -1*g[dei(p[A,0],p[A,0],p[I,0],p[B,0])]*r[A][9][0,1]*r[B][3][6,9]*r[I][2][14,0]
        hv += -1/2*g[dei(p[A,1],p[A,1],p[I,0],p[B,0])]*r[A][54][0,1]*r[B][3][6,9]*r[I][2][14,0]
        hv += -1*g[dei(p[A,1],p[A,1],p[I,0],p[B,0])]*r[A][39][0,1]*r[B][3][6,9]*r[I][2][14,0]
        hv += 1/2*g[dei(p[A,0],p[B,0],p[I,0],p[A,0])]*r[A][24][0,1]*r[B][3][6,9]*r[I][2][14,0]
        hv += 1/2*g[dei(p[A,1],p[B,0],p[I,0],p[A,1])]*r[A][54][0,1]*r[B][3][6,9]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[A,0],p[B,0])]*r[A][24][0,1]*r[B][3][6,9]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[A,1],p[B,0])]*r[A][54][0,1]*r[B][3][6,9]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[B,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][3][6,9]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[B,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][3][6,9]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B6C11I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,6),(C,11),(I,13)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,0],p[I,1],p[B,0])]*r[A][24][0,1]*r[B][3][6,9]*r[I][6][13,0]
        hv += -1*g[dei(p[A,0],p[A,0],p[I,1],p[B,0])]*r[A][9][0,1]*r[B][3][6,9]*r[I][6][13,0]
        hv += -1/2*g[dei(p[A,1],p[A,1],p[I,1],p[B,0])]*r[A][54][0,1]*r[B][3][6,9]*r[I][6][13,0]
        hv += -1*g[dei(p[A,1],p[A,1],p[I,1],p[B,0])]*r[A][39][0,1]*r[B][3][6,9]*r[I][6][13,0]
        hv += 1/2*g[dei(p[A,0],p[B,0],p[I,1],p[A,0])]*r[A][24][0,1]*r[B][3][6,9]*r[I][6][13,0]
        hv += 1/2*g[dei(p[A,1],p[B,0],p[I,1],p[A,1])]*r[A][54][0,1]*r[B][3][6,9]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[A,0],p[B,0])]*r[A][24][0,1]*r[B][3][6,9]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[A,1],p[B,0])]*r[A][54][0,1]*r[B][3][6,9]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[B,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][3][6,9]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[B,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][3][6,9]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5C11I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,5),(C,11),(I,7)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1*g[dei(p[B,0],p[A,1],p[A,0],p[I,0])]*r[A][27][5,1]*r[B][0][0,9]*r[I][3][7,0]
        hv += -1*g[dei(p[B,0],p[A,0],p[A,1],p[I,0])]*r[A][45][5,1]*r[B][0][0,9]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5C11I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,5),(C,11),(I,8)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1*g[dei(p[B,0],p[A,1],p[A,0],p[I,1])]*r[A][27][5,1]*r[B][0][0,9]*r[I][7][8,0]
        hv += -1*g[dei(p[B,0],p[A,0],p[A,1],p[I,1])]*r[A][45][5,1]*r[B][0][0,9]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14C11I6(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(C,11),(I,6)]))
        hv = 0.0
        sket = sign([A,C])
        
        hv += -1*g[dei(p[B,0],p[I,0],p[A,0],p[I,0])]*r[A][2][14,1]*r[B][0][0,9]*r[I][22][6,0]
        hv += -1*g[dei(p[B,0],p[I,1],p[A,0],p[I,1])]*r[A][2][14,1]*r[B][0][0,9]*r[I][52][6,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13C11I6(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(C,11),(I,6)]))
        hv = 0.0
        sket = sign([A,C])
        
        hv += -1*g[dei(p[B,0],p[I,0],p[A,1],p[I,0])]*r[A][6][13,1]*r[B][0][0,9]*r[I][22][6,0]
        hv += -1*g[dei(p[B,0],p[I,1],p[A,1],p[I,1])]*r[A][6][13,1]*r[B][0][0,9]*r[I][52][6,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6C11I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,6),(C,11),(I,14)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += g[dei(p[B,0],p[A,0],p[I,0],p[A,0])]*r[A][22][6,1]*r[B][0][0,9]*r[I][2][14,0]
        hv += g[dei(p[B,0],p[A,1],p[I,0],p[A,1])]*r[A][52][6,1]*r[B][0][0,9]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6C11I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,6),(C,11),(I,13)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += g[dei(p[B,0],p[A,0],p[I,1],p[A,0])]*r[A][22][6,1]*r[B][0][0,9]*r[I][6][13,0]
        hv += g[dei(p[B,0],p[A,1],p[I,1],p[A,1])]*r[A][52][6,1]*r[B][0][0,9]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9C11I1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(C,11),(I,1)]))
        hv = 0.0
        sket = sign([A,C])
        
        hv += -1/2*g[dei(p[B,0],p[A,0],p[I,0],p[I,0])]*r[A][1][9,1]*r[B][0][0,9]*r[I][9][1,0]
        hv += -1*g[dei(p[B,0],p[A,0],p[I,0],p[I,0])]*r[A][1][9,1]*r[B][0][0,9]*r[I][24][1,0]
        hv += -1/2*g[dei(p[B,0],p[A,0],p[I,1],p[I,1])]*r[A][1][9,1]*r[B][0][0,9]*r[I][39][1,0]
        hv += -1*g[dei(p[B,0],p[A,0],p[I,1],p[I,1])]*r[A][1][9,1]*r[B][0][0,9]*r[I][54][1,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[I,0],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[I][9][1,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[I,1],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[B,0],p[I,0])]*r[A][1][9,1]*r[B][0][0,9]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[B,0],p[I,1])]*r[A][1][9,1]*r[B][0][0,9]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9C11I2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(C,11),(I,2)]))
        hv = 0.0
        sket = sign([A,C])
        
        hv += -1/2*g[dei(p[B,0],p[A,0],p[I,0],p[I,1])]*r[A][1][9,1]*r[B][0][0,9]*r[I][15][2,0]
        hv += -1*g[dei(p[B,0],p[A,0],p[I,0],p[I,1])]*r[A][1][9,1]*r[B][0][0,9]*r[I][30][2,0]
        hv += -1/2*g[dei(p[B,0],p[A,0],p[I,1],p[I,0])]*r[A][1][9,1]*r[B][0][0,9]*r[I][33][2,0]
        hv += -1*g[dei(p[B,0],p[A,0],p[I,1],p[I,0])]*r[A][1][9,1]*r[B][0][0,9]*r[I][48][2,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[I,0],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[I][15][2,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[I,1],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[B,0],p[I,1])]*r[A][1][9,1]*r[B][0][0,9]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[B,0],p[I,0])]*r[A][1][9,1]*r[B][0][0,9]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9C11I3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(C,11),(I,3)]))
        hv = 0.0
        sket = sign([A,C])
        
        hv += -1/2*g[dei(p[B,0],p[A,0],p[I,0],p[I,1])]*r[A][1][9,1]*r[B][0][0,9]*r[I][15][3,0]
        hv += -1*g[dei(p[B,0],p[A,0],p[I,0],p[I,1])]*r[A][1][9,1]*r[B][0][0,9]*r[I][30][3,0]
        hv += -1/2*g[dei(p[B,0],p[A,0],p[I,1],p[I,0])]*r[A][1][9,1]*r[B][0][0,9]*r[I][33][3,0]
        hv += -1*g[dei(p[B,0],p[A,0],p[I,1],p[I,0])]*r[A][1][9,1]*r[B][0][0,9]*r[I][48][3,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[I,0],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[I][15][3,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[I,1],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[B,0],p[I,1])]*r[A][1][9,1]*r[B][0][0,9]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[B,0],p[I,0])]*r[A][1][9,1]*r[B][0][0,9]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10C11I1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(C,11),(I,1)]))
        hv = 0.0
        sket = sign([A,C])
        
        hv += -1/2*g[dei(p[B,0],p[A,1],p[I,0],p[I,0])]*r[A][5][10,1]*r[B][0][0,9]*r[I][9][1,0]
        hv += -1*g[dei(p[B,0],p[A,1],p[I,0],p[I,0])]*r[A][5][10,1]*r[B][0][0,9]*r[I][24][1,0]
        hv += -1/2*g[dei(p[B,0],p[A,1],p[I,1],p[I,1])]*r[A][5][10,1]*r[B][0][0,9]*r[I][39][1,0]
        hv += -1*g[dei(p[B,0],p[A,1],p[I,1],p[I,1])]*r[A][5][10,1]*r[B][0][0,9]*r[I][54][1,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[I,0],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[I][9][1,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[I,1],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[B,0],p[I,0])]*r[A][5][10,1]*r[B][0][0,9]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[B,0],p[I,1])]*r[A][5][10,1]*r[B][0][0,9]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10C11I2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(C,11),(I,2)]))
        hv = 0.0
        sket = sign([A,C])
        
        hv += -1/2*g[dei(p[B,0],p[A,1],p[I,0],p[I,1])]*r[A][5][10,1]*r[B][0][0,9]*r[I][15][2,0]
        hv += -1*g[dei(p[B,0],p[A,1],p[I,0],p[I,1])]*r[A][5][10,1]*r[B][0][0,9]*r[I][30][2,0]
        hv += -1/2*g[dei(p[B,0],p[A,1],p[I,1],p[I,0])]*r[A][5][10,1]*r[B][0][0,9]*r[I][33][2,0]
        hv += -1*g[dei(p[B,0],p[A,1],p[I,1],p[I,0])]*r[A][5][10,1]*r[B][0][0,9]*r[I][48][2,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[I,0],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[I][15][2,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[I,1],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[B,0],p[I,1])]*r[A][5][10,1]*r[B][0][0,9]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[B,0],p[I,0])]*r[A][5][10,1]*r[B][0][0,9]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10C11I3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(C,11),(I,3)]))
        hv = 0.0
        sket = sign([A,C])
        
        hv += -1/2*g[dei(p[B,0],p[A,1],p[I,0],p[I,1])]*r[A][5][10,1]*r[B][0][0,9]*r[I][15][3,0]
        hv += -1*g[dei(p[B,0],p[A,1],p[I,0],p[I,1])]*r[A][5][10,1]*r[B][0][0,9]*r[I][30][3,0]
        hv += -1/2*g[dei(p[B,0],p[A,1],p[I,1],p[I,0])]*r[A][5][10,1]*r[B][0][0,9]*r[I][33][3,0]
        hv += -1*g[dei(p[B,0],p[A,1],p[I,1],p[I,0])]*r[A][5][10,1]*r[B][0][0,9]*r[I][48][3,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[I,0],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[I][15][3,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[I,1],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[B,0],p[I,1])]*r[A][5][10,1]*r[B][0][0,9]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[B,0],p[I,0])]*r[A][5][10,1]*r[B][0][0,9]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7C11I5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(C,11),(I,5)]))
        hv = 0.0
        sket = sign([A,C])
        
        hv += g[dei(p[B,0],p[I,1],p[I,0],p[A,0])]*r[A][3][7,1]*r[B][0][0,9]*r[I][27][5,0]
        hv += g[dei(p[B,0],p[I,0],p[I,1],p[A,0])]*r[A][3][7,1]*r[B][0][0,9]*r[I][45][5,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8C11I5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(C,11),(I,5)]))
        hv = 0.0
        sket = sign([A,C])
        
        hv += g[dei(p[B,0],p[I,1],p[I,0],p[A,1])]*r[A][7][8,1]*r[B][0][0,9]*r[I][27][5,0]
        hv += g[dei(p[B,0],p[I,0],p[I,1],p[A,1])]*r[A][7][8,1]*r[B][0][0,9]*r[I][45][5,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A15B9I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,15),(B,9),(I,7)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[A,0],p[C,1],p[A,0],p[I,0])]*r[A][11][15,1]*r[C][5][0,11]*r[I][3][7,0]
        hv += g[dei(p[A,1],p[C,1],p[A,1],p[I,0])]*r[A][41][15,1]*r[C][5][0,11]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A15B9I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,15),(B,9),(I,8)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[A,0],p[C,1],p[A,0],p[I,1])]*r[A][11][15,1]*r[C][5][0,11]*r[I][7][8,0]
        hv += g[dei(p[A,1],p[C,1],p[A,1],p[I,1])]*r[A][41][15,1]*r[C][5][0,11]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B9C15I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,9),(C,15),(I,7)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,0],p[C,1],p[I,0])]*r[A][24][0,1]*r[C][6][15,11]*r[I][3][7,0]
        hv += -1*g[dei(p[A,0],p[A,0],p[C,1],p[I,0])]*r[A][9][0,1]*r[C][6][15,11]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,1],p[A,1],p[C,1],p[I,0])]*r[A][54][0,1]*r[C][6][15,11]*r[I][3][7,0]
        hv += -1*g[dei(p[A,1],p[A,1],p[C,1],p[I,0])]*r[A][39][0,1]*r[C][6][15,11]*r[I][3][7,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[C,1],p[A,0])]*r[A][24][0,1]*r[C][6][15,11]*r[I][3][7,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[C,1],p[A,1])]*r[A][54][0,1]*r[C][6][15,11]*r[I][3][7,0]
        hv += 1/2*g[dei(p[C,1],p[A,0],p[A,0],p[I,0])]*r[A][24][0,1]*r[C][6][15,11]*r[I][3][7,0]
        hv += 1/2*g[dei(p[C,1],p[A,1],p[A,1],p[I,0])]*r[A][54][0,1]*r[C][6][15,11]*r[I][3][7,0]
        hv += -1/2*g[dei(p[C,1],p[I,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][6][15,11]*r[I][3][7,0]
        hv += -1/2*g[dei(p[C,1],p[I,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][6][15,11]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B9C15I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,9),(C,15),(I,8)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,0],p[C,1],p[I,1])]*r[A][24][0,1]*r[C][6][15,11]*r[I][7][8,0]
        hv += -1*g[dei(p[A,0],p[A,0],p[C,1],p[I,1])]*r[A][9][0,1]*r[C][6][15,11]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,1],p[A,1],p[C,1],p[I,1])]*r[A][54][0,1]*r[C][6][15,11]*r[I][7][8,0]
        hv += -1*g[dei(p[A,1],p[A,1],p[C,1],p[I,1])]*r[A][39][0,1]*r[C][6][15,11]*r[I][7][8,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[C,1],p[A,0])]*r[A][24][0,1]*r[C][6][15,11]*r[I][7][8,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[C,1],p[A,1])]*r[A][54][0,1]*r[C][6][15,11]*r[I][7][8,0]
        hv += 1/2*g[dei(p[C,1],p[A,0],p[A,0],p[I,1])]*r[A][24][0,1]*r[C][6][15,11]*r[I][7][8,0]
        hv += 1/2*g[dei(p[C,1],p[A,1],p[A,1],p[I,1])]*r[A][54][0,1]*r[C][6][15,11]*r[I][7][8,0]
        hv += -1/2*g[dei(p[C,1],p[I,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][6][15,11]*r[I][7][8,0]
        hv += -1/2*g[dei(p[C,1],p[I,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][6][15,11]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B9C2I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,9),(C,2),(I,12)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,0],p[C,0])]*r[A][9][0,1]*r[C][1][2,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,0],p[C,0])]*r[A][39][0,1]*r[C][1][2,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[A,0],p[C,0],p[I,0],p[A,0])]*r[A][9][0,1]*r[C][1][2,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[A,1],p[C,0],p[I,0],p[A,1])]*r[A][39][0,1]*r[C][1][2,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,0],p[C,0])]*r[A][9][0,1]*r[C][1][2,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,1],p[C,0])]*r[A][39][0,1]*r[C][1][2,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[C][1][2,11]*r[I][0][12,0]
        hv += g[dei(p[I,0],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][1][2,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[C][1][2,11]*r[I][0][12,0]
        hv += g[dei(p[I,0],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][1][2,11]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B9C3I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,9),(C,3),(I,12)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,0],p[C,0])]*r[A][9][0,1]*r[C][1][3,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,0],p[C,0])]*r[A][39][0,1]*r[C][1][3,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[A,0],p[C,0],p[I,0],p[A,0])]*r[A][9][0,1]*r[C][1][3,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[A,1],p[C,0],p[I,0],p[A,1])]*r[A][39][0,1]*r[C][1][3,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,0],p[C,0])]*r[A][9][0,1]*r[C][1][3,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,1],p[C,0])]*r[A][39][0,1]*r[C][1][3,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[C][1][3,11]*r[I][0][12,0]
        hv += g[dei(p[I,0],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][1][3,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[C][1][3,11]*r[I][0][12,0]
        hv += g[dei(p[I,0],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][1][3,11]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B9C4I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,9),(C,4),(I,14)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,0],p[C,0])]*r[A][24][0,1]*r[C][3][4,11]*r[I][2][14,0]
        hv += g[dei(p[A,0],p[A,0],p[I,0],p[C,0])]*r[A][9][0,1]*r[C][3][4,11]*r[I][2][14,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,0],p[C,0])]*r[A][54][0,1]*r[C][3][4,11]*r[I][2][14,0]
        hv += g[dei(p[A,1],p[A,1],p[I,0],p[C,0])]*r[A][39][0,1]*r[C][3][4,11]*r[I][2][14,0]
        hv += -1/2*g[dei(p[A,0],p[C,0],p[I,0],p[A,0])]*r[A][24][0,1]*r[C][3][4,11]*r[I][2][14,0]
        hv += -1/2*g[dei(p[A,1],p[C,0],p[I,0],p[A,1])]*r[A][54][0,1]*r[C][3][4,11]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,0],p[C,0])]*r[A][24][0,1]*r[C][3][4,11]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,1],p[C,0])]*r[A][54][0,1]*r[C][3][4,11]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][3][4,11]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][3][4,11]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B9I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,9),(I,12)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,0],p[C,1])]*r[A][9][0,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,0],p[C,1])]*r[A][39][0,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[A,0],p[C,1],p[I,0],p[A,0])]*r[A][9][0,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[A,1],p[C,1],p[I,0],p[A,1])]*r[A][39][0,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,0],p[C,1])]*r[A][9][0,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,1],p[C,1])]*r[A][39][0,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += g[dei(p[I,0],p[C,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += g[dei(p[I,0],p[C,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][5][0,11]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B9C1I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,9),(C,1),(I,12)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,0],p[C,1])]*r[A][9][0,1]*r[C][5][1,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,0],p[C,1])]*r[A][39][0,1]*r[C][5][1,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[A,0],p[C,1],p[I,0],p[A,0])]*r[A][9][0,1]*r[C][5][1,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[A,1],p[C,1],p[I,0],p[A,1])]*r[A][39][0,1]*r[C][5][1,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,0],p[C,1])]*r[A][9][0,1]*r[C][5][1,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,1],p[C,1])]*r[A][39][0,1]*r[C][5][1,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[C][5][1,11]*r[I][0][12,0]
        hv += g[dei(p[I,0],p[C,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][5][1,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[C][5][1,11]*r[I][0][12,0]
        hv += g[dei(p[I,0],p[C,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][5][1,11]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B9I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,2),(B,9),(I,12)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,0],p[C,1])]*r[A][15][2,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,0],p[C,1])]*r[A][33][2,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[A,0],p[C,1],p[I,0],p[A,1])]*r[A][15][2,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[A,1],p[C,1],p[I,0],p[A,0])]*r[A][33][2,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,0],p[C,1])]*r[A][15][2,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,1],p[C,1])]*r[A][33][2,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[A,0],p[A,1])]*r[A][15][2,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += g[dei(p[I,0],p[C,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[A,1],p[A,0])]*r[A][33][2,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += g[dei(p[I,0],p[C,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[C][5][0,11]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B9I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,9),(I,12)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,0],p[C,1])]*r[A][15][3,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,0],p[C,1])]*r[A][33][3,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[A,0],p[C,1],p[I,0],p[A,1])]*r[A][15][3,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[A,1],p[C,1],p[I,0],p[A,0])]*r[A][33][3,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,0],p[C,1])]*r[A][15][3,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,1],p[C,1])]*r[A][33][3,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[A,0],p[A,1])]*r[A][15][3,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += g[dei(p[I,0],p[C,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[A,1],p[A,0])]*r[A][33][3,1]*r[C][5][0,11]*r[I][0][12,0]
        hv += g[dei(p[I,0],p[C,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[C][5][0,11]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B9C2I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,9),(C,2),(I,11)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,1],p[C,0])]*r[A][9][0,1]*r[C][1][2,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,1],p[C,0])]*r[A][39][0,1]*r[C][1][2,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[A,0],p[C,0],p[I,1],p[A,0])]*r[A][9][0,1]*r[C][1][2,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[A,1],p[C,0],p[I,1],p[A,1])]*r[A][39][0,1]*r[C][1][2,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,0],p[C,0])]*r[A][9][0,1]*r[C][1][2,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,1],p[C,0])]*r[A][39][0,1]*r[C][1][2,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[C][1][2,11]*r[I][4][11,0]
        hv += g[dei(p[I,1],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][1][2,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[C][1][2,11]*r[I][4][11,0]
        hv += g[dei(p[I,1],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][1][2,11]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B9C3I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,9),(C,3),(I,11)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,1],p[C,0])]*r[A][9][0,1]*r[C][1][3,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,1],p[C,0])]*r[A][39][0,1]*r[C][1][3,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[A,0],p[C,0],p[I,1],p[A,0])]*r[A][9][0,1]*r[C][1][3,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[A,1],p[C,0],p[I,1],p[A,1])]*r[A][39][0,1]*r[C][1][3,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,0],p[C,0])]*r[A][9][0,1]*r[C][1][3,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,1],p[C,0])]*r[A][39][0,1]*r[C][1][3,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[C][1][3,11]*r[I][4][11,0]
        hv += g[dei(p[I,1],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][1][3,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[C][1][3,11]*r[I][4][11,0]
        hv += g[dei(p[I,1],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][1][3,11]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B9C4I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,9),(C,4),(I,13)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,1],p[C,0])]*r[A][24][0,1]*r[C][3][4,11]*r[I][6][13,0]
        hv += g[dei(p[A,0],p[A,0],p[I,1],p[C,0])]*r[A][9][0,1]*r[C][3][4,11]*r[I][6][13,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,1],p[C,0])]*r[A][54][0,1]*r[C][3][4,11]*r[I][6][13,0]
        hv += g[dei(p[A,1],p[A,1],p[I,1],p[C,0])]*r[A][39][0,1]*r[C][3][4,11]*r[I][6][13,0]
        hv += -1/2*g[dei(p[A,0],p[C,0],p[I,1],p[A,0])]*r[A][24][0,1]*r[C][3][4,11]*r[I][6][13,0]
        hv += -1/2*g[dei(p[A,1],p[C,0],p[I,1],p[A,1])]*r[A][54][0,1]*r[C][3][4,11]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,0],p[C,0])]*r[A][24][0,1]*r[C][3][4,11]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,1],p[C,0])]*r[A][54][0,1]*r[C][3][4,11]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][3][4,11]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][3][4,11]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B9I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,9),(I,11)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,1],p[C,1])]*r[A][9][0,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,1],p[C,1])]*r[A][39][0,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[A,0],p[C,1],p[I,1],p[A,0])]*r[A][9][0,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[A,1],p[C,1],p[I,1],p[A,1])]*r[A][39][0,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,0],p[C,1])]*r[A][9][0,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,1],p[C,1])]*r[A][39][0,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += g[dei(p[I,1],p[C,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += g[dei(p[I,1],p[C,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][5][0,11]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B9C1I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,9),(C,1),(I,11)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,1],p[C,1])]*r[A][9][0,1]*r[C][5][1,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,1],p[C,1])]*r[A][39][0,1]*r[C][5][1,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[A,0],p[C,1],p[I,1],p[A,0])]*r[A][9][0,1]*r[C][5][1,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[A,1],p[C,1],p[I,1],p[A,1])]*r[A][39][0,1]*r[C][5][1,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,0],p[C,1])]*r[A][9][0,1]*r[C][5][1,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,1],p[C,1])]*r[A][39][0,1]*r[C][5][1,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[C][5][1,11]*r[I][4][11,0]
        hv += g[dei(p[I,1],p[C,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][5][1,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[C][5][1,11]*r[I][4][11,0]
        hv += g[dei(p[I,1],p[C,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][5][1,11]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B9I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,2),(B,9),(I,11)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,1],p[C,1])]*r[A][15][2,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,1],p[C,1])]*r[A][33][2,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[A,0],p[C,1],p[I,1],p[A,1])]*r[A][15][2,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[A,1],p[C,1],p[I,1],p[A,0])]*r[A][33][2,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,0],p[C,1])]*r[A][15][2,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,1],p[C,1])]*r[A][33][2,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[A,0],p[A,1])]*r[A][15][2,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += g[dei(p[I,1],p[C,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[A,1],p[A,0])]*r[A][33][2,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += g[dei(p[I,1],p[C,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[C][5][0,11]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B9I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,9),(I,11)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,1],p[C,1])]*r[A][15][3,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,1],p[C,1])]*r[A][33][3,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[A,0],p[C,1],p[I,1],p[A,1])]*r[A][15][3,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[A,1],p[C,1],p[I,1],p[A,0])]*r[A][33][3,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,0],p[C,1])]*r[A][15][3,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,1],p[C,1])]*r[A][33][3,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[A,0],p[A,1])]*r[A][15][3,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += g[dei(p[I,1],p[C,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[A,1],p[A,0])]*r[A][33][3,1]*r[C][5][0,11]*r[I][4][11,0]
        hv += g[dei(p[I,1],p[C,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[C][5][0,11]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A4B9I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,4),(B,9),(I,14)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[A,0],p[C,1],p[I,0],p[A,1])]*r[A][18][4,1]*r[C][5][0,11]*r[I][2][14,0]
        hv += -1*g[dei(p[A,1],p[C,1],p[I,0],p[A,0])]*r[A][36][4,1]*r[C][5][0,11]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A4B9I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,4),(B,9),(I,13)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[A,0],p[C,1],p[I,1],p[A,1])]*r[A][18][4,1]*r[C][5][0,11]*r[I][6][13,0]
        hv += -1*g[dei(p[A,1],p[C,1],p[I,1],p[A,0])]*r[A][36][4,1]*r[C][5][0,11]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B9I1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(B,9),(I,1)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += -1/2*g[dei(p[A,0],p[C,1],p[I,0],p[I,0])]*r[A][0][12,1]*r[C][5][0,11]*r[I][9][1,0]
        hv += -1*g[dei(p[A,0],p[C,1],p[I,0],p[I,0])]*r[A][0][12,1]*r[C][5][0,11]*r[I][24][1,0]
        hv += -1/2*g[dei(p[A,0],p[C,1],p[I,1],p[I,1])]*r[A][0][12,1]*r[C][5][0,11]*r[I][39][1,0]
        hv += -1*g[dei(p[A,0],p[C,1],p[I,1],p[I,1])]*r[A][0][12,1]*r[C][5][0,11]*r[I][54][1,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[I,0],p[C,1])]*r[A][0][12,1]*r[C][5][0,11]*r[I][9][1,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[I,1],p[C,1])]*r[A][0][12,1]*r[C][5][0,11]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[A,0],p[I,0])]*r[A][0][12,1]*r[C][5][0,11]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[A,0],p[I,1])]*r[A][0][12,1]*r[C][5][0,11]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[A,0],p[C,1])]*r[A][0][12,1]*r[C][5][0,11]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[A,0],p[C,1])]*r[A][0][12,1]*r[C][5][0,11]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B9I2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(B,9),(I,2)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += -1/2*g[dei(p[A,0],p[C,1],p[I,0],p[I,1])]*r[A][0][12,1]*r[C][5][0,11]*r[I][15][2,0]
        hv += -1*g[dei(p[A,0],p[C,1],p[I,0],p[I,1])]*r[A][0][12,1]*r[C][5][0,11]*r[I][30][2,0]
        hv += -1/2*g[dei(p[A,0],p[C,1],p[I,1],p[I,0])]*r[A][0][12,1]*r[C][5][0,11]*r[I][33][2,0]
        hv += -1*g[dei(p[A,0],p[C,1],p[I,1],p[I,0])]*r[A][0][12,1]*r[C][5][0,11]*r[I][48][2,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[I,0],p[C,1])]*r[A][0][12,1]*r[C][5][0,11]*r[I][15][2,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[I,1],p[C,1])]*r[A][0][12,1]*r[C][5][0,11]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[A,0],p[I,1])]*r[A][0][12,1]*r[C][5][0,11]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[A,0],p[I,0])]*r[A][0][12,1]*r[C][5][0,11]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,0],p[C,1])]*r[A][0][12,1]*r[C][5][0,11]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,0],p[C,1])]*r[A][0][12,1]*r[C][5][0,11]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B9I3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(B,9),(I,3)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += -1/2*g[dei(p[A,0],p[C,1],p[I,0],p[I,1])]*r[A][0][12,1]*r[C][5][0,11]*r[I][15][3,0]
        hv += -1*g[dei(p[A,0],p[C,1],p[I,0],p[I,1])]*r[A][0][12,1]*r[C][5][0,11]*r[I][30][3,0]
        hv += -1/2*g[dei(p[A,0],p[C,1],p[I,1],p[I,0])]*r[A][0][12,1]*r[C][5][0,11]*r[I][33][3,0]
        hv += -1*g[dei(p[A,0],p[C,1],p[I,1],p[I,0])]*r[A][0][12,1]*r[C][5][0,11]*r[I][48][3,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[I,0],p[C,1])]*r[A][0][12,1]*r[C][5][0,11]*r[I][15][3,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[I,1],p[C,1])]*r[A][0][12,1]*r[C][5][0,11]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[A,0],p[I,1])]*r[A][0][12,1]*r[C][5][0,11]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[A,0],p[I,0])]*r[A][0][12,1]*r[C][5][0,11]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,0],p[C,1])]*r[A][0][12,1]*r[C][5][0,11]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,0],p[C,1])]*r[A][0][12,1]*r[C][5][0,11]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B9I1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(B,9),(I,1)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += -1/2*g[dei(p[A,1],p[C,1],p[I,0],p[I,0])]*r[A][4][11,1]*r[C][5][0,11]*r[I][9][1,0]
        hv += -1*g[dei(p[A,1],p[C,1],p[I,0],p[I,0])]*r[A][4][11,1]*r[C][5][0,11]*r[I][24][1,0]
        hv += -1/2*g[dei(p[A,1],p[C,1],p[I,1],p[I,1])]*r[A][4][11,1]*r[C][5][0,11]*r[I][39][1,0]
        hv += -1*g[dei(p[A,1],p[C,1],p[I,1],p[I,1])]*r[A][4][11,1]*r[C][5][0,11]*r[I][54][1,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,0],p[C,1])]*r[A][4][11,1]*r[C][5][0,11]*r[I][9][1,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,1],p[C,1])]*r[A][4][11,1]*r[C][5][0,11]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[A,1],p[I,0])]*r[A][4][11,1]*r[C][5][0,11]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[A,1],p[I,1])]*r[A][4][11,1]*r[C][5][0,11]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[A,1],p[C,1])]*r[A][4][11,1]*r[C][5][0,11]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[A,1],p[C,1])]*r[A][4][11,1]*r[C][5][0,11]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B9I2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(B,9),(I,2)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += -1/2*g[dei(p[A,1],p[C,1],p[I,0],p[I,1])]*r[A][4][11,1]*r[C][5][0,11]*r[I][15][2,0]
        hv += -1*g[dei(p[A,1],p[C,1],p[I,0],p[I,1])]*r[A][4][11,1]*r[C][5][0,11]*r[I][30][2,0]
        hv += -1/2*g[dei(p[A,1],p[C,1],p[I,1],p[I,0])]*r[A][4][11,1]*r[C][5][0,11]*r[I][33][2,0]
        hv += -1*g[dei(p[A,1],p[C,1],p[I,1],p[I,0])]*r[A][4][11,1]*r[C][5][0,11]*r[I][48][2,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,0],p[C,1])]*r[A][4][11,1]*r[C][5][0,11]*r[I][15][2,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,1],p[C,1])]*r[A][4][11,1]*r[C][5][0,11]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[A,1],p[I,1])]*r[A][4][11,1]*r[C][5][0,11]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[A,1],p[I,0])]*r[A][4][11,1]*r[C][5][0,11]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,1],p[C,1])]*r[A][4][11,1]*r[C][5][0,11]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,1],p[C,1])]*r[A][4][11,1]*r[C][5][0,11]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B9I3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(B,9),(I,3)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += -1/2*g[dei(p[A,1],p[C,1],p[I,0],p[I,1])]*r[A][4][11,1]*r[C][5][0,11]*r[I][15][3,0]
        hv += -1*g[dei(p[A,1],p[C,1],p[I,0],p[I,1])]*r[A][4][11,1]*r[C][5][0,11]*r[I][30][3,0]
        hv += -1/2*g[dei(p[A,1],p[C,1],p[I,1],p[I,0])]*r[A][4][11,1]*r[C][5][0,11]*r[I][33][3,0]
        hv += -1*g[dei(p[A,1],p[C,1],p[I,1],p[I,0])]*r[A][4][11,1]*r[C][5][0,11]*r[I][48][3,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,0],p[C,1])]*r[A][4][11,1]*r[C][5][0,11]*r[I][15][3,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,1],p[C,1])]*r[A][4][11,1]*r[C][5][0,11]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[A,1],p[I,1])]*r[A][4][11,1]*r[C][5][0,11]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[A,1],p[I,0])]*r[A][4][11,1]*r[C][5][0,11]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,1],p[C,1])]*r[A][4][11,1]*r[C][5][0,11]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,1],p[C,1])]*r[A][4][11,1]*r[C][5][0,11]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B9I4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(B,9),(I,4)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += g[dei(p[I,0],p[C,1],p[A,0],p[I,1])]*r[A][2][14,1]*r[C][5][0,11]*r[I][18][4,0]
        hv += g[dei(p[I,1],p[C,1],p[A,0],p[I,0])]*r[A][2][14,1]*r[C][5][0,11]*r[I][36][4,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B9I4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(B,9),(I,4)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += g[dei(p[I,0],p[C,1],p[A,1],p[I,1])]*r[A][6][13,1]*r[C][5][0,11]*r[I][18][4,0]
        hv += g[dei(p[I,1],p[C,1],p[A,1],p[I,0])]*r[A][6][13,1]*r[C][5][0,11]*r[I][36][4,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B9I15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(B,9),(I,15)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += -1*g[dei(p[I,0],p[C,1],p[I,0],p[A,0])]*r[A][3][7,1]*r[C][5][0,11]*r[I][11][15,0]
        hv += -1*g[dei(p[I,1],p[C,1],p[I,1],p[A,0])]*r[A][3][7,1]*r[C][5][0,11]*r[I][41][15,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B9I15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(B,9),(I,15)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += -1*g[dei(p[I,0],p[C,1],p[I,0],p[A,1])]*r[A][7][8,1]*r[C][5][0,11]*r[I][11][15,0]
        hv += -1*g[dei(p[I,1],p[C,1],p[I,1],p[A,1])]*r[A][7][8,1]*r[C][5][0,11]*r[I][41][15,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B11I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,11),(I,9)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[B,0],p[C,1],p[B,1],p[I,0])]*r[B][14][11,9]*r[C][5][0,11]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,1],p[C,1],p[B,0],p[I,0])]*r[B][32][11,9]*r[C][5][0,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[B,1],p[C,1])]*r[B][14][11,9]*r[C][5][0,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,1],p[I,0],p[B,0],p[C,1])]*r[B][32][11,9]*r[C][5][0,11]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B13I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,13),(I,7)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[B,0],p[C,1],p[B,1],p[I,0])]*r[B][17][13,9]*r[C][5][0,11]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B11I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,11),(I,10)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[B,0],p[C,1],p[B,1],p[I,1])]*r[B][14][11,9]*r[C][5][0,11]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,1],p[C,1],p[B,0],p[I,1])]*r[B][32][11,9]*r[C][5][0,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[B,1],p[C,1])]*r[B][14][11,9]*r[C][5][0,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,1],p[I,1],p[B,0],p[C,1])]*r[B][32][11,9]*r[C][5][0,11]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B13I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,13),(I,8)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[B,0],p[C,1],p[B,1],p[I,1])]*r[B][17][13,9]*r[C][5][0,11]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B14I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,14),(I,7)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[B,1],p[C,1],p[B,1],p[I,0])]*r[B][41][14,9]*r[C][5][0,11]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B14I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,14),(I,8)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[B,1],p[C,1],p[B,1],p[I,1])]*r[B][41][14,9]*r[C][5][0,11]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C14I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,14),(I,7)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1*g[dei(p[B,0],p[C,0],p[C,1],p[I,0])]*r[B][0][0,9]*r[C][45][14,11]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C14I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,14),(I,8)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1*g[dei(p[B,0],p[C,0],p[C,1],p[I,1])]*r[B][0][0,9]*r[C][45][14,11]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C13I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,13),(I,7)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1*g[dei(p[B,0],p[C,1],p[C,1],p[I,0])]*r[B][0][0,9]*r[C][51][13,11]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C13I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,13),(I,8)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1*g[dei(p[B,0],p[C,1],p[C,1],p[I,1])]*r[B][0][0,9]*r[C][51][13,11]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C12I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,12),(I,9)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += g[dei(p[B,0],p[I,0],p[C,1],p[C,0])]*r[B][0][0,9]*r[C][48][12,11]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C12I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,12),(I,10)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += g[dei(p[B,0],p[I,1],p[C,1],p[C,0])]*r[B][0][0,9]*r[C][48][12,11]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C15I6(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,15),(I,6)]))
        hv = 0.0
        
        hv += -1*g[dei(p[B,0],p[I,0],p[C,1],p[I,0])]*r[B][0][0,9]*r[C][6][15,11]*r[I][22][6,0]
        hv += -1*g[dei(p[B,0],p[I,1],p[C,1],p[I,1])]*r[B][0][0,9]*r[C][6][15,11]*r[I][52][6,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B7I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,7),(I,14)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[B,0],p[C,1],p[I,0],p[B,0])]*r[B][12][7,9]*r[C][5][0,11]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B7I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,7),(I,13)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[B,0],p[C,1],p[I,1],p[B,0])]*r[B][12][7,9]*r[C][5][0,11]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B8I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,8),(I,14)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[B,1],p[C,1],p[I,0],p[B,0])]*r[B][36][8,9]*r[C][5][0,11]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B8I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,8),(I,13)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[B,1],p[C,1],p[I,1],p[B,0])]*r[B][36][8,9]*r[C][5][0,11]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C8I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,8),(I,14)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += g[dei(p[B,0],p[C,0],p[I,0],p[C,0])]*r[B][0][0,9]*r[C][22][8,11]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C9I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,9),(I,12)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[B,0],p[C,0],p[I,0],p[C,1])]*r[B][0][0,9]*r[C][34][9,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[B,0],p[C,1],p[I,0],p[C,0])]*r[B][0][0,9]*r[C][16][9,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][34][9,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[B,0],p[C,0])]*r[B][0][0,9]*r[C][16][9,11]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C7I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,7),(I,14)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += g[dei(p[B,0],p[C,1],p[I,0],p[C,0])]*r[B][0][0,9]*r[C][28][7,11]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C8I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,8),(I,13)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += g[dei(p[B,0],p[C,0],p[I,1],p[C,0])]*r[B][0][0,9]*r[C][22][8,11]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C9I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,9),(I,11)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[B,0],p[C,0],p[I,1],p[C,1])]*r[B][0][0,9]*r[C][34][9,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[B,0],p[C,1],p[I,1],p[C,0])]*r[B][0][0,9]*r[C][16][9,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][34][9,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[B,0],p[C,0])]*r[B][0][0,9]*r[C][16][9,11]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C7I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,7),(I,13)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += g[dei(p[B,0],p[C,1],p[I,1],p[C,0])]*r[B][0][0,9]*r[C][28][7,11]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C2I1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,2),(I,1)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,0],p[C,0],p[I,0],p[I,0])]*r[B][0][0,9]*r[C][1][2,11]*r[I][9][1,0]
        hv += -1*g[dei(p[B,0],p[C,0],p[I,0],p[I,0])]*r[B][0][0,9]*r[C][1][2,11]*r[I][24][1,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[I,1],p[I,1])]*r[B][0][0,9]*r[C][1][2,11]*r[I][39][1,0]
        hv += -1*g[dei(p[B,0],p[C,0],p[I,1],p[I,1])]*r[B][0][0,9]*r[C][1][2,11]*r[I][54][1,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[I,0],p[C,0])]*r[B][0][0,9]*r[C][1][2,11]*r[I][9][1,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[I,1],p[C,0])]*r[B][0][0,9]*r[C][1][2,11]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[B,0],p[I,0])]*r[B][0][0,9]*r[C][1][2,11]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[B,0],p[I,1])]*r[B][0][0,9]*r[C][1][2,11]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[B,0],p[C,0])]*r[B][0][0,9]*r[C][1][2,11]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[B,0],p[C,0])]*r[B][0][0,9]*r[C][1][2,11]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C3I1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,3),(I,1)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,0],p[C,0],p[I,0],p[I,0])]*r[B][0][0,9]*r[C][1][3,11]*r[I][9][1,0]
        hv += -1*g[dei(p[B,0],p[C,0],p[I,0],p[I,0])]*r[B][0][0,9]*r[C][1][3,11]*r[I][24][1,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[I,1],p[I,1])]*r[B][0][0,9]*r[C][1][3,11]*r[I][39][1,0]
        hv += -1*g[dei(p[B,0],p[C,0],p[I,1],p[I,1])]*r[B][0][0,9]*r[C][1][3,11]*r[I][54][1,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[I,0],p[C,0])]*r[B][0][0,9]*r[C][1][3,11]*r[I][9][1,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[I,1],p[C,0])]*r[B][0][0,9]*r[C][1][3,11]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[B,0],p[I,0])]*r[B][0][0,9]*r[C][1][3,11]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[B,0],p[I,1])]*r[B][0][0,9]*r[C][1][3,11]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[B,0],p[C,0])]*r[B][0][0,9]*r[C][1][3,11]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[B,0],p[C,0])]*r[B][0][0,9]*r[C][1][3,11]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C2I2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,2),(I,2)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,0],p[C,0],p[I,0],p[I,1])]*r[B][0][0,9]*r[C][1][2,11]*r[I][15][2,0]
        hv += -1*g[dei(p[B,0],p[C,0],p[I,0],p[I,1])]*r[B][0][0,9]*r[C][1][2,11]*r[I][30][2,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[I,1],p[I,0])]*r[B][0][0,9]*r[C][1][2,11]*r[I][33][2,0]
        hv += -1*g[dei(p[B,0],p[C,0],p[I,1],p[I,0])]*r[B][0][0,9]*r[C][1][2,11]*r[I][48][2,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[I,0],p[C,0])]*r[B][0][0,9]*r[C][1][2,11]*r[I][15][2,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[I,1],p[C,0])]*r[B][0][0,9]*r[C][1][2,11]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[B,0],p[I,1])]*r[B][0][0,9]*r[C][1][2,11]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[B,0],p[I,0])]*r[B][0][0,9]*r[C][1][2,11]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,0],p[C,0])]*r[B][0][0,9]*r[C][1][2,11]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,0],p[C,0])]*r[B][0][0,9]*r[C][1][2,11]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C2I3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,2),(I,3)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,0],p[C,0],p[I,0],p[I,1])]*r[B][0][0,9]*r[C][1][2,11]*r[I][15][3,0]
        hv += -1*g[dei(p[B,0],p[C,0],p[I,0],p[I,1])]*r[B][0][0,9]*r[C][1][2,11]*r[I][30][3,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[I,1],p[I,0])]*r[B][0][0,9]*r[C][1][2,11]*r[I][33][3,0]
        hv += -1*g[dei(p[B,0],p[C,0],p[I,1],p[I,0])]*r[B][0][0,9]*r[C][1][2,11]*r[I][48][3,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[I,0],p[C,0])]*r[B][0][0,9]*r[C][1][2,11]*r[I][15][3,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[I,1],p[C,0])]*r[B][0][0,9]*r[C][1][2,11]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[B,0],p[I,1])]*r[B][0][0,9]*r[C][1][2,11]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[B,0],p[I,0])]*r[B][0][0,9]*r[C][1][2,11]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,0],p[C,0])]*r[B][0][0,9]*r[C][1][2,11]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,0],p[C,0])]*r[B][0][0,9]*r[C][1][2,11]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C3I2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,3),(I,2)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,0],p[C,0],p[I,0],p[I,1])]*r[B][0][0,9]*r[C][1][3,11]*r[I][15][2,0]
        hv += -1*g[dei(p[B,0],p[C,0],p[I,0],p[I,1])]*r[B][0][0,9]*r[C][1][3,11]*r[I][30][2,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[I,1],p[I,0])]*r[B][0][0,9]*r[C][1][3,11]*r[I][33][2,0]
        hv += -1*g[dei(p[B,0],p[C,0],p[I,1],p[I,0])]*r[B][0][0,9]*r[C][1][3,11]*r[I][48][2,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[I,0],p[C,0])]*r[B][0][0,9]*r[C][1][3,11]*r[I][15][2,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[I,1],p[C,0])]*r[B][0][0,9]*r[C][1][3,11]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[B,0],p[I,1])]*r[B][0][0,9]*r[C][1][3,11]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[B,0],p[I,0])]*r[B][0][0,9]*r[C][1][3,11]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,0],p[C,0])]*r[B][0][0,9]*r[C][1][3,11]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,0],p[C,0])]*r[B][0][0,9]*r[C][1][3,11]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C3I3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,3),(I,3)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,0],p[C,0],p[I,0],p[I,1])]*r[B][0][0,9]*r[C][1][3,11]*r[I][15][3,0]
        hv += -1*g[dei(p[B,0],p[C,0],p[I,0],p[I,1])]*r[B][0][0,9]*r[C][1][3,11]*r[I][30][3,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[I,1],p[I,0])]*r[B][0][0,9]*r[C][1][3,11]*r[I][33][3,0]
        hv += -1*g[dei(p[B,0],p[C,0],p[I,1],p[I,0])]*r[B][0][0,9]*r[C][1][3,11]*r[I][48][3,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[I,0],p[C,0])]*r[B][0][0,9]*r[C][1][3,11]*r[I][15][3,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[I,1],p[C,0])]*r[B][0][0,9]*r[C][1][3,11]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[B,0],p[I,1])]*r[B][0][0,9]*r[C][1][3,11]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[B,0],p[I,0])]*r[B][0][0,9]*r[C][1][3,11]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,0],p[C,0])]*r[B][0][0,9]*r[C][1][3,11]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,0],p[C,0])]*r[B][0][0,9]*r[C][1][3,11]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(I,1)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,0],p[C,1],p[I,0],p[I,0])]*r[B][0][0,9]*r[C][5][0,11]*r[I][9][1,0]
        hv += -1*g[dei(p[B,0],p[C,1],p[I,0],p[I,0])]*r[B][0][0,9]*r[C][5][0,11]*r[I][24][1,0]
        hv += -1/2*g[dei(p[B,0],p[C,1],p[I,1],p[I,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][39][1,0]
        hv += -1*g[dei(p[B,0],p[C,1],p[I,1],p[I,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][54][1,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[I,0],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][9][1,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[I,1],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[B,0],p[I,0])]*r[B][0][0,9]*r[C][5][0,11]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[B,0],p[I,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C1I1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,1),(I,1)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,0],p[C,1],p[I,0],p[I,0])]*r[B][0][0,9]*r[C][5][1,11]*r[I][9][1,0]
        hv += -1*g[dei(p[B,0],p[C,1],p[I,0],p[I,0])]*r[B][0][0,9]*r[C][5][1,11]*r[I][24][1,0]
        hv += -1/2*g[dei(p[B,0],p[C,1],p[I,1],p[I,1])]*r[B][0][0,9]*r[C][5][1,11]*r[I][39][1,0]
        hv += -1*g[dei(p[B,0],p[C,1],p[I,1],p[I,1])]*r[B][0][0,9]*r[C][5][1,11]*r[I][54][1,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[I,0],p[C,1])]*r[B][0][0,9]*r[C][5][1,11]*r[I][9][1,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[I,1],p[C,1])]*r[B][0][0,9]*r[C][5][1,11]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[B,0],p[I,0])]*r[B][0][0,9]*r[C][5][1,11]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[B,0],p[I,1])]*r[B][0][0,9]*r[C][5][1,11]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][5][1,11]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][5][1,11]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B1I1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,1),(I,1)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,0],p[C,1],p[I,0],p[I,0])]*r[B][0][1,9]*r[C][5][0,11]*r[I][9][1,0]
        hv += -1*g[dei(p[B,0],p[C,1],p[I,0],p[I,0])]*r[B][0][1,9]*r[C][5][0,11]*r[I][24][1,0]
        hv += -1/2*g[dei(p[B,0],p[C,1],p[I,1],p[I,1])]*r[B][0][1,9]*r[C][5][0,11]*r[I][39][1,0]
        hv += -1*g[dei(p[B,0],p[C,1],p[I,1],p[I,1])]*r[B][0][1,9]*r[C][5][0,11]*r[I][54][1,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[I,0],p[C,1])]*r[B][0][1,9]*r[C][5][0,11]*r[I][9][1,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[I,1],p[C,1])]*r[B][0][1,9]*r[C][5][0,11]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[B,0],p[I,0])]*r[B][0][1,9]*r[C][5][0,11]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[B,0],p[I,1])]*r[B][0][1,9]*r[C][5][0,11]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[B,0],p[C,1])]*r[B][0][1,9]*r[C][5][0,11]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[B,0],p[C,1])]*r[B][0][1,9]*r[C][5][0,11]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(I,2)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,0],p[C,1],p[I,0],p[I,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][15][2,0]
        hv += -1*g[dei(p[B,0],p[C,1],p[I,0],p[I,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][30][2,0]
        hv += -1/2*g[dei(p[B,0],p[C,1],p[I,1],p[I,0])]*r[B][0][0,9]*r[C][5][0,11]*r[I][33][2,0]
        hv += -1*g[dei(p[B,0],p[C,1],p[I,1],p[I,0])]*r[B][0][0,9]*r[C][5][0,11]*r[I][48][2,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[I,0],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][15][2,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[I,1],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[B,0],p[I,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[B,0],p[I,0])]*r[B][0][0,9]*r[C][5][0,11]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(I,3)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,0],p[C,1],p[I,0],p[I,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][15][3,0]
        hv += -1*g[dei(p[B,0],p[C,1],p[I,0],p[I,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][30][3,0]
        hv += -1/2*g[dei(p[B,0],p[C,1],p[I,1],p[I,0])]*r[B][0][0,9]*r[C][5][0,11]*r[I][33][3,0]
        hv += -1*g[dei(p[B,0],p[C,1],p[I,1],p[I,0])]*r[B][0][0,9]*r[C][5][0,11]*r[I][48][3,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[I,0],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][15][3,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[I,1],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[B,0],p[I,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[B,0],p[I,0])]*r[B][0][0,9]*r[C][5][0,11]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C1I2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,1),(I,2)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,0],p[C,1],p[I,0],p[I,1])]*r[B][0][0,9]*r[C][5][1,11]*r[I][15][2,0]
        hv += -1*g[dei(p[B,0],p[C,1],p[I,0],p[I,1])]*r[B][0][0,9]*r[C][5][1,11]*r[I][30][2,0]
        hv += -1/2*g[dei(p[B,0],p[C,1],p[I,1],p[I,0])]*r[B][0][0,9]*r[C][5][1,11]*r[I][33][2,0]
        hv += -1*g[dei(p[B,0],p[C,1],p[I,1],p[I,0])]*r[B][0][0,9]*r[C][5][1,11]*r[I][48][2,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[I,0],p[C,1])]*r[B][0][0,9]*r[C][5][1,11]*r[I][15][2,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[I,1],p[C,1])]*r[B][0][0,9]*r[C][5][1,11]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[B,0],p[I,1])]*r[B][0][0,9]*r[C][5][1,11]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[B,0],p[I,0])]*r[B][0][0,9]*r[C][5][1,11]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][5][1,11]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][5][1,11]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C1I3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,1),(I,3)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,0],p[C,1],p[I,0],p[I,1])]*r[B][0][0,9]*r[C][5][1,11]*r[I][15][3,0]
        hv += -1*g[dei(p[B,0],p[C,1],p[I,0],p[I,1])]*r[B][0][0,9]*r[C][5][1,11]*r[I][30][3,0]
        hv += -1/2*g[dei(p[B,0],p[C,1],p[I,1],p[I,0])]*r[B][0][0,9]*r[C][5][1,11]*r[I][33][3,0]
        hv += -1*g[dei(p[B,0],p[C,1],p[I,1],p[I,0])]*r[B][0][0,9]*r[C][5][1,11]*r[I][48][3,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[I,0],p[C,1])]*r[B][0][0,9]*r[C][5][1,11]*r[I][15][3,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[I,1],p[C,1])]*r[B][0][0,9]*r[C][5][1,11]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[B,0],p[I,1])]*r[B][0][0,9]*r[C][5][1,11]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[B,0],p[I,0])]*r[B][0][0,9]*r[C][5][1,11]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][5][1,11]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][5][1,11]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B1I2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,1),(I,2)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,0],p[C,1],p[I,0],p[I,1])]*r[B][0][1,9]*r[C][5][0,11]*r[I][15][2,0]
        hv += -1*g[dei(p[B,0],p[C,1],p[I,0],p[I,1])]*r[B][0][1,9]*r[C][5][0,11]*r[I][30][2,0]
        hv += -1/2*g[dei(p[B,0],p[C,1],p[I,1],p[I,0])]*r[B][0][1,9]*r[C][5][0,11]*r[I][33][2,0]
        hv += -1*g[dei(p[B,0],p[C,1],p[I,1],p[I,0])]*r[B][0][1,9]*r[C][5][0,11]*r[I][48][2,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[I,0],p[C,1])]*r[B][0][1,9]*r[C][5][0,11]*r[I][15][2,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[I,1],p[C,1])]*r[B][0][1,9]*r[C][5][0,11]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[B,0],p[I,1])]*r[B][0][1,9]*r[C][5][0,11]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[B,0],p[I,0])]*r[B][0][1,9]*r[C][5][0,11]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,0],p[C,1])]*r[B][0][1,9]*r[C][5][0,11]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,0],p[C,1])]*r[B][0][1,9]*r[C][5][0,11]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B1I3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,1),(I,3)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,0],p[C,1],p[I,0],p[I,1])]*r[B][0][1,9]*r[C][5][0,11]*r[I][15][3,0]
        hv += -1*g[dei(p[B,0],p[C,1],p[I,0],p[I,1])]*r[B][0][1,9]*r[C][5][0,11]*r[I][30][3,0]
        hv += -1/2*g[dei(p[B,0],p[C,1],p[I,1],p[I,0])]*r[B][0][1,9]*r[C][5][0,11]*r[I][33][3,0]
        hv += -1*g[dei(p[B,0],p[C,1],p[I,1],p[I,0])]*r[B][0][1,9]*r[C][5][0,11]*r[I][48][3,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[I,0],p[C,1])]*r[B][0][1,9]*r[C][5][0,11]*r[I][15][3,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[I,1],p[C,1])]*r[B][0][1,9]*r[C][5][0,11]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[B,0],p[I,1])]*r[B][0][1,9]*r[C][5][0,11]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[B,0],p[I,0])]*r[B][0][1,9]*r[C][5][0,11]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,0],p[C,1])]*r[B][0][1,9]*r[C][5][0,11]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,0],p[C,1])]*r[B][0][1,9]*r[C][5][0,11]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B2I1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,2),(I,1)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,1],p[C,1],p[I,0],p[I,0])]*r[B][4][2,9]*r[C][5][0,11]*r[I][9][1,0]
        hv += -1*g[dei(p[B,1],p[C,1],p[I,0],p[I,0])]*r[B][4][2,9]*r[C][5][0,11]*r[I][24][1,0]
        hv += -1/2*g[dei(p[B,1],p[C,1],p[I,1],p[I,1])]*r[B][4][2,9]*r[C][5][0,11]*r[I][39][1,0]
        hv += -1*g[dei(p[B,1],p[C,1],p[I,1],p[I,1])]*r[B][4][2,9]*r[C][5][0,11]*r[I][54][1,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[I,0],p[C,1])]*r[B][4][2,9]*r[C][5][0,11]*r[I][9][1,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[I,1],p[C,1])]*r[B][4][2,9]*r[C][5][0,11]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[B,1],p[I,0])]*r[B][4][2,9]*r[C][5][0,11]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[B,1],p[I,1])]*r[B][4][2,9]*r[C][5][0,11]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[B,1],p[C,1])]*r[B][4][2,9]*r[C][5][0,11]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[B,1],p[C,1])]*r[B][4][2,9]*r[C][5][0,11]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B3I1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,3),(I,1)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,1],p[C,1],p[I,0],p[I,0])]*r[B][4][3,9]*r[C][5][0,11]*r[I][9][1,0]
        hv += -1*g[dei(p[B,1],p[C,1],p[I,0],p[I,0])]*r[B][4][3,9]*r[C][5][0,11]*r[I][24][1,0]
        hv += -1/2*g[dei(p[B,1],p[C,1],p[I,1],p[I,1])]*r[B][4][3,9]*r[C][5][0,11]*r[I][39][1,0]
        hv += -1*g[dei(p[B,1],p[C,1],p[I,1],p[I,1])]*r[B][4][3,9]*r[C][5][0,11]*r[I][54][1,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[I,0],p[C,1])]*r[B][4][3,9]*r[C][5][0,11]*r[I][9][1,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[I,1],p[C,1])]*r[B][4][3,9]*r[C][5][0,11]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[B,1],p[I,0])]*r[B][4][3,9]*r[C][5][0,11]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[B,1],p[I,1])]*r[B][4][3,9]*r[C][5][0,11]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[B,1],p[C,1])]*r[B][4][3,9]*r[C][5][0,11]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[B,1],p[C,1])]*r[B][4][3,9]*r[C][5][0,11]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B2I2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,2),(I,2)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,1],p[C,1],p[I,0],p[I,1])]*r[B][4][2,9]*r[C][5][0,11]*r[I][15][2,0]
        hv += -1*g[dei(p[B,1],p[C,1],p[I,0],p[I,1])]*r[B][4][2,9]*r[C][5][0,11]*r[I][30][2,0]
        hv += -1/2*g[dei(p[B,1],p[C,1],p[I,1],p[I,0])]*r[B][4][2,9]*r[C][5][0,11]*r[I][33][2,0]
        hv += -1*g[dei(p[B,1],p[C,1],p[I,1],p[I,0])]*r[B][4][2,9]*r[C][5][0,11]*r[I][48][2,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[I,0],p[C,1])]*r[B][4][2,9]*r[C][5][0,11]*r[I][15][2,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[I,1],p[C,1])]*r[B][4][2,9]*r[C][5][0,11]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[B,1],p[I,1])]*r[B][4][2,9]*r[C][5][0,11]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[B,1],p[I,0])]*r[B][4][2,9]*r[C][5][0,11]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,1],p[C,1])]*r[B][4][2,9]*r[C][5][0,11]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,1],p[C,1])]*r[B][4][2,9]*r[C][5][0,11]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B2I3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,2),(I,3)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,1],p[C,1],p[I,0],p[I,1])]*r[B][4][2,9]*r[C][5][0,11]*r[I][15][3,0]
        hv += -1*g[dei(p[B,1],p[C,1],p[I,0],p[I,1])]*r[B][4][2,9]*r[C][5][0,11]*r[I][30][3,0]
        hv += -1/2*g[dei(p[B,1],p[C,1],p[I,1],p[I,0])]*r[B][4][2,9]*r[C][5][0,11]*r[I][33][3,0]
        hv += -1*g[dei(p[B,1],p[C,1],p[I,1],p[I,0])]*r[B][4][2,9]*r[C][5][0,11]*r[I][48][3,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[I,0],p[C,1])]*r[B][4][2,9]*r[C][5][0,11]*r[I][15][3,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[I,1],p[C,1])]*r[B][4][2,9]*r[C][5][0,11]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[B,1],p[I,1])]*r[B][4][2,9]*r[C][5][0,11]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[B,1],p[I,0])]*r[B][4][2,9]*r[C][5][0,11]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,1],p[C,1])]*r[B][4][2,9]*r[C][5][0,11]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,1],p[C,1])]*r[B][4][2,9]*r[C][5][0,11]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B3I2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,3),(I,2)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,1],p[C,1],p[I,0],p[I,1])]*r[B][4][3,9]*r[C][5][0,11]*r[I][15][2,0]
        hv += -1*g[dei(p[B,1],p[C,1],p[I,0],p[I,1])]*r[B][4][3,9]*r[C][5][0,11]*r[I][30][2,0]
        hv += -1/2*g[dei(p[B,1],p[C,1],p[I,1],p[I,0])]*r[B][4][3,9]*r[C][5][0,11]*r[I][33][2,0]
        hv += -1*g[dei(p[B,1],p[C,1],p[I,1],p[I,0])]*r[B][4][3,9]*r[C][5][0,11]*r[I][48][2,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[I,0],p[C,1])]*r[B][4][3,9]*r[C][5][0,11]*r[I][15][2,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[I,1],p[C,1])]*r[B][4][3,9]*r[C][5][0,11]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[B,1],p[I,1])]*r[B][4][3,9]*r[C][5][0,11]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[B,1],p[I,0])]*r[B][4][3,9]*r[C][5][0,11]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,1],p[C,1])]*r[B][4][3,9]*r[C][5][0,11]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,1],p[C,1])]*r[B][4][3,9]*r[C][5][0,11]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B3I3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,3),(I,3)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,1],p[C,1],p[I,0],p[I,1])]*r[B][4][3,9]*r[C][5][0,11]*r[I][15][3,0]
        hv += -1*g[dei(p[B,1],p[C,1],p[I,0],p[I,1])]*r[B][4][3,9]*r[C][5][0,11]*r[I][30][3,0]
        hv += -1/2*g[dei(p[B,1],p[C,1],p[I,1],p[I,0])]*r[B][4][3,9]*r[C][5][0,11]*r[I][33][3,0]
        hv += -1*g[dei(p[B,1],p[C,1],p[I,1],p[I,0])]*r[B][4][3,9]*r[C][5][0,11]*r[I][48][3,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[I,0],p[C,1])]*r[B][4][3,9]*r[C][5][0,11]*r[I][15][3,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[I,1],p[C,1])]*r[B][4][3,9]*r[C][5][0,11]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[B,1],p[I,1])]*r[B][4][3,9]*r[C][5][0,11]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[B,1],p[I,0])]*r[B][4][3,9]*r[C][5][0,11]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,1],p[C,1])]*r[B][4][3,9]*r[C][5][0,11]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,1],p[C,1])]*r[B][4][3,9]*r[C][5][0,11]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C4I5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,4),(I,5)]))
        hv = 0.0
        
        hv += g[dei(p[B,0],p[I,1],p[I,0],p[C,0])]*r[B][0][0,9]*r[C][3][4,11]*r[I][27][5,0]
        hv += g[dei(p[B,0],p[I,0],p[I,1],p[C,0])]*r[B][0][0,9]*r[C][3][4,11]*r[I][45][5,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B10I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,10),(I,12)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[I,0],p[C,1],p[B,1],p[B,0])]*r[B][48][10,9]*r[C][5][0,11]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B10I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,10),(I,11)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[I,1],p[C,1],p[B,1],p[B,0])]*r[B][48][10,9]*r[C][5][0,11]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B5I4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,5),(I,4)]))
        hv = 0.0
        
        hv += g[dei(p[I,0],p[C,1],p[B,1],p[I,1])]*r[B][6][5,9]*r[C][5][0,11]*r[I][18][4,0]
        hv += g[dei(p[I,1],p[C,1],p[B,1],p[I,0])]*r[B][6][5,9]*r[C][5][0,11]*r[I][36][4,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B6I15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,6),(I,15)]))
        hv = 0.0
        
        hv += -1*g[dei(p[I,0],p[C,1],p[I,0],p[B,0])]*r[B][3][6,9]*r[C][5][0,11]*r[I][11][15,0]
        hv += -1*g[dei(p[I,1],p[C,1],p[I,1],p[B,0])]*r[B][3][6,9]*r[C][5][0,11]*r[I][41][15,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A15B6C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,15),(B,6),(C,2)]))
    hv = 0.0
    
    hv += -1*g[dei(p[A,0],p[C,0],p[A,0],p[B,0])]*r[A][11][15,1]*r[B][3][6,9]*r[C][1][2,11]
    hv += -1*g[dei(p[A,1],p[C,0],p[A,1],p[B,0])]*r[A][41][15,1]*r[B][3][6,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A15B6C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,15),(B,6),(C,3)]))
    hv = 0.0
    
    hv += -1*g[dei(p[A,0],p[C,0],p[A,0],p[B,0])]*r[A][11][15,1]*r[B][3][6,9]*r[C][1][3,11]
    hv += -1*g[dei(p[A,1],p[C,0],p[A,1],p[B,0])]*r[A][41][15,1]*r[B][3][6,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A15B6(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,15),(B,6)]))
    hv = 0.0
    
    hv += -1*g[dei(p[A,0],p[C,1],p[A,0],p[B,0])]*r[A][11][15,1]*r[B][3][6,9]*r[C][5][0,11]
    hv += -1*g[dei(p[A,1],p[C,1],p[A,1],p[B,0])]*r[A][41][15,1]*r[B][3][6,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A15B6C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,15),(B,6),(C,1)]))
    hv = 0.0
    
    hv += -1*g[dei(p[A,0],p[C,1],p[A,0],p[B,0])]*r[A][11][15,1]*r[B][3][6,9]*r[C][5][1,11]
    hv += -1*g[dei(p[A,1],p[C,1],p[A,1],p[B,0])]*r[A][41][15,1]*r[B][3][6,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(C,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][9][0,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][39][0,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,0])]*r[A][9][0,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,1])]*r[A][39][0,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,0])]*r[A][9][0,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,0])]*r[A][39][0,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][0][0,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(C,3)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][9][0,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][39][0,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,0])]*r[A][9][0,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,1])]*r[A][39][0,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,0])]*r[A][9][0,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,0])]*r[A][39][0,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][0][0,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,1),(C,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][9][0,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][39][0,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,0])]*r[A][9][0,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,1])]*r[A][39][0,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,0])]*r[A][9][0,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,0])]*r[A][39][0,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][0][1,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,1),(C,3)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][9][0,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][39][0,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,0])]*r[A][9][0,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,1])]*r[A][39][0,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,0])]*r[A][9][0,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,0])]*r[A][39][0,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][0][1,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][9][0,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][39][0,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,0])]*r[A][9][0,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,1])]*r[A][39][0,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,1])]*r[A][9][0,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,1])]*r[A][39][0,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][0][0,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(C,1)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][9][0,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][39][0,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,0])]*r[A][9][0,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,1])]*r[A][39][0,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,1])]*r[A][9][0,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,1])]*r[A][39][0,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][0][0,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,1)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][9][0,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][39][0,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,0])]*r[A][9][0,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,1])]*r[A][39][0,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,1])]*r[A][9][0,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,1])]*r[A][39][0,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][0][1,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,1),(C,1)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][9][0,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][39][0,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,0])]*r[A][9][0,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,1])]*r[A][39][0,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,1])]*r[A][9][0,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,1])]*r[A][39][0,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][0][1,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(C,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][15][2,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][33][2,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,1])]*r[A][15][2,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,0])]*r[A][33][2,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,0])]*r[A][15][2,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,0])]*r[A][33][2,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][0][0,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(C,3)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][15][2,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][33][2,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,1])]*r[A][15][2,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,0])]*r[A][33][2,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,0])]*r[A][15][2,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,0])]*r[A][33][2,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][0][0,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B1C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,1),(C,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][15][2,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][33][2,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,1])]*r[A][15][2,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,0])]*r[A][33][2,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,0])]*r[A][15][2,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,0])]*r[A][33][2,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][0][1,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B1C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,1),(C,3)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][15][2,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][33][2,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,1])]*r[A][15][2,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,0])]*r[A][33][2,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,0])]*r[A][15][2,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,0])]*r[A][33][2,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][0][1,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(C,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][15][3,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][33][3,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,1])]*r[A][15][3,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,0])]*r[A][33][3,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,0])]*r[A][15][3,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,0])]*r[A][33][3,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][0][0,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][0][0,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(C,3)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][15][3,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][33][3,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,1])]*r[A][15][3,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,0])]*r[A][33][3,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,0])]*r[A][15][3,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,0])]*r[A][33][3,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][0][0,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][0][0,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B1C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,1),(C,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][15][3,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][33][3,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,1])]*r[A][15][3,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,0])]*r[A][33][3,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,0])]*r[A][15][3,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,0])]*r[A][33][3,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][0][1,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][0][1,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B1C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,1),(C,3)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][15][3,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][33][3,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,1])]*r[A][15][3,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,0])]*r[A][33][3,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,0])]*r[A][15][3,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,0])]*r[A][33][3,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][0][1,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][0][1,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][15][2,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][33][2,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,1])]*r[A][15][2,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,0])]*r[A][33][2,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,1])]*r[A][15][2,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,1])]*r[A][33][2,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][0][0,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(C,1)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][15][2,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][33][2,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,1])]*r[A][15][2,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,0])]*r[A][33][2,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,1])]*r[A][15][2,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,1])]*r[A][33][2,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][0][0,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,1)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][15][2,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][33][2,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,1])]*r[A][15][2,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,0])]*r[A][33][2,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,1])]*r[A][15][2,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,1])]*r[A][33][2,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][0][1,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B1C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,1),(C,1)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][15][2,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][33][2,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,1])]*r[A][15][2,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,0])]*r[A][33][2,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,1])]*r[A][15][2,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,1])]*r[A][33][2,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][0][1,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][15][3,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][33][3,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,1])]*r[A][15][3,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,0])]*r[A][33][3,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,1])]*r[A][15][3,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,1])]*r[A][33][3,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][0][0,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][0][0,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(C,1)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][15][3,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][33][3,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,1])]*r[A][15][3,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,0])]*r[A][33][3,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,1])]*r[A][15][3,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,1])]*r[A][33][3,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][0][0,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][0][0,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,1)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][15][3,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][33][3,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,1])]*r[A][15][3,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,0])]*r[A][33][3,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,1])]*r[A][15][3,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,1])]*r[A][33][3,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][0][1,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][0][1,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B1C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,1),(C,1)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][15][3,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][33][3,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,1])]*r[A][15][3,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,0])]*r[A][33][3,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,1])]*r[A][15][3,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,1])]*r[A][33][3,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][0][1,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][0][1,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,2),(C,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][9][0,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][39][0,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,0])]*r[A][9][0,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,1])]*r[A][39][0,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,0])]*r[A][9][0,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,0])]*r[A][39][0,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][4][2,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,2),(C,3)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][9][0,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][39][0,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,0])]*r[A][9][0,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,1])]*r[A][39][0,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,0])]*r[A][9][0,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,0])]*r[A][39][0,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][4][2,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,3),(C,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][9][0,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][39][0,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,0])]*r[A][9][0,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,1])]*r[A][39][0,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,0])]*r[A][9][0,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,0])]*r[A][39][0,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][4][3,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,3),(C,3)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][9][0,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][39][0,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,0])]*r[A][9][0,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,1])]*r[A][39][0,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,0])]*r[A][9][0,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,0])]*r[A][39][0,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][4][3,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B5C4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,5),(C,4)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][24][0,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][9][0,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][54][0,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][39][0,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,0])]*r[A][24][0,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,1])]*r[A][54][0,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,0])]*r[A][24][0,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,0])]*r[A][54][0,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][6][5,9]*r[C][3][4,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][9][0,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][39][0,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,0])]*r[A][9][0,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,1])]*r[A][39][0,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,1])]*r[A][9][0,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,1])]*r[A][39][0,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][4][2,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,2),(C,1)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][9][0,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][39][0,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,0])]*r[A][9][0,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,1])]*r[A][39][0,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,1])]*r[A][9][0,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,1])]*r[A][39][0,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][4][2,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,3)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][9][0,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][39][0,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,0])]*r[A][9][0,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,1])]*r[A][39][0,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,1])]*r[A][9][0,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,1])]*r[A][39][0,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][4][3,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,3),(C,1)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][9][0,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][39][0,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,0])]*r[A][9][0,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,1])]*r[A][39][0,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,1])]*r[A][9][0,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,1])]*r[A][39][0,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][4][3,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B2C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,2),(C,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][15][2,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][33][2,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,1])]*r[A][15][2,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,0])]*r[A][33][2,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,0])]*r[A][15][2,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,0])]*r[A][33][2,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][4][2,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B2C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,2),(C,3)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][15][2,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][33][2,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,1])]*r[A][15][2,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,0])]*r[A][33][2,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,0])]*r[A][15][2,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,0])]*r[A][33][2,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][4][2,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B3C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,3),(C,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][15][2,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][33][2,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,1])]*r[A][15][2,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,0])]*r[A][33][2,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,0])]*r[A][15][2,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,0])]*r[A][33][2,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][4][3,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B3C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,3),(C,3)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][15][2,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][33][2,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,1])]*r[A][15][2,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,0])]*r[A][33][2,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,0])]*r[A][15][2,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,0])]*r[A][33][2,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][4][3,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B2C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,2),(C,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][15][3,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][33][3,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,1])]*r[A][15][3,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,0])]*r[A][33][3,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,0])]*r[A][15][3,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,0])]*r[A][33][3,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][4][2,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][4][2,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B2C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,2),(C,3)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][15][3,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][33][3,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,1])]*r[A][15][3,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,0])]*r[A][33][3,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,0])]*r[A][15][3,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,0])]*r[A][33][3,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][4][2,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][4][2,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B3C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,3),(C,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][15][3,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][33][3,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,1])]*r[A][15][3,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,0])]*r[A][33][3,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,0])]*r[A][15][3,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,0])]*r[A][33][3,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][4][3,9]*r[C][1][2,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][4][3,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B3C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,3),(C,3)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][15][3,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][33][3,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,1])]*r[A][15][3,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,0])]*r[A][33][3,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,0])]*r[A][15][3,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,0])]*r[A][33][3,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][4][3,9]*r[C][1][3,11]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][4][3,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B5C4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,5),(C,4)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][30][2,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][15][2,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][48][2,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][33][2,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,1])]*r[A][30][2,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,0])]*r[A][48][2,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,0])]*r[A][30][2,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,0])]*r[A][48][2,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][6][5,9]*r[C][3][4,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B5C4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,5),(C,4)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][30][3,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][15][3,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][48][3,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][33][3,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,1])]*r[A][30][3,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,0])]*r[A][48][3,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,0])]*r[A][30][3,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,0])]*r[A][48][3,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][6][5,9]*r[C][3][4,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][6][5,9]*r[C][3][4,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][15][2,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][33][2,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,1])]*r[A][15][2,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,0])]*r[A][33][2,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,1])]*r[A][15][2,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,1])]*r[A][33][2,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][4][2,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B2C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,2),(C,1)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][15][2,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][33][2,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,1])]*r[A][15][2,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,0])]*r[A][33][2,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,1])]*r[A][15][2,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,1])]*r[A][33][2,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][4][2,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,3)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][15][2,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][33][2,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,1])]*r[A][15][2,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,0])]*r[A][33][2,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,1])]*r[A][15][2,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,1])]*r[A][33][2,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][4][3,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B3C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,3),(C,1)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][15][2,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][33][2,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,1])]*r[A][15][2,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,0])]*r[A][33][2,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,1])]*r[A][15][2,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,1])]*r[A][33][2,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][4][3,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][15][3,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][33][3,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,1])]*r[A][15][3,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,0])]*r[A][33][3,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,1])]*r[A][15][3,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,1])]*r[A][33][3,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][4][2,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][4][2,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B2C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,2),(C,1)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][15][3,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][33][3,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,1])]*r[A][15][3,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,0])]*r[A][33][3,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,1])]*r[A][15][3,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,1])]*r[A][33][3,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][4][2,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][4][2,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,3)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][15][3,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][33][3,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,1])]*r[A][15][3,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,0])]*r[A][33][3,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,1])]*r[A][15][3,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,1])]*r[A][33][3,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][4][3,9]*r[C][5][0,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][4][3,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B3C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,3),(C,1)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][15][3,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][33][3,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,1])]*r[A][15][3,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,0])]*r[A][33][3,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,1])]*r[A][15][3,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,1])]*r[A][33][3,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][4][3,9]*r[C][5][1,11]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][4][3,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B10C4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,10),(C,4)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,0],p[B,0],p[B,1],p[C,0])]*r[A][2][14,1]*r[B][48][10,9]*r[C][3][4,11]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[B,1],p[B,0])]*r[A][2][14,1]*r[B][48][10,9]*r[C][3][4,11]
    hv += -1/2*g[dei(p[B,1],p[B,0],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][48][10,9]*r[C][3][4,11]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][48][10,9]*r[C][3][4,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B10C4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,10),(C,4)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,1],p[B,0],p[B,1],p[C,0])]*r[A][6][13,1]*r[B][48][10,9]*r[C][3][4,11]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[B,1],p[B,0])]*r[A][6][13,1]*r[B][48][10,9]*r[C][3][4,11]
    hv += -1/2*g[dei(p[B,1],p[B,0],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][48][10,9]*r[C][3][4,11]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][48][10,9]*r[C][3][4,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A4B5C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,4),(B,5),(C,2)]))
    hv = 0.0
    
    hv += g[dei(p[A,0],p[C,0],p[B,1],p[A,1])]*r[A][18][4,1]*r[B][6][5,9]*r[C][1][2,11]
    hv += g[dei(p[A,1],p[C,0],p[B,1],p[A,0])]*r[A][36][4,1]*r[B][6][5,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A4B5C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,4),(B,5),(C,3)]))
    hv = 0.0
    
    hv += g[dei(p[A,0],p[C,0],p[B,1],p[A,1])]*r[A][18][4,1]*r[B][6][5,9]*r[C][1][3,11]
    hv += g[dei(p[A,1],p[C,0],p[B,1],p[A,0])]*r[A][36][4,1]*r[B][6][5,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A4B5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,4),(B,5)]))
    hv = 0.0
    
    hv += g[dei(p[A,0],p[C,1],p[B,1],p[A,1])]*r[A][18][4,1]*r[B][6][5,9]*r[C][5][0,11]
    hv += g[dei(p[A,1],p[C,1],p[B,1],p[A,0])]*r[A][36][4,1]*r[B][6][5,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A4B5C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,4),(B,5),(C,1)]))
    hv = 0.0
    
    hv += g[dei(p[A,0],p[C,1],p[B,1],p[A,1])]*r[A][18][4,1]*r[B][6][5,9]*r[C][5][1,11]
    hv += g[dei(p[A,1],p[C,1],p[B,1],p[A,0])]*r[A][36][4,1]*r[B][6][5,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B10C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,10),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[A,0],p[C,0],p[B,1],p[B,0])]*r[A][0][12,1]*r[B][48][10,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B10C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,10),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[A,0],p[C,0],p[B,1],p[B,0])]*r[A][0][12,1]*r[B][48][10,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,10)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[A,0],p[C,1],p[B,1],p[B,0])]*r[A][0][12,1]*r[B][48][10,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B10C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,10),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[A,0],p[C,1],p[B,1],p[B,0])]*r[A][0][12,1]*r[B][48][10,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B10C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,10),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[A,1],p[C,0],p[B,1],p[B,0])]*r[A][4][11,1]*r[B][48][10,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B10C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,10),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[A,1],p[C,0],p[B,1],p[B,0])]*r[A][4][11,1]*r[B][48][10,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,10)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[A,1],p[C,1],p[B,1],p[B,0])]*r[A][4][11,1]*r[B][48][10,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B10C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,10),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[A,1],p[C,1],p[B,1],p[B,0])]*r[A][4][11,1]*r[B][48][10,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[C,1])]*r[A][0][12,1]*r[B][0][0,9]*r[C][34][9,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[C,0])]*r[A][0][12,1]*r[B][0][0,9]*r[C][16][9,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[C,1])]*r[A][0][12,1]*r[B][0][0,9]*r[C][34][9,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[C,0])]*r[A][0][12,1]*r[B][0][0,9]*r[C][16][9,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B1C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,1),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[C,1])]*r[A][0][12,1]*r[B][0][1,9]*r[C][34][9,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[C,0])]*r[A][0][12,1]*r[B][0][1,9]*r[C][16][9,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[C,1])]*r[A][0][12,1]*r[B][0][1,9]*r[C][34][9,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[C,0])]*r[A][0][12,1]*r[B][0][1,9]*r[C][16][9,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B5C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,5),(C,8)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[A,0],p[C,0],p[B,1],p[C,0])]*r[A][0][12,1]*r[B][6][5,9]*r[C][22][8,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B2C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,2),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[C,1])]*r[A][0][12,1]*r[B][4][2,9]*r[C][34][9,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[C,0])]*r[A][0][12,1]*r[B][4][2,9]*r[C][16][9,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[C,1])]*r[A][0][12,1]*r[B][4][2,9]*r[C][34][9,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[C,0])]*r[A][0][12,1]*r[B][4][2,9]*r[C][16][9,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B3C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,3),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[C,1])]*r[A][0][12,1]*r[B][4][3,9]*r[C][34][9,11]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[C,0])]*r[A][0][12,1]*r[B][4][3,9]*r[C][16][9,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[C,1])]*r[A][0][12,1]*r[B][4][3,9]*r[C][34][9,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[C,0])]*r[A][0][12,1]*r[B][4][3,9]*r[C][16][9,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B5C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,5),(C,7)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[A,0],p[C,1],p[B,1],p[C,0])]*r[A][0][12,1]*r[B][6][5,9]*r[C][28][7,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[C,1])]*r[A][4][11,1]*r[B][0][0,9]*r[C][34][9,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[C,0])]*r[A][4][11,1]*r[B][0][0,9]*r[C][16][9,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[C,1])]*r[A][4][11,1]*r[B][0][0,9]*r[C][34][9,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[C,0])]*r[A][4][11,1]*r[B][0][0,9]*r[C][16][9,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B1C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,1),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[C,1])]*r[A][4][11,1]*r[B][0][1,9]*r[C][34][9,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[C,0])]*r[A][4][11,1]*r[B][0][1,9]*r[C][16][9,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[C,1])]*r[A][4][11,1]*r[B][0][1,9]*r[C][34][9,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[C,0])]*r[A][4][11,1]*r[B][0][1,9]*r[C][16][9,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B5C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,5),(C,8)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[A,1],p[C,0],p[B,1],p[C,0])]*r[A][4][11,1]*r[B][6][5,9]*r[C][22][8,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B2C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,2),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[C,1])]*r[A][4][11,1]*r[B][4][2,9]*r[C][34][9,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[C,0])]*r[A][4][11,1]*r[B][4][2,9]*r[C][16][9,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[C,1])]*r[A][4][11,1]*r[B][4][2,9]*r[C][34][9,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[C,0])]*r[A][4][11,1]*r[B][4][2,9]*r[C][16][9,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B3C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,3),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[C,1])]*r[A][4][11,1]*r[B][4][3,9]*r[C][34][9,11]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[C,0])]*r[A][4][11,1]*r[B][4][3,9]*r[C][16][9,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[C,1])]*r[A][4][11,1]*r[B][4][3,9]*r[C][34][9,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[C,0])]*r[A][4][11,1]*r[B][4][3,9]*r[C][16][9,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B5C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,5),(C,7)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[A,1],p[C,1],p[B,1],p[C,0])]*r[A][4][11,1]*r[B][6][5,9]*r[C][28][7,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B6C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,6),(C,15)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[B,0])]*r[A][24][0,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += g[dei(p[A,0],p[A,0],p[C,1],p[B,0])]*r[A][9][0,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[B,0])]*r[A][54][0,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += g[dei(p[A,1],p[A,1],p[C,1],p[B,0])]*r[A][39][0,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[C,1],p[A,0])]*r[A][24][0,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[C,1],p[A,1])]*r[A][54][0,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[B,0])]*r[A][24][0,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[B,0])]*r[A][54][0,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += 1/2*g[dei(p[C,1],p[B,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += 1/2*g[dei(p[C,1],p[B,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][3][6,9]*r[C][6][15,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B6C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,6),(C,15)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,1],p[B,0])]*r[A][30][2,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += g[dei(p[A,0],p[A,1],p[C,1],p[B,0])]*r[A][15][2,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,1],p[B,0])]*r[A][48][2,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += g[dei(p[A,1],p[A,0],p[C,1],p[B,0])]*r[A][33][2,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[C,1],p[A,1])]*r[A][30][2,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[C,1],p[A,0])]*r[A][48][2,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,0],p[B,0])]*r[A][30][2,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,1],p[B,0])]*r[A][48][2,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += 1/2*g[dei(p[C,1],p[B,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += 1/2*g[dei(p[C,1],p[B,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][3][6,9]*r[C][6][15,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B6C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,6),(C,15)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,1],p[B,0])]*r[A][30][3,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += g[dei(p[A,0],p[A,1],p[C,1],p[B,0])]*r[A][15][3,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,1],p[B,0])]*r[A][48][3,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += g[dei(p[A,1],p[A,0],p[C,1],p[B,0])]*r[A][33][3,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[C,1],p[A,1])]*r[A][30][3,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[C,1],p[A,0])]*r[A][48][3,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,0],p[B,0])]*r[A][30][3,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,1],p[B,0])]*r[A][48][3,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += 1/2*g[dei(p[C,1],p[B,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][3][6,9]*r[C][6][15,11]
    hv += 1/2*g[dei(p[C,1],p[B,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][3][6,9]*r[C][6][15,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B6C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,6),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,1],p[C,0])]*r[A][2][14,1]*r[B][3][6,9]*r[C][48][12,11]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[B,0])]*r[A][2][14,1]*r[B][3][6,9]*r[C][48][12,11]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][3][6,9]*r[C][48][12,11]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][3][6,9]*r[C][48][12,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B6C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,6),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,1],p[C,0])]*r[A][6][13,1]*r[B][3][6,9]*r[C][48][12,11]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[B,0])]*r[A][6][13,1]*r[B][3][6,9]*r[C][48][12,11]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][3][6,9]*r[C][48][12,11]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][3][6,9]*r[C][48][12,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B6C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,6),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[A,0],p[C,0],p[C,1],p[B,0])]*r[A][0][12,1]*r[B][3][6,9]*r[C][45][14,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B6C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,6),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[A,0],p[C,1],p[C,1],p[B,0])]*r[A][0][12,1]*r[B][3][6,9]*r[C][51][13,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B6C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,6),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[A,1],p[C,0],p[C,1],p[B,0])]*r[A][4][11,1]*r[B][3][6,9]*r[C][45][14,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B6C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,6),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[A,1],p[C,1],p[C,1],p[B,0])]*r[A][4][11,1]*r[B][3][6,9]*r[C][51][13,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5C4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,5),(C,4)]))
    hv = 0.0
    
    hv += g[dei(p[B,0],p[A,1],p[A,0],p[C,0])]*r[A][27][5,1]*r[B][0][0,9]*r[C][3][4,11]
    hv += g[dei(p[B,0],p[A,0],p[A,1],p[C,0])]*r[A][45][5,1]*r[B][0][0,9]*r[C][3][4,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5B1C4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,5),(B,1),(C,4)]))
    hv = 0.0
    
    hv += g[dei(p[B,0],p[A,1],p[A,0],p[C,0])]*r[A][27][5,1]*r[B][0][1,9]*r[C][3][4,11]
    hv += g[dei(p[B,0],p[A,0],p[A,1],p[C,0])]*r[A][45][5,1]*r[B][0][1,9]*r[C][3][4,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5B2C4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,5),(B,2),(C,4)]))
    hv = 0.0
    
    hv += g[dei(p[B,1],p[A,1],p[A,0],p[C,0])]*r[A][27][5,1]*r[B][4][2,9]*r[C][3][4,11]
    hv += g[dei(p[B,1],p[A,0],p[A,1],p[C,0])]*r[A][45][5,1]*r[B][4][2,9]*r[C][3][4,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5B3C4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,5),(B,3),(C,4)]))
    hv = 0.0
    
    hv += g[dei(p[B,1],p[A,1],p[A,0],p[C,0])]*r[A][27][5,1]*r[B][4][3,9]*r[C][3][4,11]
    hv += g[dei(p[B,1],p[A,0],p[A,1],p[C,0])]*r[A][45][5,1]*r[B][4][3,9]*r[C][3][4,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B7C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,7),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,0],p[C,0],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][12][7,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B7C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,7),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,0],p[C,0],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][12][7,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,7)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,0],p[C,1],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][12][7,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B7C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,7),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,0],p[C,1],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][12][7,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B7C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,7),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,0],p[C,0],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][12][7,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B7C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,7),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,0],p[C,0],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][12][7,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,7)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,0],p[C,1],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][12][7,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B7C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,7),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,0],p[C,1],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][12][7,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B8C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,8),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,1],p[C,0],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][36][8,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B8C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,8),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,1],p[C,0],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][36][8,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,8)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,1],p[C,1],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][36][8,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B8C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,8),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,1],p[C,1],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][36][8,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B8C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,8),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,1],p[C,0],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][36][8,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B8C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,8),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,1],p[C,0],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][36][8,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,8)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,1],p[C,1],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][36][8,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B8C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,8),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,1],p[C,1],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][36][8,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(C,8)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,0],p[C,0],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][0][0,9]*r[C][22][8,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B1C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,1),(C,8)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,0],p[C,0],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][0][1,9]*r[C][22][8,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(C,7)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][0][0,9]*r[C][28][7,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B1C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,1),(C,7)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][0][1,9]*r[C][28][7,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(C,8)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,0],p[C,0],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][0][0,9]*r[C][22][8,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B1C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,1),(C,8)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,0],p[C,0],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][0][1,9]*r[C][22][8,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(C,7)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][0][0,9]*r[C][28][7,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B1C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,1),(C,7)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][0][1,9]*r[C][28][7,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B2C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,2),(C,8)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,1],p[C,0],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][4][2,9]*r[C][22][8,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B3C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,3),(C,8)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,1],p[C,0],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][4][3,9]*r[C][22][8,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B2C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,2),(C,7)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,1],p[C,1],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][4][2,9]*r[C][28][7,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B3C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,3),(C,7)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,1],p[C,1],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][4][3,9]*r[C][28][7,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B2C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,2),(C,8)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,1],p[C,0],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][4][2,9]*r[C][22][8,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B3C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,3),(C,8)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,1],p[C,0],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][4][3,9]*r[C][22][8,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B2C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,2),(C,7)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,1],p[C,1],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][4][2,9]*r[C][28][7,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B3C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,3),(C,7)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,1],p[C,1],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][4][3,9]*r[C][28][7,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B11C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,11),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[B,0],p[A,0],p[B,1],p[C,0])]*r[A][1][9,1]*r[B][14][11,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[B,0],p[C,0])]*r[A][1][9,1]*r[B][32][11,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][14][11,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][32][11,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B11C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,11),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[B,0],p[A,0],p[B,1],p[C,0])]*r[A][1][9,1]*r[B][14][11,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[B,0],p[C,0])]*r[A][1][9,1]*r[B][32][11,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][14][11,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][32][11,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B13C4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,13),(C,4)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,0],p[A,0],p[B,1],p[C,0])]*r[A][1][9,1]*r[B][17][13,9]*r[C][3][4,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,11)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[B,0],p[A,0],p[B,1],p[C,1])]*r[A][1][9,1]*r[B][14][11,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[B,0],p[C,1])]*r[A][1][9,1]*r[B][32][11,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][14][11,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][32][11,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B11C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,11),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[B,0],p[A,0],p[B,1],p[C,1])]*r[A][1][9,1]*r[B][14][11,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[B,0],p[C,1])]*r[A][1][9,1]*r[B][32][11,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][14][11,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][32][11,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B11C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,11),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[B,0],p[A,1],p[B,1],p[C,0])]*r[A][5][10,1]*r[B][14][11,9]*r[C][1][2,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[B,0],p[C,0])]*r[A][5][10,1]*r[B][32][11,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][14][11,9]*r[C][1][2,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][32][11,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B11C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,11),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[B,0],p[A,1],p[B,1],p[C,0])]*r[A][5][10,1]*r[B][14][11,9]*r[C][1][3,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[B,0],p[C,0])]*r[A][5][10,1]*r[B][32][11,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][14][11,9]*r[C][1][3,11]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][32][11,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B13C4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,13),(C,4)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,0],p[A,1],p[B,1],p[C,0])]*r[A][5][10,1]*r[B][17][13,9]*r[C][3][4,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,11)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[B,0],p[A,1],p[B,1],p[C,1])]*r[A][5][10,1]*r[B][14][11,9]*r[C][5][0,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[B,0],p[C,1])]*r[A][5][10,1]*r[B][32][11,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][14][11,9]*r[C][5][0,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][32][11,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B11C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,11),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[B,0],p[A,1],p[B,1],p[C,1])]*r[A][5][10,1]*r[B][14][11,9]*r[C][5][1,11]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[B,0],p[C,1])]*r[A][5][10,1]*r[B][32][11,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][14][11,9]*r[C][5][1,11]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][32][11,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B14C4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,14),(C,4)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,1],p[A,0],p[B,1],p[C,0])]*r[A][1][9,1]*r[B][41][14,9]*r[C][3][4,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B14C4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,14),(C,4)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,1],p[A,1],p[B,1],p[C,0])]*r[A][5][10,1]*r[B][41][14,9]*r[C][3][4,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B13C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,13),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,0],p[C,0],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][17][13,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B13C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,13),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,0],p[C,0],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][17][13,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B13C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,13),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,0],p[C,0],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][17][13,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B13C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,13),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,0],p[C,0],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][17][13,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,13)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,0],p[C,1],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][17][13,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B13C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,13),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,0],p[C,1],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][17][13,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,13)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,0],p[C,1],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][17][13,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B13C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,13),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,0],p[C,1],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][17][13,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B14C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,14),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,1],p[C,0],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][41][14,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B14C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,14),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,1],p[C,0],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][41][14,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B14C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,14),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,1],p[C,0],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][41][14,9]*r[C][1][2,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B14C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,14),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,1],p[C,0],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][41][14,9]*r[C][1][3,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,14)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,1],p[C,1],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][41][14,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B14C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,14),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,1],p[C,1],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][41][14,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,14)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,1],p[C,1],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][41][14,9]*r[C][5][0,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B14C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,14),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,1],p[C,1],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][41][14,9]*r[C][5][1,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,6),(C,15)]))
    hv = 0.0
    
    hv += -1*g[dei(p[B,0],p[A,0],p[C,1],p[A,0])]*r[A][22][6,1]*r[B][0][0,9]*r[C][6][15,11]
    hv += -1*g[dei(p[B,0],p[A,1],p[C,1],p[A,1])]*r[A][52][6,1]*r[B][0][0,9]*r[C][6][15,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6B1C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,6),(B,1),(C,15)]))
    hv = 0.0
    
    hv += -1*g[dei(p[B,0],p[A,0],p[C,1],p[A,0])]*r[A][22][6,1]*r[B][0][1,9]*r[C][6][15,11]
    hv += -1*g[dei(p[B,0],p[A,1],p[C,1],p[A,1])]*r[A][52][6,1]*r[B][0][1,9]*r[C][6][15,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6B2C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,6),(B,2),(C,15)]))
    hv = 0.0
    
    hv += -1*g[dei(p[B,1],p[A,0],p[C,1],p[A,0])]*r[A][22][6,1]*r[B][4][2,9]*r[C][6][15,11]
    hv += -1*g[dei(p[B,1],p[A,1],p[C,1],p[A,1])]*r[A][52][6,1]*r[B][4][2,9]*r[C][6][15,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6B3C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,6),(B,3),(C,15)]))
    hv = 0.0
    
    hv += -1*g[dei(p[B,1],p[A,0],p[C,1],p[A,0])]*r[A][22][6,1]*r[B][4][3,9]*r[C][6][15,11]
    hv += -1*g[dei(p[B,1],p[A,1],p[C,1],p[A,1])]*r[A][52][6,1]*r[B][4][3,9]*r[C][6][15,11]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B7C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,7),(C,15)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,0],p[A,0],p[C,1],p[B,0])]*r[A][1][9,1]*r[B][12][7,9]*r[C][6][15,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B7C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,7),(C,15)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,0],p[A,1],p[C,1],p[B,0])]*r[A][5][10,1]*r[B][12][7,9]*r[C][6][15,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B10C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,10),(C,15)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[B,1],p[A,0],p[C,1],p[B,0])]*r[A][3][7,1]*r[B][48][10,9]*r[C][6][15,11]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][48][10,9]*r[C][6][15,11]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[B,1],p[B,0])]*r[A][3][7,1]*r[B][48][10,9]*r[C][6][15,11]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][48][10,9]*r[C][6][15,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B8C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,8),(C,15)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,1],p[A,0],p[C,1],p[B,0])]*r[A][1][9,1]*r[B][36][8,9]*r[C][6][15,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B10C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,10),(C,15)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[B,1],p[A,1],p[C,1],p[B,0])]*r[A][7][8,1]*r[B][48][10,9]*r[C][6][15,11]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][48][10,9]*r[C][6][15,11]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[B,1],p[B,0])]*r[A][7][8,1]*r[B][48][10,9]*r[C][6][15,11]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][48][10,9]*r[C][6][15,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B8C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,8),(C,15)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,1],p[A,1],p[C,1],p[B,0])]*r[A][5][10,1]*r[B][36][8,9]*r[C][6][15,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,0],p[A,0],p[C,1],p[C,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][48][12,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B1C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,1),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,0],p[A,0],p[C,1],p[C,0])]*r[A][1][9,1]*r[B][0][1,9]*r[C][48][12,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,0],p[A,1],p[C,1],p[C,0])]*r[A][5][10,1]*r[B][0][0,9]*r[C][48][12,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B1C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,1),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,0],p[A,1],p[C,1],p[C,0])]*r[A][5][10,1]*r[B][0][1,9]*r[C][48][12,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B5C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,5),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[B,1],p[A,0],p[C,1],p[C,0])]*r[A][3][7,1]*r[B][6][5,9]*r[C][48][12,11]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][6][5,9]*r[C][48][12,11]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[B,1],p[C,0])]*r[A][3][7,1]*r[B][6][5,9]*r[C][48][12,11]
    hv += -1/2*g[dei(p[C,1],p[C,0],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][6][5,9]*r[C][48][12,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B2C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,2),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,1],p[A,0],p[C,1],p[C,0])]*r[A][1][9,1]*r[B][4][2,9]*r[C][48][12,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B3C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,3),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,1],p[A,0],p[C,1],p[C,0])]*r[A][1][9,1]*r[B][4][3,9]*r[C][48][12,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B5C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,5),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[B,1],p[A,1],p[C,1],p[C,0])]*r[A][7][8,1]*r[B][6][5,9]*r[C][48][12,11]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][6][5,9]*r[C][48][12,11]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[B,1],p[C,0])]*r[A][7][8,1]*r[B][6][5,9]*r[C][48][12,11]
    hv += -1/2*g[dei(p[C,1],p[C,0],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][6][5,9]*r[C][48][12,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B2C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,2),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,1],p[A,1],p[C,1],p[C,0])]*r[A][5][10,1]*r[B][4][2,9]*r[C][48][12,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B3C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,3),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,1],p[A,1],p[C,1],p[C,0])]*r[A][5][10,1]*r[B][4][3,9]*r[C][48][12,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[B,0],p[C,0],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][0][0,9]*r[C][45][14,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B1C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,1),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[B,0],p[C,0],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][0][1,9]*r[C][45][14,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[B,0],p[C,0],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][0][0,9]*r[C][45][14,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B1C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,1),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[B,0],p[C,0],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][0][1,9]*r[C][45][14,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[B,0],p[C,1],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][0][0,9]*r[C][51][13,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B1C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,1),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[B,0],p[C,1],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][0][1,9]*r[C][51][13,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[B,0],p[C,1],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][0][0,9]*r[C][51][13,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B1C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,1),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[B,0],p[C,1],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][0][1,9]*r[C][51][13,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B2C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,2),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[B,1],p[C,0],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][4][2,9]*r[C][45][14,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B3C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,3),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[B,1],p[C,0],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][4][3,9]*r[C][45][14,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B2C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,2),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[B,1],p[C,0],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][4][2,9]*r[C][45][14,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B3C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,3),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[B,1],p[C,0],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][4][3,9]*r[C][45][14,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B2C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,2),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[B,1],p[C,1],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][4][2,9]*r[C][51][13,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B3C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,3),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[B,1],p[C,1],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][4][3,9]*r[C][51][13,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B2C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,2),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[B,1],p[C,1],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][4][2,9]*r[C][51][13,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B3C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,3),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[B,1],p[C,1],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][4][3,9]*r[C][51][13,11]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I12J9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,1),(I,12),(J,9)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[B,0],p[C,1],p[I,0],p[J,0])]*r[B][0][0,9]*r[C][5][0,11]*r[I][0][12,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[B,0],p[J,0],p[I,0],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][0][12,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[I,0],p[C,1],p[B,0],p[J,0])]*r[B][0][0,9]*r[C][5][0,11]*r[I][0][12,0]*r[J][1][9,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][0][12,0]*r[J][1][9,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I14J7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,1),(I,14),(J,7)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[B,0],p[C,1],p[I,0],p[J,0])]*r[B][0][0,9]*r[C][5][0,11]*r[I][2][14,0]*r[J][3][7,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I12J10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,1),(I,12),(J,10)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[B,0],p[C,1],p[I,0],p[J,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][0][12,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[B,0],p[J,1],p[I,0],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][0][12,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[I,0],p[C,1],p[B,0],p[J,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][0][12,0]*r[J][5][10,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][0][12,0]*r[J][5][10,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I14J8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,1),(I,14),(J,8)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[B,0],p[C,1],p[I,0],p[J,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][2][14,0]*r[J][7][8,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I11J9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,1),(I,11),(J,9)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[B,0],p[C,1],p[I,1],p[J,0])]*r[B][0][0,9]*r[C][5][0,11]*r[I][4][11,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[B,0],p[J,0],p[I,1],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][4][11,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[I,1],p[C,1],p[B,0],p[J,0])]*r[B][0][0,9]*r[C][5][0,11]*r[I][4][11,0]*r[J][1][9,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][4][11,0]*r[J][1][9,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I13J7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,1),(I,13),(J,7)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[B,0],p[C,1],p[I,1],p[J,0])]*r[B][0][0,9]*r[C][5][0,11]*r[I][6][13,0]*r[J][3][7,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I11J10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,1),(I,11),(J,10)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[B,0],p[C,1],p[I,1],p[J,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][4][11,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[B,0],p[J,1],p[I,1],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][4][11,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[I,1],p[C,1],p[B,0],p[J,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][4][11,0]*r[J][5][10,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][4][11,0]*r[J][5][10,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I13J8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,1),(I,13),(J,8)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[B,0],p[C,1],p[I,1],p[J,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][6][13,0]*r[J][7][8,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I9J12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,1),(I,9),(J,12)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[B,0],p[C,1],p[J,0],p[I,0])]*r[B][0][0,9]*r[C][5][0,11]*r[I][1][9,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[B,0],p[I,0],p[J,0],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][1][9,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[J,0],p[C,1],p[B,0],p[I,0])]*r[B][0][0,9]*r[C][5][0,11]*r[I][1][9,0]*r[J][0][12,0]
            hv += 1/4*g[dei(p[J,0],p[I,0],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][1][9,0]*r[J][0][12,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I7J14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,1),(I,7),(J,14)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[B,0],p[C,1],p[J,0],p[I,0])]*r[B][0][0,9]*r[C][5][0,11]*r[I][3][7,0]*r[J][2][14,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I10J12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,1),(I,10),(J,12)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[B,0],p[C,1],p[J,0],p[I,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][5][10,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[B,0],p[I,1],p[J,0],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][5][10,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[J,0],p[C,1],p[B,0],p[I,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][5][10,0]*r[J][0][12,0]
            hv += 1/4*g[dei(p[J,0],p[I,1],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][5][10,0]*r[J][0][12,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I8J14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,1),(I,8),(J,14)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[B,0],p[C,1],p[J,0],p[I,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][7][8,0]*r[J][2][14,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I9J11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,1),(I,9),(J,11)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[B,0],p[C,1],p[J,1],p[I,0])]*r[B][0][0,9]*r[C][5][0,11]*r[I][1][9,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[B,0],p[I,0],p[J,1],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][1][9,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[J,1],p[C,1],p[B,0],p[I,0])]*r[B][0][0,9]*r[C][5][0,11]*r[I][1][9,0]*r[J][4][11,0]
            hv += 1/4*g[dei(p[J,1],p[I,0],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][1][9,0]*r[J][4][11,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I7J13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,1),(I,7),(J,13)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[B,0],p[C,1],p[J,1],p[I,0])]*r[B][0][0,9]*r[C][5][0,11]*r[I][3][7,0]*r[J][6][13,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I10J11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,1),(I,10),(J,11)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[B,0],p[C,1],p[J,1],p[I,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][5][10,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[B,0],p[I,1],p[J,1],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][5][10,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[J,1],p[C,1],p[B,0],p[I,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][5][10,0]*r[J][4][11,0]
            hv += 1/4*g[dei(p[J,1],p[I,1],p[B,0],p[C,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][5][10,0]*r[J][4][11,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I8J13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,1),(I,8),(J,13)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[B,0],p[C,1],p[J,1],p[I,1])]*r[B][0][0,9]*r[C][5][0,11]*r[I][7][8,0]*r[J][6][13,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12C2I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(C,2),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[I,0])]*r[A][0][12,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,0],p[C,0])]*r[A][0][12,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[I,0])]*r[A][0][12,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,0],p[C,0])]*r[A][0][12,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12C3I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(C,3),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[I,0])]*r[A][0][12,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,0],p[C,0])]*r[A][0][12,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[I,0])]*r[A][0][12,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,0],p[C,0])]*r[A][0][12,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12C2I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(C,2),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[I,1])]*r[A][0][12,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,0],p[C,0])]*r[A][0][12,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[I,1])]*r[A][0][12,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,0],p[C,0])]*r[A][0][12,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12C3I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(C,3),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[I,1])]*r[A][0][12,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,0],p[C,0])]*r[A][0][12,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[I,1])]*r[A][0][12,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,0],p[C,0])]*r[A][0][12,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[I,0])]*r[A][0][12,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,0],p[C,1])]*r[A][0][12,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[I,0])]*r[A][0][12,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,0],p[C,1])]*r[A][0][12,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12C1I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(C,1),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[I,0])]*r[A][0][12,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,0],p[C,1])]*r[A][0][12,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[I,0])]*r[A][0][12,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,0],p[C,1])]*r[A][0][12,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B1I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(B,1),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[I,0])]*r[A][0][12,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,0],p[C,1])]*r[A][0][12,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[I,0])]*r[A][0][12,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,0],p[C,1])]*r[A][0][12,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[I,1])]*r[A][0][12,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,0],p[C,1])]*r[A][0][12,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[I,1])]*r[A][0][12,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,0],p[C,1])]*r[A][0][12,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12C1I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(C,1),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[I,1])]*r[A][0][12,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,0],p[C,1])]*r[A][0][12,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[I,1])]*r[A][0][12,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,0],p[C,1])]*r[A][0][12,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B1I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(B,1),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[I,1])]*r[A][0][12,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,0],p[C,1])]*r[A][0][12,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[I,1])]*r[A][0][12,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,0],p[C,1])]*r[A][0][12,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B2I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(B,2),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[I,0])]*r[A][0][12,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,1],p[C,1])]*r[A][0][12,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[I,0])]*r[A][0][12,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,0],p[C,1])]*r[A][0][12,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B3I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(B,3),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[I,0])]*r[A][0][12,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,1],p[C,1])]*r[A][0][12,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[I,0])]*r[A][0][12,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,0],p[C,1])]*r[A][0][12,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B5I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(B,5),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,0],p[C,1],p[B,1],p[I,0])]*r[A][0][12,1]*r[B][6][5,9]*r[C][5][0,11]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B2I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(B,2),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[I,1])]*r[A][0][12,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,1],p[C,1])]*r[A][0][12,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[I,1])]*r[A][0][12,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,0],p[C,1])]*r[A][0][12,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B3I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(B,3),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[I,1])]*r[A][0][12,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,1],p[C,1])]*r[A][0][12,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[I,1])]*r[A][0][12,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,0],p[C,1])]*r[A][0][12,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B5I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(B,5),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,0],p[C,1],p[B,1],p[I,1])]*r[A][0][12,1]*r[B][6][5,9]*r[C][5][0,11]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11C2I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(C,2),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[I,0])]*r[A][4][11,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,0],p[C,0])]*r[A][4][11,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[I,0])]*r[A][4][11,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,1],p[C,0])]*r[A][4][11,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11C3I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(C,3),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[I,0])]*r[A][4][11,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,0],p[C,0])]*r[A][4][11,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[I,0])]*r[A][4][11,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,1],p[C,0])]*r[A][4][11,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11C2I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(C,2),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[I,1])]*r[A][4][11,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,0],p[C,0])]*r[A][4][11,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[I,1])]*r[A][4][11,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,1],p[C,0])]*r[A][4][11,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11C3I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(C,3),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[I,1])]*r[A][4][11,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,0],p[C,0])]*r[A][4][11,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[I,1])]*r[A][4][11,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,1],p[C,0])]*r[A][4][11,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[I,0])]*r[A][4][11,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,0],p[C,1])]*r[A][4][11,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[I,0])]*r[A][4][11,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,1],p[C,1])]*r[A][4][11,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11C1I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(C,1),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[I,0])]*r[A][4][11,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,0],p[C,1])]*r[A][4][11,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[I,0])]*r[A][4][11,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,1],p[C,1])]*r[A][4][11,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B1I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(B,1),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[I,0])]*r[A][4][11,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,0],p[C,1])]*r[A][4][11,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[I,0])]*r[A][4][11,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,1],p[C,1])]*r[A][4][11,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[I,1])]*r[A][4][11,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,0],p[C,1])]*r[A][4][11,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[I,1])]*r[A][4][11,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,1],p[C,1])]*r[A][4][11,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11C1I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(C,1),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[I,1])]*r[A][4][11,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,0],p[C,1])]*r[A][4][11,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[I,1])]*r[A][4][11,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,1],p[C,1])]*r[A][4][11,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B1I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(B,1),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[I,1])]*r[A][4][11,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,0],p[C,1])]*r[A][4][11,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[I,1])]*r[A][4][11,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,1],p[C,1])]*r[A][4][11,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B2I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(B,2),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[I,0])]*r[A][4][11,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,1],p[C,1])]*r[A][4][11,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[I,0])]*r[A][4][11,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,1],p[C,1])]*r[A][4][11,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B3I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(B,3),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[I,0])]*r[A][4][11,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,1],p[C,1])]*r[A][4][11,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[I,0])]*r[A][4][11,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,1],p[C,1])]*r[A][4][11,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B5I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(B,5),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,1],p[C,1],p[B,1],p[I,0])]*r[A][4][11,1]*r[B][6][5,9]*r[C][5][0,11]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B2I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(B,2),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[I,1])]*r[A][4][11,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,1],p[C,1])]*r[A][4][11,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[I,1])]*r[A][4][11,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,1],p[C,1])]*r[A][4][11,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B3I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(B,3),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[I,1])]*r[A][4][11,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,1],p[C,1])]*r[A][4][11,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[I,1])]*r[A][4][11,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,1],p[C,1])]*r[A][4][11,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B5I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(B,5),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,1],p[C,1],p[B,1],p[I,1])]*r[A][4][11,1]*r[B][6][5,9]*r[C][5][0,11]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B6I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(B,6),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,0],p[C,1],p[I,0],p[B,0])]*r[A][0][12,1]*r[B][3][6,9]*r[C][5][0,11]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B6I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(B,6),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,0],p[C,1],p[I,1],p[B,0])]*r[A][0][12,1]*r[B][3][6,9]*r[C][5][0,11]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B6I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(B,6),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,1],p[C,1],p[I,0],p[B,0])]*r[A][4][11,1]*r[B][3][6,9]*r[C][5][0,11]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B6I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(B,6),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,1],p[C,1],p[I,1],p[B,0])]*r[A][4][11,1]*r[B][3][6,9]*r[C][5][0,11]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14C2I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(C,2),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[C,0],p[A,0],p[I,0])]*r[A][2][14,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14C3I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(C,3),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[C,0],p[A,0],p[I,0])]*r[A][2][14,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14C2I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(C,2),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[C,0],p[A,0],p[I,1])]*r[A][2][14,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14C3I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(C,3),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[C,0],p[A,0],p[I,1])]*r[A][2][14,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[I,0])]*r[A][2][14,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14C1I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(C,1),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[I,0])]*r[A][2][14,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B1I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(B,1),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[I,0])]*r[A][2][14,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[I,1])]*r[A][2][14,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14C1I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(C,1),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[I,1])]*r[A][2][14,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B1I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(B,1),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[I,1])]*r[A][2][14,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13C2I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(C,2),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[C,0],p[A,1],p[I,0])]*r[A][6][13,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13C3I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(C,3),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[C,0],p[A,1],p[I,0])]*r[A][6][13,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13C2I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(C,2),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[C,0],p[A,1],p[I,1])]*r[A][6][13,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13C3I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(C,3),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[C,0],p[A,1],p[I,1])]*r[A][6][13,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[I,0])]*r[A][6][13,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13C1I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(C,1),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[I,0])]*r[A][6][13,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B1I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(B,1),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[I,0])]*r[A][6][13,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[I,1])]*r[A][6][13,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13C1I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(C,1),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[I,1])]*r[A][6][13,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B1I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(B,1),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[I,1])]*r[A][6][13,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B2I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(B,2),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,1],p[C,1],p[A,0],p[I,0])]*r[A][2][14,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B3I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(B,3),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,1],p[C,1],p[A,0],p[I,0])]*r[A][2][14,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B2I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(B,2),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,1],p[C,1],p[A,0],p[I,1])]*r[A][2][14,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B3I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(B,3),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,1],p[C,1],p[A,0],p[I,1])]*r[A][2][14,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B2I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(B,2),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,1],p[C,1],p[A,1],p[I,0])]*r[A][6][13,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B3I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(B,3),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,1],p[C,1],p[A,1],p[I,0])]*r[A][6][13,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B2I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(B,2),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,1],p[C,1],p[A,1],p[I,1])]*r[A][6][13,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B3I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(B,3),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,1],p[C,1],p[A,1],p[I,1])]*r[A][6][13,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14C4I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(C,4),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[I,0],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][0][0,9]*r[C][3][4,11]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14C4I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(C,4),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[I,1],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][0][0,9]*r[C][3][4,11]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13C4I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(C,4),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[I,0],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][0][0,9]*r[C][3][4,11]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13C4I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(C,4),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[I,1],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][0][0,9]*r[C][3][4,11]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9C15I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(C,15),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[A,0],p[C,1],p[I,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][6][15,11]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9C15I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(C,15),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[A,0],p[C,1],p[I,1])]*r[A][1][9,1]*r[B][0][0,9]*r[C][6][15,11]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10C15I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(C,15),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[A,1],p[C,1],p[I,0])]*r[A][5][10,1]*r[B][0][0,9]*r[C][6][15,11]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10C15I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(C,15),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[A,1],p[C,1],p[I,1])]*r[A][5][10,1]*r[B][0][0,9]*r[C][6][15,11]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7C15I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(C,15),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[I,0],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][0][0,9]*r[C][6][15,11]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8C15I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(C,15),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[I,0],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][0][0,9]*r[C][6][15,11]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7C15I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(C,15),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[I,1],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][0][0,9]*r[C][6][15,11]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8C15I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(C,15),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[I,1],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][0][0,9]*r[C][6][15,11]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9C2I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(C,2),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,0],p[A,0],p[I,0],p[C,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[B,0],p[C,0],p[I,0],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[B,0],p[C,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9C3I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(C,3),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,0],p[A,0],p[I,0],p[C,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[B,0],p[C,0],p[I,0],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[B,0],p[C,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9C4I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(C,4),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[A,0],p[I,0],p[C,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][3][4,11]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,0],p[A,0],p[I,0],p[C,1])]*r[A][1][9,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[B,0],p[C,1],p[I,0],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[B,0],p[C,1])]*r[A][1][9,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9C1I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(C,1),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,0],p[A,0],p[I,0],p[C,1])]*r[A][1][9,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[B,0],p[C,1],p[I,0],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[B,0],p[C,1])]*r[A][1][9,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B1I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(B,1),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,0],p[A,0],p[I,0],p[C,1])]*r[A][1][9,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[B,0],p[C,1],p[I,0],p[A,0])]*r[A][1][9,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[B,0],p[C,1])]*r[A][1][9,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10C2I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(C,2),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,0],p[A,1],p[I,0],p[C,0])]*r[A][5][10,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[B,0],p[C,0],p[I,0],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[B,0],p[C,0])]*r[A][5][10,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10C3I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(C,3),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,0],p[A,1],p[I,0],p[C,0])]*r[A][5][10,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[B,0],p[C,0],p[I,0],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[B,0],p[C,0])]*r[A][5][10,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10C4I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(C,4),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[A,1],p[I,0],p[C,0])]*r[A][5][10,1]*r[B][0][0,9]*r[C][3][4,11]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,0],p[A,1],p[I,0],p[C,1])]*r[A][5][10,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[B,0],p[C,1],p[I,0],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[B,0],p[C,1])]*r[A][5][10,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10C1I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(C,1),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,0],p[A,1],p[I,0],p[C,1])]*r[A][5][10,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[B,0],p[C,1],p[I,0],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[B,0],p[C,1])]*r[A][5][10,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B1I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(B,1),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,0],p[A,1],p[I,0],p[C,1])]*r[A][5][10,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[B,0],p[C,1],p[I,0],p[A,1])]*r[A][5][10,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[B,0],p[C,1])]*r[A][5][10,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9C2I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(C,2),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,0],p[A,0],p[I,1],p[C,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[B,0],p[C,0],p[I,1],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[B,0],p[C,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9C3I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(C,3),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,0],p[A,0],p[I,1],p[C,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[B,0],p[C,0],p[I,1],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[B,0],p[C,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9C4I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(C,4),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[A,0],p[I,1],p[C,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][3][4,11]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,0],p[A,0],p[I,1],p[C,1])]*r[A][1][9,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[B,0],p[C,1],p[I,1],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[B,0],p[C,1])]*r[A][1][9,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9C1I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(C,1),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,0],p[A,0],p[I,1],p[C,1])]*r[A][1][9,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[B,0],p[C,1],p[I,1],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[B,0],p[C,1])]*r[A][1][9,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B1I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(B,1),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,0],p[A,0],p[I,1],p[C,1])]*r[A][1][9,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[B,0],p[C,1],p[I,1],p[A,0])]*r[A][1][9,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[B,0],p[C,1])]*r[A][1][9,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10C2I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(C,2),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,0],p[A,1],p[I,1],p[C,0])]*r[A][5][10,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[B,0],p[C,0],p[I,1],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[B,0],p[C,0])]*r[A][5][10,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10C3I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(C,3),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,0],p[A,1],p[I,1],p[C,0])]*r[A][5][10,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[B,0],p[C,0],p[I,1],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[B,0],p[C,0])]*r[A][5][10,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10C4I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(C,4),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[A,1],p[I,1],p[C,0])]*r[A][5][10,1]*r[B][0][0,9]*r[C][3][4,11]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,0],p[A,1],p[I,1],p[C,1])]*r[A][5][10,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[B,0],p[C,1],p[I,1],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[B,0],p[C,1])]*r[A][5][10,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10C1I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(C,1),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,0],p[A,1],p[I,1],p[C,1])]*r[A][5][10,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[B,0],p[C,1],p[I,1],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[B,0],p[C,1])]*r[A][5][10,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B1I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(B,1),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,0],p[A,1],p[I,1],p[C,1])]*r[A][5][10,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[B,0],p[C,1],p[I,1],p[A,1])]*r[A][5][10,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[B,0],p[C,1])]*r[A][5][10,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B2I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(B,2),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,1],p[A,0],p[I,0],p[C,1])]*r[A][1][9,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[B,1],p[C,1],p[I,0],p[A,0])]*r[A][1][9,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[B,1],p[C,1])]*r[A][1][9,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B3I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(B,3),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,1],p[A,0],p[I,0],p[C,1])]*r[A][1][9,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[B,1],p[C,1],p[I,0],p[A,0])]*r[A][1][9,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[B,1],p[C,1])]*r[A][1][9,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B2I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(B,2),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,1],p[A,1],p[I,0],p[C,1])]*r[A][5][10,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[B,1],p[C,1],p[I,0],p[A,1])]*r[A][5][10,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[B,1],p[C,1])]*r[A][5][10,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B3I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(B,3),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,1],p[A,1],p[I,0],p[C,1])]*r[A][5][10,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[B,1],p[C,1],p[I,0],p[A,1])]*r[A][5][10,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[B,1],p[C,1])]*r[A][5][10,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B2I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(B,2),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,1],p[A,0],p[I,1],p[C,1])]*r[A][1][9,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[B,1],p[C,1],p[I,1],p[A,0])]*r[A][1][9,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[B,1],p[C,1])]*r[A][1][9,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B3I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(B,3),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,1],p[A,0],p[I,1],p[C,1])]*r[A][1][9,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[B,1],p[C,1],p[I,1],p[A,0])]*r[A][1][9,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[B,1],p[C,1])]*r[A][1][9,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B2I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(B,2),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,1],p[A,1],p[I,1],p[C,1])]*r[A][5][10,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[B,1],p[C,1],p[I,1],p[A,1])]*r[A][5][10,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[B,1],p[C,1])]*r[A][5][10,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B3I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(B,3),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,1],p[A,1],p[I,1],p[C,1])]*r[A][5][10,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[B,1],p[C,1],p[I,1],p[A,1])]*r[A][5][10,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[B,1],p[C,1])]*r[A][5][10,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7C2I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(C,2),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[C,0],p[I,0],p[A,0])]*r[A][3][7,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7C3I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(C,3),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[C,0],p[I,0],p[A,0])]*r[A][3][7,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8C2I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(C,2),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[C,0],p[I,0],p[A,1])]*r[A][7][8,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8C3I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(C,3),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[C,0],p[I,0],p[A,1])]*r[A][7][8,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[C,1],p[I,0],p[A,0])]*r[A][3][7,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7C1I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(C,1),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[C,1],p[I,0],p[A,0])]*r[A][3][7,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B1I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(B,1),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[C,1],p[I,0],p[A,0])]*r[A][3][7,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[C,1],p[I,0],p[A,1])]*r[A][7][8,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8C1I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(C,1),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[C,1],p[I,0],p[A,1])]*r[A][7][8,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B1I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(B,1),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[C,1],p[I,0],p[A,1])]*r[A][7][8,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7C2I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(C,2),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[C,0],p[I,1],p[A,0])]*r[A][3][7,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7C3I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(C,3),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[C,0],p[I,1],p[A,0])]*r[A][3][7,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8C2I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(C,2),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[C,0],p[I,1],p[A,1])]*r[A][7][8,1]*r[B][0][0,9]*r[C][1][2,11]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8C3I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(C,3),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[C,0],p[I,1],p[A,1])]*r[A][7][8,1]*r[B][0][0,9]*r[C][1][3,11]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[C,1],p[I,1],p[A,0])]*r[A][3][7,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7C1I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(C,1),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[C,1],p[I,1],p[A,0])]*r[A][3][7,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B1I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(B,1),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[C,1],p[I,1],p[A,0])]*r[A][3][7,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[C,1],p[I,1],p[A,1])]*r[A][7][8,1]*r[B][0][0,9]*r[C][5][0,11]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8C1I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(C,1),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[C,1],p[I,1],p[A,1])]*r[A][7][8,1]*r[B][0][0,9]*r[C][5][1,11]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B1I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(B,1),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[C,1],p[I,1],p[A,1])]*r[A][7][8,1]*r[B][0][1,9]*r[C][5][0,11]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B2I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(B,2),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,1],p[C,1],p[I,0],p[A,0])]*r[A][3][7,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B3I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(B,3),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,1],p[C,1],p[I,0],p[A,0])]*r[A][3][7,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B2I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(B,2),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,1],p[C,1],p[I,0],p[A,1])]*r[A][7][8,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B3I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(B,3),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,1],p[C,1],p[I,0],p[A,1])]*r[A][7][8,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B2I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(B,2),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,1],p[C,1],p[I,1],p[A,0])]*r[A][3][7,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B3I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(B,3),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,1],p[C,1],p[I,1],p[A,0])]*r[A][3][7,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B2I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(B,2),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,1],p[C,1],p[I,1],p[A,1])]*r[A][7][8,1]*r[B][4][2,9]*r[C][5][0,11]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B3I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(B,3),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,1],p[C,1],p[I,1],p[A,1])]*r[A][7][8,1]*r[B][4][3,9]*r[C][5][0,11]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B6I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(B,6),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,0],p[C,1],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][3][6,9]*r[C][5][0,11]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B6I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(B,6),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,0],p[C,1],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][3][6,9]*r[C][5][0,11]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B6I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(B,6),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,1],p[C,1],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][3][6,9]*r[C][5][0,11]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B6I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(B,6),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,1],p[C,1],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][3][6,9]*r[C][5][0,11]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B5I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(B,5),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[I,0],p[C,1],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][6][5,9]*r[C][5][0,11]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B5I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(B,5),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[I,0],p[C,1],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][6][5,9]*r[C][5][0,11]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B5I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(B,5),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[I,1],p[C,1],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][6][5,9]*r[C][5][0,11]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B5I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(B,5),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[I,1],p[C,1],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][6][5,9]*r[C][5][0,11]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def hm_A1B9C11(r, h, g, p, nc=0):
    np=len(p)
    hdd = {}
    
    for A in range(nc, np):
        for B in range(nc, np):
            if B in {A}: continue
            for C in range(nc, np):
                if C in {A,B}: continue
                u = tuple(sorted([(A,1),(B,9),(C,11)]))
                
                hd = {}
                for v,hv in _A1B9C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B9C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B9C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B9C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B10C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B9C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B9C11I1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B9C11I2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B9C11I3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C11I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C11I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B9I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B9I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B6C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B6C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B1C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B1C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B2C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B3C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B5C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B2C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B3C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B5C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B10C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B10C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B10C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A5B7C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A5B8C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A6B13C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A6B14C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B9C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B9C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B9C4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B9C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B9C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B9C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B9C4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B9C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B9C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B9C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A15B9C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A15B9C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B9C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B9C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B9C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A4B9C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A4B9C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B1C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B1C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B1C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B2C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B2C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B3C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B3C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B5C4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B2C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B3C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B6C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B13C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B11C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B13C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B14C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B14C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B10C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B7C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B7C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B8C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B8C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _C11I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B1C11I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _C11I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B1C11I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2C11I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C11I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2C11I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C11I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C11I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B3C11I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B5C11I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C11I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B3C11I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B5C11I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B6C11I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B6C11I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A5C11I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A5C11I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14C11I6(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13C11I6(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A6C11I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A6C11I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9C11I1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9C11I2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9C11I3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10C11I1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10C11I2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10C11I3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C11I5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C11I5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A15B9I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A15B9I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B9C15I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B9C15I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B9C2I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B9C3I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B9C4I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B9I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B9C1I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B9I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B9I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B9C2I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B9C3I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B9C4I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B9I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B9C1I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B9I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B9I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A4B9I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A4B9I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B9I1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B9I2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B9I3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B9I1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B9I2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B9I3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B9I4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B9I4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B9I15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B9I15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B11I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B13I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B11I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B13I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B14I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B14I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C14I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C14I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C13I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C13I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C12I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C12I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C15I6(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B7I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B7I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B8I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B8I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C8I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C9I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C7I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C8I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C9I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C7I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C2I1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C3I1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C2I2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C2I3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C3I2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C3I3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1I1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C1I1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B1I1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1I2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1I3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C1I2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C1I3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B1I2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B1I3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B2I1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B3I1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B2I2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B2I3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B3I2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B3I3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C4I5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B10I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B10I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B5I4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B6I15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A15B6C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A15B6C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A15B6(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A15B6C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B1C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B1C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B1C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B1C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B1C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B1C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B1C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B1C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B1C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B3C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B3C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B5C4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B3C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B2C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B2C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B3C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B3C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B2C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B2C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B3C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B3C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B5C4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B5C4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B2C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B3C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B2C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B3C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B10C4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B10C4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A4B5C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A4B5C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A4B5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A4B5C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B10C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B10C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B10C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B10C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B10C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B10C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B1C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B5C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B2C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B3C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B5C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B1C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B5C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B2C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B3C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B5C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B6C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B6C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B6C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B6C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B6C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B6C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B6C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B6C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B6C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A5C4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A5B1C4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A5B2C4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A5B3C4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B7C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B7C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B7C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B7C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B7C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B7C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B8C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B8C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B8C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B8C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B8C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B8C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B1C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B1C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B1C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B1C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B2C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B3C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B2C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B3C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B2C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B3C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B2C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B3C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B11C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B11C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B13C4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B11C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B11C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B11C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B13C4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B11C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B14C4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B14C4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B13C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B13C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B13C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B13C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B13C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B13C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B14C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B14C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B14C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B14C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B14C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B14C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A6C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A6B1C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A6B2C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A6B3C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B7C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B7C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B10C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B8C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B10C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B8C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B1C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B1C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B5C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B2C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B3C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B5C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B2C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B3C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B1C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B1C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B1C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B1C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B2C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B3C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B2C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B3C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B2C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B3C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B2C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B3C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1I12J9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1I14J7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1I12J10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1I14J8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1I11J9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1I13J7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1I11J10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1I13J8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1I9J12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1I7J14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1I10J12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1I8J14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1I9J11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1I7J13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1I10J11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1I8J13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12C2I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12C3I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12C2I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12C3I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12C1I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B1I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12C1I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B1I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B2I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B3I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B5I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B2I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B3I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B5I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11C2I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11C3I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11C2I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11C3I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11C1I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B1I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11C1I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B1I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B2I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B3I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B5I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B2I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B3I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B5I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B6I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B6I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B6I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B6I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14C2I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14C3I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14C2I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14C3I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14C1I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B1I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14C1I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B1I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13C2I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13C3I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13C2I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13C3I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13C1I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B1I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13C1I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B1I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B2I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B3I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B2I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B3I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B2I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B3I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B2I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B3I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14C4I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14C4I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13C4I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13C4I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9C15I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9C15I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10C15I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10C15I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C15I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C15I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C15I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C15I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9C2I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9C3I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9C4I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9C1I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B1I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10C2I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10C3I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10C4I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10C1I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B1I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9C2I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9C3I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9C4I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9C1I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B1I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10C2I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10C3I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10C4I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10C1I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B1I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B2I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B3I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B2I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B3I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B2I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B3I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B2I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B3I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C2I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C3I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C2I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C3I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C1I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B1I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C1I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B1I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C2I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C3I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C2I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C3I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C1I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B1I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C1I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B1I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B2I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B3I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B2I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B3I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B2I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B3I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B2I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B3I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B6I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B6I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B6I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B6I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B5I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B5I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B5I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B5I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                
                hdd[u] = hd
                
    return hdd
    

