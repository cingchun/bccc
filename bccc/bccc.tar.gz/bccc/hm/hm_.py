#!/usr/bin/env python 
# -*- coding: utf-8 -*- 
# 
# Author: Qingchun Wang @ NJU 
# E-mail: qingchun720@foxmail.com 
# 


import numpy
from bccc.pub import sign,dei


def _(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([]))
    hv = 0.0
    
    hv += sum(h[p[I,0],p[I,0]]*r[I][9][0,0] for I in range(np) if I not in {})
    hv += sum(h[p[I,0],p[I,0]]*r[I][24][0,0] for I in range(np) if I not in {})
    hv += sum(h[p[I,1],p[I,1]]*r[I][39][0,0] for I in range(np) if I not in {})
    hv += sum(h[p[I,1],p[I,1]]*r[I][54][0,0] for I in range(np) if I not in {})
    hv += sum(g[dei(p[I,0],p[I,0],p[I,0],p[I,0])]*r[I][194][0,0] for I in range(np) if I not in {})
    hv += sum(g[dei(p[I,0],p[I,1],p[I,0],p[I,1])]*r[I][199][0,0] for I in range(np) if I not in {})
    hv += sum(g[dei(p[I,1],p[I,0],p[I,1],p[I,0])]*r[I][274][0,0] for I in range(np) if I not in {})
    hv += sum(g[dei(p[I,1],p[I,1],p[I,1],p[I,1])]*r[I][279][0,0] for I in range(np) if I not in {})
    hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][9][0,0]*r[J][9][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][24][0,0]*r[J][24][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][9][0,0]*r[J][24][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][9][0,0]*r[J][39][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][24][0,0]*r[J][54][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][9][0,0]*r[J][54][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][39][0,0]*r[J][9][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][54][0,0]*r[J][24][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][39][0,0]*r[J][24][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][39][0,0]*r[J][39][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][54][0,0]*r[J][54][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][39][0,0]*r[J][54][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,0])]*r[I][9][0,0]*r[J][9][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,0])]*r[I][24][0,0]*r[J][24][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,0])]*r[I][9][0,0]*r[J][39][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,0])]*r[I][24][0,0]*r[J][54][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,1])]*r[I][39][0,0]*r[J][9][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,1])]*r[I][54][0,0]*r[J][24][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,1])]*r[I][39][0,0]*r[J][39][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,1])]*r[I][54][0,0]*r[J][54][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,0],p[J,0])]*r[I][9][0,0]*r[J][9][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,0],p[J,0])]*r[I][24][0,0]*r[J][24][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,1],p[J,0])]*r[I][39][0,0]*r[J][9][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,1],p[J,0])]*r[I][54][0,0]*r[J][24][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,0],p[J,1])]*r[I][9][0,0]*r[J][39][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,0],p[J,1])]*r[I][24][0,0]*r[J][54][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,1],p[J,1])]*r[I][39][0,0]*r[J][39][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,1],p[J,1])]*r[I][54][0,0]*r[J][54][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[I][9][0,0]*r[J][9][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[I][24][0,0]*r[J][24][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[I][24][0,0]*r[J][9][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[I][39][0,0]*r[J][9][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[I][54][0,0]*r[J][24][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[I][54][0,0]*r[J][9][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[I][9][0,0]*r[J][39][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[I][24][0,0]*r[J][54][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[I][24][0,0]*r[J][39][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[I][39][0,0]*r[J][39][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[I][54][0,0]*r[J][54][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[I][54][0,0]*r[J][39][0,0] for I in range(np) if I not in {} for J in range(np) if J not in {I})
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _I1(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        v = tuple(sorted([(I,1)]))
        hv = 0.0
        
        hv += h[p[I,0],p[I,0]]*r[I][9][1,0]
        hv += h[p[I,0],p[I,0]]*r[I][24][1,0]
        hv += h[p[I,1],p[I,1]]*r[I][39][1,0]
        hv += h[p[I,1],p[I,1]]*r[I][54][1,0]
        hv += g[dei(p[I,0],p[I,0],p[I,0],p[I,0])]*r[I][194][1,0]
        hv += g[dei(p[I,0],p[I,1],p[I,0],p[I,1])]*r[I][199][1,0]
        hv += g[dei(p[I,1],p[I,0],p[I,1],p[I,0])]*r[I][274][1,0]
        hv += g[dei(p[I,1],p[I,1],p[I,1],p[I,1])]*r[I][279][1,0]
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[J][9][0,0]*r[I][9][1,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[J][24][0,0]*r[I][24][1,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[J][9][0,0]*r[I][24][1,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[J][9][0,0]*r[I][39][1,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[J][24][0,0]*r[I][54][1,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[J][9][0,0]*r[I][54][1,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[J][39][0,0]*r[I][9][1,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[J][54][0,0]*r[I][24][1,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[J][39][0,0]*r[I][24][1,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[J][39][0,0]*r[I][39][1,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[J][54][0,0]*r[I][54][1,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[J][39][0,0]*r[I][54][1,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,0],p[J,0])]*r[J][9][0,0]*r[I][9][1,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,0],p[J,0])]*r[J][24][0,0]*r[I][24][1,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,1],p[J,0])]*r[J][9][0,0]*r[I][39][1,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,1],p[J,0])]*r[J][24][0,0]*r[I][54][1,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,0],p[J,1])]*r[J][39][0,0]*r[I][9][1,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,0],p[J,1])]*r[J][54][0,0]*r[I][24][1,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,1],p[J,1])]*r[J][39][0,0]*r[I][39][1,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,1],p[J,1])]*r[J][54][0,0]*r[I][54][1,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,0])]*r[J][9][0,0]*r[I][9][1,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,0])]*r[J][24][0,0]*r[I][24][1,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,0])]*r[J][39][0,0]*r[I][9][1,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,0])]*r[J][54][0,0]*r[I][24][1,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,1])]*r[J][9][0,0]*r[I][39][1,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,1])]*r[J][24][0,0]*r[I][54][1,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,1])]*r[J][39][0,0]*r[I][39][1,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,1])]*r[J][54][0,0]*r[I][54][1,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[J][9][0,0]*r[I][9][1,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[J][24][0,0]*r[I][24][1,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[J][24][0,0]*r[I][9][1,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[J][39][0,0]*r[I][9][1,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[J][54][0,0]*r[I][24][1,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[J][54][0,0]*r[I][9][1,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[J][9][0,0]*r[I][39][1,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[J][24][0,0]*r[I][54][1,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[J][24][0,0]*r[I][39][1,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[J][39][0,0]*r[I][39][1,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[J][54][0,0]*r[I][54][1,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[J][54][0,0]*r[I][39][1,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][9][1,0]*r[J][9][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][24][1,0]*r[J][24][0,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][9][1,0]*r[J][24][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][9][1,0]*r[J][39][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][24][1,0]*r[J][54][0,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][9][1,0]*r[J][54][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][39][1,0]*r[J][9][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][54][1,0]*r[J][24][0,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][39][1,0]*r[J][24][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][39][1,0]*r[J][39][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][54][1,0]*r[J][54][0,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][39][1,0]*r[J][54][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,0])]*r[I][9][1,0]*r[J][9][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,0])]*r[I][24][1,0]*r[J][24][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,0])]*r[I][9][1,0]*r[J][39][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,0])]*r[I][24][1,0]*r[J][54][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,1])]*r[I][39][1,0]*r[J][9][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,1])]*r[I][54][1,0]*r[J][24][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,1])]*r[I][39][1,0]*r[J][39][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,1])]*r[I][54][1,0]*r[J][54][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,0],p[J,0])]*r[I][9][1,0]*r[J][9][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,0],p[J,0])]*r[I][24][1,0]*r[J][24][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,1],p[J,0])]*r[I][39][1,0]*r[J][9][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,1],p[J,0])]*r[I][54][1,0]*r[J][24][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,0],p[J,1])]*r[I][9][1,0]*r[J][39][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,0],p[J,1])]*r[I][24][1,0]*r[J][54][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,1],p[J,1])]*r[I][39][1,0]*r[J][39][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,1],p[J,1])]*r[I][54][1,0]*r[J][54][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[I][9][1,0]*r[J][9][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][24][0,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][9][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[I][39][1,0]*r[J][9][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][24][0,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][9][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[I][9][1,0]*r[J][39][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][54][0,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][39][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[I][39][1,0]*r[J][39][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][54][0,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][39][0,0] for J in range(np) if J not in {I})
        
        hd[v] = hd.get(v,0.0)+hv
        
    return hd
    
def _I2(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        v = tuple(sorted([(I,2)]))
        hv = 0.0
        
        hv += h[p[I,0],p[I,1]]*r[I][15][2,0]
        hv += h[p[I,0],p[I,1]]*r[I][30][2,0]
        hv += h[p[I,1],p[I,0]]*r[I][33][2,0]
        hv += h[p[I,1],p[I,0]]*r[I][48][2,0]
        hv += g[dei(p[I,0],p[I,0],p[I,1],p[I,0])]*r[I][210][2,0]
        hv += g[dei(p[I,0],p[I,1],p[I,1],p[I,1])]*r[I][215][2,0]
        hv += g[dei(p[I,1],p[I,0],p[I,0],p[I,0])]*r[I][258][2,0]
        hv += g[dei(p[I,1],p[I,1],p[I,0],p[I,1])]*r[I][263][2,0]
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,1])]*r[J][9][0,0]*r[I][15][2,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,1])]*r[J][24][0,0]*r[I][30][2,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,0],p[I,1])]*r[J][9][0,0]*r[I][30][2,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,0])]*r[J][9][0,0]*r[I][33][2,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,0])]*r[J][24][0,0]*r[I][48][2,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,1],p[I,0])]*r[J][9][0,0]*r[I][48][2,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,1])]*r[J][39][0,0]*r[I][15][2,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,1])]*r[J][54][0,0]*r[I][30][2,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,0],p[I,1])]*r[J][39][0,0]*r[I][30][2,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,0])]*r[J][39][0,0]*r[I][33][2,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,0])]*r[J][54][0,0]*r[I][48][2,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,1],p[I,0])]*r[J][39][0,0]*r[I][48][2,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,0],p[J,0])]*r[J][9][0,0]*r[I][15][2,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,0],p[J,0])]*r[J][24][0,0]*r[I][30][2,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,1],p[J,0])]*r[J][9][0,0]*r[I][33][2,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,1],p[J,0])]*r[J][24][0,0]*r[I][48][2,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,0],p[J,1])]*r[J][39][0,0]*r[I][15][2,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,0],p[J,1])]*r[J][54][0,0]*r[I][30][2,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,1],p[J,1])]*r[J][39][0,0]*r[I][33][2,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,1],p[J,1])]*r[J][54][0,0]*r[I][48][2,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,1])]*r[J][9][0,0]*r[I][15][2,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,1])]*r[J][24][0,0]*r[I][30][2,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,1])]*r[J][39][0,0]*r[I][15][2,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,1])]*r[J][54][0,0]*r[I][30][2,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,0])]*r[J][9][0,0]*r[I][33][2,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,0])]*r[J][24][0,0]*r[I][48][2,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,0])]*r[J][39][0,0]*r[I][33][2,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,0])]*r[J][54][0,0]*r[I][48][2,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[J][9][0,0]*r[I][15][2,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[J][24][0,0]*r[I][30][2,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[J][24][0,0]*r[I][15][2,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[J][39][0,0]*r[I][15][2,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[J][54][0,0]*r[I][30][2,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[J][54][0,0]*r[I][15][2,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,0],p[J,0])]*r[J][9][0,0]*r[I][33][2,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,0],p[J,0])]*r[J][24][0,0]*r[I][48][2,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[I,1],p[I,0],p[J,0],p[J,0])]*r[J][24][0,0]*r[I][33][2,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,1],p[J,1])]*r[J][39][0,0]*r[I][33][2,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,1],p[J,1])]*r[J][54][0,0]*r[I][48][2,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[I,1],p[I,0],p[J,1],p[J,1])]*r[J][54][0,0]*r[I][33][2,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][15][2,0]*r[J][9][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][30][2,0]*r[J][24][0,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][15][2,0]*r[J][24][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][15][2,0]*r[J][39][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][30][2,0]*r[J][54][0,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][15][2,0]*r[J][54][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,0],p[J,0])]*r[I][33][2,0]*r[J][9][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,0],p[J,0])]*r[I][48][2,0]*r[J][24][0,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[I,1],p[I,0],p[J,0],p[J,0])]*r[I][33][2,0]*r[J][24][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,1],p[J,1])]*r[I][33][2,0]*r[J][39][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,1],p[J,1])]*r[I][48][2,0]*r[J][54][0,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[I,1],p[I,0],p[J,1],p[J,1])]*r[I][33][2,0]*r[J][54][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,1])]*r[I][15][2,0]*r[J][9][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,1])]*r[I][30][2,0]*r[J][24][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,1])]*r[I][15][2,0]*r[J][39][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,1])]*r[I][30][2,0]*r[J][54][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,0])]*r[I][33][2,0]*r[J][9][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,0])]*r[I][48][2,0]*r[J][24][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,0])]*r[I][33][2,0]*r[J][39][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,0])]*r[I][48][2,0]*r[J][54][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,0],p[J,0])]*r[I][15][2,0]*r[J][9][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,0],p[J,0])]*r[I][30][2,0]*r[J][24][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,1],p[J,0])]*r[I][33][2,0]*r[J][9][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,1],p[J,0])]*r[I][48][2,0]*r[J][24][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,0],p[J,1])]*r[I][15][2,0]*r[J][39][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,0],p[J,1])]*r[I][30][2,0]*r[J][54][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,1],p[J,1])]*r[I][33][2,0]*r[J][39][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,1],p[J,1])]*r[I][48][2,0]*r[J][54][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,1])]*r[I][15][2,0]*r[J][9][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][24][0,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][9][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,0])]*r[I][33][2,0]*r[J][9][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][24][0,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][9][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,1])]*r[I][15][2,0]*r[J][39][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][54][0,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][39][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,0])]*r[I][33][2,0]*r[J][39][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][54][0,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][39][0,0] for J in range(np) if J not in {I})
        
        hd[v] = hd.get(v,0.0)+hv
        
    return hd
    
def _I3(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        v = tuple(sorted([(I,3)]))
        hv = 0.0
        
        hv += h[p[I,0],p[I,1]]*r[I][15][3,0]
        hv += h[p[I,0],p[I,1]]*r[I][30][3,0]
        hv += h[p[I,1],p[I,0]]*r[I][33][3,0]
        hv += h[p[I,1],p[I,0]]*r[I][48][3,0]
        hv += g[dei(p[I,0],p[I,0],p[I,1],p[I,0])]*r[I][210][3,0]
        hv += g[dei(p[I,0],p[I,1],p[I,1],p[I,1])]*r[I][215][3,0]
        hv += g[dei(p[I,1],p[I,0],p[I,0],p[I,0])]*r[I][258][3,0]
        hv += g[dei(p[I,1],p[I,1],p[I,0],p[I,1])]*r[I][263][3,0]
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,1])]*r[J][9][0,0]*r[I][15][3,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,1])]*r[J][24][0,0]*r[I][30][3,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,0],p[I,1])]*r[J][9][0,0]*r[I][30][3,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,0])]*r[J][9][0,0]*r[I][33][3,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,0])]*r[J][24][0,0]*r[I][48][3,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,1],p[I,0])]*r[J][9][0,0]*r[I][48][3,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,1])]*r[J][39][0,0]*r[I][15][3,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,1])]*r[J][54][0,0]*r[I][30][3,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,0],p[I,1])]*r[J][39][0,0]*r[I][30][3,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,0])]*r[J][39][0,0]*r[I][33][3,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,0])]*r[J][54][0,0]*r[I][48][3,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,1],p[I,0])]*r[J][39][0,0]*r[I][48][3,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,0],p[J,0])]*r[J][9][0,0]*r[I][15][3,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,0],p[J,0])]*r[J][24][0,0]*r[I][30][3,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,1],p[J,0])]*r[J][9][0,0]*r[I][33][3,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,1],p[J,0])]*r[J][24][0,0]*r[I][48][3,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,0],p[J,1])]*r[J][39][0,0]*r[I][15][3,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,0],p[J,1])]*r[J][54][0,0]*r[I][30][3,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,1],p[J,1])]*r[J][39][0,0]*r[I][33][3,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,1],p[J,1])]*r[J][54][0,0]*r[I][48][3,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,1])]*r[J][9][0,0]*r[I][15][3,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,1])]*r[J][24][0,0]*r[I][30][3,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,1])]*r[J][39][0,0]*r[I][15][3,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,1])]*r[J][54][0,0]*r[I][30][3,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,0])]*r[J][9][0,0]*r[I][33][3,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,0])]*r[J][24][0,0]*r[I][48][3,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,0])]*r[J][39][0,0]*r[I][33][3,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,0])]*r[J][54][0,0]*r[I][48][3,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[J][9][0,0]*r[I][15][3,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[J][24][0,0]*r[I][30][3,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[J][24][0,0]*r[I][15][3,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[J][39][0,0]*r[I][15][3,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[J][54][0,0]*r[I][30][3,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[J][54][0,0]*r[I][15][3,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,0],p[J,0])]*r[J][9][0,0]*r[I][33][3,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,0],p[J,0])]*r[J][24][0,0]*r[I][48][3,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[I,1],p[I,0],p[J,0],p[J,0])]*r[J][24][0,0]*r[I][33][3,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,1],p[J,1])]*r[J][39][0,0]*r[I][33][3,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,1],p[J,1])]*r[J][54][0,0]*r[I][48][3,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[I,1],p[I,0],p[J,1],p[J,1])]*r[J][54][0,0]*r[I][33][3,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][15][3,0]*r[J][9][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][30][3,0]*r[J][24][0,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][15][3,0]*r[J][24][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][15][3,0]*r[J][39][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][30][3,0]*r[J][54][0,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][15][3,0]*r[J][54][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,0],p[J,0])]*r[I][33][3,0]*r[J][9][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,0],p[J,0])]*r[I][48][3,0]*r[J][24][0,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[I,1],p[I,0],p[J,0],p[J,0])]*r[I][33][3,0]*r[J][24][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,1],p[J,1])]*r[I][33][3,0]*r[J][39][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,1],p[J,1])]*r[I][48][3,0]*r[J][54][0,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[I,1],p[I,0],p[J,1],p[J,1])]*r[I][33][3,0]*r[J][54][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,1])]*r[I][15][3,0]*r[J][9][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,1])]*r[I][30][3,0]*r[J][24][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,1])]*r[I][15][3,0]*r[J][39][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,1])]*r[I][30][3,0]*r[J][54][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,0])]*r[I][33][3,0]*r[J][9][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,0])]*r[I][48][3,0]*r[J][24][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,0])]*r[I][33][3,0]*r[J][39][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,0])]*r[I][48][3,0]*r[J][54][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,0],p[J,0])]*r[I][15][3,0]*r[J][9][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,0],p[J,0])]*r[I][30][3,0]*r[J][24][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,1],p[J,0])]*r[I][33][3,0]*r[J][9][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,1],p[J,0])]*r[I][48][3,0]*r[J][24][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,0],p[J,1])]*r[I][15][3,0]*r[J][39][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,0],p[J,1])]*r[I][30][3,0]*r[J][54][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,1],p[J,1])]*r[I][33][3,0]*r[J][39][0,0] for J in range(np) if J not in {I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,1],p[J,1])]*r[I][48][3,0]*r[J][54][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,1])]*r[I][15][3,0]*r[J][9][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][24][0,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][9][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,0])]*r[I][33][3,0]*r[J][9][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][24][0,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][9][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,1])]*r[I][15][3,0]*r[J][39][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][54][0,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][39][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,0])]*r[I][33][3,0]*r[J][39][0,0] for J in range(np) if J not in {I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][54][0,0] for J in range(np) if J not in {I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][39][0,0] for J in range(np) if J not in {I})
        
        hd[v] = hd.get(v,0.0)+hv
        
    return hd
    
def _I12J9(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            v = tuple(sorted([(I,12),(J,9)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*h[p[I,0],p[J,0]]*r[I][0][12,0]*r[J][1][9,0]
            hv += -1/4*g[dei(p[I,0],p[I,1],p[I,1],p[J,0])]*r[I][76][12,0]*r[J][1][9,0]
            hv += -1/4*g[dei(p[I,1],p[I,1],p[I,0],p[J,0])]*r[I][124][12,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[I,0],p[J,0],p[I,1],p[I,1])]*r[I][76][12,0]*r[J][1][9,0]
            hv += 1/2*g[dei(p[I,0],p[J,0],p[I,1],p[I,1])]*r[I][86][12,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[I,1],p[J,0],p[I,0],p[I,1])]*r[I][124][12,0]*r[J][1][9,0]
            hv += 1/2*g[dei(p[I,1],p[J,0],p[I,1],p[I,0])]*r[I][146][12,0]*r[J][1][9,0]
            hv += 1/2*g[dei(p[I,0],p[J,0],p[J,0],p[J,0])]*r[I][0][12,0]*r[J][97][9,0]
            hv += 1/2*g[dei(p[I,0],p[J,1],p[J,0],p[J,1])]*r[I][0][12,0]*r[J][117][9,0]
            hv += sum(1/12*g[dei(p[K,0],p[K,0],p[I,0],p[J,0])]*r[K][9][0,0]*r[I][0][12,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[K,1],p[I,0],p[J,0])]*r[K][39][0,0]*r[I][0][12,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[J,0],p[I,0],p[K,0])]*r[K][9][0,0]*r[I][0][12,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[J,0],p[I,0],p[K,1])]*r[K][39][0,0]*r[I][0][12,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,0],p[K,0],p[K,0],p[J,0])]*r[K][9][0,0]*r[I][0][12,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,0],p[K,1],p[K,1],p[J,0])]*r[K][39][0,0]*r[I][0][12,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,0],p[J,0],p[K,0],p[K,0])]*r[K][9][0,0]*r[I][0][12,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,0])]*r[K][24][0,0]*r[I][0][12,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,0],p[J,0],p[K,1],p[K,1])]*r[K][39][0,0]*r[I][0][12,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[I,0],p[J,0],p[K,1],p[K,1])]*r[K][54][0,0]*r[I][0][12,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,0],p[K,0],p[K,0],p[J,0])]*r[I][0][12,0]*r[K][9][0,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,0],p[K,1],p[K,1],p[J,0])]*r[I][0][12,0]*r[K][39][0,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,0],p[J,0],p[K,0],p[K,0])]*r[I][0][12,0]*r[K][9][0,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,0])]*r[I][0][12,0]*r[K][24][0,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,0],p[J,0],p[K,1],p[K,1])]*r[I][0][12,0]*r[K][39][0,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[I,0],p[J,0],p[K,1],p[K,1])]*r[I][0][12,0]*r[K][54][0,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[K,0],p[I,0],p[J,0])]*r[I][0][12,0]*r[K][9][0,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[K,1],p[I,0],p[J,0])]*r[I][0][12,0]*r[K][39][0,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[J,0],p[I,0],p[K,0])]*r[I][0][12,0]*r[K][9][0,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[J,0],p[I,0],p[K,1])]*r[I][0][12,0]*r[K][39][0,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,0],p[J,0],p[K,0],p[K,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,0],p[J,0],p[K,1],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[I,0],p[J,0],p[K,1],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,0],p[K,0],p[K,0],p[J,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,0],p[K,1],p[K,1],p[J,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[J,0],p[I,0],p[K,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[J,0],p[I,0],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[K,0],p[I,0],p[J,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[K,1],p[I,0],p[J,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    return hd
    
def _I14J7(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            v = tuple(sorted([(I,14),(J,7)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*h[p[I,0],p[J,0]]*r[I][2][14,0]*r[J][3][7,0]
            hv += -1/4*g[dei(p[I,0],p[I,1],p[I,1],p[J,0])]*r[I][118][14,0]*r[J][3][7,0]
            hv += -1/4*g[dei(p[I,1],p[I,1],p[I,0],p[J,0])]*r[I][166][14,0]*r[J][3][7,0]
            hv += -1/2*g[dei(p[I,1],p[I,1],p[I,0],p[J,0])]*r[I][132][14,0]*r[J][3][7,0]
            hv += -1/2*g[dei(p[I,1],p[I,0],p[I,1],p[J,0])]*r[I][144][14,0]*r[J][3][7,0]
            hv += 1/4*g[dei(p[I,0],p[J,0],p[I,1],p[I,1])]*r[I][118][14,0]*r[J][3][7,0]
            hv += 1/4*g[dei(p[I,1],p[J,0],p[I,0],p[I,1])]*r[I][166][14,0]*r[J][3][7,0]
            hv += -1/2*g[dei(p[J,0],p[J,0],p[I,0],p[J,0])]*r[I][2][14,0]*r[J][65][7,0]
            hv += -1/2*g[dei(p[J,0],p[J,1],p[I,0],p[J,1])]*r[I][2][14,0]*r[J][85][7,0]
            hv += sum(1/12*g[dei(p[K,0],p[K,0],p[I,0],p[J,0])]*r[K][24][0,0]*r[I][2][14,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[K,0],p[K,0],p[I,0],p[J,0])]*r[K][9][0,0]*r[I][2][14,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[K,1],p[I,0],p[J,0])]*r[K][54][0,0]*r[I][2][14,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[K,1],p[K,1],p[I,0],p[J,0])]*r[K][39][0,0]*r[I][2][14,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[J,0],p[I,0],p[K,0])]*r[K][24][0,0]*r[I][2][14,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[J,0],p[I,0],p[K,1])]*r[K][54][0,0]*r[I][2][14,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,0],p[K,0],p[K,0],p[J,0])]*r[K][24][0,0]*r[I][2][14,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,0],p[K,1],p[K,1],p[J,0])]*r[K][54][0,0]*r[I][2][14,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,0],p[J,0],p[K,0],p[K,0])]*r[K][24][0,0]*r[I][2][14,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,0],p[J,0],p[K,1],p[K,1])]*r[K][54][0,0]*r[I][2][14,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,0],p[K,0],p[K,0],p[J,0])]*r[I][2][14,0]*r[K][24][0,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,0],p[K,1],p[K,1],p[J,0])]*r[I][2][14,0]*r[K][54][0,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,0],p[J,0],p[K,0],p[K,0])]*r[I][2][14,0]*r[K][24][0,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,0],p[J,0],p[K,1],p[K,1])]*r[I][2][14,0]*r[K][54][0,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[K,0],p[I,0],p[J,0])]*r[I][2][14,0]*r[K][24][0,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[K,0],p[K,0],p[I,0],p[J,0])]*r[I][2][14,0]*r[K][9][0,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[K,1],p[I,0],p[J,0])]*r[I][2][14,0]*r[K][54][0,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[K,1],p[K,1],p[I,0],p[J,0])]*r[I][2][14,0]*r[K][39][0,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[J,0],p[I,0],p[K,0])]*r[I][2][14,0]*r[K][24][0,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[J,0],p[I,0],p[K,1])]*r[I][2][14,0]*r[K][54][0,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,0],p[J,0],p[K,0],p[K,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,0],p[J,0],p[K,1],p[K,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,0],p[K,0],p[K,0],p[J,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,0],p[K,1],p[K,1],p[J,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[J,0],p[I,0],p[K,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[J,0],p[I,0],p[K,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[K,0],p[I,0],p[J,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[K,0],p[K,0],p[I,0],p[J,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[K,1],p[I,0],p[J,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[K,1],p[K,1],p[I,0],p[J,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    return hd
    
def _I12J10(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            v = tuple(sorted([(I,12),(J,10)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*h[p[I,0],p[J,1]]*r[I][0][12,0]*r[J][5][10,0]
            hv += -1/4*g[dei(p[I,0],p[I,1],p[I,1],p[J,1])]*r[I][76][12,0]*r[J][5][10,0]
            hv += -1/4*g[dei(p[I,1],p[I,1],p[I,0],p[J,1])]*r[I][124][12,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[I,0],p[J,1],p[I,1],p[I,1])]*r[I][76][12,0]*r[J][5][10,0]
            hv += 1/2*g[dei(p[I,0],p[J,1],p[I,1],p[I,1])]*r[I][86][12,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[I,1],p[J,1],p[I,0],p[I,1])]*r[I][124][12,0]*r[J][5][10,0]
            hv += 1/2*g[dei(p[I,1],p[J,1],p[I,1],p[I,0])]*r[I][146][12,0]*r[J][5][10,0]
            hv += 1/2*g[dei(p[I,0],p[J,0],p[J,1],p[J,0])]*r[I][0][12,0]*r[J][161][10,0]
            hv += 1/2*g[dei(p[I,0],p[J,1],p[J,1],p[J,1])]*r[I][0][12,0]*r[J][181][10,0]
            hv += sum(1/12*g[dei(p[K,0],p[K,0],p[I,0],p[J,1])]*r[K][9][0,0]*r[I][0][12,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[K,1],p[I,0],p[J,1])]*r[K][39][0,0]*r[I][0][12,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[J,1],p[I,0],p[K,0])]*r[K][9][0,0]*r[I][0][12,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[J,1],p[I,0],p[K,1])]*r[K][39][0,0]*r[I][0][12,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,0],p[K,0],p[K,0],p[J,1])]*r[K][9][0,0]*r[I][0][12,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,0],p[K,1],p[K,1],p[J,1])]*r[K][39][0,0]*r[I][0][12,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,0],p[J,1],p[K,0],p[K,0])]*r[K][9][0,0]*r[I][0][12,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,0])]*r[K][24][0,0]*r[I][0][12,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,0],p[J,1],p[K,1],p[K,1])]*r[K][39][0,0]*r[I][0][12,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[I,0],p[J,1],p[K,1],p[K,1])]*r[K][54][0,0]*r[I][0][12,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,0],p[K,0],p[K,0],p[J,1])]*r[I][0][12,0]*r[K][9][0,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,0],p[K,1],p[K,1],p[J,1])]*r[I][0][12,0]*r[K][39][0,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,0],p[J,1],p[K,0],p[K,0])]*r[I][0][12,0]*r[K][9][0,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,0])]*r[I][0][12,0]*r[K][24][0,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,0],p[J,1],p[K,1],p[K,1])]*r[I][0][12,0]*r[K][39][0,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[I,0],p[J,1],p[K,1],p[K,1])]*r[I][0][12,0]*r[K][54][0,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[K,0],p[I,0],p[J,1])]*r[I][0][12,0]*r[K][9][0,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[K,1],p[I,0],p[J,1])]*r[I][0][12,0]*r[K][39][0,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[J,1],p[I,0],p[K,0])]*r[I][0][12,0]*r[K][9][0,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[J,1],p[I,0],p[K,1])]*r[I][0][12,0]*r[K][39][0,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,0],p[J,1],p[K,0],p[K,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,0],p[J,1],p[K,1],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[I,0],p[J,1],p[K,1],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,0],p[K,0],p[K,0],p[J,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,0],p[K,1],p[K,1],p[J,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[J,1],p[I,0],p[K,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[J,1],p[I,0],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[K,0],p[I,0],p[J,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[K,1],p[I,0],p[J,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    return hd
    
def _I14J8(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            v = tuple(sorted([(I,14),(J,8)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*h[p[I,0],p[J,1]]*r[I][2][14,0]*r[J][7][8,0]
            hv += -1/4*g[dei(p[I,0],p[I,1],p[I,1],p[J,1])]*r[I][118][14,0]*r[J][7][8,0]
            hv += -1/4*g[dei(p[I,1],p[I,1],p[I,0],p[J,1])]*r[I][166][14,0]*r[J][7][8,0]
            hv += -1/2*g[dei(p[I,1],p[I,1],p[I,0],p[J,1])]*r[I][132][14,0]*r[J][7][8,0]
            hv += -1/2*g[dei(p[I,1],p[I,0],p[I,1],p[J,1])]*r[I][144][14,0]*r[J][7][8,0]
            hv += 1/4*g[dei(p[I,0],p[J,1],p[I,1],p[I,1])]*r[I][118][14,0]*r[J][7][8,0]
            hv += 1/4*g[dei(p[I,1],p[J,1],p[I,0],p[I,1])]*r[I][166][14,0]*r[J][7][8,0]
            hv += -1/2*g[dei(p[J,1],p[J,0],p[I,0],p[J,0])]*r[I][2][14,0]*r[J][129][8,0]
            hv += -1/2*g[dei(p[J,1],p[J,1],p[I,0],p[J,1])]*r[I][2][14,0]*r[J][149][8,0]
            hv += sum(1/12*g[dei(p[K,0],p[K,0],p[I,0],p[J,1])]*r[K][24][0,0]*r[I][2][14,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[K,0],p[K,0],p[I,0],p[J,1])]*r[K][9][0,0]*r[I][2][14,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[K,1],p[I,0],p[J,1])]*r[K][54][0,0]*r[I][2][14,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[K,1],p[K,1],p[I,0],p[J,1])]*r[K][39][0,0]*r[I][2][14,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[J,1],p[I,0],p[K,0])]*r[K][24][0,0]*r[I][2][14,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[J,1],p[I,0],p[K,1])]*r[K][54][0,0]*r[I][2][14,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,0],p[K,0],p[K,0],p[J,1])]*r[K][24][0,0]*r[I][2][14,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,0],p[K,1],p[K,1],p[J,1])]*r[K][54][0,0]*r[I][2][14,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,0],p[J,1],p[K,0],p[K,0])]*r[K][24][0,0]*r[I][2][14,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,0],p[J,1],p[K,1],p[K,1])]*r[K][54][0,0]*r[I][2][14,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,0],p[K,0],p[K,0],p[J,1])]*r[I][2][14,0]*r[K][24][0,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,0],p[K,1],p[K,1],p[J,1])]*r[I][2][14,0]*r[K][54][0,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,0],p[J,1],p[K,0],p[K,0])]*r[I][2][14,0]*r[K][24][0,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,0],p[J,1],p[K,1],p[K,1])]*r[I][2][14,0]*r[K][54][0,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[K,0],p[I,0],p[J,1])]*r[I][2][14,0]*r[K][24][0,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[K,0],p[K,0],p[I,0],p[J,1])]*r[I][2][14,0]*r[K][9][0,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[K,1],p[I,0],p[J,1])]*r[I][2][14,0]*r[K][54][0,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[K,1],p[K,1],p[I,0],p[J,1])]*r[I][2][14,0]*r[K][39][0,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[J,1],p[I,0],p[K,0])]*r[I][2][14,0]*r[K][24][0,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[J,1],p[I,0],p[K,1])]*r[I][2][14,0]*r[K][54][0,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,0],p[J,1],p[K,0],p[K,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,0],p[J,1],p[K,1],p[K,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,0],p[K,0],p[K,0],p[J,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,0],p[K,1],p[K,1],p[J,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[J,1],p[I,0],p[K,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[J,1],p[I,0],p[K,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[K,0],p[I,0],p[J,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[K,0],p[K,0],p[I,0],p[J,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[K,1],p[I,0],p[J,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[K,1],p[K,1],p[I,0],p[J,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    return hd
    
def _I11J9(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            v = tuple(sorted([(I,11),(J,9)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*h[p[I,1],p[J,0]]*r[I][4][11,0]*r[J][1][9,0]
            hv += -1/4*g[dei(p[I,0],p[I,0],p[I,1],p[J,0])]*r[I][72][11,0]*r[J][1][9,0]
            hv += -1/4*g[dei(p[I,1],p[I,0],p[I,0],p[J,0])]*r[I][120][11,0]*r[J][1][9,0]
            hv += 1/2*g[dei(p[I,0],p[J,0],p[I,0],p[I,1])]*r[I][70][11,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[I,0],p[J,0],p[I,1],p[I,0])]*r[I][72][11,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[I,1],p[J,0],p[I,0],p[I,0])]*r[I][120][11,0]*r[J][1][9,0]
            hv += 1/2*g[dei(p[I,1],p[J,0],p[I,0],p[I,0])]*r[I][130][11,0]*r[J][1][9,0]
            hv += 1/2*g[dei(p[I,1],p[J,0],p[J,0],p[J,0])]*r[I][4][11,0]*r[J][97][9,0]
            hv += 1/2*g[dei(p[I,1],p[J,1],p[J,0],p[J,1])]*r[I][4][11,0]*r[J][117][9,0]
            hv += sum(1/12*g[dei(p[K,0],p[K,0],p[I,1],p[J,0])]*r[K][9][0,0]*r[I][4][11,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[K,1],p[I,1],p[J,0])]*r[K][39][0,0]*r[I][4][11,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[J,0],p[I,1],p[K,0])]*r[K][9][0,0]*r[I][4][11,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[J,0],p[I,1],p[K,1])]*r[K][39][0,0]*r[I][4][11,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,1],p[K,0],p[K,0],p[J,0])]*r[K][9][0,0]*r[I][4][11,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,1],p[K,1],p[K,1],p[J,0])]*r[K][39][0,0]*r[I][4][11,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,1],p[J,0],p[K,0],p[K,0])]*r[K][9][0,0]*r[I][4][11,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,0])]*r[K][24][0,0]*r[I][4][11,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,1],p[J,0],p[K,1],p[K,1])]*r[K][39][0,0]*r[I][4][11,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[I,1],p[J,0],p[K,1],p[K,1])]*r[K][54][0,0]*r[I][4][11,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,1],p[K,0],p[K,0],p[J,0])]*r[I][4][11,0]*r[K][9][0,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,1],p[K,1],p[K,1],p[J,0])]*r[I][4][11,0]*r[K][39][0,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,1],p[J,0],p[K,0],p[K,0])]*r[I][4][11,0]*r[K][9][0,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,0])]*r[I][4][11,0]*r[K][24][0,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,1],p[J,0],p[K,1],p[K,1])]*r[I][4][11,0]*r[K][39][0,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[I,1],p[J,0],p[K,1],p[K,1])]*r[I][4][11,0]*r[K][54][0,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[K,0],p[I,1],p[J,0])]*r[I][4][11,0]*r[K][9][0,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[K,1],p[I,1],p[J,0])]*r[I][4][11,0]*r[K][39][0,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[J,0],p[I,1],p[K,0])]*r[I][4][11,0]*r[K][9][0,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[J,0],p[I,1],p[K,1])]*r[I][4][11,0]*r[K][39][0,0]*r[J][1][9,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,1],p[J,0],p[K,0],p[K,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,1],p[J,0],p[K,1],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[I,1],p[J,0],p[K,1],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,1],p[K,0],p[K,0],p[J,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,1],p[K,1],p[K,1],p[J,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[J,0],p[I,1],p[K,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[J,0],p[I,1],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[K,0],p[I,1],p[J,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[K,1],p[I,1],p[J,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    return hd
    
def _I13J7(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            v = tuple(sorted([(I,13),(J,7)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*h[p[I,1],p[J,0]]*r[I][6][13,0]*r[J][3][7,0]
            hv += -1/2*g[dei(p[I,0],p[I,1],p[I,0],p[J,0])]*r[I][68][13,0]*r[J][3][7,0]
            hv += -1/4*g[dei(p[I,0],p[I,0],p[I,1],p[J,0])]*r[I][114][13,0]*r[J][3][7,0]
            hv += -1/2*g[dei(p[I,0],p[I,0],p[I,1],p[J,0])]*r[I][80][13,0]*r[J][3][7,0]
            hv += -1/4*g[dei(p[I,1],p[I,0],p[I,0],p[J,0])]*r[I][162][13,0]*r[J][3][7,0]
            hv += 1/4*g[dei(p[I,0],p[J,0],p[I,1],p[I,0])]*r[I][114][13,0]*r[J][3][7,0]
            hv += 1/4*g[dei(p[I,1],p[J,0],p[I,0],p[I,0])]*r[I][162][13,0]*r[J][3][7,0]
            hv += -1/2*g[dei(p[J,0],p[J,0],p[I,1],p[J,0])]*r[I][6][13,0]*r[J][65][7,0]
            hv += -1/2*g[dei(p[J,0],p[J,1],p[I,1],p[J,1])]*r[I][6][13,0]*r[J][85][7,0]
            hv += sum(1/12*g[dei(p[K,0],p[K,0],p[I,1],p[J,0])]*r[K][24][0,0]*r[I][6][13,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[K,0],p[K,0],p[I,1],p[J,0])]*r[K][9][0,0]*r[I][6][13,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[K,1],p[I,1],p[J,0])]*r[K][54][0,0]*r[I][6][13,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[K,1],p[K,1],p[I,1],p[J,0])]*r[K][39][0,0]*r[I][6][13,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[J,0],p[I,1],p[K,0])]*r[K][24][0,0]*r[I][6][13,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[J,0],p[I,1],p[K,1])]*r[K][54][0,0]*r[I][6][13,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,1],p[K,0],p[K,0],p[J,0])]*r[K][24][0,0]*r[I][6][13,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,1],p[K,1],p[K,1],p[J,0])]*r[K][54][0,0]*r[I][6][13,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,1],p[J,0],p[K,0],p[K,0])]*r[K][24][0,0]*r[I][6][13,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,1],p[J,0],p[K,1],p[K,1])]*r[K][54][0,0]*r[I][6][13,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,1],p[K,0],p[K,0],p[J,0])]*r[I][6][13,0]*r[K][24][0,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,1],p[K,1],p[K,1],p[J,0])]*r[I][6][13,0]*r[K][54][0,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,1],p[J,0],p[K,0],p[K,0])]*r[I][6][13,0]*r[K][24][0,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,1],p[J,0],p[K,1],p[K,1])]*r[I][6][13,0]*r[K][54][0,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[K,0],p[I,1],p[J,0])]*r[I][6][13,0]*r[K][24][0,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[K,0],p[K,0],p[I,1],p[J,0])]*r[I][6][13,0]*r[K][9][0,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[K,1],p[I,1],p[J,0])]*r[I][6][13,0]*r[K][54][0,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[K,1],p[K,1],p[I,1],p[J,0])]*r[I][6][13,0]*r[K][39][0,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[J,0],p[I,1],p[K,0])]*r[I][6][13,0]*r[K][24][0,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[J,0],p[I,1],p[K,1])]*r[I][6][13,0]*r[K][54][0,0]*r[J][3][7,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,1],p[J,0],p[K,0],p[K,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,1],p[J,0],p[K,1],p[K,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,1],p[K,0],p[K,0],p[J,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,1],p[K,1],p[K,1],p[J,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[J,0],p[I,1],p[K,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[J,0],p[I,1],p[K,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[K,0],p[I,1],p[J,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[K,0],p[K,0],p[I,1],p[J,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[K,1],p[I,1],p[J,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[K,1],p[K,1],p[I,1],p[J,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    return hd
    
def _I11J10(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            v = tuple(sorted([(I,11),(J,10)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*h[p[I,1],p[J,1]]*r[I][4][11,0]*r[J][5][10,0]
            hv += -1/4*g[dei(p[I,0],p[I,0],p[I,1],p[J,1])]*r[I][72][11,0]*r[J][5][10,0]
            hv += -1/4*g[dei(p[I,1],p[I,0],p[I,0],p[J,1])]*r[I][120][11,0]*r[J][5][10,0]
            hv += 1/2*g[dei(p[I,0],p[J,1],p[I,0],p[I,1])]*r[I][70][11,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[I,0],p[J,1],p[I,1],p[I,0])]*r[I][72][11,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[I,1],p[J,1],p[I,0],p[I,0])]*r[I][120][11,0]*r[J][5][10,0]
            hv += 1/2*g[dei(p[I,1],p[J,1],p[I,0],p[I,0])]*r[I][130][11,0]*r[J][5][10,0]
            hv += 1/2*g[dei(p[I,1],p[J,0],p[J,1],p[J,0])]*r[I][4][11,0]*r[J][161][10,0]
            hv += 1/2*g[dei(p[I,1],p[J,1],p[J,1],p[J,1])]*r[I][4][11,0]*r[J][181][10,0]
            hv += sum(1/12*g[dei(p[K,0],p[K,0],p[I,1],p[J,1])]*r[K][9][0,0]*r[I][4][11,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[K,1],p[I,1],p[J,1])]*r[K][39][0,0]*r[I][4][11,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[J,1],p[I,1],p[K,0])]*r[K][9][0,0]*r[I][4][11,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[J,1],p[I,1],p[K,1])]*r[K][39][0,0]*r[I][4][11,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,1],p[K,0],p[K,0],p[J,1])]*r[K][9][0,0]*r[I][4][11,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,1],p[K,1],p[K,1],p[J,1])]*r[K][39][0,0]*r[I][4][11,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,1],p[J,1],p[K,0],p[K,0])]*r[K][9][0,0]*r[I][4][11,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,0])]*r[K][24][0,0]*r[I][4][11,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,1],p[J,1],p[K,1],p[K,1])]*r[K][39][0,0]*r[I][4][11,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[I,1],p[J,1],p[K,1],p[K,1])]*r[K][54][0,0]*r[I][4][11,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,1],p[K,0],p[K,0],p[J,1])]*r[I][4][11,0]*r[K][9][0,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,1],p[K,1],p[K,1],p[J,1])]*r[I][4][11,0]*r[K][39][0,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,1],p[J,1],p[K,0],p[K,0])]*r[I][4][11,0]*r[K][9][0,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,0])]*r[I][4][11,0]*r[K][24][0,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,1],p[J,1],p[K,1],p[K,1])]*r[I][4][11,0]*r[K][39][0,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[I,1],p[J,1],p[K,1],p[K,1])]*r[I][4][11,0]*r[K][54][0,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[K,0],p[I,1],p[J,1])]*r[I][4][11,0]*r[K][9][0,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[K,1],p[I,1],p[J,1])]*r[I][4][11,0]*r[K][39][0,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[J,1],p[I,1],p[K,0])]*r[I][4][11,0]*r[K][9][0,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[J,1],p[I,1],p[K,1])]*r[I][4][11,0]*r[K][39][0,0]*r[J][5][10,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,1],p[J,1],p[K,0],p[K,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,1],p[J,1],p[K,1],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[I,1],p[J,1],p[K,1],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,1],p[K,0],p[K,0],p[J,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,1],p[K,1],p[K,1],p[J,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[J,1],p[I,1],p[K,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[J,1],p[I,1],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[K,0],p[I,1],p[J,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[K,1],p[I,1],p[J,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    return hd
    
def _I13J8(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            v = tuple(sorted([(I,13),(J,8)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*h[p[I,1],p[J,1]]*r[I][6][13,0]*r[J][7][8,0]
            hv += -1/2*g[dei(p[I,0],p[I,1],p[I,0],p[J,1])]*r[I][68][13,0]*r[J][7][8,0]
            hv += -1/4*g[dei(p[I,0],p[I,0],p[I,1],p[J,1])]*r[I][114][13,0]*r[J][7][8,0]
            hv += -1/2*g[dei(p[I,0],p[I,0],p[I,1],p[J,1])]*r[I][80][13,0]*r[J][7][8,0]
            hv += -1/4*g[dei(p[I,1],p[I,0],p[I,0],p[J,1])]*r[I][162][13,0]*r[J][7][8,0]
            hv += 1/4*g[dei(p[I,0],p[J,1],p[I,1],p[I,0])]*r[I][114][13,0]*r[J][7][8,0]
            hv += 1/4*g[dei(p[I,1],p[J,1],p[I,0],p[I,0])]*r[I][162][13,0]*r[J][7][8,0]
            hv += -1/2*g[dei(p[J,1],p[J,0],p[I,1],p[J,0])]*r[I][6][13,0]*r[J][129][8,0]
            hv += -1/2*g[dei(p[J,1],p[J,1],p[I,1],p[J,1])]*r[I][6][13,0]*r[J][149][8,0]
            hv += sum(1/12*g[dei(p[K,0],p[K,0],p[I,1],p[J,1])]*r[K][24][0,0]*r[I][6][13,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[K,0],p[K,0],p[I,1],p[J,1])]*r[K][9][0,0]*r[I][6][13,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[K,1],p[I,1],p[J,1])]*r[K][54][0,0]*r[I][6][13,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[K,1],p[K,1],p[I,1],p[J,1])]*r[K][39][0,0]*r[I][6][13,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[J,1],p[I,1],p[K,0])]*r[K][24][0,0]*r[I][6][13,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[J,1],p[I,1],p[K,1])]*r[K][54][0,0]*r[I][6][13,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,1],p[K,0],p[K,0],p[J,1])]*r[K][24][0,0]*r[I][6][13,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,1],p[K,1],p[K,1],p[J,1])]*r[K][54][0,0]*r[I][6][13,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,1],p[J,1],p[K,0],p[K,0])]*r[K][24][0,0]*r[I][6][13,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,1],p[J,1],p[K,1],p[K,1])]*r[K][54][0,0]*r[I][6][13,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,1],p[K,0],p[K,0],p[J,1])]*r[I][6][13,0]*r[K][24][0,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,1],p[K,1],p[K,1],p[J,1])]*r[I][6][13,0]*r[K][54][0,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,1],p[J,1],p[K,0],p[K,0])]*r[I][6][13,0]*r[K][24][0,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,1],p[J,1],p[K,1],p[K,1])]*r[I][6][13,0]*r[K][54][0,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[K,0],p[I,1],p[J,1])]*r[I][6][13,0]*r[K][24][0,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[K,0],p[K,0],p[I,1],p[J,1])]*r[I][6][13,0]*r[K][9][0,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[K,1],p[I,1],p[J,1])]*r[I][6][13,0]*r[K][54][0,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[K,1],p[K,1],p[I,1],p[J,1])]*r[I][6][13,0]*r[K][39][0,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[J,1],p[I,1],p[K,0])]*r[I][6][13,0]*r[K][24][0,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[J,1],p[I,1],p[K,1])]*r[I][6][13,0]*r[K][54][0,0]*r[J][7][8,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,1],p[J,1],p[K,0],p[K,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[I,1],p[J,1],p[K,1],p[K,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,1],p[K,0],p[K,0],p[J,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[I,1],p[K,1],p[K,1],p[J,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[J,1],p[I,1],p[K,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[J,1],p[I,1],p[K,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[K,0],p[I,1],p[J,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[K,0],p[K,0],p[I,1],p[J,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[K,1],p[I,1],p[J,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/6*g[dei(p[K,1],p[K,1],p[I,1],p[J,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    return hd
    
def _I9J12(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            v = tuple(sorted([(I,9),(J,12)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*h[p[J,0],p[I,0]]*r[I][1][9,0]*r[J][0][12,0]
            hv += -1/2*g[dei(p[J,0],p[I,0],p[I,0],p[I,0])]*r[I][97][9,0]*r[J][0][12,0]
            hv += -1/2*g[dei(p[J,0],p[I,1],p[I,0],p[I,1])]*r[I][117][9,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[J,0],p[I,0],p[J,1],p[J,1])]*r[I][1][9,0]*r[J][76][12,0]
            hv += -1/2*g[dei(p[J,0],p[I,0],p[J,1],p[J,1])]*r[I][1][9,0]*r[J][86][12,0]
            hv += -1/4*g[dei(p[J,1],p[I,0],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][124][12,0]
            hv += -1/2*g[dei(p[J,1],p[I,0],p[J,1],p[J,0])]*r[I][1][9,0]*r[J][146][12,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[J,1],p[I,0])]*r[I][1][9,0]*r[J][76][12,0]
            hv += 1/4*g[dei(p[J,1],p[J,1],p[J,0],p[I,0])]*r[I][1][9,0]*r[J][124][12,0]
            hv += sum(-1/12*g[dei(p[K,0],p[K,0],p[J,0],p[I,0])]*r[K][9][0,0]*r[I][1][9,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[K,1],p[J,0],p[I,0])]*r[K][39][0,0]*r[I][1][9,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[I,0],p[J,0],p[K,0])]*r[K][9][0,0]*r[I][1][9,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[I,0],p[J,0],p[K,1])]*r[K][39][0,0]*r[I][1][9,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,0],p[K,0],p[K,0],p[I,0])]*r[K][9][0,0]*r[I][1][9,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,0],p[K,1],p[K,1],p[I,0])]*r[K][39][0,0]*r[I][1][9,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,0],p[I,0],p[K,0],p[K,0])]*r[K][9][0,0]*r[I][1][9,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[J,0],p[I,0],p[K,0],p[K,0])]*r[K][24][0,0]*r[I][1][9,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,0],p[I,0],p[K,1],p[K,1])]*r[K][39][0,0]*r[I][1][9,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[J,0],p[I,0],p[K,1],p[K,1])]*r[K][54][0,0]*r[I][1][9,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[I,0],p[J,0],p[K,0])]*r[I][1][9,0]*r[K][9][0,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[I,0],p[J,0],p[K,1])]*r[I][1][9,0]*r[K][39][0,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[K,0],p[J,0],p[I,0])]*r[I][1][9,0]*r[K][9][0,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[K,1],p[J,0],p[I,0])]*r[I][1][9,0]*r[K][39][0,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,0],p[I,0],p[K,0],p[K,0])]*r[I][1][9,0]*r[K][9][0,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[J,0],p[I,0],p[K,0],p[K,0])]*r[I][1][9,0]*r[K][24][0,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,0],p[I,0],p[K,1],p[K,1])]*r[I][1][9,0]*r[K][39][0,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[J,0],p[I,0],p[K,1],p[K,1])]*r[I][1][9,0]*r[K][54][0,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,0],p[K,0],p[K,0],p[I,0])]*r[I][1][9,0]*r[K][9][0,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,0],p[K,1],p[K,1],p[I,0])]*r[I][1][9,0]*r[K][39][0,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,0],p[I,0],p[K,0],p[K,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[J,0],p[I,0],p[K,0],p[K,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,0],p[I,0],p[K,1],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[J,0],p[I,0],p[K,1],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,0],p[K,0],p[K,0],p[I,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,0],p[K,1],p[K,1],p[I,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[I,0],p[J,0],p[K,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[I,0],p[J,0],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[K,0],p[J,0],p[I,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[K,1],p[J,0],p[I,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    return hd
    
def _I7J14(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            v = tuple(sorted([(I,7),(J,14)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*h[p[J,0],p[I,0]]*r[I][3][7,0]*r[J][2][14,0]
            hv += 1/2*g[dei(p[I,0],p[I,0],p[J,0],p[I,0])]*r[I][65][7,0]*r[J][2][14,0]
            hv += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[I,1])]*r[I][85][7,0]*r[J][2][14,0]
            hv += -1/4*g[dei(p[J,0],p[I,0],p[J,1],p[J,1])]*r[I][3][7,0]*r[J][118][14,0]
            hv += -1/4*g[dei(p[J,1],p[I,0],p[J,0],p[J,1])]*r[I][3][7,0]*r[J][166][14,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[J,1],p[I,0])]*r[I][3][7,0]*r[J][118][14,0]
            hv += 1/4*g[dei(p[J,1],p[J,1],p[J,0],p[I,0])]*r[I][3][7,0]*r[J][166][14,0]
            hv += 1/2*g[dei(p[J,1],p[J,1],p[J,0],p[I,0])]*r[I][3][7,0]*r[J][132][14,0]
            hv += 1/2*g[dei(p[J,1],p[J,0],p[J,1],p[I,0])]*r[I][3][7,0]*r[J][144][14,0]
            hv += sum(-1/12*g[dei(p[K,0],p[K,0],p[J,0],p[I,0])]*r[K][24][0,0]*r[I][3][7,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[K,0],p[K,0],p[J,0],p[I,0])]*r[K][9][0,0]*r[I][3][7,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[K,1],p[J,0],p[I,0])]*r[K][54][0,0]*r[I][3][7,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[K,1],p[K,1],p[J,0],p[I,0])]*r[K][39][0,0]*r[I][3][7,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[I,0],p[J,0],p[K,0])]*r[K][24][0,0]*r[I][3][7,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[I,0],p[J,0],p[K,1])]*r[K][54][0,0]*r[I][3][7,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,0],p[K,0],p[K,0],p[I,0])]*r[K][24][0,0]*r[I][3][7,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,0],p[K,1],p[K,1],p[I,0])]*r[K][54][0,0]*r[I][3][7,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,0],p[I,0],p[K,0],p[K,0])]*r[K][24][0,0]*r[I][3][7,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,0],p[I,0],p[K,1],p[K,1])]*r[K][54][0,0]*r[I][3][7,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[I,0],p[J,0],p[K,0])]*r[I][3][7,0]*r[K][24][0,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[I,0],p[J,0],p[K,1])]*r[I][3][7,0]*r[K][54][0,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[K,0],p[J,0],p[I,0])]*r[I][3][7,0]*r[K][24][0,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[K,0],p[K,0],p[J,0],p[I,0])]*r[I][3][7,0]*r[K][9][0,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[K,1],p[J,0],p[I,0])]*r[I][3][7,0]*r[K][54][0,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[K,1],p[K,1],p[J,0],p[I,0])]*r[I][3][7,0]*r[K][39][0,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,0],p[I,0],p[K,0],p[K,0])]*r[I][3][7,0]*r[K][24][0,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,0],p[I,0],p[K,1],p[K,1])]*r[I][3][7,0]*r[K][54][0,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,0],p[K,0],p[K,0],p[I,0])]*r[I][3][7,0]*r[K][24][0,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,0],p[K,1],p[K,1],p[I,0])]*r[I][3][7,0]*r[K][54][0,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,0],p[I,0],p[K,0],p[K,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,0],p[I,0],p[K,1],p[K,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,0],p[K,0],p[K,0],p[I,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,0],p[K,1],p[K,1],p[I,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[I,0],p[J,0],p[K,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[I,0],p[J,0],p[K,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[K,0],p[J,0],p[I,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[K,0],p[K,0],p[J,0],p[I,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[K,1],p[J,0],p[I,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[K,1],p[K,1],p[J,0],p[I,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    return hd
    
def _I10J12(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            v = tuple(sorted([(I,10),(J,12)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*h[p[J,0],p[I,1]]*r[I][5][10,0]*r[J][0][12,0]
            hv += -1/2*g[dei(p[J,0],p[I,0],p[I,1],p[I,0])]*r[I][161][10,0]*r[J][0][12,0]
            hv += -1/2*g[dei(p[J,0],p[I,1],p[I,1],p[I,1])]*r[I][181][10,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[J,0],p[I,1],p[J,1],p[J,1])]*r[I][5][10,0]*r[J][76][12,0]
            hv += -1/2*g[dei(p[J,0],p[I,1],p[J,1],p[J,1])]*r[I][5][10,0]*r[J][86][12,0]
            hv += -1/4*g[dei(p[J,1],p[I,1],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][124][12,0]
            hv += -1/2*g[dei(p[J,1],p[I,1],p[J,1],p[J,0])]*r[I][5][10,0]*r[J][146][12,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[J,1],p[I,1])]*r[I][5][10,0]*r[J][76][12,0]
            hv += 1/4*g[dei(p[J,1],p[J,1],p[J,0],p[I,1])]*r[I][5][10,0]*r[J][124][12,0]
            hv += sum(-1/12*g[dei(p[K,0],p[K,0],p[J,0],p[I,1])]*r[K][9][0,0]*r[I][5][10,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[K,1],p[J,0],p[I,1])]*r[K][39][0,0]*r[I][5][10,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[I,1],p[J,0],p[K,0])]*r[K][9][0,0]*r[I][5][10,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[I,1],p[J,0],p[K,1])]*r[K][39][0,0]*r[I][5][10,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,0],p[K,0],p[K,0],p[I,1])]*r[K][9][0,0]*r[I][5][10,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,0],p[K,1],p[K,1],p[I,1])]*r[K][39][0,0]*r[I][5][10,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,0],p[I,1],p[K,0],p[K,0])]*r[K][9][0,0]*r[I][5][10,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[J,0],p[I,1],p[K,0],p[K,0])]*r[K][24][0,0]*r[I][5][10,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,0],p[I,1],p[K,1],p[K,1])]*r[K][39][0,0]*r[I][5][10,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[J,0],p[I,1],p[K,1],p[K,1])]*r[K][54][0,0]*r[I][5][10,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[I,1],p[J,0],p[K,0])]*r[I][5][10,0]*r[K][9][0,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[I,1],p[J,0],p[K,1])]*r[I][5][10,0]*r[K][39][0,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[K,0],p[J,0],p[I,1])]*r[I][5][10,0]*r[K][9][0,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[K,1],p[J,0],p[I,1])]*r[I][5][10,0]*r[K][39][0,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,0],p[I,1],p[K,0],p[K,0])]*r[I][5][10,0]*r[K][9][0,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[J,0],p[I,1],p[K,0],p[K,0])]*r[I][5][10,0]*r[K][24][0,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,0],p[I,1],p[K,1],p[K,1])]*r[I][5][10,0]*r[K][39][0,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[J,0],p[I,1],p[K,1],p[K,1])]*r[I][5][10,0]*r[K][54][0,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,0],p[K,0],p[K,0],p[I,1])]*r[I][5][10,0]*r[K][9][0,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,0],p[K,1],p[K,1],p[I,1])]*r[I][5][10,0]*r[K][39][0,0]*r[J][0][12,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,0],p[I,1],p[K,0],p[K,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[J,0],p[I,1],p[K,0],p[K,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,0],p[I,1],p[K,1],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[J,0],p[I,1],p[K,1],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,0],p[K,0],p[K,0],p[I,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,0],p[K,1],p[K,1],p[I,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[I,1],p[J,0],p[K,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[I,1],p[J,0],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[K,0],p[J,0],p[I,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[K,1],p[J,0],p[I,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    return hd
    
def _I8J14(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            v = tuple(sorted([(I,8),(J,14)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*h[p[J,0],p[I,1]]*r[I][7][8,0]*r[J][2][14,0]
            hv += 1/2*g[dei(p[I,1],p[I,0],p[J,0],p[I,0])]*r[I][129][8,0]*r[J][2][14,0]
            hv += 1/2*g[dei(p[I,1],p[I,1],p[J,0],p[I,1])]*r[I][149][8,0]*r[J][2][14,0]
            hv += -1/4*g[dei(p[J,0],p[I,1],p[J,1],p[J,1])]*r[I][7][8,0]*r[J][118][14,0]
            hv += -1/4*g[dei(p[J,1],p[I,1],p[J,0],p[J,1])]*r[I][7][8,0]*r[J][166][14,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[J,1],p[I,1])]*r[I][7][8,0]*r[J][118][14,0]
            hv += 1/4*g[dei(p[J,1],p[J,1],p[J,0],p[I,1])]*r[I][7][8,0]*r[J][166][14,0]
            hv += 1/2*g[dei(p[J,1],p[J,1],p[J,0],p[I,1])]*r[I][7][8,0]*r[J][132][14,0]
            hv += 1/2*g[dei(p[J,1],p[J,0],p[J,1],p[I,1])]*r[I][7][8,0]*r[J][144][14,0]
            hv += sum(-1/12*g[dei(p[K,0],p[K,0],p[J,0],p[I,1])]*r[K][24][0,0]*r[I][7][8,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[K,0],p[K,0],p[J,0],p[I,1])]*r[K][9][0,0]*r[I][7][8,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[K,1],p[J,0],p[I,1])]*r[K][54][0,0]*r[I][7][8,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[K,1],p[K,1],p[J,0],p[I,1])]*r[K][39][0,0]*r[I][7][8,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[I,1],p[J,0],p[K,0])]*r[K][24][0,0]*r[I][7][8,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[I,1],p[J,0],p[K,1])]*r[K][54][0,0]*r[I][7][8,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,0],p[K,0],p[K,0],p[I,1])]*r[K][24][0,0]*r[I][7][8,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,0],p[K,1],p[K,1],p[I,1])]*r[K][54][0,0]*r[I][7][8,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,0],p[I,1],p[K,0],p[K,0])]*r[K][24][0,0]*r[I][7][8,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,0],p[I,1],p[K,1],p[K,1])]*r[K][54][0,0]*r[I][7][8,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[I,1],p[J,0],p[K,0])]*r[I][7][8,0]*r[K][24][0,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[I,1],p[J,0],p[K,1])]*r[I][7][8,0]*r[K][54][0,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[K,0],p[J,0],p[I,1])]*r[I][7][8,0]*r[K][24][0,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[K,0],p[K,0],p[J,0],p[I,1])]*r[I][7][8,0]*r[K][9][0,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[K,1],p[J,0],p[I,1])]*r[I][7][8,0]*r[K][54][0,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[K,1],p[K,1],p[J,0],p[I,1])]*r[I][7][8,0]*r[K][39][0,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,0],p[I,1],p[K,0],p[K,0])]*r[I][7][8,0]*r[K][24][0,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,0],p[I,1],p[K,1],p[K,1])]*r[I][7][8,0]*r[K][54][0,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,0],p[K,0],p[K,0],p[I,1])]*r[I][7][8,0]*r[K][24][0,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,0],p[K,1],p[K,1],p[I,1])]*r[I][7][8,0]*r[K][54][0,0]*r[J][2][14,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,0],p[I,1],p[K,0],p[K,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,0],p[I,1],p[K,1],p[K,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,0],p[K,0],p[K,0],p[I,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,0],p[K,1],p[K,1],p[I,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[I,1],p[J,0],p[K,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[I,1],p[J,0],p[K,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[K,0],p[J,0],p[I,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[K,0],p[K,0],p[J,0],p[I,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[K,1],p[J,0],p[I,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[K,1],p[K,1],p[J,0],p[I,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    return hd
    
def _I9J11(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            v = tuple(sorted([(I,9),(J,11)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*h[p[J,1],p[I,0]]*r[I][1][9,0]*r[J][4][11,0]
            hv += -1/2*g[dei(p[J,1],p[I,0],p[I,0],p[I,0])]*r[I][97][9,0]*r[J][4][11,0]
            hv += -1/2*g[dei(p[J,1],p[I,1],p[I,0],p[I,1])]*r[I][117][9,0]*r[J][4][11,0]
            hv += -1/2*g[dei(p[J,0],p[I,0],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][70][11,0]
            hv += -1/4*g[dei(p[J,0],p[I,0],p[J,1],p[J,0])]*r[I][1][9,0]*r[J][72][11,0]
            hv += -1/4*g[dei(p[J,1],p[I,0],p[J,0],p[J,0])]*r[I][1][9,0]*r[J][120][11,0]
            hv += -1/2*g[dei(p[J,1],p[I,0],p[J,0],p[J,0])]*r[I][1][9,0]*r[J][130][11,0]
            hv += 1/4*g[dei(p[J,0],p[J,0],p[J,1],p[I,0])]*r[I][1][9,0]*r[J][72][11,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[J,0],p[I,0])]*r[I][1][9,0]*r[J][120][11,0]
            hv += sum(-1/12*g[dei(p[K,0],p[K,0],p[J,1],p[I,0])]*r[K][9][0,0]*r[I][1][9,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[K,1],p[J,1],p[I,0])]*r[K][39][0,0]*r[I][1][9,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[I,0],p[J,1],p[K,0])]*r[K][9][0,0]*r[I][1][9,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[I,0],p[J,1],p[K,1])]*r[K][39][0,0]*r[I][1][9,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,1],p[K,0],p[K,0],p[I,0])]*r[K][9][0,0]*r[I][1][9,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,1],p[K,1],p[K,1],p[I,0])]*r[K][39][0,0]*r[I][1][9,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,1],p[I,0],p[K,0],p[K,0])]*r[K][9][0,0]*r[I][1][9,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[J,1],p[I,0],p[K,0],p[K,0])]*r[K][24][0,0]*r[I][1][9,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,1],p[I,0],p[K,1],p[K,1])]*r[K][39][0,0]*r[I][1][9,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[J,1],p[I,0],p[K,1],p[K,1])]*r[K][54][0,0]*r[I][1][9,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[I,0],p[J,1],p[K,0])]*r[I][1][9,0]*r[K][9][0,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[I,0],p[J,1],p[K,1])]*r[I][1][9,0]*r[K][39][0,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[K,0],p[J,1],p[I,0])]*r[I][1][9,0]*r[K][9][0,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[K,1],p[J,1],p[I,0])]*r[I][1][9,0]*r[K][39][0,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,1],p[I,0],p[K,0],p[K,0])]*r[I][1][9,0]*r[K][9][0,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[J,1],p[I,0],p[K,0],p[K,0])]*r[I][1][9,0]*r[K][24][0,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,1],p[I,0],p[K,1],p[K,1])]*r[I][1][9,0]*r[K][39][0,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[J,1],p[I,0],p[K,1],p[K,1])]*r[I][1][9,0]*r[K][54][0,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,1],p[K,0],p[K,0],p[I,0])]*r[I][1][9,0]*r[K][9][0,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,1],p[K,1],p[K,1],p[I,0])]*r[I][1][9,0]*r[K][39][0,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,1],p[I,0],p[K,0],p[K,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[J,1],p[I,0],p[K,0],p[K,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,1],p[I,0],p[K,1],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[J,1],p[I,0],p[K,1],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,1],p[K,0],p[K,0],p[I,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,1],p[K,1],p[K,1],p[I,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[I,0],p[J,1],p[K,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[I,0],p[J,1],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[K,0],p[J,1],p[I,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[K,1],p[J,1],p[I,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    return hd
    
def _I7J13(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            v = tuple(sorted([(I,7),(J,13)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*h[p[J,1],p[I,0]]*r[I][3][7,0]*r[J][6][13,0]
            hv += 1/2*g[dei(p[I,0],p[I,0],p[J,1],p[I,0])]*r[I][65][7,0]*r[J][6][13,0]
            hv += 1/2*g[dei(p[I,0],p[I,1],p[J,1],p[I,1])]*r[I][85][7,0]*r[J][6][13,0]
            hv += -1/4*g[dei(p[J,0],p[I,0],p[J,1],p[J,0])]*r[I][3][7,0]*r[J][114][13,0]
            hv += -1/4*g[dei(p[J,1],p[I,0],p[J,0],p[J,0])]*r[I][3][7,0]*r[J][162][13,0]
            hv += 1/2*g[dei(p[J,0],p[J,1],p[J,0],p[I,0])]*r[I][3][7,0]*r[J][68][13,0]
            hv += 1/4*g[dei(p[J,0],p[J,0],p[J,1],p[I,0])]*r[I][3][7,0]*r[J][114][13,0]
            hv += 1/2*g[dei(p[J,0],p[J,0],p[J,1],p[I,0])]*r[I][3][7,0]*r[J][80][13,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[J,0],p[I,0])]*r[I][3][7,0]*r[J][162][13,0]
            hv += sum(-1/12*g[dei(p[K,0],p[K,0],p[J,1],p[I,0])]*r[K][24][0,0]*r[I][3][7,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[K,0],p[K,0],p[J,1],p[I,0])]*r[K][9][0,0]*r[I][3][7,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[K,1],p[J,1],p[I,0])]*r[K][54][0,0]*r[I][3][7,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[K,1],p[K,1],p[J,1],p[I,0])]*r[K][39][0,0]*r[I][3][7,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[I,0],p[J,1],p[K,0])]*r[K][24][0,0]*r[I][3][7,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[I,0],p[J,1],p[K,1])]*r[K][54][0,0]*r[I][3][7,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,1],p[K,0],p[K,0],p[I,0])]*r[K][24][0,0]*r[I][3][7,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,1],p[K,1],p[K,1],p[I,0])]*r[K][54][0,0]*r[I][3][7,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,1],p[I,0],p[K,0],p[K,0])]*r[K][24][0,0]*r[I][3][7,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,1],p[I,0],p[K,1],p[K,1])]*r[K][54][0,0]*r[I][3][7,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[I,0],p[J,1],p[K,0])]*r[I][3][7,0]*r[K][24][0,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[I,0],p[J,1],p[K,1])]*r[I][3][7,0]*r[K][54][0,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[K,0],p[J,1],p[I,0])]*r[I][3][7,0]*r[K][24][0,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[K,0],p[K,0],p[J,1],p[I,0])]*r[I][3][7,0]*r[K][9][0,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[K,1],p[J,1],p[I,0])]*r[I][3][7,0]*r[K][54][0,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[K,1],p[K,1],p[J,1],p[I,0])]*r[I][3][7,0]*r[K][39][0,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,1],p[I,0],p[K,0],p[K,0])]*r[I][3][7,0]*r[K][24][0,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,1],p[I,0],p[K,1],p[K,1])]*r[I][3][7,0]*r[K][54][0,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,1],p[K,0],p[K,0],p[I,0])]*r[I][3][7,0]*r[K][24][0,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,1],p[K,1],p[K,1],p[I,0])]*r[I][3][7,0]*r[K][54][0,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,1],p[I,0],p[K,0],p[K,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,1],p[I,0],p[K,1],p[K,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,1],p[K,0],p[K,0],p[I,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,1],p[K,1],p[K,1],p[I,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[I,0],p[J,1],p[K,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[I,0],p[J,1],p[K,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[K,0],p[J,1],p[I,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[K,0],p[K,0],p[J,1],p[I,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[K,1],p[J,1],p[I,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[K,1],p[K,1],p[J,1],p[I,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    return hd
    
def _I10J11(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            v = tuple(sorted([(I,10),(J,11)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*h[p[J,1],p[I,1]]*r[I][5][10,0]*r[J][4][11,0]
            hv += -1/2*g[dei(p[J,1],p[I,0],p[I,1],p[I,0])]*r[I][161][10,0]*r[J][4][11,0]
            hv += -1/2*g[dei(p[J,1],p[I,1],p[I,1],p[I,1])]*r[I][181][10,0]*r[J][4][11,0]
            hv += -1/2*g[dei(p[J,0],p[I,1],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][70][11,0]
            hv += -1/4*g[dei(p[J,0],p[I,1],p[J,1],p[J,0])]*r[I][5][10,0]*r[J][72][11,0]
            hv += -1/4*g[dei(p[J,1],p[I,1],p[J,0],p[J,0])]*r[I][5][10,0]*r[J][120][11,0]
            hv += -1/2*g[dei(p[J,1],p[I,1],p[J,0],p[J,0])]*r[I][5][10,0]*r[J][130][11,0]
            hv += 1/4*g[dei(p[J,0],p[J,0],p[J,1],p[I,1])]*r[I][5][10,0]*r[J][72][11,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[J,0],p[I,1])]*r[I][5][10,0]*r[J][120][11,0]
            hv += sum(-1/12*g[dei(p[K,0],p[K,0],p[J,1],p[I,1])]*r[K][9][0,0]*r[I][5][10,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[K,1],p[J,1],p[I,1])]*r[K][39][0,0]*r[I][5][10,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[I,1],p[J,1],p[K,0])]*r[K][9][0,0]*r[I][5][10,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[I,1],p[J,1],p[K,1])]*r[K][39][0,0]*r[I][5][10,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,1],p[K,0],p[K,0],p[I,1])]*r[K][9][0,0]*r[I][5][10,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,1],p[K,1],p[K,1],p[I,1])]*r[K][39][0,0]*r[I][5][10,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,1],p[I,1],p[K,0],p[K,0])]*r[K][9][0,0]*r[I][5][10,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[J,1],p[I,1],p[K,0],p[K,0])]*r[K][24][0,0]*r[I][5][10,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,1],p[I,1],p[K,1],p[K,1])]*r[K][39][0,0]*r[I][5][10,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[J,1],p[I,1],p[K,1],p[K,1])]*r[K][54][0,0]*r[I][5][10,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[I,1],p[J,1],p[K,0])]*r[I][5][10,0]*r[K][9][0,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[I,1],p[J,1],p[K,1])]*r[I][5][10,0]*r[K][39][0,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[K,0],p[J,1],p[I,1])]*r[I][5][10,0]*r[K][9][0,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[K,1],p[J,1],p[I,1])]*r[I][5][10,0]*r[K][39][0,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,1],p[I,1],p[K,0],p[K,0])]*r[I][5][10,0]*r[K][9][0,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[J,1],p[I,1],p[K,0],p[K,0])]*r[I][5][10,0]*r[K][24][0,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,1],p[I,1],p[K,1],p[K,1])]*r[I][5][10,0]*r[K][39][0,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[J,1],p[I,1],p[K,1],p[K,1])]*r[I][5][10,0]*r[K][54][0,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,1],p[K,0],p[K,0],p[I,1])]*r[I][5][10,0]*r[K][9][0,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,1],p[K,1],p[K,1],p[I,1])]*r[I][5][10,0]*r[K][39][0,0]*r[J][4][11,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,1],p[I,1],p[K,0],p[K,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[J,1],p[I,1],p[K,0],p[K,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,1],p[I,1],p[K,1],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[J,1],p[I,1],p[K,1],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,1],p[K,0],p[K,0],p[I,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,1],p[K,1],p[K,1],p[I,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[I,1],p[J,1],p[K,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[I,1],p[J,1],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[K,0],p[J,1],p[I,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[K,1],p[J,1],p[I,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    return hd
    
def _I8J13(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            v = tuple(sorted([(I,8),(J,13)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*h[p[J,1],p[I,1]]*r[I][7][8,0]*r[J][6][13,0]
            hv += 1/2*g[dei(p[I,1],p[I,0],p[J,1],p[I,0])]*r[I][129][8,0]*r[J][6][13,0]
            hv += 1/2*g[dei(p[I,1],p[I,1],p[J,1],p[I,1])]*r[I][149][8,0]*r[J][6][13,0]
            hv += -1/4*g[dei(p[J,0],p[I,1],p[J,1],p[J,0])]*r[I][7][8,0]*r[J][114][13,0]
            hv += -1/4*g[dei(p[J,1],p[I,1],p[J,0],p[J,0])]*r[I][7][8,0]*r[J][162][13,0]
            hv += 1/2*g[dei(p[J,0],p[J,1],p[J,0],p[I,1])]*r[I][7][8,0]*r[J][68][13,0]
            hv += 1/4*g[dei(p[J,0],p[J,0],p[J,1],p[I,1])]*r[I][7][8,0]*r[J][114][13,0]
            hv += 1/2*g[dei(p[J,0],p[J,0],p[J,1],p[I,1])]*r[I][7][8,0]*r[J][80][13,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[J,0],p[I,1])]*r[I][7][8,0]*r[J][162][13,0]
            hv += sum(-1/12*g[dei(p[K,0],p[K,0],p[J,1],p[I,1])]*r[K][24][0,0]*r[I][7][8,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[K,0],p[K,0],p[J,1],p[I,1])]*r[K][9][0,0]*r[I][7][8,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[K,1],p[J,1],p[I,1])]*r[K][54][0,0]*r[I][7][8,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[K,1],p[K,1],p[J,1],p[I,1])]*r[K][39][0,0]*r[I][7][8,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[I,1],p[J,1],p[K,0])]*r[K][24][0,0]*r[I][7][8,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[I,1],p[J,1],p[K,1])]*r[K][54][0,0]*r[I][7][8,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,1],p[K,0],p[K,0],p[I,1])]*r[K][24][0,0]*r[I][7][8,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,1],p[K,1],p[K,1],p[I,1])]*r[K][54][0,0]*r[I][7][8,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,1],p[I,1],p[K,0],p[K,0])]*r[K][24][0,0]*r[I][7][8,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,1],p[I,1],p[K,1],p[K,1])]*r[K][54][0,0]*r[I][7][8,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[I,1],p[J,1],p[K,0])]*r[I][7][8,0]*r[K][24][0,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[I,1],p[J,1],p[K,1])]*r[I][7][8,0]*r[K][54][0,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[K,0],p[J,1],p[I,1])]*r[I][7][8,0]*r[K][24][0,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[K,0],p[K,0],p[J,1],p[I,1])]*r[I][7][8,0]*r[K][9][0,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[K,1],p[J,1],p[I,1])]*r[I][7][8,0]*r[K][54][0,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[K,1],p[K,1],p[J,1],p[I,1])]*r[I][7][8,0]*r[K][39][0,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,1],p[I,1],p[K,0],p[K,0])]*r[I][7][8,0]*r[K][24][0,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,1],p[I,1],p[K,1],p[K,1])]*r[I][7][8,0]*r[K][54][0,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,1],p[K,0],p[K,0],p[I,1])]*r[I][7][8,0]*r[K][24][0,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,1],p[K,1],p[K,1],p[I,1])]*r[I][7][8,0]*r[K][54][0,0]*r[J][6][13,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,1],p[I,1],p[K,0],p[K,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[J,1],p[I,1],p[K,1],p[K,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,1],p[K,0],p[K,0],p[I,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[J,1],p[K,1],p[K,1],p[I,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,0],p[I,1],p[J,1],p[K,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(1/12*g[dei(p[K,1],p[I,1],p[J,1],p[K,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,0],p[K,0],p[J,1],p[I,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][24][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[K,0],p[K,0],p[J,1],p[I,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][9][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/12*g[dei(p[K,1],p[K,1],p[J,1],p[I,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][54][0,0] for K in range(np) if K not in {I,J})
            hv += sum(-1/6*g[dei(p[K,1],p[K,1],p[J,1],p[I,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][39][0,0] for K in range(np) if K not in {I,J})
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    return hd
    
def _I15J6(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            v = tuple(sorted([(I,15),(J,6)]))
            hv = 0.0
            
            hv += 1/2*g[dei(p[I,0],p[J,0],p[I,0],p[J,0])]*r[I][11][15,0]*r[J][22][6,0]
            hv += 1/2*g[dei(p[I,0],p[J,1],p[I,0],p[J,1])]*r[I][11][15,0]*r[J][52][6,0]
            hv += 1/2*g[dei(p[I,1],p[J,0],p[I,1],p[J,0])]*r[I][41][15,0]*r[J][22][6,0]
            hv += 1/2*g[dei(p[I,1],p[J,1],p[I,1],p[J,1])]*r[I][41][15,0]*r[J][52][6,0]
            
            hd[v] = hd.get(v,0.0)+hv
            
    return hd
    
def _I1J1(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            v = tuple(sorted([(I,1),(J,1)]))
            hv = 0.0
            
            hv += 1/4*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][9][1,0]*r[J][9][1,0]
            hv += 1/4*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][24][1,0]*r[J][24][1,0]
            hv += 1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][9][1,0]*r[J][24][1,0]
            hv += 1/4*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][9][1,0]*r[J][39][1,0]
            hv += 1/4*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][24][1,0]*r[J][54][1,0]
            hv += 1/2*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][9][1,0]*r[J][54][1,0]
            hv += 1/4*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][39][1,0]*r[J][9][1,0]
            hv += 1/4*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][54][1,0]*r[J][24][1,0]
            hv += 1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][39][1,0]*r[J][24][1,0]
            hv += 1/4*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][39][1,0]*r[J][39][1,0]
            hv += 1/4*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][54][1,0]*r[J][54][1,0]
            hv += 1/2*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][39][1,0]*r[J][54][1,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,0])]*r[I][9][1,0]*r[J][9][1,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,0])]*r[I][24][1,0]*r[J][24][1,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,0])]*r[I][9][1,0]*r[J][39][1,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,0])]*r[I][24][1,0]*r[J][54][1,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,1])]*r[I][39][1,0]*r[J][9][1,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,1])]*r[I][54][1,0]*r[J][24][1,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,1])]*r[I][39][1,0]*r[J][39][1,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,1])]*r[I][54][1,0]*r[J][54][1,0]
            hv += -1/4*g[dei(p[J,0],p[I,0],p[I,0],p[J,0])]*r[I][9][1,0]*r[J][9][1,0]
            hv += -1/4*g[dei(p[J,0],p[I,0],p[I,0],p[J,0])]*r[I][24][1,0]*r[J][24][1,0]
            hv += -1/4*g[dei(p[J,0],p[I,1],p[I,1],p[J,0])]*r[I][39][1,0]*r[J][9][1,0]
            hv += -1/4*g[dei(p[J,0],p[I,1],p[I,1],p[J,0])]*r[I][54][1,0]*r[J][24][1,0]
            hv += -1/4*g[dei(p[J,1],p[I,0],p[I,0],p[J,1])]*r[I][9][1,0]*r[J][39][1,0]
            hv += -1/4*g[dei(p[J,1],p[I,0],p[I,0],p[J,1])]*r[I][24][1,0]*r[J][54][1,0]
            hv += -1/4*g[dei(p[J,1],p[I,1],p[I,1],p[J,1])]*r[I][39][1,0]*r[J][39][1,0]
            hv += -1/4*g[dei(p[J,1],p[I,1],p[I,1],p[J,1])]*r[I][54][1,0]*r[J][54][1,0]
            hv += 1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[I][9][1,0]*r[J][9][1,0]
            hv += 1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][24][1,0]
            hv += 1/2*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][9][1,0]
            hv += 1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[I][39][1,0]*r[J][9][1,0]
            hv += 1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][24][1,0]
            hv += 1/2*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][9][1,0]
            hv += 1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[I][9][1,0]*r[J][39][1,0]
            hv += 1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][54][1,0]
            hv += 1/2*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][39][1,0]
            hv += 1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[I][39][1,0]*r[J][39][1,0]
            hv += 1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][54][1,0]
            hv += 1/2*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][39][1,0]
            
            hd[v] = hd.get(v,0.0)+hv
            
    return hd
    
def _I1J2(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            v = tuple(sorted([(I,1),(J,2)]))
            hv = 0.0
            
            hv += 1/4*g[dei(p[I,0],p[I,0],p[J,0],p[J,1])]*r[I][9][1,0]*r[J][15][2,0]
            hv += 1/4*g[dei(p[I,0],p[I,0],p[J,0],p[J,1])]*r[I][24][1,0]*r[J][30][2,0]
            hv += 1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,1])]*r[I][9][1,0]*r[J][30][2,0]
            hv += 1/4*g[dei(p[I,0],p[I,0],p[J,1],p[J,0])]*r[I][9][1,0]*r[J][33][2,0]
            hv += 1/4*g[dei(p[I,0],p[I,0],p[J,1],p[J,0])]*r[I][24][1,0]*r[J][48][2,0]
            hv += 1/2*g[dei(p[I,0],p[I,0],p[J,1],p[J,0])]*r[I][9][1,0]*r[J][48][2,0]
            hv += 1/4*g[dei(p[I,1],p[I,1],p[J,0],p[J,1])]*r[I][39][1,0]*r[J][15][2,0]
            hv += 1/4*g[dei(p[I,1],p[I,1],p[J,0],p[J,1])]*r[I][54][1,0]*r[J][30][2,0]
            hv += 1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,1])]*r[I][39][1,0]*r[J][30][2,0]
            hv += 1/4*g[dei(p[I,1],p[I,1],p[J,1],p[J,0])]*r[I][39][1,0]*r[J][33][2,0]
            hv += 1/4*g[dei(p[I,1],p[I,1],p[J,1],p[J,0])]*r[I][54][1,0]*r[J][48][2,0]
            hv += 1/2*g[dei(p[I,1],p[I,1],p[J,1],p[J,0])]*r[I][39][1,0]*r[J][48][2,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[J,0],p[I,0])]*r[I][9][1,0]*r[J][15][2,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[J,0],p[I,0])]*r[I][24][1,0]*r[J][30][2,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[J,1],p[I,0])]*r[I][9][1,0]*r[J][33][2,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[J,1],p[I,0])]*r[I][24][1,0]*r[J][48][2,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[J,0],p[I,1])]*r[I][39][1,0]*r[J][15][2,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[J,0],p[I,1])]*r[I][54][1,0]*r[J][30][2,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[J,1],p[I,1])]*r[I][39][1,0]*r[J][33][2,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[J,1],p[I,1])]*r[I][54][1,0]*r[J][48][2,0]
            hv += -1/4*g[dei(p[J,0],p[I,0],p[I,0],p[J,1])]*r[I][9][1,0]*r[J][15][2,0]
            hv += -1/4*g[dei(p[J,0],p[I,0],p[I,0],p[J,1])]*r[I][24][1,0]*r[J][30][2,0]
            hv += -1/4*g[dei(p[J,0],p[I,1],p[I,1],p[J,1])]*r[I][39][1,0]*r[J][15][2,0]
            hv += -1/4*g[dei(p[J,0],p[I,1],p[I,1],p[J,1])]*r[I][54][1,0]*r[J][30][2,0]
            hv += -1/4*g[dei(p[J,1],p[I,0],p[I,0],p[J,0])]*r[I][9][1,0]*r[J][33][2,0]
            hv += -1/4*g[dei(p[J,1],p[I,0],p[I,0],p[J,0])]*r[I][24][1,0]*r[J][48][2,0]
            hv += -1/4*g[dei(p[J,1],p[I,1],p[I,1],p[J,0])]*r[I][39][1,0]*r[J][33][2,0]
            hv += -1/4*g[dei(p[J,1],p[I,1],p[I,1],p[J,0])]*r[I][54][1,0]*r[J][48][2,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[I,0],p[I,0])]*r[I][9][1,0]*r[J][15][2,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][30][2,0]
            hv += 1/2*g[dei(p[J,0],p[J,1],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][15][2,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[I,1],p[I,1])]*r[I][39][1,0]*r[J][15][2,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][30][2,0]
            hv += 1/2*g[dei(p[J,0],p[J,1],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][15][2,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[I,0],p[I,0])]*r[I][9][1,0]*r[J][33][2,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][48][2,0]
            hv += 1/2*g[dei(p[J,1],p[J,0],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][33][2,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[I,1],p[I,1])]*r[I][39][1,0]*r[J][33][2,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][48][2,0]
            hv += 1/2*g[dei(p[J,1],p[J,0],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][33][2,0]
            
            hd[v] = hd.get(v,0.0)+hv
            
    return hd
    
def _I1J3(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            v = tuple(sorted([(I,1),(J,3)]))
            hv = 0.0
            
            hv += 1/4*g[dei(p[I,0],p[I,0],p[J,0],p[J,1])]*r[I][9][1,0]*r[J][15][3,0]
            hv += 1/4*g[dei(p[I,0],p[I,0],p[J,0],p[J,1])]*r[I][24][1,0]*r[J][30][3,0]
            hv += 1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,1])]*r[I][9][1,0]*r[J][30][3,0]
            hv += 1/4*g[dei(p[I,0],p[I,0],p[J,1],p[J,0])]*r[I][9][1,0]*r[J][33][3,0]
            hv += 1/4*g[dei(p[I,0],p[I,0],p[J,1],p[J,0])]*r[I][24][1,0]*r[J][48][3,0]
            hv += 1/2*g[dei(p[I,0],p[I,0],p[J,1],p[J,0])]*r[I][9][1,0]*r[J][48][3,0]
            hv += 1/4*g[dei(p[I,1],p[I,1],p[J,0],p[J,1])]*r[I][39][1,0]*r[J][15][3,0]
            hv += 1/4*g[dei(p[I,1],p[I,1],p[J,0],p[J,1])]*r[I][54][1,0]*r[J][30][3,0]
            hv += 1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,1])]*r[I][39][1,0]*r[J][30][3,0]
            hv += 1/4*g[dei(p[I,1],p[I,1],p[J,1],p[J,0])]*r[I][39][1,0]*r[J][33][3,0]
            hv += 1/4*g[dei(p[I,1],p[I,1],p[J,1],p[J,0])]*r[I][54][1,0]*r[J][48][3,0]
            hv += 1/2*g[dei(p[I,1],p[I,1],p[J,1],p[J,0])]*r[I][39][1,0]*r[J][48][3,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[J,0],p[I,0])]*r[I][9][1,0]*r[J][15][3,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[J,0],p[I,0])]*r[I][24][1,0]*r[J][30][3,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[J,1],p[I,0])]*r[I][9][1,0]*r[J][33][3,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[J,1],p[I,0])]*r[I][24][1,0]*r[J][48][3,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[J,0],p[I,1])]*r[I][39][1,0]*r[J][15][3,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[J,0],p[I,1])]*r[I][54][1,0]*r[J][30][3,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[J,1],p[I,1])]*r[I][39][1,0]*r[J][33][3,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[J,1],p[I,1])]*r[I][54][1,0]*r[J][48][3,0]
            hv += -1/4*g[dei(p[J,0],p[I,0],p[I,0],p[J,1])]*r[I][9][1,0]*r[J][15][3,0]
            hv += -1/4*g[dei(p[J,0],p[I,0],p[I,0],p[J,1])]*r[I][24][1,0]*r[J][30][3,0]
            hv += -1/4*g[dei(p[J,0],p[I,1],p[I,1],p[J,1])]*r[I][39][1,0]*r[J][15][3,0]
            hv += -1/4*g[dei(p[J,0],p[I,1],p[I,1],p[J,1])]*r[I][54][1,0]*r[J][30][3,0]
            hv += -1/4*g[dei(p[J,1],p[I,0],p[I,0],p[J,0])]*r[I][9][1,0]*r[J][33][3,0]
            hv += -1/4*g[dei(p[J,1],p[I,0],p[I,0],p[J,0])]*r[I][24][1,0]*r[J][48][3,0]
            hv += -1/4*g[dei(p[J,1],p[I,1],p[I,1],p[J,0])]*r[I][39][1,0]*r[J][33][3,0]
            hv += -1/4*g[dei(p[J,1],p[I,1],p[I,1],p[J,0])]*r[I][54][1,0]*r[J][48][3,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[I,0],p[I,0])]*r[I][9][1,0]*r[J][15][3,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][30][3,0]
            hv += 1/2*g[dei(p[J,0],p[J,1],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][15][3,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[I,1],p[I,1])]*r[I][39][1,0]*r[J][15][3,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][30][3,0]
            hv += 1/2*g[dei(p[J,0],p[J,1],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][15][3,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[I,0],p[I,0])]*r[I][9][1,0]*r[J][33][3,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][48][3,0]
            hv += 1/2*g[dei(p[J,1],p[J,0],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][33][3,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[I,1],p[I,1])]*r[I][39][1,0]*r[J][33][3,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][48][3,0]
            hv += 1/2*g[dei(p[J,1],p[J,0],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][33][3,0]
            
            hd[v] = hd.get(v,0.0)+hv
            
    return hd
    
def _I2J1(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            v = tuple(sorted([(I,2),(J,1)]))
            hv = 0.0
            
            hv += 1/4*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][15][2,0]*r[J][9][1,0]
            hv += 1/4*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][30][2,0]*r[J][24][1,0]
            hv += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][15][2,0]*r[J][24][1,0]
            hv += 1/4*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][15][2,0]*r[J][39][1,0]
            hv += 1/4*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][30][2,0]*r[J][54][1,0]
            hv += 1/2*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][15][2,0]*r[J][54][1,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[J,0],p[J,0])]*r[I][33][2,0]*r[J][9][1,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[J,0],p[J,0])]*r[I][48][2,0]*r[J][24][1,0]
            hv += 1/2*g[dei(p[I,1],p[I,0],p[J,0],p[J,0])]*r[I][33][2,0]*r[J][24][1,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[J,1],p[J,1])]*r[I][33][2,0]*r[J][39][1,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[J,1],p[J,1])]*r[I][48][2,0]*r[J][54][1,0]
            hv += 1/2*g[dei(p[I,1],p[I,0],p[J,1],p[J,1])]*r[I][33][2,0]*r[J][54][1,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,1])]*r[I][15][2,0]*r[J][9][1,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,1])]*r[I][30][2,0]*r[J][24][1,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,1])]*r[I][15][2,0]*r[J][39][1,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,1])]*r[I][30][2,0]*r[J][54][1,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,0])]*r[I][33][2,0]*r[J][9][1,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,0])]*r[I][48][2,0]*r[J][24][1,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,0])]*r[I][33][2,0]*r[J][39][1,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,0])]*r[I][48][2,0]*r[J][54][1,0]
            hv += -1/4*g[dei(p[J,0],p[I,1],p[I,0],p[J,0])]*r[I][15][2,0]*r[J][9][1,0]
            hv += -1/4*g[dei(p[J,0],p[I,1],p[I,0],p[J,0])]*r[I][30][2,0]*r[J][24][1,0]
            hv += -1/4*g[dei(p[J,0],p[I,0],p[I,1],p[J,0])]*r[I][33][2,0]*r[J][9][1,0]
            hv += -1/4*g[dei(p[J,0],p[I,0],p[I,1],p[J,0])]*r[I][48][2,0]*r[J][24][1,0]
            hv += -1/4*g[dei(p[J,1],p[I,1],p[I,0],p[J,1])]*r[I][15][2,0]*r[J][39][1,0]
            hv += -1/4*g[dei(p[J,1],p[I,1],p[I,0],p[J,1])]*r[I][30][2,0]*r[J][54][1,0]
            hv += -1/4*g[dei(p[J,1],p[I,0],p[I,1],p[J,1])]*r[I][33][2,0]*r[J][39][1,0]
            hv += -1/4*g[dei(p[J,1],p[I,0],p[I,1],p[J,1])]*r[I][48][2,0]*r[J][54][1,0]
            hv += 1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,1])]*r[I][15][2,0]*r[J][9][1,0]
            hv += 1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][24][1,0]
            hv += 1/2*g[dei(p[J,0],p[J,0],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][9][1,0]
            hv += 1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,0])]*r[I][33][2,0]*r[J][9][1,0]
            hv += 1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][24][1,0]
            hv += 1/2*g[dei(p[J,0],p[J,0],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][9][1,0]
            hv += 1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,1])]*r[I][15][2,0]*r[J][39][1,0]
            hv += 1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][54][1,0]
            hv += 1/2*g[dei(p[J,1],p[J,1],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][39][1,0]
            hv += 1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,0])]*r[I][33][2,0]*r[J][39][1,0]
            hv += 1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][54][1,0]
            hv += 1/2*g[dei(p[J,1],p[J,1],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][39][1,0]
            
            hd[v] = hd.get(v,0.0)+hv
            
    return hd
    
def _I3J1(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            v = tuple(sorted([(I,3),(J,1)]))
            hv = 0.0
            
            hv += 1/4*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][15][3,0]*r[J][9][1,0]
            hv += 1/4*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][30][3,0]*r[J][24][1,0]
            hv += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][15][3,0]*r[J][24][1,0]
            hv += 1/4*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][15][3,0]*r[J][39][1,0]
            hv += 1/4*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][30][3,0]*r[J][54][1,0]
            hv += 1/2*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][15][3,0]*r[J][54][1,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[J,0],p[J,0])]*r[I][33][3,0]*r[J][9][1,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[J,0],p[J,0])]*r[I][48][3,0]*r[J][24][1,0]
            hv += 1/2*g[dei(p[I,1],p[I,0],p[J,0],p[J,0])]*r[I][33][3,0]*r[J][24][1,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[J,1],p[J,1])]*r[I][33][3,0]*r[J][39][1,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[J,1],p[J,1])]*r[I][48][3,0]*r[J][54][1,0]
            hv += 1/2*g[dei(p[I,1],p[I,0],p[J,1],p[J,1])]*r[I][33][3,0]*r[J][54][1,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,1])]*r[I][15][3,0]*r[J][9][1,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,1])]*r[I][30][3,0]*r[J][24][1,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,1])]*r[I][15][3,0]*r[J][39][1,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,1])]*r[I][30][3,0]*r[J][54][1,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,0])]*r[I][33][3,0]*r[J][9][1,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,0])]*r[I][48][3,0]*r[J][24][1,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,0])]*r[I][33][3,0]*r[J][39][1,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,0])]*r[I][48][3,0]*r[J][54][1,0]
            hv += -1/4*g[dei(p[J,0],p[I,1],p[I,0],p[J,0])]*r[I][15][3,0]*r[J][9][1,0]
            hv += -1/4*g[dei(p[J,0],p[I,1],p[I,0],p[J,0])]*r[I][30][3,0]*r[J][24][1,0]
            hv += -1/4*g[dei(p[J,0],p[I,0],p[I,1],p[J,0])]*r[I][33][3,0]*r[J][9][1,0]
            hv += -1/4*g[dei(p[J,0],p[I,0],p[I,1],p[J,0])]*r[I][48][3,0]*r[J][24][1,0]
            hv += -1/4*g[dei(p[J,1],p[I,1],p[I,0],p[J,1])]*r[I][15][3,0]*r[J][39][1,0]
            hv += -1/4*g[dei(p[J,1],p[I,1],p[I,0],p[J,1])]*r[I][30][3,0]*r[J][54][1,0]
            hv += -1/4*g[dei(p[J,1],p[I,0],p[I,1],p[J,1])]*r[I][33][3,0]*r[J][39][1,0]
            hv += -1/4*g[dei(p[J,1],p[I,0],p[I,1],p[J,1])]*r[I][48][3,0]*r[J][54][1,0]
            hv += 1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,1])]*r[I][15][3,0]*r[J][9][1,0]
            hv += 1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][24][1,0]
            hv += 1/2*g[dei(p[J,0],p[J,0],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][9][1,0]
            hv += 1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,0])]*r[I][33][3,0]*r[J][9][1,0]
            hv += 1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][24][1,0]
            hv += 1/2*g[dei(p[J,0],p[J,0],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][9][1,0]
            hv += 1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,1])]*r[I][15][3,0]*r[J][39][1,0]
            hv += 1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][54][1,0]
            hv += 1/2*g[dei(p[J,1],p[J,1],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][39][1,0]
            hv += 1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,0])]*r[I][33][3,0]*r[J][39][1,0]
            hv += 1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][54][1,0]
            hv += 1/2*g[dei(p[J,1],p[J,1],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][39][1,0]
            
            hd[v] = hd.get(v,0.0)+hv
            
    return hd
    
def _I2J2(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            v = tuple(sorted([(I,2),(J,2)]))
            hv = 0.0
            
            hv += 1/4*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][15][2,0]*r[J][15][2,0]
            hv += 1/4*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][30][2,0]*r[J][30][2,0]
            hv += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][15][2,0]*r[J][30][2,0]
            hv += 1/4*g[dei(p[I,0],p[I,1],p[J,1],p[J,0])]*r[I][15][2,0]*r[J][33][2,0]
            hv += 1/4*g[dei(p[I,0],p[I,1],p[J,1],p[J,0])]*r[I][30][2,0]*r[J][48][2,0]
            hv += 1/2*g[dei(p[I,0],p[I,1],p[J,1],p[J,0])]*r[I][15][2,0]*r[J][48][2,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[J,0],p[J,1])]*r[I][33][2,0]*r[J][15][2,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[J,0],p[J,1])]*r[I][48][2,0]*r[J][30][2,0]
            hv += 1/2*g[dei(p[I,1],p[I,0],p[J,0],p[J,1])]*r[I][33][2,0]*r[J][30][2,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[J,1],p[J,0])]*r[I][33][2,0]*r[J][33][2,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[J,1],p[J,0])]*r[I][48][2,0]*r[J][48][2,0]
            hv += 1/2*g[dei(p[I,1],p[I,0],p[J,1],p[J,0])]*r[I][33][2,0]*r[J][48][2,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[J,0],p[I,1])]*r[I][15][2,0]*r[J][15][2,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[J,0],p[I,1])]*r[I][30][2,0]*r[J][30][2,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[J,1],p[I,1])]*r[I][15][2,0]*r[J][33][2,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[J,1],p[I,1])]*r[I][30][2,0]*r[J][48][2,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[J,0],p[I,0])]*r[I][33][2,0]*r[J][15][2,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[J,0],p[I,0])]*r[I][48][2,0]*r[J][30][2,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[J,1],p[I,0])]*r[I][33][2,0]*r[J][33][2,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[J,1],p[I,0])]*r[I][48][2,0]*r[J][48][2,0]
            hv += -1/4*g[dei(p[J,0],p[I,1],p[I,0],p[J,1])]*r[I][15][2,0]*r[J][15][2,0]
            hv += -1/4*g[dei(p[J,0],p[I,1],p[I,0],p[J,1])]*r[I][30][2,0]*r[J][30][2,0]
            hv += -1/4*g[dei(p[J,0],p[I,0],p[I,1],p[J,1])]*r[I][33][2,0]*r[J][15][2,0]
            hv += -1/4*g[dei(p[J,0],p[I,0],p[I,1],p[J,1])]*r[I][48][2,0]*r[J][30][2,0]
            hv += -1/4*g[dei(p[J,1],p[I,1],p[I,0],p[J,0])]*r[I][15][2,0]*r[J][33][2,0]
            hv += -1/4*g[dei(p[J,1],p[I,1],p[I,0],p[J,0])]*r[I][30][2,0]*r[J][48][2,0]
            hv += -1/4*g[dei(p[J,1],p[I,0],p[I,1],p[J,0])]*r[I][33][2,0]*r[J][33][2,0]
            hv += -1/4*g[dei(p[J,1],p[I,0],p[I,1],p[J,0])]*r[I][48][2,0]*r[J][48][2,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[I,0],p[I,1])]*r[I][15][2,0]*r[J][15][2,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][30][2,0]
            hv += 1/2*g[dei(p[J,0],p[J,1],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][15][2,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[I,1],p[I,0])]*r[I][33][2,0]*r[J][15][2,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][30][2,0]
            hv += 1/2*g[dei(p[J,0],p[J,1],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][15][2,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[I,0],p[I,1])]*r[I][15][2,0]*r[J][33][2,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][48][2,0]
            hv += 1/2*g[dei(p[J,1],p[J,0],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][33][2,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[I,1],p[I,0])]*r[I][33][2,0]*r[J][33][2,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][48][2,0]
            hv += 1/2*g[dei(p[J,1],p[J,0],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][33][2,0]
            
            hd[v] = hd.get(v,0.0)+hv
            
    return hd
    
def _I2J3(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            v = tuple(sorted([(I,2),(J,3)]))
            hv = 0.0
            
            hv += 1/4*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][15][2,0]*r[J][15][3,0]
            hv += 1/4*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][30][2,0]*r[J][30][3,0]
            hv += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][15][2,0]*r[J][30][3,0]
            hv += 1/4*g[dei(p[I,0],p[I,1],p[J,1],p[J,0])]*r[I][15][2,0]*r[J][33][3,0]
            hv += 1/4*g[dei(p[I,0],p[I,1],p[J,1],p[J,0])]*r[I][30][2,0]*r[J][48][3,0]
            hv += 1/2*g[dei(p[I,0],p[I,1],p[J,1],p[J,0])]*r[I][15][2,0]*r[J][48][3,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[J,0],p[J,1])]*r[I][33][2,0]*r[J][15][3,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[J,0],p[J,1])]*r[I][48][2,0]*r[J][30][3,0]
            hv += 1/2*g[dei(p[I,1],p[I,0],p[J,0],p[J,1])]*r[I][33][2,0]*r[J][30][3,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[J,1],p[J,0])]*r[I][33][2,0]*r[J][33][3,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[J,1],p[J,0])]*r[I][48][2,0]*r[J][48][3,0]
            hv += 1/2*g[dei(p[I,1],p[I,0],p[J,1],p[J,0])]*r[I][33][2,0]*r[J][48][3,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[J,0],p[I,1])]*r[I][15][2,0]*r[J][15][3,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[J,0],p[I,1])]*r[I][30][2,0]*r[J][30][3,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[J,1],p[I,1])]*r[I][15][2,0]*r[J][33][3,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[J,1],p[I,1])]*r[I][30][2,0]*r[J][48][3,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[J,0],p[I,0])]*r[I][33][2,0]*r[J][15][3,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[J,0],p[I,0])]*r[I][48][2,0]*r[J][30][3,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[J,1],p[I,0])]*r[I][33][2,0]*r[J][33][3,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[J,1],p[I,0])]*r[I][48][2,0]*r[J][48][3,0]
            hv += -1/4*g[dei(p[J,0],p[I,1],p[I,0],p[J,1])]*r[I][15][2,0]*r[J][15][3,0]
            hv += -1/4*g[dei(p[J,0],p[I,1],p[I,0],p[J,1])]*r[I][30][2,0]*r[J][30][3,0]
            hv += -1/4*g[dei(p[J,0],p[I,0],p[I,1],p[J,1])]*r[I][33][2,0]*r[J][15][3,0]
            hv += -1/4*g[dei(p[J,0],p[I,0],p[I,1],p[J,1])]*r[I][48][2,0]*r[J][30][3,0]
            hv += -1/4*g[dei(p[J,1],p[I,1],p[I,0],p[J,0])]*r[I][15][2,0]*r[J][33][3,0]
            hv += -1/4*g[dei(p[J,1],p[I,1],p[I,0],p[J,0])]*r[I][30][2,0]*r[J][48][3,0]
            hv += -1/4*g[dei(p[J,1],p[I,0],p[I,1],p[J,0])]*r[I][33][2,0]*r[J][33][3,0]
            hv += -1/4*g[dei(p[J,1],p[I,0],p[I,1],p[J,0])]*r[I][48][2,0]*r[J][48][3,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[I,0],p[I,1])]*r[I][15][2,0]*r[J][15][3,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][30][3,0]
            hv += 1/2*g[dei(p[J,0],p[J,1],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][15][3,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[I,1],p[I,0])]*r[I][33][2,0]*r[J][15][3,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][30][3,0]
            hv += 1/2*g[dei(p[J,0],p[J,1],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][15][3,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[I,0],p[I,1])]*r[I][15][2,0]*r[J][33][3,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][48][3,0]
            hv += 1/2*g[dei(p[J,1],p[J,0],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][33][3,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[I,1],p[I,0])]*r[I][33][2,0]*r[J][33][3,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][48][3,0]
            hv += 1/2*g[dei(p[J,1],p[J,0],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][33][3,0]
            
            hd[v] = hd.get(v,0.0)+hv
            
    return hd
    
def _I3J2(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            v = tuple(sorted([(I,3),(J,2)]))
            hv = 0.0
            
            hv += 1/4*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][15][3,0]*r[J][15][2,0]
            hv += 1/4*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][30][3,0]*r[J][30][2,0]
            hv += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][15][3,0]*r[J][30][2,0]
            hv += 1/4*g[dei(p[I,0],p[I,1],p[J,1],p[J,0])]*r[I][15][3,0]*r[J][33][2,0]
            hv += 1/4*g[dei(p[I,0],p[I,1],p[J,1],p[J,0])]*r[I][30][3,0]*r[J][48][2,0]
            hv += 1/2*g[dei(p[I,0],p[I,1],p[J,1],p[J,0])]*r[I][15][3,0]*r[J][48][2,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[J,0],p[J,1])]*r[I][33][3,0]*r[J][15][2,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[J,0],p[J,1])]*r[I][48][3,0]*r[J][30][2,0]
            hv += 1/2*g[dei(p[I,1],p[I,0],p[J,0],p[J,1])]*r[I][33][3,0]*r[J][30][2,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[J,1],p[J,0])]*r[I][33][3,0]*r[J][33][2,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[J,1],p[J,0])]*r[I][48][3,0]*r[J][48][2,0]
            hv += 1/2*g[dei(p[I,1],p[I,0],p[J,1],p[J,0])]*r[I][33][3,0]*r[J][48][2,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[J,0],p[I,1])]*r[I][15][3,0]*r[J][15][2,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[J,0],p[I,1])]*r[I][30][3,0]*r[J][30][2,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[J,1],p[I,1])]*r[I][15][3,0]*r[J][33][2,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[J,1],p[I,1])]*r[I][30][3,0]*r[J][48][2,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[J,0],p[I,0])]*r[I][33][3,0]*r[J][15][2,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[J,0],p[I,0])]*r[I][48][3,0]*r[J][30][2,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[J,1],p[I,0])]*r[I][33][3,0]*r[J][33][2,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[J,1],p[I,0])]*r[I][48][3,0]*r[J][48][2,0]
            hv += -1/4*g[dei(p[J,0],p[I,1],p[I,0],p[J,1])]*r[I][15][3,0]*r[J][15][2,0]
            hv += -1/4*g[dei(p[J,0],p[I,1],p[I,0],p[J,1])]*r[I][30][3,0]*r[J][30][2,0]
            hv += -1/4*g[dei(p[J,0],p[I,0],p[I,1],p[J,1])]*r[I][33][3,0]*r[J][15][2,0]
            hv += -1/4*g[dei(p[J,0],p[I,0],p[I,1],p[J,1])]*r[I][48][3,0]*r[J][30][2,0]
            hv += -1/4*g[dei(p[J,1],p[I,1],p[I,0],p[J,0])]*r[I][15][3,0]*r[J][33][2,0]
            hv += -1/4*g[dei(p[J,1],p[I,1],p[I,0],p[J,0])]*r[I][30][3,0]*r[J][48][2,0]
            hv += -1/4*g[dei(p[J,1],p[I,0],p[I,1],p[J,0])]*r[I][33][3,0]*r[J][33][2,0]
            hv += -1/4*g[dei(p[J,1],p[I,0],p[I,1],p[J,0])]*r[I][48][3,0]*r[J][48][2,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[I,0],p[I,1])]*r[I][15][3,0]*r[J][15][2,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][30][2,0]
            hv += 1/2*g[dei(p[J,0],p[J,1],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][15][2,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[I,1],p[I,0])]*r[I][33][3,0]*r[J][15][2,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][30][2,0]
            hv += 1/2*g[dei(p[J,0],p[J,1],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][15][2,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[I,0],p[I,1])]*r[I][15][3,0]*r[J][33][2,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][48][2,0]
            hv += 1/2*g[dei(p[J,1],p[J,0],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][33][2,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[I,1],p[I,0])]*r[I][33][3,0]*r[J][33][2,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][48][2,0]
            hv += 1/2*g[dei(p[J,1],p[J,0],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][33][2,0]
            
            hd[v] = hd.get(v,0.0)+hv
            
    return hd
    
def _I3J3(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            v = tuple(sorted([(I,3),(J,3)]))
            hv = 0.0
            
            hv += 1/4*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][15][3,0]*r[J][15][3,0]
            hv += 1/4*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][30][3,0]*r[J][30][3,0]
            hv += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][15][3,0]*r[J][30][3,0]
            hv += 1/4*g[dei(p[I,0],p[I,1],p[J,1],p[J,0])]*r[I][15][3,0]*r[J][33][3,0]
            hv += 1/4*g[dei(p[I,0],p[I,1],p[J,1],p[J,0])]*r[I][30][3,0]*r[J][48][3,0]
            hv += 1/2*g[dei(p[I,0],p[I,1],p[J,1],p[J,0])]*r[I][15][3,0]*r[J][48][3,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[J,0],p[J,1])]*r[I][33][3,0]*r[J][15][3,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[J,0],p[J,1])]*r[I][48][3,0]*r[J][30][3,0]
            hv += 1/2*g[dei(p[I,1],p[I,0],p[J,0],p[J,1])]*r[I][33][3,0]*r[J][30][3,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[J,1],p[J,0])]*r[I][33][3,0]*r[J][33][3,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[J,1],p[J,0])]*r[I][48][3,0]*r[J][48][3,0]
            hv += 1/2*g[dei(p[I,1],p[I,0],p[J,1],p[J,0])]*r[I][33][3,0]*r[J][48][3,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[J,0],p[I,1])]*r[I][15][3,0]*r[J][15][3,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[J,0],p[I,1])]*r[I][30][3,0]*r[J][30][3,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[J,1],p[I,1])]*r[I][15][3,0]*r[J][33][3,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[J,1],p[I,1])]*r[I][30][3,0]*r[J][48][3,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[J,0],p[I,0])]*r[I][33][3,0]*r[J][15][3,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[J,0],p[I,0])]*r[I][48][3,0]*r[J][30][3,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[J,1],p[I,0])]*r[I][33][3,0]*r[J][33][3,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[J,1],p[I,0])]*r[I][48][3,0]*r[J][48][3,0]
            hv += -1/4*g[dei(p[J,0],p[I,1],p[I,0],p[J,1])]*r[I][15][3,0]*r[J][15][3,0]
            hv += -1/4*g[dei(p[J,0],p[I,1],p[I,0],p[J,1])]*r[I][30][3,0]*r[J][30][3,0]
            hv += -1/4*g[dei(p[J,0],p[I,0],p[I,1],p[J,1])]*r[I][33][3,0]*r[J][15][3,0]
            hv += -1/4*g[dei(p[J,0],p[I,0],p[I,1],p[J,1])]*r[I][48][3,0]*r[J][30][3,0]
            hv += -1/4*g[dei(p[J,1],p[I,1],p[I,0],p[J,0])]*r[I][15][3,0]*r[J][33][3,0]
            hv += -1/4*g[dei(p[J,1],p[I,1],p[I,0],p[J,0])]*r[I][30][3,0]*r[J][48][3,0]
            hv += -1/4*g[dei(p[J,1],p[I,0],p[I,1],p[J,0])]*r[I][33][3,0]*r[J][33][3,0]
            hv += -1/4*g[dei(p[J,1],p[I,0],p[I,1],p[J,0])]*r[I][48][3,0]*r[J][48][3,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[I,0],p[I,1])]*r[I][15][3,0]*r[J][15][3,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][30][3,0]
            hv += 1/2*g[dei(p[J,0],p[J,1],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][15][3,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[I,1],p[I,0])]*r[I][33][3,0]*r[J][15][3,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][30][3,0]
            hv += 1/2*g[dei(p[J,0],p[J,1],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][15][3,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[I,0],p[I,1])]*r[I][15][3,0]*r[J][33][3,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][48][3,0]
            hv += 1/2*g[dei(p[J,1],p[J,0],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][33][3,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[I,1],p[I,0])]*r[I][33][3,0]*r[J][33][3,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][48][3,0]
            hv += 1/2*g[dei(p[J,1],p[J,0],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][33][3,0]
            
            hd[v] = hd.get(v,0.0)+hv
            
    return hd
    
def _I4J5(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            v = tuple(sorted([(I,4),(J,5)]))
            hv = 0.0
            
            hv += -1/2*g[dei(p[I,0],p[J,1],p[J,0],p[I,1])]*r[I][18][4,0]*r[J][27][5,0]
            hv += -1/2*g[dei(p[I,0],p[J,0],p[J,1],p[I,1])]*r[I][18][4,0]*r[J][45][5,0]
            hv += -1/2*g[dei(p[I,1],p[J,1],p[J,0],p[I,0])]*r[I][36][4,0]*r[J][27][5,0]
            hv += -1/2*g[dei(p[I,1],p[J,0],p[J,1],p[I,0])]*r[I][36][4,0]*r[J][45][5,0]
            
            hd[v] = hd.get(v,0.0)+hv
            
    return hd
    
def _I5J4(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            v = tuple(sorted([(I,5),(J,4)]))
            hv = 0.0
            
            hv += -1/2*g[dei(p[J,0],p[I,1],p[I,0],p[J,1])]*r[I][27][5,0]*r[J][18][4,0]
            hv += -1/2*g[dei(p[J,0],p[I,0],p[I,1],p[J,1])]*r[I][45][5,0]*r[J][18][4,0]
            hv += -1/2*g[dei(p[J,1],p[I,1],p[I,0],p[J,0])]*r[I][27][5,0]*r[J][36][4,0]
            hv += -1/2*g[dei(p[J,1],p[I,0],p[I,1],p[J,0])]*r[I][45][5,0]*r[J][36][4,0]
            
            hd[v] = hd.get(v,0.0)+hv
            
    return hd
    
def _I6J15(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            v = tuple(sorted([(I,6),(J,15)]))
            hv = 0.0
            
            hv += 1/2*g[dei(p[J,0],p[I,0],p[J,0],p[I,0])]*r[I][22][6,0]*r[J][11][15,0]
            hv += 1/2*g[dei(p[J,0],p[I,1],p[J,0],p[I,1])]*r[I][52][6,0]*r[J][11][15,0]
            hv += 1/2*g[dei(p[J,1],p[I,0],p[J,1],p[I,0])]*r[I][22][6,0]*r[J][41][15,0]
            hv += 1/2*g[dei(p[J,1],p[I,1],p[J,1],p[I,1])]*r[I][52][6,0]*r[J][41][15,0]
            
            hd[v] = hd.get(v,0.0)+hv
            
    return hd
    
def _I15J9K7(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,15),(J,9),(K,7)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/6*g[dei(p[I,0],p[J,0],p[I,0],p[K,0])]*r[I][11][15,0]*r[J][1][9,0]*r[K][3][7,0]
                hv += -1/6*g[dei(p[I,1],p[J,0],p[I,1],p[K,0])]*r[I][41][15,0]*r[J][1][9,0]*r[K][3][7,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I15J9K8(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,15),(J,9),(K,8)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/6*g[dei(p[I,0],p[J,0],p[I,0],p[K,1])]*r[I][11][15,0]*r[J][1][9,0]*r[K][7][8,0]
                hv += -1/6*g[dei(p[I,1],p[J,0],p[I,1],p[K,1])]*r[I][41][15,0]*r[J][1][9,0]*r[K][7][8,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I15J10K7(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,15),(J,10),(K,7)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/6*g[dei(p[I,0],p[J,1],p[I,0],p[K,0])]*r[I][11][15,0]*r[J][5][10,0]*r[K][3][7,0]
                hv += -1/6*g[dei(p[I,1],p[J,1],p[I,1],p[K,0])]*r[I][41][15,0]*r[J][5][10,0]*r[K][3][7,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I15J10K8(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,15),(J,10),(K,8)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/6*g[dei(p[I,0],p[J,1],p[I,0],p[K,1])]*r[I][11][15,0]*r[J][5][10,0]*r[K][7][8,0]
                hv += -1/6*g[dei(p[I,1],p[J,1],p[I,1],p[K,1])]*r[I][41][15,0]*r[J][5][10,0]*r[K][7][8,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I15J7K9(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,15),(J,7),(K,9)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/6*g[dei(p[I,0],p[K,0],p[I,0],p[J,0])]*r[I][11][15,0]*r[J][3][7,0]*r[K][1][9,0]
                hv += 1/6*g[dei(p[I,1],p[K,0],p[I,1],p[J,0])]*r[I][41][15,0]*r[J][3][7,0]*r[K][1][9,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I15J8K9(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,15),(J,8),(K,9)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/6*g[dei(p[I,0],p[K,0],p[I,0],p[J,1])]*r[I][11][15,0]*r[J][7][8,0]*r[K][1][9,0]
                hv += 1/6*g[dei(p[I,1],p[K,0],p[I,1],p[J,1])]*r[I][41][15,0]*r[J][7][8,0]*r[K][1][9,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I15J7K10(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,15),(J,7),(K,10)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/6*g[dei(p[I,0],p[K,1],p[I,0],p[J,0])]*r[I][11][15,0]*r[J][3][7,0]*r[K][5][10,0]
                hv += 1/6*g[dei(p[I,1],p[K,1],p[I,1],p[J,0])]*r[I][41][15,0]*r[J][3][7,0]*r[K][5][10,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I15J8K10(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,15),(J,8),(K,10)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/6*g[dei(p[I,0],p[K,1],p[I,0],p[J,1])]*r[I][11][15,0]*r[J][7][8,0]*r[K][5][10,0]
                hv += 1/6*g[dei(p[I,1],p[K,1],p[I,1],p[J,1])]*r[I][41][15,0]*r[J][7][8,0]*r[K][5][10,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I1J12K9(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,1),(J,12),(K,9)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/12*g[dei(p[I,0],p[I,0],p[J,0],p[K,0])]*r[I][9][1,0]*r[J][0][12,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[I,1],p[I,1],p[J,0],p[K,0])]*r[I][39][1,0]*r[J][0][12,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[I,0],p[K,0],p[J,0],p[I,0])]*r[I][9][1,0]*r[J][0][12,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[I,1],p[K,0],p[J,0],p[I,1])]*r[I][39][1,0]*r[J][0][12,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[J,0],p[I,0],p[I,0],p[K,0])]*r[I][9][1,0]*r[J][0][12,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[J,0],p[I,1],p[I,1],p[K,0])]*r[I][39][1,0]*r[J][0][12,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[J,0],p[K,0],p[I,0],p[I,0])]*r[I][9][1,0]*r[J][0][12,0]*r[K][1][9,0]
                hv += 1/6*g[dei(p[J,0],p[K,0],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][0][12,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[J,0],p[K,0],p[I,1],p[I,1])]*r[I][39][1,0]*r[J][0][12,0]*r[K][1][9,0]
                hv += 1/6*g[dei(p[J,0],p[K,0],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][0][12,0]*r[K][1][9,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I1J14K7(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,1),(J,14),(K,7)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/12*g[dei(p[I,0],p[I,0],p[J,0],p[K,0])]*r[I][24][1,0]*r[J][2][14,0]*r[K][3][7,0]
                hv += 1/6*g[dei(p[I,0],p[I,0],p[J,0],p[K,0])]*r[I][9][1,0]*r[J][2][14,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[I,1],p[I,1],p[J,0],p[K,0])]*r[I][54][1,0]*r[J][2][14,0]*r[K][3][7,0]
                hv += 1/6*g[dei(p[I,1],p[I,1],p[J,0],p[K,0])]*r[I][39][1,0]*r[J][2][14,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[I,0],p[K,0],p[J,0],p[I,0])]*r[I][24][1,0]*r[J][2][14,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[I,1],p[K,0],p[J,0],p[I,1])]*r[I][54][1,0]*r[J][2][14,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[J,0],p[I,0],p[I,0],p[K,0])]*r[I][24][1,0]*r[J][2][14,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[J,0],p[I,1],p[I,1],p[K,0])]*r[I][54][1,0]*r[J][2][14,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[J,0],p[K,0],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][2][14,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[J,0],p[K,0],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][2][14,0]*r[K][3][7,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I1J12K10(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,1),(J,12),(K,10)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/12*g[dei(p[I,0],p[I,0],p[J,0],p[K,1])]*r[I][9][1,0]*r[J][0][12,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[I,1],p[I,1],p[J,0],p[K,1])]*r[I][39][1,0]*r[J][0][12,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[I,0],p[K,1],p[J,0],p[I,0])]*r[I][9][1,0]*r[J][0][12,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[I,1],p[K,1],p[J,0],p[I,1])]*r[I][39][1,0]*r[J][0][12,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[J,0],p[I,0],p[I,0],p[K,1])]*r[I][9][1,0]*r[J][0][12,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[J,0],p[I,1],p[I,1],p[K,1])]*r[I][39][1,0]*r[J][0][12,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[J,0],p[K,1],p[I,0],p[I,0])]*r[I][9][1,0]*r[J][0][12,0]*r[K][5][10,0]
                hv += 1/6*g[dei(p[J,0],p[K,1],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][0][12,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[J,0],p[K,1],p[I,1],p[I,1])]*r[I][39][1,0]*r[J][0][12,0]*r[K][5][10,0]
                hv += 1/6*g[dei(p[J,0],p[K,1],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][0][12,0]*r[K][5][10,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I1J14K8(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,1),(J,14),(K,8)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/12*g[dei(p[I,0],p[I,0],p[J,0],p[K,1])]*r[I][24][1,0]*r[J][2][14,0]*r[K][7][8,0]
                hv += 1/6*g[dei(p[I,0],p[I,0],p[J,0],p[K,1])]*r[I][9][1,0]*r[J][2][14,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[I,1],p[I,1],p[J,0],p[K,1])]*r[I][54][1,0]*r[J][2][14,0]*r[K][7][8,0]
                hv += 1/6*g[dei(p[I,1],p[I,1],p[J,0],p[K,1])]*r[I][39][1,0]*r[J][2][14,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[I,0],p[K,1],p[J,0],p[I,0])]*r[I][24][1,0]*r[J][2][14,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[I,1],p[K,1],p[J,0],p[I,1])]*r[I][54][1,0]*r[J][2][14,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[J,0],p[I,0],p[I,0],p[K,1])]*r[I][24][1,0]*r[J][2][14,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[J,0],p[I,1],p[I,1],p[K,1])]*r[I][54][1,0]*r[J][2][14,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[J,0],p[K,1],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][2][14,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[J,0],p[K,1],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][2][14,0]*r[K][7][8,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I2J12K9(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,2),(J,12),(K,9)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/12*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][15][2,0]*r[J][0][12,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[I,1],p[I,0],p[J,0],p[K,0])]*r[I][33][2,0]*r[J][0][12,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[I,0],p[K,0],p[J,0],p[I,1])]*r[I][15][2,0]*r[J][0][12,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[I,1],p[K,0],p[J,0],p[I,0])]*r[I][33][2,0]*r[J][0][12,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[J,0],p[I,1],p[I,0],p[K,0])]*r[I][15][2,0]*r[J][0][12,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[J,0],p[I,0],p[I,1],p[K,0])]*r[I][33][2,0]*r[J][0][12,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[J,0],p[K,0],p[I,0],p[I,1])]*r[I][15][2,0]*r[J][0][12,0]*r[K][1][9,0]
                hv += 1/6*g[dei(p[J,0],p[K,0],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][0][12,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[J,0],p[K,0],p[I,1],p[I,0])]*r[I][33][2,0]*r[J][0][12,0]*r[K][1][9,0]
                hv += 1/6*g[dei(p[J,0],p[K,0],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][0][12,0]*r[K][1][9,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I3J12K9(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,3),(J,12),(K,9)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/12*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][15][3,0]*r[J][0][12,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[I,1],p[I,0],p[J,0],p[K,0])]*r[I][33][3,0]*r[J][0][12,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[I,0],p[K,0],p[J,0],p[I,1])]*r[I][15][3,0]*r[J][0][12,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[I,1],p[K,0],p[J,0],p[I,0])]*r[I][33][3,0]*r[J][0][12,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[J,0],p[I,1],p[I,0],p[K,0])]*r[I][15][3,0]*r[J][0][12,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[J,0],p[I,0],p[I,1],p[K,0])]*r[I][33][3,0]*r[J][0][12,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[J,0],p[K,0],p[I,0],p[I,1])]*r[I][15][3,0]*r[J][0][12,0]*r[K][1][9,0]
                hv += 1/6*g[dei(p[J,0],p[K,0],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][0][12,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[J,0],p[K,0],p[I,1],p[I,0])]*r[I][33][3,0]*r[J][0][12,0]*r[K][1][9,0]
                hv += 1/6*g[dei(p[J,0],p[K,0],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][0][12,0]*r[K][1][9,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I2J14K7(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,2),(J,14),(K,7)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/12*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][30][2,0]*r[J][2][14,0]*r[K][3][7,0]
                hv += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][15][2,0]*r[J][2][14,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[I,1],p[I,0],p[J,0],p[K,0])]*r[I][48][2,0]*r[J][2][14,0]*r[K][3][7,0]
                hv += 1/6*g[dei(p[I,1],p[I,0],p[J,0],p[K,0])]*r[I][33][2,0]*r[J][2][14,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[I,0],p[K,0],p[J,0],p[I,1])]*r[I][30][2,0]*r[J][2][14,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[I,1],p[K,0],p[J,0],p[I,0])]*r[I][48][2,0]*r[J][2][14,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[J,0],p[I,1],p[I,0],p[K,0])]*r[I][30][2,0]*r[J][2][14,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[J,0],p[I,0],p[I,1],p[K,0])]*r[I][48][2,0]*r[J][2][14,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[J,0],p[K,0],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][2][14,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[J,0],p[K,0],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][2][14,0]*r[K][3][7,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I3J14K7(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,3),(J,14),(K,7)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/12*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][30][3,0]*r[J][2][14,0]*r[K][3][7,0]
                hv += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][15][3,0]*r[J][2][14,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[I,1],p[I,0],p[J,0],p[K,0])]*r[I][48][3,0]*r[J][2][14,0]*r[K][3][7,0]
                hv += 1/6*g[dei(p[I,1],p[I,0],p[J,0],p[K,0])]*r[I][33][3,0]*r[J][2][14,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[I,0],p[K,0],p[J,0],p[I,1])]*r[I][30][3,0]*r[J][2][14,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[I,1],p[K,0],p[J,0],p[I,0])]*r[I][48][3,0]*r[J][2][14,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[J,0],p[I,1],p[I,0],p[K,0])]*r[I][30][3,0]*r[J][2][14,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[J,0],p[I,0],p[I,1],p[K,0])]*r[I][48][3,0]*r[J][2][14,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[J,0],p[K,0],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][2][14,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[J,0],p[K,0],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][2][14,0]*r[K][3][7,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I2J12K10(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,2),(J,12),(K,10)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/12*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][15][2,0]*r[J][0][12,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[I,1],p[I,0],p[J,0],p[K,1])]*r[I][33][2,0]*r[J][0][12,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[I,0],p[K,1],p[J,0],p[I,1])]*r[I][15][2,0]*r[J][0][12,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[I,1],p[K,1],p[J,0],p[I,0])]*r[I][33][2,0]*r[J][0][12,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[J,0],p[I,1],p[I,0],p[K,1])]*r[I][15][2,0]*r[J][0][12,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[J,0],p[I,0],p[I,1],p[K,1])]*r[I][33][2,0]*r[J][0][12,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[J,0],p[K,1],p[I,0],p[I,1])]*r[I][15][2,0]*r[J][0][12,0]*r[K][5][10,0]
                hv += 1/6*g[dei(p[J,0],p[K,1],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][0][12,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[J,0],p[K,1],p[I,1],p[I,0])]*r[I][33][2,0]*r[J][0][12,0]*r[K][5][10,0]
                hv += 1/6*g[dei(p[J,0],p[K,1],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][0][12,0]*r[K][5][10,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I3J12K10(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,3),(J,12),(K,10)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/12*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][15][3,0]*r[J][0][12,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[I,1],p[I,0],p[J,0],p[K,1])]*r[I][33][3,0]*r[J][0][12,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[I,0],p[K,1],p[J,0],p[I,1])]*r[I][15][3,0]*r[J][0][12,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[I,1],p[K,1],p[J,0],p[I,0])]*r[I][33][3,0]*r[J][0][12,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[J,0],p[I,1],p[I,0],p[K,1])]*r[I][15][3,0]*r[J][0][12,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[J,0],p[I,0],p[I,1],p[K,1])]*r[I][33][3,0]*r[J][0][12,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[J,0],p[K,1],p[I,0],p[I,1])]*r[I][15][3,0]*r[J][0][12,0]*r[K][5][10,0]
                hv += 1/6*g[dei(p[J,0],p[K,1],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][0][12,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[J,0],p[K,1],p[I,1],p[I,0])]*r[I][33][3,0]*r[J][0][12,0]*r[K][5][10,0]
                hv += 1/6*g[dei(p[J,0],p[K,1],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][0][12,0]*r[K][5][10,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I2J14K8(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,2),(J,14),(K,8)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/12*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][30][2,0]*r[J][2][14,0]*r[K][7][8,0]
                hv += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][15][2,0]*r[J][2][14,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[I,1],p[I,0],p[J,0],p[K,1])]*r[I][48][2,0]*r[J][2][14,0]*r[K][7][8,0]
                hv += 1/6*g[dei(p[I,1],p[I,0],p[J,0],p[K,1])]*r[I][33][2,0]*r[J][2][14,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[I,0],p[K,1],p[J,0],p[I,1])]*r[I][30][2,0]*r[J][2][14,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[I,1],p[K,1],p[J,0],p[I,0])]*r[I][48][2,0]*r[J][2][14,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[J,0],p[I,1],p[I,0],p[K,1])]*r[I][30][2,0]*r[J][2][14,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[J,0],p[I,0],p[I,1],p[K,1])]*r[I][48][2,0]*r[J][2][14,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[J,0],p[K,1],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][2][14,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[J,0],p[K,1],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][2][14,0]*r[K][7][8,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I3J14K8(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,3),(J,14),(K,8)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/12*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][30][3,0]*r[J][2][14,0]*r[K][7][8,0]
                hv += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][15][3,0]*r[J][2][14,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[I,1],p[I,0],p[J,0],p[K,1])]*r[I][48][3,0]*r[J][2][14,0]*r[K][7][8,0]
                hv += 1/6*g[dei(p[I,1],p[I,0],p[J,0],p[K,1])]*r[I][33][3,0]*r[J][2][14,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[I,0],p[K,1],p[J,0],p[I,1])]*r[I][30][3,0]*r[J][2][14,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[I,1],p[K,1],p[J,0],p[I,0])]*r[I][48][3,0]*r[J][2][14,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[J,0],p[I,1],p[I,0],p[K,1])]*r[I][30][3,0]*r[J][2][14,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[J,0],p[I,0],p[I,1],p[K,1])]*r[I][48][3,0]*r[J][2][14,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[J,0],p[K,1],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][2][14,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[J,0],p[K,1],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][2][14,0]*r[K][7][8,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I1J11K9(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,1),(J,11),(K,9)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/12*g[dei(p[I,0],p[I,0],p[J,1],p[K,0])]*r[I][9][1,0]*r[J][4][11,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[I,1],p[I,1],p[J,1],p[K,0])]*r[I][39][1,0]*r[J][4][11,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[I,0],p[K,0],p[J,1],p[I,0])]*r[I][9][1,0]*r[J][4][11,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[I,1],p[K,0],p[J,1],p[I,1])]*r[I][39][1,0]*r[J][4][11,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[J,1],p[I,0],p[I,0],p[K,0])]*r[I][9][1,0]*r[J][4][11,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[J,1],p[I,1],p[I,1],p[K,0])]*r[I][39][1,0]*r[J][4][11,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[J,1],p[K,0],p[I,0],p[I,0])]*r[I][9][1,0]*r[J][4][11,0]*r[K][1][9,0]
                hv += 1/6*g[dei(p[J,1],p[K,0],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][4][11,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[J,1],p[K,0],p[I,1],p[I,1])]*r[I][39][1,0]*r[J][4][11,0]*r[K][1][9,0]
                hv += 1/6*g[dei(p[J,1],p[K,0],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][4][11,0]*r[K][1][9,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I1J13K7(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,1),(J,13),(K,7)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/12*g[dei(p[I,0],p[I,0],p[J,1],p[K,0])]*r[I][24][1,0]*r[J][6][13,0]*r[K][3][7,0]
                hv += 1/6*g[dei(p[I,0],p[I,0],p[J,1],p[K,0])]*r[I][9][1,0]*r[J][6][13,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[I,1],p[I,1],p[J,1],p[K,0])]*r[I][54][1,0]*r[J][6][13,0]*r[K][3][7,0]
                hv += 1/6*g[dei(p[I,1],p[I,1],p[J,1],p[K,0])]*r[I][39][1,0]*r[J][6][13,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[I,0],p[K,0],p[J,1],p[I,0])]*r[I][24][1,0]*r[J][6][13,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[I,1],p[K,0],p[J,1],p[I,1])]*r[I][54][1,0]*r[J][6][13,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[J,1],p[I,0],p[I,0],p[K,0])]*r[I][24][1,0]*r[J][6][13,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[J,1],p[I,1],p[I,1],p[K,0])]*r[I][54][1,0]*r[J][6][13,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[J,1],p[K,0],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][6][13,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[J,1],p[K,0],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][6][13,0]*r[K][3][7,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I1J11K10(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,1),(J,11),(K,10)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/12*g[dei(p[I,0],p[I,0],p[J,1],p[K,1])]*r[I][9][1,0]*r[J][4][11,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[I,1],p[I,1],p[J,1],p[K,1])]*r[I][39][1,0]*r[J][4][11,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[I,0],p[K,1],p[J,1],p[I,0])]*r[I][9][1,0]*r[J][4][11,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[I,1],p[K,1],p[J,1],p[I,1])]*r[I][39][1,0]*r[J][4][11,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[J,1],p[I,0],p[I,0],p[K,1])]*r[I][9][1,0]*r[J][4][11,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[J,1],p[I,1],p[I,1],p[K,1])]*r[I][39][1,0]*r[J][4][11,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[J,1],p[K,1],p[I,0],p[I,0])]*r[I][9][1,0]*r[J][4][11,0]*r[K][5][10,0]
                hv += 1/6*g[dei(p[J,1],p[K,1],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][4][11,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[J,1],p[K,1],p[I,1],p[I,1])]*r[I][39][1,0]*r[J][4][11,0]*r[K][5][10,0]
                hv += 1/6*g[dei(p[J,1],p[K,1],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][4][11,0]*r[K][5][10,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I1J13K8(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,1),(J,13),(K,8)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/12*g[dei(p[I,0],p[I,0],p[J,1],p[K,1])]*r[I][24][1,0]*r[J][6][13,0]*r[K][7][8,0]
                hv += 1/6*g[dei(p[I,0],p[I,0],p[J,1],p[K,1])]*r[I][9][1,0]*r[J][6][13,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[I,1],p[I,1],p[J,1],p[K,1])]*r[I][54][1,0]*r[J][6][13,0]*r[K][7][8,0]
                hv += 1/6*g[dei(p[I,1],p[I,1],p[J,1],p[K,1])]*r[I][39][1,0]*r[J][6][13,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[I,0],p[K,1],p[J,1],p[I,0])]*r[I][24][1,0]*r[J][6][13,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[I,1],p[K,1],p[J,1],p[I,1])]*r[I][54][1,0]*r[J][6][13,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[J,1],p[I,0],p[I,0],p[K,1])]*r[I][24][1,0]*r[J][6][13,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[J,1],p[I,1],p[I,1],p[K,1])]*r[I][54][1,0]*r[J][6][13,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[J,1],p[K,1],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][6][13,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[J,1],p[K,1],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][6][13,0]*r[K][7][8,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I2J11K9(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,2),(J,11),(K,9)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/12*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][15][2,0]*r[J][4][11,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[I,1],p[I,0],p[J,1],p[K,0])]*r[I][33][2,0]*r[J][4][11,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[I,0],p[K,0],p[J,1],p[I,1])]*r[I][15][2,0]*r[J][4][11,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[I,1],p[K,0],p[J,1],p[I,0])]*r[I][33][2,0]*r[J][4][11,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[J,1],p[I,1],p[I,0],p[K,0])]*r[I][15][2,0]*r[J][4][11,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[J,1],p[I,0],p[I,1],p[K,0])]*r[I][33][2,0]*r[J][4][11,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[J,1],p[K,0],p[I,0],p[I,1])]*r[I][15][2,0]*r[J][4][11,0]*r[K][1][9,0]
                hv += 1/6*g[dei(p[J,1],p[K,0],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][4][11,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[J,1],p[K,0],p[I,1],p[I,0])]*r[I][33][2,0]*r[J][4][11,0]*r[K][1][9,0]
                hv += 1/6*g[dei(p[J,1],p[K,0],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][4][11,0]*r[K][1][9,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I3J11K9(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,3),(J,11),(K,9)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/12*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][15][3,0]*r[J][4][11,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[I,1],p[I,0],p[J,1],p[K,0])]*r[I][33][3,0]*r[J][4][11,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[I,0],p[K,0],p[J,1],p[I,1])]*r[I][15][3,0]*r[J][4][11,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[I,1],p[K,0],p[J,1],p[I,0])]*r[I][33][3,0]*r[J][4][11,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[J,1],p[I,1],p[I,0],p[K,0])]*r[I][15][3,0]*r[J][4][11,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[J,1],p[I,0],p[I,1],p[K,0])]*r[I][33][3,0]*r[J][4][11,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[J,1],p[K,0],p[I,0],p[I,1])]*r[I][15][3,0]*r[J][4][11,0]*r[K][1][9,0]
                hv += 1/6*g[dei(p[J,1],p[K,0],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][4][11,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[J,1],p[K,0],p[I,1],p[I,0])]*r[I][33][3,0]*r[J][4][11,0]*r[K][1][9,0]
                hv += 1/6*g[dei(p[J,1],p[K,0],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][4][11,0]*r[K][1][9,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I2J13K7(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,2),(J,13),(K,7)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/12*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][30][2,0]*r[J][6][13,0]*r[K][3][7,0]
                hv += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][15][2,0]*r[J][6][13,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[I,1],p[I,0],p[J,1],p[K,0])]*r[I][48][2,0]*r[J][6][13,0]*r[K][3][7,0]
                hv += 1/6*g[dei(p[I,1],p[I,0],p[J,1],p[K,0])]*r[I][33][2,0]*r[J][6][13,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[I,0],p[K,0],p[J,1],p[I,1])]*r[I][30][2,0]*r[J][6][13,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[I,1],p[K,0],p[J,1],p[I,0])]*r[I][48][2,0]*r[J][6][13,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[J,1],p[I,1],p[I,0],p[K,0])]*r[I][30][2,0]*r[J][6][13,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[J,1],p[I,0],p[I,1],p[K,0])]*r[I][48][2,0]*r[J][6][13,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[J,1],p[K,0],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][6][13,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[J,1],p[K,0],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][6][13,0]*r[K][3][7,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I3J13K7(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,3),(J,13),(K,7)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/12*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][30][3,0]*r[J][6][13,0]*r[K][3][7,0]
                hv += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][15][3,0]*r[J][6][13,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[I,1],p[I,0],p[J,1],p[K,0])]*r[I][48][3,0]*r[J][6][13,0]*r[K][3][7,0]
                hv += 1/6*g[dei(p[I,1],p[I,0],p[J,1],p[K,0])]*r[I][33][3,0]*r[J][6][13,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[I,0],p[K,0],p[J,1],p[I,1])]*r[I][30][3,0]*r[J][6][13,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[I,1],p[K,0],p[J,1],p[I,0])]*r[I][48][3,0]*r[J][6][13,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[J,1],p[I,1],p[I,0],p[K,0])]*r[I][30][3,0]*r[J][6][13,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[J,1],p[I,0],p[I,1],p[K,0])]*r[I][48][3,0]*r[J][6][13,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[J,1],p[K,0],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][6][13,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[J,1],p[K,0],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][6][13,0]*r[K][3][7,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I2J11K10(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,2),(J,11),(K,10)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/12*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][15][2,0]*r[J][4][11,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[I,1],p[I,0],p[J,1],p[K,1])]*r[I][33][2,0]*r[J][4][11,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[I,0],p[K,1],p[J,1],p[I,1])]*r[I][15][2,0]*r[J][4][11,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[I,1],p[K,1],p[J,1],p[I,0])]*r[I][33][2,0]*r[J][4][11,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[J,1],p[I,1],p[I,0],p[K,1])]*r[I][15][2,0]*r[J][4][11,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[J,1],p[I,0],p[I,1],p[K,1])]*r[I][33][2,0]*r[J][4][11,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[J,1],p[K,1],p[I,0],p[I,1])]*r[I][15][2,0]*r[J][4][11,0]*r[K][5][10,0]
                hv += 1/6*g[dei(p[J,1],p[K,1],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][4][11,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[J,1],p[K,1],p[I,1],p[I,0])]*r[I][33][2,0]*r[J][4][11,0]*r[K][5][10,0]
                hv += 1/6*g[dei(p[J,1],p[K,1],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][4][11,0]*r[K][5][10,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I3J11K10(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,3),(J,11),(K,10)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/12*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][15][3,0]*r[J][4][11,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[I,1],p[I,0],p[J,1],p[K,1])]*r[I][33][3,0]*r[J][4][11,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[I,0],p[K,1],p[J,1],p[I,1])]*r[I][15][3,0]*r[J][4][11,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[I,1],p[K,1],p[J,1],p[I,0])]*r[I][33][3,0]*r[J][4][11,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[J,1],p[I,1],p[I,0],p[K,1])]*r[I][15][3,0]*r[J][4][11,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[J,1],p[I,0],p[I,1],p[K,1])]*r[I][33][3,0]*r[J][4][11,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[J,1],p[K,1],p[I,0],p[I,1])]*r[I][15][3,0]*r[J][4][11,0]*r[K][5][10,0]
                hv += 1/6*g[dei(p[J,1],p[K,1],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][4][11,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[J,1],p[K,1],p[I,1],p[I,0])]*r[I][33][3,0]*r[J][4][11,0]*r[K][5][10,0]
                hv += 1/6*g[dei(p[J,1],p[K,1],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][4][11,0]*r[K][5][10,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I2J13K8(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,2),(J,13),(K,8)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/12*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][30][2,0]*r[J][6][13,0]*r[K][7][8,0]
                hv += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][15][2,0]*r[J][6][13,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[I,1],p[I,0],p[J,1],p[K,1])]*r[I][48][2,0]*r[J][6][13,0]*r[K][7][8,0]
                hv += 1/6*g[dei(p[I,1],p[I,0],p[J,1],p[K,1])]*r[I][33][2,0]*r[J][6][13,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[I,0],p[K,1],p[J,1],p[I,1])]*r[I][30][2,0]*r[J][6][13,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[I,1],p[K,1],p[J,1],p[I,0])]*r[I][48][2,0]*r[J][6][13,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[J,1],p[I,1],p[I,0],p[K,1])]*r[I][30][2,0]*r[J][6][13,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[J,1],p[I,0],p[I,1],p[K,1])]*r[I][48][2,0]*r[J][6][13,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[J,1],p[K,1],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][6][13,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[J,1],p[K,1],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][6][13,0]*r[K][7][8,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I3J13K8(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,3),(J,13),(K,8)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/12*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][30][3,0]*r[J][6][13,0]*r[K][7][8,0]
                hv += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][15][3,0]*r[J][6][13,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[I,1],p[I,0],p[J,1],p[K,1])]*r[I][48][3,0]*r[J][6][13,0]*r[K][7][8,0]
                hv += 1/6*g[dei(p[I,1],p[I,0],p[J,1],p[K,1])]*r[I][33][3,0]*r[J][6][13,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[I,0],p[K,1],p[J,1],p[I,1])]*r[I][30][3,0]*r[J][6][13,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[I,1],p[K,1],p[J,1],p[I,0])]*r[I][48][3,0]*r[J][6][13,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[J,1],p[I,1],p[I,0],p[K,1])]*r[I][30][3,0]*r[J][6][13,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[J,1],p[I,0],p[I,1],p[K,1])]*r[I][48][3,0]*r[J][6][13,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[J,1],p[K,1],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][6][13,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[J,1],p[K,1],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][6][13,0]*r[K][7][8,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I12J1K9(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,12),(J,1),(K,9)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/12*g[dei(p[I,0],p[J,0],p[J,0],p[K,0])]*r[I][0][12,0]*r[J][9][1,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[I,0],p[J,1],p[J,1],p[K,0])]*r[I][0][12,0]*r[J][39][1,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[I,0],p[K,0],p[J,0],p[J,0])]*r[I][0][12,0]*r[J][9][1,0]*r[K][1][9,0]
                hv += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,0])]*r[I][0][12,0]*r[J][24][1,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[I,0],p[K,0],p[J,1],p[J,1])]*r[I][0][12,0]*r[J][39][1,0]*r[K][1][9,0]
                hv += 1/6*g[dei(p[I,0],p[K,0],p[J,1],p[J,1])]*r[I][0][12,0]*r[J][54][1,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[J,0],p[J,0],p[I,0],p[K,0])]*r[I][0][12,0]*r[J][9][1,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[J,1],p[J,1],p[I,0],p[K,0])]*r[I][0][12,0]*r[J][39][1,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[J,0],p[K,0],p[I,0],p[J,0])]*r[I][0][12,0]*r[J][9][1,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[J,1],p[K,0],p[I,0],p[J,1])]*r[I][0][12,0]*r[J][39][1,0]*r[K][1][9,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I14J1K7(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,14),(J,1),(K,7)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/12*g[dei(p[I,0],p[J,0],p[J,0],p[K,0])]*r[I][2][14,0]*r[J][24][1,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[I,0],p[J,1],p[J,1],p[K,0])]*r[I][2][14,0]*r[J][54][1,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[I,0],p[K,0],p[J,0],p[J,0])]*r[I][2][14,0]*r[J][24][1,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[I,0],p[K,0],p[J,1],p[J,1])]*r[I][2][14,0]*r[J][54][1,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[J,0],p[J,0],p[I,0],p[K,0])]*r[I][2][14,0]*r[J][24][1,0]*r[K][3][7,0]
                hv += 1/6*g[dei(p[J,0],p[J,0],p[I,0],p[K,0])]*r[I][2][14,0]*r[J][9][1,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[J,1],p[J,1],p[I,0],p[K,0])]*r[I][2][14,0]*r[J][54][1,0]*r[K][3][7,0]
                hv += 1/6*g[dei(p[J,1],p[J,1],p[I,0],p[K,0])]*r[I][2][14,0]*r[J][39][1,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[J,0],p[K,0],p[I,0],p[J,0])]*r[I][2][14,0]*r[J][24][1,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[J,1],p[K,0],p[I,0],p[J,1])]*r[I][2][14,0]*r[J][54][1,0]*r[K][3][7,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I12J1K10(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,12),(J,1),(K,10)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/12*g[dei(p[I,0],p[J,0],p[J,0],p[K,1])]*r[I][0][12,0]*r[J][9][1,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[I,0],p[J,1],p[J,1],p[K,1])]*r[I][0][12,0]*r[J][39][1,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[I,0],p[K,1],p[J,0],p[J,0])]*r[I][0][12,0]*r[J][9][1,0]*r[K][5][10,0]
                hv += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,0])]*r[I][0][12,0]*r[J][24][1,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[I,0],p[K,1],p[J,1],p[J,1])]*r[I][0][12,0]*r[J][39][1,0]*r[K][5][10,0]
                hv += 1/6*g[dei(p[I,0],p[K,1],p[J,1],p[J,1])]*r[I][0][12,0]*r[J][54][1,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[J,0],p[J,0],p[I,0],p[K,1])]*r[I][0][12,0]*r[J][9][1,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[J,1],p[J,1],p[I,0],p[K,1])]*r[I][0][12,0]*r[J][39][1,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[J,0],p[K,1],p[I,0],p[J,0])]*r[I][0][12,0]*r[J][9][1,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[J,1],p[K,1],p[I,0],p[J,1])]*r[I][0][12,0]*r[J][39][1,0]*r[K][5][10,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I14J1K8(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,14),(J,1),(K,8)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/12*g[dei(p[I,0],p[J,0],p[J,0],p[K,1])]*r[I][2][14,0]*r[J][24][1,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[I,0],p[J,1],p[J,1],p[K,1])]*r[I][2][14,0]*r[J][54][1,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[I,0],p[K,1],p[J,0],p[J,0])]*r[I][2][14,0]*r[J][24][1,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[I,0],p[K,1],p[J,1],p[J,1])]*r[I][2][14,0]*r[J][54][1,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[J,0],p[J,0],p[I,0],p[K,1])]*r[I][2][14,0]*r[J][24][1,0]*r[K][7][8,0]
                hv += 1/6*g[dei(p[J,0],p[J,0],p[I,0],p[K,1])]*r[I][2][14,0]*r[J][9][1,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[J,1],p[J,1],p[I,0],p[K,1])]*r[I][2][14,0]*r[J][54][1,0]*r[K][7][8,0]
                hv += 1/6*g[dei(p[J,1],p[J,1],p[I,0],p[K,1])]*r[I][2][14,0]*r[J][39][1,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[J,0],p[K,1],p[I,0],p[J,0])]*r[I][2][14,0]*r[J][24][1,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[J,1],p[K,1],p[I,0],p[J,1])]*r[I][2][14,0]*r[J][54][1,0]*r[K][7][8,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I12J2K9(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,12),(J,2),(K,9)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/12*g[dei(p[I,0],p[J,1],p[J,0],p[K,0])]*r[I][0][12,0]*r[J][15][2,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[I,0],p[J,0],p[J,1],p[K,0])]*r[I][0][12,0]*r[J][33][2,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][0][12,0]*r[J][15][2,0]*r[K][1][9,0]
                hv += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][0][12,0]*r[J][30][2,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[I,0],p[K,0],p[J,1],p[J,0])]*r[I][0][12,0]*r[J][33][2,0]*r[K][1][9,0]
                hv += 1/6*g[dei(p[I,0],p[K,0],p[J,1],p[J,0])]*r[I][0][12,0]*r[J][48][2,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[J,0],p[J,1],p[I,0],p[K,0])]*r[I][0][12,0]*r[J][15][2,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[J,1],p[J,0],p[I,0],p[K,0])]*r[I][0][12,0]*r[J][33][2,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[J,0],p[K,0],p[I,0],p[J,1])]*r[I][0][12,0]*r[J][15][2,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[J,1],p[K,0],p[I,0],p[J,0])]*r[I][0][12,0]*r[J][33][2,0]*r[K][1][9,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I12J3K9(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,12),(J,3),(K,9)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/12*g[dei(p[I,0],p[J,1],p[J,0],p[K,0])]*r[I][0][12,0]*r[J][15][3,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[I,0],p[J,0],p[J,1],p[K,0])]*r[I][0][12,0]*r[J][33][3,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][0][12,0]*r[J][15][3,0]*r[K][1][9,0]
                hv += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][0][12,0]*r[J][30][3,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[I,0],p[K,0],p[J,1],p[J,0])]*r[I][0][12,0]*r[J][33][3,0]*r[K][1][9,0]
                hv += 1/6*g[dei(p[I,0],p[K,0],p[J,1],p[J,0])]*r[I][0][12,0]*r[J][48][3,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[J,0],p[J,1],p[I,0],p[K,0])]*r[I][0][12,0]*r[J][15][3,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[J,1],p[J,0],p[I,0],p[K,0])]*r[I][0][12,0]*r[J][33][3,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[J,0],p[K,0],p[I,0],p[J,1])]*r[I][0][12,0]*r[J][15][3,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[J,1],p[K,0],p[I,0],p[J,0])]*r[I][0][12,0]*r[J][33][3,0]*r[K][1][9,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I14J2K7(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,14),(J,2),(K,7)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/12*g[dei(p[I,0],p[J,1],p[J,0],p[K,0])]*r[I][2][14,0]*r[J][30][2,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[I,0],p[J,0],p[J,1],p[K,0])]*r[I][2][14,0]*r[J][48][2,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][2][14,0]*r[J][30][2,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[I,0],p[K,0],p[J,1],p[J,0])]*r[I][2][14,0]*r[J][48][2,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[J,0],p[J,1],p[I,0],p[K,0])]*r[I][2][14,0]*r[J][30][2,0]*r[K][3][7,0]
                hv += 1/6*g[dei(p[J,0],p[J,1],p[I,0],p[K,0])]*r[I][2][14,0]*r[J][15][2,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[J,1],p[J,0],p[I,0],p[K,0])]*r[I][2][14,0]*r[J][48][2,0]*r[K][3][7,0]
                hv += 1/6*g[dei(p[J,1],p[J,0],p[I,0],p[K,0])]*r[I][2][14,0]*r[J][33][2,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[J,0],p[K,0],p[I,0],p[J,1])]*r[I][2][14,0]*r[J][30][2,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[J,1],p[K,0],p[I,0],p[J,0])]*r[I][2][14,0]*r[J][48][2,0]*r[K][3][7,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I14J3K7(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,14),(J,3),(K,7)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/12*g[dei(p[I,0],p[J,1],p[J,0],p[K,0])]*r[I][2][14,0]*r[J][30][3,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[I,0],p[J,0],p[J,1],p[K,0])]*r[I][2][14,0]*r[J][48][3,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][2][14,0]*r[J][30][3,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[I,0],p[K,0],p[J,1],p[J,0])]*r[I][2][14,0]*r[J][48][3,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[J,0],p[J,1],p[I,0],p[K,0])]*r[I][2][14,0]*r[J][30][3,0]*r[K][3][7,0]
                hv += 1/6*g[dei(p[J,0],p[J,1],p[I,0],p[K,0])]*r[I][2][14,0]*r[J][15][3,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[J,1],p[J,0],p[I,0],p[K,0])]*r[I][2][14,0]*r[J][48][3,0]*r[K][3][7,0]
                hv += 1/6*g[dei(p[J,1],p[J,0],p[I,0],p[K,0])]*r[I][2][14,0]*r[J][33][3,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[J,0],p[K,0],p[I,0],p[J,1])]*r[I][2][14,0]*r[J][30][3,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[J,1],p[K,0],p[I,0],p[J,0])]*r[I][2][14,0]*r[J][48][3,0]*r[K][3][7,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I12J5K7(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,12),(J,5),(K,7)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/6*g[dei(p[I,0],p[J,1],p[J,0],p[K,0])]*r[I][0][12,0]*r[J][27][5,0]*r[K][3][7,0]
                hv += -1/6*g[dei(p[I,0],p[J,0],p[J,1],p[K,0])]*r[I][0][12,0]*r[J][45][5,0]*r[K][3][7,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I12J2K10(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,12),(J,2),(K,10)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/12*g[dei(p[I,0],p[J,1],p[J,0],p[K,1])]*r[I][0][12,0]*r[J][15][2,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[I,0],p[J,0],p[J,1],p[K,1])]*r[I][0][12,0]*r[J][33][2,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][0][12,0]*r[J][15][2,0]*r[K][5][10,0]
                hv += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][0][12,0]*r[J][30][2,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[I,0],p[K,1],p[J,1],p[J,0])]*r[I][0][12,0]*r[J][33][2,0]*r[K][5][10,0]
                hv += 1/6*g[dei(p[I,0],p[K,1],p[J,1],p[J,0])]*r[I][0][12,0]*r[J][48][2,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[J,0],p[J,1],p[I,0],p[K,1])]*r[I][0][12,0]*r[J][15][2,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[J,1],p[J,0],p[I,0],p[K,1])]*r[I][0][12,0]*r[J][33][2,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[J,0],p[K,1],p[I,0],p[J,1])]*r[I][0][12,0]*r[J][15][2,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[J,1],p[K,1],p[I,0],p[J,0])]*r[I][0][12,0]*r[J][33][2,0]*r[K][5][10,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I12J3K10(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,12),(J,3),(K,10)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/12*g[dei(p[I,0],p[J,1],p[J,0],p[K,1])]*r[I][0][12,0]*r[J][15][3,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[I,0],p[J,0],p[J,1],p[K,1])]*r[I][0][12,0]*r[J][33][3,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][0][12,0]*r[J][15][3,0]*r[K][5][10,0]
                hv += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][0][12,0]*r[J][30][3,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[I,0],p[K,1],p[J,1],p[J,0])]*r[I][0][12,0]*r[J][33][3,0]*r[K][5][10,0]
                hv += 1/6*g[dei(p[I,0],p[K,1],p[J,1],p[J,0])]*r[I][0][12,0]*r[J][48][3,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[J,0],p[J,1],p[I,0],p[K,1])]*r[I][0][12,0]*r[J][15][3,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[J,1],p[J,0],p[I,0],p[K,1])]*r[I][0][12,0]*r[J][33][3,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[J,0],p[K,1],p[I,0],p[J,1])]*r[I][0][12,0]*r[J][15][3,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[J,1],p[K,1],p[I,0],p[J,0])]*r[I][0][12,0]*r[J][33][3,0]*r[K][5][10,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I14J2K8(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,14),(J,2),(K,8)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/12*g[dei(p[I,0],p[J,1],p[J,0],p[K,1])]*r[I][2][14,0]*r[J][30][2,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[I,0],p[J,0],p[J,1],p[K,1])]*r[I][2][14,0]*r[J][48][2,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][2][14,0]*r[J][30][2,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[I,0],p[K,1],p[J,1],p[J,0])]*r[I][2][14,0]*r[J][48][2,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[J,0],p[J,1],p[I,0],p[K,1])]*r[I][2][14,0]*r[J][30][2,0]*r[K][7][8,0]
                hv += 1/6*g[dei(p[J,0],p[J,1],p[I,0],p[K,1])]*r[I][2][14,0]*r[J][15][2,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[J,1],p[J,0],p[I,0],p[K,1])]*r[I][2][14,0]*r[J][48][2,0]*r[K][7][8,0]
                hv += 1/6*g[dei(p[J,1],p[J,0],p[I,0],p[K,1])]*r[I][2][14,0]*r[J][33][2,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[J,0],p[K,1],p[I,0],p[J,1])]*r[I][2][14,0]*r[J][30][2,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[J,1],p[K,1],p[I,0],p[J,0])]*r[I][2][14,0]*r[J][48][2,0]*r[K][7][8,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I14J3K8(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,14),(J,3),(K,8)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/12*g[dei(p[I,0],p[J,1],p[J,0],p[K,1])]*r[I][2][14,0]*r[J][30][3,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[I,0],p[J,0],p[J,1],p[K,1])]*r[I][2][14,0]*r[J][48][3,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][2][14,0]*r[J][30][3,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[I,0],p[K,1],p[J,1],p[J,0])]*r[I][2][14,0]*r[J][48][3,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[J,0],p[J,1],p[I,0],p[K,1])]*r[I][2][14,0]*r[J][30][3,0]*r[K][7][8,0]
                hv += 1/6*g[dei(p[J,0],p[J,1],p[I,0],p[K,1])]*r[I][2][14,0]*r[J][15][3,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[J,1],p[J,0],p[I,0],p[K,1])]*r[I][2][14,0]*r[J][48][3,0]*r[K][7][8,0]
                hv += 1/6*g[dei(p[J,1],p[J,0],p[I,0],p[K,1])]*r[I][2][14,0]*r[J][33][3,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[J,0],p[K,1],p[I,0],p[J,1])]*r[I][2][14,0]*r[J][30][3,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[J,1],p[K,1],p[I,0],p[J,0])]*r[I][2][14,0]*r[J][48][3,0]*r[K][7][8,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I12J5K8(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,12),(J,5),(K,8)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/6*g[dei(p[I,0],p[J,1],p[J,0],p[K,1])]*r[I][0][12,0]*r[J][27][5,0]*r[K][7][8,0]
                hv += -1/6*g[dei(p[I,0],p[J,0],p[J,1],p[K,1])]*r[I][0][12,0]*r[J][45][5,0]*r[K][7][8,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I11J1K9(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,11),(J,1),(K,9)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/12*g[dei(p[I,1],p[J,0],p[J,0],p[K,0])]*r[I][4][11,0]*r[J][9][1,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[I,1],p[J,1],p[J,1],p[K,0])]*r[I][4][11,0]*r[J][39][1,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[I,1],p[K,0],p[J,0],p[J,0])]*r[I][4][11,0]*r[J][9][1,0]*r[K][1][9,0]
                hv += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,0])]*r[I][4][11,0]*r[J][24][1,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[I,1],p[K,0],p[J,1],p[J,1])]*r[I][4][11,0]*r[J][39][1,0]*r[K][1][9,0]
                hv += 1/6*g[dei(p[I,1],p[K,0],p[J,1],p[J,1])]*r[I][4][11,0]*r[J][54][1,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[J,0],p[J,0],p[I,1],p[K,0])]*r[I][4][11,0]*r[J][9][1,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[J,1],p[J,1],p[I,1],p[K,0])]*r[I][4][11,0]*r[J][39][1,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[J,0],p[K,0],p[I,1],p[J,0])]*r[I][4][11,0]*r[J][9][1,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[J,1],p[K,0],p[I,1],p[J,1])]*r[I][4][11,0]*r[J][39][1,0]*r[K][1][9,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I13J1K7(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,13),(J,1),(K,7)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/12*g[dei(p[I,1],p[J,0],p[J,0],p[K,0])]*r[I][6][13,0]*r[J][24][1,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[I,1],p[J,1],p[J,1],p[K,0])]*r[I][6][13,0]*r[J][54][1,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[I,1],p[K,0],p[J,0],p[J,0])]*r[I][6][13,0]*r[J][24][1,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[I,1],p[K,0],p[J,1],p[J,1])]*r[I][6][13,0]*r[J][54][1,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[J,0],p[J,0],p[I,1],p[K,0])]*r[I][6][13,0]*r[J][24][1,0]*r[K][3][7,0]
                hv += 1/6*g[dei(p[J,0],p[J,0],p[I,1],p[K,0])]*r[I][6][13,0]*r[J][9][1,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[J,1],p[J,1],p[I,1],p[K,0])]*r[I][6][13,0]*r[J][54][1,0]*r[K][3][7,0]
                hv += 1/6*g[dei(p[J,1],p[J,1],p[I,1],p[K,0])]*r[I][6][13,0]*r[J][39][1,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[J,0],p[K,0],p[I,1],p[J,0])]*r[I][6][13,0]*r[J][24][1,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[J,1],p[K,0],p[I,1],p[J,1])]*r[I][6][13,0]*r[J][54][1,0]*r[K][3][7,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I11J1K10(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,11),(J,1),(K,10)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/12*g[dei(p[I,1],p[J,0],p[J,0],p[K,1])]*r[I][4][11,0]*r[J][9][1,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[I,1],p[J,1],p[J,1],p[K,1])]*r[I][4][11,0]*r[J][39][1,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[I,1],p[K,1],p[J,0],p[J,0])]*r[I][4][11,0]*r[J][9][1,0]*r[K][5][10,0]
                hv += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,0])]*r[I][4][11,0]*r[J][24][1,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[I,1],p[K,1],p[J,1],p[J,1])]*r[I][4][11,0]*r[J][39][1,0]*r[K][5][10,0]
                hv += 1/6*g[dei(p[I,1],p[K,1],p[J,1],p[J,1])]*r[I][4][11,0]*r[J][54][1,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[J,0],p[J,0],p[I,1],p[K,1])]*r[I][4][11,0]*r[J][9][1,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[J,1],p[J,1],p[I,1],p[K,1])]*r[I][4][11,0]*r[J][39][1,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[J,0],p[K,1],p[I,1],p[J,0])]*r[I][4][11,0]*r[J][9][1,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[J,1],p[K,1],p[I,1],p[J,1])]*r[I][4][11,0]*r[J][39][1,0]*r[K][5][10,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I13J1K8(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,13),(J,1),(K,8)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/12*g[dei(p[I,1],p[J,0],p[J,0],p[K,1])]*r[I][6][13,0]*r[J][24][1,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[I,1],p[J,1],p[J,1],p[K,1])]*r[I][6][13,0]*r[J][54][1,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[I,1],p[K,1],p[J,0],p[J,0])]*r[I][6][13,0]*r[J][24][1,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[I,1],p[K,1],p[J,1],p[J,1])]*r[I][6][13,0]*r[J][54][1,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[J,0],p[J,0],p[I,1],p[K,1])]*r[I][6][13,0]*r[J][24][1,0]*r[K][7][8,0]
                hv += 1/6*g[dei(p[J,0],p[J,0],p[I,1],p[K,1])]*r[I][6][13,0]*r[J][9][1,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[J,1],p[J,1],p[I,1],p[K,1])]*r[I][6][13,0]*r[J][54][1,0]*r[K][7][8,0]
                hv += 1/6*g[dei(p[J,1],p[J,1],p[I,1],p[K,1])]*r[I][6][13,0]*r[J][39][1,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[J,0],p[K,1],p[I,1],p[J,0])]*r[I][6][13,0]*r[J][24][1,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[J,1],p[K,1],p[I,1],p[J,1])]*r[I][6][13,0]*r[J][54][1,0]*r[K][7][8,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I11J2K9(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,11),(J,2),(K,9)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/12*g[dei(p[I,1],p[J,1],p[J,0],p[K,0])]*r[I][4][11,0]*r[J][15][2,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[I,1],p[J,0],p[J,1],p[K,0])]*r[I][4][11,0]*r[J][33][2,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][4][11,0]*r[J][15][2,0]*r[K][1][9,0]
                hv += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][4][11,0]*r[J][30][2,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[I,1],p[K,0],p[J,1],p[J,0])]*r[I][4][11,0]*r[J][33][2,0]*r[K][1][9,0]
                hv += 1/6*g[dei(p[I,1],p[K,0],p[J,1],p[J,0])]*r[I][4][11,0]*r[J][48][2,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[J,0],p[J,1],p[I,1],p[K,0])]*r[I][4][11,0]*r[J][15][2,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[J,1],p[J,0],p[I,1],p[K,0])]*r[I][4][11,0]*r[J][33][2,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[J,0],p[K,0],p[I,1],p[J,1])]*r[I][4][11,0]*r[J][15][2,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[J,1],p[K,0],p[I,1],p[J,0])]*r[I][4][11,0]*r[J][33][2,0]*r[K][1][9,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I11J3K9(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,11),(J,3),(K,9)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/12*g[dei(p[I,1],p[J,1],p[J,0],p[K,0])]*r[I][4][11,0]*r[J][15][3,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[I,1],p[J,0],p[J,1],p[K,0])]*r[I][4][11,0]*r[J][33][3,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][4][11,0]*r[J][15][3,0]*r[K][1][9,0]
                hv += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][4][11,0]*r[J][30][3,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[I,1],p[K,0],p[J,1],p[J,0])]*r[I][4][11,0]*r[J][33][3,0]*r[K][1][9,0]
                hv += 1/6*g[dei(p[I,1],p[K,0],p[J,1],p[J,0])]*r[I][4][11,0]*r[J][48][3,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[J,0],p[J,1],p[I,1],p[K,0])]*r[I][4][11,0]*r[J][15][3,0]*r[K][1][9,0]
                hv += 1/12*g[dei(p[J,1],p[J,0],p[I,1],p[K,0])]*r[I][4][11,0]*r[J][33][3,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[J,0],p[K,0],p[I,1],p[J,1])]*r[I][4][11,0]*r[J][15][3,0]*r[K][1][9,0]
                hv += -1/12*g[dei(p[J,1],p[K,0],p[I,1],p[J,0])]*r[I][4][11,0]*r[J][33][3,0]*r[K][1][9,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I13J2K7(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,13),(J,2),(K,7)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/12*g[dei(p[I,1],p[J,1],p[J,0],p[K,0])]*r[I][6][13,0]*r[J][30][2,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[I,1],p[J,0],p[J,1],p[K,0])]*r[I][6][13,0]*r[J][48][2,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][6][13,0]*r[J][30][2,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[I,1],p[K,0],p[J,1],p[J,0])]*r[I][6][13,0]*r[J][48][2,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[J,0],p[J,1],p[I,1],p[K,0])]*r[I][6][13,0]*r[J][30][2,0]*r[K][3][7,0]
                hv += 1/6*g[dei(p[J,0],p[J,1],p[I,1],p[K,0])]*r[I][6][13,0]*r[J][15][2,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[J,1],p[J,0],p[I,1],p[K,0])]*r[I][6][13,0]*r[J][48][2,0]*r[K][3][7,0]
                hv += 1/6*g[dei(p[J,1],p[J,0],p[I,1],p[K,0])]*r[I][6][13,0]*r[J][33][2,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[J,0],p[K,0],p[I,1],p[J,1])]*r[I][6][13,0]*r[J][30][2,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[J,1],p[K,0],p[I,1],p[J,0])]*r[I][6][13,0]*r[J][48][2,0]*r[K][3][7,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I13J3K7(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,13),(J,3),(K,7)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/12*g[dei(p[I,1],p[J,1],p[J,0],p[K,0])]*r[I][6][13,0]*r[J][30][3,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[I,1],p[J,0],p[J,1],p[K,0])]*r[I][6][13,0]*r[J][48][3,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][6][13,0]*r[J][30][3,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[I,1],p[K,0],p[J,1],p[J,0])]*r[I][6][13,0]*r[J][48][3,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[J,0],p[J,1],p[I,1],p[K,0])]*r[I][6][13,0]*r[J][30][3,0]*r[K][3][7,0]
                hv += 1/6*g[dei(p[J,0],p[J,1],p[I,1],p[K,0])]*r[I][6][13,0]*r[J][15][3,0]*r[K][3][7,0]
                hv += 1/12*g[dei(p[J,1],p[J,0],p[I,1],p[K,0])]*r[I][6][13,0]*r[J][48][3,0]*r[K][3][7,0]
                hv += 1/6*g[dei(p[J,1],p[J,0],p[I,1],p[K,0])]*r[I][6][13,0]*r[J][33][3,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[J,0],p[K,0],p[I,1],p[J,1])]*r[I][6][13,0]*r[J][30][3,0]*r[K][3][7,0]
                hv += -1/12*g[dei(p[J,1],p[K,0],p[I,1],p[J,0])]*r[I][6][13,0]*r[J][48][3,0]*r[K][3][7,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I11J5K7(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,11),(J,5),(K,7)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/6*g[dei(p[I,1],p[J,1],p[J,0],p[K,0])]*r[I][4][11,0]*r[J][27][5,0]*r[K][3][7,0]
                hv += -1/6*g[dei(p[I,1],p[J,0],p[J,1],p[K,0])]*r[I][4][11,0]*r[J][45][5,0]*r[K][3][7,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I11J2K10(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,11),(J,2),(K,10)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/12*g[dei(p[I,1],p[J,1],p[J,0],p[K,1])]*r[I][4][11,0]*r[J][15][2,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[I,1],p[J,0],p[J,1],p[K,1])]*r[I][4][11,0]*r[J][33][2,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][4][11,0]*r[J][15][2,0]*r[K][5][10,0]
                hv += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][4][11,0]*r[J][30][2,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[I,1],p[K,1],p[J,1],p[J,0])]*r[I][4][11,0]*r[J][33][2,0]*r[K][5][10,0]
                hv += 1/6*g[dei(p[I,1],p[K,1],p[J,1],p[J,0])]*r[I][4][11,0]*r[J][48][2,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[J,0],p[J,1],p[I,1],p[K,1])]*r[I][4][11,0]*r[J][15][2,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[J,1],p[J,0],p[I,1],p[K,1])]*r[I][4][11,0]*r[J][33][2,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[J,0],p[K,1],p[I,1],p[J,1])]*r[I][4][11,0]*r[J][15][2,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[J,1],p[K,1],p[I,1],p[J,0])]*r[I][4][11,0]*r[J][33][2,0]*r[K][5][10,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I11J3K10(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,11),(J,3),(K,10)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/12*g[dei(p[I,1],p[J,1],p[J,0],p[K,1])]*r[I][4][11,0]*r[J][15][3,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[I,1],p[J,0],p[J,1],p[K,1])]*r[I][4][11,0]*r[J][33][3,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][4][11,0]*r[J][15][3,0]*r[K][5][10,0]
                hv += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][4][11,0]*r[J][30][3,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[I,1],p[K,1],p[J,1],p[J,0])]*r[I][4][11,0]*r[J][33][3,0]*r[K][5][10,0]
                hv += 1/6*g[dei(p[I,1],p[K,1],p[J,1],p[J,0])]*r[I][4][11,0]*r[J][48][3,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[J,0],p[J,1],p[I,1],p[K,1])]*r[I][4][11,0]*r[J][15][3,0]*r[K][5][10,0]
                hv += 1/12*g[dei(p[J,1],p[J,0],p[I,1],p[K,1])]*r[I][4][11,0]*r[J][33][3,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[J,0],p[K,1],p[I,1],p[J,1])]*r[I][4][11,0]*r[J][15][3,0]*r[K][5][10,0]
                hv += -1/12*g[dei(p[J,1],p[K,1],p[I,1],p[J,0])]*r[I][4][11,0]*r[J][33][3,0]*r[K][5][10,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I13J2K8(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,13),(J,2),(K,8)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/12*g[dei(p[I,1],p[J,1],p[J,0],p[K,1])]*r[I][6][13,0]*r[J][30][2,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[I,1],p[J,0],p[J,1],p[K,1])]*r[I][6][13,0]*r[J][48][2,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][6][13,0]*r[J][30][2,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[I,1],p[K,1],p[J,1],p[J,0])]*r[I][6][13,0]*r[J][48][2,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[J,0],p[J,1],p[I,1],p[K,1])]*r[I][6][13,0]*r[J][30][2,0]*r[K][7][8,0]
                hv += 1/6*g[dei(p[J,0],p[J,1],p[I,1],p[K,1])]*r[I][6][13,0]*r[J][15][2,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[J,1],p[J,0],p[I,1],p[K,1])]*r[I][6][13,0]*r[J][48][2,0]*r[K][7][8,0]
                hv += 1/6*g[dei(p[J,1],p[J,0],p[I,1],p[K,1])]*r[I][6][13,0]*r[J][33][2,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[J,0],p[K,1],p[I,1],p[J,1])]*r[I][6][13,0]*r[J][30][2,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[J,1],p[K,1],p[I,1],p[J,0])]*r[I][6][13,0]*r[J][48][2,0]*r[K][7][8,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I13J3K8(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,13),(J,3),(K,8)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/12*g[dei(p[I,1],p[J,1],p[J,0],p[K,1])]*r[I][6][13,0]*r[J][30][3,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[I,1],p[J,0],p[J,1],p[K,1])]*r[I][6][13,0]*r[J][48][3,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][6][13,0]*r[J][30][3,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[I,1],p[K,1],p[J,1],p[J,0])]*r[I][6][13,0]*r[J][48][3,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[J,0],p[J,1],p[I,1],p[K,1])]*r[I][6][13,0]*r[J][30][3,0]*r[K][7][8,0]
                hv += 1/6*g[dei(p[J,0],p[J,1],p[I,1],p[K,1])]*r[I][6][13,0]*r[J][15][3,0]*r[K][7][8,0]
                hv += 1/12*g[dei(p[J,1],p[J,0],p[I,1],p[K,1])]*r[I][6][13,0]*r[J][48][3,0]*r[K][7][8,0]
                hv += 1/6*g[dei(p[J,1],p[J,0],p[I,1],p[K,1])]*r[I][6][13,0]*r[J][33][3,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[J,0],p[K,1],p[I,1],p[J,1])]*r[I][6][13,0]*r[J][30][3,0]*r[K][7][8,0]
                hv += -1/12*g[dei(p[J,1],p[K,1],p[I,1],p[J,0])]*r[I][6][13,0]*r[J][48][3,0]*r[K][7][8,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I11J5K8(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,11),(J,5),(K,8)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/6*g[dei(p[I,1],p[J,1],p[J,0],p[K,1])]*r[I][4][11,0]*r[J][27][5,0]*r[K][7][8,0]
                hv += -1/6*g[dei(p[I,1],p[J,0],p[J,1],p[K,1])]*r[I][4][11,0]*r[J][45][5,0]*r[K][7][8,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I4J14K9(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,4),(J,14),(K,9)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/6*g[dei(p[I,0],p[K,0],p[J,0],p[I,1])]*r[I][18][4,0]*r[J][2][14,0]*r[K][1][9,0]
                hv += -1/6*g[dei(p[I,1],p[K,0],p[J,0],p[I,0])]*r[I][36][4,0]*r[J][2][14,0]*r[K][1][9,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I4J14K10(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,4),(J,14),(K,10)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/6*g[dei(p[I,0],p[K,1],p[J,0],p[I,1])]*r[I][18][4,0]*r[J][2][14,0]*r[K][5][10,0]
                hv += -1/6*g[dei(p[I,1],p[K,1],p[J,0],p[I,0])]*r[I][36][4,0]*r[J][2][14,0]*r[K][5][10,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I4J13K9(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,4),(J,13),(K,9)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/6*g[dei(p[I,0],p[K,0],p[J,1],p[I,1])]*r[I][18][4,0]*r[J][6][13,0]*r[K][1][9,0]
                hv += -1/6*g[dei(p[I,1],p[K,0],p[J,1],p[I,0])]*r[I][36][4,0]*r[J][6][13,0]*r[K][1][9,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I4J13K10(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,4),(J,13),(K,10)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/6*g[dei(p[I,0],p[K,1],p[J,1],p[I,1])]*r[I][18][4,0]*r[J][6][13,0]*r[K][5][10,0]
                hv += -1/6*g[dei(p[I,1],p[K,1],p[J,1],p[I,0])]*r[I][36][4,0]*r[J][6][13,0]*r[K][5][10,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I12J14K6(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,12),(J,14),(K,6)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[K,0])]*r[I][0][12,0]*r[J][2][14,0]*r[K][22][6,0]
                hv += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[K,1])]*r[I][0][12,0]*r[J][2][14,0]*r[K][52][6,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I12J13K6(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,12),(J,13),(K,6)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/6*g[dei(p[I,0],p[K,0],p[J,1],p[K,0])]*r[I][0][12,0]*r[J][6][13,0]*r[K][22][6,0]
                hv += 1/6*g[dei(p[I,0],p[K,1],p[J,1],p[K,1])]*r[I][0][12,0]*r[J][6][13,0]*r[K][52][6,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I11J14K6(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,11),(J,14),(K,6)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[K,0])]*r[I][4][11,0]*r[J][2][14,0]*r[K][22][6,0]
                hv += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[K,1])]*r[I][4][11,0]*r[J][2][14,0]*r[K][52][6,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I11J13K6(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,11),(J,13),(K,6)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/6*g[dei(p[I,1],p[K,0],p[J,1],p[K,0])]*r[I][4][11,0]*r[J][6][13,0]*r[K][22][6,0]
                hv += 1/6*g[dei(p[I,1],p[K,1],p[J,1],p[K,1])]*r[I][4][11,0]*r[J][6][13,0]*r[K][52][6,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I1J9K12(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,1),(J,9),(K,12)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/12*g[dei(p[I,0],p[I,0],p[K,0],p[J,0])]*r[I][9][1,0]*r[J][1][9,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[I,1],p[I,1],p[K,0],p[J,0])]*r[I][39][1,0]*r[J][1][9,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[I,0],p[J,0],p[K,0],p[I,0])]*r[I][9][1,0]*r[J][1][9,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[I,1],p[J,0],p[K,0],p[I,1])]*r[I][39][1,0]*r[J][1][9,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[K,0],p[I,0],p[I,0],p[J,0])]*r[I][9][1,0]*r[J][1][9,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[K,0],p[I,1],p[I,1],p[J,0])]*r[I][39][1,0]*r[J][1][9,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[K,0],p[J,0],p[I,0],p[I,0])]*r[I][9][1,0]*r[J][1][9,0]*r[K][0][12,0]
                hv += -1/6*g[dei(p[K,0],p[J,0],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][1][9,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[K,0],p[J,0],p[I,1],p[I,1])]*r[I][39][1,0]*r[J][1][9,0]*r[K][0][12,0]
                hv += -1/6*g[dei(p[K,0],p[J,0],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][1][9,0]*r[K][0][12,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I1J7K14(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,1),(J,7),(K,14)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/12*g[dei(p[I,0],p[I,0],p[K,0],p[J,0])]*r[I][24][1,0]*r[J][3][7,0]*r[K][2][14,0]
                hv += -1/6*g[dei(p[I,0],p[I,0],p[K,0],p[J,0])]*r[I][9][1,0]*r[J][3][7,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[I,1],p[I,1],p[K,0],p[J,0])]*r[I][54][1,0]*r[J][3][7,0]*r[K][2][14,0]
                hv += -1/6*g[dei(p[I,1],p[I,1],p[K,0],p[J,0])]*r[I][39][1,0]*r[J][3][7,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[I,0],p[J,0],p[K,0],p[I,0])]*r[I][24][1,0]*r[J][3][7,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[I,1],p[J,0],p[K,0],p[I,1])]*r[I][54][1,0]*r[J][3][7,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[K,0],p[I,0],p[I,0],p[J,0])]*r[I][24][1,0]*r[J][3][7,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[K,0],p[I,1],p[I,1],p[J,0])]*r[I][54][1,0]*r[J][3][7,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[K,0],p[J,0],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][3][7,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[K,0],p[J,0],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][3][7,0]*r[K][2][14,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I1J10K12(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,1),(J,10),(K,12)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/12*g[dei(p[I,0],p[I,0],p[K,0],p[J,1])]*r[I][9][1,0]*r[J][5][10,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[I,1],p[I,1],p[K,0],p[J,1])]*r[I][39][1,0]*r[J][5][10,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[I,0],p[J,1],p[K,0],p[I,0])]*r[I][9][1,0]*r[J][5][10,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[I,1],p[J,1],p[K,0],p[I,1])]*r[I][39][1,0]*r[J][5][10,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[K,0],p[I,0],p[I,0],p[J,1])]*r[I][9][1,0]*r[J][5][10,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[K,0],p[I,1],p[I,1],p[J,1])]*r[I][39][1,0]*r[J][5][10,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[K,0],p[J,1],p[I,0],p[I,0])]*r[I][9][1,0]*r[J][5][10,0]*r[K][0][12,0]
                hv += -1/6*g[dei(p[K,0],p[J,1],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][5][10,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[K,0],p[J,1],p[I,1],p[I,1])]*r[I][39][1,0]*r[J][5][10,0]*r[K][0][12,0]
                hv += -1/6*g[dei(p[K,0],p[J,1],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][5][10,0]*r[K][0][12,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I1J8K14(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,1),(J,8),(K,14)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/12*g[dei(p[I,0],p[I,0],p[K,0],p[J,1])]*r[I][24][1,0]*r[J][7][8,0]*r[K][2][14,0]
                hv += -1/6*g[dei(p[I,0],p[I,0],p[K,0],p[J,1])]*r[I][9][1,0]*r[J][7][8,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[I,1],p[I,1],p[K,0],p[J,1])]*r[I][54][1,0]*r[J][7][8,0]*r[K][2][14,0]
                hv += -1/6*g[dei(p[I,1],p[I,1],p[K,0],p[J,1])]*r[I][39][1,0]*r[J][7][8,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[I,0],p[J,1],p[K,0],p[I,0])]*r[I][24][1,0]*r[J][7][8,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[I,1],p[J,1],p[K,0],p[I,1])]*r[I][54][1,0]*r[J][7][8,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[K,0],p[I,0],p[I,0],p[J,1])]*r[I][24][1,0]*r[J][7][8,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[K,0],p[I,1],p[I,1],p[J,1])]*r[I][54][1,0]*r[J][7][8,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[K,0],p[J,1],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][7][8,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[K,0],p[J,1],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][7][8,0]*r[K][2][14,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I2J9K12(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,2),(J,9),(K,12)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/12*g[dei(p[I,0],p[I,1],p[K,0],p[J,0])]*r[I][15][2,0]*r[J][1][9,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[I,1],p[I,0],p[K,0],p[J,0])]*r[I][33][2,0]*r[J][1][9,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[I,0],p[J,0],p[K,0],p[I,1])]*r[I][15][2,0]*r[J][1][9,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[I,1],p[J,0],p[K,0],p[I,0])]*r[I][33][2,0]*r[J][1][9,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[K,0],p[I,1],p[I,0],p[J,0])]*r[I][15][2,0]*r[J][1][9,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[K,0],p[I,0],p[I,1],p[J,0])]*r[I][33][2,0]*r[J][1][9,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[K,0],p[J,0],p[I,0],p[I,1])]*r[I][15][2,0]*r[J][1][9,0]*r[K][0][12,0]
                hv += -1/6*g[dei(p[K,0],p[J,0],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][1][9,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[K,0],p[J,0],p[I,1],p[I,0])]*r[I][33][2,0]*r[J][1][9,0]*r[K][0][12,0]
                hv += -1/6*g[dei(p[K,0],p[J,0],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][1][9,0]*r[K][0][12,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I3J9K12(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,3),(J,9),(K,12)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/12*g[dei(p[I,0],p[I,1],p[K,0],p[J,0])]*r[I][15][3,0]*r[J][1][9,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[I,1],p[I,0],p[K,0],p[J,0])]*r[I][33][3,0]*r[J][1][9,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[I,0],p[J,0],p[K,0],p[I,1])]*r[I][15][3,0]*r[J][1][9,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[I,1],p[J,0],p[K,0],p[I,0])]*r[I][33][3,0]*r[J][1][9,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[K,0],p[I,1],p[I,0],p[J,0])]*r[I][15][3,0]*r[J][1][9,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[K,0],p[I,0],p[I,1],p[J,0])]*r[I][33][3,0]*r[J][1][9,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[K,0],p[J,0],p[I,0],p[I,1])]*r[I][15][3,0]*r[J][1][9,0]*r[K][0][12,0]
                hv += -1/6*g[dei(p[K,0],p[J,0],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][1][9,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[K,0],p[J,0],p[I,1],p[I,0])]*r[I][33][3,0]*r[J][1][9,0]*r[K][0][12,0]
                hv += -1/6*g[dei(p[K,0],p[J,0],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][1][9,0]*r[K][0][12,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I2J7K14(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,2),(J,7),(K,14)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/12*g[dei(p[I,0],p[I,1],p[K,0],p[J,0])]*r[I][30][2,0]*r[J][3][7,0]*r[K][2][14,0]
                hv += -1/6*g[dei(p[I,0],p[I,1],p[K,0],p[J,0])]*r[I][15][2,0]*r[J][3][7,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[I,1],p[I,0],p[K,0],p[J,0])]*r[I][48][2,0]*r[J][3][7,0]*r[K][2][14,0]
                hv += -1/6*g[dei(p[I,1],p[I,0],p[K,0],p[J,0])]*r[I][33][2,0]*r[J][3][7,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[I,0],p[J,0],p[K,0],p[I,1])]*r[I][30][2,0]*r[J][3][7,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[I,1],p[J,0],p[K,0],p[I,0])]*r[I][48][2,0]*r[J][3][7,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[K,0],p[I,1],p[I,0],p[J,0])]*r[I][30][2,0]*r[J][3][7,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[K,0],p[I,0],p[I,1],p[J,0])]*r[I][48][2,0]*r[J][3][7,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[K,0],p[J,0],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][3][7,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[K,0],p[J,0],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][3][7,0]*r[K][2][14,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I3J7K14(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,3),(J,7),(K,14)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/12*g[dei(p[I,0],p[I,1],p[K,0],p[J,0])]*r[I][30][3,0]*r[J][3][7,0]*r[K][2][14,0]
                hv += -1/6*g[dei(p[I,0],p[I,1],p[K,0],p[J,0])]*r[I][15][3,0]*r[J][3][7,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[I,1],p[I,0],p[K,0],p[J,0])]*r[I][48][3,0]*r[J][3][7,0]*r[K][2][14,0]
                hv += -1/6*g[dei(p[I,1],p[I,0],p[K,0],p[J,0])]*r[I][33][3,0]*r[J][3][7,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[I,0],p[J,0],p[K,0],p[I,1])]*r[I][30][3,0]*r[J][3][7,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[I,1],p[J,0],p[K,0],p[I,0])]*r[I][48][3,0]*r[J][3][7,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[K,0],p[I,1],p[I,0],p[J,0])]*r[I][30][3,0]*r[J][3][7,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[K,0],p[I,0],p[I,1],p[J,0])]*r[I][48][3,0]*r[J][3][7,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[K,0],p[J,0],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][3][7,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[K,0],p[J,0],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][3][7,0]*r[K][2][14,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I2J10K12(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,2),(J,10),(K,12)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/12*g[dei(p[I,0],p[I,1],p[K,0],p[J,1])]*r[I][15][2,0]*r[J][5][10,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[I,1],p[I,0],p[K,0],p[J,1])]*r[I][33][2,0]*r[J][5][10,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[I,0],p[J,1],p[K,0],p[I,1])]*r[I][15][2,0]*r[J][5][10,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[I,1],p[J,1],p[K,0],p[I,0])]*r[I][33][2,0]*r[J][5][10,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[K,0],p[I,1],p[I,0],p[J,1])]*r[I][15][2,0]*r[J][5][10,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[K,0],p[I,0],p[I,1],p[J,1])]*r[I][33][2,0]*r[J][5][10,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[K,0],p[J,1],p[I,0],p[I,1])]*r[I][15][2,0]*r[J][5][10,0]*r[K][0][12,0]
                hv += -1/6*g[dei(p[K,0],p[J,1],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][5][10,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[K,0],p[J,1],p[I,1],p[I,0])]*r[I][33][2,0]*r[J][5][10,0]*r[K][0][12,0]
                hv += -1/6*g[dei(p[K,0],p[J,1],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][5][10,0]*r[K][0][12,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I3J10K12(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,3),(J,10),(K,12)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/12*g[dei(p[I,0],p[I,1],p[K,0],p[J,1])]*r[I][15][3,0]*r[J][5][10,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[I,1],p[I,0],p[K,0],p[J,1])]*r[I][33][3,0]*r[J][5][10,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[I,0],p[J,1],p[K,0],p[I,1])]*r[I][15][3,0]*r[J][5][10,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[I,1],p[J,1],p[K,0],p[I,0])]*r[I][33][3,0]*r[J][5][10,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[K,0],p[I,1],p[I,0],p[J,1])]*r[I][15][3,0]*r[J][5][10,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[K,0],p[I,0],p[I,1],p[J,1])]*r[I][33][3,0]*r[J][5][10,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[K,0],p[J,1],p[I,0],p[I,1])]*r[I][15][3,0]*r[J][5][10,0]*r[K][0][12,0]
                hv += -1/6*g[dei(p[K,0],p[J,1],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][5][10,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[K,0],p[J,1],p[I,1],p[I,0])]*r[I][33][3,0]*r[J][5][10,0]*r[K][0][12,0]
                hv += -1/6*g[dei(p[K,0],p[J,1],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][5][10,0]*r[K][0][12,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I2J8K14(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,2),(J,8),(K,14)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/12*g[dei(p[I,0],p[I,1],p[K,0],p[J,1])]*r[I][30][2,0]*r[J][7][8,0]*r[K][2][14,0]
                hv += -1/6*g[dei(p[I,0],p[I,1],p[K,0],p[J,1])]*r[I][15][2,0]*r[J][7][8,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[I,1],p[I,0],p[K,0],p[J,1])]*r[I][48][2,0]*r[J][7][8,0]*r[K][2][14,0]
                hv += -1/6*g[dei(p[I,1],p[I,0],p[K,0],p[J,1])]*r[I][33][2,0]*r[J][7][8,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[I,0],p[J,1],p[K,0],p[I,1])]*r[I][30][2,0]*r[J][7][8,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[I,1],p[J,1],p[K,0],p[I,0])]*r[I][48][2,0]*r[J][7][8,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[K,0],p[I,1],p[I,0],p[J,1])]*r[I][30][2,0]*r[J][7][8,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[K,0],p[I,0],p[I,1],p[J,1])]*r[I][48][2,0]*r[J][7][8,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[K,0],p[J,1],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][7][8,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[K,0],p[J,1],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][7][8,0]*r[K][2][14,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I3J8K14(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,3),(J,8),(K,14)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/12*g[dei(p[I,0],p[I,1],p[K,0],p[J,1])]*r[I][30][3,0]*r[J][7][8,0]*r[K][2][14,0]
                hv += -1/6*g[dei(p[I,0],p[I,1],p[K,0],p[J,1])]*r[I][15][3,0]*r[J][7][8,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[I,1],p[I,0],p[K,0],p[J,1])]*r[I][48][3,0]*r[J][7][8,0]*r[K][2][14,0]
                hv += -1/6*g[dei(p[I,1],p[I,0],p[K,0],p[J,1])]*r[I][33][3,0]*r[J][7][8,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[I,0],p[J,1],p[K,0],p[I,1])]*r[I][30][3,0]*r[J][7][8,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[I,1],p[J,1],p[K,0],p[I,0])]*r[I][48][3,0]*r[J][7][8,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[K,0],p[I,1],p[I,0],p[J,1])]*r[I][30][3,0]*r[J][7][8,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[K,0],p[I,0],p[I,1],p[J,1])]*r[I][48][3,0]*r[J][7][8,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[K,0],p[J,1],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][7][8,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[K,0],p[J,1],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][7][8,0]*r[K][2][14,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I1J9K11(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,1),(J,9),(K,11)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/12*g[dei(p[I,0],p[I,0],p[K,1],p[J,0])]*r[I][9][1,0]*r[J][1][9,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[I,1],p[I,1],p[K,1],p[J,0])]*r[I][39][1,0]*r[J][1][9,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[I,0],p[J,0],p[K,1],p[I,0])]*r[I][9][1,0]*r[J][1][9,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[I,1],p[J,0],p[K,1],p[I,1])]*r[I][39][1,0]*r[J][1][9,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[K,1],p[I,0],p[I,0],p[J,0])]*r[I][9][1,0]*r[J][1][9,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[K,1],p[I,1],p[I,1],p[J,0])]*r[I][39][1,0]*r[J][1][9,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[K,1],p[J,0],p[I,0],p[I,0])]*r[I][9][1,0]*r[J][1][9,0]*r[K][4][11,0]
                hv += -1/6*g[dei(p[K,1],p[J,0],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][1][9,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[K,1],p[J,0],p[I,1],p[I,1])]*r[I][39][1,0]*r[J][1][9,0]*r[K][4][11,0]
                hv += -1/6*g[dei(p[K,1],p[J,0],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][1][9,0]*r[K][4][11,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I1J7K13(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,1),(J,7),(K,13)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/12*g[dei(p[I,0],p[I,0],p[K,1],p[J,0])]*r[I][24][1,0]*r[J][3][7,0]*r[K][6][13,0]
                hv += -1/6*g[dei(p[I,0],p[I,0],p[K,1],p[J,0])]*r[I][9][1,0]*r[J][3][7,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[I,1],p[I,1],p[K,1],p[J,0])]*r[I][54][1,0]*r[J][3][7,0]*r[K][6][13,0]
                hv += -1/6*g[dei(p[I,1],p[I,1],p[K,1],p[J,0])]*r[I][39][1,0]*r[J][3][7,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[I,0],p[J,0],p[K,1],p[I,0])]*r[I][24][1,0]*r[J][3][7,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[I,1],p[J,0],p[K,1],p[I,1])]*r[I][54][1,0]*r[J][3][7,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[K,1],p[I,0],p[I,0],p[J,0])]*r[I][24][1,0]*r[J][3][7,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[K,1],p[I,1],p[I,1],p[J,0])]*r[I][54][1,0]*r[J][3][7,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[K,1],p[J,0],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][3][7,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[K,1],p[J,0],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][3][7,0]*r[K][6][13,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I1J10K11(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,1),(J,10),(K,11)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/12*g[dei(p[I,0],p[I,0],p[K,1],p[J,1])]*r[I][9][1,0]*r[J][5][10,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[I,1],p[I,1],p[K,1],p[J,1])]*r[I][39][1,0]*r[J][5][10,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[I,0],p[J,1],p[K,1],p[I,0])]*r[I][9][1,0]*r[J][5][10,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[I,1],p[J,1],p[K,1],p[I,1])]*r[I][39][1,0]*r[J][5][10,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[K,1],p[I,0],p[I,0],p[J,1])]*r[I][9][1,0]*r[J][5][10,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[K,1],p[I,1],p[I,1],p[J,1])]*r[I][39][1,0]*r[J][5][10,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[K,1],p[J,1],p[I,0],p[I,0])]*r[I][9][1,0]*r[J][5][10,0]*r[K][4][11,0]
                hv += -1/6*g[dei(p[K,1],p[J,1],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][5][10,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[K,1],p[J,1],p[I,1],p[I,1])]*r[I][39][1,0]*r[J][5][10,0]*r[K][4][11,0]
                hv += -1/6*g[dei(p[K,1],p[J,1],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][5][10,0]*r[K][4][11,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I1J8K13(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,1),(J,8),(K,13)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/12*g[dei(p[I,0],p[I,0],p[K,1],p[J,1])]*r[I][24][1,0]*r[J][7][8,0]*r[K][6][13,0]
                hv += -1/6*g[dei(p[I,0],p[I,0],p[K,1],p[J,1])]*r[I][9][1,0]*r[J][7][8,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[I,1],p[I,1],p[K,1],p[J,1])]*r[I][54][1,0]*r[J][7][8,0]*r[K][6][13,0]
                hv += -1/6*g[dei(p[I,1],p[I,1],p[K,1],p[J,1])]*r[I][39][1,0]*r[J][7][8,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[I,0],p[J,1],p[K,1],p[I,0])]*r[I][24][1,0]*r[J][7][8,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[I,1],p[J,1],p[K,1],p[I,1])]*r[I][54][1,0]*r[J][7][8,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[K,1],p[I,0],p[I,0],p[J,1])]*r[I][24][1,0]*r[J][7][8,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[K,1],p[I,1],p[I,1],p[J,1])]*r[I][54][1,0]*r[J][7][8,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[K,1],p[J,1],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][7][8,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[K,1],p[J,1],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][7][8,0]*r[K][6][13,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I2J9K11(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,2),(J,9),(K,11)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/12*g[dei(p[I,0],p[I,1],p[K,1],p[J,0])]*r[I][15][2,0]*r[J][1][9,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[I,1],p[I,0],p[K,1],p[J,0])]*r[I][33][2,0]*r[J][1][9,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[I,0],p[J,0],p[K,1],p[I,1])]*r[I][15][2,0]*r[J][1][9,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[I,1],p[J,0],p[K,1],p[I,0])]*r[I][33][2,0]*r[J][1][9,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[K,1],p[I,1],p[I,0],p[J,0])]*r[I][15][2,0]*r[J][1][9,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[K,1],p[I,0],p[I,1],p[J,0])]*r[I][33][2,0]*r[J][1][9,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[K,1],p[J,0],p[I,0],p[I,1])]*r[I][15][2,0]*r[J][1][9,0]*r[K][4][11,0]
                hv += -1/6*g[dei(p[K,1],p[J,0],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][1][9,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[K,1],p[J,0],p[I,1],p[I,0])]*r[I][33][2,0]*r[J][1][9,0]*r[K][4][11,0]
                hv += -1/6*g[dei(p[K,1],p[J,0],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][1][9,0]*r[K][4][11,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I3J9K11(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,3),(J,9),(K,11)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/12*g[dei(p[I,0],p[I,1],p[K,1],p[J,0])]*r[I][15][3,0]*r[J][1][9,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[I,1],p[I,0],p[K,1],p[J,0])]*r[I][33][3,0]*r[J][1][9,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[I,0],p[J,0],p[K,1],p[I,1])]*r[I][15][3,0]*r[J][1][9,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[I,1],p[J,0],p[K,1],p[I,0])]*r[I][33][3,0]*r[J][1][9,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[K,1],p[I,1],p[I,0],p[J,0])]*r[I][15][3,0]*r[J][1][9,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[K,1],p[I,0],p[I,1],p[J,0])]*r[I][33][3,0]*r[J][1][9,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[K,1],p[J,0],p[I,0],p[I,1])]*r[I][15][3,0]*r[J][1][9,0]*r[K][4][11,0]
                hv += -1/6*g[dei(p[K,1],p[J,0],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][1][9,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[K,1],p[J,0],p[I,1],p[I,0])]*r[I][33][3,0]*r[J][1][9,0]*r[K][4][11,0]
                hv += -1/6*g[dei(p[K,1],p[J,0],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][1][9,0]*r[K][4][11,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I2J7K13(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,2),(J,7),(K,13)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/12*g[dei(p[I,0],p[I,1],p[K,1],p[J,0])]*r[I][30][2,0]*r[J][3][7,0]*r[K][6][13,0]
                hv += -1/6*g[dei(p[I,0],p[I,1],p[K,1],p[J,0])]*r[I][15][2,0]*r[J][3][7,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[I,1],p[I,0],p[K,1],p[J,0])]*r[I][48][2,0]*r[J][3][7,0]*r[K][6][13,0]
                hv += -1/6*g[dei(p[I,1],p[I,0],p[K,1],p[J,0])]*r[I][33][2,0]*r[J][3][7,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[I,0],p[J,0],p[K,1],p[I,1])]*r[I][30][2,0]*r[J][3][7,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[I,1],p[J,0],p[K,1],p[I,0])]*r[I][48][2,0]*r[J][3][7,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[K,1],p[I,1],p[I,0],p[J,0])]*r[I][30][2,0]*r[J][3][7,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[K,1],p[I,0],p[I,1],p[J,0])]*r[I][48][2,0]*r[J][3][7,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[K,1],p[J,0],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][3][7,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[K,1],p[J,0],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][3][7,0]*r[K][6][13,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I3J7K13(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,3),(J,7),(K,13)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/12*g[dei(p[I,0],p[I,1],p[K,1],p[J,0])]*r[I][30][3,0]*r[J][3][7,0]*r[K][6][13,0]
                hv += -1/6*g[dei(p[I,0],p[I,1],p[K,1],p[J,0])]*r[I][15][3,0]*r[J][3][7,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[I,1],p[I,0],p[K,1],p[J,0])]*r[I][48][3,0]*r[J][3][7,0]*r[K][6][13,0]
                hv += -1/6*g[dei(p[I,1],p[I,0],p[K,1],p[J,0])]*r[I][33][3,0]*r[J][3][7,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[I,0],p[J,0],p[K,1],p[I,1])]*r[I][30][3,0]*r[J][3][7,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[I,1],p[J,0],p[K,1],p[I,0])]*r[I][48][3,0]*r[J][3][7,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[K,1],p[I,1],p[I,0],p[J,0])]*r[I][30][3,0]*r[J][3][7,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[K,1],p[I,0],p[I,1],p[J,0])]*r[I][48][3,0]*r[J][3][7,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[K,1],p[J,0],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][3][7,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[K,1],p[J,0],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][3][7,0]*r[K][6][13,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I2J10K11(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,2),(J,10),(K,11)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/12*g[dei(p[I,0],p[I,1],p[K,1],p[J,1])]*r[I][15][2,0]*r[J][5][10,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[I,1],p[I,0],p[K,1],p[J,1])]*r[I][33][2,0]*r[J][5][10,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[I,0],p[J,1],p[K,1],p[I,1])]*r[I][15][2,0]*r[J][5][10,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[I,1],p[J,1],p[K,1],p[I,0])]*r[I][33][2,0]*r[J][5][10,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[K,1],p[I,1],p[I,0],p[J,1])]*r[I][15][2,0]*r[J][5][10,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[K,1],p[I,0],p[I,1],p[J,1])]*r[I][33][2,0]*r[J][5][10,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[K,1],p[J,1],p[I,0],p[I,1])]*r[I][15][2,0]*r[J][5][10,0]*r[K][4][11,0]
                hv += -1/6*g[dei(p[K,1],p[J,1],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][5][10,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[K,1],p[J,1],p[I,1],p[I,0])]*r[I][33][2,0]*r[J][5][10,0]*r[K][4][11,0]
                hv += -1/6*g[dei(p[K,1],p[J,1],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][5][10,0]*r[K][4][11,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I3J10K11(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,3),(J,10),(K,11)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/12*g[dei(p[I,0],p[I,1],p[K,1],p[J,1])]*r[I][15][3,0]*r[J][5][10,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[I,1],p[I,0],p[K,1],p[J,1])]*r[I][33][3,0]*r[J][5][10,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[I,0],p[J,1],p[K,1],p[I,1])]*r[I][15][3,0]*r[J][5][10,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[I,1],p[J,1],p[K,1],p[I,0])]*r[I][33][3,0]*r[J][5][10,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[K,1],p[I,1],p[I,0],p[J,1])]*r[I][15][3,0]*r[J][5][10,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[K,1],p[I,0],p[I,1],p[J,1])]*r[I][33][3,0]*r[J][5][10,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[K,1],p[J,1],p[I,0],p[I,1])]*r[I][15][3,0]*r[J][5][10,0]*r[K][4][11,0]
                hv += -1/6*g[dei(p[K,1],p[J,1],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][5][10,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[K,1],p[J,1],p[I,1],p[I,0])]*r[I][33][3,0]*r[J][5][10,0]*r[K][4][11,0]
                hv += -1/6*g[dei(p[K,1],p[J,1],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][5][10,0]*r[K][4][11,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I2J8K13(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,2),(J,8),(K,13)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/12*g[dei(p[I,0],p[I,1],p[K,1],p[J,1])]*r[I][30][2,0]*r[J][7][8,0]*r[K][6][13,0]
                hv += -1/6*g[dei(p[I,0],p[I,1],p[K,1],p[J,1])]*r[I][15][2,0]*r[J][7][8,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[I,1],p[I,0],p[K,1],p[J,1])]*r[I][48][2,0]*r[J][7][8,0]*r[K][6][13,0]
                hv += -1/6*g[dei(p[I,1],p[I,0],p[K,1],p[J,1])]*r[I][33][2,0]*r[J][7][8,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[I,0],p[J,1],p[K,1],p[I,1])]*r[I][30][2,0]*r[J][7][8,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[I,1],p[J,1],p[K,1],p[I,0])]*r[I][48][2,0]*r[J][7][8,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[K,1],p[I,1],p[I,0],p[J,1])]*r[I][30][2,0]*r[J][7][8,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[K,1],p[I,0],p[I,1],p[J,1])]*r[I][48][2,0]*r[J][7][8,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[K,1],p[J,1],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][7][8,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[K,1],p[J,1],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][7][8,0]*r[K][6][13,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I3J8K13(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,3),(J,8),(K,13)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/12*g[dei(p[I,0],p[I,1],p[K,1],p[J,1])]*r[I][30][3,0]*r[J][7][8,0]*r[K][6][13,0]
                hv += -1/6*g[dei(p[I,0],p[I,1],p[K,1],p[J,1])]*r[I][15][3,0]*r[J][7][8,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[I,1],p[I,0],p[K,1],p[J,1])]*r[I][48][3,0]*r[J][7][8,0]*r[K][6][13,0]
                hv += -1/6*g[dei(p[I,1],p[I,0],p[K,1],p[J,1])]*r[I][33][3,0]*r[J][7][8,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[I,0],p[J,1],p[K,1],p[I,1])]*r[I][30][3,0]*r[J][7][8,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[I,1],p[J,1],p[K,1],p[I,0])]*r[I][48][3,0]*r[J][7][8,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[K,1],p[I,1],p[I,0],p[J,1])]*r[I][30][3,0]*r[J][7][8,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[K,1],p[I,0],p[I,1],p[J,1])]*r[I][48][3,0]*r[J][7][8,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[K,1],p[J,1],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][7][8,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[K,1],p[J,1],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][7][8,0]*r[K][6][13,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I4J9K14(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,4),(J,9),(K,14)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/6*g[dei(p[I,0],p[J,0],p[K,0],p[I,1])]*r[I][18][4,0]*r[J][1][9,0]*r[K][2][14,0]
                hv += 1/6*g[dei(p[I,1],p[J,0],p[K,0],p[I,0])]*r[I][36][4,0]*r[J][1][9,0]*r[K][2][14,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I4J10K14(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,4),(J,10),(K,14)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/6*g[dei(p[I,0],p[J,1],p[K,0],p[I,1])]*r[I][18][4,0]*r[J][5][10,0]*r[K][2][14,0]
                hv += 1/6*g[dei(p[I,1],p[J,1],p[K,0],p[I,0])]*r[I][36][4,0]*r[J][5][10,0]*r[K][2][14,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I4J9K13(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,4),(J,9),(K,13)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/6*g[dei(p[I,0],p[J,0],p[K,1],p[I,1])]*r[I][18][4,0]*r[J][1][9,0]*r[K][6][13,0]
                hv += 1/6*g[dei(p[I,1],p[J,0],p[K,1],p[I,0])]*r[I][36][4,0]*r[J][1][9,0]*r[K][6][13,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I4J10K13(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,4),(J,10),(K,13)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/6*g[dei(p[I,0],p[J,1],p[K,1],p[I,1])]*r[I][18][4,0]*r[J][5][10,0]*r[K][6][13,0]
                hv += 1/6*g[dei(p[I,1],p[J,1],p[K,1],p[I,0])]*r[I][36][4,0]*r[J][5][10,0]*r[K][6][13,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I12J6K14(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,12),(J,6),(K,14)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/6*g[dei(p[I,0],p[J,0],p[K,0],p[J,0])]*r[I][0][12,0]*r[J][22][6,0]*r[K][2][14,0]
                hv += 1/6*g[dei(p[I,0],p[J,1],p[K,0],p[J,1])]*r[I][0][12,0]*r[J][52][6,0]*r[K][2][14,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I12J6K13(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,12),(J,6),(K,13)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/6*g[dei(p[I,0],p[J,0],p[K,1],p[J,0])]*r[I][0][12,0]*r[J][22][6,0]*r[K][6][13,0]
                hv += 1/6*g[dei(p[I,0],p[J,1],p[K,1],p[J,1])]*r[I][0][12,0]*r[J][52][6,0]*r[K][6][13,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I11J6K14(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,11),(J,6),(K,14)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/6*g[dei(p[I,1],p[J,0],p[K,0],p[J,0])]*r[I][4][11,0]*r[J][22][6,0]*r[K][2][14,0]
                hv += 1/6*g[dei(p[I,1],p[J,1],p[K,0],p[J,1])]*r[I][4][11,0]*r[J][52][6,0]*r[K][2][14,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I11J6K13(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,11),(J,6),(K,13)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/6*g[dei(p[I,1],p[J,0],p[K,1],p[J,0])]*r[I][4][11,0]*r[J][22][6,0]*r[K][6][13,0]
                hv += 1/6*g[dei(p[I,1],p[J,1],p[K,1],p[J,1])]*r[I][4][11,0]*r[J][52][6,0]*r[K][6][13,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I12J9K1(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,12),(J,9),(K,1)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/12*g[dei(p[I,0],p[J,0],p[K,0],p[K,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][9][1,0]
                hv += 1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][24][1,0]
                hv += 1/12*g[dei(p[I,0],p[J,0],p[K,1],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][39][1,0]
                hv += 1/6*g[dei(p[I,0],p[J,0],p[K,1],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][54][1,0]
                hv += -1/12*g[dei(p[I,0],p[K,0],p[K,0],p[J,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][9][1,0]
                hv += -1/12*g[dei(p[I,0],p[K,1],p[K,1],p[J,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][39][1,0]
                hv += -1/12*g[dei(p[K,0],p[J,0],p[I,0],p[K,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][9][1,0]
                hv += -1/12*g[dei(p[K,1],p[J,0],p[I,0],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][39][1,0]
                hv += 1/12*g[dei(p[K,0],p[K,0],p[I,0],p[J,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][9][1,0]
                hv += 1/12*g[dei(p[K,1],p[K,1],p[I,0],p[J,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][39][1,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I14J7K1(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,14),(J,7),(K,1)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/12*g[dei(p[I,0],p[J,0],p[K,0],p[K,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][24][1,0]
                hv += 1/12*g[dei(p[I,0],p[J,0],p[K,1],p[K,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][54][1,0]
                hv += -1/12*g[dei(p[I,0],p[K,0],p[K,0],p[J,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][24][1,0]
                hv += -1/12*g[dei(p[I,0],p[K,1],p[K,1],p[J,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][54][1,0]
                hv += -1/12*g[dei(p[K,0],p[J,0],p[I,0],p[K,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][24][1,0]
                hv += -1/12*g[dei(p[K,1],p[J,0],p[I,0],p[K,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][54][1,0]
                hv += 1/12*g[dei(p[K,0],p[K,0],p[I,0],p[J,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][24][1,0]
                hv += 1/6*g[dei(p[K,0],p[K,0],p[I,0],p[J,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][9][1,0]
                hv += 1/12*g[dei(p[K,1],p[K,1],p[I,0],p[J,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][54][1,0]
                hv += 1/6*g[dei(p[K,1],p[K,1],p[I,0],p[J,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][39][1,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I12J9K2(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,12),(J,9),(K,2)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/12*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][15][2,0]
                hv += 1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][30][2,0]
                hv += 1/12*g[dei(p[I,0],p[J,0],p[K,1],p[K,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][33][2,0]
                hv += 1/6*g[dei(p[I,0],p[J,0],p[K,1],p[K,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][48][2,0]
                hv += -1/12*g[dei(p[I,0],p[K,1],p[K,0],p[J,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][15][2,0]
                hv += -1/12*g[dei(p[I,0],p[K,0],p[K,1],p[J,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][33][2,0]
                hv += -1/12*g[dei(p[K,0],p[J,0],p[I,0],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][15][2,0]
                hv += -1/12*g[dei(p[K,1],p[J,0],p[I,0],p[K,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][33][2,0]
                hv += 1/12*g[dei(p[K,0],p[K,1],p[I,0],p[J,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][15][2,0]
                hv += 1/12*g[dei(p[K,1],p[K,0],p[I,0],p[J,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][33][2,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I12J9K3(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,12),(J,9),(K,3)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/12*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][15][3,0]
                hv += 1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][30][3,0]
                hv += 1/12*g[dei(p[I,0],p[J,0],p[K,1],p[K,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][33][3,0]
                hv += 1/6*g[dei(p[I,0],p[J,0],p[K,1],p[K,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][48][3,0]
                hv += -1/12*g[dei(p[I,0],p[K,1],p[K,0],p[J,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][15][3,0]
                hv += -1/12*g[dei(p[I,0],p[K,0],p[K,1],p[J,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][33][3,0]
                hv += -1/12*g[dei(p[K,0],p[J,0],p[I,0],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][15][3,0]
                hv += -1/12*g[dei(p[K,1],p[J,0],p[I,0],p[K,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][33][3,0]
                hv += 1/12*g[dei(p[K,0],p[K,1],p[I,0],p[J,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][15][3,0]
                hv += 1/12*g[dei(p[K,1],p[K,0],p[I,0],p[J,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][33][3,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I14J7K2(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,14),(J,7),(K,2)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/12*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][30][2,0]
                hv += 1/12*g[dei(p[I,0],p[J,0],p[K,1],p[K,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][48][2,0]
                hv += -1/12*g[dei(p[I,0],p[K,1],p[K,0],p[J,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][30][2,0]
                hv += -1/12*g[dei(p[I,0],p[K,0],p[K,1],p[J,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][48][2,0]
                hv += -1/12*g[dei(p[K,0],p[J,0],p[I,0],p[K,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][30][2,0]
                hv += -1/12*g[dei(p[K,1],p[J,0],p[I,0],p[K,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][48][2,0]
                hv += 1/12*g[dei(p[K,0],p[K,1],p[I,0],p[J,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][30][2,0]
                hv += 1/6*g[dei(p[K,0],p[K,1],p[I,0],p[J,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][15][2,0]
                hv += 1/12*g[dei(p[K,1],p[K,0],p[I,0],p[J,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][48][2,0]
                hv += 1/6*g[dei(p[K,1],p[K,0],p[I,0],p[J,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][33][2,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I14J7K3(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,14),(J,7),(K,3)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/12*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][30][3,0]
                hv += 1/12*g[dei(p[I,0],p[J,0],p[K,1],p[K,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][48][3,0]
                hv += -1/12*g[dei(p[I,0],p[K,1],p[K,0],p[J,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][30][3,0]
                hv += -1/12*g[dei(p[I,0],p[K,0],p[K,1],p[J,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][48][3,0]
                hv += -1/12*g[dei(p[K,0],p[J,0],p[I,0],p[K,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][30][3,0]
                hv += -1/12*g[dei(p[K,1],p[J,0],p[I,0],p[K,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][48][3,0]
                hv += 1/12*g[dei(p[K,0],p[K,1],p[I,0],p[J,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][30][3,0]
                hv += 1/6*g[dei(p[K,0],p[K,1],p[I,0],p[J,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][15][3,0]
                hv += 1/12*g[dei(p[K,1],p[K,0],p[I,0],p[J,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][48][3,0]
                hv += 1/6*g[dei(p[K,1],p[K,0],p[I,0],p[J,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][33][3,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I12J10K1(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,12),(J,10),(K,1)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/12*g[dei(p[I,0],p[J,1],p[K,0],p[K,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][9][1,0]
                hv += 1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][24][1,0]
                hv += 1/12*g[dei(p[I,0],p[J,1],p[K,1],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][39][1,0]
                hv += 1/6*g[dei(p[I,0],p[J,1],p[K,1],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][54][1,0]
                hv += -1/12*g[dei(p[I,0],p[K,0],p[K,0],p[J,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][9][1,0]
                hv += -1/12*g[dei(p[I,0],p[K,1],p[K,1],p[J,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][39][1,0]
                hv += -1/12*g[dei(p[K,0],p[J,1],p[I,0],p[K,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][9][1,0]
                hv += -1/12*g[dei(p[K,1],p[J,1],p[I,0],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][39][1,0]
                hv += 1/12*g[dei(p[K,0],p[K,0],p[I,0],p[J,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][9][1,0]
                hv += 1/12*g[dei(p[K,1],p[K,1],p[I,0],p[J,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][39][1,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I14J8K1(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,14),(J,8),(K,1)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/12*g[dei(p[I,0],p[J,1],p[K,0],p[K,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][24][1,0]
                hv += 1/12*g[dei(p[I,0],p[J,1],p[K,1],p[K,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][54][1,0]
                hv += -1/12*g[dei(p[I,0],p[K,0],p[K,0],p[J,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][24][1,0]
                hv += -1/12*g[dei(p[I,0],p[K,1],p[K,1],p[J,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][54][1,0]
                hv += -1/12*g[dei(p[K,0],p[J,1],p[I,0],p[K,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][24][1,0]
                hv += -1/12*g[dei(p[K,1],p[J,1],p[I,0],p[K,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][54][1,0]
                hv += 1/12*g[dei(p[K,0],p[K,0],p[I,0],p[J,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][24][1,0]
                hv += 1/6*g[dei(p[K,0],p[K,0],p[I,0],p[J,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][9][1,0]
                hv += 1/12*g[dei(p[K,1],p[K,1],p[I,0],p[J,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][54][1,0]
                hv += 1/6*g[dei(p[K,1],p[K,1],p[I,0],p[J,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][39][1,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I12J10K2(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,12),(J,10),(K,2)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/12*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][15][2,0]
                hv += 1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][30][2,0]
                hv += 1/12*g[dei(p[I,0],p[J,1],p[K,1],p[K,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][33][2,0]
                hv += 1/6*g[dei(p[I,0],p[J,1],p[K,1],p[K,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][48][2,0]
                hv += -1/12*g[dei(p[I,0],p[K,1],p[K,0],p[J,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][15][2,0]
                hv += -1/12*g[dei(p[I,0],p[K,0],p[K,1],p[J,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][33][2,0]
                hv += -1/12*g[dei(p[K,0],p[J,1],p[I,0],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][15][2,0]
                hv += -1/12*g[dei(p[K,1],p[J,1],p[I,0],p[K,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][33][2,0]
                hv += 1/12*g[dei(p[K,0],p[K,1],p[I,0],p[J,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][15][2,0]
                hv += 1/12*g[dei(p[K,1],p[K,0],p[I,0],p[J,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][33][2,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I12J10K3(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,12),(J,10),(K,3)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/12*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][15][3,0]
                hv += 1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][30][3,0]
                hv += 1/12*g[dei(p[I,0],p[J,1],p[K,1],p[K,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][33][3,0]
                hv += 1/6*g[dei(p[I,0],p[J,1],p[K,1],p[K,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][48][3,0]
                hv += -1/12*g[dei(p[I,0],p[K,1],p[K,0],p[J,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][15][3,0]
                hv += -1/12*g[dei(p[I,0],p[K,0],p[K,1],p[J,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][33][3,0]
                hv += -1/12*g[dei(p[K,0],p[J,1],p[I,0],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][15][3,0]
                hv += -1/12*g[dei(p[K,1],p[J,1],p[I,0],p[K,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][33][3,0]
                hv += 1/12*g[dei(p[K,0],p[K,1],p[I,0],p[J,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][15][3,0]
                hv += 1/12*g[dei(p[K,1],p[K,0],p[I,0],p[J,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][33][3,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I14J8K2(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,14),(J,8),(K,2)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/12*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][30][2,0]
                hv += 1/12*g[dei(p[I,0],p[J,1],p[K,1],p[K,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][48][2,0]
                hv += -1/12*g[dei(p[I,0],p[K,1],p[K,0],p[J,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][30][2,0]
                hv += -1/12*g[dei(p[I,0],p[K,0],p[K,1],p[J,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][48][2,0]
                hv += -1/12*g[dei(p[K,0],p[J,1],p[I,0],p[K,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][30][2,0]
                hv += -1/12*g[dei(p[K,1],p[J,1],p[I,0],p[K,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][48][2,0]
                hv += 1/12*g[dei(p[K,0],p[K,1],p[I,0],p[J,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][30][2,0]
                hv += 1/6*g[dei(p[K,0],p[K,1],p[I,0],p[J,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][15][2,0]
                hv += 1/12*g[dei(p[K,1],p[K,0],p[I,0],p[J,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][48][2,0]
                hv += 1/6*g[dei(p[K,1],p[K,0],p[I,0],p[J,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][33][2,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I14J8K3(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,14),(J,8),(K,3)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/12*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][30][3,0]
                hv += 1/12*g[dei(p[I,0],p[J,1],p[K,1],p[K,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][48][3,0]
                hv += -1/12*g[dei(p[I,0],p[K,1],p[K,0],p[J,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][30][3,0]
                hv += -1/12*g[dei(p[I,0],p[K,0],p[K,1],p[J,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][48][3,0]
                hv += -1/12*g[dei(p[K,0],p[J,1],p[I,0],p[K,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][30][3,0]
                hv += -1/12*g[dei(p[K,1],p[J,1],p[I,0],p[K,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][48][3,0]
                hv += 1/12*g[dei(p[K,0],p[K,1],p[I,0],p[J,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][30][3,0]
                hv += 1/6*g[dei(p[K,0],p[K,1],p[I,0],p[J,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][15][3,0]
                hv += 1/12*g[dei(p[K,1],p[K,0],p[I,0],p[J,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][48][3,0]
                hv += 1/6*g[dei(p[K,1],p[K,0],p[I,0],p[J,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][33][3,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I11J9K1(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,11),(J,9),(K,1)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/12*g[dei(p[I,1],p[J,0],p[K,0],p[K,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][9][1,0]
                hv += 1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][24][1,0]
                hv += 1/12*g[dei(p[I,1],p[J,0],p[K,1],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][39][1,0]
                hv += 1/6*g[dei(p[I,1],p[J,0],p[K,1],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][54][1,0]
                hv += -1/12*g[dei(p[I,1],p[K,0],p[K,0],p[J,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][9][1,0]
                hv += -1/12*g[dei(p[I,1],p[K,1],p[K,1],p[J,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][39][1,0]
                hv += -1/12*g[dei(p[K,0],p[J,0],p[I,1],p[K,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][9][1,0]
                hv += -1/12*g[dei(p[K,1],p[J,0],p[I,1],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][39][1,0]
                hv += 1/12*g[dei(p[K,0],p[K,0],p[I,1],p[J,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][9][1,0]
                hv += 1/12*g[dei(p[K,1],p[K,1],p[I,1],p[J,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][39][1,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I13J7K1(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,13),(J,7),(K,1)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/12*g[dei(p[I,1],p[J,0],p[K,0],p[K,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][24][1,0]
                hv += 1/12*g[dei(p[I,1],p[J,0],p[K,1],p[K,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][54][1,0]
                hv += -1/12*g[dei(p[I,1],p[K,0],p[K,0],p[J,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][24][1,0]
                hv += -1/12*g[dei(p[I,1],p[K,1],p[K,1],p[J,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][54][1,0]
                hv += -1/12*g[dei(p[K,0],p[J,0],p[I,1],p[K,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][24][1,0]
                hv += -1/12*g[dei(p[K,1],p[J,0],p[I,1],p[K,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][54][1,0]
                hv += 1/12*g[dei(p[K,0],p[K,0],p[I,1],p[J,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][24][1,0]
                hv += 1/6*g[dei(p[K,0],p[K,0],p[I,1],p[J,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][9][1,0]
                hv += 1/12*g[dei(p[K,1],p[K,1],p[I,1],p[J,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][54][1,0]
                hv += 1/6*g[dei(p[K,1],p[K,1],p[I,1],p[J,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][39][1,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I11J9K2(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,11),(J,9),(K,2)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/12*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][15][2,0]
                hv += 1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][30][2,0]
                hv += 1/12*g[dei(p[I,1],p[J,0],p[K,1],p[K,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][33][2,0]
                hv += 1/6*g[dei(p[I,1],p[J,0],p[K,1],p[K,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][48][2,0]
                hv += -1/12*g[dei(p[I,1],p[K,1],p[K,0],p[J,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][15][2,0]
                hv += -1/12*g[dei(p[I,1],p[K,0],p[K,1],p[J,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][33][2,0]
                hv += -1/12*g[dei(p[K,0],p[J,0],p[I,1],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][15][2,0]
                hv += -1/12*g[dei(p[K,1],p[J,0],p[I,1],p[K,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][33][2,0]
                hv += 1/12*g[dei(p[K,0],p[K,1],p[I,1],p[J,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][15][2,0]
                hv += 1/12*g[dei(p[K,1],p[K,0],p[I,1],p[J,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][33][2,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I11J9K3(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,11),(J,9),(K,3)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/12*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][15][3,0]
                hv += 1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][30][3,0]
                hv += 1/12*g[dei(p[I,1],p[J,0],p[K,1],p[K,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][33][3,0]
                hv += 1/6*g[dei(p[I,1],p[J,0],p[K,1],p[K,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][48][3,0]
                hv += -1/12*g[dei(p[I,1],p[K,1],p[K,0],p[J,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][15][3,0]
                hv += -1/12*g[dei(p[I,1],p[K,0],p[K,1],p[J,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][33][3,0]
                hv += -1/12*g[dei(p[K,0],p[J,0],p[I,1],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][15][3,0]
                hv += -1/12*g[dei(p[K,1],p[J,0],p[I,1],p[K,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][33][3,0]
                hv += 1/12*g[dei(p[K,0],p[K,1],p[I,1],p[J,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][15][3,0]
                hv += 1/12*g[dei(p[K,1],p[K,0],p[I,1],p[J,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][33][3,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I13J7K2(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,13),(J,7),(K,2)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/12*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][30][2,0]
                hv += 1/12*g[dei(p[I,1],p[J,0],p[K,1],p[K,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][48][2,0]
                hv += -1/12*g[dei(p[I,1],p[K,1],p[K,0],p[J,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][30][2,0]
                hv += -1/12*g[dei(p[I,1],p[K,0],p[K,1],p[J,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][48][2,0]
                hv += -1/12*g[dei(p[K,0],p[J,0],p[I,1],p[K,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][30][2,0]
                hv += -1/12*g[dei(p[K,1],p[J,0],p[I,1],p[K,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][48][2,0]
                hv += 1/12*g[dei(p[K,0],p[K,1],p[I,1],p[J,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][30][2,0]
                hv += 1/6*g[dei(p[K,0],p[K,1],p[I,1],p[J,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][15][2,0]
                hv += 1/12*g[dei(p[K,1],p[K,0],p[I,1],p[J,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][48][2,0]
                hv += 1/6*g[dei(p[K,1],p[K,0],p[I,1],p[J,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][33][2,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I13J7K3(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,13),(J,7),(K,3)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/12*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][30][3,0]
                hv += 1/12*g[dei(p[I,1],p[J,0],p[K,1],p[K,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][48][3,0]
                hv += -1/12*g[dei(p[I,1],p[K,1],p[K,0],p[J,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][30][3,0]
                hv += -1/12*g[dei(p[I,1],p[K,0],p[K,1],p[J,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][48][3,0]
                hv += -1/12*g[dei(p[K,0],p[J,0],p[I,1],p[K,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][30][3,0]
                hv += -1/12*g[dei(p[K,1],p[J,0],p[I,1],p[K,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][48][3,0]
                hv += 1/12*g[dei(p[K,0],p[K,1],p[I,1],p[J,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][30][3,0]
                hv += 1/6*g[dei(p[K,0],p[K,1],p[I,1],p[J,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][15][3,0]
                hv += 1/12*g[dei(p[K,1],p[K,0],p[I,1],p[J,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][48][3,0]
                hv += 1/6*g[dei(p[K,1],p[K,0],p[I,1],p[J,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][33][3,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I11J10K1(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,11),(J,10),(K,1)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/12*g[dei(p[I,1],p[J,1],p[K,0],p[K,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][9][1,0]
                hv += 1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][24][1,0]
                hv += 1/12*g[dei(p[I,1],p[J,1],p[K,1],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][39][1,0]
                hv += 1/6*g[dei(p[I,1],p[J,1],p[K,1],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][54][1,0]
                hv += -1/12*g[dei(p[I,1],p[K,0],p[K,0],p[J,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][9][1,0]
                hv += -1/12*g[dei(p[I,1],p[K,1],p[K,1],p[J,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][39][1,0]
                hv += -1/12*g[dei(p[K,0],p[J,1],p[I,1],p[K,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][9][1,0]
                hv += -1/12*g[dei(p[K,1],p[J,1],p[I,1],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][39][1,0]
                hv += 1/12*g[dei(p[K,0],p[K,0],p[I,1],p[J,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][9][1,0]
                hv += 1/12*g[dei(p[K,1],p[K,1],p[I,1],p[J,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][39][1,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I13J8K1(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,13),(J,8),(K,1)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/12*g[dei(p[I,1],p[J,1],p[K,0],p[K,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][24][1,0]
                hv += 1/12*g[dei(p[I,1],p[J,1],p[K,1],p[K,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][54][1,0]
                hv += -1/12*g[dei(p[I,1],p[K,0],p[K,0],p[J,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][24][1,0]
                hv += -1/12*g[dei(p[I,1],p[K,1],p[K,1],p[J,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][54][1,0]
                hv += -1/12*g[dei(p[K,0],p[J,1],p[I,1],p[K,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][24][1,0]
                hv += -1/12*g[dei(p[K,1],p[J,1],p[I,1],p[K,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][54][1,0]
                hv += 1/12*g[dei(p[K,0],p[K,0],p[I,1],p[J,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][24][1,0]
                hv += 1/6*g[dei(p[K,0],p[K,0],p[I,1],p[J,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][9][1,0]
                hv += 1/12*g[dei(p[K,1],p[K,1],p[I,1],p[J,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][54][1,0]
                hv += 1/6*g[dei(p[K,1],p[K,1],p[I,1],p[J,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][39][1,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I11J10K2(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,11),(J,10),(K,2)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/12*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][15][2,0]
                hv += 1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][30][2,0]
                hv += 1/12*g[dei(p[I,1],p[J,1],p[K,1],p[K,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][33][2,0]
                hv += 1/6*g[dei(p[I,1],p[J,1],p[K,1],p[K,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][48][2,0]
                hv += -1/12*g[dei(p[I,1],p[K,1],p[K,0],p[J,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][15][2,0]
                hv += -1/12*g[dei(p[I,1],p[K,0],p[K,1],p[J,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][33][2,0]
                hv += -1/12*g[dei(p[K,0],p[J,1],p[I,1],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][15][2,0]
                hv += -1/12*g[dei(p[K,1],p[J,1],p[I,1],p[K,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][33][2,0]
                hv += 1/12*g[dei(p[K,0],p[K,1],p[I,1],p[J,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][15][2,0]
                hv += 1/12*g[dei(p[K,1],p[K,0],p[I,1],p[J,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][33][2,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I11J10K3(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,11),(J,10),(K,3)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/12*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][15][3,0]
                hv += 1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][30][3,0]
                hv += 1/12*g[dei(p[I,1],p[J,1],p[K,1],p[K,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][33][3,0]
                hv += 1/6*g[dei(p[I,1],p[J,1],p[K,1],p[K,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][48][3,0]
                hv += -1/12*g[dei(p[I,1],p[K,1],p[K,0],p[J,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][15][3,0]
                hv += -1/12*g[dei(p[I,1],p[K,0],p[K,1],p[J,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][33][3,0]
                hv += -1/12*g[dei(p[K,0],p[J,1],p[I,1],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][15][3,0]
                hv += -1/12*g[dei(p[K,1],p[J,1],p[I,1],p[K,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][33][3,0]
                hv += 1/12*g[dei(p[K,0],p[K,1],p[I,1],p[J,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][15][3,0]
                hv += 1/12*g[dei(p[K,1],p[K,0],p[I,1],p[J,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][33][3,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I13J8K2(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,13),(J,8),(K,2)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/12*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][30][2,0]
                hv += 1/12*g[dei(p[I,1],p[J,1],p[K,1],p[K,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][48][2,0]
                hv += -1/12*g[dei(p[I,1],p[K,1],p[K,0],p[J,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][30][2,0]
                hv += -1/12*g[dei(p[I,1],p[K,0],p[K,1],p[J,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][48][2,0]
                hv += -1/12*g[dei(p[K,0],p[J,1],p[I,1],p[K,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][30][2,0]
                hv += -1/12*g[dei(p[K,1],p[J,1],p[I,1],p[K,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][48][2,0]
                hv += 1/12*g[dei(p[K,0],p[K,1],p[I,1],p[J,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][30][2,0]
                hv += 1/6*g[dei(p[K,0],p[K,1],p[I,1],p[J,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][15][2,0]
                hv += 1/12*g[dei(p[K,1],p[K,0],p[I,1],p[J,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][48][2,0]
                hv += 1/6*g[dei(p[K,1],p[K,0],p[I,1],p[J,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][33][2,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I13J8K3(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,13),(J,8),(K,3)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/12*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][30][3,0]
                hv += 1/12*g[dei(p[I,1],p[J,1],p[K,1],p[K,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][48][3,0]
                hv += -1/12*g[dei(p[I,1],p[K,1],p[K,0],p[J,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][30][3,0]
                hv += -1/12*g[dei(p[I,1],p[K,0],p[K,1],p[J,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][48][3,0]
                hv += -1/12*g[dei(p[K,0],p[J,1],p[I,1],p[K,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][30][3,0]
                hv += -1/12*g[dei(p[K,1],p[J,1],p[I,1],p[K,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][48][3,0]
                hv += 1/12*g[dei(p[K,0],p[K,1],p[I,1],p[J,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][30][3,0]
                hv += 1/6*g[dei(p[K,0],p[K,1],p[I,1],p[J,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][15][3,0]
                hv += 1/12*g[dei(p[K,1],p[K,0],p[I,1],p[J,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][48][3,0]
                hv += 1/6*g[dei(p[K,1],p[K,0],p[I,1],p[J,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][33][3,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I12J7K5(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,12),(J,7),(K,5)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/6*g[dei(p[I,0],p[K,1],p[K,0],p[J,0])]*r[I][0][12,0]*r[J][3][7,0]*r[K][27][5,0]
                hv += -1/6*g[dei(p[I,0],p[K,0],p[K,1],p[J,0])]*r[I][0][12,0]*r[J][3][7,0]*r[K][45][5,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I12J8K5(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,12),(J,8),(K,5)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/6*g[dei(p[I,0],p[K,1],p[K,0],p[J,1])]*r[I][0][12,0]*r[J][7][8,0]*r[K][27][5,0]
                hv += -1/6*g[dei(p[I,0],p[K,0],p[K,1],p[J,1])]*r[I][0][12,0]*r[J][7][8,0]*r[K][45][5,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I11J7K5(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,11),(J,7),(K,5)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/6*g[dei(p[I,1],p[K,1],p[K,0],p[J,0])]*r[I][4][11,0]*r[J][3][7,0]*r[K][27][5,0]
                hv += -1/6*g[dei(p[I,1],p[K,0],p[K,1],p[J,0])]*r[I][4][11,0]*r[J][3][7,0]*r[K][45][5,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I11J8K5(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,11),(J,8),(K,5)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/6*g[dei(p[I,1],p[K,1],p[K,0],p[J,1])]*r[I][4][11,0]*r[J][7][8,0]*r[K][27][5,0]
                hv += -1/6*g[dei(p[I,1],p[K,0],p[K,1],p[J,1])]*r[I][4][11,0]*r[J][7][8,0]*r[K][45][5,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I5J12K7(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,5),(J,12),(K,7)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/6*g[dei(p[J,0],p[I,1],p[I,0],p[K,0])]*r[I][27][5,0]*r[J][0][12,0]*r[K][3][7,0]
                hv += -1/6*g[dei(p[J,0],p[I,0],p[I,1],p[K,0])]*r[I][45][5,0]*r[J][0][12,0]*r[K][3][7,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I5J12K8(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,5),(J,12),(K,8)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/6*g[dei(p[J,0],p[I,1],p[I,0],p[K,1])]*r[I][27][5,0]*r[J][0][12,0]*r[K][7][8,0]
                hv += -1/6*g[dei(p[J,0],p[I,0],p[I,1],p[K,1])]*r[I][45][5,0]*r[J][0][12,0]*r[K][7][8,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I5J11K7(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,5),(J,11),(K,7)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/6*g[dei(p[J,1],p[I,1],p[I,0],p[K,0])]*r[I][27][5,0]*r[J][4][11,0]*r[K][3][7,0]
                hv += -1/6*g[dei(p[J,1],p[I,0],p[I,1],p[K,0])]*r[I][45][5,0]*r[J][4][11,0]*r[K][3][7,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I5J11K8(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,5),(J,11),(K,8)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/6*g[dei(p[J,1],p[I,1],p[I,0],p[K,1])]*r[I][27][5,0]*r[J][4][11,0]*r[K][7][8,0]
                hv += -1/6*g[dei(p[J,1],p[I,0],p[I,1],p[K,1])]*r[I][45][5,0]*r[J][4][11,0]*r[K][7][8,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I14J4K9(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,14),(J,4),(K,9)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/6*g[dei(p[J,0],p[K,0],p[I,0],p[J,1])]*r[I][2][14,0]*r[J][18][4,0]*r[K][1][9,0]
                hv += -1/6*g[dei(p[J,1],p[K,0],p[I,0],p[J,0])]*r[I][2][14,0]*r[J][36][4,0]*r[K][1][9,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I14J4K10(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,14),(J,4),(K,10)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/6*g[dei(p[J,0],p[K,1],p[I,0],p[J,1])]*r[I][2][14,0]*r[J][18][4,0]*r[K][5][10,0]
                hv += -1/6*g[dei(p[J,1],p[K,1],p[I,0],p[J,0])]*r[I][2][14,0]*r[J][36][4,0]*r[K][5][10,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I13J4K9(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,13),(J,4),(K,9)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/6*g[dei(p[J,0],p[K,0],p[I,1],p[J,1])]*r[I][6][13,0]*r[J][18][4,0]*r[K][1][9,0]
                hv += -1/6*g[dei(p[J,1],p[K,0],p[I,1],p[J,0])]*r[I][6][13,0]*r[J][36][4,0]*r[K][1][9,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I13J4K10(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,13),(J,4),(K,10)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/6*g[dei(p[J,0],p[K,1],p[I,1],p[J,1])]*r[I][6][13,0]*r[J][18][4,0]*r[K][5][10,0]
                hv += -1/6*g[dei(p[J,1],p[K,1],p[I,1],p[J,0])]*r[I][6][13,0]*r[J][36][4,0]*r[K][5][10,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I14J12K6(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,14),(J,12),(K,6)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/6*g[dei(p[J,0],p[K,0],p[I,0],p[K,0])]*r[I][2][14,0]*r[J][0][12,0]*r[K][22][6,0]
                hv += -1/6*g[dei(p[J,0],p[K,1],p[I,0],p[K,1])]*r[I][2][14,0]*r[J][0][12,0]*r[K][52][6,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I13J12K6(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,13),(J,12),(K,6)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/6*g[dei(p[J,0],p[K,0],p[I,1],p[K,0])]*r[I][6][13,0]*r[J][0][12,0]*r[K][22][6,0]
                hv += -1/6*g[dei(p[J,0],p[K,1],p[I,1],p[K,1])]*r[I][6][13,0]*r[J][0][12,0]*r[K][52][6,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I14J11K6(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,14),(J,11),(K,6)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/6*g[dei(p[J,1],p[K,0],p[I,0],p[K,0])]*r[I][2][14,0]*r[J][4][11,0]*r[K][22][6,0]
                hv += -1/6*g[dei(p[J,1],p[K,1],p[I,0],p[K,1])]*r[I][2][14,0]*r[J][4][11,0]*r[K][52][6,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I13J11K6(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,13),(J,11),(K,6)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/6*g[dei(p[J,1],p[K,0],p[I,1],p[K,0])]*r[I][6][13,0]*r[J][4][11,0]*r[K][22][6,0]
                hv += -1/6*g[dei(p[J,1],p[K,1],p[I,1],p[K,1])]*r[I][6][13,0]*r[J][4][11,0]*r[K][52][6,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I9J15K7(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,9),(J,15),(K,7)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/6*g[dei(p[J,0],p[I,0],p[J,0],p[K,0])]*r[I][1][9,0]*r[J][11][15,0]*r[K][3][7,0]
                hv += -1/6*g[dei(p[J,1],p[I,0],p[J,1],p[K,0])]*r[I][1][9,0]*r[J][41][15,0]*r[K][3][7,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I9J15K8(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,9),(J,15),(K,8)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/6*g[dei(p[J,0],p[I,0],p[J,0],p[K,1])]*r[I][1][9,0]*r[J][11][15,0]*r[K][7][8,0]
                hv += -1/6*g[dei(p[J,1],p[I,0],p[J,1],p[K,1])]*r[I][1][9,0]*r[J][41][15,0]*r[K][7][8,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I10J15K7(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,10),(J,15),(K,7)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/6*g[dei(p[J,0],p[I,1],p[J,0],p[K,0])]*r[I][5][10,0]*r[J][11][15,0]*r[K][3][7,0]
                hv += -1/6*g[dei(p[J,1],p[I,1],p[J,1],p[K,0])]*r[I][5][10,0]*r[J][41][15,0]*r[K][3][7,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I10J15K8(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,10),(J,15),(K,8)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/6*g[dei(p[J,0],p[I,1],p[J,0],p[K,1])]*r[I][5][10,0]*r[J][11][15,0]*r[K][7][8,0]
                hv += -1/6*g[dei(p[J,1],p[I,1],p[J,1],p[K,1])]*r[I][5][10,0]*r[J][41][15,0]*r[K][7][8,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I7J15K9(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,7),(J,15),(K,9)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/6*g[dei(p[J,0],p[K,0],p[J,0],p[I,0])]*r[I][3][7,0]*r[J][11][15,0]*r[K][1][9,0]
                hv += 1/6*g[dei(p[J,1],p[K,0],p[J,1],p[I,0])]*r[I][3][7,0]*r[J][41][15,0]*r[K][1][9,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I8J15K9(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,8),(J,15),(K,9)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/6*g[dei(p[J,0],p[K,0],p[J,0],p[I,1])]*r[I][7][8,0]*r[J][11][15,0]*r[K][1][9,0]
                hv += 1/6*g[dei(p[J,1],p[K,0],p[J,1],p[I,1])]*r[I][7][8,0]*r[J][41][15,0]*r[K][1][9,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I7J15K10(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,7),(J,15),(K,10)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/6*g[dei(p[J,0],p[K,1],p[J,0],p[I,0])]*r[I][3][7,0]*r[J][11][15,0]*r[K][5][10,0]
                hv += 1/6*g[dei(p[J,1],p[K,1],p[J,1],p[I,0])]*r[I][3][7,0]*r[J][41][15,0]*r[K][5][10,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I8J15K10(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,8),(J,15),(K,10)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/6*g[dei(p[J,0],p[K,1],p[J,0],p[I,1])]*r[I][7][8,0]*r[J][11][15,0]*r[K][5][10,0]
                hv += 1/6*g[dei(p[J,1],p[K,1],p[J,1],p[I,1])]*r[I][7][8,0]*r[J][41][15,0]*r[K][5][10,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I6J12K14(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,6),(J,12),(K,14)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/6*g[dei(p[J,0],p[I,0],p[K,0],p[I,0])]*r[I][22][6,0]*r[J][0][12,0]*r[K][2][14,0]
                hv += 1/6*g[dei(p[J,0],p[I,1],p[K,0],p[I,1])]*r[I][52][6,0]*r[J][0][12,0]*r[K][2][14,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I6J12K13(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,6),(J,12),(K,13)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/6*g[dei(p[J,0],p[I,0],p[K,1],p[I,0])]*r[I][22][6,0]*r[J][0][12,0]*r[K][6][13,0]
                hv += 1/6*g[dei(p[J,0],p[I,1],p[K,1],p[I,1])]*r[I][52][6,0]*r[J][0][12,0]*r[K][6][13,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I6J11K14(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,6),(J,11),(K,14)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/6*g[dei(p[J,1],p[I,0],p[K,0],p[I,0])]*r[I][22][6,0]*r[J][4][11,0]*r[K][2][14,0]
                hv += 1/6*g[dei(p[J,1],p[I,1],p[K,0],p[I,1])]*r[I][52][6,0]*r[J][4][11,0]*r[K][2][14,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I6J11K13(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,6),(J,11),(K,13)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/6*g[dei(p[J,1],p[I,0],p[K,1],p[I,0])]*r[I][22][6,0]*r[J][4][11,0]*r[K][6][13,0]
                hv += 1/6*g[dei(p[J,1],p[I,1],p[K,1],p[I,1])]*r[I][52][6,0]*r[J][4][11,0]*r[K][6][13,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I9J1K12(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,9),(J,1),(K,12)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/12*g[dei(p[J,0],p[I,0],p[K,0],p[J,0])]*r[I][1][9,0]*r[J][9][1,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[J,1],p[I,0],p[K,0],p[J,1])]*r[I][1][9,0]*r[J][39][1,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[J,0],p[J,0],p[K,0],p[I,0])]*r[I][1][9,0]*r[J][9][1,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[J,1],p[J,1],p[K,0],p[I,0])]*r[I][1][9,0]*r[J][39][1,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[K,0],p[I,0],p[J,0],p[J,0])]*r[I][1][9,0]*r[J][9][1,0]*r[K][0][12,0]
                hv += -1/6*g[dei(p[K,0],p[I,0],p[J,0],p[J,0])]*r[I][1][9,0]*r[J][24][1,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[K,0],p[I,0],p[J,1],p[J,1])]*r[I][1][9,0]*r[J][39][1,0]*r[K][0][12,0]
                hv += -1/6*g[dei(p[K,0],p[I,0],p[J,1],p[J,1])]*r[I][1][9,0]*r[J][54][1,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[K,0],p[J,0],p[J,0],p[I,0])]*r[I][1][9,0]*r[J][9][1,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[K,0],p[J,1],p[J,1],p[I,0])]*r[I][1][9,0]*r[J][39][1,0]*r[K][0][12,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I7J1K14(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,7),(J,1),(K,14)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/12*g[dei(p[J,0],p[I,0],p[K,0],p[J,0])]*r[I][3][7,0]*r[J][24][1,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[J,1],p[I,0],p[K,0],p[J,1])]*r[I][3][7,0]*r[J][54][1,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[J,0],p[J,0],p[K,0],p[I,0])]*r[I][3][7,0]*r[J][24][1,0]*r[K][2][14,0]
                hv += -1/6*g[dei(p[J,0],p[J,0],p[K,0],p[I,0])]*r[I][3][7,0]*r[J][9][1,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[J,1],p[J,1],p[K,0],p[I,0])]*r[I][3][7,0]*r[J][54][1,0]*r[K][2][14,0]
                hv += -1/6*g[dei(p[J,1],p[J,1],p[K,0],p[I,0])]*r[I][3][7,0]*r[J][39][1,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[K,0],p[I,0],p[J,0],p[J,0])]*r[I][3][7,0]*r[J][24][1,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[K,0],p[I,0],p[J,1],p[J,1])]*r[I][3][7,0]*r[J][54][1,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[K,0],p[J,0],p[J,0],p[I,0])]*r[I][3][7,0]*r[J][24][1,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[K,0],p[J,1],p[J,1],p[I,0])]*r[I][3][7,0]*r[J][54][1,0]*r[K][2][14,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I9J2K12(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,9),(J,2),(K,12)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/12*g[dei(p[J,0],p[I,0],p[K,0],p[J,1])]*r[I][1][9,0]*r[J][15][2,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[J,1],p[I,0],p[K,0],p[J,0])]*r[I][1][9,0]*r[J][33][2,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[J,0],p[J,1],p[K,0],p[I,0])]*r[I][1][9,0]*r[J][15][2,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[J,1],p[J,0],p[K,0],p[I,0])]*r[I][1][9,0]*r[J][33][2,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[K,0],p[I,0],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][15][2,0]*r[K][0][12,0]
                hv += -1/6*g[dei(p[K,0],p[I,0],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][30][2,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[K,0],p[I,0],p[J,1],p[J,0])]*r[I][1][9,0]*r[J][33][2,0]*r[K][0][12,0]
                hv += -1/6*g[dei(p[K,0],p[I,0],p[J,1],p[J,0])]*r[I][1][9,0]*r[J][48][2,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[K,0],p[J,1],p[J,0],p[I,0])]*r[I][1][9,0]*r[J][15][2,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[K,0],p[J,0],p[J,1],p[I,0])]*r[I][1][9,0]*r[J][33][2,0]*r[K][0][12,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I9J3K12(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,9),(J,3),(K,12)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/12*g[dei(p[J,0],p[I,0],p[K,0],p[J,1])]*r[I][1][9,0]*r[J][15][3,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[J,1],p[I,0],p[K,0],p[J,0])]*r[I][1][9,0]*r[J][33][3,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[J,0],p[J,1],p[K,0],p[I,0])]*r[I][1][9,0]*r[J][15][3,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[J,1],p[J,0],p[K,0],p[I,0])]*r[I][1][9,0]*r[J][33][3,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[K,0],p[I,0],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][15][3,0]*r[K][0][12,0]
                hv += -1/6*g[dei(p[K,0],p[I,0],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][30][3,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[K,0],p[I,0],p[J,1],p[J,0])]*r[I][1][9,0]*r[J][33][3,0]*r[K][0][12,0]
                hv += -1/6*g[dei(p[K,0],p[I,0],p[J,1],p[J,0])]*r[I][1][9,0]*r[J][48][3,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[K,0],p[J,1],p[J,0],p[I,0])]*r[I][1][9,0]*r[J][15][3,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[K,0],p[J,0],p[J,1],p[I,0])]*r[I][1][9,0]*r[J][33][3,0]*r[K][0][12,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I7J2K14(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,7),(J,2),(K,14)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/12*g[dei(p[J,0],p[I,0],p[K,0],p[J,1])]*r[I][3][7,0]*r[J][30][2,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[J,1],p[I,0],p[K,0],p[J,0])]*r[I][3][7,0]*r[J][48][2,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[J,0],p[J,1],p[K,0],p[I,0])]*r[I][3][7,0]*r[J][30][2,0]*r[K][2][14,0]
                hv += -1/6*g[dei(p[J,0],p[J,1],p[K,0],p[I,0])]*r[I][3][7,0]*r[J][15][2,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[J,1],p[J,0],p[K,0],p[I,0])]*r[I][3][7,0]*r[J][48][2,0]*r[K][2][14,0]
                hv += -1/6*g[dei(p[J,1],p[J,0],p[K,0],p[I,0])]*r[I][3][7,0]*r[J][33][2,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[K,0],p[I,0],p[J,0],p[J,1])]*r[I][3][7,0]*r[J][30][2,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[K,0],p[I,0],p[J,1],p[J,0])]*r[I][3][7,0]*r[J][48][2,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[K,0],p[J,1],p[J,0],p[I,0])]*r[I][3][7,0]*r[J][30][2,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[K,0],p[J,0],p[J,1],p[I,0])]*r[I][3][7,0]*r[J][48][2,0]*r[K][2][14,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I7J3K14(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,7),(J,3),(K,14)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/12*g[dei(p[J,0],p[I,0],p[K,0],p[J,1])]*r[I][3][7,0]*r[J][30][3,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[J,1],p[I,0],p[K,0],p[J,0])]*r[I][3][7,0]*r[J][48][3,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[J,0],p[J,1],p[K,0],p[I,0])]*r[I][3][7,0]*r[J][30][3,0]*r[K][2][14,0]
                hv += -1/6*g[dei(p[J,0],p[J,1],p[K,0],p[I,0])]*r[I][3][7,0]*r[J][15][3,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[J,1],p[J,0],p[K,0],p[I,0])]*r[I][3][7,0]*r[J][48][3,0]*r[K][2][14,0]
                hv += -1/6*g[dei(p[J,1],p[J,0],p[K,0],p[I,0])]*r[I][3][7,0]*r[J][33][3,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[K,0],p[I,0],p[J,0],p[J,1])]*r[I][3][7,0]*r[J][30][3,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[K,0],p[I,0],p[J,1],p[J,0])]*r[I][3][7,0]*r[J][48][3,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[K,0],p[J,1],p[J,0],p[I,0])]*r[I][3][7,0]*r[J][30][3,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[K,0],p[J,0],p[J,1],p[I,0])]*r[I][3][7,0]*r[J][48][3,0]*r[K][2][14,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I9J4K14(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,9),(J,4),(K,14)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/6*g[dei(p[J,0],p[I,0],p[K,0],p[J,1])]*r[I][1][9,0]*r[J][18][4,0]*r[K][2][14,0]
                hv += 1/6*g[dei(p[J,1],p[I,0],p[K,0],p[J,0])]*r[I][1][9,0]*r[J][36][4,0]*r[K][2][14,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I10J1K12(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,10),(J,1),(K,12)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/12*g[dei(p[J,0],p[I,1],p[K,0],p[J,0])]*r[I][5][10,0]*r[J][9][1,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[J,1],p[I,1],p[K,0],p[J,1])]*r[I][5][10,0]*r[J][39][1,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[J,0],p[J,0],p[K,0],p[I,1])]*r[I][5][10,0]*r[J][9][1,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[J,1],p[J,1],p[K,0],p[I,1])]*r[I][5][10,0]*r[J][39][1,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[K,0],p[I,1],p[J,0],p[J,0])]*r[I][5][10,0]*r[J][9][1,0]*r[K][0][12,0]
                hv += -1/6*g[dei(p[K,0],p[I,1],p[J,0],p[J,0])]*r[I][5][10,0]*r[J][24][1,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[K,0],p[I,1],p[J,1],p[J,1])]*r[I][5][10,0]*r[J][39][1,0]*r[K][0][12,0]
                hv += -1/6*g[dei(p[K,0],p[I,1],p[J,1],p[J,1])]*r[I][5][10,0]*r[J][54][1,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[K,0],p[J,0],p[J,0],p[I,1])]*r[I][5][10,0]*r[J][9][1,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[K,0],p[J,1],p[J,1],p[I,1])]*r[I][5][10,0]*r[J][39][1,0]*r[K][0][12,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I8J1K14(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,8),(J,1),(K,14)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/12*g[dei(p[J,0],p[I,1],p[K,0],p[J,0])]*r[I][7][8,0]*r[J][24][1,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[J,1],p[I,1],p[K,0],p[J,1])]*r[I][7][8,0]*r[J][54][1,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[J,0],p[J,0],p[K,0],p[I,1])]*r[I][7][8,0]*r[J][24][1,0]*r[K][2][14,0]
                hv += -1/6*g[dei(p[J,0],p[J,0],p[K,0],p[I,1])]*r[I][7][8,0]*r[J][9][1,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[J,1],p[J,1],p[K,0],p[I,1])]*r[I][7][8,0]*r[J][54][1,0]*r[K][2][14,0]
                hv += -1/6*g[dei(p[J,1],p[J,1],p[K,0],p[I,1])]*r[I][7][8,0]*r[J][39][1,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[K,0],p[I,1],p[J,0],p[J,0])]*r[I][7][8,0]*r[J][24][1,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[K,0],p[I,1],p[J,1],p[J,1])]*r[I][7][8,0]*r[J][54][1,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[K,0],p[J,0],p[J,0],p[I,1])]*r[I][7][8,0]*r[J][24][1,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[K,0],p[J,1],p[J,1],p[I,1])]*r[I][7][8,0]*r[J][54][1,0]*r[K][2][14,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I10J2K12(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,10),(J,2),(K,12)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/12*g[dei(p[J,0],p[I,1],p[K,0],p[J,1])]*r[I][5][10,0]*r[J][15][2,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[J,1],p[I,1],p[K,0],p[J,0])]*r[I][5][10,0]*r[J][33][2,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[J,0],p[J,1],p[K,0],p[I,1])]*r[I][5][10,0]*r[J][15][2,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[J,1],p[J,0],p[K,0],p[I,1])]*r[I][5][10,0]*r[J][33][2,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[K,0],p[I,1],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][15][2,0]*r[K][0][12,0]
                hv += -1/6*g[dei(p[K,0],p[I,1],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][30][2,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[K,0],p[I,1],p[J,1],p[J,0])]*r[I][5][10,0]*r[J][33][2,0]*r[K][0][12,0]
                hv += -1/6*g[dei(p[K,0],p[I,1],p[J,1],p[J,0])]*r[I][5][10,0]*r[J][48][2,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[K,0],p[J,1],p[J,0],p[I,1])]*r[I][5][10,0]*r[J][15][2,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[K,0],p[J,0],p[J,1],p[I,1])]*r[I][5][10,0]*r[J][33][2,0]*r[K][0][12,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I10J3K12(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,10),(J,3),(K,12)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/12*g[dei(p[J,0],p[I,1],p[K,0],p[J,1])]*r[I][5][10,0]*r[J][15][3,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[J,1],p[I,1],p[K,0],p[J,0])]*r[I][5][10,0]*r[J][33][3,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[J,0],p[J,1],p[K,0],p[I,1])]*r[I][5][10,0]*r[J][15][3,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[J,1],p[J,0],p[K,0],p[I,1])]*r[I][5][10,0]*r[J][33][3,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[K,0],p[I,1],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][15][3,0]*r[K][0][12,0]
                hv += -1/6*g[dei(p[K,0],p[I,1],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][30][3,0]*r[K][0][12,0]
                hv += -1/12*g[dei(p[K,0],p[I,1],p[J,1],p[J,0])]*r[I][5][10,0]*r[J][33][3,0]*r[K][0][12,0]
                hv += -1/6*g[dei(p[K,0],p[I,1],p[J,1],p[J,0])]*r[I][5][10,0]*r[J][48][3,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[K,0],p[J,1],p[J,0],p[I,1])]*r[I][5][10,0]*r[J][15][3,0]*r[K][0][12,0]
                hv += 1/12*g[dei(p[K,0],p[J,0],p[J,1],p[I,1])]*r[I][5][10,0]*r[J][33][3,0]*r[K][0][12,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I8J2K14(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,8),(J,2),(K,14)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/12*g[dei(p[J,0],p[I,1],p[K,0],p[J,1])]*r[I][7][8,0]*r[J][30][2,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[J,1],p[I,1],p[K,0],p[J,0])]*r[I][7][8,0]*r[J][48][2,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[J,0],p[J,1],p[K,0],p[I,1])]*r[I][7][8,0]*r[J][30][2,0]*r[K][2][14,0]
                hv += -1/6*g[dei(p[J,0],p[J,1],p[K,0],p[I,1])]*r[I][7][8,0]*r[J][15][2,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[J,1],p[J,0],p[K,0],p[I,1])]*r[I][7][8,0]*r[J][48][2,0]*r[K][2][14,0]
                hv += -1/6*g[dei(p[J,1],p[J,0],p[K,0],p[I,1])]*r[I][7][8,0]*r[J][33][2,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[K,0],p[I,1],p[J,0],p[J,1])]*r[I][7][8,0]*r[J][30][2,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[K,0],p[I,1],p[J,1],p[J,0])]*r[I][7][8,0]*r[J][48][2,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[K,0],p[J,1],p[J,0],p[I,1])]*r[I][7][8,0]*r[J][30][2,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[K,0],p[J,0],p[J,1],p[I,1])]*r[I][7][8,0]*r[J][48][2,0]*r[K][2][14,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I8J3K14(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,8),(J,3),(K,14)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/12*g[dei(p[J,0],p[I,1],p[K,0],p[J,1])]*r[I][7][8,0]*r[J][30][3,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[J,1],p[I,1],p[K,0],p[J,0])]*r[I][7][8,0]*r[J][48][3,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[J,0],p[J,1],p[K,0],p[I,1])]*r[I][7][8,0]*r[J][30][3,0]*r[K][2][14,0]
                hv += -1/6*g[dei(p[J,0],p[J,1],p[K,0],p[I,1])]*r[I][7][8,0]*r[J][15][3,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[J,1],p[J,0],p[K,0],p[I,1])]*r[I][7][8,0]*r[J][48][3,0]*r[K][2][14,0]
                hv += -1/6*g[dei(p[J,1],p[J,0],p[K,0],p[I,1])]*r[I][7][8,0]*r[J][33][3,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[K,0],p[I,1],p[J,0],p[J,1])]*r[I][7][8,0]*r[J][30][3,0]*r[K][2][14,0]
                hv += -1/12*g[dei(p[K,0],p[I,1],p[J,1],p[J,0])]*r[I][7][8,0]*r[J][48][3,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[K,0],p[J,1],p[J,0],p[I,1])]*r[I][7][8,0]*r[J][30][3,0]*r[K][2][14,0]
                hv += 1/12*g[dei(p[K,0],p[J,0],p[J,1],p[I,1])]*r[I][7][8,0]*r[J][48][3,0]*r[K][2][14,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I10J4K14(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,10),(J,4),(K,14)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/6*g[dei(p[J,0],p[I,1],p[K,0],p[J,1])]*r[I][5][10,0]*r[J][18][4,0]*r[K][2][14,0]
                hv += 1/6*g[dei(p[J,1],p[I,1],p[K,0],p[J,0])]*r[I][5][10,0]*r[J][36][4,0]*r[K][2][14,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I9J1K11(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,9),(J,1),(K,11)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/12*g[dei(p[J,0],p[I,0],p[K,1],p[J,0])]*r[I][1][9,0]*r[J][9][1,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[J,1],p[I,0],p[K,1],p[J,1])]*r[I][1][9,0]*r[J][39][1,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[J,0],p[J,0],p[K,1],p[I,0])]*r[I][1][9,0]*r[J][9][1,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[J,1],p[J,1],p[K,1],p[I,0])]*r[I][1][9,0]*r[J][39][1,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[K,1],p[I,0],p[J,0],p[J,0])]*r[I][1][9,0]*r[J][9][1,0]*r[K][4][11,0]
                hv += -1/6*g[dei(p[K,1],p[I,0],p[J,0],p[J,0])]*r[I][1][9,0]*r[J][24][1,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[K,1],p[I,0],p[J,1],p[J,1])]*r[I][1][9,0]*r[J][39][1,0]*r[K][4][11,0]
                hv += -1/6*g[dei(p[K,1],p[I,0],p[J,1],p[J,1])]*r[I][1][9,0]*r[J][54][1,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[K,1],p[J,0],p[J,0],p[I,0])]*r[I][1][9,0]*r[J][9][1,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[K,1],p[J,1],p[J,1],p[I,0])]*r[I][1][9,0]*r[J][39][1,0]*r[K][4][11,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I7J1K13(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,7),(J,1),(K,13)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/12*g[dei(p[J,0],p[I,0],p[K,1],p[J,0])]*r[I][3][7,0]*r[J][24][1,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[J,1],p[I,0],p[K,1],p[J,1])]*r[I][3][7,0]*r[J][54][1,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[J,0],p[J,0],p[K,1],p[I,0])]*r[I][3][7,0]*r[J][24][1,0]*r[K][6][13,0]
                hv += -1/6*g[dei(p[J,0],p[J,0],p[K,1],p[I,0])]*r[I][3][7,0]*r[J][9][1,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[J,1],p[J,1],p[K,1],p[I,0])]*r[I][3][7,0]*r[J][54][1,0]*r[K][6][13,0]
                hv += -1/6*g[dei(p[J,1],p[J,1],p[K,1],p[I,0])]*r[I][3][7,0]*r[J][39][1,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[K,1],p[I,0],p[J,0],p[J,0])]*r[I][3][7,0]*r[J][24][1,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[K,1],p[I,0],p[J,1],p[J,1])]*r[I][3][7,0]*r[J][54][1,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[K,1],p[J,0],p[J,0],p[I,0])]*r[I][3][7,0]*r[J][24][1,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[K,1],p[J,1],p[J,1],p[I,0])]*r[I][3][7,0]*r[J][54][1,0]*r[K][6][13,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I9J2K11(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,9),(J,2),(K,11)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/12*g[dei(p[J,0],p[I,0],p[K,1],p[J,1])]*r[I][1][9,0]*r[J][15][2,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[J,1],p[I,0],p[K,1],p[J,0])]*r[I][1][9,0]*r[J][33][2,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[J,0],p[J,1],p[K,1],p[I,0])]*r[I][1][9,0]*r[J][15][2,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[J,1],p[J,0],p[K,1],p[I,0])]*r[I][1][9,0]*r[J][33][2,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[K,1],p[I,0],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][15][2,0]*r[K][4][11,0]
                hv += -1/6*g[dei(p[K,1],p[I,0],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][30][2,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[K,1],p[I,0],p[J,1],p[J,0])]*r[I][1][9,0]*r[J][33][2,0]*r[K][4][11,0]
                hv += -1/6*g[dei(p[K,1],p[I,0],p[J,1],p[J,0])]*r[I][1][9,0]*r[J][48][2,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[K,1],p[J,1],p[J,0],p[I,0])]*r[I][1][9,0]*r[J][15][2,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[K,1],p[J,0],p[J,1],p[I,0])]*r[I][1][9,0]*r[J][33][2,0]*r[K][4][11,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I9J3K11(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,9),(J,3),(K,11)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/12*g[dei(p[J,0],p[I,0],p[K,1],p[J,1])]*r[I][1][9,0]*r[J][15][3,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[J,1],p[I,0],p[K,1],p[J,0])]*r[I][1][9,0]*r[J][33][3,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[J,0],p[J,1],p[K,1],p[I,0])]*r[I][1][9,0]*r[J][15][3,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[J,1],p[J,0],p[K,1],p[I,0])]*r[I][1][9,0]*r[J][33][3,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[K,1],p[I,0],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][15][3,0]*r[K][4][11,0]
                hv += -1/6*g[dei(p[K,1],p[I,0],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][30][3,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[K,1],p[I,0],p[J,1],p[J,0])]*r[I][1][9,0]*r[J][33][3,0]*r[K][4][11,0]
                hv += -1/6*g[dei(p[K,1],p[I,0],p[J,1],p[J,0])]*r[I][1][9,0]*r[J][48][3,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[K,1],p[J,1],p[J,0],p[I,0])]*r[I][1][9,0]*r[J][15][3,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[K,1],p[J,0],p[J,1],p[I,0])]*r[I][1][9,0]*r[J][33][3,0]*r[K][4][11,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I7J2K13(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,7),(J,2),(K,13)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/12*g[dei(p[J,0],p[I,0],p[K,1],p[J,1])]*r[I][3][7,0]*r[J][30][2,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[J,1],p[I,0],p[K,1],p[J,0])]*r[I][3][7,0]*r[J][48][2,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[J,0],p[J,1],p[K,1],p[I,0])]*r[I][3][7,0]*r[J][30][2,0]*r[K][6][13,0]
                hv += -1/6*g[dei(p[J,0],p[J,1],p[K,1],p[I,0])]*r[I][3][7,0]*r[J][15][2,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[J,1],p[J,0],p[K,1],p[I,0])]*r[I][3][7,0]*r[J][48][2,0]*r[K][6][13,0]
                hv += -1/6*g[dei(p[J,1],p[J,0],p[K,1],p[I,0])]*r[I][3][7,0]*r[J][33][2,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[K,1],p[I,0],p[J,0],p[J,1])]*r[I][3][7,0]*r[J][30][2,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[K,1],p[I,0],p[J,1],p[J,0])]*r[I][3][7,0]*r[J][48][2,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[K,1],p[J,1],p[J,0],p[I,0])]*r[I][3][7,0]*r[J][30][2,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[K,1],p[J,0],p[J,1],p[I,0])]*r[I][3][7,0]*r[J][48][2,0]*r[K][6][13,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I7J3K13(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,7),(J,3),(K,13)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/12*g[dei(p[J,0],p[I,0],p[K,1],p[J,1])]*r[I][3][7,0]*r[J][30][3,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[J,1],p[I,0],p[K,1],p[J,0])]*r[I][3][7,0]*r[J][48][3,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[J,0],p[J,1],p[K,1],p[I,0])]*r[I][3][7,0]*r[J][30][3,0]*r[K][6][13,0]
                hv += -1/6*g[dei(p[J,0],p[J,1],p[K,1],p[I,0])]*r[I][3][7,0]*r[J][15][3,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[J,1],p[J,0],p[K,1],p[I,0])]*r[I][3][7,0]*r[J][48][3,0]*r[K][6][13,0]
                hv += -1/6*g[dei(p[J,1],p[J,0],p[K,1],p[I,0])]*r[I][3][7,0]*r[J][33][3,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[K,1],p[I,0],p[J,0],p[J,1])]*r[I][3][7,0]*r[J][30][3,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[K,1],p[I,0],p[J,1],p[J,0])]*r[I][3][7,0]*r[J][48][3,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[K,1],p[J,1],p[J,0],p[I,0])]*r[I][3][7,0]*r[J][30][3,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[K,1],p[J,0],p[J,1],p[I,0])]*r[I][3][7,0]*r[J][48][3,0]*r[K][6][13,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I9J4K13(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,9),(J,4),(K,13)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/6*g[dei(p[J,0],p[I,0],p[K,1],p[J,1])]*r[I][1][9,0]*r[J][18][4,0]*r[K][6][13,0]
                hv += 1/6*g[dei(p[J,1],p[I,0],p[K,1],p[J,0])]*r[I][1][9,0]*r[J][36][4,0]*r[K][6][13,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I10J1K11(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,10),(J,1),(K,11)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/12*g[dei(p[J,0],p[I,1],p[K,1],p[J,0])]*r[I][5][10,0]*r[J][9][1,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[J,1],p[I,1],p[K,1],p[J,1])]*r[I][5][10,0]*r[J][39][1,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[J,0],p[J,0],p[K,1],p[I,1])]*r[I][5][10,0]*r[J][9][1,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[J,1],p[J,1],p[K,1],p[I,1])]*r[I][5][10,0]*r[J][39][1,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[K,1],p[I,1],p[J,0],p[J,0])]*r[I][5][10,0]*r[J][9][1,0]*r[K][4][11,0]
                hv += -1/6*g[dei(p[K,1],p[I,1],p[J,0],p[J,0])]*r[I][5][10,0]*r[J][24][1,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[K,1],p[I,1],p[J,1],p[J,1])]*r[I][5][10,0]*r[J][39][1,0]*r[K][4][11,0]
                hv += -1/6*g[dei(p[K,1],p[I,1],p[J,1],p[J,1])]*r[I][5][10,0]*r[J][54][1,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[K,1],p[J,0],p[J,0],p[I,1])]*r[I][5][10,0]*r[J][9][1,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[K,1],p[J,1],p[J,1],p[I,1])]*r[I][5][10,0]*r[J][39][1,0]*r[K][4][11,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I8J1K13(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,8),(J,1),(K,13)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/12*g[dei(p[J,0],p[I,1],p[K,1],p[J,0])]*r[I][7][8,0]*r[J][24][1,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[J,1],p[I,1],p[K,1],p[J,1])]*r[I][7][8,0]*r[J][54][1,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[J,0],p[J,0],p[K,1],p[I,1])]*r[I][7][8,0]*r[J][24][1,0]*r[K][6][13,0]
                hv += -1/6*g[dei(p[J,0],p[J,0],p[K,1],p[I,1])]*r[I][7][8,0]*r[J][9][1,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[J,1],p[J,1],p[K,1],p[I,1])]*r[I][7][8,0]*r[J][54][1,0]*r[K][6][13,0]
                hv += -1/6*g[dei(p[J,1],p[J,1],p[K,1],p[I,1])]*r[I][7][8,0]*r[J][39][1,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[K,1],p[I,1],p[J,0],p[J,0])]*r[I][7][8,0]*r[J][24][1,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[K,1],p[I,1],p[J,1],p[J,1])]*r[I][7][8,0]*r[J][54][1,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[K,1],p[J,0],p[J,0],p[I,1])]*r[I][7][8,0]*r[J][24][1,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[K,1],p[J,1],p[J,1],p[I,1])]*r[I][7][8,0]*r[J][54][1,0]*r[K][6][13,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I10J2K11(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,10),(J,2),(K,11)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/12*g[dei(p[J,0],p[I,1],p[K,1],p[J,1])]*r[I][5][10,0]*r[J][15][2,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[J,1],p[I,1],p[K,1],p[J,0])]*r[I][5][10,0]*r[J][33][2,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[J,0],p[J,1],p[K,1],p[I,1])]*r[I][5][10,0]*r[J][15][2,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[J,1],p[J,0],p[K,1],p[I,1])]*r[I][5][10,0]*r[J][33][2,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[K,1],p[I,1],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][15][2,0]*r[K][4][11,0]
                hv += -1/6*g[dei(p[K,1],p[I,1],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][30][2,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[K,1],p[I,1],p[J,1],p[J,0])]*r[I][5][10,0]*r[J][33][2,0]*r[K][4][11,0]
                hv += -1/6*g[dei(p[K,1],p[I,1],p[J,1],p[J,0])]*r[I][5][10,0]*r[J][48][2,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[K,1],p[J,1],p[J,0],p[I,1])]*r[I][5][10,0]*r[J][15][2,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[K,1],p[J,0],p[J,1],p[I,1])]*r[I][5][10,0]*r[J][33][2,0]*r[K][4][11,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I10J3K11(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,10),(J,3),(K,11)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/12*g[dei(p[J,0],p[I,1],p[K,1],p[J,1])]*r[I][5][10,0]*r[J][15][3,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[J,1],p[I,1],p[K,1],p[J,0])]*r[I][5][10,0]*r[J][33][3,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[J,0],p[J,1],p[K,1],p[I,1])]*r[I][5][10,0]*r[J][15][3,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[J,1],p[J,0],p[K,1],p[I,1])]*r[I][5][10,0]*r[J][33][3,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[K,1],p[I,1],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][15][3,0]*r[K][4][11,0]
                hv += -1/6*g[dei(p[K,1],p[I,1],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][30][3,0]*r[K][4][11,0]
                hv += -1/12*g[dei(p[K,1],p[I,1],p[J,1],p[J,0])]*r[I][5][10,0]*r[J][33][3,0]*r[K][4][11,0]
                hv += -1/6*g[dei(p[K,1],p[I,1],p[J,1],p[J,0])]*r[I][5][10,0]*r[J][48][3,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[K,1],p[J,1],p[J,0],p[I,1])]*r[I][5][10,0]*r[J][15][3,0]*r[K][4][11,0]
                hv += 1/12*g[dei(p[K,1],p[J,0],p[J,1],p[I,1])]*r[I][5][10,0]*r[J][33][3,0]*r[K][4][11,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I8J2K13(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,8),(J,2),(K,13)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/12*g[dei(p[J,0],p[I,1],p[K,1],p[J,1])]*r[I][7][8,0]*r[J][30][2,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[J,1],p[I,1],p[K,1],p[J,0])]*r[I][7][8,0]*r[J][48][2,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[J,0],p[J,1],p[K,1],p[I,1])]*r[I][7][8,0]*r[J][30][2,0]*r[K][6][13,0]
                hv += -1/6*g[dei(p[J,0],p[J,1],p[K,1],p[I,1])]*r[I][7][8,0]*r[J][15][2,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[J,1],p[J,0],p[K,1],p[I,1])]*r[I][7][8,0]*r[J][48][2,0]*r[K][6][13,0]
                hv += -1/6*g[dei(p[J,1],p[J,0],p[K,1],p[I,1])]*r[I][7][8,0]*r[J][33][2,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[K,1],p[I,1],p[J,0],p[J,1])]*r[I][7][8,0]*r[J][30][2,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[K,1],p[I,1],p[J,1],p[J,0])]*r[I][7][8,0]*r[J][48][2,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[K,1],p[J,1],p[J,0],p[I,1])]*r[I][7][8,0]*r[J][30][2,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[K,1],p[J,0],p[J,1],p[I,1])]*r[I][7][8,0]*r[J][48][2,0]*r[K][6][13,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I8J3K13(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,8),(J,3),(K,13)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/12*g[dei(p[J,0],p[I,1],p[K,1],p[J,1])]*r[I][7][8,0]*r[J][30][3,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[J,1],p[I,1],p[K,1],p[J,0])]*r[I][7][8,0]*r[J][48][3,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[J,0],p[J,1],p[K,1],p[I,1])]*r[I][7][8,0]*r[J][30][3,0]*r[K][6][13,0]
                hv += -1/6*g[dei(p[J,0],p[J,1],p[K,1],p[I,1])]*r[I][7][8,0]*r[J][15][3,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[J,1],p[J,0],p[K,1],p[I,1])]*r[I][7][8,0]*r[J][48][3,0]*r[K][6][13,0]
                hv += -1/6*g[dei(p[J,1],p[J,0],p[K,1],p[I,1])]*r[I][7][8,0]*r[J][33][3,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[K,1],p[I,1],p[J,0],p[J,1])]*r[I][7][8,0]*r[J][30][3,0]*r[K][6][13,0]
                hv += -1/12*g[dei(p[K,1],p[I,1],p[J,1],p[J,0])]*r[I][7][8,0]*r[J][48][3,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[K,1],p[J,1],p[J,0],p[I,1])]*r[I][7][8,0]*r[J][30][3,0]*r[K][6][13,0]
                hv += 1/12*g[dei(p[K,1],p[J,0],p[J,1],p[I,1])]*r[I][7][8,0]*r[J][48][3,0]*r[K][6][13,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I10J4K13(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,10),(J,4),(K,13)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/6*g[dei(p[J,0],p[I,1],p[K,1],p[J,1])]*r[I][5][10,0]*r[J][18][4,0]*r[K][6][13,0]
                hv += 1/6*g[dei(p[J,1],p[I,1],p[K,1],p[J,0])]*r[I][5][10,0]*r[J][36][4,0]*r[K][6][13,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I9J12K1(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,9),(J,12),(K,1)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/12*g[dei(p[J,0],p[I,0],p[K,0],p[K,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][9][1,0]
                hv += -1/6*g[dei(p[J,0],p[I,0],p[K,0],p[K,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][24][1,0]
                hv += -1/12*g[dei(p[J,0],p[I,0],p[K,1],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][39][1,0]
                hv += -1/6*g[dei(p[J,0],p[I,0],p[K,1],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][54][1,0]
                hv += 1/12*g[dei(p[J,0],p[K,0],p[K,0],p[I,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][9][1,0]
                hv += 1/12*g[dei(p[J,0],p[K,1],p[K,1],p[I,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][39][1,0]
                hv += 1/12*g[dei(p[K,0],p[I,0],p[J,0],p[K,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][9][1,0]
                hv += 1/12*g[dei(p[K,1],p[I,0],p[J,0],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][39][1,0]
                hv += -1/12*g[dei(p[K,0],p[K,0],p[J,0],p[I,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][9][1,0]
                hv += -1/12*g[dei(p[K,1],p[K,1],p[J,0],p[I,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][39][1,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I7J14K1(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,7),(J,14),(K,1)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/12*g[dei(p[J,0],p[I,0],p[K,0],p[K,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][24][1,0]
                hv += -1/12*g[dei(p[J,0],p[I,0],p[K,1],p[K,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][54][1,0]
                hv += 1/12*g[dei(p[J,0],p[K,0],p[K,0],p[I,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][24][1,0]
                hv += 1/12*g[dei(p[J,0],p[K,1],p[K,1],p[I,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][54][1,0]
                hv += 1/12*g[dei(p[K,0],p[I,0],p[J,0],p[K,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][24][1,0]
                hv += 1/12*g[dei(p[K,1],p[I,0],p[J,0],p[K,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][54][1,0]
                hv += -1/12*g[dei(p[K,0],p[K,0],p[J,0],p[I,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][24][1,0]
                hv += -1/6*g[dei(p[K,0],p[K,0],p[J,0],p[I,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][9][1,0]
                hv += -1/12*g[dei(p[K,1],p[K,1],p[J,0],p[I,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][54][1,0]
                hv += -1/6*g[dei(p[K,1],p[K,1],p[J,0],p[I,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][39][1,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I9J12K2(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,9),(J,12),(K,2)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/12*g[dei(p[J,0],p[I,0],p[K,0],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][15][2,0]
                hv += -1/6*g[dei(p[J,0],p[I,0],p[K,0],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][30][2,0]
                hv += -1/12*g[dei(p[J,0],p[I,0],p[K,1],p[K,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][33][2,0]
                hv += -1/6*g[dei(p[J,0],p[I,0],p[K,1],p[K,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][48][2,0]
                hv += 1/12*g[dei(p[J,0],p[K,1],p[K,0],p[I,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][15][2,0]
                hv += 1/12*g[dei(p[J,0],p[K,0],p[K,1],p[I,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][33][2,0]
                hv += 1/12*g[dei(p[K,0],p[I,0],p[J,0],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][15][2,0]
                hv += 1/12*g[dei(p[K,1],p[I,0],p[J,0],p[K,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][33][2,0]
                hv += -1/12*g[dei(p[K,0],p[K,1],p[J,0],p[I,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][15][2,0]
                hv += -1/12*g[dei(p[K,1],p[K,0],p[J,0],p[I,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][33][2,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I9J12K3(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,9),(J,12),(K,3)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/12*g[dei(p[J,0],p[I,0],p[K,0],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][15][3,0]
                hv += -1/6*g[dei(p[J,0],p[I,0],p[K,0],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][30][3,0]
                hv += -1/12*g[dei(p[J,0],p[I,0],p[K,1],p[K,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][33][3,0]
                hv += -1/6*g[dei(p[J,0],p[I,0],p[K,1],p[K,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][48][3,0]
                hv += 1/12*g[dei(p[J,0],p[K,1],p[K,0],p[I,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][15][3,0]
                hv += 1/12*g[dei(p[J,0],p[K,0],p[K,1],p[I,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][33][3,0]
                hv += 1/12*g[dei(p[K,0],p[I,0],p[J,0],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][15][3,0]
                hv += 1/12*g[dei(p[K,1],p[I,0],p[J,0],p[K,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][33][3,0]
                hv += -1/12*g[dei(p[K,0],p[K,1],p[J,0],p[I,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][15][3,0]
                hv += -1/12*g[dei(p[K,1],p[K,0],p[J,0],p[I,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][33][3,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I7J14K2(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,7),(J,14),(K,2)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/12*g[dei(p[J,0],p[I,0],p[K,0],p[K,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][30][2,0]
                hv += -1/12*g[dei(p[J,0],p[I,0],p[K,1],p[K,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][48][2,0]
                hv += 1/12*g[dei(p[J,0],p[K,1],p[K,0],p[I,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][30][2,0]
                hv += 1/12*g[dei(p[J,0],p[K,0],p[K,1],p[I,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][48][2,0]
                hv += 1/12*g[dei(p[K,0],p[I,0],p[J,0],p[K,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][30][2,0]
                hv += 1/12*g[dei(p[K,1],p[I,0],p[J,0],p[K,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][48][2,0]
                hv += -1/12*g[dei(p[K,0],p[K,1],p[J,0],p[I,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][30][2,0]
                hv += -1/6*g[dei(p[K,0],p[K,1],p[J,0],p[I,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][15][2,0]
                hv += -1/12*g[dei(p[K,1],p[K,0],p[J,0],p[I,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][48][2,0]
                hv += -1/6*g[dei(p[K,1],p[K,0],p[J,0],p[I,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][33][2,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I7J14K3(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,7),(J,14),(K,3)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/12*g[dei(p[J,0],p[I,0],p[K,0],p[K,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][30][3,0]
                hv += -1/12*g[dei(p[J,0],p[I,0],p[K,1],p[K,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][48][3,0]
                hv += 1/12*g[dei(p[J,0],p[K,1],p[K,0],p[I,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][30][3,0]
                hv += 1/12*g[dei(p[J,0],p[K,0],p[K,1],p[I,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][48][3,0]
                hv += 1/12*g[dei(p[K,0],p[I,0],p[J,0],p[K,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][30][3,0]
                hv += 1/12*g[dei(p[K,1],p[I,0],p[J,0],p[K,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][48][3,0]
                hv += -1/12*g[dei(p[K,0],p[K,1],p[J,0],p[I,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][30][3,0]
                hv += -1/6*g[dei(p[K,0],p[K,1],p[J,0],p[I,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][15][3,0]
                hv += -1/12*g[dei(p[K,1],p[K,0],p[J,0],p[I,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][48][3,0]
                hv += -1/6*g[dei(p[K,1],p[K,0],p[J,0],p[I,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][33][3,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I10J12K1(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,10),(J,12),(K,1)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/12*g[dei(p[J,0],p[I,1],p[K,0],p[K,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][9][1,0]
                hv += -1/6*g[dei(p[J,0],p[I,1],p[K,0],p[K,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][24][1,0]
                hv += -1/12*g[dei(p[J,0],p[I,1],p[K,1],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][39][1,0]
                hv += -1/6*g[dei(p[J,0],p[I,1],p[K,1],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][54][1,0]
                hv += 1/12*g[dei(p[J,0],p[K,0],p[K,0],p[I,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][9][1,0]
                hv += 1/12*g[dei(p[J,0],p[K,1],p[K,1],p[I,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][39][1,0]
                hv += 1/12*g[dei(p[K,0],p[I,1],p[J,0],p[K,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][9][1,0]
                hv += 1/12*g[dei(p[K,1],p[I,1],p[J,0],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][39][1,0]
                hv += -1/12*g[dei(p[K,0],p[K,0],p[J,0],p[I,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][9][1,0]
                hv += -1/12*g[dei(p[K,1],p[K,1],p[J,0],p[I,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][39][1,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I8J14K1(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,8),(J,14),(K,1)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/12*g[dei(p[J,0],p[I,1],p[K,0],p[K,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][24][1,0]
                hv += -1/12*g[dei(p[J,0],p[I,1],p[K,1],p[K,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][54][1,0]
                hv += 1/12*g[dei(p[J,0],p[K,0],p[K,0],p[I,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][24][1,0]
                hv += 1/12*g[dei(p[J,0],p[K,1],p[K,1],p[I,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][54][1,0]
                hv += 1/12*g[dei(p[K,0],p[I,1],p[J,0],p[K,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][24][1,0]
                hv += 1/12*g[dei(p[K,1],p[I,1],p[J,0],p[K,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][54][1,0]
                hv += -1/12*g[dei(p[K,0],p[K,0],p[J,0],p[I,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][24][1,0]
                hv += -1/6*g[dei(p[K,0],p[K,0],p[J,0],p[I,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][9][1,0]
                hv += -1/12*g[dei(p[K,1],p[K,1],p[J,0],p[I,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][54][1,0]
                hv += -1/6*g[dei(p[K,1],p[K,1],p[J,0],p[I,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][39][1,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I10J12K2(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,10),(J,12),(K,2)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/12*g[dei(p[J,0],p[I,1],p[K,0],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][15][2,0]
                hv += -1/6*g[dei(p[J,0],p[I,1],p[K,0],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][30][2,0]
                hv += -1/12*g[dei(p[J,0],p[I,1],p[K,1],p[K,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][33][2,0]
                hv += -1/6*g[dei(p[J,0],p[I,1],p[K,1],p[K,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][48][2,0]
                hv += 1/12*g[dei(p[J,0],p[K,1],p[K,0],p[I,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][15][2,0]
                hv += 1/12*g[dei(p[J,0],p[K,0],p[K,1],p[I,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][33][2,0]
                hv += 1/12*g[dei(p[K,0],p[I,1],p[J,0],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][15][2,0]
                hv += 1/12*g[dei(p[K,1],p[I,1],p[J,0],p[K,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][33][2,0]
                hv += -1/12*g[dei(p[K,0],p[K,1],p[J,0],p[I,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][15][2,0]
                hv += -1/12*g[dei(p[K,1],p[K,0],p[J,0],p[I,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][33][2,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I10J12K3(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,10),(J,12),(K,3)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/12*g[dei(p[J,0],p[I,1],p[K,0],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][15][3,0]
                hv += -1/6*g[dei(p[J,0],p[I,1],p[K,0],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][30][3,0]
                hv += -1/12*g[dei(p[J,0],p[I,1],p[K,1],p[K,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][33][3,0]
                hv += -1/6*g[dei(p[J,0],p[I,1],p[K,1],p[K,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][48][3,0]
                hv += 1/12*g[dei(p[J,0],p[K,1],p[K,0],p[I,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][15][3,0]
                hv += 1/12*g[dei(p[J,0],p[K,0],p[K,1],p[I,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][33][3,0]
                hv += 1/12*g[dei(p[K,0],p[I,1],p[J,0],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][15][3,0]
                hv += 1/12*g[dei(p[K,1],p[I,1],p[J,0],p[K,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][33][3,0]
                hv += -1/12*g[dei(p[K,0],p[K,1],p[J,0],p[I,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][15][3,0]
                hv += -1/12*g[dei(p[K,1],p[K,0],p[J,0],p[I,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][33][3,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I8J14K2(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,8),(J,14),(K,2)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/12*g[dei(p[J,0],p[I,1],p[K,0],p[K,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][30][2,0]
                hv += -1/12*g[dei(p[J,0],p[I,1],p[K,1],p[K,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][48][2,0]
                hv += 1/12*g[dei(p[J,0],p[K,1],p[K,0],p[I,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][30][2,0]
                hv += 1/12*g[dei(p[J,0],p[K,0],p[K,1],p[I,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][48][2,0]
                hv += 1/12*g[dei(p[K,0],p[I,1],p[J,0],p[K,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][30][2,0]
                hv += 1/12*g[dei(p[K,1],p[I,1],p[J,0],p[K,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][48][2,0]
                hv += -1/12*g[dei(p[K,0],p[K,1],p[J,0],p[I,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][30][2,0]
                hv += -1/6*g[dei(p[K,0],p[K,1],p[J,0],p[I,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][15][2,0]
                hv += -1/12*g[dei(p[K,1],p[K,0],p[J,0],p[I,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][48][2,0]
                hv += -1/6*g[dei(p[K,1],p[K,0],p[J,0],p[I,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][33][2,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I8J14K3(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,8),(J,14),(K,3)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/12*g[dei(p[J,0],p[I,1],p[K,0],p[K,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][30][3,0]
                hv += -1/12*g[dei(p[J,0],p[I,1],p[K,1],p[K,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][48][3,0]
                hv += 1/12*g[dei(p[J,0],p[K,1],p[K,0],p[I,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][30][3,0]
                hv += 1/12*g[dei(p[J,0],p[K,0],p[K,1],p[I,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][48][3,0]
                hv += 1/12*g[dei(p[K,0],p[I,1],p[J,0],p[K,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][30][3,0]
                hv += 1/12*g[dei(p[K,1],p[I,1],p[J,0],p[K,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][48][3,0]
                hv += -1/12*g[dei(p[K,0],p[K,1],p[J,0],p[I,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][30][3,0]
                hv += -1/6*g[dei(p[K,0],p[K,1],p[J,0],p[I,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][15][3,0]
                hv += -1/12*g[dei(p[K,1],p[K,0],p[J,0],p[I,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][48][3,0]
                hv += -1/6*g[dei(p[K,1],p[K,0],p[J,0],p[I,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][33][3,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I9J11K1(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,9),(J,11),(K,1)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/12*g[dei(p[J,1],p[I,0],p[K,0],p[K,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][9][1,0]
                hv += -1/6*g[dei(p[J,1],p[I,0],p[K,0],p[K,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][24][1,0]
                hv += -1/12*g[dei(p[J,1],p[I,0],p[K,1],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][39][1,0]
                hv += -1/6*g[dei(p[J,1],p[I,0],p[K,1],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][54][1,0]
                hv += 1/12*g[dei(p[J,1],p[K,0],p[K,0],p[I,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][9][1,0]
                hv += 1/12*g[dei(p[J,1],p[K,1],p[K,1],p[I,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][39][1,0]
                hv += 1/12*g[dei(p[K,0],p[I,0],p[J,1],p[K,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][9][1,0]
                hv += 1/12*g[dei(p[K,1],p[I,0],p[J,1],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][39][1,0]
                hv += -1/12*g[dei(p[K,0],p[K,0],p[J,1],p[I,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][9][1,0]
                hv += -1/12*g[dei(p[K,1],p[K,1],p[J,1],p[I,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][39][1,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I7J13K1(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,7),(J,13),(K,1)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/12*g[dei(p[J,1],p[I,0],p[K,0],p[K,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][24][1,0]
                hv += -1/12*g[dei(p[J,1],p[I,0],p[K,1],p[K,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][54][1,0]
                hv += 1/12*g[dei(p[J,1],p[K,0],p[K,0],p[I,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][24][1,0]
                hv += 1/12*g[dei(p[J,1],p[K,1],p[K,1],p[I,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][54][1,0]
                hv += 1/12*g[dei(p[K,0],p[I,0],p[J,1],p[K,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][24][1,0]
                hv += 1/12*g[dei(p[K,1],p[I,0],p[J,1],p[K,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][54][1,0]
                hv += -1/12*g[dei(p[K,0],p[K,0],p[J,1],p[I,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][24][1,0]
                hv += -1/6*g[dei(p[K,0],p[K,0],p[J,1],p[I,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][9][1,0]
                hv += -1/12*g[dei(p[K,1],p[K,1],p[J,1],p[I,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][54][1,0]
                hv += -1/6*g[dei(p[K,1],p[K,1],p[J,1],p[I,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][39][1,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I9J11K2(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,9),(J,11),(K,2)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/12*g[dei(p[J,1],p[I,0],p[K,0],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][15][2,0]
                hv += -1/6*g[dei(p[J,1],p[I,0],p[K,0],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][30][2,0]
                hv += -1/12*g[dei(p[J,1],p[I,0],p[K,1],p[K,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][33][2,0]
                hv += -1/6*g[dei(p[J,1],p[I,0],p[K,1],p[K,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][48][2,0]
                hv += 1/12*g[dei(p[J,1],p[K,1],p[K,0],p[I,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][15][2,0]
                hv += 1/12*g[dei(p[J,1],p[K,0],p[K,1],p[I,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][33][2,0]
                hv += 1/12*g[dei(p[K,0],p[I,0],p[J,1],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][15][2,0]
                hv += 1/12*g[dei(p[K,1],p[I,0],p[J,1],p[K,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][33][2,0]
                hv += -1/12*g[dei(p[K,0],p[K,1],p[J,1],p[I,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][15][2,0]
                hv += -1/12*g[dei(p[K,1],p[K,0],p[J,1],p[I,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][33][2,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I9J11K3(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,9),(J,11),(K,3)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/12*g[dei(p[J,1],p[I,0],p[K,0],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][15][3,0]
                hv += -1/6*g[dei(p[J,1],p[I,0],p[K,0],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][30][3,0]
                hv += -1/12*g[dei(p[J,1],p[I,0],p[K,1],p[K,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][33][3,0]
                hv += -1/6*g[dei(p[J,1],p[I,0],p[K,1],p[K,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][48][3,0]
                hv += 1/12*g[dei(p[J,1],p[K,1],p[K,0],p[I,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][15][3,0]
                hv += 1/12*g[dei(p[J,1],p[K,0],p[K,1],p[I,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][33][3,0]
                hv += 1/12*g[dei(p[K,0],p[I,0],p[J,1],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][15][3,0]
                hv += 1/12*g[dei(p[K,1],p[I,0],p[J,1],p[K,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][33][3,0]
                hv += -1/12*g[dei(p[K,0],p[K,1],p[J,1],p[I,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][15][3,0]
                hv += -1/12*g[dei(p[K,1],p[K,0],p[J,1],p[I,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][33][3,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I7J13K2(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,7),(J,13),(K,2)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/12*g[dei(p[J,1],p[I,0],p[K,0],p[K,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][30][2,0]
                hv += -1/12*g[dei(p[J,1],p[I,0],p[K,1],p[K,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][48][2,0]
                hv += 1/12*g[dei(p[J,1],p[K,1],p[K,0],p[I,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][30][2,0]
                hv += 1/12*g[dei(p[J,1],p[K,0],p[K,1],p[I,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][48][2,0]
                hv += 1/12*g[dei(p[K,0],p[I,0],p[J,1],p[K,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][30][2,0]
                hv += 1/12*g[dei(p[K,1],p[I,0],p[J,1],p[K,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][48][2,0]
                hv += -1/12*g[dei(p[K,0],p[K,1],p[J,1],p[I,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][30][2,0]
                hv += -1/6*g[dei(p[K,0],p[K,1],p[J,1],p[I,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][15][2,0]
                hv += -1/12*g[dei(p[K,1],p[K,0],p[J,1],p[I,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][48][2,0]
                hv += -1/6*g[dei(p[K,1],p[K,0],p[J,1],p[I,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][33][2,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I7J13K3(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,7),(J,13),(K,3)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/12*g[dei(p[J,1],p[I,0],p[K,0],p[K,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][30][3,0]
                hv += -1/12*g[dei(p[J,1],p[I,0],p[K,1],p[K,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][48][3,0]
                hv += 1/12*g[dei(p[J,1],p[K,1],p[K,0],p[I,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][30][3,0]
                hv += 1/12*g[dei(p[J,1],p[K,0],p[K,1],p[I,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][48][3,0]
                hv += 1/12*g[dei(p[K,0],p[I,0],p[J,1],p[K,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][30][3,0]
                hv += 1/12*g[dei(p[K,1],p[I,0],p[J,1],p[K,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][48][3,0]
                hv += -1/12*g[dei(p[K,0],p[K,1],p[J,1],p[I,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][30][3,0]
                hv += -1/6*g[dei(p[K,0],p[K,1],p[J,1],p[I,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][15][3,0]
                hv += -1/12*g[dei(p[K,1],p[K,0],p[J,1],p[I,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][48][3,0]
                hv += -1/6*g[dei(p[K,1],p[K,0],p[J,1],p[I,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][33][3,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I10J11K1(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,10),(J,11),(K,1)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/12*g[dei(p[J,1],p[I,1],p[K,0],p[K,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][9][1,0]
                hv += -1/6*g[dei(p[J,1],p[I,1],p[K,0],p[K,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][24][1,0]
                hv += -1/12*g[dei(p[J,1],p[I,1],p[K,1],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][39][1,0]
                hv += -1/6*g[dei(p[J,1],p[I,1],p[K,1],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][54][1,0]
                hv += 1/12*g[dei(p[J,1],p[K,0],p[K,0],p[I,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][9][1,0]
                hv += 1/12*g[dei(p[J,1],p[K,1],p[K,1],p[I,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][39][1,0]
                hv += 1/12*g[dei(p[K,0],p[I,1],p[J,1],p[K,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][9][1,0]
                hv += 1/12*g[dei(p[K,1],p[I,1],p[J,1],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][39][1,0]
                hv += -1/12*g[dei(p[K,0],p[K,0],p[J,1],p[I,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][9][1,0]
                hv += -1/12*g[dei(p[K,1],p[K,1],p[J,1],p[I,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][39][1,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I8J13K1(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,8),(J,13),(K,1)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/12*g[dei(p[J,1],p[I,1],p[K,0],p[K,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][24][1,0]
                hv += -1/12*g[dei(p[J,1],p[I,1],p[K,1],p[K,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][54][1,0]
                hv += 1/12*g[dei(p[J,1],p[K,0],p[K,0],p[I,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][24][1,0]
                hv += 1/12*g[dei(p[J,1],p[K,1],p[K,1],p[I,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][54][1,0]
                hv += 1/12*g[dei(p[K,0],p[I,1],p[J,1],p[K,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][24][1,0]
                hv += 1/12*g[dei(p[K,1],p[I,1],p[J,1],p[K,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][54][1,0]
                hv += -1/12*g[dei(p[K,0],p[K,0],p[J,1],p[I,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][24][1,0]
                hv += -1/6*g[dei(p[K,0],p[K,0],p[J,1],p[I,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][9][1,0]
                hv += -1/12*g[dei(p[K,1],p[K,1],p[J,1],p[I,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][54][1,0]
                hv += -1/6*g[dei(p[K,1],p[K,1],p[J,1],p[I,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][39][1,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I10J11K2(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,10),(J,11),(K,2)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/12*g[dei(p[J,1],p[I,1],p[K,0],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][15][2,0]
                hv += -1/6*g[dei(p[J,1],p[I,1],p[K,0],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][30][2,0]
                hv += -1/12*g[dei(p[J,1],p[I,1],p[K,1],p[K,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][33][2,0]
                hv += -1/6*g[dei(p[J,1],p[I,1],p[K,1],p[K,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][48][2,0]
                hv += 1/12*g[dei(p[J,1],p[K,1],p[K,0],p[I,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][15][2,0]
                hv += 1/12*g[dei(p[J,1],p[K,0],p[K,1],p[I,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][33][2,0]
                hv += 1/12*g[dei(p[K,0],p[I,1],p[J,1],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][15][2,0]
                hv += 1/12*g[dei(p[K,1],p[I,1],p[J,1],p[K,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][33][2,0]
                hv += -1/12*g[dei(p[K,0],p[K,1],p[J,1],p[I,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][15][2,0]
                hv += -1/12*g[dei(p[K,1],p[K,0],p[J,1],p[I,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][33][2,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I10J11K3(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,10),(J,11),(K,3)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/12*g[dei(p[J,1],p[I,1],p[K,0],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][15][3,0]
                hv += -1/6*g[dei(p[J,1],p[I,1],p[K,0],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][30][3,0]
                hv += -1/12*g[dei(p[J,1],p[I,1],p[K,1],p[K,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][33][3,0]
                hv += -1/6*g[dei(p[J,1],p[I,1],p[K,1],p[K,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][48][3,0]
                hv += 1/12*g[dei(p[J,1],p[K,1],p[K,0],p[I,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][15][3,0]
                hv += 1/12*g[dei(p[J,1],p[K,0],p[K,1],p[I,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][33][3,0]
                hv += 1/12*g[dei(p[K,0],p[I,1],p[J,1],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][15][3,0]
                hv += 1/12*g[dei(p[K,1],p[I,1],p[J,1],p[K,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][33][3,0]
                hv += -1/12*g[dei(p[K,0],p[K,1],p[J,1],p[I,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][15][3,0]
                hv += -1/12*g[dei(p[K,1],p[K,0],p[J,1],p[I,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][33][3,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I8J13K2(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,8),(J,13),(K,2)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/12*g[dei(p[J,1],p[I,1],p[K,0],p[K,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][30][2,0]
                hv += -1/12*g[dei(p[J,1],p[I,1],p[K,1],p[K,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][48][2,0]
                hv += 1/12*g[dei(p[J,1],p[K,1],p[K,0],p[I,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][30][2,0]
                hv += 1/12*g[dei(p[J,1],p[K,0],p[K,1],p[I,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][48][2,0]
                hv += 1/12*g[dei(p[K,0],p[I,1],p[J,1],p[K,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][30][2,0]
                hv += 1/12*g[dei(p[K,1],p[I,1],p[J,1],p[K,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][48][2,0]
                hv += -1/12*g[dei(p[K,0],p[K,1],p[J,1],p[I,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][30][2,0]
                hv += -1/6*g[dei(p[K,0],p[K,1],p[J,1],p[I,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][15][2,0]
                hv += -1/12*g[dei(p[K,1],p[K,0],p[J,1],p[I,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][48][2,0]
                hv += -1/6*g[dei(p[K,1],p[K,0],p[J,1],p[I,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][33][2,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I8J13K3(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,8),(J,13),(K,3)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/12*g[dei(p[J,1],p[I,1],p[K,0],p[K,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][30][3,0]
                hv += -1/12*g[dei(p[J,1],p[I,1],p[K,1],p[K,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][48][3,0]
                hv += 1/12*g[dei(p[J,1],p[K,1],p[K,0],p[I,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][30][3,0]
                hv += 1/12*g[dei(p[J,1],p[K,0],p[K,1],p[I,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][48][3,0]
                hv += 1/12*g[dei(p[K,0],p[I,1],p[J,1],p[K,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][30][3,0]
                hv += 1/12*g[dei(p[K,1],p[I,1],p[J,1],p[K,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][48][3,0]
                hv += -1/12*g[dei(p[K,0],p[K,1],p[J,1],p[I,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][30][3,0]
                hv += -1/6*g[dei(p[K,0],p[K,1],p[J,1],p[I,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][15][3,0]
                hv += -1/12*g[dei(p[K,1],p[K,0],p[J,1],p[I,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][48][3,0]
                hv += -1/6*g[dei(p[K,1],p[K,0],p[J,1],p[I,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][33][3,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I7J12K5(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,7),(J,12),(K,5)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/6*g[dei(p[J,0],p[K,1],p[K,0],p[I,0])]*r[I][3][7,0]*r[J][0][12,0]*r[K][27][5,0]
                hv += 1/6*g[dei(p[J,0],p[K,0],p[K,1],p[I,0])]*r[I][3][7,0]*r[J][0][12,0]*r[K][45][5,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I8J12K5(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,8),(J,12),(K,5)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/6*g[dei(p[J,0],p[K,1],p[K,0],p[I,1])]*r[I][7][8,0]*r[J][0][12,0]*r[K][27][5,0]
                hv += 1/6*g[dei(p[J,0],p[K,0],p[K,1],p[I,1])]*r[I][7][8,0]*r[J][0][12,0]*r[K][45][5,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I7J11K5(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,7),(J,11),(K,5)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/6*g[dei(p[J,1],p[K,1],p[K,0],p[I,0])]*r[I][3][7,0]*r[J][4][11,0]*r[K][27][5,0]
                hv += 1/6*g[dei(p[J,1],p[K,0],p[K,1],p[I,0])]*r[I][3][7,0]*r[J][4][11,0]*r[K][45][5,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I8J11K5(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,8),(J,11),(K,5)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/6*g[dei(p[J,1],p[K,1],p[K,0],p[I,1])]*r[I][7][8,0]*r[J][4][11,0]*r[K][27][5,0]
                hv += 1/6*g[dei(p[J,1],p[K,0],p[K,1],p[I,1])]*r[I][7][8,0]*r[J][4][11,0]*r[K][45][5,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I5J7K12(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,5),(J,7),(K,12)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/6*g[dei(p[K,0],p[I,1],p[I,0],p[J,0])]*r[I][27][5,0]*r[J][3][7,0]*r[K][0][12,0]
                hv += 1/6*g[dei(p[K,0],p[I,0],p[I,1],p[J,0])]*r[I][45][5,0]*r[J][3][7,0]*r[K][0][12,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I5J8K12(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,5),(J,8),(K,12)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/6*g[dei(p[K,0],p[I,1],p[I,0],p[J,1])]*r[I][27][5,0]*r[J][7][8,0]*r[K][0][12,0]
                hv += 1/6*g[dei(p[K,0],p[I,0],p[I,1],p[J,1])]*r[I][45][5,0]*r[J][7][8,0]*r[K][0][12,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I5J7K11(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,5),(J,7),(K,11)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/6*g[dei(p[K,1],p[I,1],p[I,0],p[J,0])]*r[I][27][5,0]*r[J][3][7,0]*r[K][4][11,0]
                hv += 1/6*g[dei(p[K,1],p[I,0],p[I,1],p[J,0])]*r[I][45][5,0]*r[J][3][7,0]*r[K][4][11,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I5J8K11(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,5),(J,8),(K,11)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += 1/6*g[dei(p[K,1],p[I,1],p[I,0],p[J,1])]*r[I][27][5,0]*r[J][7][8,0]*r[K][4][11,0]
                hv += 1/6*g[dei(p[K,1],p[I,0],p[I,1],p[J,1])]*r[I][45][5,0]*r[J][7][8,0]*r[K][4][11,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I14J6K12(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,14),(J,6),(K,12)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/6*g[dei(p[K,0],p[J,0],p[I,0],p[J,0])]*r[I][2][14,0]*r[J][22][6,0]*r[K][0][12,0]
                hv += -1/6*g[dei(p[K,0],p[J,1],p[I,0],p[J,1])]*r[I][2][14,0]*r[J][52][6,0]*r[K][0][12,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I13J6K12(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,13),(J,6),(K,12)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/6*g[dei(p[K,0],p[J,0],p[I,1],p[J,0])]*r[I][6][13,0]*r[J][22][6,0]*r[K][0][12,0]
                hv += -1/6*g[dei(p[K,0],p[J,1],p[I,1],p[J,1])]*r[I][6][13,0]*r[J][52][6,0]*r[K][0][12,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I14J6K11(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,14),(J,6),(K,11)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/6*g[dei(p[K,1],p[J,0],p[I,0],p[J,0])]*r[I][2][14,0]*r[J][22][6,0]*r[K][4][11,0]
                hv += -1/6*g[dei(p[K,1],p[J,1],p[I,0],p[J,1])]*r[I][2][14,0]*r[J][52][6,0]*r[K][4][11,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I13J6K11(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,13),(J,6),(K,11)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += -1/6*g[dei(p[K,1],p[J,0],p[I,1],p[J,0])]*r[I][6][13,0]*r[J][22][6,0]*r[K][4][11,0]
                hv += -1/6*g[dei(p[K,1],p[J,1],p[I,1],p[J,1])]*r[I][6][13,0]*r[J][52][6,0]*r[K][4][11,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I14J9K4(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,14),(J,9),(K,4)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/6*g[dei(p[K,0],p[J,0],p[I,0],p[K,1])]*r[I][2][14,0]*r[J][1][9,0]*r[K][18][4,0]
                hv += -1/6*g[dei(p[K,1],p[J,0],p[I,0],p[K,0])]*r[I][2][14,0]*r[J][1][9,0]*r[K][36][4,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I14J10K4(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,14),(J,10),(K,4)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/6*g[dei(p[K,0],p[J,1],p[I,0],p[K,1])]*r[I][2][14,0]*r[J][5][10,0]*r[K][18][4,0]
                hv += -1/6*g[dei(p[K,1],p[J,1],p[I,0],p[K,0])]*r[I][2][14,0]*r[J][5][10,0]*r[K][36][4,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I13J9K4(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,13),(J,9),(K,4)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/6*g[dei(p[K,0],p[J,0],p[I,1],p[K,1])]*r[I][6][13,0]*r[J][1][9,0]*r[K][18][4,0]
                hv += -1/6*g[dei(p[K,1],p[J,0],p[I,1],p[K,0])]*r[I][6][13,0]*r[J][1][9,0]*r[K][36][4,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I13J10K4(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,13),(J,10),(K,4)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/6*g[dei(p[K,0],p[J,1],p[I,1],p[K,1])]*r[I][6][13,0]*r[J][5][10,0]*r[K][18][4,0]
                hv += -1/6*g[dei(p[K,1],p[J,1],p[I,1],p[K,0])]*r[I][6][13,0]*r[J][5][10,0]*r[K][36][4,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I6J14K12(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,6),(J,14),(K,12)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/6*g[dei(p[K,0],p[I,0],p[J,0],p[I,0])]*r[I][22][6,0]*r[J][2][14,0]*r[K][0][12,0]
                hv += -1/6*g[dei(p[K,0],p[I,1],p[J,0],p[I,1])]*r[I][52][6,0]*r[J][2][14,0]*r[K][0][12,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I6J13K12(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,6),(J,13),(K,12)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/6*g[dei(p[K,0],p[I,0],p[J,1],p[I,0])]*r[I][22][6,0]*r[J][6][13,0]*r[K][0][12,0]
                hv += -1/6*g[dei(p[K,0],p[I,1],p[J,1],p[I,1])]*r[I][52][6,0]*r[J][6][13,0]*r[K][0][12,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I6J14K11(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,6),(J,14),(K,11)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/6*g[dei(p[K,1],p[I,0],p[J,0],p[I,0])]*r[I][22][6,0]*r[J][2][14,0]*r[K][4][11,0]
                hv += -1/6*g[dei(p[K,1],p[I,1],p[J,0],p[I,1])]*r[I][52][6,0]*r[J][2][14,0]*r[K][4][11,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I6J13K11(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,6),(J,13),(K,11)]))
                hv = 0.0
                sket = sign([J,K])
                
                hv += -1/6*g[dei(p[K,1],p[I,0],p[J,1],p[I,0])]*r[I][22][6,0]*r[J][6][13,0]*r[K][4][11,0]
                hv += -1/6*g[dei(p[K,1],p[I,1],p[J,1],p[I,1])]*r[I][52][6,0]*r[J][6][13,0]*r[K][4][11,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I9J14K4(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,9),(J,14),(K,4)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/6*g[dei(p[K,0],p[I,0],p[J,0],p[K,1])]*r[I][1][9,0]*r[J][2][14,0]*r[K][18][4,0]
                hv += 1/6*g[dei(p[K,1],p[I,0],p[J,0],p[K,0])]*r[I][1][9,0]*r[J][2][14,0]*r[K][36][4,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I10J14K4(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,10),(J,14),(K,4)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/6*g[dei(p[K,0],p[I,1],p[J,0],p[K,1])]*r[I][5][10,0]*r[J][2][14,0]*r[K][18][4,0]
                hv += 1/6*g[dei(p[K,1],p[I,1],p[J,0],p[K,0])]*r[I][5][10,0]*r[J][2][14,0]*r[K][36][4,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I9J13K4(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,9),(J,13),(K,4)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/6*g[dei(p[K,0],p[I,0],p[J,1],p[K,1])]*r[I][1][9,0]*r[J][6][13,0]*r[K][18][4,0]
                hv += 1/6*g[dei(p[K,1],p[I,0],p[J,1],p[K,0])]*r[I][1][9,0]*r[J][6][13,0]*r[K][36][4,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I10J13K4(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,10),(J,13),(K,4)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/6*g[dei(p[K,0],p[I,1],p[J,1],p[K,1])]*r[I][5][10,0]*r[J][6][13,0]*r[K][18][4,0]
                hv += 1/6*g[dei(p[K,1],p[I,1],p[J,1],p[K,0])]*r[I][5][10,0]*r[J][6][13,0]*r[K][36][4,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I7J5K12(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,7),(J,5),(K,12)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/6*g[dei(p[K,0],p[J,1],p[J,0],p[I,0])]*r[I][3][7,0]*r[J][27][5,0]*r[K][0][12,0]
                hv += 1/6*g[dei(p[K,0],p[J,0],p[J,1],p[I,0])]*r[I][3][7,0]*r[J][45][5,0]*r[K][0][12,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I8J5K12(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,8),(J,5),(K,12)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/6*g[dei(p[K,0],p[J,1],p[J,0],p[I,1])]*r[I][7][8,0]*r[J][27][5,0]*r[K][0][12,0]
                hv += 1/6*g[dei(p[K,0],p[J,0],p[J,1],p[I,1])]*r[I][7][8,0]*r[J][45][5,0]*r[K][0][12,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I7J5K11(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,7),(J,5),(K,11)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/6*g[dei(p[K,1],p[J,1],p[J,0],p[I,0])]*r[I][3][7,0]*r[J][27][5,0]*r[K][4][11,0]
                hv += 1/6*g[dei(p[K,1],p[J,0],p[J,1],p[I,0])]*r[I][3][7,0]*r[J][45][5,0]*r[K][4][11,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I8J5K11(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,8),(J,5),(K,11)]))
                hv = 0.0
                sket = sign([I,K])
                
                hv += 1/6*g[dei(p[K,1],p[J,1],p[J,0],p[I,1])]*r[I][7][8,0]*r[J][27][5,0]*r[K][4][11,0]
                hv += 1/6*g[dei(p[K,1],p[J,0],p[J,1],p[I,1])]*r[I][7][8,0]*r[J][45][5,0]*r[K][4][11,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I9J7K15(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,9),(J,7),(K,15)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/6*g[dei(p[K,0],p[I,0],p[K,0],p[J,0])]*r[I][1][9,0]*r[J][3][7,0]*r[K][11][15,0]
                hv += -1/6*g[dei(p[K,1],p[I,0],p[K,1],p[J,0])]*r[I][1][9,0]*r[J][3][7,0]*r[K][41][15,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I9J8K15(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,9),(J,8),(K,15)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/6*g[dei(p[K,0],p[I,0],p[K,0],p[J,1])]*r[I][1][9,0]*r[J][7][8,0]*r[K][11][15,0]
                hv += -1/6*g[dei(p[K,1],p[I,0],p[K,1],p[J,1])]*r[I][1][9,0]*r[J][7][8,0]*r[K][41][15,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I10J7K15(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,10),(J,7),(K,15)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/6*g[dei(p[K,0],p[I,1],p[K,0],p[J,0])]*r[I][5][10,0]*r[J][3][7,0]*r[K][11][15,0]
                hv += -1/6*g[dei(p[K,1],p[I,1],p[K,1],p[J,0])]*r[I][5][10,0]*r[J][3][7,0]*r[K][41][15,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I10J8K15(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,10),(J,8),(K,15)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += -1/6*g[dei(p[K,0],p[I,1],p[K,0],p[J,1])]*r[I][5][10,0]*r[J][7][8,0]*r[K][11][15,0]
                hv += -1/6*g[dei(p[K,1],p[I,1],p[K,1],p[J,1])]*r[I][5][10,0]*r[J][7][8,0]*r[K][41][15,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I7J9K15(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,7),(J,9),(K,15)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/6*g[dei(p[K,0],p[J,0],p[K,0],p[I,0])]*r[I][3][7,0]*r[J][1][9,0]*r[K][11][15,0]
                hv += 1/6*g[dei(p[K,1],p[J,0],p[K,1],p[I,0])]*r[I][3][7,0]*r[J][1][9,0]*r[K][41][15,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I8J9K15(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,8),(J,9),(K,15)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/6*g[dei(p[K,0],p[J,0],p[K,0],p[I,1])]*r[I][7][8,0]*r[J][1][9,0]*r[K][11][15,0]
                hv += 1/6*g[dei(p[K,1],p[J,0],p[K,1],p[I,1])]*r[I][7][8,0]*r[J][1][9,0]*r[K][41][15,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I7J10K15(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,7),(J,10),(K,15)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/6*g[dei(p[K,0],p[J,1],p[K,0],p[I,0])]*r[I][3][7,0]*r[J][5][10,0]*r[K][11][15,0]
                hv += 1/6*g[dei(p[K,1],p[J,1],p[K,1],p[I,0])]*r[I][3][7,0]*r[J][5][10,0]*r[K][41][15,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def _I8J10K15(r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        for J in range(nc, np):
            if J in {I}: continue
            for K in range(nc, np):
                if K in {I,J}: continue
                v = tuple(sorted([(I,8),(J,10),(K,15)]))
                hv = 0.0
                sket = sign([I,J])
                
                hv += 1/6*g[dei(p[K,0],p[J,1],p[K,0],p[I,1])]*r[I][7][8,0]*r[J][5][10,0]*r[K][11][15,0]
                hv += 1/6*g[dei(p[K,1],p[J,1],p[K,1],p[I,1])]*r[I][7][8,0]*r[J][5][10,0]*r[K][41][15,0]
                
                hd[v] = hd.get(v,0.0)+sket*hv
                
    return hd
    
def hm_(r, h, g, p, nc=0):
    np=len(p)
    hdd = {}
    
    u = tuple(sorted([]))
    
    hd = {}
    for v,hv in _(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I1(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I2(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I3(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I12J9(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I14J7(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I12J10(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I14J8(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I11J9(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I13J7(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I11J10(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I13J8(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I9J12(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I7J14(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I10J12(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I8J14(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I9J11(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I7J13(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I10J11(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I8J13(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I15J6(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I1J1(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I1J2(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I1J3(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I2J1(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I3J1(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I2J2(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I2J3(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I3J2(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I3J3(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I4J5(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I5J4(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I6J15(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I15J9K7(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I15J9K8(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I15J10K7(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I15J10K8(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I15J7K9(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I15J8K9(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I15J7K10(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I15J8K10(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I1J12K9(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I1J14K7(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I1J12K10(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I1J14K8(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I2J12K9(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I3J12K9(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I2J14K7(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I3J14K7(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I2J12K10(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I3J12K10(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I2J14K8(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I3J14K8(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I1J11K9(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I1J13K7(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I1J11K10(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I1J13K8(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I2J11K9(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I3J11K9(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I2J13K7(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I3J13K7(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I2J11K10(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I3J11K10(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I2J13K8(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I3J13K8(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I12J1K9(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I14J1K7(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I12J1K10(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I14J1K8(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I12J2K9(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I12J3K9(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I14J2K7(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I14J3K7(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I12J5K7(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I12J2K10(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I12J3K10(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I14J2K8(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I14J3K8(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I12J5K8(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I11J1K9(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I13J1K7(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I11J1K10(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I13J1K8(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I11J2K9(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I11J3K9(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I13J2K7(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I13J3K7(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I11J5K7(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I11J2K10(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I11J3K10(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I13J2K8(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I13J3K8(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I11J5K8(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I4J14K9(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I4J14K10(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I4J13K9(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I4J13K10(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I12J14K6(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I12J13K6(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I11J14K6(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I11J13K6(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I1J9K12(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I1J7K14(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I1J10K12(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I1J8K14(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I2J9K12(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I3J9K12(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I2J7K14(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I3J7K14(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I2J10K12(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I3J10K12(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I2J8K14(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I3J8K14(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I1J9K11(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I1J7K13(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I1J10K11(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I1J8K13(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I2J9K11(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I3J9K11(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I2J7K13(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I3J7K13(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I2J10K11(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I3J10K11(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I2J8K13(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I3J8K13(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I4J9K14(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I4J10K14(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I4J9K13(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I4J10K13(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I12J6K14(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I12J6K13(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I11J6K14(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I11J6K13(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I12J9K1(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I14J7K1(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I12J9K2(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I12J9K3(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I14J7K2(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I14J7K3(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I12J10K1(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I14J8K1(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I12J10K2(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I12J10K3(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I14J8K2(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I14J8K3(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I11J9K1(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I13J7K1(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I11J9K2(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I11J9K3(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I13J7K2(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I13J7K3(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I11J10K1(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I13J8K1(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I11J10K2(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I11J10K3(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I13J8K2(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I13J8K3(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I12J7K5(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I12J8K5(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I11J7K5(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I11J8K5(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I5J12K7(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I5J12K8(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I5J11K7(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I5J11K8(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I14J4K9(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I14J4K10(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I13J4K9(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I13J4K10(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I14J12K6(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I13J12K6(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I14J11K6(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I13J11K6(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I9J15K7(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I9J15K8(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I10J15K7(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I10J15K8(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I7J15K9(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I8J15K9(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I7J15K10(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I8J15K10(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I6J12K14(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I6J12K13(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I6J11K14(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I6J11K13(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I9J1K12(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I7J1K14(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I9J2K12(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I9J3K12(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I7J2K14(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I7J3K14(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I9J4K14(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I10J1K12(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I8J1K14(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I10J2K12(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I10J3K12(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I8J2K14(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I8J3K14(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I10J4K14(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I9J1K11(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I7J1K13(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I9J2K11(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I9J3K11(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I7J2K13(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I7J3K13(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I9J4K13(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I10J1K11(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I8J1K13(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I10J2K11(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I10J3K11(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I8J2K13(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I8J3K13(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I10J4K13(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I9J12K1(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I7J14K1(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I9J12K2(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I9J12K3(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I7J14K2(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I7J14K3(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I10J12K1(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I8J14K1(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I10J12K2(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I10J12K3(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I8J14K2(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I8J14K3(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I9J11K1(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I7J13K1(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I9J11K2(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I9J11K3(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I7J13K2(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I7J13K3(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I10J11K1(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I8J13K1(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I10J11K2(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I10J11K3(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I8J13K2(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I8J13K3(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I7J12K5(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I8J12K5(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I7J11K5(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I8J11K5(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I5J7K12(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I5J8K12(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I5J7K11(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I5J8K11(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I14J6K12(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I13J6K12(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I14J6K11(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I13J6K11(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I14J9K4(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I14J10K4(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I13J9K4(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I13J10K4(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I6J14K12(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I6J13K12(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I6J14K11(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I6J13K11(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I9J14K4(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I10J14K4(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I9J13K4(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I10J13K4(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I7J5K12(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I8J5K12(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I7J5K11(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I8J5K11(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I9J7K15(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I9J8K15(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I10J7K15(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I10J8K15(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I7J9K15(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I8J9K15(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I7J10K15(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    for v,hv in _I8J10K15(r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
    
    hdd[u] = hd
    
    return hdd
    

