#!/usr/bin/env python 
# -*- coding: utf-8 -*- 
# 
# Author: Qingchun Wang @ NJU 
# E-mail: qingchun720@foxmail.com 
# 


import numpy
from bccc.pub import sign,dei


def _A1B2C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,2),(C,3)]))
    hv = 0.0
    
    hv += sum(h[p[I,0],p[I,0]]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(h[p[I,0],p[I,0]]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(h[p[I,1],p[I,1]]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(h[p[I,1],p[I,1]]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[I,0],p[I,0])]*r[I][194][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,1],p[I,0],p[I,1])]*r[I][199][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,0],p[I,1],p[I,0])]*r[I][274][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[I,1],p[I,1])]*r[I][279][0,0] for I in range(np) if I not in {A,B,C})
    hv += h[p[A,0],p[A,0]]*r[A][9][1,1]
    hv += h[p[A,0],p[A,0]]*r[A][24][1,1]
    hv += h[p[A,1],p[A,1]]*r[A][39][1,1]
    hv += h[p[A,1],p[A,1]]*r[A][54][1,1]
    hv += g[dei(p[A,0],p[A,0],p[A,0],p[A,0])]*r[A][194][1,1]
    hv += g[dei(p[A,0],p[A,1],p[A,0],p[A,1])]*r[A][199][1,1]
    hv += g[dei(p[A,1],p[A,0],p[A,1],p[A,0])]*r[A][274][1,1]
    hv += g[dei(p[A,1],p[A,1],p[A,1],p[A,1])]*r[A][279][1,1]
    hv += h[p[B,0],p[B,0]]*r[B][9][2,2]
    hv += h[p[B,0],p[B,0]]*r[B][24][2,2]
    hv += h[p[B,1],p[B,1]]*r[B][39][2,2]
    hv += h[p[B,1],p[B,1]]*r[B][54][2,2]
    hv += g[dei(p[B,0],p[B,0],p[B,1],p[B,1])]*r[B][214][2,2]
    hv += g[dei(p[B,0],p[B,1],p[B,1],p[B,0])]*r[B][211][2,2]
    hv += g[dei(p[B,1],p[B,0],p[B,0],p[B,1])]*r[B][262][2,2]
    hv += g[dei(p[B,1],p[B,1],p[B,0],p[B,0])]*r[B][259][2,2]
    hv += h[p[C,0],p[C,0]]*r[C][9][3,3]
    hv += h[p[C,0],p[C,0]]*r[C][24][3,3]
    hv += h[p[C,1],p[C,1]]*r[C][39][3,3]
    hv += h[p[C,1],p[C,1]]*r[C][54][3,3]
    hv += g[dei(p[C,0],p[C,0],p[C,1],p[C,1])]*r[C][214][3,3]
    hv += g[dei(p[C,0],p[C,1],p[C,1],p[C,0])]*r[C][211][3,3]
    hv += g[dei(p[C,1],p[C,0],p[C,0],p[C,1])]*r[C][262][3,3]
    hv += g[dei(p[C,1],p[C,1],p[C,0],p[C,0])]*r[C][259][3,3]
    hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][9][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][24][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][9][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][9][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][24][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][9][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][39][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][54][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][39][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][39][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][54][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][39][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,0])]*r[I][9][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,0])]*r[I][24][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,0])]*r[I][9][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,0])]*r[I][24][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,1])]*r[I][39][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,1])]*r[I][54][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,1])]*r[I][39][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,1])]*r[I][54][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,0],p[J,0])]*r[I][9][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,0],p[J,0])]*r[I][24][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,1],p[J,0])]*r[I][39][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,1],p[J,0])]*r[I][54][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,0],p[J,1])]*r[I][9][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,0],p[J,1])]*r[I][24][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,1],p[J,1])]*r[I][39][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,1],p[J,1])]*r[I][54][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[I][9][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[I][24][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[I][24][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[I][39][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[I][54][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[I][54][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[I][9][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[I][24][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[I][24][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[I][39][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[I][54][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[I][54][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][9][1,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][24][1,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][9][1,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][9][1,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][24][1,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][9][1,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,0],p[I,0])]*r[A][39][1,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,0],p[I,0])]*r[A][54][1,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,1],p[I,0],p[I,0])]*r[A][39][1,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,1],p[I,1])]*r[A][39][1,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,1],p[I,1])]*r[A][54][1,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,1],p[I,1],p[I,1])]*r[A][39][1,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,0])]*r[A][9][1,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,0])]*r[A][24][1,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,0])]*r[A][9][1,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,0])]*r[A][24][1,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,1])]*r[A][39][1,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,1])]*r[A][54][1,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,1])]*r[A][39][1,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,1])]*r[A][54][1,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,0])]*r[A][9][1,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,0])]*r[A][24][1,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,1],p[I,0])]*r[A][39][1,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,1],p[I,0])]*r[A][54][1,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,1])]*r[A][9][1,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,1])]*r[A][24][1,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,1],p[I,1])]*r[A][39][1,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,1],p[I,1])]*r[A][54][1,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][9][1,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,1])]*r[A][39][1,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][9][1,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,1])]*r[A][39][1,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[B,0],p[I,0],p[I,0])]*r[B][9][2,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[B,0],p[I,0],p[I,0])]*r[B][24][2,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,0],p[B,0],p[I,0],p[I,0])]*r[B][9][2,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[B,0],p[I,1],p[I,1])]*r[B][9][2,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[B,0],p[I,1],p[I,1])]*r[B][24][2,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,0],p[B,0],p[I,1],p[I,1])]*r[B][9][2,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[B,1],p[I,0],p[I,0])]*r[B][39][2,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[B,1],p[I,0],p[I,0])]*r[B][54][2,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,1],p[B,1],p[I,0],p[I,0])]*r[B][39][2,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[B,1],p[I,1],p[I,1])]*r[B][39][2,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[B,1],p[I,1],p[I,1])]*r[B][54][2,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,1],p[B,1],p[I,1],p[I,1])]*r[B][39][2,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,0],p[I,0],p[B,0])]*r[B][9][2,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,0],p[I,0],p[B,0])]*r[B][24][2,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,1],p[I,1],p[B,0])]*r[B][9][2,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,1],p[I,1],p[B,0])]*r[B][24][2,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,0],p[I,0],p[B,1])]*r[B][39][2,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,0],p[I,0],p[B,1])]*r[B][54][2,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,1],p[I,1],p[B,1])]*r[B][39][2,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,1],p[I,1],p[B,1])]*r[B][54][2,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,0],p[B,0],p[I,0])]*r[B][9][2,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,0],p[B,0],p[I,0])]*r[B][24][2,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,1],p[B,1],p[I,0])]*r[B][39][2,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,1],p[B,1],p[I,0])]*r[B][54][2,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,0],p[B,0],p[I,1])]*r[B][9][2,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,0],p[B,0],p[I,1])]*r[B][24][2,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,1],p[B,1],p[I,1])]*r[B][39][2,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,1],p[B,1],p[I,1])]*r[B][54][2,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,0],p[B,0])]*r[B][9][2,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,0],p[B,0])]*r[B][24][2,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[B,0],p[B,0])]*r[B][24][2,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,1],p[B,1])]*r[B][39][2,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,1],p[B,1])]*r[B][54][2,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[B,1],p[B,1])]*r[B][54][2,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,0],p[B,0])]*r[B][9][2,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,0],p[B,0])]*r[B][24][2,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[B,0],p[B,0])]*r[B][24][2,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,1],p[B,1])]*r[B][39][2,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,1],p[B,1])]*r[B][54][2,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[B,1],p[B,1])]*r[B][54][2,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[C,0],p[I,0],p[I,0])]*r[C][9][3,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[C,0],p[I,0],p[I,0])]*r[C][24][3,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[C,0],p[C,0],p[I,0],p[I,0])]*r[C][9][3,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[C,0],p[I,1],p[I,1])]*r[C][9][3,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[C,0],p[I,1],p[I,1])]*r[C][24][3,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[C,0],p[C,0],p[I,1],p[I,1])]*r[C][9][3,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[C,1],p[I,0],p[I,0])]*r[C][39][3,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[C,1],p[I,0],p[I,0])]*r[C][54][3,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[C,1],p[C,1],p[I,0],p[I,0])]*r[C][39][3,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[C,1],p[I,1],p[I,1])]*r[C][39][3,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[C,1],p[I,1],p[I,1])]*r[C][54][3,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[C,1],p[C,1],p[I,1],p[I,1])]*r[C][39][3,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,0],p[I,0],p[C,0])]*r[C][9][3,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,0],p[I,0],p[C,0])]*r[C][24][3,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,1],p[I,1],p[C,0])]*r[C][9][3,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,1],p[I,1],p[C,0])]*r[C][24][3,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,0],p[I,0],p[C,1])]*r[C][39][3,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,0],p[I,0],p[C,1])]*r[C][54][3,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,1],p[I,1],p[C,1])]*r[C][39][3,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,1],p[I,1],p[C,1])]*r[C][54][3,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,0],p[C,0],p[I,0])]*r[C][9][3,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,0],p[C,0],p[I,0])]*r[C][24][3,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,1],p[C,1],p[I,0])]*r[C][39][3,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,1],p[C,1],p[I,0])]*r[C][54][3,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,0],p[C,0],p[I,1])]*r[C][9][3,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,0],p[C,0],p[I,1])]*r[C][24][3,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,1],p[C,1],p[I,1])]*r[C][39][3,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,1],p[C,1],p[I,1])]*r[C][54][3,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,0],p[C,0])]*r[C][9][3,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,0],p[C,0])]*r[C][24][3,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[C,0],p[C,0])]*r[C][24][3,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,1],p[C,1])]*r[C][39][3,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,1],p[C,1])]*r[C][54][3,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[C,1],p[C,1])]*r[C][54][3,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,0],p[C,0])]*r[C][9][3,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,0],p[C,0])]*r[C][24][3,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[C,0],p[C,0])]*r[C][24][3,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,1],p[C,1])]*r[C][39][3,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,1],p[C,1])]*r[C][54][3,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[C,1],p[C,1])]*r[C][54][3,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[B,0])]*r[A][9][1,1]*r[B][9][2,2]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[B,0])]*r[A][24][1,1]*r[B][24][2,2]
    hv += g[dei(p[A,0],p[A,0],p[B,0],p[B,0])]*r[A][9][1,1]*r[B][24][2,2]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[B,1])]*r[A][9][1,1]*r[B][39][2,2]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[B,1])]*r[A][24][1,1]*r[B][54][2,2]
    hv += g[dei(p[A,0],p[A,0],p[B,1],p[B,1])]*r[A][9][1,1]*r[B][54][2,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[B,0])]*r[A][39][1,1]*r[B][9][2,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[B,0])]*r[A][54][1,1]*r[B][24][2,2]
    hv += g[dei(p[A,1],p[A,1],p[B,0],p[B,0])]*r[A][39][1,1]*r[B][24][2,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[B,1])]*r[A][39][1,1]*r[B][39][2,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[B,1])]*r[A][54][1,1]*r[B][54][2,2]
    hv += g[dei(p[A,1],p[A,1],p[B,1],p[B,1])]*r[A][39][1,1]*r[B][54][2,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[A,0])]*r[A][9][1,1]*r[B][9][2,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[A,0])]*r[A][24][1,1]*r[B][24][2,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[A,0])]*r[A][9][1,1]*r[B][39][2,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[A,0])]*r[A][24][1,1]*r[B][54][2,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[A,1])]*r[A][39][1,1]*r[B][9][2,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[A,1])]*r[A][54][1,1]*r[B][24][2,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[A,1])]*r[A][39][1,1]*r[B][39][2,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[A,1])]*r[A][54][1,1]*r[B][54][2,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[B,0])]*r[A][9][1,1]*r[B][9][2,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[B,0])]*r[A][24][1,1]*r[B][24][2,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[B,0])]*r[A][39][1,1]*r[B][9][2,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[B,0])]*r[A][54][1,1]*r[B][24][2,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[B,1])]*r[A][9][1,1]*r[B][39][2,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[B,1])]*r[A][24][1,1]*r[B][54][2,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[B,1])]*r[A][39][1,1]*r[B][39][2,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[B,1])]*r[A][54][1,1]*r[B][54][2,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][9][2,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][24][2,2]
    hv += g[dei(p[B,0],p[B,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][9][2,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][9][2,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][24][2,2]
    hv += g[dei(p[B,0],p[B,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][9][2,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][39][2,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][54][2,2]
    hv += g[dei(p[B,1],p[B,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][39][2,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][39][2,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][54][2,2]
    hv += g[dei(p[B,1],p[B,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][39][2,2]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[C,0])]*r[A][9][1,1]*r[C][9][3,3]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[C,0])]*r[A][24][1,1]*r[C][24][3,3]
    hv += g[dei(p[A,0],p[A,0],p[C,0],p[C,0])]*r[A][9][1,1]*r[C][24][3,3]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[C,1])]*r[A][9][1,1]*r[C][39][3,3]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[C,1])]*r[A][24][1,1]*r[C][54][3,3]
    hv += g[dei(p[A,0],p[A,0],p[C,1],p[C,1])]*r[A][9][1,1]*r[C][54][3,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[C,0])]*r[A][39][1,1]*r[C][9][3,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[C,0])]*r[A][54][1,1]*r[C][24][3,3]
    hv += g[dei(p[A,1],p[A,1],p[C,0],p[C,0])]*r[A][39][1,1]*r[C][24][3,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[C,1])]*r[A][39][1,1]*r[C][39][3,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[C,1])]*r[A][54][1,1]*r[C][54][3,3]
    hv += g[dei(p[A,1],p[A,1],p[C,1],p[C,1])]*r[A][39][1,1]*r[C][54][3,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,0])]*r[A][9][1,1]*r[C][9][3,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,0])]*r[A][24][1,1]*r[C][24][3,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,0])]*r[A][9][1,1]*r[C][39][3,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,0])]*r[A][24][1,1]*r[C][54][3,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,1])]*r[A][39][1,1]*r[C][9][3,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,1])]*r[A][54][1,1]*r[C][24][3,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,1])]*r[A][39][1,1]*r[C][39][3,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,1])]*r[A][54][1,1]*r[C][54][3,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[C,0])]*r[A][9][1,1]*r[C][9][3,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[C,0])]*r[A][24][1,1]*r[C][24][3,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[C,0])]*r[A][39][1,1]*r[C][9][3,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[C,0])]*r[A][54][1,1]*r[C][24][3,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[C,1])]*r[A][9][1,1]*r[C][39][3,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[C,1])]*r[A][24][1,1]*r[C][54][3,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[C,1])]*r[A][39][1,1]*r[C][39][3,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[C,1])]*r[A][54][1,1]*r[C][54][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,0])]*r[A][9][1,1]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[C][24][3,3]
    hv += g[dei(p[C,0],p[C,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,1])]*r[A][39][1,1]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[C][24][3,3]
    hv += g[dei(p[C,0],p[C,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,0])]*r[A][9][1,1]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[C][54][3,3]
    hv += g[dei(p[C,1],p[C,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,1])]*r[A][39][1,1]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[C][54][3,3]
    hv += g[dei(p[C,1],p[C,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[C][39][3,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,0],p[C,0])]*r[B][9][2,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,0],p[C,0])]*r[B][24][2,2]*r[C][24][3,3]
    hv += g[dei(p[B,0],p[B,0],p[C,0],p[C,0])]*r[B][9][2,2]*r[C][24][3,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,1],p[C,1])]*r[B][9][2,2]*r[C][39][3,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,1],p[C,1])]*r[B][24][2,2]*r[C][54][3,3]
    hv += g[dei(p[B,0],p[B,0],p[C,1],p[C,1])]*r[B][9][2,2]*r[C][54][3,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,0],p[C,0])]*r[B][39][2,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,0],p[C,0])]*r[B][54][2,2]*r[C][24][3,3]
    hv += g[dei(p[B,1],p[B,1],p[C,0],p[C,0])]*r[B][39][2,2]*r[C][24][3,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,1],p[C,1])]*r[B][39][2,2]*r[C][39][3,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,1],p[C,1])]*r[B][54][2,2]*r[C][54][3,3]
    hv += g[dei(p[B,1],p[B,1],p[C,1],p[C,1])]*r[B][39][2,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,0],p[B,0])]*r[B][9][2,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,0],p[B,0])]*r[B][24][2,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,1],p[B,0])]*r[B][9][2,2]*r[C][39][3,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,1],p[B,0])]*r[B][24][2,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,0],p[B,1])]*r[B][39][2,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,0],p[B,1])]*r[B][54][2,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,1],p[B,1])]*r[B][39][2,2]*r[C][39][3,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,1],p[B,1])]*r[B][54][2,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,0],p[C,0])]*r[B][9][2,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,0],p[C,0])]*r[B][24][2,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,1],p[C,0])]*r[B][39][2,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,1],p[C,0])]*r[B][54][2,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,0],p[C,1])]*r[B][9][2,2]*r[C][39][3,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,0],p[C,1])]*r[B][24][2,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,1],p[C,1])]*r[B][39][2,2]*r[C][39][3,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,1],p[C,1])]*r[B][54][2,2]*r[C][54][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,0],p[B,0])]*r[B][9][2,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,0],p[B,0])]*r[B][24][2,2]*r[C][24][3,3]
    hv += g[dei(p[C,0],p[C,0],p[B,0],p[B,0])]*r[B][24][2,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,1],p[B,1])]*r[B][39][2,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,1],p[B,1])]*r[B][54][2,2]*r[C][24][3,3]
    hv += g[dei(p[C,0],p[C,0],p[B,1],p[B,1])]*r[B][54][2,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,0],p[B,0])]*r[B][9][2,2]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,0],p[B,0])]*r[B][24][2,2]*r[C][54][3,3]
    hv += g[dei(p[C,1],p[C,1],p[B,0],p[B,0])]*r[B][24][2,2]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,1],p[B,1])]*r[B][39][2,2]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,1],p[B,1])]*r[B][54][2,2]*r[C][54][3,3]
    hv += g[dei(p[C,1],p[C,1],p[B,1],p[B,1])]*r[B][54][2,2]*r[C][39][3,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _B2C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(B,2),(C,3)]))
    hv = 0.0
    
    hv += h[p[A,0],p[A,0]]*r[A][9][0,1]
    hv += h[p[A,0],p[A,0]]*r[A][24][0,1]
    hv += h[p[A,1],p[A,1]]*r[A][39][0,1]
    hv += h[p[A,1],p[A,1]]*r[A][54][0,1]
    hv += g[dei(p[A,0],p[A,0],p[A,0],p[A,0])]*r[A][194][0,1]
    hv += g[dei(p[A,0],p[A,1],p[A,0],p[A,1])]*r[A][199][0,1]
    hv += g[dei(p[A,1],p[A,0],p[A,1],p[A,0])]*r[A][274][0,1]
    hv += g[dei(p[A,1],p[A,1],p[A,1],p[A,1])]*r[A][279][0,1]
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][9][0,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][24][0,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][9][0,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][9][0,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][24][0,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][9][0,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,0],p[I,0])]*r[A][39][0,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,0],p[I,0])]*r[A][54][0,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,1],p[I,0],p[I,0])]*r[A][39][0,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,1],p[I,1])]*r[A][39][0,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,1],p[I,1])]*r[A][54][0,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,1],p[I,1],p[I,1])]*r[A][39][0,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,0])]*r[A][9][0,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,0])]*r[A][24][0,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,0])]*r[A][9][0,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,0])]*r[A][24][0,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,1])]*r[A][39][0,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,1])]*r[A][54][0,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,1])]*r[A][39][0,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,1])]*r[A][54][0,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,0])]*r[A][9][0,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,0])]*r[A][24][0,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,1],p[I,0])]*r[A][39][0,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,1],p[I,0])]*r[A][54][0,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,1])]*r[A][9][0,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,1])]*r[A][24][0,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,1],p[I,1])]*r[A][39][0,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,1],p[I,1])]*r[A][54][0,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[B,0])]*r[A][9][0,1]*r[B][9][2,2]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[B,0])]*r[A][24][0,1]*r[B][24][2,2]
    hv += g[dei(p[A,0],p[A,0],p[B,0],p[B,0])]*r[A][9][0,1]*r[B][24][2,2]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[B,1])]*r[A][9][0,1]*r[B][39][2,2]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[B,1])]*r[A][24][0,1]*r[B][54][2,2]
    hv += g[dei(p[A,0],p[A,0],p[B,1],p[B,1])]*r[A][9][0,1]*r[B][54][2,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[B,0])]*r[A][39][0,1]*r[B][9][2,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[B,0])]*r[A][54][0,1]*r[B][24][2,2]
    hv += g[dei(p[A,1],p[A,1],p[B,0],p[B,0])]*r[A][39][0,1]*r[B][24][2,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[B,1])]*r[A][39][0,1]*r[B][39][2,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[B,1])]*r[A][54][0,1]*r[B][54][2,2]
    hv += g[dei(p[A,1],p[A,1],p[B,1],p[B,1])]*r[A][39][0,1]*r[B][54][2,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[A,0])]*r[A][9][0,1]*r[B][9][2,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[A,0])]*r[A][24][0,1]*r[B][24][2,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[A,0])]*r[A][9][0,1]*r[B][39][2,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[A,0])]*r[A][24][0,1]*r[B][54][2,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[A,1])]*r[A][39][0,1]*r[B][9][2,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[A,1])]*r[A][54][0,1]*r[B][24][2,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[A,1])]*r[A][39][0,1]*r[B][39][2,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[A,1])]*r[A][54][0,1]*r[B][54][2,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[B,0])]*r[A][9][0,1]*r[B][9][2,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[B,0])]*r[A][24][0,1]*r[B][24][2,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[B,0])]*r[A][39][0,1]*r[B][9][2,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[B,0])]*r[A][54][0,1]*r[B][24][2,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[B,1])]*r[A][9][0,1]*r[B][39][2,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[B,1])]*r[A][24][0,1]*r[B][54][2,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[B,1])]*r[A][39][0,1]*r[B][39][2,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[B,1])]*r[A][54][0,1]*r[B][54][2,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][9][2,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][24][2,2]
    hv += g[dei(p[B,0],p[B,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][9][2,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][9][2,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][24][2,2]
    hv += g[dei(p[B,0],p[B,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][9][2,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][39][2,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][54][2,2]
    hv += g[dei(p[B,1],p[B,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][39][2,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][39][2,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][54][2,2]
    hv += g[dei(p[B,1],p[B,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][39][2,2]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[C,0])]*r[A][9][0,1]*r[C][9][3,3]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[C,0])]*r[A][24][0,1]*r[C][24][3,3]
    hv += g[dei(p[A,0],p[A,0],p[C,0],p[C,0])]*r[A][9][0,1]*r[C][24][3,3]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[C,1])]*r[A][9][0,1]*r[C][39][3,3]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[C,1])]*r[A][24][0,1]*r[C][54][3,3]
    hv += g[dei(p[A,0],p[A,0],p[C,1],p[C,1])]*r[A][9][0,1]*r[C][54][3,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[C,0])]*r[A][39][0,1]*r[C][9][3,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[C,0])]*r[A][54][0,1]*r[C][24][3,3]
    hv += g[dei(p[A,1],p[A,1],p[C,0],p[C,0])]*r[A][39][0,1]*r[C][24][3,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[C,1])]*r[A][39][0,1]*r[C][39][3,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[C,1])]*r[A][54][0,1]*r[C][54][3,3]
    hv += g[dei(p[A,1],p[A,1],p[C,1],p[C,1])]*r[A][39][0,1]*r[C][54][3,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,0])]*r[A][9][0,1]*r[C][9][3,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,0])]*r[A][24][0,1]*r[C][24][3,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,0])]*r[A][9][0,1]*r[C][39][3,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,0])]*r[A][24][0,1]*r[C][54][3,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,1])]*r[A][39][0,1]*r[C][9][3,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,1])]*r[A][54][0,1]*r[C][24][3,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,1])]*r[A][39][0,1]*r[C][39][3,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,1])]*r[A][54][0,1]*r[C][54][3,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[C,0])]*r[A][9][0,1]*r[C][9][3,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[C,0])]*r[A][24][0,1]*r[C][24][3,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[C,0])]*r[A][39][0,1]*r[C][9][3,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[C,0])]*r[A][54][0,1]*r[C][24][3,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[C,1])]*r[A][9][0,1]*r[C][39][3,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[C,1])]*r[A][24][0,1]*r[C][54][3,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[C,1])]*r[A][39][0,1]*r[C][39][3,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[C,1])]*r[A][54][0,1]*r[C][54][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][24][3,3]
    hv += g[dei(p[C,0],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][24][3,3]
    hv += g[dei(p[C,0],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][54][3,3]
    hv += g[dei(p[C,1],p[C,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][54][3,3]
    hv += g[dei(p[C,1],p[C,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][39][3,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A2B2C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(B,2),(C,3)]))
    hv = 0.0
    
    hv += h[p[A,0],p[A,1]]*r[A][15][2,1]
    hv += h[p[A,0],p[A,1]]*r[A][30][2,1]
    hv += h[p[A,1],p[A,0]]*r[A][33][2,1]
    hv += h[p[A,1],p[A,0]]*r[A][48][2,1]
    hv += g[dei(p[A,0],p[A,0],p[A,1],p[A,0])]*r[A][210][2,1]
    hv += g[dei(p[A,0],p[A,1],p[A,1],p[A,1])]*r[A][215][2,1]
    hv += g[dei(p[A,1],p[A,0],p[A,0],p[A,0])]*r[A][258][2,1]
    hv += g[dei(p[A,1],p[A,1],p[A,0],p[A,1])]*r[A][263][2,1]
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,0],p[I,0])]*r[A][15][2,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,0],p[I,0])]*r[A][30][2,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,1],p[I,0],p[I,0])]*r[A][15][2,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,1],p[I,1])]*r[A][15][2,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,1],p[I,1])]*r[A][30][2,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,1],p[I,1],p[I,1])]*r[A][15][2,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][33][2,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][48][2,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][33][2,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][33][2,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][48][2,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][33][2,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,1])]*r[A][15][2,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,1])]*r[A][30][2,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,1])]*r[A][15][2,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,1])]*r[A][30][2,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,0])]*r[A][33][2,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,0])]*r[A][48][2,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,0])]*r[A][33][2,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,0])]*r[A][48][2,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,0],p[I,0])]*r[A][15][2,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,0],p[I,0])]*r[A][30][2,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,0])]*r[A][33][2,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,0])]*r[A][48][2,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,0],p[I,1])]*r[A][15][2,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,0],p[I,1])]*r[A][30][2,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,1])]*r[A][33][2,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,1])]*r[A][48][2,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,1])]*r[A][15][2,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][33][2,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,1])]*r[A][15][2,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][33][2,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[B,0])]*r[A][15][2,1]*r[B][9][2,2]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[B,0])]*r[A][30][2,1]*r[B][24][2,2]
    hv += g[dei(p[A,0],p[A,1],p[B,0],p[B,0])]*r[A][15][2,1]*r[B][24][2,2]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[B,1])]*r[A][15][2,1]*r[B][39][2,2]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[B,1])]*r[A][30][2,1]*r[B][54][2,2]
    hv += g[dei(p[A,0],p[A,1],p[B,1],p[B,1])]*r[A][15][2,1]*r[B][54][2,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[B,0])]*r[A][33][2,1]*r[B][9][2,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[B,0])]*r[A][48][2,1]*r[B][24][2,2]
    hv += g[dei(p[A,1],p[A,0],p[B,0],p[B,0])]*r[A][33][2,1]*r[B][24][2,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[B,1])]*r[A][33][2,1]*r[B][39][2,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[B,1])]*r[A][48][2,1]*r[B][54][2,2]
    hv += g[dei(p[A,1],p[A,0],p[B,1],p[B,1])]*r[A][33][2,1]*r[B][54][2,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[A,1])]*r[A][15][2,1]*r[B][9][2,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[A,1])]*r[A][30][2,1]*r[B][24][2,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[A,1])]*r[A][15][2,1]*r[B][39][2,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[A,1])]*r[A][30][2,1]*r[B][54][2,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[A,0])]*r[A][33][2,1]*r[B][9][2,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[A,0])]*r[A][48][2,1]*r[B][24][2,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[A,0])]*r[A][33][2,1]*r[B][39][2,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[A,0])]*r[A][48][2,1]*r[B][54][2,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[B,0])]*r[A][15][2,1]*r[B][9][2,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[B,0])]*r[A][30][2,1]*r[B][24][2,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[B,0])]*r[A][33][2,1]*r[B][9][2,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[B,0])]*r[A][48][2,1]*r[B][24][2,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[B,1])]*r[A][15][2,1]*r[B][39][2,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[B,1])]*r[A][30][2,1]*r[B][54][2,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[B,1])]*r[A][33][2,1]*r[B][39][2,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[B,1])]*r[A][48][2,1]*r[B][54][2,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][9][2,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][24][2,2]
    hv += g[dei(p[B,0],p[B,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][9][2,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][9][2,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][24][2,2]
    hv += g[dei(p[B,0],p[B,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][9][2,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][39][2,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][54][2,2]
    hv += g[dei(p[B,1],p[B,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][39][2,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][39][2,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][54][2,2]
    hv += g[dei(p[B,1],p[B,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][39][2,2]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,0],p[C,0])]*r[A][15][2,1]*r[C][9][3,3]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,0],p[C,0])]*r[A][30][2,1]*r[C][24][3,3]
    hv += g[dei(p[A,0],p[A,1],p[C,0],p[C,0])]*r[A][15][2,1]*r[C][24][3,3]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,1],p[C,1])]*r[A][15][2,1]*r[C][39][3,3]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,1],p[C,1])]*r[A][30][2,1]*r[C][54][3,3]
    hv += g[dei(p[A,0],p[A,1],p[C,1],p[C,1])]*r[A][15][2,1]*r[C][54][3,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,0],p[C,0])]*r[A][33][2,1]*r[C][9][3,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,0],p[C,0])]*r[A][48][2,1]*r[C][24][3,3]
    hv += g[dei(p[A,1],p[A,0],p[C,0],p[C,0])]*r[A][33][2,1]*r[C][24][3,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,1],p[C,1])]*r[A][33][2,1]*r[C][39][3,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,1],p[C,1])]*r[A][48][2,1]*r[C][54][3,3]
    hv += g[dei(p[A,1],p[A,0],p[C,1],p[C,1])]*r[A][33][2,1]*r[C][54][3,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,1])]*r[A][15][2,1]*r[C][9][3,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,1])]*r[A][30][2,1]*r[C][24][3,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,1])]*r[A][15][2,1]*r[C][39][3,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,1])]*r[A][30][2,1]*r[C][54][3,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,0])]*r[A][33][2,1]*r[C][9][3,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,0])]*r[A][48][2,1]*r[C][24][3,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,0])]*r[A][33][2,1]*r[C][39][3,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,0])]*r[A][48][2,1]*r[C][54][3,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,0],p[C,0])]*r[A][15][2,1]*r[C][9][3,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,0],p[C,0])]*r[A][30][2,1]*r[C][24][3,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,1],p[C,0])]*r[A][33][2,1]*r[C][9][3,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,1],p[C,0])]*r[A][48][2,1]*r[C][24][3,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,0],p[C,1])]*r[A][15][2,1]*r[C][39][3,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,0],p[C,1])]*r[A][30][2,1]*r[C][54][3,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,1],p[C,1])]*r[A][33][2,1]*r[C][39][3,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,1],p[C,1])]*r[A][48][2,1]*r[C][54][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,1])]*r[A][15][2,1]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[C][24][3,3]
    hv += g[dei(p[C,0],p[C,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,0])]*r[A][33][2,1]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[C][24][3,3]
    hv += g[dei(p[C,0],p[C,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,1])]*r[A][15][2,1]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[C][54][3,3]
    hv += g[dei(p[C,1],p[C,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,0])]*r[A][33][2,1]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[C][54][3,3]
    hv += g[dei(p[C,1],p[C,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[C][39][3,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A3B2C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,2),(C,3)]))
    hv = 0.0
    
    hv += h[p[A,0],p[A,1]]*r[A][15][3,1]
    hv += h[p[A,0],p[A,1]]*r[A][30][3,1]
    hv += h[p[A,1],p[A,0]]*r[A][33][3,1]
    hv += h[p[A,1],p[A,0]]*r[A][48][3,1]
    hv += g[dei(p[A,0],p[A,0],p[A,1],p[A,0])]*r[A][210][3,1]
    hv += g[dei(p[A,0],p[A,1],p[A,1],p[A,1])]*r[A][215][3,1]
    hv += g[dei(p[A,1],p[A,0],p[A,0],p[A,0])]*r[A][258][3,1]
    hv += g[dei(p[A,1],p[A,1],p[A,0],p[A,1])]*r[A][263][3,1]
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,0],p[I,0])]*r[A][15][3,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,0],p[I,0])]*r[A][30][3,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,1],p[I,0],p[I,0])]*r[A][15][3,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,1],p[I,1])]*r[A][15][3,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,1],p[I,1])]*r[A][30][3,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,1],p[I,1],p[I,1])]*r[A][15][3,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][33][3,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][48][3,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][33][3,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][33][3,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][48][3,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][33][3,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,1])]*r[A][15][3,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,1])]*r[A][30][3,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,1])]*r[A][15][3,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,1])]*r[A][30][3,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,0])]*r[A][33][3,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,0])]*r[A][48][3,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,0])]*r[A][33][3,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,0])]*r[A][48][3,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,0],p[I,0])]*r[A][15][3,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,0],p[I,0])]*r[A][30][3,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,0])]*r[A][33][3,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,0])]*r[A][48][3,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,0],p[I,1])]*r[A][15][3,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,0],p[I,1])]*r[A][30][3,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,1])]*r[A][33][3,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,1])]*r[A][48][3,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,1])]*r[A][15][3,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][33][3,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,1])]*r[A][15][3,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][33][3,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[B,0])]*r[A][15][3,1]*r[B][9][2,2]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[B,0])]*r[A][30][3,1]*r[B][24][2,2]
    hv += g[dei(p[A,0],p[A,1],p[B,0],p[B,0])]*r[A][15][3,1]*r[B][24][2,2]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[B,1])]*r[A][15][3,1]*r[B][39][2,2]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[B,1])]*r[A][30][3,1]*r[B][54][2,2]
    hv += g[dei(p[A,0],p[A,1],p[B,1],p[B,1])]*r[A][15][3,1]*r[B][54][2,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[B,0])]*r[A][33][3,1]*r[B][9][2,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[B,0])]*r[A][48][3,1]*r[B][24][2,2]
    hv += g[dei(p[A,1],p[A,0],p[B,0],p[B,0])]*r[A][33][3,1]*r[B][24][2,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[B,1])]*r[A][33][3,1]*r[B][39][2,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[B,1])]*r[A][48][3,1]*r[B][54][2,2]
    hv += g[dei(p[A,1],p[A,0],p[B,1],p[B,1])]*r[A][33][3,1]*r[B][54][2,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[A,1])]*r[A][15][3,1]*r[B][9][2,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[A,1])]*r[A][30][3,1]*r[B][24][2,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[A,1])]*r[A][15][3,1]*r[B][39][2,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[A,1])]*r[A][30][3,1]*r[B][54][2,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[A,0])]*r[A][33][3,1]*r[B][9][2,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[A,0])]*r[A][48][3,1]*r[B][24][2,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[A,0])]*r[A][33][3,1]*r[B][39][2,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[A,0])]*r[A][48][3,1]*r[B][54][2,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[B,0])]*r[A][15][3,1]*r[B][9][2,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[B,0])]*r[A][30][3,1]*r[B][24][2,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[B,0])]*r[A][33][3,1]*r[B][9][2,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[B,0])]*r[A][48][3,1]*r[B][24][2,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[B,1])]*r[A][15][3,1]*r[B][39][2,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[B,1])]*r[A][30][3,1]*r[B][54][2,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[B,1])]*r[A][33][3,1]*r[B][39][2,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[B,1])]*r[A][48][3,1]*r[B][54][2,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][9][2,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][24][2,2]
    hv += g[dei(p[B,0],p[B,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][9][2,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][9][2,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][24][2,2]
    hv += g[dei(p[B,0],p[B,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][9][2,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][39][2,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][54][2,2]
    hv += g[dei(p[B,1],p[B,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][39][2,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][39][2,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][54][2,2]
    hv += g[dei(p[B,1],p[B,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][39][2,2]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,0],p[C,0])]*r[A][15][3,1]*r[C][9][3,3]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,0],p[C,0])]*r[A][30][3,1]*r[C][24][3,3]
    hv += g[dei(p[A,0],p[A,1],p[C,0],p[C,0])]*r[A][15][3,1]*r[C][24][3,3]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,1],p[C,1])]*r[A][15][3,1]*r[C][39][3,3]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,1],p[C,1])]*r[A][30][3,1]*r[C][54][3,3]
    hv += g[dei(p[A,0],p[A,1],p[C,1],p[C,1])]*r[A][15][3,1]*r[C][54][3,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,0],p[C,0])]*r[A][33][3,1]*r[C][9][3,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,0],p[C,0])]*r[A][48][3,1]*r[C][24][3,3]
    hv += g[dei(p[A,1],p[A,0],p[C,0],p[C,0])]*r[A][33][3,1]*r[C][24][3,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,1],p[C,1])]*r[A][33][3,1]*r[C][39][3,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,1],p[C,1])]*r[A][48][3,1]*r[C][54][3,3]
    hv += g[dei(p[A,1],p[A,0],p[C,1],p[C,1])]*r[A][33][3,1]*r[C][54][3,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,1])]*r[A][15][3,1]*r[C][9][3,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,1])]*r[A][30][3,1]*r[C][24][3,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,1])]*r[A][15][3,1]*r[C][39][3,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,1])]*r[A][30][3,1]*r[C][54][3,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,0])]*r[A][33][3,1]*r[C][9][3,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,0])]*r[A][48][3,1]*r[C][24][3,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,0])]*r[A][33][3,1]*r[C][39][3,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,0])]*r[A][48][3,1]*r[C][54][3,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,0],p[C,0])]*r[A][15][3,1]*r[C][9][3,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,0],p[C,0])]*r[A][30][3,1]*r[C][24][3,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,1],p[C,0])]*r[A][33][3,1]*r[C][9][3,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,1],p[C,0])]*r[A][48][3,1]*r[C][24][3,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,0],p[C,1])]*r[A][15][3,1]*r[C][39][3,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,0],p[C,1])]*r[A][30][3,1]*r[C][54][3,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,1],p[C,1])]*r[A][33][3,1]*r[C][39][3,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,1],p[C,1])]*r[A][48][3,1]*r[C][54][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,1])]*r[A][15][3,1]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[C][24][3,3]
    hv += g[dei(p[C,0],p[C,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,0])]*r[A][33][3,1]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[C][24][3,3]
    hv += g[dei(p[C,0],p[C,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,1])]*r[A][15][3,1]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[C][54][3,3]
    hv += g[dei(p[C,1],p[C,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,0])]*r[A][33][3,1]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[C][54][3,3]
    hv += g[dei(p[C,1],p[C,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[C][39][3,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A1B3C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,3),(C,3)]))
    hv = 0.0
    
    hv += h[p[B,0],p[B,0]]*r[B][9][3,2]
    hv += h[p[B,0],p[B,0]]*r[B][24][3,2]
    hv += h[p[B,1],p[B,1]]*r[B][39][3,2]
    hv += h[p[B,1],p[B,1]]*r[B][54][3,2]
    hv += g[dei(p[B,0],p[B,0],p[B,1],p[B,1])]*r[B][214][3,2]
    hv += g[dei(p[B,0],p[B,1],p[B,1],p[B,0])]*r[B][211][3,2]
    hv += g[dei(p[B,1],p[B,0],p[B,0],p[B,1])]*r[B][262][3,2]
    hv += g[dei(p[B,1],p[B,1],p[B,0],p[B,0])]*r[B][259][3,2]
    hv += sum(1/2*g[dei(p[B,0],p[B,0],p[I,0],p[I,0])]*r[B][9][3,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[B,0],p[I,0],p[I,0])]*r[B][24][3,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,0],p[B,0],p[I,0],p[I,0])]*r[B][9][3,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[B,0],p[I,1],p[I,1])]*r[B][9][3,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[B,0],p[I,1],p[I,1])]*r[B][24][3,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,0],p[B,0],p[I,1],p[I,1])]*r[B][9][3,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[B,1],p[I,0],p[I,0])]*r[B][39][3,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[B,1],p[I,0],p[I,0])]*r[B][54][3,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,1],p[B,1],p[I,0],p[I,0])]*r[B][39][3,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[B,1],p[I,1],p[I,1])]*r[B][39][3,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[B,1],p[I,1],p[I,1])]*r[B][54][3,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,1],p[B,1],p[I,1],p[I,1])]*r[B][39][3,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,0],p[I,0],p[B,0])]*r[B][9][3,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,0],p[I,0],p[B,0])]*r[B][24][3,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,1],p[I,1],p[B,0])]*r[B][9][3,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,1],p[I,1],p[B,0])]*r[B][24][3,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,0],p[I,0],p[B,1])]*r[B][39][3,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,0],p[I,0],p[B,1])]*r[B][54][3,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,1],p[I,1],p[B,1])]*r[B][39][3,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,1],p[I,1],p[B,1])]*r[B][54][3,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,0],p[B,0],p[I,0])]*r[B][9][3,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,0],p[B,0],p[I,0])]*r[B][24][3,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,1],p[B,1],p[I,0])]*r[B][39][3,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,1],p[B,1],p[I,0])]*r[B][54][3,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,0],p[B,0],p[I,1])]*r[B][9][3,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,0],p[B,0],p[I,1])]*r[B][24][3,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,1],p[B,1],p[I,1])]*r[B][39][3,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,1],p[B,1],p[I,1])]*r[B][54][3,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,0],p[B,0])]*r[B][9][3,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,0],p[B,0])]*r[B][24][3,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[B,0],p[B,0])]*r[B][24][3,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,1],p[B,1])]*r[B][39][3,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,1],p[B,1])]*r[B][54][3,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[B,1],p[B,1])]*r[B][54][3,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,0],p[B,0])]*r[B][9][3,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,0],p[B,0])]*r[B][24][3,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[B,0],p[B,0])]*r[B][24][3,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,1],p[B,1])]*r[B][39][3,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,1],p[B,1])]*r[B][54][3,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[B,1],p[B,1])]*r[B][54][3,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[B,0])]*r[A][9][1,1]*r[B][9][3,2]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[B,0])]*r[A][24][1,1]*r[B][24][3,2]
    hv += g[dei(p[A,0],p[A,0],p[B,0],p[B,0])]*r[A][9][1,1]*r[B][24][3,2]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[B,1])]*r[A][9][1,1]*r[B][39][3,2]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[B,1])]*r[A][24][1,1]*r[B][54][3,2]
    hv += g[dei(p[A,0],p[A,0],p[B,1],p[B,1])]*r[A][9][1,1]*r[B][54][3,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[B,0])]*r[A][39][1,1]*r[B][9][3,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[B,0])]*r[A][54][1,1]*r[B][24][3,2]
    hv += g[dei(p[A,1],p[A,1],p[B,0],p[B,0])]*r[A][39][1,1]*r[B][24][3,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[B,1])]*r[A][39][1,1]*r[B][39][3,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[B,1])]*r[A][54][1,1]*r[B][54][3,2]
    hv += g[dei(p[A,1],p[A,1],p[B,1],p[B,1])]*r[A][39][1,1]*r[B][54][3,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[A,0])]*r[A][9][1,1]*r[B][9][3,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[A,0])]*r[A][24][1,1]*r[B][24][3,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[A,0])]*r[A][9][1,1]*r[B][39][3,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[A,0])]*r[A][24][1,1]*r[B][54][3,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[A,1])]*r[A][39][1,1]*r[B][9][3,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[A,1])]*r[A][54][1,1]*r[B][24][3,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[A,1])]*r[A][39][1,1]*r[B][39][3,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[A,1])]*r[A][54][1,1]*r[B][54][3,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[B,0])]*r[A][9][1,1]*r[B][9][3,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[B,0])]*r[A][24][1,1]*r[B][24][3,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[B,0])]*r[A][39][1,1]*r[B][9][3,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[B,0])]*r[A][54][1,1]*r[B][24][3,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[B,1])]*r[A][9][1,1]*r[B][39][3,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[B,1])]*r[A][24][1,1]*r[B][54][3,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[B,1])]*r[A][39][1,1]*r[B][39][3,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[B,1])]*r[A][54][1,1]*r[B][54][3,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][9][3,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][24][3,2]
    hv += g[dei(p[B,0],p[B,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][9][3,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][9][3,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][24][3,2]
    hv += g[dei(p[B,0],p[B,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][9][3,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][39][3,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][54][3,2]
    hv += g[dei(p[B,1],p[B,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][39][3,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][39][3,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][54][3,2]
    hv += g[dei(p[B,1],p[B,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][39][3,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,0],p[C,0])]*r[B][9][3,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,0],p[C,0])]*r[B][24][3,2]*r[C][24][3,3]
    hv += g[dei(p[B,0],p[B,0],p[C,0],p[C,0])]*r[B][9][3,2]*r[C][24][3,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,1],p[C,1])]*r[B][9][3,2]*r[C][39][3,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,1],p[C,1])]*r[B][24][3,2]*r[C][54][3,3]
    hv += g[dei(p[B,0],p[B,0],p[C,1],p[C,1])]*r[B][9][3,2]*r[C][54][3,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,0],p[C,0])]*r[B][39][3,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,0],p[C,0])]*r[B][54][3,2]*r[C][24][3,3]
    hv += g[dei(p[B,1],p[B,1],p[C,0],p[C,0])]*r[B][39][3,2]*r[C][24][3,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,1],p[C,1])]*r[B][39][3,2]*r[C][39][3,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,1],p[C,1])]*r[B][54][3,2]*r[C][54][3,3]
    hv += g[dei(p[B,1],p[B,1],p[C,1],p[C,1])]*r[B][39][3,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,0],p[B,0])]*r[B][9][3,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,0],p[B,0])]*r[B][24][3,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,1],p[B,0])]*r[B][9][3,2]*r[C][39][3,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,1],p[B,0])]*r[B][24][3,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,0],p[B,1])]*r[B][39][3,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,0],p[B,1])]*r[B][54][3,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,1],p[B,1])]*r[B][39][3,2]*r[C][39][3,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,1],p[B,1])]*r[B][54][3,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,0],p[C,0])]*r[B][9][3,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,0],p[C,0])]*r[B][24][3,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,1],p[C,0])]*r[B][39][3,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,1],p[C,0])]*r[B][54][3,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,0],p[C,1])]*r[B][9][3,2]*r[C][39][3,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,0],p[C,1])]*r[B][24][3,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,1],p[C,1])]*r[B][39][3,2]*r[C][39][3,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,1],p[C,1])]*r[B][54][3,2]*r[C][54][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,0],p[B,0])]*r[B][9][3,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,0],p[B,0])]*r[B][24][3,2]*r[C][24][3,3]
    hv += g[dei(p[C,0],p[C,0],p[B,0],p[B,0])]*r[B][24][3,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,1],p[B,1])]*r[B][39][3,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,1],p[B,1])]*r[B][54][3,2]*r[C][24][3,3]
    hv += g[dei(p[C,0],p[C,0],p[B,1],p[B,1])]*r[B][54][3,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,0],p[B,0])]*r[B][9][3,2]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,0],p[B,0])]*r[B][24][3,2]*r[C][54][3,3]
    hv += g[dei(p[C,1],p[C,1],p[B,0],p[B,0])]*r[B][24][3,2]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,1],p[B,1])]*r[B][39][3,2]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,1],p[B,1])]*r[B][54][3,2]*r[C][54][3,3]
    hv += g[dei(p[C,1],p[C,1],p[B,1],p[B,1])]*r[B][54][3,2]*r[C][39][3,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A1C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(C,3)]))
    hv = 0.0
    
    hv += h[p[B,0],p[B,1]]*r[B][15][0,2]
    hv += h[p[B,0],p[B,1]]*r[B][30][0,2]
    hv += h[p[B,1],p[B,0]]*r[B][33][0,2]
    hv += h[p[B,1],p[B,0]]*r[B][48][0,2]
    hv += g[dei(p[B,0],p[B,0],p[B,0],p[B,1])]*r[B][198][0,2]
    hv += g[dei(p[B,0],p[B,1],p[B,0],p[B,0])]*r[B][195][0,2]
    hv += g[dei(p[B,1],p[B,0],p[B,1],p[B,1])]*r[B][278][0,2]
    hv += g[dei(p[B,1],p[B,1],p[B,1],p[B,0])]*r[B][275][0,2]
    hv += sum(1/2*g[dei(p[B,0],p[B,1],p[I,0],p[I,0])]*r[B][15][0,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[B,1],p[I,0],p[I,0])]*r[B][30][0,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,0],p[B,1],p[I,0],p[I,0])]*r[B][15][0,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[B,1],p[I,1],p[I,1])]*r[B][15][0,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[B,1],p[I,1],p[I,1])]*r[B][30][0,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,0],p[B,1],p[I,1],p[I,1])]*r[B][15][0,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[B,0],p[I,0],p[I,0])]*r[B][33][0,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[B,0],p[I,0],p[I,0])]*r[B][48][0,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,1],p[B,0],p[I,0],p[I,0])]*r[B][33][0,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[B,0],p[I,1],p[I,1])]*r[B][33][0,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[B,0],p[I,1],p[I,1])]*r[B][48][0,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,1],p[B,0],p[I,1],p[I,1])]*r[B][33][0,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,0],p[I,0],p[B,1])]*r[B][15][0,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,0],p[I,0],p[B,1])]*r[B][30][0,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,1],p[I,1],p[B,1])]*r[B][15][0,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,1],p[I,1],p[B,1])]*r[B][30][0,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,0],p[I,0],p[B,0])]*r[B][33][0,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,0],p[I,0],p[B,0])]*r[B][48][0,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,1],p[I,1],p[B,0])]*r[B][33][0,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,1],p[I,1],p[B,0])]*r[B][48][0,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,1],p[B,0],p[I,0])]*r[B][15][0,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,1],p[B,0],p[I,0])]*r[B][30][0,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,0],p[B,1],p[I,0])]*r[B][33][0,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,0],p[B,1],p[I,0])]*r[B][48][0,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,1],p[B,0],p[I,1])]*r[B][15][0,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,1],p[B,0],p[I,1])]*r[B][30][0,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,0],p[B,1],p[I,1])]*r[B][33][0,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,0],p[B,1],p[I,1])]*r[B][48][0,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,0],p[B,1])]*r[B][15][0,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,0],p[B,1])]*r[B][30][0,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[B,0],p[B,1])]*r[B][30][0,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,1],p[B,0])]*r[B][33][0,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,1],p[B,0])]*r[B][48][0,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[B,1],p[B,0])]*r[B][48][0,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,0],p[B,1])]*r[B][15][0,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,0],p[B,1])]*r[B][30][0,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[B,0],p[B,1])]*r[B][30][0,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,1],p[B,0])]*r[B][33][0,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,1],p[B,0])]*r[B][48][0,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[B,1],p[B,0])]*r[B][48][0,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[B,1])]*r[A][9][1,1]*r[B][15][0,2]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[B,1])]*r[A][24][1,1]*r[B][30][0,2]
    hv += g[dei(p[A,0],p[A,0],p[B,0],p[B,1])]*r[A][9][1,1]*r[B][30][0,2]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[B,0])]*r[A][9][1,1]*r[B][33][0,2]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[B,0])]*r[A][24][1,1]*r[B][48][0,2]
    hv += g[dei(p[A,0],p[A,0],p[B,1],p[B,0])]*r[A][9][1,1]*r[B][48][0,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[B,1])]*r[A][39][1,1]*r[B][15][0,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[B,1])]*r[A][54][1,1]*r[B][30][0,2]
    hv += g[dei(p[A,1],p[A,1],p[B,0],p[B,1])]*r[A][39][1,1]*r[B][30][0,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[B,0])]*r[A][39][1,1]*r[B][33][0,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[B,0])]*r[A][54][1,1]*r[B][48][0,2]
    hv += g[dei(p[A,1],p[A,1],p[B,1],p[B,0])]*r[A][39][1,1]*r[B][48][0,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[A,0])]*r[A][9][1,1]*r[B][15][0,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[A,0])]*r[A][24][1,1]*r[B][30][0,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[A,0])]*r[A][9][1,1]*r[B][33][0,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[A,0])]*r[A][24][1,1]*r[B][48][0,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[A,1])]*r[A][39][1,1]*r[B][15][0,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[A,1])]*r[A][54][1,1]*r[B][30][0,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[A,1])]*r[A][39][1,1]*r[B][33][0,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[A,1])]*r[A][54][1,1]*r[B][48][0,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[B,1])]*r[A][9][1,1]*r[B][15][0,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[B,1])]*r[A][24][1,1]*r[B][30][0,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[B,1])]*r[A][39][1,1]*r[B][15][0,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[B,1])]*r[A][54][1,1]*r[B][30][0,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[B,0])]*r[A][9][1,1]*r[B][33][0,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[B,0])]*r[A][24][1,1]*r[B][48][0,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[B,0])]*r[A][39][1,1]*r[B][33][0,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[B,0])]*r[A][54][1,1]*r[B][48][0,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][15][0,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][30][0,2]
    hv += g[dei(p[B,0],p[B,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][15][0,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][15][0,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][30][0,2]
    hv += g[dei(p[B,0],p[B,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][15][0,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][33][0,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][48][0,2]
    hv += g[dei(p[B,1],p[B,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][33][0,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][33][0,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][48][0,2]
    hv += g[dei(p[B,1],p[B,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][33][0,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,0],p[C,0])]*r[B][15][0,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,0],p[C,0])]*r[B][30][0,2]*r[C][24][3,3]
    hv += g[dei(p[B,0],p[B,1],p[C,0],p[C,0])]*r[B][15][0,2]*r[C][24][3,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,1],p[C,1])]*r[B][15][0,2]*r[C][39][3,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,1],p[C,1])]*r[B][30][0,2]*r[C][54][3,3]
    hv += g[dei(p[B,0],p[B,1],p[C,1],p[C,1])]*r[B][15][0,2]*r[C][54][3,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,0],p[C,0])]*r[B][33][0,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,0],p[C,0])]*r[B][48][0,2]*r[C][24][3,3]
    hv += g[dei(p[B,1],p[B,0],p[C,0],p[C,0])]*r[B][33][0,2]*r[C][24][3,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,1],p[C,1])]*r[B][33][0,2]*r[C][39][3,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,1],p[C,1])]*r[B][48][0,2]*r[C][54][3,3]
    hv += g[dei(p[B,1],p[B,0],p[C,1],p[C,1])]*r[B][33][0,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,0],p[B,1])]*r[B][15][0,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,0],p[B,1])]*r[B][30][0,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,1],p[B,1])]*r[B][15][0,2]*r[C][39][3,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,1],p[B,1])]*r[B][30][0,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,0],p[B,0])]*r[B][33][0,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,0],p[B,0])]*r[B][48][0,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,1],p[B,0])]*r[B][33][0,2]*r[C][39][3,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,1],p[B,0])]*r[B][48][0,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,0],p[C,0])]*r[B][15][0,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,0],p[C,0])]*r[B][30][0,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,1],p[C,0])]*r[B][33][0,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,1],p[C,0])]*r[B][48][0,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,0],p[C,1])]*r[B][15][0,2]*r[C][39][3,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,0],p[C,1])]*r[B][30][0,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,1],p[C,1])]*r[B][33][0,2]*r[C][39][3,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,1],p[C,1])]*r[B][48][0,2]*r[C][54][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,0],p[B,1])]*r[B][15][0,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][24][3,3]
    hv += g[dei(p[C,0],p[C,0],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,1],p[B,0])]*r[B][33][0,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][24][3,3]
    hv += g[dei(p[C,0],p[C,0],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,0],p[B,1])]*r[B][15][0,2]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][54][3,3]
    hv += g[dei(p[C,1],p[C,1],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,1],p[B,0])]*r[B][33][0,2]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][54][3,3]
    hv += g[dei(p[C,1],p[C,1],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][39][3,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A1B1C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,1),(C,3)]))
    hv = 0.0
    
    hv += h[p[B,0],p[B,1]]*r[B][15][1,2]
    hv += h[p[B,0],p[B,1]]*r[B][30][1,2]
    hv += h[p[B,1],p[B,0]]*r[B][33][1,2]
    hv += h[p[B,1],p[B,0]]*r[B][48][1,2]
    hv += g[dei(p[B,0],p[B,0],p[B,0],p[B,1])]*r[B][198][1,2]
    hv += g[dei(p[B,0],p[B,1],p[B,0],p[B,0])]*r[B][195][1,2]
    hv += g[dei(p[B,1],p[B,0],p[B,1],p[B,1])]*r[B][278][1,2]
    hv += g[dei(p[B,1],p[B,1],p[B,1],p[B,0])]*r[B][275][1,2]
    hv += sum(1/2*g[dei(p[B,0],p[B,1],p[I,0],p[I,0])]*r[B][15][1,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[B,1],p[I,0],p[I,0])]*r[B][30][1,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,0],p[B,1],p[I,0],p[I,0])]*r[B][15][1,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[B,1],p[I,1],p[I,1])]*r[B][15][1,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[B,1],p[I,1],p[I,1])]*r[B][30][1,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,0],p[B,1],p[I,1],p[I,1])]*r[B][15][1,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[B,0],p[I,0],p[I,0])]*r[B][33][1,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[B,0],p[I,0],p[I,0])]*r[B][48][1,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,1],p[B,0],p[I,0],p[I,0])]*r[B][33][1,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[B,0],p[I,1],p[I,1])]*r[B][33][1,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[B,0],p[I,1],p[I,1])]*r[B][48][1,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,1],p[B,0],p[I,1],p[I,1])]*r[B][33][1,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,0],p[I,0],p[B,1])]*r[B][15][1,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,0],p[I,0],p[B,1])]*r[B][30][1,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,1],p[I,1],p[B,1])]*r[B][15][1,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,1],p[I,1],p[B,1])]*r[B][30][1,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,0],p[I,0],p[B,0])]*r[B][33][1,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,0],p[I,0],p[B,0])]*r[B][48][1,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,1],p[I,1],p[B,0])]*r[B][33][1,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,1],p[I,1],p[B,0])]*r[B][48][1,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,1],p[B,0],p[I,0])]*r[B][15][1,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,1],p[B,0],p[I,0])]*r[B][30][1,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,0],p[B,1],p[I,0])]*r[B][33][1,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,0],p[B,1],p[I,0])]*r[B][48][1,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,1],p[B,0],p[I,1])]*r[B][15][1,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,1],p[B,0],p[I,1])]*r[B][30][1,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,0],p[B,1],p[I,1])]*r[B][33][1,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,0],p[B,1],p[I,1])]*r[B][48][1,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,0],p[B,1])]*r[B][15][1,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,0],p[B,1])]*r[B][30][1,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[B,0],p[B,1])]*r[B][30][1,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,1],p[B,0])]*r[B][33][1,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,1],p[B,0])]*r[B][48][1,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[B,1],p[B,0])]*r[B][48][1,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,0],p[B,1])]*r[B][15][1,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,0],p[B,1])]*r[B][30][1,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[B,0],p[B,1])]*r[B][30][1,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,1],p[B,0])]*r[B][33][1,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,1],p[B,0])]*r[B][48][1,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[B,1],p[B,0])]*r[B][48][1,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[B,1])]*r[A][9][1,1]*r[B][15][1,2]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[B,1])]*r[A][24][1,1]*r[B][30][1,2]
    hv += g[dei(p[A,0],p[A,0],p[B,0],p[B,1])]*r[A][9][1,1]*r[B][30][1,2]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[B,0])]*r[A][9][1,1]*r[B][33][1,2]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[B,0])]*r[A][24][1,1]*r[B][48][1,2]
    hv += g[dei(p[A,0],p[A,0],p[B,1],p[B,0])]*r[A][9][1,1]*r[B][48][1,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[B,1])]*r[A][39][1,1]*r[B][15][1,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[B,1])]*r[A][54][1,1]*r[B][30][1,2]
    hv += g[dei(p[A,1],p[A,1],p[B,0],p[B,1])]*r[A][39][1,1]*r[B][30][1,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[B,0])]*r[A][39][1,1]*r[B][33][1,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[B,0])]*r[A][54][1,1]*r[B][48][1,2]
    hv += g[dei(p[A,1],p[A,1],p[B,1],p[B,0])]*r[A][39][1,1]*r[B][48][1,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[A,0])]*r[A][9][1,1]*r[B][15][1,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[A,0])]*r[A][24][1,1]*r[B][30][1,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[A,0])]*r[A][9][1,1]*r[B][33][1,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[A,0])]*r[A][24][1,1]*r[B][48][1,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[A,1])]*r[A][39][1,1]*r[B][15][1,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[A,1])]*r[A][54][1,1]*r[B][30][1,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[A,1])]*r[A][39][1,1]*r[B][33][1,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[A,1])]*r[A][54][1,1]*r[B][48][1,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[B,1])]*r[A][9][1,1]*r[B][15][1,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[B,1])]*r[A][24][1,1]*r[B][30][1,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[B,1])]*r[A][39][1,1]*r[B][15][1,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[B,1])]*r[A][54][1,1]*r[B][30][1,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[B,0])]*r[A][9][1,1]*r[B][33][1,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[B,0])]*r[A][24][1,1]*r[B][48][1,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[B,0])]*r[A][39][1,1]*r[B][33][1,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[B,0])]*r[A][54][1,1]*r[B][48][1,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][15][1,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][30][1,2]
    hv += g[dei(p[B,0],p[B,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][15][1,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][15][1,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][30][1,2]
    hv += g[dei(p[B,0],p[B,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][15][1,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][33][1,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][48][1,2]
    hv += g[dei(p[B,1],p[B,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][33][1,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][33][1,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][48][1,2]
    hv += g[dei(p[B,1],p[B,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][33][1,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,0],p[C,0])]*r[B][15][1,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,0],p[C,0])]*r[B][30][1,2]*r[C][24][3,3]
    hv += g[dei(p[B,0],p[B,1],p[C,0],p[C,0])]*r[B][15][1,2]*r[C][24][3,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,1],p[C,1])]*r[B][15][1,2]*r[C][39][3,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,1],p[C,1])]*r[B][30][1,2]*r[C][54][3,3]
    hv += g[dei(p[B,0],p[B,1],p[C,1],p[C,1])]*r[B][15][1,2]*r[C][54][3,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,0],p[C,0])]*r[B][33][1,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,0],p[C,0])]*r[B][48][1,2]*r[C][24][3,3]
    hv += g[dei(p[B,1],p[B,0],p[C,0],p[C,0])]*r[B][33][1,2]*r[C][24][3,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,1],p[C,1])]*r[B][33][1,2]*r[C][39][3,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,1],p[C,1])]*r[B][48][1,2]*r[C][54][3,3]
    hv += g[dei(p[B,1],p[B,0],p[C,1],p[C,1])]*r[B][33][1,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,0],p[B,1])]*r[B][15][1,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,0],p[B,1])]*r[B][30][1,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,1],p[B,1])]*r[B][15][1,2]*r[C][39][3,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,1],p[B,1])]*r[B][30][1,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,0],p[B,0])]*r[B][33][1,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,0],p[B,0])]*r[B][48][1,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,1],p[B,0])]*r[B][33][1,2]*r[C][39][3,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,1],p[B,0])]*r[B][48][1,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,0],p[C,0])]*r[B][15][1,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,0],p[C,0])]*r[B][30][1,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,1],p[C,0])]*r[B][33][1,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,1],p[C,0])]*r[B][48][1,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,0],p[C,1])]*r[B][15][1,2]*r[C][39][3,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,0],p[C,1])]*r[B][30][1,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,1],p[C,1])]*r[B][33][1,2]*r[C][39][3,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,1],p[C,1])]*r[B][48][1,2]*r[C][54][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,0],p[B,1])]*r[B][15][1,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,0],p[B,1])]*r[B][30][1,2]*r[C][24][3,3]
    hv += g[dei(p[C,0],p[C,0],p[B,0],p[B,1])]*r[B][30][1,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,1],p[B,0])]*r[B][33][1,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,1],p[B,0])]*r[B][48][1,2]*r[C][24][3,3]
    hv += g[dei(p[C,0],p[C,0],p[B,1],p[B,0])]*r[B][48][1,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,0],p[B,1])]*r[B][15][1,2]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,0],p[B,1])]*r[B][30][1,2]*r[C][54][3,3]
    hv += g[dei(p[C,1],p[C,1],p[B,0],p[B,1])]*r[B][30][1,2]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,1],p[B,0])]*r[B][33][1,2]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,1],p[B,0])]*r[B][48][1,2]*r[C][54][3,3]
    hv += g[dei(p[C,1],p[C,1],p[B,1],p[B,0])]*r[B][48][1,2]*r[C][39][3,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A1B2C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,2),(C,2)]))
    hv = 0.0
    
    hv += h[p[C,0],p[C,0]]*r[C][9][2,3]
    hv += h[p[C,0],p[C,0]]*r[C][24][2,3]
    hv += h[p[C,1],p[C,1]]*r[C][39][2,3]
    hv += h[p[C,1],p[C,1]]*r[C][54][2,3]
    hv += g[dei(p[C,0],p[C,0],p[C,1],p[C,1])]*r[C][214][2,3]
    hv += g[dei(p[C,0],p[C,1],p[C,1],p[C,0])]*r[C][211][2,3]
    hv += g[dei(p[C,1],p[C,0],p[C,0],p[C,1])]*r[C][262][2,3]
    hv += g[dei(p[C,1],p[C,1],p[C,0],p[C,0])]*r[C][259][2,3]
    hv += sum(1/2*g[dei(p[C,0],p[C,0],p[I,0],p[I,0])]*r[C][9][2,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[C,0],p[I,0],p[I,0])]*r[C][24][2,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[C,0],p[C,0],p[I,0],p[I,0])]*r[C][9][2,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[C,0],p[I,1],p[I,1])]*r[C][9][2,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[C,0],p[I,1],p[I,1])]*r[C][24][2,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[C,0],p[C,0],p[I,1],p[I,1])]*r[C][9][2,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[C,1],p[I,0],p[I,0])]*r[C][39][2,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[C,1],p[I,0],p[I,0])]*r[C][54][2,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[C,1],p[C,1],p[I,0],p[I,0])]*r[C][39][2,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[C,1],p[I,1],p[I,1])]*r[C][39][2,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[C,1],p[I,1],p[I,1])]*r[C][54][2,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[C,1],p[C,1],p[I,1],p[I,1])]*r[C][39][2,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,0],p[I,0],p[C,0])]*r[C][9][2,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,0],p[I,0],p[C,0])]*r[C][24][2,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,1],p[I,1],p[C,0])]*r[C][9][2,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,1],p[I,1],p[C,0])]*r[C][24][2,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,0],p[I,0],p[C,1])]*r[C][39][2,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,0],p[I,0],p[C,1])]*r[C][54][2,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,1],p[I,1],p[C,1])]*r[C][39][2,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,1],p[I,1],p[C,1])]*r[C][54][2,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,0],p[C,0],p[I,0])]*r[C][9][2,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,0],p[C,0],p[I,0])]*r[C][24][2,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,1],p[C,1],p[I,0])]*r[C][39][2,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,1],p[C,1],p[I,0])]*r[C][54][2,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,0],p[C,0],p[I,1])]*r[C][9][2,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,0],p[C,0],p[I,1])]*r[C][24][2,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,1],p[C,1],p[I,1])]*r[C][39][2,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,1],p[C,1],p[I,1])]*r[C][54][2,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,0],p[C,0])]*r[C][9][2,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,0],p[C,0])]*r[C][24][2,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[C,0],p[C,0])]*r[C][24][2,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,1],p[C,1])]*r[C][39][2,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,1],p[C,1])]*r[C][54][2,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[C,1],p[C,1])]*r[C][54][2,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,0],p[C,0])]*r[C][9][2,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,0],p[C,0])]*r[C][24][2,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[C,0],p[C,0])]*r[C][24][2,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,1],p[C,1])]*r[C][39][2,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,1],p[C,1])]*r[C][54][2,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[C,1],p[C,1])]*r[C][54][2,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[C,0])]*r[A][9][1,1]*r[C][9][2,3]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[C,0])]*r[A][24][1,1]*r[C][24][2,3]
    hv += g[dei(p[A,0],p[A,0],p[C,0],p[C,0])]*r[A][9][1,1]*r[C][24][2,3]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[C,1])]*r[A][9][1,1]*r[C][39][2,3]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[C,1])]*r[A][24][1,1]*r[C][54][2,3]
    hv += g[dei(p[A,0],p[A,0],p[C,1],p[C,1])]*r[A][9][1,1]*r[C][54][2,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[C,0])]*r[A][39][1,1]*r[C][9][2,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[C,0])]*r[A][54][1,1]*r[C][24][2,3]
    hv += g[dei(p[A,1],p[A,1],p[C,0],p[C,0])]*r[A][39][1,1]*r[C][24][2,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[C,1])]*r[A][39][1,1]*r[C][39][2,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[C,1])]*r[A][54][1,1]*r[C][54][2,3]
    hv += g[dei(p[A,1],p[A,1],p[C,1],p[C,1])]*r[A][39][1,1]*r[C][54][2,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,0])]*r[A][9][1,1]*r[C][9][2,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,0])]*r[A][24][1,1]*r[C][24][2,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,0])]*r[A][9][1,1]*r[C][39][2,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,0])]*r[A][24][1,1]*r[C][54][2,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,1])]*r[A][39][1,1]*r[C][9][2,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,1])]*r[A][54][1,1]*r[C][24][2,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,1])]*r[A][39][1,1]*r[C][39][2,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,1])]*r[A][54][1,1]*r[C][54][2,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[C,0])]*r[A][9][1,1]*r[C][9][2,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[C,0])]*r[A][24][1,1]*r[C][24][2,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[C,0])]*r[A][39][1,1]*r[C][9][2,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[C,0])]*r[A][54][1,1]*r[C][24][2,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[C,1])]*r[A][9][1,1]*r[C][39][2,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[C,1])]*r[A][24][1,1]*r[C][54][2,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[C,1])]*r[A][39][1,1]*r[C][39][2,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[C,1])]*r[A][54][1,1]*r[C][54][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,0])]*r[A][9][1,1]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[C][24][2,3]
    hv += g[dei(p[C,0],p[C,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,1])]*r[A][39][1,1]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[C][24][2,3]
    hv += g[dei(p[C,0],p[C,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,0])]*r[A][9][1,1]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[C][54][2,3]
    hv += g[dei(p[C,1],p[C,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,1])]*r[A][39][1,1]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[C][54][2,3]
    hv += g[dei(p[C,1],p[C,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[C][39][2,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,0],p[C,0])]*r[B][9][2,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,0],p[C,0])]*r[B][24][2,2]*r[C][24][2,3]
    hv += g[dei(p[B,0],p[B,0],p[C,0],p[C,0])]*r[B][9][2,2]*r[C][24][2,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,1],p[C,1])]*r[B][9][2,2]*r[C][39][2,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,1],p[C,1])]*r[B][24][2,2]*r[C][54][2,3]
    hv += g[dei(p[B,0],p[B,0],p[C,1],p[C,1])]*r[B][9][2,2]*r[C][54][2,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,0],p[C,0])]*r[B][39][2,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,0],p[C,0])]*r[B][54][2,2]*r[C][24][2,3]
    hv += g[dei(p[B,1],p[B,1],p[C,0],p[C,0])]*r[B][39][2,2]*r[C][24][2,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,1],p[C,1])]*r[B][39][2,2]*r[C][39][2,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,1],p[C,1])]*r[B][54][2,2]*r[C][54][2,3]
    hv += g[dei(p[B,1],p[B,1],p[C,1],p[C,1])]*r[B][39][2,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,0],p[B,0])]*r[B][9][2,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,0],p[B,0])]*r[B][24][2,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,1],p[B,0])]*r[B][9][2,2]*r[C][39][2,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,1],p[B,0])]*r[B][24][2,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,0],p[B,1])]*r[B][39][2,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,0],p[B,1])]*r[B][54][2,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,1],p[B,1])]*r[B][39][2,2]*r[C][39][2,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,1],p[B,1])]*r[B][54][2,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,0],p[C,0])]*r[B][9][2,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,0],p[C,0])]*r[B][24][2,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,1],p[C,0])]*r[B][39][2,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,1],p[C,0])]*r[B][54][2,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,0],p[C,1])]*r[B][9][2,2]*r[C][39][2,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,0],p[C,1])]*r[B][24][2,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,1],p[C,1])]*r[B][39][2,2]*r[C][39][2,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,1],p[C,1])]*r[B][54][2,2]*r[C][54][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,0],p[B,0])]*r[B][9][2,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,0],p[B,0])]*r[B][24][2,2]*r[C][24][2,3]
    hv += g[dei(p[C,0],p[C,0],p[B,0],p[B,0])]*r[B][24][2,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,1],p[B,1])]*r[B][39][2,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,1],p[B,1])]*r[B][54][2,2]*r[C][24][2,3]
    hv += g[dei(p[C,0],p[C,0],p[B,1],p[B,1])]*r[B][54][2,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,0],p[B,0])]*r[B][9][2,2]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,0],p[B,0])]*r[B][24][2,2]*r[C][54][2,3]
    hv += g[dei(p[C,1],p[C,1],p[B,0],p[B,0])]*r[B][24][2,2]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,1],p[B,1])]*r[B][39][2,2]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,1],p[B,1])]*r[B][54][2,2]*r[C][54][2,3]
    hv += g[dei(p[C,1],p[C,1],p[B,1],p[B,1])]*r[B][54][2,2]*r[C][39][2,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A1B2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,2)]))
    hv = 0.0
    
    hv += h[p[C,0],p[C,1]]*r[C][15][0,3]
    hv += h[p[C,0],p[C,1]]*r[C][30][0,3]
    hv += h[p[C,1],p[C,0]]*r[C][33][0,3]
    hv += h[p[C,1],p[C,0]]*r[C][48][0,3]
    hv += g[dei(p[C,0],p[C,0],p[C,0],p[C,1])]*r[C][198][0,3]
    hv += g[dei(p[C,0],p[C,1],p[C,0],p[C,0])]*r[C][195][0,3]
    hv += g[dei(p[C,1],p[C,0],p[C,1],p[C,1])]*r[C][278][0,3]
    hv += g[dei(p[C,1],p[C,1],p[C,1],p[C,0])]*r[C][275][0,3]
    hv += sum(1/2*g[dei(p[C,0],p[C,1],p[I,0],p[I,0])]*r[C][15][0,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[C,1],p[I,0],p[I,0])]*r[C][30][0,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[C,0],p[C,1],p[I,0],p[I,0])]*r[C][15][0,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[C,1],p[I,1],p[I,1])]*r[C][15][0,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[C,1],p[I,1],p[I,1])]*r[C][30][0,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[C,0],p[C,1],p[I,1],p[I,1])]*r[C][15][0,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[C,0],p[I,0],p[I,0])]*r[C][33][0,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[C,0],p[I,0],p[I,0])]*r[C][48][0,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[C,1],p[C,0],p[I,0],p[I,0])]*r[C][33][0,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[C,0],p[I,1],p[I,1])]*r[C][33][0,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[C,0],p[I,1],p[I,1])]*r[C][48][0,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[C,1],p[C,0],p[I,1],p[I,1])]*r[C][33][0,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,0],p[I,0],p[C,1])]*r[C][15][0,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,0],p[I,0],p[C,1])]*r[C][30][0,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,1],p[I,1],p[C,1])]*r[C][15][0,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,1],p[I,1],p[C,1])]*r[C][30][0,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,0],p[I,0],p[C,0])]*r[C][33][0,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,0],p[I,0],p[C,0])]*r[C][48][0,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,1],p[I,1],p[C,0])]*r[C][33][0,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,1],p[I,1],p[C,0])]*r[C][48][0,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,1],p[C,0],p[I,0])]*r[C][15][0,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,1],p[C,0],p[I,0])]*r[C][30][0,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,0],p[C,1],p[I,0])]*r[C][33][0,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,0],p[C,1],p[I,0])]*r[C][48][0,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,1],p[C,0],p[I,1])]*r[C][15][0,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,1],p[C,0],p[I,1])]*r[C][30][0,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,0],p[C,1],p[I,1])]*r[C][33][0,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,0],p[C,1],p[I,1])]*r[C][48][0,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,0],p[C,1])]*r[C][15][0,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,0],p[C,1])]*r[C][30][0,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[C,0],p[C,1])]*r[C][30][0,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,1],p[C,0])]*r[C][33][0,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,1],p[C,0])]*r[C][48][0,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[C,1],p[C,0])]*r[C][48][0,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,0],p[C,1])]*r[C][15][0,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,0],p[C,1])]*r[C][30][0,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[C,0],p[C,1])]*r[C][30][0,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,1],p[C,0])]*r[C][33][0,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,1],p[C,0])]*r[C][48][0,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[C,1],p[C,0])]*r[C][48][0,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[C,1])]*r[A][9][1,1]*r[C][15][0,3]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[C,1])]*r[A][24][1,1]*r[C][30][0,3]
    hv += g[dei(p[A,0],p[A,0],p[C,0],p[C,1])]*r[A][9][1,1]*r[C][30][0,3]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[C,0])]*r[A][9][1,1]*r[C][33][0,3]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[C,0])]*r[A][24][1,1]*r[C][48][0,3]
    hv += g[dei(p[A,0],p[A,0],p[C,1],p[C,0])]*r[A][9][1,1]*r[C][48][0,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[C,1])]*r[A][39][1,1]*r[C][15][0,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[C,1])]*r[A][54][1,1]*r[C][30][0,3]
    hv += g[dei(p[A,1],p[A,1],p[C,0],p[C,1])]*r[A][39][1,1]*r[C][30][0,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[C,0])]*r[A][39][1,1]*r[C][33][0,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[C,0])]*r[A][54][1,1]*r[C][48][0,3]
    hv += g[dei(p[A,1],p[A,1],p[C,1],p[C,0])]*r[A][39][1,1]*r[C][48][0,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[A,0])]*r[A][9][1,1]*r[C][15][0,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[A,0])]*r[A][24][1,1]*r[C][30][0,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[A,0])]*r[A][9][1,1]*r[C][33][0,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[A,0])]*r[A][24][1,1]*r[C][48][0,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[A,1])]*r[A][39][1,1]*r[C][15][0,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[A,1])]*r[A][54][1,1]*r[C][30][0,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[A,1])]*r[A][39][1,1]*r[C][33][0,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[A,1])]*r[A][54][1,1]*r[C][48][0,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[C,1])]*r[A][9][1,1]*r[C][15][0,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[C,1])]*r[A][24][1,1]*r[C][30][0,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[C,1])]*r[A][39][1,1]*r[C][15][0,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[C,1])]*r[A][54][1,1]*r[C][30][0,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[C,0])]*r[A][9][1,1]*r[C][33][0,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[C,0])]*r[A][24][1,1]*r[C][48][0,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[C,0])]*r[A][39][1,1]*r[C][33][0,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[C,0])]*r[A][54][1,1]*r[C][48][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[A,0])]*r[A][9][1,1]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[C][30][0,3]
    hv += g[dei(p[C,0],p[C,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[A,1])]*r[A][39][1,1]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[C][30][0,3]
    hv += g[dei(p[C,0],p[C,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[A,0])]*r[A][9][1,1]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[C][48][0,3]
    hv += g[dei(p[C,1],p[C,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[A,1])]*r[A][39][1,1]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[C][48][0,3]
    hv += g[dei(p[C,1],p[C,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[C][33][0,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,0],p[C,1])]*r[B][9][2,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,0],p[C,1])]*r[B][24][2,2]*r[C][30][0,3]
    hv += g[dei(p[B,0],p[B,0],p[C,0],p[C,1])]*r[B][9][2,2]*r[C][30][0,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,1],p[C,0])]*r[B][9][2,2]*r[C][33][0,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,1],p[C,0])]*r[B][24][2,2]*r[C][48][0,3]
    hv += g[dei(p[B,0],p[B,0],p[C,1],p[C,0])]*r[B][9][2,2]*r[C][48][0,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,0],p[C,1])]*r[B][39][2,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,0],p[C,1])]*r[B][54][2,2]*r[C][30][0,3]
    hv += g[dei(p[B,1],p[B,1],p[C,0],p[C,1])]*r[B][39][2,2]*r[C][30][0,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,1],p[C,0])]*r[B][39][2,2]*r[C][33][0,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,1],p[C,0])]*r[B][54][2,2]*r[C][48][0,3]
    hv += g[dei(p[B,1],p[B,1],p[C,1],p[C,0])]*r[B][39][2,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,0],p[B,0])]*r[B][9][2,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,0],p[B,0])]*r[B][24][2,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,1],p[B,0])]*r[B][9][2,2]*r[C][33][0,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,1],p[B,0])]*r[B][24][2,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,0],p[B,1])]*r[B][39][2,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,0],p[B,1])]*r[B][54][2,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,1],p[B,1])]*r[B][39][2,2]*r[C][33][0,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,1],p[B,1])]*r[B][54][2,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,0],p[C,1])]*r[B][9][2,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,0],p[C,1])]*r[B][24][2,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,1],p[C,1])]*r[B][39][2,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,1],p[C,1])]*r[B][54][2,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,0],p[C,0])]*r[B][9][2,2]*r[C][33][0,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,0],p[C,0])]*r[B][24][2,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,1],p[C,0])]*r[B][39][2,2]*r[C][33][0,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,1],p[C,0])]*r[B][54][2,2]*r[C][48][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,0],p[B,0])]*r[B][9][2,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,0],p[B,0])]*r[B][24][2,2]*r[C][30][0,3]
    hv += g[dei(p[C,0],p[C,1],p[B,0],p[B,0])]*r[B][24][2,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,1],p[B,1])]*r[B][39][2,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,1],p[B,1])]*r[B][54][2,2]*r[C][30][0,3]
    hv += g[dei(p[C,0],p[C,1],p[B,1],p[B,1])]*r[B][54][2,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,0],p[B,0])]*r[B][9][2,2]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,0],p[B,0])]*r[B][24][2,2]*r[C][48][0,3]
    hv += g[dei(p[C,1],p[C,0],p[B,0],p[B,0])]*r[B][24][2,2]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,1],p[B,1])]*r[B][39][2,2]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,1],p[B,1])]*r[B][54][2,2]*r[C][48][0,3]
    hv += g[dei(p[C,1],p[C,0],p[B,1],p[B,1])]*r[B][54][2,2]*r[C][33][0,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A1B2C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,2),(C,1)]))
    hv = 0.0
    
    hv += h[p[C,0],p[C,1]]*r[C][15][1,3]
    hv += h[p[C,0],p[C,1]]*r[C][30][1,3]
    hv += h[p[C,1],p[C,0]]*r[C][33][1,3]
    hv += h[p[C,1],p[C,0]]*r[C][48][1,3]
    hv += g[dei(p[C,0],p[C,0],p[C,0],p[C,1])]*r[C][198][1,3]
    hv += g[dei(p[C,0],p[C,1],p[C,0],p[C,0])]*r[C][195][1,3]
    hv += g[dei(p[C,1],p[C,0],p[C,1],p[C,1])]*r[C][278][1,3]
    hv += g[dei(p[C,1],p[C,1],p[C,1],p[C,0])]*r[C][275][1,3]
    hv += sum(1/2*g[dei(p[C,0],p[C,1],p[I,0],p[I,0])]*r[C][15][1,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[C,1],p[I,0],p[I,0])]*r[C][30][1,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[C,0],p[C,1],p[I,0],p[I,0])]*r[C][15][1,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[C,1],p[I,1],p[I,1])]*r[C][15][1,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[C,1],p[I,1],p[I,1])]*r[C][30][1,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[C,0],p[C,1],p[I,1],p[I,1])]*r[C][15][1,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[C,0],p[I,0],p[I,0])]*r[C][33][1,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[C,0],p[I,0],p[I,0])]*r[C][48][1,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[C,1],p[C,0],p[I,0],p[I,0])]*r[C][33][1,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[C,0],p[I,1],p[I,1])]*r[C][33][1,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[C,0],p[I,1],p[I,1])]*r[C][48][1,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[C,1],p[C,0],p[I,1],p[I,1])]*r[C][33][1,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,0],p[I,0],p[C,1])]*r[C][15][1,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,0],p[I,0],p[C,1])]*r[C][30][1,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,1],p[I,1],p[C,1])]*r[C][15][1,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,1],p[I,1],p[C,1])]*r[C][30][1,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,0],p[I,0],p[C,0])]*r[C][33][1,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,0],p[I,0],p[C,0])]*r[C][48][1,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,1],p[I,1],p[C,0])]*r[C][33][1,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,1],p[I,1],p[C,0])]*r[C][48][1,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,1],p[C,0],p[I,0])]*r[C][15][1,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,1],p[C,0],p[I,0])]*r[C][30][1,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,0],p[C,1],p[I,0])]*r[C][33][1,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,0],p[C,1],p[I,0])]*r[C][48][1,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,1],p[C,0],p[I,1])]*r[C][15][1,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,1],p[C,0],p[I,1])]*r[C][30][1,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,0],p[C,1],p[I,1])]*r[C][33][1,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,0],p[C,1],p[I,1])]*r[C][48][1,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,0],p[C,1])]*r[C][15][1,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,0],p[C,1])]*r[C][30][1,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[C,0],p[C,1])]*r[C][30][1,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,1],p[C,0])]*r[C][33][1,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,1],p[C,0])]*r[C][48][1,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[C,1],p[C,0])]*r[C][48][1,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,0],p[C,1])]*r[C][15][1,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,0],p[C,1])]*r[C][30][1,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[C,0],p[C,1])]*r[C][30][1,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,1],p[C,0])]*r[C][33][1,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,1],p[C,0])]*r[C][48][1,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[C,1],p[C,0])]*r[C][48][1,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[C,1])]*r[A][9][1,1]*r[C][15][1,3]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[C,1])]*r[A][24][1,1]*r[C][30][1,3]
    hv += g[dei(p[A,0],p[A,0],p[C,0],p[C,1])]*r[A][9][1,1]*r[C][30][1,3]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[C,0])]*r[A][9][1,1]*r[C][33][1,3]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[C,0])]*r[A][24][1,1]*r[C][48][1,3]
    hv += g[dei(p[A,0],p[A,0],p[C,1],p[C,0])]*r[A][9][1,1]*r[C][48][1,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[C,1])]*r[A][39][1,1]*r[C][15][1,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[C,1])]*r[A][54][1,1]*r[C][30][1,3]
    hv += g[dei(p[A,1],p[A,1],p[C,0],p[C,1])]*r[A][39][1,1]*r[C][30][1,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[C,0])]*r[A][39][1,1]*r[C][33][1,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[C,0])]*r[A][54][1,1]*r[C][48][1,3]
    hv += g[dei(p[A,1],p[A,1],p[C,1],p[C,0])]*r[A][39][1,1]*r[C][48][1,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[A,0])]*r[A][9][1,1]*r[C][15][1,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[A,0])]*r[A][24][1,1]*r[C][30][1,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[A,0])]*r[A][9][1,1]*r[C][33][1,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[A,0])]*r[A][24][1,1]*r[C][48][1,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[A,1])]*r[A][39][1,1]*r[C][15][1,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[A,1])]*r[A][54][1,1]*r[C][30][1,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[A,1])]*r[A][39][1,1]*r[C][33][1,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[A,1])]*r[A][54][1,1]*r[C][48][1,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[C,1])]*r[A][9][1,1]*r[C][15][1,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[C,1])]*r[A][24][1,1]*r[C][30][1,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[C,1])]*r[A][39][1,1]*r[C][15][1,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[C,1])]*r[A][54][1,1]*r[C][30][1,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[C,0])]*r[A][9][1,1]*r[C][33][1,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[C,0])]*r[A][24][1,1]*r[C][48][1,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[C,0])]*r[A][39][1,1]*r[C][33][1,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[C,0])]*r[A][54][1,1]*r[C][48][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[A,0])]*r[A][9][1,1]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[C][30][1,3]
    hv += g[dei(p[C,0],p[C,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[A,1])]*r[A][39][1,1]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[C][30][1,3]
    hv += g[dei(p[C,0],p[C,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[A,0])]*r[A][9][1,1]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[C][48][1,3]
    hv += g[dei(p[C,1],p[C,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[A,1])]*r[A][39][1,1]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[C][48][1,3]
    hv += g[dei(p[C,1],p[C,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[C][33][1,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,0],p[C,1])]*r[B][9][2,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,0],p[C,1])]*r[B][24][2,2]*r[C][30][1,3]
    hv += g[dei(p[B,0],p[B,0],p[C,0],p[C,1])]*r[B][9][2,2]*r[C][30][1,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,1],p[C,0])]*r[B][9][2,2]*r[C][33][1,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,1],p[C,0])]*r[B][24][2,2]*r[C][48][1,3]
    hv += g[dei(p[B,0],p[B,0],p[C,1],p[C,0])]*r[B][9][2,2]*r[C][48][1,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,0],p[C,1])]*r[B][39][2,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,0],p[C,1])]*r[B][54][2,2]*r[C][30][1,3]
    hv += g[dei(p[B,1],p[B,1],p[C,0],p[C,1])]*r[B][39][2,2]*r[C][30][1,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,1],p[C,0])]*r[B][39][2,2]*r[C][33][1,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,1],p[C,0])]*r[B][54][2,2]*r[C][48][1,3]
    hv += g[dei(p[B,1],p[B,1],p[C,1],p[C,0])]*r[B][39][2,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,0],p[B,0])]*r[B][9][2,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,0],p[B,0])]*r[B][24][2,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,1],p[B,0])]*r[B][9][2,2]*r[C][33][1,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,1],p[B,0])]*r[B][24][2,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,0],p[B,1])]*r[B][39][2,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,0],p[B,1])]*r[B][54][2,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,1],p[B,1])]*r[B][39][2,2]*r[C][33][1,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,1],p[B,1])]*r[B][54][2,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,0],p[C,1])]*r[B][9][2,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,0],p[C,1])]*r[B][24][2,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,1],p[C,1])]*r[B][39][2,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,1],p[C,1])]*r[B][54][2,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,0],p[C,0])]*r[B][9][2,2]*r[C][33][1,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,0],p[C,0])]*r[B][24][2,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,1],p[C,0])]*r[B][39][2,2]*r[C][33][1,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,1],p[C,0])]*r[B][54][2,2]*r[C][48][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,0],p[B,0])]*r[B][9][2,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,0],p[B,0])]*r[B][24][2,2]*r[C][30][1,3]
    hv += g[dei(p[C,0],p[C,1],p[B,0],p[B,0])]*r[B][24][2,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,1],p[B,1])]*r[B][39][2,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,1],p[B,1])]*r[B][54][2,2]*r[C][30][1,3]
    hv += g[dei(p[C,0],p[C,1],p[B,1],p[B,1])]*r[B][54][2,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,0],p[B,0])]*r[B][9][2,2]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,0],p[B,0])]*r[B][24][2,2]*r[C][48][1,3]
    hv += g[dei(p[C,1],p[C,0],p[B,0],p[B,0])]*r[B][24][2,2]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,1],p[B,1])]*r[B][39][2,2]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,1],p[B,1])]*r[B][54][2,2]*r[C][48][1,3]
    hv += g[dei(p[C,1],p[C,0],p[B,1],p[B,1])]*r[B][54][2,2]*r[C][33][1,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _B2C3I1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,2),(C,3),(I,1)]))
        hv = 0.0
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][9][0,1]*r[I][9][1,0]
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][24][0,1]*r[I][24][1,0]
        hv += g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][9][0,1]*r[I][24][1,0]
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][9][0,1]*r[I][39][1,0]
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][24][0,1]*r[I][54][1,0]
        hv += g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][9][0,1]*r[I][54][1,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,0],p[I,0])]*r[A][39][0,1]*r[I][9][1,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,0],p[I,0])]*r[A][54][0,1]*r[I][24][1,0]
        hv += g[dei(p[A,1],p[A,1],p[I,0],p[I,0])]*r[A][39][0,1]*r[I][24][1,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,1],p[I,1])]*r[A][39][0,1]*r[I][39][1,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,1],p[I,1])]*r[A][54][0,1]*r[I][54][1,0]
        hv += g[dei(p[A,1],p[A,1],p[I,1],p[I,1])]*r[A][39][0,1]*r[I][54][1,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,0])]*r[A][9][0,1]*r[I][9][1,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,0])]*r[A][24][0,1]*r[I][24][1,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,0])]*r[A][9][0,1]*r[I][39][1,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,0])]*r[A][24][0,1]*r[I][54][1,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,1])]*r[A][39][0,1]*r[I][9][1,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,1])]*r[A][54][0,1]*r[I][24][1,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,1])]*r[A][39][0,1]*r[I][39][1,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,1])]*r[A][54][0,1]*r[I][54][1,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,0])]*r[A][9][0,1]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,0])]*r[A][24][0,1]*r[I][24][1,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,1],p[I,0])]*r[A][39][0,1]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,1],p[I,0])]*r[A][54][0,1]*r[I][24][1,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,1])]*r[A][9][0,1]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,1])]*r[A][24][0,1]*r[I][54][1,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,1],p[I,1])]*r[A][39][0,1]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,1],p[I,1])]*r[A][54][0,1]*r[I][54][1,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][24][1,0]
        hv += g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][24][1,0]
        hv += g[dei(p[I,0],p[I,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][54][1,0]
        hv += g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][54][1,0]
        hv += g[dei(p[I,1],p[I,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    return hd
    
def _B2C3I2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,2),(C,3),(I,2)]))
        hv = 0.0
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,1])]*r[A][9][0,1]*r[I][15][2,0]
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,1])]*r[A][24][0,1]*r[I][30][2,0]
        hv += g[dei(p[A,0],p[A,0],p[I,0],p[I,1])]*r[A][9][0,1]*r[I][30][2,0]
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,0])]*r[A][9][0,1]*r[I][33][2,0]
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,0])]*r[A][24][0,1]*r[I][48][2,0]
        hv += g[dei(p[A,0],p[A,0],p[I,1],p[I,0])]*r[A][9][0,1]*r[I][48][2,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,0],p[I,1])]*r[A][39][0,1]*r[I][15][2,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,0],p[I,1])]*r[A][54][0,1]*r[I][30][2,0]
        hv += g[dei(p[A,1],p[A,1],p[I,0],p[I,1])]*r[A][39][0,1]*r[I][30][2,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,1],p[I,0])]*r[A][39][0,1]*r[I][33][2,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,1],p[I,0])]*r[A][54][0,1]*r[I][48][2,0]
        hv += g[dei(p[A,1],p[A,1],p[I,1],p[I,0])]*r[A][39][0,1]*r[I][48][2,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[I,0],p[A,0])]*r[A][9][0,1]*r[I][15][2,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[I,0],p[A,0])]*r[A][24][0,1]*r[I][30][2,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[I,1],p[A,0])]*r[A][9][0,1]*r[I][33][2,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[I,1],p[A,0])]*r[A][24][0,1]*r[I][48][2,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[I,0],p[A,1])]*r[A][39][0,1]*r[I][15][2,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[I,0],p[A,1])]*r[A][54][0,1]*r[I][30][2,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[I,1],p[A,1])]*r[A][39][0,1]*r[I][33][2,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[I,1],p[A,1])]*r[A][54][0,1]*r[I][48][2,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,1])]*r[A][9][0,1]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,1])]*r[A][24][0,1]*r[I][30][2,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,1],p[I,1])]*r[A][39][0,1]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,1],p[I,1])]*r[A][54][0,1]*r[I][30][2,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,0])]*r[A][9][0,1]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,0])]*r[A][24][0,1]*r[I][48][2,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,1],p[I,0])]*r[A][39][0,1]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,1],p[I,0])]*r[A][54][0,1]*r[I][48][2,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][30][2,0]
        hv += g[dei(p[I,0],p[I,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][30][2,0]
        hv += g[dei(p[I,0],p[I,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][48][2,0]
        hv += g[dei(p[I,1],p[I,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][48][2,0]
        hv += g[dei(p[I,1],p[I,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    return hd
    
def _B2C3I3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,2),(C,3),(I,3)]))
        hv = 0.0
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,1])]*r[A][9][0,1]*r[I][15][3,0]
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,1])]*r[A][24][0,1]*r[I][30][3,0]
        hv += g[dei(p[A,0],p[A,0],p[I,0],p[I,1])]*r[A][9][0,1]*r[I][30][3,0]
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,0])]*r[A][9][0,1]*r[I][33][3,0]
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,0])]*r[A][24][0,1]*r[I][48][3,0]
        hv += g[dei(p[A,0],p[A,0],p[I,1],p[I,0])]*r[A][9][0,1]*r[I][48][3,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,0],p[I,1])]*r[A][39][0,1]*r[I][15][3,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,0],p[I,1])]*r[A][54][0,1]*r[I][30][3,0]
        hv += g[dei(p[A,1],p[A,1],p[I,0],p[I,1])]*r[A][39][0,1]*r[I][30][3,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,1],p[I,0])]*r[A][39][0,1]*r[I][33][3,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,1],p[I,0])]*r[A][54][0,1]*r[I][48][3,0]
        hv += g[dei(p[A,1],p[A,1],p[I,1],p[I,0])]*r[A][39][0,1]*r[I][48][3,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[I,0],p[A,0])]*r[A][9][0,1]*r[I][15][3,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[I,0],p[A,0])]*r[A][24][0,1]*r[I][30][3,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[I,1],p[A,0])]*r[A][9][0,1]*r[I][33][3,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[I,1],p[A,0])]*r[A][24][0,1]*r[I][48][3,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[I,0],p[A,1])]*r[A][39][0,1]*r[I][15][3,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[I,0],p[A,1])]*r[A][54][0,1]*r[I][30][3,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[I,1],p[A,1])]*r[A][39][0,1]*r[I][33][3,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[I,1],p[A,1])]*r[A][54][0,1]*r[I][48][3,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,1])]*r[A][9][0,1]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,1])]*r[A][24][0,1]*r[I][30][3,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,1],p[I,1])]*r[A][39][0,1]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,1],p[I,1])]*r[A][54][0,1]*r[I][30][3,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,0])]*r[A][9][0,1]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,0])]*r[A][24][0,1]*r[I][48][3,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,1],p[I,0])]*r[A][39][0,1]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,1],p[I,0])]*r[A][54][0,1]*r[I][48][3,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][30][3,0]
        hv += g[dei(p[I,0],p[I,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][30][3,0]
        hv += g[dei(p[I,0],p[I,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][48][3,0]
        hv += g[dei(p[I,1],p[I,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][48][3,0]
        hv += g[dei(p[I,1],p[I,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    return hd
    
def _A1C3I1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,3),(I,1)]))
        hv = 0.0
        
        hv += 1/2*g[dei(p[B,0],p[B,1],p[I,0],p[I,0])]*r[B][15][0,2]*r[I][9][1,0]
        hv += 1/2*g[dei(p[B,0],p[B,1],p[I,0],p[I,0])]*r[B][30][0,2]*r[I][24][1,0]
        hv += g[dei(p[B,0],p[B,1],p[I,0],p[I,0])]*r[B][15][0,2]*r[I][24][1,0]
        hv += 1/2*g[dei(p[B,0],p[B,1],p[I,1],p[I,1])]*r[B][15][0,2]*r[I][39][1,0]
        hv += 1/2*g[dei(p[B,0],p[B,1],p[I,1],p[I,1])]*r[B][30][0,2]*r[I][54][1,0]
        hv += g[dei(p[B,0],p[B,1],p[I,1],p[I,1])]*r[B][15][0,2]*r[I][54][1,0]
        hv += 1/2*g[dei(p[B,1],p[B,0],p[I,0],p[I,0])]*r[B][33][0,2]*r[I][9][1,0]
        hv += 1/2*g[dei(p[B,1],p[B,0],p[I,0],p[I,0])]*r[B][48][0,2]*r[I][24][1,0]
        hv += g[dei(p[B,1],p[B,0],p[I,0],p[I,0])]*r[B][33][0,2]*r[I][24][1,0]
        hv += 1/2*g[dei(p[B,1],p[B,0],p[I,1],p[I,1])]*r[B][33][0,2]*r[I][39][1,0]
        hv += 1/2*g[dei(p[B,1],p[B,0],p[I,1],p[I,1])]*r[B][48][0,2]*r[I][54][1,0]
        hv += g[dei(p[B,1],p[B,0],p[I,1],p[I,1])]*r[B][33][0,2]*r[I][54][1,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[I,0],p[B,1])]*r[B][15][0,2]*r[I][9][1,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[I,0],p[B,1])]*r[B][30][0,2]*r[I][24][1,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[I,1],p[B,1])]*r[B][15][0,2]*r[I][39][1,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[I,1],p[B,1])]*r[B][30][0,2]*r[I][54][1,0]
        hv += -1/2*g[dei(p[B,1],p[I,0],p[I,0],p[B,0])]*r[B][33][0,2]*r[I][9][1,0]
        hv += -1/2*g[dei(p[B,1],p[I,0],p[I,0],p[B,0])]*r[B][48][0,2]*r[I][24][1,0]
        hv += -1/2*g[dei(p[B,1],p[I,1],p[I,1],p[B,0])]*r[B][33][0,2]*r[I][39][1,0]
        hv += -1/2*g[dei(p[B,1],p[I,1],p[I,1],p[B,0])]*r[B][48][0,2]*r[I][54][1,0]
        hv += -1/2*g[dei(p[I,0],p[B,1],p[B,0],p[I,0])]*r[B][15][0,2]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,0],p[B,1],p[B,0],p[I,0])]*r[B][30][0,2]*r[I][24][1,0]
        hv += -1/2*g[dei(p[I,0],p[B,0],p[B,1],p[I,0])]*r[B][33][0,2]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,0],p[B,0],p[B,1],p[I,0])]*r[B][48][0,2]*r[I][24][1,0]
        hv += -1/2*g[dei(p[I,1],p[B,1],p[B,0],p[I,1])]*r[B][15][0,2]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,1],p[B,1],p[B,0],p[I,1])]*r[B][30][0,2]*r[I][54][1,0]
        hv += -1/2*g[dei(p[I,1],p[B,0],p[B,1],p[I,1])]*r[B][33][0,2]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,1],p[B,0],p[B,1],p[I,1])]*r[B][48][0,2]*r[I][54][1,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[B,0],p[B,1])]*r[B][15][0,2]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[B,0],p[B,1])]*r[B][30][0,2]*r[I][24][1,0]
        hv += g[dei(p[I,0],p[I,0],p[B,0],p[B,1])]*r[B][30][0,2]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[B,1],p[B,0])]*r[B][33][0,2]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[B,1],p[B,0])]*r[B][48][0,2]*r[I][24][1,0]
        hv += g[dei(p[I,0],p[I,0],p[B,1],p[B,0])]*r[B][48][0,2]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[B,0],p[B,1])]*r[B][15][0,2]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[B,0],p[B,1])]*r[B][30][0,2]*r[I][54][1,0]
        hv += g[dei(p[I,1],p[I,1],p[B,0],p[B,1])]*r[B][30][0,2]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[B,1],p[B,0])]*r[B][33][0,2]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[B,1],p[B,0])]*r[B][48][0,2]*r[I][54][1,0]
        hv += g[dei(p[I,1],p[I,1],p[B,1],p[B,0])]*r[B][48][0,2]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    return hd
    
def _A1C3I2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,3),(I,2)]))
        hv = 0.0
        
        hv += 1/2*g[dei(p[B,0],p[B,1],p[I,0],p[I,1])]*r[B][15][0,2]*r[I][15][2,0]
        hv += 1/2*g[dei(p[B,0],p[B,1],p[I,0],p[I,1])]*r[B][30][0,2]*r[I][30][2,0]
        hv += g[dei(p[B,0],p[B,1],p[I,0],p[I,1])]*r[B][15][0,2]*r[I][30][2,0]
        hv += 1/2*g[dei(p[B,0],p[B,1],p[I,1],p[I,0])]*r[B][15][0,2]*r[I][33][2,0]
        hv += 1/2*g[dei(p[B,0],p[B,1],p[I,1],p[I,0])]*r[B][30][0,2]*r[I][48][2,0]
        hv += g[dei(p[B,0],p[B,1],p[I,1],p[I,0])]*r[B][15][0,2]*r[I][48][2,0]
        hv += 1/2*g[dei(p[B,1],p[B,0],p[I,0],p[I,1])]*r[B][33][0,2]*r[I][15][2,0]
        hv += 1/2*g[dei(p[B,1],p[B,0],p[I,0],p[I,1])]*r[B][48][0,2]*r[I][30][2,0]
        hv += g[dei(p[B,1],p[B,0],p[I,0],p[I,1])]*r[B][33][0,2]*r[I][30][2,0]
        hv += 1/2*g[dei(p[B,1],p[B,0],p[I,1],p[I,0])]*r[B][33][0,2]*r[I][33][2,0]
        hv += 1/2*g[dei(p[B,1],p[B,0],p[I,1],p[I,0])]*r[B][48][0,2]*r[I][48][2,0]
        hv += g[dei(p[B,1],p[B,0],p[I,1],p[I,0])]*r[B][33][0,2]*r[I][48][2,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[I,0],p[B,1])]*r[B][15][0,2]*r[I][15][2,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[I,0],p[B,1])]*r[B][30][0,2]*r[I][30][2,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[I,1],p[B,1])]*r[B][15][0,2]*r[I][33][2,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[I,1],p[B,1])]*r[B][30][0,2]*r[I][48][2,0]
        hv += -1/2*g[dei(p[B,1],p[I,1],p[I,0],p[B,0])]*r[B][33][0,2]*r[I][15][2,0]
        hv += -1/2*g[dei(p[B,1],p[I,1],p[I,0],p[B,0])]*r[B][48][0,2]*r[I][30][2,0]
        hv += -1/2*g[dei(p[B,1],p[I,0],p[I,1],p[B,0])]*r[B][33][0,2]*r[I][33][2,0]
        hv += -1/2*g[dei(p[B,1],p[I,0],p[I,1],p[B,0])]*r[B][48][0,2]*r[I][48][2,0]
        hv += -1/2*g[dei(p[I,0],p[B,1],p[B,0],p[I,1])]*r[B][15][0,2]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,0],p[B,1],p[B,0],p[I,1])]*r[B][30][0,2]*r[I][30][2,0]
        hv += -1/2*g[dei(p[I,0],p[B,0],p[B,1],p[I,1])]*r[B][33][0,2]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,0],p[B,0],p[B,1],p[I,1])]*r[B][48][0,2]*r[I][30][2,0]
        hv += -1/2*g[dei(p[I,1],p[B,1],p[B,0],p[I,0])]*r[B][15][0,2]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,1],p[B,1],p[B,0],p[I,0])]*r[B][30][0,2]*r[I][48][2,0]
        hv += -1/2*g[dei(p[I,1],p[B,0],p[B,1],p[I,0])]*r[B][33][0,2]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,1],p[B,0],p[B,1],p[I,0])]*r[B][48][0,2]*r[I][48][2,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[B,0],p[B,1])]*r[B][15][0,2]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[B,0],p[B,1])]*r[B][30][0,2]*r[I][30][2,0]
        hv += g[dei(p[I,0],p[I,1],p[B,0],p[B,1])]*r[B][30][0,2]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[B,1],p[B,0])]*r[B][33][0,2]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[B,1],p[B,0])]*r[B][48][0,2]*r[I][30][2,0]
        hv += g[dei(p[I,0],p[I,1],p[B,1],p[B,0])]*r[B][48][0,2]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[B,0],p[B,1])]*r[B][15][0,2]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[B,0],p[B,1])]*r[B][30][0,2]*r[I][48][2,0]
        hv += g[dei(p[I,1],p[I,0],p[B,0],p[B,1])]*r[B][30][0,2]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[B,1],p[B,0])]*r[B][33][0,2]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[B,1],p[B,0])]*r[B][48][0,2]*r[I][48][2,0]
        hv += g[dei(p[I,1],p[I,0],p[B,1],p[B,0])]*r[B][48][0,2]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    return hd
    
def _A1C3I3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,3),(I,3)]))
        hv = 0.0
        
        hv += 1/2*g[dei(p[B,0],p[B,1],p[I,0],p[I,1])]*r[B][15][0,2]*r[I][15][3,0]
        hv += 1/2*g[dei(p[B,0],p[B,1],p[I,0],p[I,1])]*r[B][30][0,2]*r[I][30][3,0]
        hv += g[dei(p[B,0],p[B,1],p[I,0],p[I,1])]*r[B][15][0,2]*r[I][30][3,0]
        hv += 1/2*g[dei(p[B,0],p[B,1],p[I,1],p[I,0])]*r[B][15][0,2]*r[I][33][3,0]
        hv += 1/2*g[dei(p[B,0],p[B,1],p[I,1],p[I,0])]*r[B][30][0,2]*r[I][48][3,0]
        hv += g[dei(p[B,0],p[B,1],p[I,1],p[I,0])]*r[B][15][0,2]*r[I][48][3,0]
        hv += 1/2*g[dei(p[B,1],p[B,0],p[I,0],p[I,1])]*r[B][33][0,2]*r[I][15][3,0]
        hv += 1/2*g[dei(p[B,1],p[B,0],p[I,0],p[I,1])]*r[B][48][0,2]*r[I][30][3,0]
        hv += g[dei(p[B,1],p[B,0],p[I,0],p[I,1])]*r[B][33][0,2]*r[I][30][3,0]
        hv += 1/2*g[dei(p[B,1],p[B,0],p[I,1],p[I,0])]*r[B][33][0,2]*r[I][33][3,0]
        hv += 1/2*g[dei(p[B,1],p[B,0],p[I,1],p[I,0])]*r[B][48][0,2]*r[I][48][3,0]
        hv += g[dei(p[B,1],p[B,0],p[I,1],p[I,0])]*r[B][33][0,2]*r[I][48][3,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[I,0],p[B,1])]*r[B][15][0,2]*r[I][15][3,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[I,0],p[B,1])]*r[B][30][0,2]*r[I][30][3,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[I,1],p[B,1])]*r[B][15][0,2]*r[I][33][3,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[I,1],p[B,1])]*r[B][30][0,2]*r[I][48][3,0]
        hv += -1/2*g[dei(p[B,1],p[I,1],p[I,0],p[B,0])]*r[B][33][0,2]*r[I][15][3,0]
        hv += -1/2*g[dei(p[B,1],p[I,1],p[I,0],p[B,0])]*r[B][48][0,2]*r[I][30][3,0]
        hv += -1/2*g[dei(p[B,1],p[I,0],p[I,1],p[B,0])]*r[B][33][0,2]*r[I][33][3,0]
        hv += -1/2*g[dei(p[B,1],p[I,0],p[I,1],p[B,0])]*r[B][48][0,2]*r[I][48][3,0]
        hv += -1/2*g[dei(p[I,0],p[B,1],p[B,0],p[I,1])]*r[B][15][0,2]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,0],p[B,1],p[B,0],p[I,1])]*r[B][30][0,2]*r[I][30][3,0]
        hv += -1/2*g[dei(p[I,0],p[B,0],p[B,1],p[I,1])]*r[B][33][0,2]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,0],p[B,0],p[B,1],p[I,1])]*r[B][48][0,2]*r[I][30][3,0]
        hv += -1/2*g[dei(p[I,1],p[B,1],p[B,0],p[I,0])]*r[B][15][0,2]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,1],p[B,1],p[B,0],p[I,0])]*r[B][30][0,2]*r[I][48][3,0]
        hv += -1/2*g[dei(p[I,1],p[B,0],p[B,1],p[I,0])]*r[B][33][0,2]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,1],p[B,0],p[B,1],p[I,0])]*r[B][48][0,2]*r[I][48][3,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[B,0],p[B,1])]*r[B][15][0,2]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[B,0],p[B,1])]*r[B][30][0,2]*r[I][30][3,0]
        hv += g[dei(p[I,0],p[I,1],p[B,0],p[B,1])]*r[B][30][0,2]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[B,1],p[B,0])]*r[B][33][0,2]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[B,1],p[B,0])]*r[B][48][0,2]*r[I][30][3,0]
        hv += g[dei(p[I,0],p[I,1],p[B,1],p[B,0])]*r[B][48][0,2]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[B,0],p[B,1])]*r[B][15][0,2]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[B,0],p[B,1])]*r[B][30][0,2]*r[I][48][3,0]
        hv += g[dei(p[I,1],p[I,0],p[B,0],p[B,1])]*r[B][30][0,2]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[B,1],p[B,0])]*r[B][33][0,2]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[B,1],p[B,0])]*r[B][48][0,2]*r[I][48][3,0]
        hv += g[dei(p[I,1],p[I,0],p[B,1],p[B,0])]*r[B][48][0,2]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    return hd
    
def _A1B2I1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,2),(I,1)]))
        hv = 0.0
        
        hv += 1/2*g[dei(p[C,0],p[C,1],p[I,0],p[I,0])]*r[C][15][0,3]*r[I][9][1,0]
        hv += 1/2*g[dei(p[C,0],p[C,1],p[I,0],p[I,0])]*r[C][30][0,3]*r[I][24][1,0]
        hv += g[dei(p[C,0],p[C,1],p[I,0],p[I,0])]*r[C][15][0,3]*r[I][24][1,0]
        hv += 1/2*g[dei(p[C,0],p[C,1],p[I,1],p[I,1])]*r[C][15][0,3]*r[I][39][1,0]
        hv += 1/2*g[dei(p[C,0],p[C,1],p[I,1],p[I,1])]*r[C][30][0,3]*r[I][54][1,0]
        hv += g[dei(p[C,0],p[C,1],p[I,1],p[I,1])]*r[C][15][0,3]*r[I][54][1,0]
        hv += 1/2*g[dei(p[C,1],p[C,0],p[I,0],p[I,0])]*r[C][33][0,3]*r[I][9][1,0]
        hv += 1/2*g[dei(p[C,1],p[C,0],p[I,0],p[I,0])]*r[C][48][0,3]*r[I][24][1,0]
        hv += g[dei(p[C,1],p[C,0],p[I,0],p[I,0])]*r[C][33][0,3]*r[I][24][1,0]
        hv += 1/2*g[dei(p[C,1],p[C,0],p[I,1],p[I,1])]*r[C][33][0,3]*r[I][39][1,0]
        hv += 1/2*g[dei(p[C,1],p[C,0],p[I,1],p[I,1])]*r[C][48][0,3]*r[I][54][1,0]
        hv += g[dei(p[C,1],p[C,0],p[I,1],p[I,1])]*r[C][33][0,3]*r[I][54][1,0]
        hv += -1/2*g[dei(p[C,0],p[I,0],p[I,0],p[C,1])]*r[C][15][0,3]*r[I][9][1,0]
        hv += -1/2*g[dei(p[C,0],p[I,0],p[I,0],p[C,1])]*r[C][30][0,3]*r[I][24][1,0]
        hv += -1/2*g[dei(p[C,0],p[I,1],p[I,1],p[C,1])]*r[C][15][0,3]*r[I][39][1,0]
        hv += -1/2*g[dei(p[C,0],p[I,1],p[I,1],p[C,1])]*r[C][30][0,3]*r[I][54][1,0]
        hv += -1/2*g[dei(p[C,1],p[I,0],p[I,0],p[C,0])]*r[C][33][0,3]*r[I][9][1,0]
        hv += -1/2*g[dei(p[C,1],p[I,0],p[I,0],p[C,0])]*r[C][48][0,3]*r[I][24][1,0]
        hv += -1/2*g[dei(p[C,1],p[I,1],p[I,1],p[C,0])]*r[C][33][0,3]*r[I][39][1,0]
        hv += -1/2*g[dei(p[C,1],p[I,1],p[I,1],p[C,0])]*r[C][48][0,3]*r[I][54][1,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[C,0],p[I,0])]*r[C][15][0,3]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[C,0],p[I,0])]*r[C][30][0,3]*r[I][24][1,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[C,1],p[I,0])]*r[C][33][0,3]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[C,1],p[I,0])]*r[C][48][0,3]*r[I][24][1,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[C,0],p[I,1])]*r[C][15][0,3]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[C,0],p[I,1])]*r[C][30][0,3]*r[I][54][1,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[C,1],p[I,1])]*r[C][33][0,3]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[C,1],p[I,1])]*r[C][48][0,3]*r[I][54][1,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[C,0],p[C,1])]*r[C][15][0,3]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[C,0],p[C,1])]*r[C][30][0,3]*r[I][24][1,0]
        hv += g[dei(p[I,0],p[I,0],p[C,0],p[C,1])]*r[C][30][0,3]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[C,1],p[C,0])]*r[C][33][0,3]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[C,1],p[C,0])]*r[C][48][0,3]*r[I][24][1,0]
        hv += g[dei(p[I,0],p[I,0],p[C,1],p[C,0])]*r[C][48][0,3]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[C,0],p[C,1])]*r[C][15][0,3]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[C,0],p[C,1])]*r[C][30][0,3]*r[I][54][1,0]
        hv += g[dei(p[I,1],p[I,1],p[C,0],p[C,1])]*r[C][30][0,3]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[C,1],p[C,0])]*r[C][33][0,3]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[C,1],p[C,0])]*r[C][48][0,3]*r[I][54][1,0]
        hv += g[dei(p[I,1],p[I,1],p[C,1],p[C,0])]*r[C][48][0,3]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    return hd
    
def _A1B2I2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,2),(I,2)]))
        hv = 0.0
        
        hv += 1/2*g[dei(p[C,0],p[C,1],p[I,0],p[I,1])]*r[C][15][0,3]*r[I][15][2,0]
        hv += 1/2*g[dei(p[C,0],p[C,1],p[I,0],p[I,1])]*r[C][30][0,3]*r[I][30][2,0]
        hv += g[dei(p[C,0],p[C,1],p[I,0],p[I,1])]*r[C][15][0,3]*r[I][30][2,0]
        hv += 1/2*g[dei(p[C,0],p[C,1],p[I,1],p[I,0])]*r[C][15][0,3]*r[I][33][2,0]
        hv += 1/2*g[dei(p[C,0],p[C,1],p[I,1],p[I,0])]*r[C][30][0,3]*r[I][48][2,0]
        hv += g[dei(p[C,0],p[C,1],p[I,1],p[I,0])]*r[C][15][0,3]*r[I][48][2,0]
        hv += 1/2*g[dei(p[C,1],p[C,0],p[I,0],p[I,1])]*r[C][33][0,3]*r[I][15][2,0]
        hv += 1/2*g[dei(p[C,1],p[C,0],p[I,0],p[I,1])]*r[C][48][0,3]*r[I][30][2,0]
        hv += g[dei(p[C,1],p[C,0],p[I,0],p[I,1])]*r[C][33][0,3]*r[I][30][2,0]
        hv += 1/2*g[dei(p[C,1],p[C,0],p[I,1],p[I,0])]*r[C][33][0,3]*r[I][33][2,0]
        hv += 1/2*g[dei(p[C,1],p[C,0],p[I,1],p[I,0])]*r[C][48][0,3]*r[I][48][2,0]
        hv += g[dei(p[C,1],p[C,0],p[I,1],p[I,0])]*r[C][33][0,3]*r[I][48][2,0]
        hv += -1/2*g[dei(p[C,0],p[I,1],p[I,0],p[C,1])]*r[C][15][0,3]*r[I][15][2,0]
        hv += -1/2*g[dei(p[C,0],p[I,1],p[I,0],p[C,1])]*r[C][30][0,3]*r[I][30][2,0]
        hv += -1/2*g[dei(p[C,0],p[I,0],p[I,1],p[C,1])]*r[C][15][0,3]*r[I][33][2,0]
        hv += -1/2*g[dei(p[C,0],p[I,0],p[I,1],p[C,1])]*r[C][30][0,3]*r[I][48][2,0]
        hv += -1/2*g[dei(p[C,1],p[I,1],p[I,0],p[C,0])]*r[C][33][0,3]*r[I][15][2,0]
        hv += -1/2*g[dei(p[C,1],p[I,1],p[I,0],p[C,0])]*r[C][48][0,3]*r[I][30][2,0]
        hv += -1/2*g[dei(p[C,1],p[I,0],p[I,1],p[C,0])]*r[C][33][0,3]*r[I][33][2,0]
        hv += -1/2*g[dei(p[C,1],p[I,0],p[I,1],p[C,0])]*r[C][48][0,3]*r[I][48][2,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[C,0],p[I,1])]*r[C][15][0,3]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[C,0],p[I,1])]*r[C][30][0,3]*r[I][30][2,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[C,1],p[I,1])]*r[C][33][0,3]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[C,1],p[I,1])]*r[C][48][0,3]*r[I][30][2,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[C,0],p[I,0])]*r[C][15][0,3]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[C,0],p[I,0])]*r[C][30][0,3]*r[I][48][2,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[C,1],p[I,0])]*r[C][33][0,3]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[C,1],p[I,0])]*r[C][48][0,3]*r[I][48][2,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[C,0],p[C,1])]*r[C][15][0,3]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[C,0],p[C,1])]*r[C][30][0,3]*r[I][30][2,0]
        hv += g[dei(p[I,0],p[I,1],p[C,0],p[C,1])]*r[C][30][0,3]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[C,1],p[C,0])]*r[C][33][0,3]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[C,1],p[C,0])]*r[C][48][0,3]*r[I][30][2,0]
        hv += g[dei(p[I,0],p[I,1],p[C,1],p[C,0])]*r[C][48][0,3]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[C,0],p[C,1])]*r[C][15][0,3]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[C,0],p[C,1])]*r[C][30][0,3]*r[I][48][2,0]
        hv += g[dei(p[I,1],p[I,0],p[C,0],p[C,1])]*r[C][30][0,3]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[C,1],p[C,0])]*r[C][33][0,3]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[C,1],p[C,0])]*r[C][48][0,3]*r[I][48][2,0]
        hv += g[dei(p[I,1],p[I,0],p[C,1],p[C,0])]*r[C][48][0,3]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    return hd
    
def _A1B2I3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,2),(I,3)]))
        hv = 0.0
        
        hv += 1/2*g[dei(p[C,0],p[C,1],p[I,0],p[I,1])]*r[C][15][0,3]*r[I][15][3,0]
        hv += 1/2*g[dei(p[C,0],p[C,1],p[I,0],p[I,1])]*r[C][30][0,3]*r[I][30][3,0]
        hv += g[dei(p[C,0],p[C,1],p[I,0],p[I,1])]*r[C][15][0,3]*r[I][30][3,0]
        hv += 1/2*g[dei(p[C,0],p[C,1],p[I,1],p[I,0])]*r[C][15][0,3]*r[I][33][3,0]
        hv += 1/2*g[dei(p[C,0],p[C,1],p[I,1],p[I,0])]*r[C][30][0,3]*r[I][48][3,0]
        hv += g[dei(p[C,0],p[C,1],p[I,1],p[I,0])]*r[C][15][0,3]*r[I][48][3,0]
        hv += 1/2*g[dei(p[C,1],p[C,0],p[I,0],p[I,1])]*r[C][33][0,3]*r[I][15][3,0]
        hv += 1/2*g[dei(p[C,1],p[C,0],p[I,0],p[I,1])]*r[C][48][0,3]*r[I][30][3,0]
        hv += g[dei(p[C,1],p[C,0],p[I,0],p[I,1])]*r[C][33][0,3]*r[I][30][3,0]
        hv += 1/2*g[dei(p[C,1],p[C,0],p[I,1],p[I,0])]*r[C][33][0,3]*r[I][33][3,0]
        hv += 1/2*g[dei(p[C,1],p[C,0],p[I,1],p[I,0])]*r[C][48][0,3]*r[I][48][3,0]
        hv += g[dei(p[C,1],p[C,0],p[I,1],p[I,0])]*r[C][33][0,3]*r[I][48][3,0]
        hv += -1/2*g[dei(p[C,0],p[I,1],p[I,0],p[C,1])]*r[C][15][0,3]*r[I][15][3,0]
        hv += -1/2*g[dei(p[C,0],p[I,1],p[I,0],p[C,1])]*r[C][30][0,3]*r[I][30][3,0]
        hv += -1/2*g[dei(p[C,0],p[I,0],p[I,1],p[C,1])]*r[C][15][0,3]*r[I][33][3,0]
        hv += -1/2*g[dei(p[C,0],p[I,0],p[I,1],p[C,1])]*r[C][30][0,3]*r[I][48][3,0]
        hv += -1/2*g[dei(p[C,1],p[I,1],p[I,0],p[C,0])]*r[C][33][0,3]*r[I][15][3,0]
        hv += -1/2*g[dei(p[C,1],p[I,1],p[I,0],p[C,0])]*r[C][48][0,3]*r[I][30][3,0]
        hv += -1/2*g[dei(p[C,1],p[I,0],p[I,1],p[C,0])]*r[C][33][0,3]*r[I][33][3,0]
        hv += -1/2*g[dei(p[C,1],p[I,0],p[I,1],p[C,0])]*r[C][48][0,3]*r[I][48][3,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[C,0],p[I,1])]*r[C][15][0,3]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[C,0],p[I,1])]*r[C][30][0,3]*r[I][30][3,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[C,1],p[I,1])]*r[C][33][0,3]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[C,1],p[I,1])]*r[C][48][0,3]*r[I][30][3,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[C,0],p[I,0])]*r[C][15][0,3]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[C,0],p[I,0])]*r[C][30][0,3]*r[I][48][3,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[C,1],p[I,0])]*r[C][33][0,3]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[C,1],p[I,0])]*r[C][48][0,3]*r[I][48][3,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[C,0],p[C,1])]*r[C][15][0,3]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[C,0],p[C,1])]*r[C][30][0,3]*r[I][30][3,0]
        hv += g[dei(p[I,0],p[I,1],p[C,0],p[C,1])]*r[C][30][0,3]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[C,1],p[C,0])]*r[C][33][0,3]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[C,1],p[C,0])]*r[C][48][0,3]*r[I][30][3,0]
        hv += g[dei(p[I,0],p[I,1],p[C,1],p[C,0])]*r[C][48][0,3]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[C,0],p[C,1])]*r[C][15][0,3]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[C,0],p[C,1])]*r[C][30][0,3]*r[I][48][3,0]
        hv += g[dei(p[I,1],p[I,0],p[C,0],p[C,1])]*r[C][30][0,3]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[C,1],p[C,0])]*r[C][33][0,3]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[C,1],p[C,0])]*r[C][48][0,3]*r[I][48][3,0]
        hv += g[dei(p[I,1],p[I,0],p[C,1],p[C,0])]*r[C][48][0,3]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    return hd
    
def _A12B10C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,10),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += h[p[A,0],p[B,0]]*r[A][0][12,1]*r[B][1][10,2]
    hv += -1/2*g[dei(p[A,0],p[A,1],p[A,1],p[B,0])]*r[A][76][12,1]*r[B][1][10,2]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[A,0],p[B,0])]*r[A][124][12,1]*r[B][1][10,2]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[A,1],p[A,1])]*r[A][76][12,1]*r[B][1][10,2]
    hv += g[dei(p[A,0],p[B,0],p[A,1],p[A,1])]*r[A][86][12,1]*r[B][1][10,2]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[A,0],p[A,1])]*r[A][124][12,1]*r[B][1][10,2]
    hv += g[dei(p[A,1],p[B,0],p[A,1],p[A,0])]*r[A][146][12,1]*r[B][1][10,2]
    hv += g[dei(p[A,0],p[B,0],p[B,1],p[B,1])]*r[A][0][12,1]*r[B][177][10,2]
    hv += g[dei(p[A,0],p[B,1],p[B,1],p[B,0])]*r[A][0][12,1]*r[B][165][10,2]
    hv += sum(1/2*g[dei(p[A,0],p[B,0],p[I,0],p[I,0])]*r[A][0][12,1]*r[B][1][10,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[B,0],p[I,0],p[I,0])]*r[A][0][12,1]*r[B][1][10,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[B,0],p[I,1],p[I,1])]*r[A][0][12,1]*r[B][1][10,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[B,0],p[I,1],p[I,1])]*r[A][0][12,1]*r[B][1][10,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[B,0])]*r[A][0][12,1]*r[B][1][10,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[B,0])]*r[A][0][12,1]*r[B][1][10,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,0],p[A,0],p[I,0])]*r[A][0][12,1]*r[B][1][10,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,0],p[A,0],p[I,1])]*r[A][0][12,1]*r[B][1][10,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[B,0])]*r[A][0][12,1]*r[B][1][10,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[B,0])]*r[A][0][12,1]*r[B][1][10,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,0],p[C,0])]*r[A][0][12,1]*r[B][1][10,2]*r[C][9][3,3]
    hv += g[dei(p[A,0],p[B,0],p[C,0],p[C,0])]*r[A][0][12,1]*r[B][1][10,2]*r[C][24][3,3]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,1],p[C,1])]*r[A][0][12,1]*r[B][1][10,2]*r[C][39][3,3]
    hv += g[dei(p[A,0],p[B,0],p[C,1],p[C,1])]*r[A][0][12,1]*r[B][1][10,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[B,0])]*r[A][0][12,1]*r[B][1][10,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[B,0])]*r[A][0][12,1]*r[B][1][10,2]*r[C][39][3,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,0],p[C,0])]*r[A][0][12,1]*r[B][1][10,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,0],p[C,1])]*r[A][0][12,1]*r[B][1][10,2]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[B,0])]*r[A][0][12,1]*r[B][1][10,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[B,0])]*r[A][0][12,1]*r[B][1][10,2]*r[C][39][3,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B8C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,8),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += h[p[A,0],p[B,0]]*r[A][2][14,1]*r[B][3][8,2]
    hv += -1/2*g[dei(p[A,0],p[A,1],p[A,1],p[B,0])]*r[A][118][14,1]*r[B][3][8,2]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[A,0],p[B,0])]*r[A][166][14,1]*r[B][3][8,2]
    hv += -1*g[dei(p[A,1],p[A,1],p[A,0],p[B,0])]*r[A][132][14,1]*r[B][3][8,2]
    hv += -1*g[dei(p[A,1],p[A,0],p[A,1],p[B,0])]*r[A][144][14,1]*r[B][3][8,2]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[A,1],p[A,1])]*r[A][118][14,1]*r[B][3][8,2]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[A,0],p[A,1])]*r[A][166][14,1]*r[B][3][8,2]
    hv += -1*g[dei(p[B,1],p[B,0],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][145][8,2]
    hv += -1*g[dei(p[B,1],p[B,1],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][133][8,2]
    hv += sum(1/2*g[dei(p[A,0],p[B,0],p[I,0],p[I,0])]*r[A][2][14,1]*r[B][3][8,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[B,0],p[I,1],p[I,1])]*r[A][2][14,1]*r[B][3][8,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[B,0])]*r[A][2][14,1]*r[B][3][8,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[B,0])]*r[A][2][14,1]*r[B][3][8,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,0],p[A,0],p[I,0])]*r[A][2][14,1]*r[B][3][8,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,0],p[A,0],p[I,1])]*r[A][2][14,1]*r[B][3][8,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][3][8,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][3][8,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][3][8,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][3][8,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,0],p[C,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][24][3,3]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,1],p[C,1])]*r[A][2][14,1]*r[B][3][8,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[B,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[B,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,0],p[C,1])]*r[A][2][14,1]*r[B][3][8,2]*r[C][54][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][24][3,3]
    hv += g[dei(p[C,0],p[C,0],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][54][3,3]
    hv += g[dei(p[C,1],p[C,1],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][39][3,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12B9C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,9),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += h[p[A,0],p[B,1]]*r[A][0][12,1]*r[B][5][9,2]
    hv += -1/2*g[dei(p[A,0],p[A,1],p[A,1],p[B,1])]*r[A][76][12,1]*r[B][5][9,2]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[A,0],p[B,1])]*r[A][124][12,1]*r[B][5][9,2]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[A,1],p[A,1])]*r[A][76][12,1]*r[B][5][9,2]
    hv += g[dei(p[A,0],p[B,1],p[A,1],p[A,1])]*r[A][86][12,1]*r[B][5][9,2]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[A,0],p[A,1])]*r[A][124][12,1]*r[B][5][9,2]
    hv += g[dei(p[A,1],p[B,1],p[A,1],p[A,0])]*r[A][146][12,1]*r[B][5][9,2]
    hv += g[dei(p[A,0],p[B,0],p[B,0],p[B,1])]*r[A][0][12,1]*r[B][113][9,2]
    hv += g[dei(p[A,0],p[B,1],p[B,0],p[B,0])]*r[A][0][12,1]*r[B][101][9,2]
    hv += sum(1/2*g[dei(p[A,0],p[B,1],p[I,0],p[I,0])]*r[A][0][12,1]*r[B][5][9,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[B,1],p[I,0],p[I,0])]*r[A][0][12,1]*r[B][5][9,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[B,1],p[I,1],p[I,1])]*r[A][0][12,1]*r[B][5][9,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[B,1],p[I,1],p[I,1])]*r[A][0][12,1]*r[B][5][9,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[B,1])]*r[A][0][12,1]*r[B][5][9,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[B,1])]*r[A][0][12,1]*r[B][5][9,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,1],p[A,0],p[I,0])]*r[A][0][12,1]*r[B][5][9,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,1],p[A,0],p[I,1])]*r[A][0][12,1]*r[B][5][9,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[B,1])]*r[A][0][12,1]*r[B][5][9,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[B,1])]*r[A][0][12,1]*r[B][5][9,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,0],p[C,0])]*r[A][0][12,1]*r[B][5][9,2]*r[C][9][3,3]
    hv += g[dei(p[A,0],p[B,1],p[C,0],p[C,0])]*r[A][0][12,1]*r[B][5][9,2]*r[C][24][3,3]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,1],p[C,1])]*r[A][0][12,1]*r[B][5][9,2]*r[C][39][3,3]
    hv += g[dei(p[A,0],p[B,1],p[C,1],p[C,1])]*r[A][0][12,1]*r[B][5][9,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[B,1])]*r[A][0][12,1]*r[B][5][9,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[B,1])]*r[A][0][12,1]*r[B][5][9,2]*r[C][39][3,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,0],p[C,0])]*r[A][0][12,1]*r[B][5][9,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,0],p[C,1])]*r[A][0][12,1]*r[B][5][9,2]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[B,1])]*r[A][0][12,1]*r[B][5][9,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[B,1])]*r[A][0][12,1]*r[B][5][9,2]*r[C][39][3,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B7C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,7),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += h[p[A,0],p[B,1]]*r[A][2][14,1]*r[B][7][7,2]
    hv += -1/2*g[dei(p[A,0],p[A,1],p[A,1],p[B,1])]*r[A][118][14,1]*r[B][7][7,2]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[A,0],p[B,1])]*r[A][166][14,1]*r[B][7][7,2]
    hv += -1*g[dei(p[A,1],p[A,1],p[A,0],p[B,1])]*r[A][132][14,1]*r[B][7][7,2]
    hv += -1*g[dei(p[A,1],p[A,0],p[A,1],p[B,1])]*r[A][144][14,1]*r[B][7][7,2]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[A,1],p[A,1])]*r[A][118][14,1]*r[B][7][7,2]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[A,0],p[A,1])]*r[A][166][14,1]*r[B][7][7,2]
    hv += -1*g[dei(p[B,0],p[B,0],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][81][7,2]
    hv += -1*g[dei(p[B,0],p[B,1],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][69][7,2]
    hv += sum(1/2*g[dei(p[A,0],p[B,1],p[I,0],p[I,0])]*r[A][2][14,1]*r[B][7][7,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[B,1],p[I,1],p[I,1])]*r[A][2][14,1]*r[B][7][7,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[B,1])]*r[A][2][14,1]*r[B][7][7,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[B,1])]*r[A][2][14,1]*r[B][7][7,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,1],p[A,0],p[I,0])]*r[A][2][14,1]*r[B][7][7,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,1],p[A,0],p[I,1])]*r[A][2][14,1]*r[B][7][7,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][7][7,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][7][7,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][7][7,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][7][7,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,0],p[C,0])]*r[A][2][14,1]*r[B][7][7,2]*r[C][24][3,3]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,1],p[C,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[B,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[B,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][7][7,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,0],p[C,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][54][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][24][3,3]
    hv += g[dei(p[C,0],p[C,0],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][54][3,3]
    hv += g[dei(p[C,1],p[C,1],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][39][3,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11B10C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,10),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += h[p[A,1],p[B,0]]*r[A][4][11,1]*r[B][1][10,2]
    hv += -1/2*g[dei(p[A,0],p[A,0],p[A,1],p[B,0])]*r[A][72][11,1]*r[B][1][10,2]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[A,0],p[B,0])]*r[A][120][11,1]*r[B][1][10,2]
    hv += g[dei(p[A,0],p[B,0],p[A,0],p[A,1])]*r[A][70][11,1]*r[B][1][10,2]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[A,1],p[A,0])]*r[A][72][11,1]*r[B][1][10,2]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[A,0],p[A,0])]*r[A][120][11,1]*r[B][1][10,2]
    hv += g[dei(p[A,1],p[B,0],p[A,0],p[A,0])]*r[A][130][11,1]*r[B][1][10,2]
    hv += g[dei(p[A,1],p[B,0],p[B,1],p[B,1])]*r[A][4][11,1]*r[B][177][10,2]
    hv += g[dei(p[A,1],p[B,1],p[B,1],p[B,0])]*r[A][4][11,1]*r[B][165][10,2]
    hv += sum(1/2*g[dei(p[A,1],p[B,0],p[I,0],p[I,0])]*r[A][4][11,1]*r[B][1][10,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[B,0],p[I,0],p[I,0])]*r[A][4][11,1]*r[B][1][10,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[B,0],p[I,1],p[I,1])]*r[A][4][11,1]*r[B][1][10,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[B,0],p[I,1],p[I,1])]*r[A][4][11,1]*r[B][1][10,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[B,0])]*r[A][4][11,1]*r[B][1][10,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[B,0])]*r[A][4][11,1]*r[B][1][10,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,0],p[A,1],p[I,0])]*r[A][4][11,1]*r[B][1][10,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,0],p[A,1],p[I,1])]*r[A][4][11,1]*r[B][1][10,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[B,0])]*r[A][4][11,1]*r[B][1][10,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[B,0])]*r[A][4][11,1]*r[B][1][10,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,0],p[C,0])]*r[A][4][11,1]*r[B][1][10,2]*r[C][9][3,3]
    hv += g[dei(p[A,1],p[B,0],p[C,0],p[C,0])]*r[A][4][11,1]*r[B][1][10,2]*r[C][24][3,3]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,1],p[C,1])]*r[A][4][11,1]*r[B][1][10,2]*r[C][39][3,3]
    hv += g[dei(p[A,1],p[B,0],p[C,1],p[C,1])]*r[A][4][11,1]*r[B][1][10,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[B,0])]*r[A][4][11,1]*r[B][1][10,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[B,0])]*r[A][4][11,1]*r[B][1][10,2]*r[C][39][3,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,1],p[C,0])]*r[A][4][11,1]*r[B][1][10,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,1],p[C,1])]*r[A][4][11,1]*r[B][1][10,2]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[B,0])]*r[A][4][11,1]*r[B][1][10,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[B,0])]*r[A][4][11,1]*r[B][1][10,2]*r[C][39][3,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B8C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,8),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += h[p[A,1],p[B,0]]*r[A][6][13,1]*r[B][3][8,2]
    hv += -1*g[dei(p[A,0],p[A,1],p[A,0],p[B,0])]*r[A][68][13,1]*r[B][3][8,2]
    hv += -1/2*g[dei(p[A,0],p[A,0],p[A,1],p[B,0])]*r[A][114][13,1]*r[B][3][8,2]
    hv += -1*g[dei(p[A,0],p[A,0],p[A,1],p[B,0])]*r[A][80][13,1]*r[B][3][8,2]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[A,0],p[B,0])]*r[A][162][13,1]*r[B][3][8,2]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[A,1],p[A,0])]*r[A][114][13,1]*r[B][3][8,2]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[A,0],p[A,0])]*r[A][162][13,1]*r[B][3][8,2]
    hv += -1*g[dei(p[B,1],p[B,0],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][145][8,2]
    hv += -1*g[dei(p[B,1],p[B,1],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][133][8,2]
    hv += sum(1/2*g[dei(p[A,1],p[B,0],p[I,0],p[I,0])]*r[A][6][13,1]*r[B][3][8,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[B,0],p[I,1],p[I,1])]*r[A][6][13,1]*r[B][3][8,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[B,0])]*r[A][6][13,1]*r[B][3][8,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[B,0])]*r[A][6][13,1]*r[B][3][8,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,0],p[A,1],p[I,0])]*r[A][6][13,1]*r[B][3][8,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,0],p[A,1],p[I,1])]*r[A][6][13,1]*r[B][3][8,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][3][8,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][3][8,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][3][8,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][3][8,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,0],p[C,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][24][3,3]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,1],p[C,1])]*r[A][6][13,1]*r[B][3][8,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[B,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[B,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,1],p[C,1])]*r[A][6][13,1]*r[B][3][8,2]*r[C][54][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][24][3,3]
    hv += g[dei(p[C,0],p[C,0],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][54][3,3]
    hv += g[dei(p[C,1],p[C,1],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][39][3,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11B9C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,9),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += h[p[A,1],p[B,1]]*r[A][4][11,1]*r[B][5][9,2]
    hv += -1/2*g[dei(p[A,0],p[A,0],p[A,1],p[B,1])]*r[A][72][11,1]*r[B][5][9,2]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[A,0],p[B,1])]*r[A][120][11,1]*r[B][5][9,2]
    hv += g[dei(p[A,0],p[B,1],p[A,0],p[A,1])]*r[A][70][11,1]*r[B][5][9,2]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[A,1],p[A,0])]*r[A][72][11,1]*r[B][5][9,2]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[A,0],p[A,0])]*r[A][120][11,1]*r[B][5][9,2]
    hv += g[dei(p[A,1],p[B,1],p[A,0],p[A,0])]*r[A][130][11,1]*r[B][5][9,2]
    hv += g[dei(p[A,1],p[B,0],p[B,0],p[B,1])]*r[A][4][11,1]*r[B][113][9,2]
    hv += g[dei(p[A,1],p[B,1],p[B,0],p[B,0])]*r[A][4][11,1]*r[B][101][9,2]
    hv += sum(1/2*g[dei(p[A,1],p[B,1],p[I,0],p[I,0])]*r[A][4][11,1]*r[B][5][9,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[B,1],p[I,0],p[I,0])]*r[A][4][11,1]*r[B][5][9,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[B,1],p[I,1],p[I,1])]*r[A][4][11,1]*r[B][5][9,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[B,1],p[I,1],p[I,1])]*r[A][4][11,1]*r[B][5][9,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[B,1])]*r[A][4][11,1]*r[B][5][9,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[B,1])]*r[A][4][11,1]*r[B][5][9,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,1],p[A,1],p[I,0])]*r[A][4][11,1]*r[B][5][9,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,1],p[A,1],p[I,1])]*r[A][4][11,1]*r[B][5][9,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[B,1])]*r[A][4][11,1]*r[B][5][9,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[B,1])]*r[A][4][11,1]*r[B][5][9,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,0],p[C,0])]*r[A][4][11,1]*r[B][5][9,2]*r[C][9][3,3]
    hv += g[dei(p[A,1],p[B,1],p[C,0],p[C,0])]*r[A][4][11,1]*r[B][5][9,2]*r[C][24][3,3]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,1],p[C,1])]*r[A][4][11,1]*r[B][5][9,2]*r[C][39][3,3]
    hv += g[dei(p[A,1],p[B,1],p[C,1],p[C,1])]*r[A][4][11,1]*r[B][5][9,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[B,1])]*r[A][4][11,1]*r[B][5][9,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[B,1])]*r[A][4][11,1]*r[B][5][9,2]*r[C][39][3,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,1],p[C,0])]*r[A][4][11,1]*r[B][5][9,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,1],p[C,1])]*r[A][4][11,1]*r[B][5][9,2]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[B,1])]*r[A][4][11,1]*r[B][5][9,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[B,1])]*r[A][4][11,1]*r[B][5][9,2]*r[C][39][3,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B7C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,7),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += h[p[A,1],p[B,1]]*r[A][6][13,1]*r[B][7][7,2]
    hv += -1*g[dei(p[A,0],p[A,1],p[A,0],p[B,1])]*r[A][68][13,1]*r[B][7][7,2]
    hv += -1/2*g[dei(p[A,0],p[A,0],p[A,1],p[B,1])]*r[A][114][13,1]*r[B][7][7,2]
    hv += -1*g[dei(p[A,0],p[A,0],p[A,1],p[B,1])]*r[A][80][13,1]*r[B][7][7,2]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[A,0],p[B,1])]*r[A][162][13,1]*r[B][7][7,2]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[A,1],p[A,0])]*r[A][114][13,1]*r[B][7][7,2]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[A,0],p[A,0])]*r[A][162][13,1]*r[B][7][7,2]
    hv += -1*g[dei(p[B,0],p[B,0],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][81][7,2]
    hv += -1*g[dei(p[B,0],p[B,1],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][69][7,2]
    hv += sum(1/2*g[dei(p[A,1],p[B,1],p[I,0],p[I,0])]*r[A][6][13,1]*r[B][7][7,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[B,1],p[I,1],p[I,1])]*r[A][6][13,1]*r[B][7][7,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[B,1])]*r[A][6][13,1]*r[B][7][7,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[B,1])]*r[A][6][13,1]*r[B][7][7,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,1],p[A,1],p[I,0])]*r[A][6][13,1]*r[B][7][7,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,1],p[A,1],p[I,1])]*r[A][6][13,1]*r[B][7][7,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][7][7,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][7][7,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][7][7,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][7][7,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,0],p[C,0])]*r[A][6][13,1]*r[B][7][7,2]*r[C][24][3,3]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,1],p[C,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[B,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[B,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][7][7,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,1],p[C,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][54][3,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][24][3,3]
    hv += g[dei(p[C,0],p[C,0],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][54][3,3]
    hv += g[dei(p[C,1],p[C,1],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][39][3,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B11C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,11),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[B,0],p[A,0]]*r[A][1][9,1]*r[B][0][11,2]
    hv += -1*g[dei(p[B,0],p[A,0],p[A,0],p[A,0])]*r[A][97][9,1]*r[B][0][11,2]
    hv += -1*g[dei(p[B,0],p[A,1],p[A,0],p[A,1])]*r[A][117][9,1]*r[B][0][11,2]
    hv += -1*g[dei(p[B,0],p[A,0],p[B,0],p[B,0])]*r[A][1][9,1]*r[B][66][11,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[B,1],p[B,1])]*r[A][1][9,1]*r[B][76][11,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[B,0],p[B,1])]*r[A][1][9,1]*r[B][124][11,2]
    hv += -1*g[dei(p[B,1],p[A,0],p[B,0],p[B,1])]*r[A][1][9,1]*r[B][134][11,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][76][11,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][124][11,2]
    hv += sum(-1/2*g[dei(p[B,0],p[A,0],p[I,0],p[I,0])]*r[A][1][9,1]*r[B][0][11,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[A,0],p[I,0],p[I,0])]*r[A][1][9,1]*r[B][0][11,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[A,0],p[I,1],p[I,1])]*r[A][1][9,1]*r[B][0][11,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[A,0],p[I,1],p[I,1])]*r[A][1][9,1]*r[B][0][11,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[A,0])]*r[A][1][9,1]*r[B][0][11,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[A,0])]*r[A][1][9,1]*r[B][0][11,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,0],p[B,0],p[I,0])]*r[A][1][9,1]*r[B][0][11,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,0],p[B,0],p[I,1])]*r[A][1][9,1]*r[B][0][11,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][11,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][11,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,0],p[A,0],p[C,0],p[C,0])]*r[A][1][9,1]*r[B][0][11,2]*r[C][9][3,3]
    hv += -1*g[dei(p[B,0],p[A,0],p[C,0],p[C,0])]*r[A][1][9,1]*r[B][0][11,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[C,1],p[C,1])]*r[A][1][9,1]*r[B][0][11,2]*r[C][39][3,3]
    hv += -1*g[dei(p[B,0],p[A,0],p[C,1],p[C,1])]*r[A][1][9,1]*r[B][0][11,2]*r[C][54][3,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[C,0],p[A,0])]*r[A][1][9,1]*r[B][0][11,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,1],p[A,0])]*r[A][1][9,1]*r[B][0][11,2]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[B,0],p[C,0])]*r[A][1][9,1]*r[B][0][11,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[B,0],p[C,1])]*r[A][1][9,1]*r[B][0][11,2]*r[C][39][3,3]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][11,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][11,2]*r[C][39][3,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B13C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,13),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[B,0],p[A,0]]*r[A][3][7,1]*r[B][2][13,2]
    hv += g[dei(p[A,0],p[A,0],p[B,0],p[A,0])]*r[A][65][7,1]*r[B][2][13,2]
    hv += g[dei(p[A,0],p[A,1],p[B,0],p[A,1])]*r[A][85][7,1]*r[B][2][13,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[B,1],p[B,1])]*r[A][3][7,1]*r[B][118][13,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[B,0],p[B,1])]*r[A][3][7,1]*r[B][166][13,2]
    hv += g[dei(p[B,0],p[B,0],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][64][13,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][118][13,2]
    hv += g[dei(p[B,0],p[B,1],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][84][13,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][166][13,2]
    hv += sum(-1/2*g[dei(p[B,0],p[A,0],p[I,0],p[I,0])]*r[A][3][7,1]*r[B][2][13,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[A,0],p[I,1],p[I,1])]*r[A][3][7,1]*r[B][2][13,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[A,0])]*r[A][3][7,1]*r[B][2][13,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[A,0])]*r[A][3][7,1]*r[B][2][13,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,0],p[B,0],p[I,0])]*r[A][3][7,1]*r[B][2][13,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,0],p[B,0],p[I,1])]*r[A][3][7,1]*r[B][2][13,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][2][13,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][2][13,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][2][13,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][2][13,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,0],p[A,0],p[C,0],p[C,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[C,1],p[C,1])]*r[A][3][7,1]*r[B][2][13,2]*r[C][54][3,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[C,0],p[A,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][24][3,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][54][3,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[B,0],p[C,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][24][3,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[B,0],p[C,1])]*r[A][3][7,1]*r[B][2][13,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][24][3,3]
    hv += -1*g[dei(p[C,0],p[C,0],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][54][3,3]
    hv += -1*g[dei(p[C,1],p[C,1],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][39][3,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B11C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,11),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[B,0],p[A,1]]*r[A][5][10,1]*r[B][0][11,2]
    hv += -1*g[dei(p[B,0],p[A,0],p[A,1],p[A,0])]*r[A][161][10,1]*r[B][0][11,2]
    hv += -1*g[dei(p[B,0],p[A,1],p[A,1],p[A,1])]*r[A][181][10,1]*r[B][0][11,2]
    hv += -1*g[dei(p[B,0],p[A,1],p[B,0],p[B,0])]*r[A][5][10,1]*r[B][66][11,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[B,1],p[B,1])]*r[A][5][10,1]*r[B][76][11,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[B,0],p[B,1])]*r[A][5][10,1]*r[B][124][11,2]
    hv += -1*g[dei(p[B,1],p[A,1],p[B,0],p[B,1])]*r[A][5][10,1]*r[B][134][11,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][76][11,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][124][11,2]
    hv += sum(-1/2*g[dei(p[B,0],p[A,1],p[I,0],p[I,0])]*r[A][5][10,1]*r[B][0][11,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[A,1],p[I,0],p[I,0])]*r[A][5][10,1]*r[B][0][11,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[A,1],p[I,1],p[I,1])]*r[A][5][10,1]*r[B][0][11,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[A,1],p[I,1],p[I,1])]*r[A][5][10,1]*r[B][0][11,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[A,1])]*r[A][5][10,1]*r[B][0][11,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[A,1])]*r[A][5][10,1]*r[B][0][11,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,1],p[B,0],p[I,0])]*r[A][5][10,1]*r[B][0][11,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,1],p[B,0],p[I,1])]*r[A][5][10,1]*r[B][0][11,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][11,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][11,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,0],p[A,1],p[C,0],p[C,0])]*r[A][5][10,1]*r[B][0][11,2]*r[C][9][3,3]
    hv += -1*g[dei(p[B,0],p[A,1],p[C,0],p[C,0])]*r[A][5][10,1]*r[B][0][11,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[C,1],p[C,1])]*r[A][5][10,1]*r[B][0][11,2]*r[C][39][3,3]
    hv += -1*g[dei(p[B,0],p[A,1],p[C,1],p[C,1])]*r[A][5][10,1]*r[B][0][11,2]*r[C][54][3,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[C,0],p[A,1])]*r[A][5][10,1]*r[B][0][11,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,1],p[A,1])]*r[A][5][10,1]*r[B][0][11,2]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[B,0],p[C,0])]*r[A][5][10,1]*r[B][0][11,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[B,0],p[C,1])]*r[A][5][10,1]*r[B][0][11,2]*r[C][39][3,3]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][11,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][11,2]*r[C][39][3,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B13C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,13),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[B,0],p[A,1]]*r[A][7][8,1]*r[B][2][13,2]
    hv += g[dei(p[A,1],p[A,0],p[B,0],p[A,0])]*r[A][129][8,1]*r[B][2][13,2]
    hv += g[dei(p[A,1],p[A,1],p[B,0],p[A,1])]*r[A][149][8,1]*r[B][2][13,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[B,1],p[B,1])]*r[A][7][8,1]*r[B][118][13,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[B,0],p[B,1])]*r[A][7][8,1]*r[B][166][13,2]
    hv += g[dei(p[B,0],p[B,0],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][64][13,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][118][13,2]
    hv += g[dei(p[B,0],p[B,1],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][84][13,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][166][13,2]
    hv += sum(-1/2*g[dei(p[B,0],p[A,1],p[I,0],p[I,0])]*r[A][7][8,1]*r[B][2][13,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[A,1],p[I,1],p[I,1])]*r[A][7][8,1]*r[B][2][13,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[A,1])]*r[A][7][8,1]*r[B][2][13,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[A,1])]*r[A][7][8,1]*r[B][2][13,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,1],p[B,0],p[I,0])]*r[A][7][8,1]*r[B][2][13,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,1],p[B,0],p[I,1])]*r[A][7][8,1]*r[B][2][13,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][2][13,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][2][13,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][2][13,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][2][13,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,0],p[A,1],p[C,0],p[C,0])]*r[A][7][8,1]*r[B][2][13,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[C,1],p[C,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][54][3,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[C,0],p[A,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][24][3,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][54][3,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[B,0],p[C,0])]*r[A][7][8,1]*r[B][2][13,2]*r[C][24][3,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[B,0],p[C,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][24][3,3]
    hv += -1*g[dei(p[C,0],p[C,0],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][54][3,3]
    hv += -1*g[dei(p[C,1],p[C,1],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][39][3,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B12C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,12),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[B,1],p[A,0]]*r[A][1][9,1]*r[B][4][12,2]
    hv += -1*g[dei(p[B,1],p[A,0],p[A,0],p[A,0])]*r[A][97][9,1]*r[B][4][12,2]
    hv += -1*g[dei(p[B,1],p[A,1],p[A,0],p[A,1])]*r[A][117][9,1]*r[B][4][12,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[B,1],p[B,0])]*r[A][1][9,1]*r[B][72][12,2]
    hv += -1*g[dei(p[B,0],p[A,0],p[B,1],p[B,0])]*r[A][1][9,1]*r[B][82][12,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[B,0],p[B,0])]*r[A][1][9,1]*r[B][120][12,2]
    hv += -1*g[dei(p[B,1],p[A,0],p[B,1],p[B,1])]*r[A][1][9,1]*r[B][150][12,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][72][12,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][120][12,2]
    hv += sum(-1/2*g[dei(p[B,1],p[A,0],p[I,0],p[I,0])]*r[A][1][9,1]*r[B][4][12,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,1],p[A,0],p[I,0],p[I,0])]*r[A][1][9,1]*r[B][4][12,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[A,0],p[I,1],p[I,1])]*r[A][1][9,1]*r[B][4][12,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,1],p[A,0],p[I,1],p[I,1])]*r[A][1][9,1]*r[B][4][12,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[A,0])]*r[A][1][9,1]*r[B][4][12,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[A,0])]*r[A][1][9,1]*r[B][4][12,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,0],p[B,1],p[I,0])]*r[A][1][9,1]*r[B][4][12,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,0],p[B,1],p[I,1])]*r[A][1][9,1]*r[B][4][12,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][4][12,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][4][12,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,1],p[A,0],p[C,0],p[C,0])]*r[A][1][9,1]*r[B][4][12,2]*r[C][9][3,3]
    hv += -1*g[dei(p[B,1],p[A,0],p[C,0],p[C,0])]*r[A][1][9,1]*r[B][4][12,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[C,1],p[C,1])]*r[A][1][9,1]*r[B][4][12,2]*r[C][39][3,3]
    hv += -1*g[dei(p[B,1],p[A,0],p[C,1],p[C,1])]*r[A][1][9,1]*r[B][4][12,2]*r[C][54][3,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,0],p[A,0])]*r[A][1][9,1]*r[B][4][12,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[C,1],p[A,0])]*r[A][1][9,1]*r[B][4][12,2]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[B,1],p[C,0])]*r[A][1][9,1]*r[B][4][12,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[B,1],p[C,1])]*r[A][1][9,1]*r[B][4][12,2]*r[C][39][3,3]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][4][12,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][4][12,2]*r[C][39][3,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B14C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,14),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[B,1],p[A,0]]*r[A][3][7,1]*r[B][6][14,2]
    hv += g[dei(p[A,0],p[A,0],p[B,1],p[A,0])]*r[A][65][7,1]*r[B][6][14,2]
    hv += g[dei(p[A,0],p[A,1],p[B,1],p[A,1])]*r[A][85][7,1]*r[B][6][14,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[B,1],p[B,0])]*r[A][3][7,1]*r[B][114][14,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[B,0],p[B,0])]*r[A][3][7,1]*r[B][162][14,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][114][14,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][162][14,2]
    hv += g[dei(p[B,1],p[B,0],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][128][14,2]
    hv += g[dei(p[B,1],p[B,1],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][148][14,2]
    hv += sum(-1/2*g[dei(p[B,1],p[A,0],p[I,0],p[I,0])]*r[A][3][7,1]*r[B][6][14,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[A,0],p[I,1],p[I,1])]*r[A][3][7,1]*r[B][6][14,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[A,0])]*r[A][3][7,1]*r[B][6][14,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[A,0])]*r[A][3][7,1]*r[B][6][14,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,0],p[B,1],p[I,0])]*r[A][3][7,1]*r[B][6][14,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,0],p[B,1],p[I,1])]*r[A][3][7,1]*r[B][6][14,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][6][14,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][6][14,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][6][14,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][6][14,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,1],p[A,0],p[C,0],p[C,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[C,1],p[C,1])]*r[A][3][7,1]*r[B][6][14,2]*r[C][54][3,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,0],p[A,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][24][3,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][54][3,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[B,1],p[C,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][24][3,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[B,1],p[C,1])]*r[A][3][7,1]*r[B][6][14,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][24][3,3]
    hv += -1*g[dei(p[C,0],p[C,0],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][54][3,3]
    hv += -1*g[dei(p[C,1],p[C,1],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][39][3,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B12C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,12),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[B,1],p[A,1]]*r[A][5][10,1]*r[B][4][12,2]
    hv += -1*g[dei(p[B,1],p[A,0],p[A,1],p[A,0])]*r[A][161][10,1]*r[B][4][12,2]
    hv += -1*g[dei(p[B,1],p[A,1],p[A,1],p[A,1])]*r[A][181][10,1]*r[B][4][12,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[B,1],p[B,0])]*r[A][5][10,1]*r[B][72][12,2]
    hv += -1*g[dei(p[B,0],p[A,1],p[B,1],p[B,0])]*r[A][5][10,1]*r[B][82][12,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[B,0],p[B,0])]*r[A][5][10,1]*r[B][120][12,2]
    hv += -1*g[dei(p[B,1],p[A,1],p[B,1],p[B,1])]*r[A][5][10,1]*r[B][150][12,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][72][12,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][120][12,2]
    hv += sum(-1/2*g[dei(p[B,1],p[A,1],p[I,0],p[I,0])]*r[A][5][10,1]*r[B][4][12,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,1],p[A,1],p[I,0],p[I,0])]*r[A][5][10,1]*r[B][4][12,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[A,1],p[I,1],p[I,1])]*r[A][5][10,1]*r[B][4][12,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,1],p[A,1],p[I,1],p[I,1])]*r[A][5][10,1]*r[B][4][12,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[A,1])]*r[A][5][10,1]*r[B][4][12,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[A,1])]*r[A][5][10,1]*r[B][4][12,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,1],p[B,1],p[I,0])]*r[A][5][10,1]*r[B][4][12,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,1],p[B,1],p[I,1])]*r[A][5][10,1]*r[B][4][12,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][4][12,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][4][12,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,1],p[A,1],p[C,0],p[C,0])]*r[A][5][10,1]*r[B][4][12,2]*r[C][9][3,3]
    hv += -1*g[dei(p[B,1],p[A,1],p[C,0],p[C,0])]*r[A][5][10,1]*r[B][4][12,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[C,1],p[C,1])]*r[A][5][10,1]*r[B][4][12,2]*r[C][39][3,3]
    hv += -1*g[dei(p[B,1],p[A,1],p[C,1],p[C,1])]*r[A][5][10,1]*r[B][4][12,2]*r[C][54][3,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,0],p[A,1])]*r[A][5][10,1]*r[B][4][12,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[C,1],p[A,1])]*r[A][5][10,1]*r[B][4][12,2]*r[C][39][3,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[B,1],p[C,0])]*r[A][5][10,1]*r[B][4][12,2]*r[C][9][3,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[B,1],p[C,1])]*r[A][5][10,1]*r[B][4][12,2]*r[C][39][3,3]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][4][12,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][4][12,2]*r[C][39][3,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B14C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,14),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[B,1],p[A,1]]*r[A][7][8,1]*r[B][6][14,2]
    hv += g[dei(p[A,1],p[A,0],p[B,1],p[A,0])]*r[A][129][8,1]*r[B][6][14,2]
    hv += g[dei(p[A,1],p[A,1],p[B,1],p[A,1])]*r[A][149][8,1]*r[B][6][14,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[B,1],p[B,0])]*r[A][7][8,1]*r[B][114][14,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[B,0],p[B,0])]*r[A][7][8,1]*r[B][162][14,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][114][14,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][162][14,2]
    hv += g[dei(p[B,1],p[B,0],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][128][14,2]
    hv += g[dei(p[B,1],p[B,1],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][148][14,2]
    hv += sum(-1/2*g[dei(p[B,1],p[A,1],p[I,0],p[I,0])]*r[A][7][8,1]*r[B][6][14,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[A,1],p[I,1],p[I,1])]*r[A][7][8,1]*r[B][6][14,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[A,1])]*r[A][7][8,1]*r[B][6][14,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[A,1])]*r[A][7][8,1]*r[B][6][14,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,1],p[B,1],p[I,0])]*r[A][7][8,1]*r[B][6][14,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,1],p[B,1],p[I,1])]*r[A][7][8,1]*r[B][6][14,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][6][14,2]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][6][14,2]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][6][14,2]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][6][14,2]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,1],p[A,1],p[C,0],p[C,0])]*r[A][7][8,1]*r[B][6][14,2]*r[C][24][3,3]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[C,1],p[C,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][54][3,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,0],p[A,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][24][3,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][54][3,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[B,1],p[C,0])]*r[A][7][8,1]*r[B][6][14,2]*r[C][24][3,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[B,1],p[C,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][54][3,3]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][24][3,3]
    hv += -1*g[dei(p[C,0],p[C,0],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][9][3,3]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][54][3,3]
    hv += -1*g[dei(p[C,1],p[C,1],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][39][3,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A15B6C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,15),(B,6),(C,3)]))
    hv = 0.0
    
    hv += g[dei(p[A,0],p[B,0],p[A,0],p[B,1])]*r[A][11][15,1]*r[B][46][6,2]
    hv += g[dei(p[A,0],p[B,1],p[A,0],p[B,0])]*r[A][11][15,1]*r[B][28][6,2]
    hv += g[dei(p[A,1],p[B,0],p[A,1],p[B,1])]*r[A][41][15,1]*r[B][46][6,2]
    hv += g[dei(p[A,1],p[B,1],p[A,1],p[B,0])]*r[A][41][15,1]*r[B][28][6,2]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _B3C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(B,3),(C,3)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[B,0])]*r[A][9][0,1]*r[B][9][3,2]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[B,0])]*r[A][24][0,1]*r[B][24][3,2]
    hv += g[dei(p[A,0],p[A,0],p[B,0],p[B,0])]*r[A][9][0,1]*r[B][24][3,2]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[B,1])]*r[A][9][0,1]*r[B][39][3,2]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[B,1])]*r[A][24][0,1]*r[B][54][3,2]
    hv += g[dei(p[A,0],p[A,0],p[B,1],p[B,1])]*r[A][9][0,1]*r[B][54][3,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[B,0])]*r[A][39][0,1]*r[B][9][3,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[B,0])]*r[A][54][0,1]*r[B][24][3,2]
    hv += g[dei(p[A,1],p[A,1],p[B,0],p[B,0])]*r[A][39][0,1]*r[B][24][3,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[B,1])]*r[A][39][0,1]*r[B][39][3,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[B,1])]*r[A][54][0,1]*r[B][54][3,2]
    hv += g[dei(p[A,1],p[A,1],p[B,1],p[B,1])]*r[A][39][0,1]*r[B][54][3,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[A,0])]*r[A][9][0,1]*r[B][9][3,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[A,0])]*r[A][24][0,1]*r[B][24][3,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[A,0])]*r[A][9][0,1]*r[B][39][3,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[A,0])]*r[A][24][0,1]*r[B][54][3,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[A,1])]*r[A][39][0,1]*r[B][9][3,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[A,1])]*r[A][54][0,1]*r[B][24][3,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[A,1])]*r[A][39][0,1]*r[B][39][3,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[A,1])]*r[A][54][0,1]*r[B][54][3,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[B,0])]*r[A][9][0,1]*r[B][9][3,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[B,0])]*r[A][24][0,1]*r[B][24][3,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[B,0])]*r[A][39][0,1]*r[B][9][3,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[B,0])]*r[A][54][0,1]*r[B][24][3,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[B,1])]*r[A][9][0,1]*r[B][39][3,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[B,1])]*r[A][24][0,1]*r[B][54][3,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[B,1])]*r[A][39][0,1]*r[B][39][3,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[B,1])]*r[A][54][0,1]*r[B][54][3,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][9][3,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][24][3,2]
    hv += g[dei(p[B,0],p[B,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][9][3,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][9][3,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][24][3,2]
    hv += g[dei(p[B,0],p[B,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][9][3,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][39][3,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][54][3,2]
    hv += g[dei(p[B,1],p[B,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][39][3,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][39][3,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][54][3,2]
    hv += g[dei(p[B,1],p[B,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][39][3,2]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(C,3)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[B,1])]*r[A][9][0,1]*r[B][15][0,2]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[B,1])]*r[A][24][0,1]*r[B][30][0,2]
    hv += g[dei(p[A,0],p[A,0],p[B,0],p[B,1])]*r[A][9][0,1]*r[B][30][0,2]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[B,0])]*r[A][9][0,1]*r[B][33][0,2]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[B,0])]*r[A][24][0,1]*r[B][48][0,2]
    hv += g[dei(p[A,0],p[A,0],p[B,1],p[B,0])]*r[A][9][0,1]*r[B][48][0,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[B,1])]*r[A][39][0,1]*r[B][15][0,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[B,1])]*r[A][54][0,1]*r[B][30][0,2]
    hv += g[dei(p[A,1],p[A,1],p[B,0],p[B,1])]*r[A][39][0,1]*r[B][30][0,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[B,0])]*r[A][39][0,1]*r[B][33][0,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[B,0])]*r[A][54][0,1]*r[B][48][0,2]
    hv += g[dei(p[A,1],p[A,1],p[B,1],p[B,0])]*r[A][39][0,1]*r[B][48][0,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[A,0])]*r[A][9][0,1]*r[B][15][0,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[A,0])]*r[A][24][0,1]*r[B][30][0,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[A,0])]*r[A][9][0,1]*r[B][33][0,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[A,0])]*r[A][24][0,1]*r[B][48][0,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[A,1])]*r[A][39][0,1]*r[B][15][0,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[A,1])]*r[A][54][0,1]*r[B][30][0,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[A,1])]*r[A][39][0,1]*r[B][33][0,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[A,1])]*r[A][54][0,1]*r[B][48][0,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[B,1])]*r[A][9][0,1]*r[B][15][0,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[B,1])]*r[A][24][0,1]*r[B][30][0,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[B,1])]*r[A][39][0,1]*r[B][15][0,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[B,1])]*r[A][54][0,1]*r[B][30][0,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[B,0])]*r[A][9][0,1]*r[B][33][0,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[B,0])]*r[A][24][0,1]*r[B][48][0,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[B,0])]*r[A][39][0,1]*r[B][33][0,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[B,0])]*r[A][54][0,1]*r[B][48][0,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][15][0,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][30][0,2]
    hv += g[dei(p[B,0],p[B,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][15][0,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][15][0,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][30][0,2]
    hv += g[dei(p[B,0],p[B,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][15][0,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][33][0,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][48][0,2]
    hv += g[dei(p[B,1],p[B,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][33][0,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][33][0,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][48][0,2]
    hv += g[dei(p[B,1],p[B,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][33][0,2]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _B1C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(B,1),(C,3)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[B,1])]*r[A][9][0,1]*r[B][15][1,2]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[B,1])]*r[A][24][0,1]*r[B][30][1,2]
    hv += g[dei(p[A,0],p[A,0],p[B,0],p[B,1])]*r[A][9][0,1]*r[B][30][1,2]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[B,0])]*r[A][9][0,1]*r[B][33][1,2]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[B,0])]*r[A][24][0,1]*r[B][48][1,2]
    hv += g[dei(p[A,0],p[A,0],p[B,1],p[B,0])]*r[A][9][0,1]*r[B][48][1,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[B,1])]*r[A][39][0,1]*r[B][15][1,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[B,1])]*r[A][54][0,1]*r[B][30][1,2]
    hv += g[dei(p[A,1],p[A,1],p[B,0],p[B,1])]*r[A][39][0,1]*r[B][30][1,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[B,0])]*r[A][39][0,1]*r[B][33][1,2]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[B,0])]*r[A][54][0,1]*r[B][48][1,2]
    hv += g[dei(p[A,1],p[A,1],p[B,1],p[B,0])]*r[A][39][0,1]*r[B][48][1,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[A,0])]*r[A][9][0,1]*r[B][15][1,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[A,0])]*r[A][24][0,1]*r[B][30][1,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[A,0])]*r[A][9][0,1]*r[B][33][1,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[A,0])]*r[A][24][0,1]*r[B][48][1,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[A,1])]*r[A][39][0,1]*r[B][15][1,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[A,1])]*r[A][54][0,1]*r[B][30][1,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[A,1])]*r[A][39][0,1]*r[B][33][1,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[A,1])]*r[A][54][0,1]*r[B][48][1,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[B,1])]*r[A][9][0,1]*r[B][15][1,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[B,1])]*r[A][24][0,1]*r[B][30][1,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[B,1])]*r[A][39][0,1]*r[B][15][1,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[B,1])]*r[A][54][0,1]*r[B][30][1,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[B,0])]*r[A][9][0,1]*r[B][33][1,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[B,0])]*r[A][24][0,1]*r[B][48][1,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[B,0])]*r[A][39][0,1]*r[B][33][1,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[B,0])]*r[A][54][0,1]*r[B][48][1,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][15][1,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][30][1,2]
    hv += g[dei(p[B,0],p[B,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][15][1,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][15][1,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][30][1,2]
    hv += g[dei(p[B,0],p[B,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][15][1,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][33][1,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][48][1,2]
    hv += g[dei(p[B,1],p[B,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][33][1,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][33][1,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][48][1,2]
    hv += g[dei(p[B,1],p[B,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][33][1,2]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A2B3C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(B,3),(C,3)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[B,0])]*r[A][15][2,1]*r[B][9][3,2]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[B,0])]*r[A][30][2,1]*r[B][24][3,2]
    hv += g[dei(p[A,0],p[A,1],p[B,0],p[B,0])]*r[A][15][2,1]*r[B][24][3,2]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[B,1])]*r[A][15][2,1]*r[B][39][3,2]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[B,1])]*r[A][30][2,1]*r[B][54][3,2]
    hv += g[dei(p[A,0],p[A,1],p[B,1],p[B,1])]*r[A][15][2,1]*r[B][54][3,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[B,0])]*r[A][33][2,1]*r[B][9][3,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[B,0])]*r[A][48][2,1]*r[B][24][3,2]
    hv += g[dei(p[A,1],p[A,0],p[B,0],p[B,0])]*r[A][33][2,1]*r[B][24][3,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[B,1])]*r[A][33][2,1]*r[B][39][3,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[B,1])]*r[A][48][2,1]*r[B][54][3,2]
    hv += g[dei(p[A,1],p[A,0],p[B,1],p[B,1])]*r[A][33][2,1]*r[B][54][3,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[A,1])]*r[A][15][2,1]*r[B][9][3,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[A,1])]*r[A][30][2,1]*r[B][24][3,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[A,1])]*r[A][15][2,1]*r[B][39][3,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[A,1])]*r[A][30][2,1]*r[B][54][3,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[A,0])]*r[A][33][2,1]*r[B][9][3,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[A,0])]*r[A][48][2,1]*r[B][24][3,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[A,0])]*r[A][33][2,1]*r[B][39][3,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[A,0])]*r[A][48][2,1]*r[B][54][3,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[B,0])]*r[A][15][2,1]*r[B][9][3,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[B,0])]*r[A][30][2,1]*r[B][24][3,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[B,0])]*r[A][33][2,1]*r[B][9][3,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[B,0])]*r[A][48][2,1]*r[B][24][3,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[B,1])]*r[A][15][2,1]*r[B][39][3,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[B,1])]*r[A][30][2,1]*r[B][54][3,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[B,1])]*r[A][33][2,1]*r[B][39][3,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[B,1])]*r[A][48][2,1]*r[B][54][3,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][9][3,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][24][3,2]
    hv += g[dei(p[B,0],p[B,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][9][3,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][9][3,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][24][3,2]
    hv += g[dei(p[B,0],p[B,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][9][3,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][39][3,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][54][3,2]
    hv += g[dei(p[B,1],p[B,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][39][3,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][39][3,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][54][3,2]
    hv += g[dei(p[B,1],p[B,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][39][3,2]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A3B3C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,3),(C,3)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[B,0])]*r[A][15][3,1]*r[B][9][3,2]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[B,0])]*r[A][30][3,1]*r[B][24][3,2]
    hv += g[dei(p[A,0],p[A,1],p[B,0],p[B,0])]*r[A][15][3,1]*r[B][24][3,2]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[B,1])]*r[A][15][3,1]*r[B][39][3,2]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[B,1])]*r[A][30][3,1]*r[B][54][3,2]
    hv += g[dei(p[A,0],p[A,1],p[B,1],p[B,1])]*r[A][15][3,1]*r[B][54][3,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[B,0])]*r[A][33][3,1]*r[B][9][3,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[B,0])]*r[A][48][3,1]*r[B][24][3,2]
    hv += g[dei(p[A,1],p[A,0],p[B,0],p[B,0])]*r[A][33][3,1]*r[B][24][3,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[B,1])]*r[A][33][3,1]*r[B][39][3,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[B,1])]*r[A][48][3,1]*r[B][54][3,2]
    hv += g[dei(p[A,1],p[A,0],p[B,1],p[B,1])]*r[A][33][3,1]*r[B][54][3,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[A,1])]*r[A][15][3,1]*r[B][9][3,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[A,1])]*r[A][30][3,1]*r[B][24][3,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[A,1])]*r[A][15][3,1]*r[B][39][3,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[A,1])]*r[A][30][3,1]*r[B][54][3,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[A,0])]*r[A][33][3,1]*r[B][9][3,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[A,0])]*r[A][48][3,1]*r[B][24][3,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[A,0])]*r[A][33][3,1]*r[B][39][3,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[A,0])]*r[A][48][3,1]*r[B][54][3,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[B,0])]*r[A][15][3,1]*r[B][9][3,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[B,0])]*r[A][30][3,1]*r[B][24][3,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[B,0])]*r[A][33][3,1]*r[B][9][3,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[B,0])]*r[A][48][3,1]*r[B][24][3,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[B,1])]*r[A][15][3,1]*r[B][39][3,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[B,1])]*r[A][30][3,1]*r[B][54][3,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[B,1])]*r[A][33][3,1]*r[B][39][3,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[B,1])]*r[A][48][3,1]*r[B][54][3,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][9][3,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][24][3,2]
    hv += g[dei(p[B,0],p[B,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][9][3,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][9][3,2]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][24][3,2]
    hv += g[dei(p[B,0],p[B,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][9][3,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][39][3,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][54][3,2]
    hv += g[dei(p[B,1],p[B,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][39][3,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][39][3,2]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][54][3,2]
    hv += g[dei(p[B,1],p[B,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][39][3,2]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A2C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(C,3)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[B,1])]*r[A][15][2,1]*r[B][15][0,2]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[B,1])]*r[A][30][2,1]*r[B][30][0,2]
    hv += g[dei(p[A,0],p[A,1],p[B,0],p[B,1])]*r[A][15][2,1]*r[B][30][0,2]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[B,0])]*r[A][15][2,1]*r[B][33][0,2]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[B,0])]*r[A][30][2,1]*r[B][48][0,2]
    hv += g[dei(p[A,0],p[A,1],p[B,1],p[B,0])]*r[A][15][2,1]*r[B][48][0,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[B,1])]*r[A][33][2,1]*r[B][15][0,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[B,1])]*r[A][48][2,1]*r[B][30][0,2]
    hv += g[dei(p[A,1],p[A,0],p[B,0],p[B,1])]*r[A][33][2,1]*r[B][30][0,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[B,0])]*r[A][33][2,1]*r[B][33][0,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[B,0])]*r[A][48][2,1]*r[B][48][0,2]
    hv += g[dei(p[A,1],p[A,0],p[B,1],p[B,0])]*r[A][33][2,1]*r[B][48][0,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[A,1])]*r[A][15][2,1]*r[B][15][0,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[A,1])]*r[A][30][2,1]*r[B][30][0,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[A,1])]*r[A][15][2,1]*r[B][33][0,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[A,1])]*r[A][30][2,1]*r[B][48][0,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[A,0])]*r[A][33][2,1]*r[B][15][0,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[A,0])]*r[A][48][2,1]*r[B][30][0,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[A,0])]*r[A][33][2,1]*r[B][33][0,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[A,0])]*r[A][48][2,1]*r[B][48][0,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[B,1])]*r[A][15][2,1]*r[B][15][0,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[B,1])]*r[A][30][2,1]*r[B][30][0,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[B,1])]*r[A][33][2,1]*r[B][15][0,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[B,1])]*r[A][48][2,1]*r[B][30][0,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[B,0])]*r[A][15][2,1]*r[B][33][0,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[B,0])]*r[A][30][2,1]*r[B][48][0,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[B,0])]*r[A][33][2,1]*r[B][33][0,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[B,0])]*r[A][48][2,1]*r[B][48][0,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][15][0,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][30][0,2]
    hv += g[dei(p[B,0],p[B,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][15][0,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][15][0,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][30][0,2]
    hv += g[dei(p[B,0],p[B,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][15][0,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][33][0,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][48][0,2]
    hv += g[dei(p[B,1],p[B,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][33][0,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][33][0,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][48][0,2]
    hv += g[dei(p[B,1],p[B,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][33][0,2]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A2B1C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(B,1),(C,3)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[B,1])]*r[A][15][2,1]*r[B][15][1,2]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[B,1])]*r[A][30][2,1]*r[B][30][1,2]
    hv += g[dei(p[A,0],p[A,1],p[B,0],p[B,1])]*r[A][15][2,1]*r[B][30][1,2]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[B,0])]*r[A][15][2,1]*r[B][33][1,2]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[B,0])]*r[A][30][2,1]*r[B][48][1,2]
    hv += g[dei(p[A,0],p[A,1],p[B,1],p[B,0])]*r[A][15][2,1]*r[B][48][1,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[B,1])]*r[A][33][2,1]*r[B][15][1,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[B,1])]*r[A][48][2,1]*r[B][30][1,2]
    hv += g[dei(p[A,1],p[A,0],p[B,0],p[B,1])]*r[A][33][2,1]*r[B][30][1,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[B,0])]*r[A][33][2,1]*r[B][33][1,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[B,0])]*r[A][48][2,1]*r[B][48][1,2]
    hv += g[dei(p[A,1],p[A,0],p[B,1],p[B,0])]*r[A][33][2,1]*r[B][48][1,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[A,1])]*r[A][15][2,1]*r[B][15][1,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[A,1])]*r[A][30][2,1]*r[B][30][1,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[A,1])]*r[A][15][2,1]*r[B][33][1,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[A,1])]*r[A][30][2,1]*r[B][48][1,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[A,0])]*r[A][33][2,1]*r[B][15][1,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[A,0])]*r[A][48][2,1]*r[B][30][1,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[A,0])]*r[A][33][2,1]*r[B][33][1,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[A,0])]*r[A][48][2,1]*r[B][48][1,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[B,1])]*r[A][15][2,1]*r[B][15][1,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[B,1])]*r[A][30][2,1]*r[B][30][1,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[B,1])]*r[A][33][2,1]*r[B][15][1,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[B,1])]*r[A][48][2,1]*r[B][30][1,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[B,0])]*r[A][15][2,1]*r[B][33][1,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[B,0])]*r[A][30][2,1]*r[B][48][1,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[B,0])]*r[A][33][2,1]*r[B][33][1,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[B,0])]*r[A][48][2,1]*r[B][48][1,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][15][1,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][30][1,2]
    hv += g[dei(p[B,0],p[B,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][15][1,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][15][1,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][30][1,2]
    hv += g[dei(p[B,0],p[B,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][15][1,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][33][1,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][48][1,2]
    hv += g[dei(p[B,1],p[B,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][33][1,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][33][1,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][48][1,2]
    hv += g[dei(p[B,1],p[B,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][33][1,2]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A3C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(C,3)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[B,1])]*r[A][15][3,1]*r[B][15][0,2]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[B,1])]*r[A][30][3,1]*r[B][30][0,2]
    hv += g[dei(p[A,0],p[A,1],p[B,0],p[B,1])]*r[A][15][3,1]*r[B][30][0,2]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[B,0])]*r[A][15][3,1]*r[B][33][0,2]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[B,0])]*r[A][30][3,1]*r[B][48][0,2]
    hv += g[dei(p[A,0],p[A,1],p[B,1],p[B,0])]*r[A][15][3,1]*r[B][48][0,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[B,1])]*r[A][33][3,1]*r[B][15][0,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[B,1])]*r[A][48][3,1]*r[B][30][0,2]
    hv += g[dei(p[A,1],p[A,0],p[B,0],p[B,1])]*r[A][33][3,1]*r[B][30][0,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[B,0])]*r[A][33][3,1]*r[B][33][0,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[B,0])]*r[A][48][3,1]*r[B][48][0,2]
    hv += g[dei(p[A,1],p[A,0],p[B,1],p[B,0])]*r[A][33][3,1]*r[B][48][0,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[A,1])]*r[A][15][3,1]*r[B][15][0,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[A,1])]*r[A][30][3,1]*r[B][30][0,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[A,1])]*r[A][15][3,1]*r[B][33][0,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[A,1])]*r[A][30][3,1]*r[B][48][0,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[A,0])]*r[A][33][3,1]*r[B][15][0,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[A,0])]*r[A][48][3,1]*r[B][30][0,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[A,0])]*r[A][33][3,1]*r[B][33][0,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[A,0])]*r[A][48][3,1]*r[B][48][0,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[B,1])]*r[A][15][3,1]*r[B][15][0,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[B,1])]*r[A][30][3,1]*r[B][30][0,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[B,1])]*r[A][33][3,1]*r[B][15][0,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[B,1])]*r[A][48][3,1]*r[B][30][0,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[B,0])]*r[A][15][3,1]*r[B][33][0,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[B,0])]*r[A][30][3,1]*r[B][48][0,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[B,0])]*r[A][33][3,1]*r[B][33][0,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[B,0])]*r[A][48][3,1]*r[B][48][0,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][15][0,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][30][0,2]
    hv += g[dei(p[B,0],p[B,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][15][0,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][15][0,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][30][0,2]
    hv += g[dei(p[B,0],p[B,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][15][0,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][33][0,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][48][0,2]
    hv += g[dei(p[B,1],p[B,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][33][0,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][33][0,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][48][0,2]
    hv += g[dei(p[B,1],p[B,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][33][0,2]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A3B1C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,1),(C,3)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[B,1])]*r[A][15][3,1]*r[B][15][1,2]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[B,1])]*r[A][30][3,1]*r[B][30][1,2]
    hv += g[dei(p[A,0],p[A,1],p[B,0],p[B,1])]*r[A][15][3,1]*r[B][30][1,2]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[B,0])]*r[A][15][3,1]*r[B][33][1,2]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[B,0])]*r[A][30][3,1]*r[B][48][1,2]
    hv += g[dei(p[A,0],p[A,1],p[B,1],p[B,0])]*r[A][15][3,1]*r[B][48][1,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[B,1])]*r[A][33][3,1]*r[B][15][1,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[B,1])]*r[A][48][3,1]*r[B][30][1,2]
    hv += g[dei(p[A,1],p[A,0],p[B,0],p[B,1])]*r[A][33][3,1]*r[B][30][1,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[B,0])]*r[A][33][3,1]*r[B][33][1,2]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[B,0])]*r[A][48][3,1]*r[B][48][1,2]
    hv += g[dei(p[A,1],p[A,0],p[B,1],p[B,0])]*r[A][33][3,1]*r[B][48][1,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[A,1])]*r[A][15][3,1]*r[B][15][1,2]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[A,1])]*r[A][30][3,1]*r[B][30][1,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[A,1])]*r[A][15][3,1]*r[B][33][1,2]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[A,1])]*r[A][30][3,1]*r[B][48][1,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[A,0])]*r[A][33][3,1]*r[B][15][1,2]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[A,0])]*r[A][48][3,1]*r[B][30][1,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[A,0])]*r[A][33][3,1]*r[B][33][1,2]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[A,0])]*r[A][48][3,1]*r[B][48][1,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[B,1])]*r[A][15][3,1]*r[B][15][1,2]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[B,1])]*r[A][30][3,1]*r[B][30][1,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[B,1])]*r[A][33][3,1]*r[B][15][1,2]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[B,1])]*r[A][48][3,1]*r[B][30][1,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[B,0])]*r[A][15][3,1]*r[B][33][1,2]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[B,0])]*r[A][30][3,1]*r[B][48][1,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[B,0])]*r[A][33][3,1]*r[B][33][1,2]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[B,0])]*r[A][48][3,1]*r[B][48][1,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][15][1,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][30][1,2]
    hv += g[dei(p[B,0],p[B,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][15][1,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][15][1,2]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][30][1,2]
    hv += g[dei(p[B,0],p[B,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][15][1,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][33][1,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][48][1,2]
    hv += g[dei(p[B,1],p[B,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][33][1,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][33][1,2]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][48][1,2]
    hv += g[dei(p[B,1],p[B,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][33][1,2]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A4B5C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,4),(B,5),(C,3)]))
    hv = 0.0
    
    hv += -1*g[dei(p[A,0],p[B,0],p[B,0],p[A,1])]*r[A][18][4,1]*r[B][21][5,2]
    hv += -1*g[dei(p[A,0],p[B,1],p[B,1],p[A,1])]*r[A][18][4,1]*r[B][51][5,2]
    hv += -1*g[dei(p[A,1],p[B,0],p[B,0],p[A,0])]*r[A][36][4,1]*r[B][21][5,2]
    hv += -1*g[dei(p[A,1],p[B,1],p[B,1],p[A,0])]*r[A][36][4,1]*r[B][51][5,2]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A5B4C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,5),(B,4),(C,3)]))
    hv = 0.0
    
    hv += -1*g[dei(p[B,0],p[A,1],p[A,0],p[B,0])]*r[A][27][5,1]*r[B][12][4,2]
    hv += -1*g[dei(p[B,0],p[A,0],p[A,1],p[B,0])]*r[A][45][5,1]*r[B][12][4,2]
    hv += -1*g[dei(p[B,1],p[A,1],p[A,0],p[B,1])]*r[A][27][5,1]*r[B][42][4,2]
    hv += -1*g[dei(p[B,1],p[A,0],p[A,1],p[B,1])]*r[A][45][5,1]*r[B][42][4,2]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A6B15C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,6),(B,15),(C,3)]))
    hv = 0.0
    
    hv += g[dei(p[B,0],p[A,0],p[B,1],p[A,0])]*r[A][22][6,1]*r[B][17][15,2]
    hv += g[dei(p[B,0],p[A,1],p[B,1],p[A,1])]*r[A][52][6,1]*r[B][17][15,2]
    hv += g[dei(p[B,1],p[A,0],p[B,0],p[A,0])]*r[A][22][6,1]*r[B][35][15,2]
    hv += g[dei(p[B,1],p[A,1],p[B,0],p[A,1])]*r[A][52][6,1]*r[B][35][15,2]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A12B2C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,2),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += h[p[A,0],p[C,0]]*r[A][0][12,1]*r[C][1][10,3]
    hv += -1/2*g[dei(p[A,0],p[A,1],p[A,1],p[C,0])]*r[A][76][12,1]*r[C][1][10,3]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[A,0],p[C,0])]*r[A][124][12,1]*r[C][1][10,3]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[A,1],p[A,1])]*r[A][76][12,1]*r[C][1][10,3]
    hv += g[dei(p[A,0],p[C,0],p[A,1],p[A,1])]*r[A][86][12,1]*r[C][1][10,3]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[A,0],p[A,1])]*r[A][124][12,1]*r[C][1][10,3]
    hv += g[dei(p[A,1],p[C,0],p[A,1],p[A,0])]*r[A][146][12,1]*r[C][1][10,3]
    hv += g[dei(p[A,0],p[C,0],p[C,1],p[C,1])]*r[A][0][12,1]*r[C][177][10,3]
    hv += g[dei(p[A,0],p[C,1],p[C,1],p[C,0])]*r[A][0][12,1]*r[C][165][10,3]
    hv += sum(1/2*g[dei(p[A,0],p[C,0],p[I,0],p[I,0])]*r[A][0][12,1]*r[C][1][10,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[C,0],p[I,0],p[I,0])]*r[A][0][12,1]*r[C][1][10,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[C,0],p[I,1],p[I,1])]*r[A][0][12,1]*r[C][1][10,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[C,0],p[I,1],p[I,1])]*r[A][0][12,1]*r[C][1][10,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[C,0])]*r[A][0][12,1]*r[C][1][10,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[C,0])]*r[A][0][12,1]*r[C][1][10,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,0],p[A,0],p[I,0])]*r[A][0][12,1]*r[C][1][10,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,0],p[A,0],p[I,1])]*r[A][0][12,1]*r[C][1][10,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[C,0])]*r[A][0][12,1]*r[C][1][10,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[C,0])]*r[A][0][12,1]*r[C][1][10,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[C,0])]*r[A][0][12,1]*r[B][9][2,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[C,0])]*r[A][0][12,1]*r[B][39][2,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[B,0])]*r[A][0][12,1]*r[B][9][2,2]*r[C][1][10,3]
    hv += g[dei(p[A,0],p[C,0],p[B,0],p[B,0])]*r[A][0][12,1]*r[B][24][2,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[B,1])]*r[A][0][12,1]*r[B][39][2,2]*r[C][1][10,3]
    hv += g[dei(p[A,0],p[C,0],p[B,1],p[B,1])]*r[A][0][12,1]*r[B][54][2,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[C,0])]*r[A][0][12,1]*r[B][9][2,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[C,0])]*r[A][0][12,1]*r[B][39][2,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[B,0])]*r[A][0][12,1]*r[B][9][2,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[B,1])]*r[A][0][12,1]*r[B][39][2,2]*r[C][1][10,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B2C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,2),(C,8)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += h[p[A,0],p[C,0]]*r[A][2][14,1]*r[C][3][8,3]
    hv += -1/2*g[dei(p[A,0],p[A,1],p[A,1],p[C,0])]*r[A][118][14,1]*r[C][3][8,3]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[A,0],p[C,0])]*r[A][166][14,1]*r[C][3][8,3]
    hv += -1*g[dei(p[A,1],p[A,1],p[A,0],p[C,0])]*r[A][132][14,1]*r[C][3][8,3]
    hv += -1*g[dei(p[A,1],p[A,0],p[A,1],p[C,0])]*r[A][144][14,1]*r[C][3][8,3]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[A,1],p[A,1])]*r[A][118][14,1]*r[C][3][8,3]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[A,0],p[A,1])]*r[A][166][14,1]*r[C][3][8,3]
    hv += -1*g[dei(p[C,1],p[C,0],p[A,0],p[C,1])]*r[A][2][14,1]*r[C][145][8,3]
    hv += -1*g[dei(p[C,1],p[C,1],p[A,0],p[C,0])]*r[A][2][14,1]*r[C][133][8,3]
    hv += sum(1/2*g[dei(p[A,0],p[C,0],p[I,0],p[I,0])]*r[A][2][14,1]*r[C][3][8,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[C,0],p[I,1],p[I,1])]*r[A][2][14,1]*r[C][3][8,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[C,0])]*r[A][2][14,1]*r[C][3][8,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[C,0])]*r[A][2][14,1]*r[C][3][8,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,0],p[A,0],p[I,0])]*r[A][2][14,1]*r[C][3][8,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,0],p[A,0],p[I,1])]*r[A][2][14,1]*r[C][3][8,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[C,0])]*r[A][2][14,1]*r[C][3][8,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,0],p[C,0])]*r[A][2][14,1]*r[C][3][8,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[C,0])]*r[A][2][14,1]*r[C][3][8,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,0],p[C,0])]*r[A][2][14,1]*r[C][3][8,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[C,0])]*r[A][2][14,1]*r[B][24][2,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[C,0])]*r[A][2][14,1]*r[B][54][2,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[B,0])]*r[A][2][14,1]*r[B][24][2,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[B,1])]*r[A][2][14,1]*r[B][54][2,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][24][2,2]*r[C][3][8,3]
    hv += g[dei(p[B,0],p[B,0],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][9][2,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][54][2,2]*r[C][3][8,3]
    hv += g[dei(p[B,1],p[B,1],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][39][2,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][24][2,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][54][2,2]*r[C][3][8,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12B2C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,2),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += h[p[A,0],p[C,1]]*r[A][0][12,1]*r[C][5][9,3]
    hv += -1/2*g[dei(p[A,0],p[A,1],p[A,1],p[C,1])]*r[A][76][12,1]*r[C][5][9,3]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[A,0],p[C,1])]*r[A][124][12,1]*r[C][5][9,3]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[A,1],p[A,1])]*r[A][76][12,1]*r[C][5][9,3]
    hv += g[dei(p[A,0],p[C,1],p[A,1],p[A,1])]*r[A][86][12,1]*r[C][5][9,3]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[A,0],p[A,1])]*r[A][124][12,1]*r[C][5][9,3]
    hv += g[dei(p[A,1],p[C,1],p[A,1],p[A,0])]*r[A][146][12,1]*r[C][5][9,3]
    hv += g[dei(p[A,0],p[C,0],p[C,0],p[C,1])]*r[A][0][12,1]*r[C][113][9,3]
    hv += g[dei(p[A,0],p[C,1],p[C,0],p[C,0])]*r[A][0][12,1]*r[C][101][9,3]
    hv += sum(1/2*g[dei(p[A,0],p[C,1],p[I,0],p[I,0])]*r[A][0][12,1]*r[C][5][9,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[C,1],p[I,0],p[I,0])]*r[A][0][12,1]*r[C][5][9,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[C,1],p[I,1],p[I,1])]*r[A][0][12,1]*r[C][5][9,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[C,1],p[I,1],p[I,1])]*r[A][0][12,1]*r[C][5][9,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[C,1])]*r[A][0][12,1]*r[C][5][9,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[C,1])]*r[A][0][12,1]*r[C][5][9,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,1],p[A,0],p[I,0])]*r[A][0][12,1]*r[C][5][9,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,1],p[A,0],p[I,1])]*r[A][0][12,1]*r[C][5][9,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[C,1])]*r[A][0][12,1]*r[C][5][9,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[C,1])]*r[A][0][12,1]*r[C][5][9,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[C,1])]*r[A][0][12,1]*r[B][9][2,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[C,1])]*r[A][0][12,1]*r[B][39][2,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[B,0])]*r[A][0][12,1]*r[B][9][2,2]*r[C][5][9,3]
    hv += g[dei(p[A,0],p[C,1],p[B,0],p[B,0])]*r[A][0][12,1]*r[B][24][2,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[B,1])]*r[A][0][12,1]*r[B][39][2,2]*r[C][5][9,3]
    hv += g[dei(p[A,0],p[C,1],p[B,1],p[B,1])]*r[A][0][12,1]*r[B][54][2,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[C,1])]*r[A][0][12,1]*r[B][9][2,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[C,1])]*r[A][0][12,1]*r[B][39][2,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[B,0])]*r[A][0][12,1]*r[B][9][2,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[B,1])]*r[A][0][12,1]*r[B][39][2,2]*r[C][5][9,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B2C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,2),(C,7)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += h[p[A,0],p[C,1]]*r[A][2][14,1]*r[C][7][7,3]
    hv += -1/2*g[dei(p[A,0],p[A,1],p[A,1],p[C,1])]*r[A][118][14,1]*r[C][7][7,3]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[A,0],p[C,1])]*r[A][166][14,1]*r[C][7][7,3]
    hv += -1*g[dei(p[A,1],p[A,1],p[A,0],p[C,1])]*r[A][132][14,1]*r[C][7][7,3]
    hv += -1*g[dei(p[A,1],p[A,0],p[A,1],p[C,1])]*r[A][144][14,1]*r[C][7][7,3]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[A,1],p[A,1])]*r[A][118][14,1]*r[C][7][7,3]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[A,0],p[A,1])]*r[A][166][14,1]*r[C][7][7,3]
    hv += -1*g[dei(p[C,0],p[C,0],p[A,0],p[C,1])]*r[A][2][14,1]*r[C][81][7,3]
    hv += -1*g[dei(p[C,0],p[C,1],p[A,0],p[C,0])]*r[A][2][14,1]*r[C][69][7,3]
    hv += sum(1/2*g[dei(p[A,0],p[C,1],p[I,0],p[I,0])]*r[A][2][14,1]*r[C][7][7,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[C,1],p[I,1],p[I,1])]*r[A][2][14,1]*r[C][7][7,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[C,1])]*r[A][2][14,1]*r[C][7][7,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[C,1])]*r[A][2][14,1]*r[C][7][7,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,1],p[A,0],p[I,0])]*r[A][2][14,1]*r[C][7][7,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,1],p[A,0],p[I,1])]*r[A][2][14,1]*r[C][7][7,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[C,1])]*r[A][2][14,1]*r[C][7][7,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,0],p[C,1])]*r[A][2][14,1]*r[C][7][7,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[C,1])]*r[A][2][14,1]*r[C][7][7,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,0],p[C,1])]*r[A][2][14,1]*r[C][7][7,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[C,1])]*r[A][2][14,1]*r[B][24][2,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[C,1])]*r[A][2][14,1]*r[B][54][2,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[B,0])]*r[A][2][14,1]*r[B][24][2,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[B,1])]*r[A][2][14,1]*r[B][54][2,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[C,1])]*r[A][2][14,1]*r[B][24][2,2]*r[C][7][7,3]
    hv += g[dei(p[B,0],p[B,0],p[A,0],p[C,1])]*r[A][2][14,1]*r[B][9][2,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[C,1])]*r[A][2][14,1]*r[B][54][2,2]*r[C][7][7,3]
    hv += g[dei(p[B,1],p[B,1],p[A,0],p[C,1])]*r[A][2][14,1]*r[B][39][2,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][24][2,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][54][2,2]*r[C][7][7,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11B2C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,2),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += h[p[A,1],p[C,0]]*r[A][4][11,1]*r[C][1][10,3]
    hv += -1/2*g[dei(p[A,0],p[A,0],p[A,1],p[C,0])]*r[A][72][11,1]*r[C][1][10,3]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[A,0],p[C,0])]*r[A][120][11,1]*r[C][1][10,3]
    hv += g[dei(p[A,0],p[C,0],p[A,0],p[A,1])]*r[A][70][11,1]*r[C][1][10,3]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[A,1],p[A,0])]*r[A][72][11,1]*r[C][1][10,3]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[A,0],p[A,0])]*r[A][120][11,1]*r[C][1][10,3]
    hv += g[dei(p[A,1],p[C,0],p[A,0],p[A,0])]*r[A][130][11,1]*r[C][1][10,3]
    hv += g[dei(p[A,1],p[C,0],p[C,1],p[C,1])]*r[A][4][11,1]*r[C][177][10,3]
    hv += g[dei(p[A,1],p[C,1],p[C,1],p[C,0])]*r[A][4][11,1]*r[C][165][10,3]
    hv += sum(1/2*g[dei(p[A,1],p[C,0],p[I,0],p[I,0])]*r[A][4][11,1]*r[C][1][10,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[C,0],p[I,0],p[I,0])]*r[A][4][11,1]*r[C][1][10,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[C,0],p[I,1],p[I,1])]*r[A][4][11,1]*r[C][1][10,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[C,0],p[I,1],p[I,1])]*r[A][4][11,1]*r[C][1][10,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[C,0])]*r[A][4][11,1]*r[C][1][10,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[C,0])]*r[A][4][11,1]*r[C][1][10,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,0],p[A,1],p[I,0])]*r[A][4][11,1]*r[C][1][10,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,0],p[A,1],p[I,1])]*r[A][4][11,1]*r[C][1][10,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[C,0])]*r[A][4][11,1]*r[C][1][10,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[C,0])]*r[A][4][11,1]*r[C][1][10,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[C,0])]*r[A][4][11,1]*r[B][9][2,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[C,0])]*r[A][4][11,1]*r[B][39][2,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[B,0])]*r[A][4][11,1]*r[B][9][2,2]*r[C][1][10,3]
    hv += g[dei(p[A,1],p[C,0],p[B,0],p[B,0])]*r[A][4][11,1]*r[B][24][2,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[B,1])]*r[A][4][11,1]*r[B][39][2,2]*r[C][1][10,3]
    hv += g[dei(p[A,1],p[C,0],p[B,1],p[B,1])]*r[A][4][11,1]*r[B][54][2,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[C,0])]*r[A][4][11,1]*r[B][9][2,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[C,0])]*r[A][4][11,1]*r[B][39][2,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[B,0])]*r[A][4][11,1]*r[B][9][2,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[B,1])]*r[A][4][11,1]*r[B][39][2,2]*r[C][1][10,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B2C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,2),(C,8)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += h[p[A,1],p[C,0]]*r[A][6][13,1]*r[C][3][8,3]
    hv += -1*g[dei(p[A,0],p[A,1],p[A,0],p[C,0])]*r[A][68][13,1]*r[C][3][8,3]
    hv += -1/2*g[dei(p[A,0],p[A,0],p[A,1],p[C,0])]*r[A][114][13,1]*r[C][3][8,3]
    hv += -1*g[dei(p[A,0],p[A,0],p[A,1],p[C,0])]*r[A][80][13,1]*r[C][3][8,3]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[A,0],p[C,0])]*r[A][162][13,1]*r[C][3][8,3]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[A,1],p[A,0])]*r[A][114][13,1]*r[C][3][8,3]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[A,0],p[A,0])]*r[A][162][13,1]*r[C][3][8,3]
    hv += -1*g[dei(p[C,1],p[C,0],p[A,1],p[C,1])]*r[A][6][13,1]*r[C][145][8,3]
    hv += -1*g[dei(p[C,1],p[C,1],p[A,1],p[C,0])]*r[A][6][13,1]*r[C][133][8,3]
    hv += sum(1/2*g[dei(p[A,1],p[C,0],p[I,0],p[I,0])]*r[A][6][13,1]*r[C][3][8,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[C,0],p[I,1],p[I,1])]*r[A][6][13,1]*r[C][3][8,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[C,0])]*r[A][6][13,1]*r[C][3][8,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[C,0])]*r[A][6][13,1]*r[C][3][8,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,0],p[A,1],p[I,0])]*r[A][6][13,1]*r[C][3][8,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,0],p[A,1],p[I,1])]*r[A][6][13,1]*r[C][3][8,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[C,0])]*r[A][6][13,1]*r[C][3][8,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,1],p[C,0])]*r[A][6][13,1]*r[C][3][8,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[C,0])]*r[A][6][13,1]*r[C][3][8,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,1],p[C,0])]*r[A][6][13,1]*r[C][3][8,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[C,0])]*r[A][6][13,1]*r[B][24][2,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[C,0])]*r[A][6][13,1]*r[B][54][2,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[B,0])]*r[A][6][13,1]*r[B][24][2,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[B,1])]*r[A][6][13,1]*r[B][54][2,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][24][2,2]*r[C][3][8,3]
    hv += g[dei(p[B,0],p[B,0],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][9][2,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][54][2,2]*r[C][3][8,3]
    hv += g[dei(p[B,1],p[B,1],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][39][2,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][24][2,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][54][2,2]*r[C][3][8,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11B2C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,2),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += h[p[A,1],p[C,1]]*r[A][4][11,1]*r[C][5][9,3]
    hv += -1/2*g[dei(p[A,0],p[A,0],p[A,1],p[C,1])]*r[A][72][11,1]*r[C][5][9,3]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[A,0],p[C,1])]*r[A][120][11,1]*r[C][5][9,3]
    hv += g[dei(p[A,0],p[C,1],p[A,0],p[A,1])]*r[A][70][11,1]*r[C][5][9,3]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[A,1],p[A,0])]*r[A][72][11,1]*r[C][5][9,3]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[A,0],p[A,0])]*r[A][120][11,1]*r[C][5][9,3]
    hv += g[dei(p[A,1],p[C,1],p[A,0],p[A,0])]*r[A][130][11,1]*r[C][5][9,3]
    hv += g[dei(p[A,1],p[C,0],p[C,0],p[C,1])]*r[A][4][11,1]*r[C][113][9,3]
    hv += g[dei(p[A,1],p[C,1],p[C,0],p[C,0])]*r[A][4][11,1]*r[C][101][9,3]
    hv += sum(1/2*g[dei(p[A,1],p[C,1],p[I,0],p[I,0])]*r[A][4][11,1]*r[C][5][9,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[C,1],p[I,0],p[I,0])]*r[A][4][11,1]*r[C][5][9,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[C,1],p[I,1],p[I,1])]*r[A][4][11,1]*r[C][5][9,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[C,1],p[I,1],p[I,1])]*r[A][4][11,1]*r[C][5][9,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[C,1])]*r[A][4][11,1]*r[C][5][9,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[C,1])]*r[A][4][11,1]*r[C][5][9,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,1],p[A,1],p[I,0])]*r[A][4][11,1]*r[C][5][9,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,1],p[A,1],p[I,1])]*r[A][4][11,1]*r[C][5][9,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[C,1])]*r[A][4][11,1]*r[C][5][9,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[C,1])]*r[A][4][11,1]*r[C][5][9,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[C,1])]*r[A][4][11,1]*r[B][9][2,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[C,1])]*r[A][4][11,1]*r[B][39][2,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[B,0])]*r[A][4][11,1]*r[B][9][2,2]*r[C][5][9,3]
    hv += g[dei(p[A,1],p[C,1],p[B,0],p[B,0])]*r[A][4][11,1]*r[B][24][2,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[B,1])]*r[A][4][11,1]*r[B][39][2,2]*r[C][5][9,3]
    hv += g[dei(p[A,1],p[C,1],p[B,1],p[B,1])]*r[A][4][11,1]*r[B][54][2,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[C,1])]*r[A][4][11,1]*r[B][9][2,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[C,1])]*r[A][4][11,1]*r[B][39][2,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[B,0])]*r[A][4][11,1]*r[B][9][2,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[B,1])]*r[A][4][11,1]*r[B][39][2,2]*r[C][5][9,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B2C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,2),(C,7)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += h[p[A,1],p[C,1]]*r[A][6][13,1]*r[C][7][7,3]
    hv += -1*g[dei(p[A,0],p[A,1],p[A,0],p[C,1])]*r[A][68][13,1]*r[C][7][7,3]
    hv += -1/2*g[dei(p[A,0],p[A,0],p[A,1],p[C,1])]*r[A][114][13,1]*r[C][7][7,3]
    hv += -1*g[dei(p[A,0],p[A,0],p[A,1],p[C,1])]*r[A][80][13,1]*r[C][7][7,3]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[A,0],p[C,1])]*r[A][162][13,1]*r[C][7][7,3]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[A,1],p[A,0])]*r[A][114][13,1]*r[C][7][7,3]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[A,0],p[A,0])]*r[A][162][13,1]*r[C][7][7,3]
    hv += -1*g[dei(p[C,0],p[C,0],p[A,1],p[C,1])]*r[A][6][13,1]*r[C][81][7,3]
    hv += -1*g[dei(p[C,0],p[C,1],p[A,1],p[C,0])]*r[A][6][13,1]*r[C][69][7,3]
    hv += sum(1/2*g[dei(p[A,1],p[C,1],p[I,0],p[I,0])]*r[A][6][13,1]*r[C][7][7,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[C,1],p[I,1],p[I,1])]*r[A][6][13,1]*r[C][7][7,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[C,1])]*r[A][6][13,1]*r[C][7][7,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[C,1])]*r[A][6][13,1]*r[C][7][7,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,1],p[A,1],p[I,0])]*r[A][6][13,1]*r[C][7][7,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,1],p[A,1],p[I,1])]*r[A][6][13,1]*r[C][7][7,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[C,1])]*r[A][6][13,1]*r[C][7][7,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,1],p[C,1])]*r[A][6][13,1]*r[C][7][7,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[C,1])]*r[A][6][13,1]*r[C][7][7,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,1],p[C,1])]*r[A][6][13,1]*r[C][7][7,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[C,1])]*r[A][6][13,1]*r[B][24][2,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[C,1])]*r[A][6][13,1]*r[B][54][2,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[B,0])]*r[A][6][13,1]*r[B][24][2,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[B,1])]*r[A][6][13,1]*r[B][54][2,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[C,1])]*r[A][6][13,1]*r[B][24][2,2]*r[C][7][7,3]
    hv += g[dei(p[B,0],p[B,0],p[A,1],p[C,1])]*r[A][6][13,1]*r[B][9][2,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[C,1])]*r[A][6][13,1]*r[B][54][2,2]*r[C][7][7,3]
    hv += g[dei(p[B,1],p[B,1],p[A,1],p[C,1])]*r[A][6][13,1]*r[B][39][2,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][24][2,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][54][2,2]*r[C][7][7,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B2C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,2),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[C,0],p[A,0]]*r[A][1][9,1]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[A,0],p[A,0],p[A,0])]*r[A][97][9,1]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[A,1],p[A,0],p[A,1])]*r[A][117][9,1]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[A,0],p[C,0],p[C,0])]*r[A][1][9,1]*r[C][66][11,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[C,1],p[C,1])]*r[A][1][9,1]*r[C][76][11,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[C,0],p[C,1])]*r[A][1][9,1]*r[C][124][11,3]
    hv += -1*g[dei(p[C,1],p[A,0],p[C,0],p[C,1])]*r[A][1][9,1]*r[C][134][11,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[C,1],p[A,0])]*r[A][1][9,1]*r[C][76][11,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[C,0],p[A,0])]*r[A][1][9,1]*r[C][124][11,3]
    hv += sum(-1/2*g[dei(p[C,0],p[A,0],p[I,0],p[I,0])]*r[A][1][9,1]*r[C][0][11,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,0],p[A,0],p[I,0],p[I,0])]*r[A][1][9,1]*r[C][0][11,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[A,0],p[I,1],p[I,1])]*r[A][1][9,1]*r[C][0][11,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,0],p[A,0],p[I,1],p[I,1])]*r[A][1][9,1]*r[C][0][11,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[I,0],p[I,0],p[A,0])]*r[A][1][9,1]*r[C][0][11,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[I,1],p[I,1],p[A,0])]*r[A][1][9,1]*r[C][0][11,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,0],p[C,0],p[I,0])]*r[A][1][9,1]*r[C][0][11,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,0],p[C,0],p[I,1])]*r[A][1][9,1]*r[C][0][11,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[C,0],p[A,0])]*r[A][1][9,1]*r[C][0][11,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[C,0],p[A,0])]*r[A][1][9,1]*r[C][0][11,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[B,0],p[A,0],p[C,0],p[B,0])]*r[A][1][9,1]*r[B][9][2,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[C,0],p[B,1])]*r[A][1][9,1]*r[B][39][2,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[B,0],p[B,0],p[C,0],p[A,0])]*r[A][1][9,1]*r[B][9][2,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[B,1],p[B,1],p[C,0],p[A,0])]*r[A][1][9,1]*r[B][39][2,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[B,0],p[B,0])]*r[A][1][9,1]*r[B][9][2,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[A,0],p[B,0],p[B,0])]*r[A][1][9,1]*r[B][24][2,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[B,1],p[B,1])]*r[A][1][9,1]*r[B][39][2,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[A,0],p[B,1],p[B,1])]*r[A][1][9,1]*r[B][54][2,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[B,0],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][9][2,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[B,1],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][39][2,2]*r[C][0][11,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B2C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,2),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[C,0],p[A,0]]*r[A][3][7,1]*r[C][2][13,3]
    hv += g[dei(p[A,0],p[A,0],p[C,0],p[A,0])]*r[A][65][7,1]*r[C][2][13,3]
    hv += g[dei(p[A,0],p[A,1],p[C,0],p[A,1])]*r[A][85][7,1]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[C,1],p[C,1])]*r[A][3][7,1]*r[C][118][13,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[C,0],p[C,1])]*r[A][3][7,1]*r[C][166][13,3]
    hv += g[dei(p[C,0],p[C,0],p[C,0],p[A,0])]*r[A][3][7,1]*r[C][64][13,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[C,1],p[A,0])]*r[A][3][7,1]*r[C][118][13,3]
    hv += g[dei(p[C,0],p[C,1],p[C,1],p[A,0])]*r[A][3][7,1]*r[C][84][13,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[C,0],p[A,0])]*r[A][3][7,1]*r[C][166][13,3]
    hv += sum(-1/2*g[dei(p[C,0],p[A,0],p[I,0],p[I,0])]*r[A][3][7,1]*r[C][2][13,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[A,0],p[I,1],p[I,1])]*r[A][3][7,1]*r[C][2][13,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[I,0],p[I,0],p[A,0])]*r[A][3][7,1]*r[C][2][13,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[I,1],p[I,1],p[A,0])]*r[A][3][7,1]*r[C][2][13,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,0],p[C,0],p[I,0])]*r[A][3][7,1]*r[C][2][13,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,0],p[C,0],p[I,1])]*r[A][3][7,1]*r[C][2][13,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[C,0],p[A,0])]*r[A][3][7,1]*r[C][2][13,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[C,0],p[A,0])]*r[A][3][7,1]*r[C][2][13,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[C,0],p[A,0])]*r[A][3][7,1]*r[C][2][13,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[C,0],p[A,0])]*r[A][3][7,1]*r[C][2][13,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[B,0],p[A,0],p[C,0],p[B,0])]*r[A][3][7,1]*r[B][24][2,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[C,0],p[B,1])]*r[A][3][7,1]*r[B][54][2,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[B,0],p[B,0],p[C,0],p[A,0])]*r[A][3][7,1]*r[B][24][2,2]*r[C][2][13,3]
    hv += -1*g[dei(p[B,0],p[B,0],p[C,0],p[A,0])]*r[A][3][7,1]*r[B][9][2,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[B,1],p[B,1],p[C,0],p[A,0])]*r[A][3][7,1]*r[B][54][2,2]*r[C][2][13,3]
    hv += -1*g[dei(p[B,1],p[B,1],p[C,0],p[A,0])]*r[A][3][7,1]*r[B][39][2,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[B,0],p[B,0])]*r[A][3][7,1]*r[B][24][2,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[B,1],p[B,1])]*r[A][3][7,1]*r[B][54][2,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[B,0],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][24][2,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[B,1],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][54][2,2]*r[C][2][13,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B2C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,2),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[C,0],p[A,1]]*r[A][5][10,1]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[A,0],p[A,1],p[A,0])]*r[A][161][10,1]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[A,1],p[A,1],p[A,1])]*r[A][181][10,1]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[A,1],p[C,0],p[C,0])]*r[A][5][10,1]*r[C][66][11,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[C,1],p[C,1])]*r[A][5][10,1]*r[C][76][11,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[C,0],p[C,1])]*r[A][5][10,1]*r[C][124][11,3]
    hv += -1*g[dei(p[C,1],p[A,1],p[C,0],p[C,1])]*r[A][5][10,1]*r[C][134][11,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[C,1],p[A,1])]*r[A][5][10,1]*r[C][76][11,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[C,0],p[A,1])]*r[A][5][10,1]*r[C][124][11,3]
    hv += sum(-1/2*g[dei(p[C,0],p[A,1],p[I,0],p[I,0])]*r[A][5][10,1]*r[C][0][11,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,0],p[A,1],p[I,0],p[I,0])]*r[A][5][10,1]*r[C][0][11,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[A,1],p[I,1],p[I,1])]*r[A][5][10,1]*r[C][0][11,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,0],p[A,1],p[I,1],p[I,1])]*r[A][5][10,1]*r[C][0][11,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[I,0],p[I,0],p[A,1])]*r[A][5][10,1]*r[C][0][11,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[I,1],p[I,1],p[A,1])]*r[A][5][10,1]*r[C][0][11,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,1],p[C,0],p[I,0])]*r[A][5][10,1]*r[C][0][11,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,1],p[C,0],p[I,1])]*r[A][5][10,1]*r[C][0][11,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[C,0],p[A,1])]*r[A][5][10,1]*r[C][0][11,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[C,0],p[A,1])]*r[A][5][10,1]*r[C][0][11,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[B,0],p[A,1],p[C,0],p[B,0])]*r[A][5][10,1]*r[B][9][2,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[C,0],p[B,1])]*r[A][5][10,1]*r[B][39][2,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[B,0],p[B,0],p[C,0],p[A,1])]*r[A][5][10,1]*r[B][9][2,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[B,1],p[B,1],p[C,0],p[A,1])]*r[A][5][10,1]*r[B][39][2,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[B,0],p[B,0])]*r[A][5][10,1]*r[B][9][2,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[A,1],p[B,0],p[B,0])]*r[A][5][10,1]*r[B][24][2,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[B,1],p[B,1])]*r[A][5][10,1]*r[B][39][2,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[A,1],p[B,1],p[B,1])]*r[A][5][10,1]*r[B][54][2,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[B,0],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][9][2,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[B,1],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][39][2,2]*r[C][0][11,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B2C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,2),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[C,0],p[A,1]]*r[A][7][8,1]*r[C][2][13,3]
    hv += g[dei(p[A,1],p[A,0],p[C,0],p[A,0])]*r[A][129][8,1]*r[C][2][13,3]
    hv += g[dei(p[A,1],p[A,1],p[C,0],p[A,1])]*r[A][149][8,1]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[C,1],p[C,1])]*r[A][7][8,1]*r[C][118][13,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[C,0],p[C,1])]*r[A][7][8,1]*r[C][166][13,3]
    hv += g[dei(p[C,0],p[C,0],p[C,0],p[A,1])]*r[A][7][8,1]*r[C][64][13,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[C,1],p[A,1])]*r[A][7][8,1]*r[C][118][13,3]
    hv += g[dei(p[C,0],p[C,1],p[C,1],p[A,1])]*r[A][7][8,1]*r[C][84][13,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[C,0],p[A,1])]*r[A][7][8,1]*r[C][166][13,3]
    hv += sum(-1/2*g[dei(p[C,0],p[A,1],p[I,0],p[I,0])]*r[A][7][8,1]*r[C][2][13,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[A,1],p[I,1],p[I,1])]*r[A][7][8,1]*r[C][2][13,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[I,0],p[I,0],p[A,1])]*r[A][7][8,1]*r[C][2][13,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[I,1],p[I,1],p[A,1])]*r[A][7][8,1]*r[C][2][13,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,1],p[C,0],p[I,0])]*r[A][7][8,1]*r[C][2][13,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,1],p[C,0],p[I,1])]*r[A][7][8,1]*r[C][2][13,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[C,0],p[A,1])]*r[A][7][8,1]*r[C][2][13,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[C,0],p[A,1])]*r[A][7][8,1]*r[C][2][13,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[C,0],p[A,1])]*r[A][7][8,1]*r[C][2][13,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[C,0],p[A,1])]*r[A][7][8,1]*r[C][2][13,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[B,0],p[A,1],p[C,0],p[B,0])]*r[A][7][8,1]*r[B][24][2,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[C,0],p[B,1])]*r[A][7][8,1]*r[B][54][2,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[B,0],p[B,0],p[C,0],p[A,1])]*r[A][7][8,1]*r[B][24][2,2]*r[C][2][13,3]
    hv += -1*g[dei(p[B,0],p[B,0],p[C,0],p[A,1])]*r[A][7][8,1]*r[B][9][2,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[B,1],p[B,1],p[C,0],p[A,1])]*r[A][7][8,1]*r[B][54][2,2]*r[C][2][13,3]
    hv += -1*g[dei(p[B,1],p[B,1],p[C,0],p[A,1])]*r[A][7][8,1]*r[B][39][2,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[B,0],p[B,0])]*r[A][7][8,1]*r[B][24][2,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[B,1],p[B,1])]*r[A][7][8,1]*r[B][54][2,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[B,0],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][24][2,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[B,1],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][54][2,2]*r[C][2][13,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B2C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,2),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[C,1],p[A,0]]*r[A][1][9,1]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[A,0],p[A,0],p[A,0])]*r[A][97][9,1]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[A,1],p[A,0],p[A,1])]*r[A][117][9,1]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[C,1],p[C,0])]*r[A][1][9,1]*r[C][72][12,3]
    hv += -1*g[dei(p[C,0],p[A,0],p[C,1],p[C,0])]*r[A][1][9,1]*r[C][82][12,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[C,0],p[C,0])]*r[A][1][9,1]*r[C][120][12,3]
    hv += -1*g[dei(p[C,1],p[A,0],p[C,1],p[C,1])]*r[A][1][9,1]*r[C][150][12,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[C,1],p[A,0])]*r[A][1][9,1]*r[C][72][12,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[C,0],p[A,0])]*r[A][1][9,1]*r[C][120][12,3]
    hv += sum(-1/2*g[dei(p[C,1],p[A,0],p[I,0],p[I,0])]*r[A][1][9,1]*r[C][4][12,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,1],p[A,0],p[I,0],p[I,0])]*r[A][1][9,1]*r[C][4][12,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[A,0],p[I,1],p[I,1])]*r[A][1][9,1]*r[C][4][12,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,1],p[A,0],p[I,1],p[I,1])]*r[A][1][9,1]*r[C][4][12,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[I,0],p[I,0],p[A,0])]*r[A][1][9,1]*r[C][4][12,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[I,1],p[I,1],p[A,0])]*r[A][1][9,1]*r[C][4][12,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,0],p[C,1],p[I,0])]*r[A][1][9,1]*r[C][4][12,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,0],p[C,1],p[I,1])]*r[A][1][9,1]*r[C][4][12,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[C,1],p[A,0])]*r[A][1][9,1]*r[C][4][12,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[C,1],p[A,0])]*r[A][1][9,1]*r[C][4][12,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[B,0],p[A,0],p[C,1],p[B,0])]*r[A][1][9,1]*r[B][9][2,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[C,1],p[B,1])]*r[A][1][9,1]*r[B][39][2,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[B,0],p[B,0],p[C,1],p[A,0])]*r[A][1][9,1]*r[B][9][2,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[B,1],p[B,1],p[C,1],p[A,0])]*r[A][1][9,1]*r[B][39][2,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[B,0],p[B,0])]*r[A][1][9,1]*r[B][9][2,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[A,0],p[B,0],p[B,0])]*r[A][1][9,1]*r[B][24][2,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[B,1],p[B,1])]*r[A][1][9,1]*r[B][39][2,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[A,0],p[B,1],p[B,1])]*r[A][1][9,1]*r[B][54][2,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[B,0],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][9][2,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[B,1],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][39][2,2]*r[C][4][12,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B2C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,2),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[C,1],p[A,0]]*r[A][3][7,1]*r[C][6][14,3]
    hv += g[dei(p[A,0],p[A,0],p[C,1],p[A,0])]*r[A][65][7,1]*r[C][6][14,3]
    hv += g[dei(p[A,0],p[A,1],p[C,1],p[A,1])]*r[A][85][7,1]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[C,1],p[C,0])]*r[A][3][7,1]*r[C][114][14,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[C,0],p[C,0])]*r[A][3][7,1]*r[C][162][14,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[C,1],p[A,0])]*r[A][3][7,1]*r[C][114][14,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[C,0],p[A,0])]*r[A][3][7,1]*r[C][162][14,3]
    hv += g[dei(p[C,1],p[C,0],p[C,0],p[A,0])]*r[A][3][7,1]*r[C][128][14,3]
    hv += g[dei(p[C,1],p[C,1],p[C,1],p[A,0])]*r[A][3][7,1]*r[C][148][14,3]
    hv += sum(-1/2*g[dei(p[C,1],p[A,0],p[I,0],p[I,0])]*r[A][3][7,1]*r[C][6][14,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[A,0],p[I,1],p[I,1])]*r[A][3][7,1]*r[C][6][14,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[I,0],p[I,0],p[A,0])]*r[A][3][7,1]*r[C][6][14,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[I,1],p[I,1],p[A,0])]*r[A][3][7,1]*r[C][6][14,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,0],p[C,1],p[I,0])]*r[A][3][7,1]*r[C][6][14,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,0],p[C,1],p[I,1])]*r[A][3][7,1]*r[C][6][14,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[C,1],p[A,0])]*r[A][3][7,1]*r[C][6][14,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[C,1],p[A,0])]*r[A][3][7,1]*r[C][6][14,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[C,1],p[A,0])]*r[A][3][7,1]*r[C][6][14,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[C,1],p[A,0])]*r[A][3][7,1]*r[C][6][14,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[B,0],p[A,0],p[C,1],p[B,0])]*r[A][3][7,1]*r[B][24][2,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[C,1],p[B,1])]*r[A][3][7,1]*r[B][54][2,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[B,0],p[B,0],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][24][2,2]*r[C][6][14,3]
    hv += -1*g[dei(p[B,0],p[B,0],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][9][2,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[B,1],p[B,1],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][54][2,2]*r[C][6][14,3]
    hv += -1*g[dei(p[B,1],p[B,1],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][39][2,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[B,0],p[B,0])]*r[A][3][7,1]*r[B][24][2,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[B,1],p[B,1])]*r[A][3][7,1]*r[B][54][2,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[B,0],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][24][2,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[B,1],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][54][2,2]*r[C][6][14,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B2C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,2),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[C,1],p[A,1]]*r[A][5][10,1]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[A,0],p[A,1],p[A,0])]*r[A][161][10,1]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[A,1],p[A,1],p[A,1])]*r[A][181][10,1]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[C,1],p[C,0])]*r[A][5][10,1]*r[C][72][12,3]
    hv += -1*g[dei(p[C,0],p[A,1],p[C,1],p[C,0])]*r[A][5][10,1]*r[C][82][12,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[C,0],p[C,0])]*r[A][5][10,1]*r[C][120][12,3]
    hv += -1*g[dei(p[C,1],p[A,1],p[C,1],p[C,1])]*r[A][5][10,1]*r[C][150][12,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[C,1],p[A,1])]*r[A][5][10,1]*r[C][72][12,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[C,0],p[A,1])]*r[A][5][10,1]*r[C][120][12,3]
    hv += sum(-1/2*g[dei(p[C,1],p[A,1],p[I,0],p[I,0])]*r[A][5][10,1]*r[C][4][12,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,1],p[A,1],p[I,0],p[I,0])]*r[A][5][10,1]*r[C][4][12,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[A,1],p[I,1],p[I,1])]*r[A][5][10,1]*r[C][4][12,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,1],p[A,1],p[I,1],p[I,1])]*r[A][5][10,1]*r[C][4][12,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[I,0],p[I,0],p[A,1])]*r[A][5][10,1]*r[C][4][12,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[I,1],p[I,1],p[A,1])]*r[A][5][10,1]*r[C][4][12,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,1],p[C,1],p[I,0])]*r[A][5][10,1]*r[C][4][12,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,1],p[C,1],p[I,1])]*r[A][5][10,1]*r[C][4][12,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[C,1],p[A,1])]*r[A][5][10,1]*r[C][4][12,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[C,1],p[A,1])]*r[A][5][10,1]*r[C][4][12,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[B,0],p[A,1],p[C,1],p[B,0])]*r[A][5][10,1]*r[B][9][2,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[C,1],p[B,1])]*r[A][5][10,1]*r[B][39][2,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[B,0],p[B,0],p[C,1],p[A,1])]*r[A][5][10,1]*r[B][9][2,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[B,1],p[B,1],p[C,1],p[A,1])]*r[A][5][10,1]*r[B][39][2,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[B,0],p[B,0])]*r[A][5][10,1]*r[B][9][2,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[A,1],p[B,0],p[B,0])]*r[A][5][10,1]*r[B][24][2,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[B,1],p[B,1])]*r[A][5][10,1]*r[B][39][2,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[A,1],p[B,1],p[B,1])]*r[A][5][10,1]*r[B][54][2,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[B,0],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][9][2,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[B,1],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][39][2,2]*r[C][4][12,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B2C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,2),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[C,1],p[A,1]]*r[A][7][8,1]*r[C][6][14,3]
    hv += g[dei(p[A,1],p[A,0],p[C,1],p[A,0])]*r[A][129][8,1]*r[C][6][14,3]
    hv += g[dei(p[A,1],p[A,1],p[C,1],p[A,1])]*r[A][149][8,1]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[C,1],p[C,0])]*r[A][7][8,1]*r[C][114][14,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[C,0],p[C,0])]*r[A][7][8,1]*r[C][162][14,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[C,1],p[A,1])]*r[A][7][8,1]*r[C][114][14,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[C,0],p[A,1])]*r[A][7][8,1]*r[C][162][14,3]
    hv += g[dei(p[C,1],p[C,0],p[C,0],p[A,1])]*r[A][7][8,1]*r[C][128][14,3]
    hv += g[dei(p[C,1],p[C,1],p[C,1],p[A,1])]*r[A][7][8,1]*r[C][148][14,3]
    hv += sum(-1/2*g[dei(p[C,1],p[A,1],p[I,0],p[I,0])]*r[A][7][8,1]*r[C][6][14,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[A,1],p[I,1],p[I,1])]*r[A][7][8,1]*r[C][6][14,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[I,0],p[I,0],p[A,1])]*r[A][7][8,1]*r[C][6][14,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[I,1],p[I,1],p[A,1])]*r[A][7][8,1]*r[C][6][14,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,1],p[C,1],p[I,0])]*r[A][7][8,1]*r[C][6][14,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,1],p[C,1],p[I,1])]*r[A][7][8,1]*r[C][6][14,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[C,1],p[A,1])]*r[A][7][8,1]*r[C][6][14,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[C,1],p[A,1])]*r[A][7][8,1]*r[C][6][14,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[C,1],p[A,1])]*r[A][7][8,1]*r[C][6][14,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[C,1],p[A,1])]*r[A][7][8,1]*r[C][6][14,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[B,0],p[A,1],p[C,1],p[B,0])]*r[A][7][8,1]*r[B][24][2,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[C,1],p[B,1])]*r[A][7][8,1]*r[B][54][2,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[B,0],p[B,0],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][24][2,2]*r[C][6][14,3]
    hv += -1*g[dei(p[B,0],p[B,0],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][9][2,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[B,1],p[B,1],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][54][2,2]*r[C][6][14,3]
    hv += -1*g[dei(p[B,1],p[B,1],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][39][2,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[B,0],p[B,0])]*r[A][7][8,1]*r[B][24][2,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[B,1],p[B,1])]*r[A][7][8,1]*r[B][54][2,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[B,0],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][24][2,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[B,1],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][54][2,2]*r[C][6][14,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A15B2C6(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,15),(B,2),(C,6)]))
    hv = 0.0
    
    hv += g[dei(p[A,0],p[C,0],p[A,0],p[C,1])]*r[A][11][15,1]*r[C][46][6,3]
    hv += g[dei(p[A,0],p[C,1],p[A,0],p[C,0])]*r[A][11][15,1]*r[C][28][6,3]
    hv += g[dei(p[A,1],p[C,0],p[A,1],p[C,1])]*r[A][41][15,1]*r[C][46][6,3]
    hv += g[dei(p[A,1],p[C,1],p[A,1],p[C,0])]*r[A][41][15,1]*r[C][28][6,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _B2C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(B,2),(C,2)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[C,0])]*r[A][9][0,1]*r[C][9][2,3]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[C,0])]*r[A][24][0,1]*r[C][24][2,3]
    hv += g[dei(p[A,0],p[A,0],p[C,0],p[C,0])]*r[A][9][0,1]*r[C][24][2,3]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[C,1])]*r[A][9][0,1]*r[C][39][2,3]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[C,1])]*r[A][24][0,1]*r[C][54][2,3]
    hv += g[dei(p[A,0],p[A,0],p[C,1],p[C,1])]*r[A][9][0,1]*r[C][54][2,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[C,0])]*r[A][39][0,1]*r[C][9][2,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[C,0])]*r[A][54][0,1]*r[C][24][2,3]
    hv += g[dei(p[A,1],p[A,1],p[C,0],p[C,0])]*r[A][39][0,1]*r[C][24][2,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[C,1])]*r[A][39][0,1]*r[C][39][2,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[C,1])]*r[A][54][0,1]*r[C][54][2,3]
    hv += g[dei(p[A,1],p[A,1],p[C,1],p[C,1])]*r[A][39][0,1]*r[C][54][2,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,0])]*r[A][9][0,1]*r[C][9][2,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,0])]*r[A][24][0,1]*r[C][24][2,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,0])]*r[A][9][0,1]*r[C][39][2,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,0])]*r[A][24][0,1]*r[C][54][2,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,1])]*r[A][39][0,1]*r[C][9][2,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,1])]*r[A][54][0,1]*r[C][24][2,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,1])]*r[A][39][0,1]*r[C][39][2,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,1])]*r[A][54][0,1]*r[C][54][2,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[C,0])]*r[A][9][0,1]*r[C][9][2,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[C,0])]*r[A][24][0,1]*r[C][24][2,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[C,0])]*r[A][39][0,1]*r[C][9][2,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[C,0])]*r[A][54][0,1]*r[C][24][2,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[C,1])]*r[A][9][0,1]*r[C][39][2,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[C,1])]*r[A][24][0,1]*r[C][54][2,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[C,1])]*r[A][39][0,1]*r[C][39][2,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[C,1])]*r[A][54][0,1]*r[C][54][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][24][2,3]
    hv += g[dei(p[C,0],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][24][2,3]
    hv += g[dei(p[C,0],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][54][2,3]
    hv += g[dei(p[C,1],p[C,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][54][2,3]
    hv += g[dei(p[C,1],p[C,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][39][2,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _B2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(B,2)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[C,1])]*r[A][9][0,1]*r[C][15][0,3]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[C,1])]*r[A][24][0,1]*r[C][30][0,3]
    hv += g[dei(p[A,0],p[A,0],p[C,0],p[C,1])]*r[A][9][0,1]*r[C][30][0,3]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[C,0])]*r[A][9][0,1]*r[C][33][0,3]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[C,0])]*r[A][24][0,1]*r[C][48][0,3]
    hv += g[dei(p[A,0],p[A,0],p[C,1],p[C,0])]*r[A][9][0,1]*r[C][48][0,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[C,1])]*r[A][39][0,1]*r[C][15][0,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[C,1])]*r[A][54][0,1]*r[C][30][0,3]
    hv += g[dei(p[A,1],p[A,1],p[C,0],p[C,1])]*r[A][39][0,1]*r[C][30][0,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[C,0])]*r[A][39][0,1]*r[C][33][0,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[C,0])]*r[A][54][0,1]*r[C][48][0,3]
    hv += g[dei(p[A,1],p[A,1],p[C,1],p[C,0])]*r[A][39][0,1]*r[C][48][0,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[A,0])]*r[A][9][0,1]*r[C][15][0,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[A,0])]*r[A][24][0,1]*r[C][30][0,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[A,0])]*r[A][9][0,1]*r[C][33][0,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[A,0])]*r[A][24][0,1]*r[C][48][0,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[A,1])]*r[A][39][0,1]*r[C][15][0,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[A,1])]*r[A][54][0,1]*r[C][30][0,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[A,1])]*r[A][39][0,1]*r[C][33][0,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[A,1])]*r[A][54][0,1]*r[C][48][0,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[C,1])]*r[A][9][0,1]*r[C][15][0,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[C,1])]*r[A][24][0,1]*r[C][30][0,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[C,1])]*r[A][39][0,1]*r[C][15][0,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[C,1])]*r[A][54][0,1]*r[C][30][0,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[C,0])]*r[A][9][0,1]*r[C][33][0,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[C,0])]*r[A][24][0,1]*r[C][48][0,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[C,0])]*r[A][39][0,1]*r[C][33][0,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[C,0])]*r[A][54][0,1]*r[C][48][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][30][0,3]
    hv += g[dei(p[C,0],p[C,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][30][0,3]
    hv += g[dei(p[C,0],p[C,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][48][0,3]
    hv += g[dei(p[C,1],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][48][0,3]
    hv += g[dei(p[C,1],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][33][0,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _B2C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(B,2),(C,1)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[C,1])]*r[A][9][0,1]*r[C][15][1,3]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[C,1])]*r[A][24][0,1]*r[C][30][1,3]
    hv += g[dei(p[A,0],p[A,0],p[C,0],p[C,1])]*r[A][9][0,1]*r[C][30][1,3]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[C,0])]*r[A][9][0,1]*r[C][33][1,3]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[C,0])]*r[A][24][0,1]*r[C][48][1,3]
    hv += g[dei(p[A,0],p[A,0],p[C,1],p[C,0])]*r[A][9][0,1]*r[C][48][1,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[C,1])]*r[A][39][0,1]*r[C][15][1,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[C,1])]*r[A][54][0,1]*r[C][30][1,3]
    hv += g[dei(p[A,1],p[A,1],p[C,0],p[C,1])]*r[A][39][0,1]*r[C][30][1,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[C,0])]*r[A][39][0,1]*r[C][33][1,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[C,0])]*r[A][54][0,1]*r[C][48][1,3]
    hv += g[dei(p[A,1],p[A,1],p[C,1],p[C,0])]*r[A][39][0,1]*r[C][48][1,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[A,0])]*r[A][9][0,1]*r[C][15][1,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[A,0])]*r[A][24][0,1]*r[C][30][1,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[A,0])]*r[A][9][0,1]*r[C][33][1,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[A,0])]*r[A][24][0,1]*r[C][48][1,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[A,1])]*r[A][39][0,1]*r[C][15][1,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[A,1])]*r[A][54][0,1]*r[C][30][1,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[A,1])]*r[A][39][0,1]*r[C][33][1,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[A,1])]*r[A][54][0,1]*r[C][48][1,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[C,1])]*r[A][9][0,1]*r[C][15][1,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[C,1])]*r[A][24][0,1]*r[C][30][1,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[C,1])]*r[A][39][0,1]*r[C][15][1,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[C,1])]*r[A][54][0,1]*r[C][30][1,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[C,0])]*r[A][9][0,1]*r[C][33][1,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[C,0])]*r[A][24][0,1]*r[C][48][1,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[C,0])]*r[A][39][0,1]*r[C][33][1,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[C,0])]*r[A][54][0,1]*r[C][48][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][30][1,3]
    hv += g[dei(p[C,0],p[C,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][30][1,3]
    hv += g[dei(p[C,0],p[C,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][48][1,3]
    hv += g[dei(p[C,1],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][48][1,3]
    hv += g[dei(p[C,1],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][33][1,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A2B2C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(B,2),(C,2)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,0],p[C,0])]*r[A][15][2,1]*r[C][9][2,3]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,0],p[C,0])]*r[A][30][2,1]*r[C][24][2,3]
    hv += g[dei(p[A,0],p[A,1],p[C,0],p[C,0])]*r[A][15][2,1]*r[C][24][2,3]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,1],p[C,1])]*r[A][15][2,1]*r[C][39][2,3]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,1],p[C,1])]*r[A][30][2,1]*r[C][54][2,3]
    hv += g[dei(p[A,0],p[A,1],p[C,1],p[C,1])]*r[A][15][2,1]*r[C][54][2,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,0],p[C,0])]*r[A][33][2,1]*r[C][9][2,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,0],p[C,0])]*r[A][48][2,1]*r[C][24][2,3]
    hv += g[dei(p[A,1],p[A,0],p[C,0],p[C,0])]*r[A][33][2,1]*r[C][24][2,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,1],p[C,1])]*r[A][33][2,1]*r[C][39][2,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,1],p[C,1])]*r[A][48][2,1]*r[C][54][2,3]
    hv += g[dei(p[A,1],p[A,0],p[C,1],p[C,1])]*r[A][33][2,1]*r[C][54][2,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,1])]*r[A][15][2,1]*r[C][9][2,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,1])]*r[A][30][2,1]*r[C][24][2,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,1])]*r[A][15][2,1]*r[C][39][2,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,1])]*r[A][30][2,1]*r[C][54][2,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,0])]*r[A][33][2,1]*r[C][9][2,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,0])]*r[A][48][2,1]*r[C][24][2,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,0])]*r[A][33][2,1]*r[C][39][2,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,0])]*r[A][48][2,1]*r[C][54][2,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,0],p[C,0])]*r[A][15][2,1]*r[C][9][2,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,0],p[C,0])]*r[A][30][2,1]*r[C][24][2,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,1],p[C,0])]*r[A][33][2,1]*r[C][9][2,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,1],p[C,0])]*r[A][48][2,1]*r[C][24][2,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,0],p[C,1])]*r[A][15][2,1]*r[C][39][2,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,0],p[C,1])]*r[A][30][2,1]*r[C][54][2,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,1],p[C,1])]*r[A][33][2,1]*r[C][39][2,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,1],p[C,1])]*r[A][48][2,1]*r[C][54][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,1])]*r[A][15][2,1]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[C][24][2,3]
    hv += g[dei(p[C,0],p[C,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,0])]*r[A][33][2,1]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[C][24][2,3]
    hv += g[dei(p[C,0],p[C,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,1])]*r[A][15][2,1]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[C][54][2,3]
    hv += g[dei(p[C,1],p[C,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,0])]*r[A][33][2,1]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[C][54][2,3]
    hv += g[dei(p[C,1],p[C,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[C][39][2,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A3B2C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,2),(C,2)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,0],p[C,0])]*r[A][15][3,1]*r[C][9][2,3]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,0],p[C,0])]*r[A][30][3,1]*r[C][24][2,3]
    hv += g[dei(p[A,0],p[A,1],p[C,0],p[C,0])]*r[A][15][3,1]*r[C][24][2,3]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,1],p[C,1])]*r[A][15][3,1]*r[C][39][2,3]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,1],p[C,1])]*r[A][30][3,1]*r[C][54][2,3]
    hv += g[dei(p[A,0],p[A,1],p[C,1],p[C,1])]*r[A][15][3,1]*r[C][54][2,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,0],p[C,0])]*r[A][33][3,1]*r[C][9][2,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,0],p[C,0])]*r[A][48][3,1]*r[C][24][2,3]
    hv += g[dei(p[A,1],p[A,0],p[C,0],p[C,0])]*r[A][33][3,1]*r[C][24][2,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,1],p[C,1])]*r[A][33][3,1]*r[C][39][2,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,1],p[C,1])]*r[A][48][3,1]*r[C][54][2,3]
    hv += g[dei(p[A,1],p[A,0],p[C,1],p[C,1])]*r[A][33][3,1]*r[C][54][2,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,1])]*r[A][15][3,1]*r[C][9][2,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,1])]*r[A][30][3,1]*r[C][24][2,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,1])]*r[A][15][3,1]*r[C][39][2,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,1])]*r[A][30][3,1]*r[C][54][2,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,0])]*r[A][33][3,1]*r[C][9][2,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,0])]*r[A][48][3,1]*r[C][24][2,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,0])]*r[A][33][3,1]*r[C][39][2,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,0])]*r[A][48][3,1]*r[C][54][2,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,0],p[C,0])]*r[A][15][3,1]*r[C][9][2,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,0],p[C,0])]*r[A][30][3,1]*r[C][24][2,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,1],p[C,0])]*r[A][33][3,1]*r[C][9][2,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,1],p[C,0])]*r[A][48][3,1]*r[C][24][2,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,0],p[C,1])]*r[A][15][3,1]*r[C][39][2,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,0],p[C,1])]*r[A][30][3,1]*r[C][54][2,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,1],p[C,1])]*r[A][33][3,1]*r[C][39][2,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,1],p[C,1])]*r[A][48][3,1]*r[C][54][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,1])]*r[A][15][3,1]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[C][24][2,3]
    hv += g[dei(p[C,0],p[C,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,0])]*r[A][33][3,1]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[C][24][2,3]
    hv += g[dei(p[C,0],p[C,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,1])]*r[A][15][3,1]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[C][54][2,3]
    hv += g[dei(p[C,1],p[C,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,0])]*r[A][33][3,1]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[C][54][2,3]
    hv += g[dei(p[C,1],p[C,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[C][39][2,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A2B2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(B,2)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,0],p[C,1])]*r[A][15][2,1]*r[C][15][0,3]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,0],p[C,1])]*r[A][30][2,1]*r[C][30][0,3]
    hv += g[dei(p[A,0],p[A,1],p[C,0],p[C,1])]*r[A][15][2,1]*r[C][30][0,3]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,1],p[C,0])]*r[A][15][2,1]*r[C][33][0,3]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,1],p[C,0])]*r[A][30][2,1]*r[C][48][0,3]
    hv += g[dei(p[A,0],p[A,1],p[C,1],p[C,0])]*r[A][15][2,1]*r[C][48][0,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,0],p[C,1])]*r[A][33][2,1]*r[C][15][0,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,0],p[C,1])]*r[A][48][2,1]*r[C][30][0,3]
    hv += g[dei(p[A,1],p[A,0],p[C,0],p[C,1])]*r[A][33][2,1]*r[C][30][0,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,1],p[C,0])]*r[A][33][2,1]*r[C][33][0,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,1],p[C,0])]*r[A][48][2,1]*r[C][48][0,3]
    hv += g[dei(p[A,1],p[A,0],p[C,1],p[C,0])]*r[A][33][2,1]*r[C][48][0,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[A,1])]*r[A][15][2,1]*r[C][15][0,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[A,1])]*r[A][30][2,1]*r[C][30][0,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[A,1])]*r[A][15][2,1]*r[C][33][0,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[A,1])]*r[A][30][2,1]*r[C][48][0,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[A,0])]*r[A][33][2,1]*r[C][15][0,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[A,0])]*r[A][48][2,1]*r[C][30][0,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[A,0])]*r[A][33][2,1]*r[C][33][0,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[A,0])]*r[A][48][2,1]*r[C][48][0,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,0],p[C,1])]*r[A][15][2,1]*r[C][15][0,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,0],p[C,1])]*r[A][30][2,1]*r[C][30][0,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,1],p[C,1])]*r[A][33][2,1]*r[C][15][0,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,1],p[C,1])]*r[A][48][2,1]*r[C][30][0,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,0],p[C,0])]*r[A][15][2,1]*r[C][33][0,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,0],p[C,0])]*r[A][30][2,1]*r[C][48][0,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,1],p[C,0])]*r[A][33][2,1]*r[C][33][0,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,1],p[C,0])]*r[A][48][2,1]*r[C][48][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[A,1])]*r[A][15][2,1]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[C][30][0,3]
    hv += g[dei(p[C,0],p[C,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[A,0])]*r[A][33][2,1]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[C][30][0,3]
    hv += g[dei(p[C,0],p[C,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[A,1])]*r[A][15][2,1]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[C][48][0,3]
    hv += g[dei(p[C,1],p[C,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[A,0])]*r[A][33][2,1]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[C][48][0,3]
    hv += g[dei(p[C,1],p[C,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[C][33][0,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A2B2C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(B,2),(C,1)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,0],p[C,1])]*r[A][15][2,1]*r[C][15][1,3]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,0],p[C,1])]*r[A][30][2,1]*r[C][30][1,3]
    hv += g[dei(p[A,0],p[A,1],p[C,0],p[C,1])]*r[A][15][2,1]*r[C][30][1,3]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,1],p[C,0])]*r[A][15][2,1]*r[C][33][1,3]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,1],p[C,0])]*r[A][30][2,1]*r[C][48][1,3]
    hv += g[dei(p[A,0],p[A,1],p[C,1],p[C,0])]*r[A][15][2,1]*r[C][48][1,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,0],p[C,1])]*r[A][33][2,1]*r[C][15][1,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,0],p[C,1])]*r[A][48][2,1]*r[C][30][1,3]
    hv += g[dei(p[A,1],p[A,0],p[C,0],p[C,1])]*r[A][33][2,1]*r[C][30][1,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,1],p[C,0])]*r[A][33][2,1]*r[C][33][1,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,1],p[C,0])]*r[A][48][2,1]*r[C][48][1,3]
    hv += g[dei(p[A,1],p[A,0],p[C,1],p[C,0])]*r[A][33][2,1]*r[C][48][1,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[A,1])]*r[A][15][2,1]*r[C][15][1,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[A,1])]*r[A][30][2,1]*r[C][30][1,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[A,1])]*r[A][15][2,1]*r[C][33][1,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[A,1])]*r[A][30][2,1]*r[C][48][1,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[A,0])]*r[A][33][2,1]*r[C][15][1,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[A,0])]*r[A][48][2,1]*r[C][30][1,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[A,0])]*r[A][33][2,1]*r[C][33][1,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[A,0])]*r[A][48][2,1]*r[C][48][1,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,0],p[C,1])]*r[A][15][2,1]*r[C][15][1,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,0],p[C,1])]*r[A][30][2,1]*r[C][30][1,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,1],p[C,1])]*r[A][33][2,1]*r[C][15][1,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,1],p[C,1])]*r[A][48][2,1]*r[C][30][1,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,0],p[C,0])]*r[A][15][2,1]*r[C][33][1,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,0],p[C,0])]*r[A][30][2,1]*r[C][48][1,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,1],p[C,0])]*r[A][33][2,1]*r[C][33][1,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,1],p[C,0])]*r[A][48][2,1]*r[C][48][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[A,1])]*r[A][15][2,1]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[C][30][1,3]
    hv += g[dei(p[C,0],p[C,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[A,0])]*r[A][33][2,1]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[C][30][1,3]
    hv += g[dei(p[C,0],p[C,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[A,1])]*r[A][15][2,1]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[C][48][1,3]
    hv += g[dei(p[C,1],p[C,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[A,0])]*r[A][33][2,1]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[C][48][1,3]
    hv += g[dei(p[C,1],p[C,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[C][33][1,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A3B2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,2)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,0],p[C,1])]*r[A][15][3,1]*r[C][15][0,3]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,0],p[C,1])]*r[A][30][3,1]*r[C][30][0,3]
    hv += g[dei(p[A,0],p[A,1],p[C,0],p[C,1])]*r[A][15][3,1]*r[C][30][0,3]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,1],p[C,0])]*r[A][15][3,1]*r[C][33][0,3]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,1],p[C,0])]*r[A][30][3,1]*r[C][48][0,3]
    hv += g[dei(p[A,0],p[A,1],p[C,1],p[C,0])]*r[A][15][3,1]*r[C][48][0,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,0],p[C,1])]*r[A][33][3,1]*r[C][15][0,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,0],p[C,1])]*r[A][48][3,1]*r[C][30][0,3]
    hv += g[dei(p[A,1],p[A,0],p[C,0],p[C,1])]*r[A][33][3,1]*r[C][30][0,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,1],p[C,0])]*r[A][33][3,1]*r[C][33][0,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,1],p[C,0])]*r[A][48][3,1]*r[C][48][0,3]
    hv += g[dei(p[A,1],p[A,0],p[C,1],p[C,0])]*r[A][33][3,1]*r[C][48][0,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[A,1])]*r[A][15][3,1]*r[C][15][0,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[A,1])]*r[A][30][3,1]*r[C][30][0,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[A,1])]*r[A][15][3,1]*r[C][33][0,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[A,1])]*r[A][30][3,1]*r[C][48][0,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[A,0])]*r[A][33][3,1]*r[C][15][0,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[A,0])]*r[A][48][3,1]*r[C][30][0,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[A,0])]*r[A][33][3,1]*r[C][33][0,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[A,0])]*r[A][48][3,1]*r[C][48][0,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,0],p[C,1])]*r[A][15][3,1]*r[C][15][0,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,0],p[C,1])]*r[A][30][3,1]*r[C][30][0,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,1],p[C,1])]*r[A][33][3,1]*r[C][15][0,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,1],p[C,1])]*r[A][48][3,1]*r[C][30][0,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,0],p[C,0])]*r[A][15][3,1]*r[C][33][0,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,0],p[C,0])]*r[A][30][3,1]*r[C][48][0,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,1],p[C,0])]*r[A][33][3,1]*r[C][33][0,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,1],p[C,0])]*r[A][48][3,1]*r[C][48][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[A,1])]*r[A][15][3,1]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[C][30][0,3]
    hv += g[dei(p[C,0],p[C,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[A,0])]*r[A][33][3,1]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[C][30][0,3]
    hv += g[dei(p[C,0],p[C,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[A,1])]*r[A][15][3,1]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[C][48][0,3]
    hv += g[dei(p[C,1],p[C,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[A,0])]*r[A][33][3,1]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[C][48][0,3]
    hv += g[dei(p[C,1],p[C,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[C][33][0,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A3B2C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,2),(C,1)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,0],p[C,1])]*r[A][15][3,1]*r[C][15][1,3]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,0],p[C,1])]*r[A][30][3,1]*r[C][30][1,3]
    hv += g[dei(p[A,0],p[A,1],p[C,0],p[C,1])]*r[A][15][3,1]*r[C][30][1,3]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,1],p[C,0])]*r[A][15][3,1]*r[C][33][1,3]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,1],p[C,0])]*r[A][30][3,1]*r[C][48][1,3]
    hv += g[dei(p[A,0],p[A,1],p[C,1],p[C,0])]*r[A][15][3,1]*r[C][48][1,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,0],p[C,1])]*r[A][33][3,1]*r[C][15][1,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,0],p[C,1])]*r[A][48][3,1]*r[C][30][1,3]
    hv += g[dei(p[A,1],p[A,0],p[C,0],p[C,1])]*r[A][33][3,1]*r[C][30][1,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,1],p[C,0])]*r[A][33][3,1]*r[C][33][1,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,1],p[C,0])]*r[A][48][3,1]*r[C][48][1,3]
    hv += g[dei(p[A,1],p[A,0],p[C,1],p[C,0])]*r[A][33][3,1]*r[C][48][1,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[A,1])]*r[A][15][3,1]*r[C][15][1,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[A,1])]*r[A][30][3,1]*r[C][30][1,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[A,1])]*r[A][15][3,1]*r[C][33][1,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[A,1])]*r[A][30][3,1]*r[C][48][1,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[A,0])]*r[A][33][3,1]*r[C][15][1,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[A,0])]*r[A][48][3,1]*r[C][30][1,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[A,0])]*r[A][33][3,1]*r[C][33][1,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[A,0])]*r[A][48][3,1]*r[C][48][1,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,0],p[C,1])]*r[A][15][3,1]*r[C][15][1,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,0],p[C,1])]*r[A][30][3,1]*r[C][30][1,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,1],p[C,1])]*r[A][33][3,1]*r[C][15][1,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,1],p[C,1])]*r[A][48][3,1]*r[C][30][1,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,0],p[C,0])]*r[A][15][3,1]*r[C][33][1,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,0],p[C,0])]*r[A][30][3,1]*r[C][48][1,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,1],p[C,0])]*r[A][33][3,1]*r[C][33][1,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,1],p[C,0])]*r[A][48][3,1]*r[C][48][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[A,1])]*r[A][15][3,1]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[C][30][1,3]
    hv += g[dei(p[C,0],p[C,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[A,0])]*r[A][33][3,1]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[C][30][1,3]
    hv += g[dei(p[C,0],p[C,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[A,1])]*r[A][15][3,1]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[C][48][1,3]
    hv += g[dei(p[C,1],p[C,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[A,0])]*r[A][33][3,1]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[C][48][1,3]
    hv += g[dei(p[C,1],p[C,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[C][33][1,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A4B2C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,4),(B,2),(C,5)]))
    hv = 0.0
    
    hv += -1*g[dei(p[A,0],p[C,0],p[C,0],p[A,1])]*r[A][18][4,1]*r[C][21][5,3]
    hv += -1*g[dei(p[A,0],p[C,1],p[C,1],p[A,1])]*r[A][18][4,1]*r[C][51][5,3]
    hv += -1*g[dei(p[A,1],p[C,0],p[C,0],p[A,0])]*r[A][36][4,1]*r[C][21][5,3]
    hv += -1*g[dei(p[A,1],p[C,1],p[C,1],p[A,0])]*r[A][36][4,1]*r[C][51][5,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A5B2C4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,5),(B,2),(C,4)]))
    hv = 0.0
    
    hv += -1*g[dei(p[C,0],p[A,1],p[A,0],p[C,0])]*r[A][27][5,1]*r[C][12][4,3]
    hv += -1*g[dei(p[C,0],p[A,0],p[A,1],p[C,0])]*r[A][45][5,1]*r[C][12][4,3]
    hv += -1*g[dei(p[C,1],p[A,1],p[A,0],p[C,1])]*r[A][27][5,1]*r[C][42][4,3]
    hv += -1*g[dei(p[C,1],p[A,0],p[A,1],p[C,1])]*r[A][45][5,1]*r[C][42][4,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A6B2C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,6),(B,2),(C,15)]))
    hv = 0.0
    
    hv += g[dei(p[C,0],p[A,0],p[C,1],p[A,0])]*r[A][22][6,1]*r[C][17][15,3]
    hv += g[dei(p[C,0],p[A,1],p[C,1],p[A,1])]*r[A][52][6,1]*r[C][17][15,3]
    hv += g[dei(p[C,1],p[A,0],p[C,0],p[A,0])]*r[A][22][6,1]*r[C][35][15,3]
    hv += g[dei(p[C,1],p[A,1],p[C,0],p[A,1])]*r[A][52][6,1]*r[C][35][15,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A1B11C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,11),(C,10)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += h[p[B,0],p[C,0]]*r[B][0][11,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,0],p[B,1],p[B,1],p[C,0])]*r[B][76][11,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,1],p[B,1],p[B,0],p[C,0])]*r[B][124][11,2]*r[C][1][10,3]
    hv += g[dei(p[B,0],p[C,0],p[B,0],p[B,0])]*r[B][66][11,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[B,1],p[B,1])]*r[B][76][11,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[B,0],p[B,1])]*r[B][124][11,2]*r[C][1][10,3]
    hv += g[dei(p[B,1],p[C,0],p[B,0],p[B,1])]*r[B][134][11,2]*r[C][1][10,3]
    hv += g[dei(p[B,0],p[C,0],p[C,1],p[C,1])]*r[B][0][11,2]*r[C][177][10,3]
    hv += g[dei(p[B,0],p[C,1],p[C,1],p[C,0])]*r[B][0][11,2]*r[C][165][10,3]
    hv += sum(1/2*g[dei(p[B,0],p[C,0],p[I,0],p[I,0])]*r[B][0][11,2]*r[C][1][10,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,0],p[C,0],p[I,0],p[I,0])]*r[B][0][11,2]*r[C][1][10,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[C,0],p[I,1],p[I,1])]*r[B][0][11,2]*r[C][1][10,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,0],p[C,0],p[I,1],p[I,1])]*r[B][0][11,2]*r[C][1][10,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,0],p[I,0],p[C,0])]*r[B][0][11,2]*r[C][1][10,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,1],p[I,1],p[C,0])]*r[B][0][11,2]*r[C][1][10,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,0],p[B,0],p[I,0])]*r[B][0][11,2]*r[C][1][10,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,0],p[B,0],p[I,1])]*r[B][0][11,2]*r[C][1][10,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,0],p[C,0])]*r[B][0][11,2]*r[C][1][10,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,0],p[C,0])]*r[B][0][11,2]*r[C][1][10,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][9][1,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][39][1,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,0])]*r[A][9][1,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,1])]*r[A][39][1,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,0])]*r[A][9][1,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,0])]*r[A][39][1,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][0][11,2]*r[C][1][10,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A1B13C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,13),(C,8)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += h[p[B,0],p[C,0]]*r[B][2][13,2]*r[C][3][8,3]
    hv += -1*g[dei(p[B,0],p[B,0],p[B,0],p[C,0])]*r[B][64][13,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,0],p[B,1],p[B,1],p[C,0])]*r[B][118][13,2]*r[C][3][8,3]
    hv += -1*g[dei(p[B,0],p[B,1],p[B,1],p[C,0])]*r[B][84][13,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,1],p[B,1],p[B,0],p[C,0])]*r[B][166][13,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[B,1],p[B,1])]*r[B][118][13,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[B,0],p[B,1])]*r[B][166][13,2]*r[C][3][8,3]
    hv += -1*g[dei(p[C,1],p[C,0],p[B,0],p[C,1])]*r[B][2][13,2]*r[C][145][8,3]
    hv += -1*g[dei(p[C,1],p[C,1],p[B,0],p[C,0])]*r[B][2][13,2]*r[C][133][8,3]
    hv += sum(1/2*g[dei(p[B,0],p[C,0],p[I,0],p[I,0])]*r[B][2][13,2]*r[C][3][8,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[C,0],p[I,1],p[I,1])]*r[B][2][13,2]*r[C][3][8,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,0],p[I,0],p[C,0])]*r[B][2][13,2]*r[C][3][8,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,1],p[I,1],p[C,0])]*r[B][2][13,2]*r[C][3][8,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,0],p[B,0],p[I,0])]*r[B][2][13,2]*r[C][3][8,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,0],p[B,0],p[I,1])]*r[B][2][13,2]*r[C][3][8,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,0],p[C,0])]*r[B][2][13,2]*r[C][3][8,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[B,0],p[C,0])]*r[B][2][13,2]*r[C][3][8,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,0],p[C,0])]*r[B][2][13,2]*r[C][3][8,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[B,0],p[C,0])]*r[B][2][13,2]*r[C][3][8,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][24][1,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][9][1,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][54][1,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][39][1,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,0])]*r[A][24][1,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,1])]*r[A][54][1,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,0])]*r[A][24][1,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,0])]*r[A][54][1,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][2][13,2]*r[C][3][8,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A1B11C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,11),(C,9)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += h[p[B,0],p[C,1]]*r[B][0][11,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,0],p[B,1],p[B,1],p[C,1])]*r[B][76][11,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,1],p[B,1],p[B,0],p[C,1])]*r[B][124][11,2]*r[C][5][9,3]
    hv += g[dei(p[B,0],p[C,1],p[B,0],p[B,0])]*r[B][66][11,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[B,1],p[B,1])]*r[B][76][11,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[B,0],p[B,1])]*r[B][124][11,2]*r[C][5][9,3]
    hv += g[dei(p[B,1],p[C,1],p[B,0],p[B,1])]*r[B][134][11,2]*r[C][5][9,3]
    hv += g[dei(p[B,0],p[C,0],p[C,0],p[C,1])]*r[B][0][11,2]*r[C][113][9,3]
    hv += g[dei(p[B,0],p[C,1],p[C,0],p[C,0])]*r[B][0][11,2]*r[C][101][9,3]
    hv += sum(1/2*g[dei(p[B,0],p[C,1],p[I,0],p[I,0])]*r[B][0][11,2]*r[C][5][9,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,0],p[C,1],p[I,0],p[I,0])]*r[B][0][11,2]*r[C][5][9,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[C,1],p[I,1],p[I,1])]*r[B][0][11,2]*r[C][5][9,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,0],p[C,1],p[I,1],p[I,1])]*r[B][0][11,2]*r[C][5][9,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,0],p[I,0],p[C,1])]*r[B][0][11,2]*r[C][5][9,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,1],p[I,1],p[C,1])]*r[B][0][11,2]*r[C][5][9,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,1],p[B,0],p[I,0])]*r[B][0][11,2]*r[C][5][9,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,1],p[B,0],p[I,1])]*r[B][0][11,2]*r[C][5][9,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,0],p[C,1])]*r[B][0][11,2]*r[C][5][9,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,0],p[C,1])]*r[B][0][11,2]*r[C][5][9,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][9][1,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][39][1,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,0])]*r[A][9][1,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,1])]*r[A][39][1,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,1])]*r[A][9][1,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,1])]*r[A][39][1,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][0][11,2]*r[C][5][9,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A1B13C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,13),(C,7)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += h[p[B,0],p[C,1]]*r[B][2][13,2]*r[C][7][7,3]
    hv += -1*g[dei(p[B,0],p[B,0],p[B,0],p[C,1])]*r[B][64][13,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,0],p[B,1],p[B,1],p[C,1])]*r[B][118][13,2]*r[C][7][7,3]
    hv += -1*g[dei(p[B,0],p[B,1],p[B,1],p[C,1])]*r[B][84][13,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,1],p[B,1],p[B,0],p[C,1])]*r[B][166][13,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[B,1],p[B,1])]*r[B][118][13,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[B,0],p[B,1])]*r[B][166][13,2]*r[C][7][7,3]
    hv += -1*g[dei(p[C,0],p[C,0],p[B,0],p[C,1])]*r[B][2][13,2]*r[C][81][7,3]
    hv += -1*g[dei(p[C,0],p[C,1],p[B,0],p[C,0])]*r[B][2][13,2]*r[C][69][7,3]
    hv += sum(1/2*g[dei(p[B,0],p[C,1],p[I,0],p[I,0])]*r[B][2][13,2]*r[C][7][7,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[C,1],p[I,1],p[I,1])]*r[B][2][13,2]*r[C][7][7,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,0],p[I,0],p[C,1])]*r[B][2][13,2]*r[C][7][7,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,1],p[I,1],p[C,1])]*r[B][2][13,2]*r[C][7][7,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,1],p[B,0],p[I,0])]*r[B][2][13,2]*r[C][7][7,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,1],p[B,0],p[I,1])]*r[B][2][13,2]*r[C][7][7,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,0],p[C,1])]*r[B][2][13,2]*r[C][7][7,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[B,0],p[C,1])]*r[B][2][13,2]*r[C][7][7,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,0],p[C,1])]*r[B][2][13,2]*r[C][7][7,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[B,0],p[C,1])]*r[B][2][13,2]*r[C][7][7,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][24][1,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][9][1,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][54][1,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][39][1,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,0])]*r[A][24][1,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,1])]*r[A][54][1,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,1])]*r[A][24][1,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,1])]*r[A][54][1,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][2][13,2]*r[C][7][7,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A1B12C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,12),(C,10)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += h[p[B,1],p[C,0]]*r[B][4][12,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,0],p[B,0],p[B,1],p[C,0])]*r[B][72][12,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,1],p[B,0],p[B,0],p[C,0])]*r[B][120][12,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[B,1],p[B,0])]*r[B][72][12,2]*r[C][1][10,3]
    hv += g[dei(p[B,0],p[C,0],p[B,1],p[B,0])]*r[B][82][12,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[B,0],p[B,0])]*r[B][120][12,2]*r[C][1][10,3]
    hv += g[dei(p[B,1],p[C,0],p[B,1],p[B,1])]*r[B][150][12,2]*r[C][1][10,3]
    hv += g[dei(p[B,1],p[C,0],p[C,1],p[C,1])]*r[B][4][12,2]*r[C][177][10,3]
    hv += g[dei(p[B,1],p[C,1],p[C,1],p[C,0])]*r[B][4][12,2]*r[C][165][10,3]
    hv += sum(1/2*g[dei(p[B,1],p[C,0],p[I,0],p[I,0])]*r[B][4][12,2]*r[C][1][10,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,1],p[C,0],p[I,0],p[I,0])]*r[B][4][12,2]*r[C][1][10,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[C,0],p[I,1],p[I,1])]*r[B][4][12,2]*r[C][1][10,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,1],p[C,0],p[I,1],p[I,1])]*r[B][4][12,2]*r[C][1][10,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,0],p[I,0],p[C,0])]*r[B][4][12,2]*r[C][1][10,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,1],p[I,1],p[C,0])]*r[B][4][12,2]*r[C][1][10,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,0],p[B,1],p[I,0])]*r[B][4][12,2]*r[C][1][10,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,0],p[B,1],p[I,1])]*r[B][4][12,2]*r[C][1][10,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,1],p[C,0])]*r[B][4][12,2]*r[C][1][10,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,1],p[C,0])]*r[B][4][12,2]*r[C][1][10,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][9][1,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][39][1,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,0])]*r[A][9][1,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,1])]*r[A][39][1,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,0])]*r[A][9][1,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,0])]*r[A][39][1,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][4][12,2]*r[C][1][10,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A1B14C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,14),(C,8)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += h[p[B,1],p[C,0]]*r[B][6][14,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,0],p[B,0],p[B,1],p[C,0])]*r[B][114][14,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,1],p[B,0],p[B,0],p[C,0])]*r[B][162][14,2]*r[C][3][8,3]
    hv += -1*g[dei(p[B,1],p[B,0],p[B,0],p[C,0])]*r[B][128][14,2]*r[C][3][8,3]
    hv += -1*g[dei(p[B,1],p[B,1],p[B,1],p[C,0])]*r[B][148][14,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[B,1],p[B,0])]*r[B][114][14,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[B,0],p[B,0])]*r[B][162][14,2]*r[C][3][8,3]
    hv += -1*g[dei(p[C,1],p[C,0],p[B,1],p[C,1])]*r[B][6][14,2]*r[C][145][8,3]
    hv += -1*g[dei(p[C,1],p[C,1],p[B,1],p[C,0])]*r[B][6][14,2]*r[C][133][8,3]
    hv += sum(1/2*g[dei(p[B,1],p[C,0],p[I,0],p[I,0])]*r[B][6][14,2]*r[C][3][8,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[C,0],p[I,1],p[I,1])]*r[B][6][14,2]*r[C][3][8,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,0],p[I,0],p[C,0])]*r[B][6][14,2]*r[C][3][8,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,1],p[I,1],p[C,0])]*r[B][6][14,2]*r[C][3][8,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,0],p[B,1],p[I,0])]*r[B][6][14,2]*r[C][3][8,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,0],p[B,1],p[I,1])]*r[B][6][14,2]*r[C][3][8,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,1],p[C,0])]*r[B][6][14,2]*r[C][3][8,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[B,1],p[C,0])]*r[B][6][14,2]*r[C][3][8,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,1],p[C,0])]*r[B][6][14,2]*r[C][3][8,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[B,1],p[C,0])]*r[B][6][14,2]*r[C][3][8,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][24][1,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][9][1,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][54][1,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][39][1,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,0])]*r[A][24][1,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,1])]*r[A][54][1,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,0])]*r[A][24][1,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,0])]*r[A][54][1,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][6][14,2]*r[C][3][8,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A1B12C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,12),(C,9)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += h[p[B,1],p[C,1]]*r[B][4][12,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,0],p[B,0],p[B,1],p[C,1])]*r[B][72][12,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,1],p[B,0],p[B,0],p[C,1])]*r[B][120][12,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[B,1],p[B,0])]*r[B][72][12,2]*r[C][5][9,3]
    hv += g[dei(p[B,0],p[C,1],p[B,1],p[B,0])]*r[B][82][12,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[B,0],p[B,0])]*r[B][120][12,2]*r[C][5][9,3]
    hv += g[dei(p[B,1],p[C,1],p[B,1],p[B,1])]*r[B][150][12,2]*r[C][5][9,3]
    hv += g[dei(p[B,1],p[C,0],p[C,0],p[C,1])]*r[B][4][12,2]*r[C][113][9,3]
    hv += g[dei(p[B,1],p[C,1],p[C,0],p[C,0])]*r[B][4][12,2]*r[C][101][9,3]
    hv += sum(1/2*g[dei(p[B,1],p[C,1],p[I,0],p[I,0])]*r[B][4][12,2]*r[C][5][9,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,1],p[C,1],p[I,0],p[I,0])]*r[B][4][12,2]*r[C][5][9,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[C,1],p[I,1],p[I,1])]*r[B][4][12,2]*r[C][5][9,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,1],p[C,1],p[I,1],p[I,1])]*r[B][4][12,2]*r[C][5][9,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,0],p[I,0],p[C,1])]*r[B][4][12,2]*r[C][5][9,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,1],p[I,1],p[C,1])]*r[B][4][12,2]*r[C][5][9,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,1],p[B,1],p[I,0])]*r[B][4][12,2]*r[C][5][9,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,1],p[B,1],p[I,1])]*r[B][4][12,2]*r[C][5][9,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,1],p[C,1])]*r[B][4][12,2]*r[C][5][9,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,1],p[C,1])]*r[B][4][12,2]*r[C][5][9,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][9][1,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][39][1,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,0])]*r[A][9][1,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,1])]*r[A][39][1,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,1])]*r[A][9][1,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,1])]*r[A][39][1,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][4][12,2]*r[C][5][9,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A1B14C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,14),(C,7)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += h[p[B,1],p[C,1]]*r[B][6][14,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,0],p[B,0],p[B,1],p[C,1])]*r[B][114][14,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,1],p[B,0],p[B,0],p[C,1])]*r[B][162][14,2]*r[C][7][7,3]
    hv += -1*g[dei(p[B,1],p[B,0],p[B,0],p[C,1])]*r[B][128][14,2]*r[C][7][7,3]
    hv += -1*g[dei(p[B,1],p[B,1],p[B,1],p[C,1])]*r[B][148][14,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[B,1],p[B,0])]*r[B][114][14,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[B,0],p[B,0])]*r[B][162][14,2]*r[C][7][7,3]
    hv += -1*g[dei(p[C,0],p[C,0],p[B,1],p[C,1])]*r[B][6][14,2]*r[C][81][7,3]
    hv += -1*g[dei(p[C,0],p[C,1],p[B,1],p[C,0])]*r[B][6][14,2]*r[C][69][7,3]
    hv += sum(1/2*g[dei(p[B,1],p[C,1],p[I,0],p[I,0])]*r[B][6][14,2]*r[C][7][7,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[C,1],p[I,1],p[I,1])]*r[B][6][14,2]*r[C][7][7,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,0],p[I,0],p[C,1])]*r[B][6][14,2]*r[C][7][7,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,1],p[I,1],p[C,1])]*r[B][6][14,2]*r[C][7][7,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,1],p[B,1],p[I,0])]*r[B][6][14,2]*r[C][7][7,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,1],p[B,1],p[I,1])]*r[B][6][14,2]*r[C][7][7,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,1],p[C,1])]*r[B][6][14,2]*r[C][7][7,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[B,1],p[C,1])]*r[B][6][14,2]*r[C][7][7,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,1],p[C,1])]*r[B][6][14,2]*r[C][7][7,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[B,1],p[C,1])]*r[B][6][14,2]*r[C][7][7,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][24][1,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][9][1,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][54][1,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][39][1,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,0])]*r[A][24][1,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,1])]*r[A][54][1,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,1])]*r[A][24][1,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,1])]*r[A][54][1,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][6][14,2]*r[C][7][7,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A1B10C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,10),(C,11)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*h[p[C,0],p[B,0]]*r[B][1][10,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[B,0],p[B,1],p[B,1])]*r[B][177][10,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[B,1],p[B,1],p[B,0])]*r[B][165][10,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[B,0],p[C,0],p[C,0])]*r[B][1][10,2]*r[C][66][11,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[C,1],p[C,1])]*r[B][1][10,2]*r[C][76][11,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[C,0],p[C,1])]*r[B][1][10,2]*r[C][124][11,3]
    hv += -1*g[dei(p[C,1],p[B,0],p[C,0],p[C,1])]*r[B][1][10,2]*r[C][134][11,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[C,1],p[B,0])]*r[B][1][10,2]*r[C][76][11,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[C,0],p[B,0])]*r[B][1][10,2]*r[C][124][11,3]
    hv += sum(-1/2*g[dei(p[C,0],p[B,0],p[I,0],p[I,0])]*r[B][1][10,2]*r[C][0][11,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,0],p[B,0],p[I,0],p[I,0])]*r[B][1][10,2]*r[C][0][11,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[B,0],p[I,1],p[I,1])]*r[B][1][10,2]*r[C][0][11,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,0],p[B,0],p[I,1],p[I,1])]*r[B][1][10,2]*r[C][0][11,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[I,0],p[I,0],p[B,0])]*r[B][1][10,2]*r[C][0][11,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[I,1],p[I,1],p[B,0])]*r[B][1][10,2]*r[C][0][11,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[B,0],p[C,0],p[I,0])]*r[B][1][10,2]*r[C][0][11,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[B,0],p[C,0],p[I,1])]*r[B][1][10,2]*r[C][0][11,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[C,0],p[B,0])]*r[B][1][10,2]*r[C][0][11,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[C,0],p[B,0])]*r[B][1][10,2]*r[C][0][11,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[C,0],p[B,0])]*r[A][9][1,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[C,0],p[B,0])]*r[A][39][1,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,0],p[A,0])]*r[A][9][1,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,0],p[A,1])]*r[A][39][1,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[A,0],p[B,0])]*r[A][9][1,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[A,1],p[B,0])]*r[A][39][1,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[B,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[B,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][1][10,2]*r[C][0][11,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A1B8C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,8),(C,13)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*h[p[C,0],p[B,0]]*r[B][3][8,2]*r[C][2][13,3]
    hv += g[dei(p[B,1],p[B,0],p[C,0],p[B,1])]*r[B][145][8,2]*r[C][2][13,3]
    hv += g[dei(p[B,1],p[B,1],p[C,0],p[B,0])]*r[B][133][8,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[C,1],p[C,1])]*r[B][3][8,2]*r[C][118][13,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[C,0],p[C,1])]*r[B][3][8,2]*r[C][166][13,3]
    hv += g[dei(p[C,0],p[C,0],p[C,0],p[B,0])]*r[B][3][8,2]*r[C][64][13,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[C,1],p[B,0])]*r[B][3][8,2]*r[C][118][13,3]
    hv += g[dei(p[C,0],p[C,1],p[C,1],p[B,0])]*r[B][3][8,2]*r[C][84][13,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[C,0],p[B,0])]*r[B][3][8,2]*r[C][166][13,3]
    hv += sum(-1/2*g[dei(p[C,0],p[B,0],p[I,0],p[I,0])]*r[B][3][8,2]*r[C][2][13,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[B,0],p[I,1],p[I,1])]*r[B][3][8,2]*r[C][2][13,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[I,0],p[I,0],p[B,0])]*r[B][3][8,2]*r[C][2][13,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[I,1],p[I,1],p[B,0])]*r[B][3][8,2]*r[C][2][13,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[B,0],p[C,0],p[I,0])]*r[B][3][8,2]*r[C][2][13,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[B,0],p[C,0],p[I,1])]*r[B][3][8,2]*r[C][2][13,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[C,0],p[B,0])]*r[B][3][8,2]*r[C][2][13,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[C,0],p[B,0])]*r[B][3][8,2]*r[C][2][13,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[C,0],p[B,0])]*r[B][3][8,2]*r[C][2][13,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[C,0],p[B,0])]*r[B][3][8,2]*r[C][2][13,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[C,0],p[B,0])]*r[A][24][1,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += -1*g[dei(p[A,0],p[A,0],p[C,0],p[B,0])]*r[A][9][1,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[C,0],p[B,0])]*r[A][54][1,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += -1*g[dei(p[A,1],p[A,1],p[C,0],p[B,0])]*r[A][39][1,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,0],p[A,0])]*r[A][24][1,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,0],p[A,1])]*r[A][54][1,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[A,0],p[B,0])]*r[A][24][1,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[A,1],p[B,0])]*r[A][54][1,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][3][8,2]*r[C][2][13,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A1B9C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,9),(C,11)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*h[p[C,0],p[B,1]]*r[B][5][9,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[B,0],p[B,0],p[B,1])]*r[B][113][9,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[B,1],p[B,0],p[B,0])]*r[B][101][9,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[B,1],p[C,0],p[C,0])]*r[B][5][9,2]*r[C][66][11,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[C,1],p[C,1])]*r[B][5][9,2]*r[C][76][11,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[C,0],p[C,1])]*r[B][5][9,2]*r[C][124][11,3]
    hv += -1*g[dei(p[C,1],p[B,1],p[C,0],p[C,1])]*r[B][5][9,2]*r[C][134][11,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[C,1],p[B,1])]*r[B][5][9,2]*r[C][76][11,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[C,0],p[B,1])]*r[B][5][9,2]*r[C][124][11,3]
    hv += sum(-1/2*g[dei(p[C,0],p[B,1],p[I,0],p[I,0])]*r[B][5][9,2]*r[C][0][11,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,0],p[B,1],p[I,0],p[I,0])]*r[B][5][9,2]*r[C][0][11,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[B,1],p[I,1],p[I,1])]*r[B][5][9,2]*r[C][0][11,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,0],p[B,1],p[I,1],p[I,1])]*r[B][5][9,2]*r[C][0][11,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[I,0],p[I,0],p[B,1])]*r[B][5][9,2]*r[C][0][11,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[I,1],p[I,1],p[B,1])]*r[B][5][9,2]*r[C][0][11,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[B,1],p[C,0],p[I,0])]*r[B][5][9,2]*r[C][0][11,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[B,1],p[C,0],p[I,1])]*r[B][5][9,2]*r[C][0][11,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[C,0],p[B,1])]*r[B][5][9,2]*r[C][0][11,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[C,0],p[B,1])]*r[B][5][9,2]*r[C][0][11,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[C,0],p[B,1])]*r[A][9][1,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[C,0],p[B,1])]*r[A][39][1,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,0],p[A,0])]*r[A][9][1,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,0],p[A,1])]*r[A][39][1,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[A,0],p[B,1])]*r[A][9][1,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[A,1],p[B,1])]*r[A][39][1,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[B,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[B,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][5][9,2]*r[C][0][11,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A1B7C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,7),(C,13)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*h[p[C,0],p[B,1]]*r[B][7][7,2]*r[C][2][13,3]
    hv += g[dei(p[B,0],p[B,0],p[C,0],p[B,1])]*r[B][81][7,2]*r[C][2][13,3]
    hv += g[dei(p[B,0],p[B,1],p[C,0],p[B,0])]*r[B][69][7,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[C,1],p[C,1])]*r[B][7][7,2]*r[C][118][13,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[C,0],p[C,1])]*r[B][7][7,2]*r[C][166][13,3]
    hv += g[dei(p[C,0],p[C,0],p[C,0],p[B,1])]*r[B][7][7,2]*r[C][64][13,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[C,1],p[B,1])]*r[B][7][7,2]*r[C][118][13,3]
    hv += g[dei(p[C,0],p[C,1],p[C,1],p[B,1])]*r[B][7][7,2]*r[C][84][13,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[C,0],p[B,1])]*r[B][7][7,2]*r[C][166][13,3]
    hv += sum(-1/2*g[dei(p[C,0],p[B,1],p[I,0],p[I,0])]*r[B][7][7,2]*r[C][2][13,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[B,1],p[I,1],p[I,1])]*r[B][7][7,2]*r[C][2][13,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[I,0],p[I,0],p[B,1])]*r[B][7][7,2]*r[C][2][13,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[I,1],p[I,1],p[B,1])]*r[B][7][7,2]*r[C][2][13,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[B,1],p[C,0],p[I,0])]*r[B][7][7,2]*r[C][2][13,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[B,1],p[C,0],p[I,1])]*r[B][7][7,2]*r[C][2][13,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[C,0],p[B,1])]*r[B][7][7,2]*r[C][2][13,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[C,0],p[B,1])]*r[B][7][7,2]*r[C][2][13,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[C,0],p[B,1])]*r[B][7][7,2]*r[C][2][13,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[C,0],p[B,1])]*r[B][7][7,2]*r[C][2][13,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[C,0],p[B,1])]*r[A][24][1,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += -1*g[dei(p[A,0],p[A,0],p[C,0],p[B,1])]*r[A][9][1,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[C,0],p[B,1])]*r[A][54][1,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += -1*g[dei(p[A,1],p[A,1],p[C,0],p[B,1])]*r[A][39][1,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,0],p[A,0])]*r[A][24][1,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,0],p[A,1])]*r[A][54][1,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[A,0],p[B,1])]*r[A][24][1,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[A,1],p[B,1])]*r[A][54][1,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][7][7,2]*r[C][2][13,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A1B10C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,10),(C,12)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*h[p[C,1],p[B,0]]*r[B][1][10,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[B,0],p[B,1],p[B,1])]*r[B][177][10,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[B,1],p[B,1],p[B,0])]*r[B][165][10,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[C,1],p[C,0])]*r[B][1][10,2]*r[C][72][12,3]
    hv += -1*g[dei(p[C,0],p[B,0],p[C,1],p[C,0])]*r[B][1][10,2]*r[C][82][12,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[C,0],p[C,0])]*r[B][1][10,2]*r[C][120][12,3]
    hv += -1*g[dei(p[C,1],p[B,0],p[C,1],p[C,1])]*r[B][1][10,2]*r[C][150][12,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[C,1],p[B,0])]*r[B][1][10,2]*r[C][72][12,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[C,0],p[B,0])]*r[B][1][10,2]*r[C][120][12,3]
    hv += sum(-1/2*g[dei(p[C,1],p[B,0],p[I,0],p[I,0])]*r[B][1][10,2]*r[C][4][12,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,1],p[B,0],p[I,0],p[I,0])]*r[B][1][10,2]*r[C][4][12,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[B,0],p[I,1],p[I,1])]*r[B][1][10,2]*r[C][4][12,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,1],p[B,0],p[I,1],p[I,1])]*r[B][1][10,2]*r[C][4][12,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[I,0],p[I,0],p[B,0])]*r[B][1][10,2]*r[C][4][12,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[I,1],p[I,1],p[B,0])]*r[B][1][10,2]*r[C][4][12,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[B,0],p[C,1],p[I,0])]*r[B][1][10,2]*r[C][4][12,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[B,0],p[C,1],p[I,1])]*r[B][1][10,2]*r[C][4][12,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[C,1],p[B,0])]*r[B][1][10,2]*r[C][4][12,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[C,1],p[B,0])]*r[B][1][10,2]*r[C][4][12,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[C,1],p[B,0])]*r[A][9][1,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[C,1],p[B,0])]*r[A][39][1,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,1],p[A,0])]*r[A][9][1,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,1],p[A,1])]*r[A][39][1,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[A,0],p[B,0])]*r[A][9][1,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[A,1],p[B,0])]*r[A][39][1,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[B,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[B,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][1][10,2]*r[C][4][12,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A1B8C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,8),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*h[p[C,1],p[B,0]]*r[B][3][8,2]*r[C][6][14,3]
    hv += g[dei(p[B,1],p[B,0],p[C,1],p[B,1])]*r[B][145][8,2]*r[C][6][14,3]
    hv += g[dei(p[B,1],p[B,1],p[C,1],p[B,0])]*r[B][133][8,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[C,1],p[C,0])]*r[B][3][8,2]*r[C][114][14,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[C,0],p[C,0])]*r[B][3][8,2]*r[C][162][14,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[C,1],p[B,0])]*r[B][3][8,2]*r[C][114][14,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[C,0],p[B,0])]*r[B][3][8,2]*r[C][162][14,3]
    hv += g[dei(p[C,1],p[C,0],p[C,0],p[B,0])]*r[B][3][8,2]*r[C][128][14,3]
    hv += g[dei(p[C,1],p[C,1],p[C,1],p[B,0])]*r[B][3][8,2]*r[C][148][14,3]
    hv += sum(-1/2*g[dei(p[C,1],p[B,0],p[I,0],p[I,0])]*r[B][3][8,2]*r[C][6][14,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[B,0],p[I,1],p[I,1])]*r[B][3][8,2]*r[C][6][14,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[I,0],p[I,0],p[B,0])]*r[B][3][8,2]*r[C][6][14,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[I,1],p[I,1],p[B,0])]*r[B][3][8,2]*r[C][6][14,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[B,0],p[C,1],p[I,0])]*r[B][3][8,2]*r[C][6][14,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[B,0],p[C,1],p[I,1])]*r[B][3][8,2]*r[C][6][14,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[C,1],p[B,0])]*r[B][3][8,2]*r[C][6][14,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[C,1],p[B,0])]*r[B][3][8,2]*r[C][6][14,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[C,1],p[B,0])]*r[B][3][8,2]*r[C][6][14,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[C,1],p[B,0])]*r[B][3][8,2]*r[C][6][14,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[C,1],p[B,0])]*r[A][24][1,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += -1*g[dei(p[A,0],p[A,0],p[C,1],p[B,0])]*r[A][9][1,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[C,1],p[B,0])]*r[A][54][1,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += -1*g[dei(p[A,1],p[A,1],p[C,1],p[B,0])]*r[A][39][1,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,1],p[A,0])]*r[A][24][1,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,1],p[A,1])]*r[A][54][1,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[A,0],p[B,0])]*r[A][24][1,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[A,1],p[B,0])]*r[A][54][1,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][3][8,2]*r[C][6][14,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A1B9C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,9),(C,12)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*h[p[C,1],p[B,1]]*r[B][5][9,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[B,0],p[B,0],p[B,1])]*r[B][113][9,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[B,1],p[B,0],p[B,0])]*r[B][101][9,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[C,1],p[C,0])]*r[B][5][9,2]*r[C][72][12,3]
    hv += -1*g[dei(p[C,0],p[B,1],p[C,1],p[C,0])]*r[B][5][9,2]*r[C][82][12,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[C,0],p[C,0])]*r[B][5][9,2]*r[C][120][12,3]
    hv += -1*g[dei(p[C,1],p[B,1],p[C,1],p[C,1])]*r[B][5][9,2]*r[C][150][12,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[C,1],p[B,1])]*r[B][5][9,2]*r[C][72][12,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[C,0],p[B,1])]*r[B][5][9,2]*r[C][120][12,3]
    hv += sum(-1/2*g[dei(p[C,1],p[B,1],p[I,0],p[I,0])]*r[B][5][9,2]*r[C][4][12,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,1],p[B,1],p[I,0],p[I,0])]*r[B][5][9,2]*r[C][4][12,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[B,1],p[I,1],p[I,1])]*r[B][5][9,2]*r[C][4][12,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,1],p[B,1],p[I,1],p[I,1])]*r[B][5][9,2]*r[C][4][12,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[I,0],p[I,0],p[B,1])]*r[B][5][9,2]*r[C][4][12,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[I,1],p[I,1],p[B,1])]*r[B][5][9,2]*r[C][4][12,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[B,1],p[C,1],p[I,0])]*r[B][5][9,2]*r[C][4][12,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[B,1],p[C,1],p[I,1])]*r[B][5][9,2]*r[C][4][12,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[C,1],p[B,1])]*r[B][5][9,2]*r[C][4][12,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[C,1],p[B,1])]*r[B][5][9,2]*r[C][4][12,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[C,1],p[B,1])]*r[A][9][1,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[C,1],p[B,1])]*r[A][39][1,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,1],p[A,0])]*r[A][9][1,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,1],p[A,1])]*r[A][39][1,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[A,0],p[B,1])]*r[A][9][1,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[A,1],p[B,1])]*r[A][39][1,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,0],p[A,0])]*r[A][9][1,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[B,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,1],p[A,1])]*r[A][39][1,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[B,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][5][9,2]*r[C][4][12,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A1B7C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,7),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*h[p[C,1],p[B,1]]*r[B][7][7,2]*r[C][6][14,3]
    hv += g[dei(p[B,0],p[B,0],p[C,1],p[B,1])]*r[B][81][7,2]*r[C][6][14,3]
    hv += g[dei(p[B,0],p[B,1],p[C,1],p[B,0])]*r[B][69][7,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[C,1],p[C,0])]*r[B][7][7,2]*r[C][114][14,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[C,0],p[C,0])]*r[B][7][7,2]*r[C][162][14,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[C,1],p[B,1])]*r[B][7][7,2]*r[C][114][14,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[C,0],p[B,1])]*r[B][7][7,2]*r[C][162][14,3]
    hv += g[dei(p[C,1],p[C,0],p[C,0],p[B,1])]*r[B][7][7,2]*r[C][128][14,3]
    hv += g[dei(p[C,1],p[C,1],p[C,1],p[B,1])]*r[B][7][7,2]*r[C][148][14,3]
    hv += sum(-1/2*g[dei(p[C,1],p[B,1],p[I,0],p[I,0])]*r[B][7][7,2]*r[C][6][14,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[B,1],p[I,1],p[I,1])]*r[B][7][7,2]*r[C][6][14,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[I,0],p[I,0],p[B,1])]*r[B][7][7,2]*r[C][6][14,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[I,1],p[I,1],p[B,1])]*r[B][7][7,2]*r[C][6][14,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[B,1],p[C,1],p[I,0])]*r[B][7][7,2]*r[C][6][14,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[B,1],p[C,1],p[I,1])]*r[B][7][7,2]*r[C][6][14,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[C,1],p[B,1])]*r[B][7][7,2]*r[C][6][14,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[C,1],p[B,1])]*r[B][7][7,2]*r[C][6][14,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[C,1],p[B,1])]*r[B][7][7,2]*r[C][6][14,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[C,1],p[B,1])]*r[B][7][7,2]*r[C][6][14,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[C,1],p[B,1])]*r[A][24][1,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += -1*g[dei(p[A,0],p[A,0],p[C,1],p[B,1])]*r[A][9][1,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[C,1],p[B,1])]*r[A][54][1,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += -1*g[dei(p[A,1],p[A,1],p[C,1],p[B,1])]*r[A][39][1,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,1],p[A,0])]*r[A][24][1,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,1],p[A,1])]*r[A][54][1,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[A,0],p[B,1])]*r[A][24][1,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[A,1],p[B,1])]*r[A][54][1,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,0],p[A,0])]*r[A][24][1,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,1],p[A,1])]*r[A][54][1,1]*r[B][7][7,2]*r[C][6][14,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A1B15C6(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,15),(C,6)]))
    hv = 0.0
    
    hv += g[dei(p[B,0],p[C,0],p[B,1],p[C,1])]*r[B][17][15,2]*r[C][46][6,3]
    hv += g[dei(p[B,0],p[C,1],p[B,1],p[C,0])]*r[B][17][15,2]*r[C][28][6,3]
    hv += g[dei(p[B,1],p[C,0],p[B,0],p[C,1])]*r[B][35][15,2]*r[C][46][6,3]
    hv += g[dei(p[B,1],p[C,1],p[B,0],p[C,0])]*r[B][35][15,2]*r[C][28][6,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A1B3C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,3),(C,2)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,0],p[C,0])]*r[B][9][3,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,0],p[C,0])]*r[B][24][3,2]*r[C][24][2,3]
    hv += g[dei(p[B,0],p[B,0],p[C,0],p[C,0])]*r[B][9][3,2]*r[C][24][2,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,1],p[C,1])]*r[B][9][3,2]*r[C][39][2,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,1],p[C,1])]*r[B][24][3,2]*r[C][54][2,3]
    hv += g[dei(p[B,0],p[B,0],p[C,1],p[C,1])]*r[B][9][3,2]*r[C][54][2,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,0],p[C,0])]*r[B][39][3,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,0],p[C,0])]*r[B][54][3,2]*r[C][24][2,3]
    hv += g[dei(p[B,1],p[B,1],p[C,0],p[C,0])]*r[B][39][3,2]*r[C][24][2,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,1],p[C,1])]*r[B][39][3,2]*r[C][39][2,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,1],p[C,1])]*r[B][54][3,2]*r[C][54][2,3]
    hv += g[dei(p[B,1],p[B,1],p[C,1],p[C,1])]*r[B][39][3,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,0],p[B,0])]*r[B][9][3,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,0],p[B,0])]*r[B][24][3,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,1],p[B,0])]*r[B][9][3,2]*r[C][39][2,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,1],p[B,0])]*r[B][24][3,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,0],p[B,1])]*r[B][39][3,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,0],p[B,1])]*r[B][54][3,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,1],p[B,1])]*r[B][39][3,2]*r[C][39][2,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,1],p[B,1])]*r[B][54][3,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,0],p[C,0])]*r[B][9][3,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,0],p[C,0])]*r[B][24][3,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,1],p[C,0])]*r[B][39][3,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,1],p[C,0])]*r[B][54][3,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,0],p[C,1])]*r[B][9][3,2]*r[C][39][2,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,0],p[C,1])]*r[B][24][3,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,1],p[C,1])]*r[B][39][3,2]*r[C][39][2,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,1],p[C,1])]*r[B][54][3,2]*r[C][54][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,0],p[B,0])]*r[B][9][3,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,0],p[B,0])]*r[B][24][3,2]*r[C][24][2,3]
    hv += g[dei(p[C,0],p[C,0],p[B,0],p[B,0])]*r[B][24][3,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,1],p[B,1])]*r[B][39][3,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,1],p[B,1])]*r[B][54][3,2]*r[C][24][2,3]
    hv += g[dei(p[C,0],p[C,0],p[B,1],p[B,1])]*r[B][54][3,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,0],p[B,0])]*r[B][9][3,2]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,0],p[B,0])]*r[B][24][3,2]*r[C][54][2,3]
    hv += g[dei(p[C,1],p[C,1],p[B,0],p[B,0])]*r[B][24][3,2]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,1],p[B,1])]*r[B][39][3,2]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,1],p[B,1])]*r[B][54][3,2]*r[C][54][2,3]
    hv += g[dei(p[C,1],p[C,1],p[B,1],p[B,1])]*r[B][54][3,2]*r[C][39][2,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A1B3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,3)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,0],p[C,1])]*r[B][9][3,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,0],p[C,1])]*r[B][24][3,2]*r[C][30][0,3]
    hv += g[dei(p[B,0],p[B,0],p[C,0],p[C,1])]*r[B][9][3,2]*r[C][30][0,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,1],p[C,0])]*r[B][9][3,2]*r[C][33][0,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,1],p[C,0])]*r[B][24][3,2]*r[C][48][0,3]
    hv += g[dei(p[B,0],p[B,0],p[C,1],p[C,0])]*r[B][9][3,2]*r[C][48][0,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,0],p[C,1])]*r[B][39][3,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,0],p[C,1])]*r[B][54][3,2]*r[C][30][0,3]
    hv += g[dei(p[B,1],p[B,1],p[C,0],p[C,1])]*r[B][39][3,2]*r[C][30][0,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,1],p[C,0])]*r[B][39][3,2]*r[C][33][0,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,1],p[C,0])]*r[B][54][3,2]*r[C][48][0,3]
    hv += g[dei(p[B,1],p[B,1],p[C,1],p[C,0])]*r[B][39][3,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,0],p[B,0])]*r[B][9][3,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,0],p[B,0])]*r[B][24][3,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,1],p[B,0])]*r[B][9][3,2]*r[C][33][0,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,1],p[B,0])]*r[B][24][3,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,0],p[B,1])]*r[B][39][3,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,0],p[B,1])]*r[B][54][3,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,1],p[B,1])]*r[B][39][3,2]*r[C][33][0,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,1],p[B,1])]*r[B][54][3,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,0],p[C,1])]*r[B][9][3,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,0],p[C,1])]*r[B][24][3,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,1],p[C,1])]*r[B][39][3,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,1],p[C,1])]*r[B][54][3,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,0],p[C,0])]*r[B][9][3,2]*r[C][33][0,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,0],p[C,0])]*r[B][24][3,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,1],p[C,0])]*r[B][39][3,2]*r[C][33][0,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,1],p[C,0])]*r[B][54][3,2]*r[C][48][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,0],p[B,0])]*r[B][9][3,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,0],p[B,0])]*r[B][24][3,2]*r[C][30][0,3]
    hv += g[dei(p[C,0],p[C,1],p[B,0],p[B,0])]*r[B][24][3,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,1],p[B,1])]*r[B][39][3,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,1],p[B,1])]*r[B][54][3,2]*r[C][30][0,3]
    hv += g[dei(p[C,0],p[C,1],p[B,1],p[B,1])]*r[B][54][3,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,0],p[B,0])]*r[B][9][3,2]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,0],p[B,0])]*r[B][24][3,2]*r[C][48][0,3]
    hv += g[dei(p[C,1],p[C,0],p[B,0],p[B,0])]*r[B][24][3,2]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,1],p[B,1])]*r[B][39][3,2]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,1],p[B,1])]*r[B][54][3,2]*r[C][48][0,3]
    hv += g[dei(p[C,1],p[C,0],p[B,1],p[B,1])]*r[B][54][3,2]*r[C][33][0,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A1B3C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,3),(C,1)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,0],p[C,1])]*r[B][9][3,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,0],p[C,1])]*r[B][24][3,2]*r[C][30][1,3]
    hv += g[dei(p[B,0],p[B,0],p[C,0],p[C,1])]*r[B][9][3,2]*r[C][30][1,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,1],p[C,0])]*r[B][9][3,2]*r[C][33][1,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,1],p[C,0])]*r[B][24][3,2]*r[C][48][1,3]
    hv += g[dei(p[B,0],p[B,0],p[C,1],p[C,0])]*r[B][9][3,2]*r[C][48][1,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,0],p[C,1])]*r[B][39][3,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,0],p[C,1])]*r[B][54][3,2]*r[C][30][1,3]
    hv += g[dei(p[B,1],p[B,1],p[C,0],p[C,1])]*r[B][39][3,2]*r[C][30][1,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,1],p[C,0])]*r[B][39][3,2]*r[C][33][1,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,1],p[C,0])]*r[B][54][3,2]*r[C][48][1,3]
    hv += g[dei(p[B,1],p[B,1],p[C,1],p[C,0])]*r[B][39][3,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,0],p[B,0])]*r[B][9][3,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,0],p[B,0])]*r[B][24][3,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,1],p[B,0])]*r[B][9][3,2]*r[C][33][1,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,1],p[B,0])]*r[B][24][3,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,0],p[B,1])]*r[B][39][3,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,0],p[B,1])]*r[B][54][3,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,1],p[B,1])]*r[B][39][3,2]*r[C][33][1,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,1],p[B,1])]*r[B][54][3,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,0],p[C,1])]*r[B][9][3,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,0],p[C,1])]*r[B][24][3,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,1],p[C,1])]*r[B][39][3,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,1],p[C,1])]*r[B][54][3,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,0],p[C,0])]*r[B][9][3,2]*r[C][33][1,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,0],p[C,0])]*r[B][24][3,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,1],p[C,0])]*r[B][39][3,2]*r[C][33][1,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,1],p[C,0])]*r[B][54][3,2]*r[C][48][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,0],p[B,0])]*r[B][9][3,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,0],p[B,0])]*r[B][24][3,2]*r[C][30][1,3]
    hv += g[dei(p[C,0],p[C,1],p[B,0],p[B,0])]*r[B][24][3,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,1],p[B,1])]*r[B][39][3,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,1],p[B,1])]*r[B][54][3,2]*r[C][30][1,3]
    hv += g[dei(p[C,0],p[C,1],p[B,1],p[B,1])]*r[B][54][3,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,0],p[B,0])]*r[B][9][3,2]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,0],p[B,0])]*r[B][24][3,2]*r[C][48][1,3]
    hv += g[dei(p[C,1],p[C,0],p[B,0],p[B,0])]*r[B][24][3,2]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,1],p[B,1])]*r[B][39][3,2]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,1],p[B,1])]*r[B][54][3,2]*r[C][48][1,3]
    hv += g[dei(p[C,1],p[C,0],p[B,1],p[B,1])]*r[B][54][3,2]*r[C][33][1,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A1C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(C,2)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,0],p[C,0])]*r[B][15][0,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,0],p[C,0])]*r[B][30][0,2]*r[C][24][2,3]
    hv += g[dei(p[B,0],p[B,1],p[C,0],p[C,0])]*r[B][15][0,2]*r[C][24][2,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,1],p[C,1])]*r[B][15][0,2]*r[C][39][2,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,1],p[C,1])]*r[B][30][0,2]*r[C][54][2,3]
    hv += g[dei(p[B,0],p[B,1],p[C,1],p[C,1])]*r[B][15][0,2]*r[C][54][2,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,0],p[C,0])]*r[B][33][0,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,0],p[C,0])]*r[B][48][0,2]*r[C][24][2,3]
    hv += g[dei(p[B,1],p[B,0],p[C,0],p[C,0])]*r[B][33][0,2]*r[C][24][2,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,1],p[C,1])]*r[B][33][0,2]*r[C][39][2,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,1],p[C,1])]*r[B][48][0,2]*r[C][54][2,3]
    hv += g[dei(p[B,1],p[B,0],p[C,1],p[C,1])]*r[B][33][0,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,0],p[B,1])]*r[B][15][0,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,0],p[B,1])]*r[B][30][0,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,1],p[B,1])]*r[B][15][0,2]*r[C][39][2,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,1],p[B,1])]*r[B][30][0,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,0],p[B,0])]*r[B][33][0,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,0],p[B,0])]*r[B][48][0,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,1],p[B,0])]*r[B][33][0,2]*r[C][39][2,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,1],p[B,0])]*r[B][48][0,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,0],p[C,0])]*r[B][15][0,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,0],p[C,0])]*r[B][30][0,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,1],p[C,0])]*r[B][33][0,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,1],p[C,0])]*r[B][48][0,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,0],p[C,1])]*r[B][15][0,2]*r[C][39][2,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,0],p[C,1])]*r[B][30][0,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,1],p[C,1])]*r[B][33][0,2]*r[C][39][2,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,1],p[C,1])]*r[B][48][0,2]*r[C][54][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,0],p[B,1])]*r[B][15][0,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][24][2,3]
    hv += g[dei(p[C,0],p[C,0],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,1],p[B,0])]*r[B][33][0,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][24][2,3]
    hv += g[dei(p[C,0],p[C,0],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,0],p[B,1])]*r[B][15][0,2]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][54][2,3]
    hv += g[dei(p[C,1],p[C,1],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,1],p[B,0])]*r[B][33][0,2]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][54][2,3]
    hv += g[dei(p[C,1],p[C,1],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][39][2,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A1B1C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,1),(C,2)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,0],p[C,0])]*r[B][15][1,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,0],p[C,0])]*r[B][30][1,2]*r[C][24][2,3]
    hv += g[dei(p[B,0],p[B,1],p[C,0],p[C,0])]*r[B][15][1,2]*r[C][24][2,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,1],p[C,1])]*r[B][15][1,2]*r[C][39][2,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,1],p[C,1])]*r[B][30][1,2]*r[C][54][2,3]
    hv += g[dei(p[B,0],p[B,1],p[C,1],p[C,1])]*r[B][15][1,2]*r[C][54][2,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,0],p[C,0])]*r[B][33][1,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,0],p[C,0])]*r[B][48][1,2]*r[C][24][2,3]
    hv += g[dei(p[B,1],p[B,0],p[C,0],p[C,0])]*r[B][33][1,2]*r[C][24][2,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,1],p[C,1])]*r[B][33][1,2]*r[C][39][2,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,1],p[C,1])]*r[B][48][1,2]*r[C][54][2,3]
    hv += g[dei(p[B,1],p[B,0],p[C,1],p[C,1])]*r[B][33][1,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,0],p[B,1])]*r[B][15][1,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,0],p[B,1])]*r[B][30][1,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,1],p[B,1])]*r[B][15][1,2]*r[C][39][2,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,1],p[B,1])]*r[B][30][1,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,0],p[B,0])]*r[B][33][1,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,0],p[B,0])]*r[B][48][1,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,1],p[B,0])]*r[B][33][1,2]*r[C][39][2,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,1],p[B,0])]*r[B][48][1,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,0],p[C,0])]*r[B][15][1,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,0],p[C,0])]*r[B][30][1,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,1],p[C,0])]*r[B][33][1,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,1],p[C,0])]*r[B][48][1,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,0],p[C,1])]*r[B][15][1,2]*r[C][39][2,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,0],p[C,1])]*r[B][30][1,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,1],p[C,1])]*r[B][33][1,2]*r[C][39][2,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,1],p[C,1])]*r[B][48][1,2]*r[C][54][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,0],p[B,1])]*r[B][15][1,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,0],p[B,1])]*r[B][30][1,2]*r[C][24][2,3]
    hv += g[dei(p[C,0],p[C,0],p[B,0],p[B,1])]*r[B][30][1,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,1],p[B,0])]*r[B][33][1,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,1],p[B,0])]*r[B][48][1,2]*r[C][24][2,3]
    hv += g[dei(p[C,0],p[C,0],p[B,1],p[B,0])]*r[B][48][1,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,0],p[B,1])]*r[B][15][1,2]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,0],p[B,1])]*r[B][30][1,2]*r[C][54][2,3]
    hv += g[dei(p[C,1],p[C,1],p[B,0],p[B,1])]*r[B][30][1,2]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,1],p[B,0])]*r[B][33][1,2]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,1],p[B,0])]*r[B][48][1,2]*r[C][54][2,3]
    hv += g[dei(p[C,1],p[C,1],p[B,1],p[B,0])]*r[B][48][1,2]*r[C][39][2,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,0],p[C,1])]*r[B][15][0,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,0],p[C,1])]*r[B][30][0,2]*r[C][30][0,3]
    hv += g[dei(p[B,0],p[B,1],p[C,0],p[C,1])]*r[B][15][0,2]*r[C][30][0,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,1],p[C,0])]*r[B][15][0,2]*r[C][33][0,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,1],p[C,0])]*r[B][30][0,2]*r[C][48][0,3]
    hv += g[dei(p[B,0],p[B,1],p[C,1],p[C,0])]*r[B][15][0,2]*r[C][48][0,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,0],p[C,1])]*r[B][33][0,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,0],p[C,1])]*r[B][48][0,2]*r[C][30][0,3]
    hv += g[dei(p[B,1],p[B,0],p[C,0],p[C,1])]*r[B][33][0,2]*r[C][30][0,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,1],p[C,0])]*r[B][33][0,2]*r[C][33][0,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,1],p[C,0])]*r[B][48][0,2]*r[C][48][0,3]
    hv += g[dei(p[B,1],p[B,0],p[C,1],p[C,0])]*r[B][33][0,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,0],p[B,1])]*r[B][15][0,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,0],p[B,1])]*r[B][30][0,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,1],p[B,1])]*r[B][15][0,2]*r[C][33][0,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,1],p[B,1])]*r[B][30][0,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,0],p[B,0])]*r[B][33][0,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,0],p[B,0])]*r[B][48][0,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,1],p[B,0])]*r[B][33][0,2]*r[C][33][0,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,1],p[B,0])]*r[B][48][0,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,0],p[C,1])]*r[B][15][0,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,0],p[C,1])]*r[B][30][0,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,1],p[C,1])]*r[B][33][0,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,1],p[C,1])]*r[B][48][0,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,0],p[C,0])]*r[B][15][0,2]*r[C][33][0,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,0],p[C,0])]*r[B][30][0,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,1],p[C,0])]*r[B][33][0,2]*r[C][33][0,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,1],p[C,0])]*r[B][48][0,2]*r[C][48][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,0],p[B,1])]*r[B][15][0,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][30][0,3]
    hv += g[dei(p[C,0],p[C,1],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,1],p[B,0])]*r[B][33][0,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][30][0,3]
    hv += g[dei(p[C,0],p[C,1],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,0],p[B,1])]*r[B][15][0,2]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][48][0,3]
    hv += g[dei(p[C,1],p[C,0],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,1],p[B,0])]*r[B][33][0,2]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][48][0,3]
    hv += g[dei(p[C,1],p[C,0],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][33][0,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A1C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(C,1)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,0],p[C,1])]*r[B][15][0,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,0],p[C,1])]*r[B][30][0,2]*r[C][30][1,3]
    hv += g[dei(p[B,0],p[B,1],p[C,0],p[C,1])]*r[B][15][0,2]*r[C][30][1,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,1],p[C,0])]*r[B][15][0,2]*r[C][33][1,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,1],p[C,0])]*r[B][30][0,2]*r[C][48][1,3]
    hv += g[dei(p[B,0],p[B,1],p[C,1],p[C,0])]*r[B][15][0,2]*r[C][48][1,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,0],p[C,1])]*r[B][33][0,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,0],p[C,1])]*r[B][48][0,2]*r[C][30][1,3]
    hv += g[dei(p[B,1],p[B,0],p[C,0],p[C,1])]*r[B][33][0,2]*r[C][30][1,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,1],p[C,0])]*r[B][33][0,2]*r[C][33][1,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,1],p[C,0])]*r[B][48][0,2]*r[C][48][1,3]
    hv += g[dei(p[B,1],p[B,0],p[C,1],p[C,0])]*r[B][33][0,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,0],p[B,1])]*r[B][15][0,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,0],p[B,1])]*r[B][30][0,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,1],p[B,1])]*r[B][15][0,2]*r[C][33][1,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,1],p[B,1])]*r[B][30][0,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,0],p[B,0])]*r[B][33][0,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,0],p[B,0])]*r[B][48][0,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,1],p[B,0])]*r[B][33][0,2]*r[C][33][1,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,1],p[B,0])]*r[B][48][0,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,0],p[C,1])]*r[B][15][0,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,0],p[C,1])]*r[B][30][0,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,1],p[C,1])]*r[B][33][0,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,1],p[C,1])]*r[B][48][0,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,0],p[C,0])]*r[B][15][0,2]*r[C][33][1,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,0],p[C,0])]*r[B][30][0,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,1],p[C,0])]*r[B][33][0,2]*r[C][33][1,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,1],p[C,0])]*r[B][48][0,2]*r[C][48][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,0],p[B,1])]*r[B][15][0,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][30][1,3]
    hv += g[dei(p[C,0],p[C,1],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,1],p[B,0])]*r[B][33][0,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][30][1,3]
    hv += g[dei(p[C,0],p[C,1],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,0],p[B,1])]*r[B][15][0,2]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][48][1,3]
    hv += g[dei(p[C,1],p[C,0],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,1],p[B,0])]*r[B][33][0,2]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][48][1,3]
    hv += g[dei(p[C,1],p[C,0],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][33][1,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A1B1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,1)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,0],p[C,1])]*r[B][15][1,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,0],p[C,1])]*r[B][30][1,2]*r[C][30][0,3]
    hv += g[dei(p[B,0],p[B,1],p[C,0],p[C,1])]*r[B][15][1,2]*r[C][30][0,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,1],p[C,0])]*r[B][15][1,2]*r[C][33][0,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,1],p[C,0])]*r[B][30][1,2]*r[C][48][0,3]
    hv += g[dei(p[B,0],p[B,1],p[C,1],p[C,0])]*r[B][15][1,2]*r[C][48][0,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,0],p[C,1])]*r[B][33][1,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,0],p[C,1])]*r[B][48][1,2]*r[C][30][0,3]
    hv += g[dei(p[B,1],p[B,0],p[C,0],p[C,1])]*r[B][33][1,2]*r[C][30][0,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,1],p[C,0])]*r[B][33][1,2]*r[C][33][0,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,1],p[C,0])]*r[B][48][1,2]*r[C][48][0,3]
    hv += g[dei(p[B,1],p[B,0],p[C,1],p[C,0])]*r[B][33][1,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,0],p[B,1])]*r[B][15][1,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,0],p[B,1])]*r[B][30][1,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,1],p[B,1])]*r[B][15][1,2]*r[C][33][0,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,1],p[B,1])]*r[B][30][1,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,0],p[B,0])]*r[B][33][1,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,0],p[B,0])]*r[B][48][1,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,1],p[B,0])]*r[B][33][1,2]*r[C][33][0,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,1],p[B,0])]*r[B][48][1,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,0],p[C,1])]*r[B][15][1,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,0],p[C,1])]*r[B][30][1,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,1],p[C,1])]*r[B][33][1,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,1],p[C,1])]*r[B][48][1,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,0],p[C,0])]*r[B][15][1,2]*r[C][33][0,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,0],p[C,0])]*r[B][30][1,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,1],p[C,0])]*r[B][33][1,2]*r[C][33][0,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,1],p[C,0])]*r[B][48][1,2]*r[C][48][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,0],p[B,1])]*r[B][15][1,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,0],p[B,1])]*r[B][30][1,2]*r[C][30][0,3]
    hv += g[dei(p[C,0],p[C,1],p[B,0],p[B,1])]*r[B][30][1,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,1],p[B,0])]*r[B][33][1,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,1],p[B,0])]*r[B][48][1,2]*r[C][30][0,3]
    hv += g[dei(p[C,0],p[C,1],p[B,1],p[B,0])]*r[B][48][1,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,0],p[B,1])]*r[B][15][1,2]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,0],p[B,1])]*r[B][30][1,2]*r[C][48][0,3]
    hv += g[dei(p[C,1],p[C,0],p[B,0],p[B,1])]*r[B][30][1,2]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,1],p[B,0])]*r[B][33][1,2]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,1],p[B,0])]*r[B][48][1,2]*r[C][48][0,3]
    hv += g[dei(p[C,1],p[C,0],p[B,1],p[B,0])]*r[B][48][1,2]*r[C][33][0,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A1B1C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,1),(C,1)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,0],p[C,1])]*r[B][15][1,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,0],p[C,1])]*r[B][30][1,2]*r[C][30][1,3]
    hv += g[dei(p[B,0],p[B,1],p[C,0],p[C,1])]*r[B][15][1,2]*r[C][30][1,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,1],p[C,0])]*r[B][15][1,2]*r[C][33][1,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,1],p[C,0])]*r[B][30][1,2]*r[C][48][1,3]
    hv += g[dei(p[B,0],p[B,1],p[C,1],p[C,0])]*r[B][15][1,2]*r[C][48][1,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,0],p[C,1])]*r[B][33][1,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,0],p[C,1])]*r[B][48][1,2]*r[C][30][1,3]
    hv += g[dei(p[B,1],p[B,0],p[C,0],p[C,1])]*r[B][33][1,2]*r[C][30][1,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,1],p[C,0])]*r[B][33][1,2]*r[C][33][1,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,1],p[C,0])]*r[B][48][1,2]*r[C][48][1,3]
    hv += g[dei(p[B,1],p[B,0],p[C,1],p[C,0])]*r[B][33][1,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,0],p[B,1])]*r[B][15][1,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,0],p[B,1])]*r[B][30][1,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,1],p[B,1])]*r[B][15][1,2]*r[C][33][1,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,1],p[B,1])]*r[B][30][1,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,0],p[B,0])]*r[B][33][1,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,0],p[B,0])]*r[B][48][1,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,1],p[B,0])]*r[B][33][1,2]*r[C][33][1,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,1],p[B,0])]*r[B][48][1,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,0],p[C,1])]*r[B][15][1,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,0],p[C,1])]*r[B][30][1,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,1],p[C,1])]*r[B][33][1,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,1],p[C,1])]*r[B][48][1,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,0],p[C,0])]*r[B][15][1,2]*r[C][33][1,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,0],p[C,0])]*r[B][30][1,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,1],p[C,0])]*r[B][33][1,2]*r[C][33][1,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,1],p[C,0])]*r[B][48][1,2]*r[C][48][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,0],p[B,1])]*r[B][15][1,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,0],p[B,1])]*r[B][30][1,2]*r[C][30][1,3]
    hv += g[dei(p[C,0],p[C,1],p[B,0],p[B,1])]*r[B][30][1,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,1],p[B,0])]*r[B][33][1,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,1],p[B,0])]*r[B][48][1,2]*r[C][30][1,3]
    hv += g[dei(p[C,0],p[C,1],p[B,1],p[B,0])]*r[B][48][1,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,0],p[B,1])]*r[B][15][1,2]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,0],p[B,1])]*r[B][30][1,2]*r[C][48][1,3]
    hv += g[dei(p[C,1],p[C,0],p[B,0],p[B,1])]*r[B][30][1,2]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,1],p[B,0])]*r[B][33][1,2]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,1],p[B,0])]*r[B][48][1,2]*r[C][48][1,3]
    hv += g[dei(p[C,1],p[C,0],p[B,1],p[B,0])]*r[B][48][1,2]*r[C][33][1,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A1B4C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,4),(C,5)]))
    hv = 0.0
    
    hv += -1*g[dei(p[B,0],p[C,0],p[C,0],p[B,0])]*r[B][12][4,2]*r[C][21][5,3]
    hv += -1*g[dei(p[B,0],p[C,1],p[C,1],p[B,0])]*r[B][12][4,2]*r[C][51][5,3]
    hv += -1*g[dei(p[B,1],p[C,0],p[C,0],p[B,1])]*r[B][42][4,2]*r[C][21][5,3]
    hv += -1*g[dei(p[B,1],p[C,1],p[C,1],p[B,1])]*r[B][42][4,2]*r[C][51][5,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A1B5C4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,5),(C,4)]))
    hv = 0.0
    
    hv += -1*g[dei(p[C,0],p[B,0],p[B,0],p[C,0])]*r[B][21][5,2]*r[C][12][4,3]
    hv += -1*g[dei(p[C,0],p[B,1],p[B,1],p[C,0])]*r[B][51][5,2]*r[C][12][4,3]
    hv += -1*g[dei(p[C,1],p[B,0],p[B,0],p[C,1])]*r[B][21][5,2]*r[C][42][4,3]
    hv += -1*g[dei(p[C,1],p[B,1],p[B,1],p[C,1])]*r[B][51][5,2]*r[C][42][4,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A1B6C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,6),(C,15)]))
    hv = 0.0
    
    hv += g[dei(p[C,0],p[B,0],p[C,1],p[B,1])]*r[B][46][6,2]*r[C][17][15,3]
    hv += g[dei(p[C,0],p[B,1],p[C,1],p[B,0])]*r[B][28][6,2]*r[C][17][15,3]
    hv += g[dei(p[C,1],p[B,0],p[C,0],p[B,1])]*r[B][46][6,2]*r[C][35][15,3]
    hv += g[dei(p[C,1],p[B,1],p[C,0],p[B,0])]*r[B][28][6,2]*r[C][35][15,3]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _B11C3I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,11),(C,3),(I,9)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[I,0])]*r[A][9][0,1]*r[B][0][11,2]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[I,0])]*r[A][39][0,1]*r[B][0][11,2]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,0],p[A,0])]*r[A][9][0,1]*r[B][0][11,2]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,0],p[A,1])]*r[A][39][0,1]*r[B][0][11,2]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[I,0])]*r[A][9][0,1]*r[B][0][11,2]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[I,0])]*r[A][39][0,1]*r[B][0][11,2]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][0][11,2]*r[I][1][9,0]
        hv += g[dei(p[B,0],p[I,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][0][11,2]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][0][11,2]*r[I][1][9,0]
        hv += g[dei(p[B,0],p[I,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][0][11,2]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B13C3I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,13),(C,3),(I,7)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[I,0])]*r[A][24][0,1]*r[B][2][13,2]*r[I][3][7,0]
        hv += g[dei(p[A,0],p[A,0],p[B,0],p[I,0])]*r[A][9][0,1]*r[B][2][13,2]*r[I][3][7,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[I,0])]*r[A][54][0,1]*r[B][2][13,2]*r[I][3][7,0]
        hv += g[dei(p[A,1],p[A,1],p[B,0],p[I,0])]*r[A][39][0,1]*r[B][2][13,2]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,0],p[A,0])]*r[A][24][0,1]*r[B][2][13,2]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,0],p[A,1])]*r[A][54][0,1]*r[B][2][13,2]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[I,0])]*r[A][24][0,1]*r[B][2][13,2]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[I,0])]*r[A][54][0,1]*r[B][2][13,2]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][2][13,2]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][2][13,2]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B11C3I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,11),(C,3),(I,10)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[I,1])]*r[A][9][0,1]*r[B][0][11,2]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[I,1])]*r[A][39][0,1]*r[B][0][11,2]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,0],p[A,0])]*r[A][9][0,1]*r[B][0][11,2]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,0],p[A,1])]*r[A][39][0,1]*r[B][0][11,2]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[I,1])]*r[A][9][0,1]*r[B][0][11,2]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[I,1])]*r[A][39][0,1]*r[B][0][11,2]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][0][11,2]*r[I][5][10,0]
        hv += g[dei(p[B,0],p[I,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][0][11,2]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][0][11,2]*r[I][5][10,0]
        hv += g[dei(p[B,0],p[I,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][0][11,2]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B13C3I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,13),(C,3),(I,8)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[I,1])]*r[A][24][0,1]*r[B][2][13,2]*r[I][7][8,0]
        hv += g[dei(p[A,0],p[A,0],p[B,0],p[I,1])]*r[A][9][0,1]*r[B][2][13,2]*r[I][7][8,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[I,1])]*r[A][54][0,1]*r[B][2][13,2]*r[I][7][8,0]
        hv += g[dei(p[A,1],p[A,1],p[B,0],p[I,1])]*r[A][39][0,1]*r[B][2][13,2]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,0],p[A,0])]*r[A][24][0,1]*r[B][2][13,2]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,0],p[A,1])]*r[A][54][0,1]*r[B][2][13,2]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[I,1])]*r[A][24][0,1]*r[B][2][13,2]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[I,1])]*r[A][54][0,1]*r[B][2][13,2]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][2][13,2]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][2][13,2]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B12C3I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,12),(C,3),(I,9)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[I,0])]*r[A][9][0,1]*r[B][4][12,2]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[I,0])]*r[A][39][0,1]*r[B][4][12,2]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,1],p[A,0])]*r[A][9][0,1]*r[B][4][12,2]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,1],p[A,1])]*r[A][39][0,1]*r[B][4][12,2]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[I,0])]*r[A][9][0,1]*r[B][4][12,2]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[I,0])]*r[A][39][0,1]*r[B][4][12,2]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][4][12,2]*r[I][1][9,0]
        hv += g[dei(p[B,1],p[I,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][4][12,2]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][4][12,2]*r[I][1][9,0]
        hv += g[dei(p[B,1],p[I,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][4][12,2]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B14C3I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,14),(C,3),(I,7)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[I,0])]*r[A][24][0,1]*r[B][6][14,2]*r[I][3][7,0]
        hv += g[dei(p[A,0],p[A,0],p[B,1],p[I,0])]*r[A][9][0,1]*r[B][6][14,2]*r[I][3][7,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[I,0])]*r[A][54][0,1]*r[B][6][14,2]*r[I][3][7,0]
        hv += g[dei(p[A,1],p[A,1],p[B,1],p[I,0])]*r[A][39][0,1]*r[B][6][14,2]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,1],p[A,0])]*r[A][24][0,1]*r[B][6][14,2]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,1],p[A,1])]*r[A][54][0,1]*r[B][6][14,2]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[I,0])]*r[A][24][0,1]*r[B][6][14,2]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[I,0])]*r[A][54][0,1]*r[B][6][14,2]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][6][14,2]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][6][14,2]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B12C3I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,12),(C,3),(I,10)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[I,1])]*r[A][9][0,1]*r[B][4][12,2]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[I,1])]*r[A][39][0,1]*r[B][4][12,2]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,1],p[A,0])]*r[A][9][0,1]*r[B][4][12,2]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,1],p[A,1])]*r[A][39][0,1]*r[B][4][12,2]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[I,1])]*r[A][9][0,1]*r[B][4][12,2]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[I,1])]*r[A][39][0,1]*r[B][4][12,2]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][4][12,2]*r[I][5][10,0]
        hv += g[dei(p[B,1],p[I,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][4][12,2]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][4][12,2]*r[I][5][10,0]
        hv += g[dei(p[B,1],p[I,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][4][12,2]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B14C3I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,14),(C,3),(I,8)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[I,1])]*r[A][24][0,1]*r[B][6][14,2]*r[I][7][8,0]
        hv += g[dei(p[A,0],p[A,0],p[B,1],p[I,1])]*r[A][9][0,1]*r[B][6][14,2]*r[I][7][8,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[I,1])]*r[A][54][0,1]*r[B][6][14,2]*r[I][7][8,0]
        hv += g[dei(p[A,1],p[A,1],p[B,1],p[I,1])]*r[A][39][0,1]*r[B][6][14,2]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,1],p[A,0])]*r[A][24][0,1]*r[B][6][14,2]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,1],p[A,1])]*r[A][54][0,1]*r[B][6][14,2]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[I,1])]*r[A][24][0,1]*r[B][6][14,2]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[I,1])]*r[A][54][0,1]*r[B][6][14,2]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][6][14,2]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][6][14,2]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A12C3I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(C,3),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[I,0])]*r[A][0][12,1]*r[B][15][0,2]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[I,0])]*r[A][0][12,1]*r[B][33][0,2]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[B,0],p[B,1])]*r[A][0][12,1]*r[B][15][0,2]*r[I][1][9,0]
        hv += g[dei(p[A,0],p[I,0],p[B,0],p[B,1])]*r[A][0][12,1]*r[B][30][0,2]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[B,1],p[B,0])]*r[A][0][12,1]*r[B][33][0,2]*r[I][1][9,0]
        hv += g[dei(p[A,0],p[I,0],p[B,1],p[B,0])]*r[A][0][12,1]*r[B][48][0,2]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[I,0])]*r[A][0][12,1]*r[B][15][0,2]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[I,0])]*r[A][0][12,1]*r[B][33][0,2]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[A,0],p[B,1])]*r[A][0][12,1]*r[B][15][0,2]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,1],p[I,0],p[A,0],p[B,0])]*r[A][0][12,1]*r[B][33][0,2]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A14C3I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(C,3),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[I,0])]*r[A][2][14,1]*r[B][30][0,2]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[I,0])]*r[A][2][14,1]*r[B][48][0,2]*r[I][3][7,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[B,0],p[B,1])]*r[A][2][14,1]*r[B][30][0,2]*r[I][3][7,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[B,1],p[B,0])]*r[A][2][14,1]*r[B][48][0,2]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[I,0])]*r[A][2][14,1]*r[B][30][0,2]*r[I][3][7,0]
        hv += g[dei(p[B,0],p[B,1],p[A,0],p[I,0])]*r[A][2][14,1]*r[B][15][0,2]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[I,0])]*r[A][2][14,1]*r[B][48][0,2]*r[I][3][7,0]
        hv += g[dei(p[B,1],p[B,0],p[A,0],p[I,0])]*r[A][2][14,1]*r[B][33][0,2]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][30][0,2]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[I,0],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][48][0,2]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A12C3I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(C,3),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[I,1])]*r[A][0][12,1]*r[B][15][0,2]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[I,1])]*r[A][0][12,1]*r[B][33][0,2]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[B,0],p[B,1])]*r[A][0][12,1]*r[B][15][0,2]*r[I][5][10,0]
        hv += g[dei(p[A,0],p[I,1],p[B,0],p[B,1])]*r[A][0][12,1]*r[B][30][0,2]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[B,1],p[B,0])]*r[A][0][12,1]*r[B][33][0,2]*r[I][5][10,0]
        hv += g[dei(p[A,0],p[I,1],p[B,1],p[B,0])]*r[A][0][12,1]*r[B][48][0,2]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[I,1])]*r[A][0][12,1]*r[B][15][0,2]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[I,1])]*r[A][0][12,1]*r[B][33][0,2]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[A,0],p[B,1])]*r[A][0][12,1]*r[B][15][0,2]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,1],p[I,1],p[A,0],p[B,0])]*r[A][0][12,1]*r[B][33][0,2]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A14C3I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(C,3),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[I,1])]*r[A][2][14,1]*r[B][30][0,2]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[I,1])]*r[A][2][14,1]*r[B][48][0,2]*r[I][7][8,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[B,0],p[B,1])]*r[A][2][14,1]*r[B][30][0,2]*r[I][7][8,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[B,1],p[B,0])]*r[A][2][14,1]*r[B][48][0,2]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[I,1])]*r[A][2][14,1]*r[B][30][0,2]*r[I][7][8,0]
        hv += g[dei(p[B,0],p[B,1],p[A,0],p[I,1])]*r[A][2][14,1]*r[B][15][0,2]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[I,1])]*r[A][2][14,1]*r[B][48][0,2]*r[I][7][8,0]
        hv += g[dei(p[B,1],p[B,0],p[A,0],p[I,1])]*r[A][2][14,1]*r[B][33][0,2]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][30][0,2]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[I,1],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][48][0,2]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A11C3I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(C,3),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[I,0])]*r[A][4][11,1]*r[B][15][0,2]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[I,0])]*r[A][4][11,1]*r[B][33][0,2]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[B,0],p[B,1])]*r[A][4][11,1]*r[B][15][0,2]*r[I][1][9,0]
        hv += g[dei(p[A,1],p[I,0],p[B,0],p[B,1])]*r[A][4][11,1]*r[B][30][0,2]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[B,1],p[B,0])]*r[A][4][11,1]*r[B][33][0,2]*r[I][1][9,0]
        hv += g[dei(p[A,1],p[I,0],p[B,1],p[B,0])]*r[A][4][11,1]*r[B][48][0,2]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[I,0])]*r[A][4][11,1]*r[B][15][0,2]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[I,0])]*r[A][4][11,1]*r[B][33][0,2]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[A,1],p[B,1])]*r[A][4][11,1]*r[B][15][0,2]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,1],p[I,0],p[A,1],p[B,0])]*r[A][4][11,1]*r[B][33][0,2]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A13C3I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(C,3),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[I,0])]*r[A][6][13,1]*r[B][30][0,2]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[I,0])]*r[A][6][13,1]*r[B][48][0,2]*r[I][3][7,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[B,0],p[B,1])]*r[A][6][13,1]*r[B][30][0,2]*r[I][3][7,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[B,1],p[B,0])]*r[A][6][13,1]*r[B][48][0,2]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[I,0])]*r[A][6][13,1]*r[B][30][0,2]*r[I][3][7,0]
        hv += g[dei(p[B,0],p[B,1],p[A,1],p[I,0])]*r[A][6][13,1]*r[B][15][0,2]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[I,0])]*r[A][6][13,1]*r[B][48][0,2]*r[I][3][7,0]
        hv += g[dei(p[B,1],p[B,0],p[A,1],p[I,0])]*r[A][6][13,1]*r[B][33][0,2]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][30][0,2]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[I,0],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][48][0,2]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A11C3I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(C,3),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[I,1])]*r[A][4][11,1]*r[B][15][0,2]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[I,1])]*r[A][4][11,1]*r[B][33][0,2]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[B,0],p[B,1])]*r[A][4][11,1]*r[B][15][0,2]*r[I][5][10,0]
        hv += g[dei(p[A,1],p[I,1],p[B,0],p[B,1])]*r[A][4][11,1]*r[B][30][0,2]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[B,1],p[B,0])]*r[A][4][11,1]*r[B][33][0,2]*r[I][5][10,0]
        hv += g[dei(p[A,1],p[I,1],p[B,1],p[B,0])]*r[A][4][11,1]*r[B][48][0,2]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[I,1])]*r[A][4][11,1]*r[B][15][0,2]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[I,1])]*r[A][4][11,1]*r[B][33][0,2]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[A,1],p[B,1])]*r[A][4][11,1]*r[B][15][0,2]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,1],p[I,1],p[A,1],p[B,0])]*r[A][4][11,1]*r[B][33][0,2]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A13C3I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(C,3),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[I,1])]*r[A][6][13,1]*r[B][30][0,2]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[I,1])]*r[A][6][13,1]*r[B][48][0,2]*r[I][7][8,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[B,0],p[B,1])]*r[A][6][13,1]*r[B][30][0,2]*r[I][7][8,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[B,1],p[B,0])]*r[A][6][13,1]*r[B][48][0,2]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[I,1])]*r[A][6][13,1]*r[B][30][0,2]*r[I][7][8,0]
        hv += g[dei(p[B,0],p[B,1],p[A,1],p[I,1])]*r[A][6][13,1]*r[B][15][0,2]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[I,1])]*r[A][6][13,1]*r[B][48][0,2]*r[I][7][8,0]
        hv += g[dei(p[B,1],p[B,0],p[A,1],p[I,1])]*r[A][6][13,1]*r[B][33][0,2]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][30][0,2]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[I,1],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][48][0,2]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B10C3I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,10),(C,3),(I,12)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,0],p[I,0],p[B,0])]*r[A][9][0,1]*r[B][1][10,2]*r[I][0][12,0]
        hv += -1/2*g[dei(p[A,1],p[A,1],p[I,0],p[B,0])]*r[A][39][0,1]*r[B][1][10,2]*r[I][0][12,0]
        hv += 1/2*g[dei(p[A,0],p[B,0],p[I,0],p[A,0])]*r[A][9][0,1]*r[B][1][10,2]*r[I][0][12,0]
        hv += 1/2*g[dei(p[A,1],p[B,0],p[I,0],p[A,1])]*r[A][39][0,1]*r[B][1][10,2]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[A,0],p[B,0])]*r[A][9][0,1]*r[B][1][10,2]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[A,1],p[B,0])]*r[A][39][0,1]*r[B][1][10,2]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[B,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][1][10,2]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[B,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][1][10,2]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[B,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][1][10,2]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[B,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][1][10,2]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B8C3I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,8),(C,3),(I,14)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,0],p[I,0],p[B,0])]*r[A][24][0,1]*r[B][3][8,2]*r[I][2][14,0]
        hv += -1*g[dei(p[A,0],p[A,0],p[I,0],p[B,0])]*r[A][9][0,1]*r[B][3][8,2]*r[I][2][14,0]
        hv += -1/2*g[dei(p[A,1],p[A,1],p[I,0],p[B,0])]*r[A][54][0,1]*r[B][3][8,2]*r[I][2][14,0]
        hv += -1*g[dei(p[A,1],p[A,1],p[I,0],p[B,0])]*r[A][39][0,1]*r[B][3][8,2]*r[I][2][14,0]
        hv += 1/2*g[dei(p[A,0],p[B,0],p[I,0],p[A,0])]*r[A][24][0,1]*r[B][3][8,2]*r[I][2][14,0]
        hv += 1/2*g[dei(p[A,1],p[B,0],p[I,0],p[A,1])]*r[A][54][0,1]*r[B][3][8,2]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[A,0],p[B,0])]*r[A][24][0,1]*r[B][3][8,2]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[A,1],p[B,0])]*r[A][54][0,1]*r[B][3][8,2]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[B,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][3][8,2]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[B,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][3][8,2]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B9C3I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,9),(C,3),(I,12)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,0],p[I,0],p[B,1])]*r[A][9][0,1]*r[B][5][9,2]*r[I][0][12,0]
        hv += -1/2*g[dei(p[A,1],p[A,1],p[I,0],p[B,1])]*r[A][39][0,1]*r[B][5][9,2]*r[I][0][12,0]
        hv += 1/2*g[dei(p[A,0],p[B,1],p[I,0],p[A,0])]*r[A][9][0,1]*r[B][5][9,2]*r[I][0][12,0]
        hv += 1/2*g[dei(p[A,1],p[B,1],p[I,0],p[A,1])]*r[A][39][0,1]*r[B][5][9,2]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[A,0],p[B,1])]*r[A][9][0,1]*r[B][5][9,2]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[A,1],p[B,1])]*r[A][39][0,1]*r[B][5][9,2]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[B,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][5][9,2]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[B,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][5][9,2]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[B,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][5][9,2]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[B,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][5][9,2]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B7C3I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,7),(C,3),(I,14)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,0],p[I,0],p[B,1])]*r[A][24][0,1]*r[B][7][7,2]*r[I][2][14,0]
        hv += -1*g[dei(p[A,0],p[A,0],p[I,0],p[B,1])]*r[A][9][0,1]*r[B][7][7,2]*r[I][2][14,0]
        hv += -1/2*g[dei(p[A,1],p[A,1],p[I,0],p[B,1])]*r[A][54][0,1]*r[B][7][7,2]*r[I][2][14,0]
        hv += -1*g[dei(p[A,1],p[A,1],p[I,0],p[B,1])]*r[A][39][0,1]*r[B][7][7,2]*r[I][2][14,0]
        hv += 1/2*g[dei(p[A,0],p[B,1],p[I,0],p[A,0])]*r[A][24][0,1]*r[B][7][7,2]*r[I][2][14,0]
        hv += 1/2*g[dei(p[A,1],p[B,1],p[I,0],p[A,1])]*r[A][54][0,1]*r[B][7][7,2]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[A,0],p[B,1])]*r[A][24][0,1]*r[B][7][7,2]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[A,1],p[B,1])]*r[A][54][0,1]*r[B][7][7,2]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[B,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][7][7,2]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[B,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][7][7,2]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B10C3I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,10),(C,3),(I,11)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,0],p[I,1],p[B,0])]*r[A][9][0,1]*r[B][1][10,2]*r[I][4][11,0]
        hv += -1/2*g[dei(p[A,1],p[A,1],p[I,1],p[B,0])]*r[A][39][0,1]*r[B][1][10,2]*r[I][4][11,0]
        hv += 1/2*g[dei(p[A,0],p[B,0],p[I,1],p[A,0])]*r[A][9][0,1]*r[B][1][10,2]*r[I][4][11,0]
        hv += 1/2*g[dei(p[A,1],p[B,0],p[I,1],p[A,1])]*r[A][39][0,1]*r[B][1][10,2]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[A,0],p[B,0])]*r[A][9][0,1]*r[B][1][10,2]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[A,1],p[B,0])]*r[A][39][0,1]*r[B][1][10,2]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[B,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][1][10,2]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[B,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][1][10,2]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[B,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][1][10,2]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[B,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][1][10,2]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B8C3I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,8),(C,3),(I,13)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,0],p[I,1],p[B,0])]*r[A][24][0,1]*r[B][3][8,2]*r[I][6][13,0]
        hv += -1*g[dei(p[A,0],p[A,0],p[I,1],p[B,0])]*r[A][9][0,1]*r[B][3][8,2]*r[I][6][13,0]
        hv += -1/2*g[dei(p[A,1],p[A,1],p[I,1],p[B,0])]*r[A][54][0,1]*r[B][3][8,2]*r[I][6][13,0]
        hv += -1*g[dei(p[A,1],p[A,1],p[I,1],p[B,0])]*r[A][39][0,1]*r[B][3][8,2]*r[I][6][13,0]
        hv += 1/2*g[dei(p[A,0],p[B,0],p[I,1],p[A,0])]*r[A][24][0,1]*r[B][3][8,2]*r[I][6][13,0]
        hv += 1/2*g[dei(p[A,1],p[B,0],p[I,1],p[A,1])]*r[A][54][0,1]*r[B][3][8,2]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[A,0],p[B,0])]*r[A][24][0,1]*r[B][3][8,2]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[A,1],p[B,0])]*r[A][54][0,1]*r[B][3][8,2]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[B,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][3][8,2]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[B,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][3][8,2]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B9C3I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,9),(C,3),(I,11)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,0],p[I,1],p[B,1])]*r[A][9][0,1]*r[B][5][9,2]*r[I][4][11,0]
        hv += -1/2*g[dei(p[A,1],p[A,1],p[I,1],p[B,1])]*r[A][39][0,1]*r[B][5][9,2]*r[I][4][11,0]
        hv += 1/2*g[dei(p[A,0],p[B,1],p[I,1],p[A,0])]*r[A][9][0,1]*r[B][5][9,2]*r[I][4][11,0]
        hv += 1/2*g[dei(p[A,1],p[B,1],p[I,1],p[A,1])]*r[A][39][0,1]*r[B][5][9,2]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[A,0],p[B,1])]*r[A][9][0,1]*r[B][5][9,2]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[A,1],p[B,1])]*r[A][39][0,1]*r[B][5][9,2]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[B,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][5][9,2]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[B,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][5][9,2]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[B,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][5][9,2]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[B,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][5][9,2]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B7C3I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,7),(C,3),(I,13)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,0],p[I,1],p[B,1])]*r[A][24][0,1]*r[B][7][7,2]*r[I][6][13,0]
        hv += -1*g[dei(p[A,0],p[A,0],p[I,1],p[B,1])]*r[A][9][0,1]*r[B][7][7,2]*r[I][6][13,0]
        hv += -1/2*g[dei(p[A,1],p[A,1],p[I,1],p[B,1])]*r[A][54][0,1]*r[B][7][7,2]*r[I][6][13,0]
        hv += -1*g[dei(p[A,1],p[A,1],p[I,1],p[B,1])]*r[A][39][0,1]*r[B][7][7,2]*r[I][6][13,0]
        hv += 1/2*g[dei(p[A,0],p[B,1],p[I,1],p[A,0])]*r[A][24][0,1]*r[B][7][7,2]*r[I][6][13,0]
        hv += 1/2*g[dei(p[A,1],p[B,1],p[I,1],p[A,1])]*r[A][54][0,1]*r[B][7][7,2]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[A,0],p[B,1])]*r[A][24][0,1]*r[B][7][7,2]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[A,1],p[B,1])]*r[A][54][0,1]*r[B][7][7,2]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[B,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][7][7,2]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[B,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][7][7,2]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A9C3I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(C,3),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[B,0],p[A,0],p[I,0],p[B,1])]*r[A][1][9,1]*r[B][15][0,2]*r[I][0][12,0]
        hv += 1/2*g[dei(p[B,1],p[A,0],p[I,0],p[B,0])]*r[A][1][9,1]*r[B][33][0,2]*r[I][0][12,0]
        hv += -1/2*g[dei(p[B,0],p[B,1],p[I,0],p[A,0])]*r[A][1][9,1]*r[B][15][0,2]*r[I][0][12,0]
        hv += -1/2*g[dei(p[B,1],p[B,0],p[I,0],p[A,0])]*r[A][1][9,1]*r[B][33][0,2]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[B,0],p[B,1])]*r[A][1][9,1]*r[B][15][0,2]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[A,0],p[B,0],p[B,1])]*r[A][1][9,1]*r[B][30][0,2]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[B,1],p[B,0])]*r[A][1][9,1]*r[B][33][0,2]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[A,0],p[B,1],p[B,0])]*r[A][1][9,1]*r[B][48][0,2]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][15][0,2]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][33][0,2]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A7C3I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(C,3),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[B,0],p[A,0],p[I,0],p[B,1])]*r[A][3][7,1]*r[B][30][0,2]*r[I][2][14,0]
        hv += 1/2*g[dei(p[B,1],p[A,0],p[I,0],p[B,0])]*r[A][3][7,1]*r[B][48][0,2]*r[I][2][14,0]
        hv += -1/2*g[dei(p[B,0],p[B,1],p[I,0],p[A,0])]*r[A][3][7,1]*r[B][30][0,2]*r[I][2][14,0]
        hv += -1*g[dei(p[B,0],p[B,1],p[I,0],p[A,0])]*r[A][3][7,1]*r[B][15][0,2]*r[I][2][14,0]
        hv += -1/2*g[dei(p[B,1],p[B,0],p[I,0],p[A,0])]*r[A][3][7,1]*r[B][48][0,2]*r[I][2][14,0]
        hv += -1*g[dei(p[B,1],p[B,0],p[I,0],p[A,0])]*r[A][3][7,1]*r[B][33][0,2]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[B,0],p[B,1])]*r[A][3][7,1]*r[B][30][0,2]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[B,1],p[B,0])]*r[A][3][7,1]*r[B][48][0,2]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][30][0,2]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][48][0,2]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A10C3I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(C,3),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[B,0],p[A,1],p[I,0],p[B,1])]*r[A][5][10,1]*r[B][15][0,2]*r[I][0][12,0]
        hv += 1/2*g[dei(p[B,1],p[A,1],p[I,0],p[B,0])]*r[A][5][10,1]*r[B][33][0,2]*r[I][0][12,0]
        hv += -1/2*g[dei(p[B,0],p[B,1],p[I,0],p[A,1])]*r[A][5][10,1]*r[B][15][0,2]*r[I][0][12,0]
        hv += -1/2*g[dei(p[B,1],p[B,0],p[I,0],p[A,1])]*r[A][5][10,1]*r[B][33][0,2]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[B,0],p[B,1])]*r[A][5][10,1]*r[B][15][0,2]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[A,1],p[B,0],p[B,1])]*r[A][5][10,1]*r[B][30][0,2]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[B,1],p[B,0])]*r[A][5][10,1]*r[B][33][0,2]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[A,1],p[B,1],p[B,0])]*r[A][5][10,1]*r[B][48][0,2]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][15][0,2]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][33][0,2]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A8C3I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(C,3),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[B,0],p[A,1],p[I,0],p[B,1])]*r[A][7][8,1]*r[B][30][0,2]*r[I][2][14,0]
        hv += 1/2*g[dei(p[B,1],p[A,1],p[I,0],p[B,0])]*r[A][7][8,1]*r[B][48][0,2]*r[I][2][14,0]
        hv += -1/2*g[dei(p[B,0],p[B,1],p[I,0],p[A,1])]*r[A][7][8,1]*r[B][30][0,2]*r[I][2][14,0]
        hv += -1*g[dei(p[B,0],p[B,1],p[I,0],p[A,1])]*r[A][7][8,1]*r[B][15][0,2]*r[I][2][14,0]
        hv += -1/2*g[dei(p[B,1],p[B,0],p[I,0],p[A,1])]*r[A][7][8,1]*r[B][48][0,2]*r[I][2][14,0]
        hv += -1*g[dei(p[B,1],p[B,0],p[I,0],p[A,1])]*r[A][7][8,1]*r[B][33][0,2]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[B,0],p[B,1])]*r[A][7][8,1]*r[B][30][0,2]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[B,1],p[B,0])]*r[A][7][8,1]*r[B][48][0,2]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][30][0,2]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][48][0,2]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A9C3I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(C,3),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[B,0],p[A,0],p[I,1],p[B,1])]*r[A][1][9,1]*r[B][15][0,2]*r[I][4][11,0]
        hv += 1/2*g[dei(p[B,1],p[A,0],p[I,1],p[B,0])]*r[A][1][9,1]*r[B][33][0,2]*r[I][4][11,0]
        hv += -1/2*g[dei(p[B,0],p[B,1],p[I,1],p[A,0])]*r[A][1][9,1]*r[B][15][0,2]*r[I][4][11,0]
        hv += -1/2*g[dei(p[B,1],p[B,0],p[I,1],p[A,0])]*r[A][1][9,1]*r[B][33][0,2]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[B,0],p[B,1])]*r[A][1][9,1]*r[B][15][0,2]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[A,0],p[B,0],p[B,1])]*r[A][1][9,1]*r[B][30][0,2]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[B,1],p[B,0])]*r[A][1][9,1]*r[B][33][0,2]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[A,0],p[B,1],p[B,0])]*r[A][1][9,1]*r[B][48][0,2]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][15][0,2]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][33][0,2]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A7C3I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(C,3),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[B,0],p[A,0],p[I,1],p[B,1])]*r[A][3][7,1]*r[B][30][0,2]*r[I][6][13,0]
        hv += 1/2*g[dei(p[B,1],p[A,0],p[I,1],p[B,0])]*r[A][3][7,1]*r[B][48][0,2]*r[I][6][13,0]
        hv += -1/2*g[dei(p[B,0],p[B,1],p[I,1],p[A,0])]*r[A][3][7,1]*r[B][30][0,2]*r[I][6][13,0]
        hv += -1*g[dei(p[B,0],p[B,1],p[I,1],p[A,0])]*r[A][3][7,1]*r[B][15][0,2]*r[I][6][13,0]
        hv += -1/2*g[dei(p[B,1],p[B,0],p[I,1],p[A,0])]*r[A][3][7,1]*r[B][48][0,2]*r[I][6][13,0]
        hv += -1*g[dei(p[B,1],p[B,0],p[I,1],p[A,0])]*r[A][3][7,1]*r[B][33][0,2]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[B,0],p[B,1])]*r[A][3][7,1]*r[B][30][0,2]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[B,1],p[B,0])]*r[A][3][7,1]*r[B][48][0,2]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][30][0,2]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][48][0,2]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A10C3I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(C,3),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[B,0],p[A,1],p[I,1],p[B,1])]*r[A][5][10,1]*r[B][15][0,2]*r[I][4][11,0]
        hv += 1/2*g[dei(p[B,1],p[A,1],p[I,1],p[B,0])]*r[A][5][10,1]*r[B][33][0,2]*r[I][4][11,0]
        hv += -1/2*g[dei(p[B,0],p[B,1],p[I,1],p[A,1])]*r[A][5][10,1]*r[B][15][0,2]*r[I][4][11,0]
        hv += -1/2*g[dei(p[B,1],p[B,0],p[I,1],p[A,1])]*r[A][5][10,1]*r[B][33][0,2]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[B,0],p[B,1])]*r[A][5][10,1]*r[B][15][0,2]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[A,1],p[B,0],p[B,1])]*r[A][5][10,1]*r[B][30][0,2]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[B,1],p[B,0])]*r[A][5][10,1]*r[B][33][0,2]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[A,1],p[B,1],p[B,0])]*r[A][5][10,1]*r[B][48][0,2]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][15][0,2]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][33][0,2]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A8C3I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(C,3),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[B,0],p[A,1],p[I,1],p[B,1])]*r[A][7][8,1]*r[B][30][0,2]*r[I][6][13,0]
        hv += 1/2*g[dei(p[B,1],p[A,1],p[I,1],p[B,0])]*r[A][7][8,1]*r[B][48][0,2]*r[I][6][13,0]
        hv += -1/2*g[dei(p[B,0],p[B,1],p[I,1],p[A,1])]*r[A][7][8,1]*r[B][30][0,2]*r[I][6][13,0]
        hv += -1*g[dei(p[B,0],p[B,1],p[I,1],p[A,1])]*r[A][7][8,1]*r[B][15][0,2]*r[I][6][13,0]
        hv += -1/2*g[dei(p[B,1],p[B,0],p[I,1],p[A,1])]*r[A][7][8,1]*r[B][48][0,2]*r[I][6][13,0]
        hv += -1*g[dei(p[B,1],p[B,0],p[I,1],p[A,1])]*r[A][7][8,1]*r[B][33][0,2]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[B,0],p[B,1])]*r[A][7][8,1]*r[B][30][0,2]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[B,1],p[B,0])]*r[A][7][8,1]*r[B][48][0,2]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][30][0,2]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][48][0,2]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B2C11I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,2),(C,11),(I,9)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[I,0])]*r[A][9][0,1]*r[C][0][11,3]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[I,0])]*r[A][39][0,1]*r[C][0][11,3]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[C,0],p[A,0])]*r[A][9][0,1]*r[C][0][11,3]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[C,0],p[A,1])]*r[A][39][0,1]*r[C][0][11,3]*r[I][1][9,0]
        hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[I,0])]*r[A][9][0,1]*r[C][0][11,3]*r[I][1][9,0]
        hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[I,0])]*r[A][39][0,1]*r[C][0][11,3]*r[I][1][9,0]
        hv += 1/2*g[dei(p[C,0],p[I,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[C][0][11,3]*r[I][1][9,0]
        hv += g[dei(p[C,0],p[I,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][0][11,3]*r[I][1][9,0]
        hv += 1/2*g[dei(p[C,0],p[I,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[C][0][11,3]*r[I][1][9,0]
        hv += g[dei(p[C,0],p[I,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][0][11,3]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B2C13I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,2),(C,13),(I,7)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[I,0])]*r[A][24][0,1]*r[C][2][13,3]*r[I][3][7,0]
        hv += g[dei(p[A,0],p[A,0],p[C,0],p[I,0])]*r[A][9][0,1]*r[C][2][13,3]*r[I][3][7,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[I,0])]*r[A][54][0,1]*r[C][2][13,3]*r[I][3][7,0]
        hv += g[dei(p[A,1],p[A,1],p[C,0],p[I,0])]*r[A][39][0,1]*r[C][2][13,3]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[C,0],p[A,0])]*r[A][24][0,1]*r[C][2][13,3]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[C,0],p[A,1])]*r[A][54][0,1]*r[C][2][13,3]*r[I][3][7,0]
        hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[I,0])]*r[A][24][0,1]*r[C][2][13,3]*r[I][3][7,0]
        hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[I,0])]*r[A][54][0,1]*r[C][2][13,3]*r[I][3][7,0]
        hv += 1/2*g[dei(p[C,0],p[I,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][2][13,3]*r[I][3][7,0]
        hv += 1/2*g[dei(p[C,0],p[I,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][2][13,3]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B2C11I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,2),(C,11),(I,10)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[I,1])]*r[A][9][0,1]*r[C][0][11,3]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[I,1])]*r[A][39][0,1]*r[C][0][11,3]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[C,0],p[A,0])]*r[A][9][0,1]*r[C][0][11,3]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[C,0],p[A,1])]*r[A][39][0,1]*r[C][0][11,3]*r[I][5][10,0]
        hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[I,1])]*r[A][9][0,1]*r[C][0][11,3]*r[I][5][10,0]
        hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[I,1])]*r[A][39][0,1]*r[C][0][11,3]*r[I][5][10,0]
        hv += 1/2*g[dei(p[C,0],p[I,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[C][0][11,3]*r[I][5][10,0]
        hv += g[dei(p[C,0],p[I,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][0][11,3]*r[I][5][10,0]
        hv += 1/2*g[dei(p[C,0],p[I,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[C][0][11,3]*r[I][5][10,0]
        hv += g[dei(p[C,0],p[I,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][0][11,3]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B2C13I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,2),(C,13),(I,8)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[I,1])]*r[A][24][0,1]*r[C][2][13,3]*r[I][7][8,0]
        hv += g[dei(p[A,0],p[A,0],p[C,0],p[I,1])]*r[A][9][0,1]*r[C][2][13,3]*r[I][7][8,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[I,1])]*r[A][54][0,1]*r[C][2][13,3]*r[I][7][8,0]
        hv += g[dei(p[A,1],p[A,1],p[C,0],p[I,1])]*r[A][39][0,1]*r[C][2][13,3]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[C,0],p[A,0])]*r[A][24][0,1]*r[C][2][13,3]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[C,0],p[A,1])]*r[A][54][0,1]*r[C][2][13,3]*r[I][7][8,0]
        hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[I,1])]*r[A][24][0,1]*r[C][2][13,3]*r[I][7][8,0]
        hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[I,1])]*r[A][54][0,1]*r[C][2][13,3]*r[I][7][8,0]
        hv += 1/2*g[dei(p[C,0],p[I,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][2][13,3]*r[I][7][8,0]
        hv += 1/2*g[dei(p[C,0],p[I,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][2][13,3]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B2C12I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,2),(C,12),(I,9)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[I,0])]*r[A][9][0,1]*r[C][4][12,3]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[I,0])]*r[A][39][0,1]*r[C][4][12,3]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[C,1],p[A,0])]*r[A][9][0,1]*r[C][4][12,3]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[C,1],p[A,1])]*r[A][39][0,1]*r[C][4][12,3]*r[I][1][9,0]
        hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[I,0])]*r[A][9][0,1]*r[C][4][12,3]*r[I][1][9,0]
        hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[I,0])]*r[A][39][0,1]*r[C][4][12,3]*r[I][1][9,0]
        hv += 1/2*g[dei(p[C,1],p[I,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[C][4][12,3]*r[I][1][9,0]
        hv += g[dei(p[C,1],p[I,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][4][12,3]*r[I][1][9,0]
        hv += 1/2*g[dei(p[C,1],p[I,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[C][4][12,3]*r[I][1][9,0]
        hv += g[dei(p[C,1],p[I,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][4][12,3]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B2C14I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,2),(C,14),(I,7)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[I,0])]*r[A][24][0,1]*r[C][6][14,3]*r[I][3][7,0]
        hv += g[dei(p[A,0],p[A,0],p[C,1],p[I,0])]*r[A][9][0,1]*r[C][6][14,3]*r[I][3][7,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[I,0])]*r[A][54][0,1]*r[C][6][14,3]*r[I][3][7,0]
        hv += g[dei(p[A,1],p[A,1],p[C,1],p[I,0])]*r[A][39][0,1]*r[C][6][14,3]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[C,1],p[A,0])]*r[A][24][0,1]*r[C][6][14,3]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[C,1],p[A,1])]*r[A][54][0,1]*r[C][6][14,3]*r[I][3][7,0]
        hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[I,0])]*r[A][24][0,1]*r[C][6][14,3]*r[I][3][7,0]
        hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[I,0])]*r[A][54][0,1]*r[C][6][14,3]*r[I][3][7,0]
        hv += 1/2*g[dei(p[C,1],p[I,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][6][14,3]*r[I][3][7,0]
        hv += 1/2*g[dei(p[C,1],p[I,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][6][14,3]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B2C12I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,2),(C,12),(I,10)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[I,1])]*r[A][9][0,1]*r[C][4][12,3]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[I,1])]*r[A][39][0,1]*r[C][4][12,3]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[C,1],p[A,0])]*r[A][9][0,1]*r[C][4][12,3]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[C,1],p[A,1])]*r[A][39][0,1]*r[C][4][12,3]*r[I][5][10,0]
        hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[I,1])]*r[A][9][0,1]*r[C][4][12,3]*r[I][5][10,0]
        hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[I,1])]*r[A][39][0,1]*r[C][4][12,3]*r[I][5][10,0]
        hv += 1/2*g[dei(p[C,1],p[I,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[C][4][12,3]*r[I][5][10,0]
        hv += g[dei(p[C,1],p[I,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][4][12,3]*r[I][5][10,0]
        hv += 1/2*g[dei(p[C,1],p[I,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[C][4][12,3]*r[I][5][10,0]
        hv += g[dei(p[C,1],p[I,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][4][12,3]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B2C14I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,2),(C,14),(I,8)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[I,1])]*r[A][24][0,1]*r[C][6][14,3]*r[I][7][8,0]
        hv += g[dei(p[A,0],p[A,0],p[C,1],p[I,1])]*r[A][9][0,1]*r[C][6][14,3]*r[I][7][8,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[I,1])]*r[A][54][0,1]*r[C][6][14,3]*r[I][7][8,0]
        hv += g[dei(p[A,1],p[A,1],p[C,1],p[I,1])]*r[A][39][0,1]*r[C][6][14,3]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[C,1],p[A,0])]*r[A][24][0,1]*r[C][6][14,3]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[C,1],p[A,1])]*r[A][54][0,1]*r[C][6][14,3]*r[I][7][8,0]
        hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[I,1])]*r[A][24][0,1]*r[C][6][14,3]*r[I][7][8,0]
        hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[I,1])]*r[A][54][0,1]*r[C][6][14,3]*r[I][7][8,0]
        hv += 1/2*g[dei(p[C,1],p[I,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][6][14,3]*r[I][7][8,0]
        hv += 1/2*g[dei(p[C,1],p[I,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][6][14,3]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A12B2I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(B,2),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[I,0])]*r[A][0][12,1]*r[C][15][0,3]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[I,0])]*r[A][0][12,1]*r[C][33][0,3]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[C,0],p[C,1])]*r[A][0][12,1]*r[C][15][0,3]*r[I][1][9,0]
        hv += g[dei(p[A,0],p[I,0],p[C,0],p[C,1])]*r[A][0][12,1]*r[C][30][0,3]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[C,1],p[C,0])]*r[A][0][12,1]*r[C][33][0,3]*r[I][1][9,0]
        hv += g[dei(p[A,0],p[I,0],p[C,1],p[C,0])]*r[A][0][12,1]*r[C][48][0,3]*r[I][1][9,0]
        hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[I,0])]*r[A][0][12,1]*r[C][15][0,3]*r[I][1][9,0]
        hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[I,0])]*r[A][0][12,1]*r[C][33][0,3]*r[I][1][9,0]
        hv += -1/2*g[dei(p[C,0],p[I,0],p[A,0],p[C,1])]*r[A][0][12,1]*r[C][15][0,3]*r[I][1][9,0]
        hv += -1/2*g[dei(p[C,1],p[I,0],p[A,0],p[C,0])]*r[A][0][12,1]*r[C][33][0,3]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A14B2I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(B,2),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[I,0])]*r[A][2][14,1]*r[C][30][0,3]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[I,0])]*r[A][2][14,1]*r[C][48][0,3]*r[I][3][7,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[C,0],p[C,1])]*r[A][2][14,1]*r[C][30][0,3]*r[I][3][7,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[C,1],p[C,0])]*r[A][2][14,1]*r[C][48][0,3]*r[I][3][7,0]
        hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[I,0])]*r[A][2][14,1]*r[C][30][0,3]*r[I][3][7,0]
        hv += g[dei(p[C,0],p[C,1],p[A,0],p[I,0])]*r[A][2][14,1]*r[C][15][0,3]*r[I][3][7,0]
        hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[I,0])]*r[A][2][14,1]*r[C][48][0,3]*r[I][3][7,0]
        hv += g[dei(p[C,1],p[C,0],p[A,0],p[I,0])]*r[A][2][14,1]*r[C][33][0,3]*r[I][3][7,0]
        hv += -1/2*g[dei(p[C,0],p[I,0],p[A,0],p[C,1])]*r[A][2][14,1]*r[C][30][0,3]*r[I][3][7,0]
        hv += -1/2*g[dei(p[C,1],p[I,0],p[A,0],p[C,0])]*r[A][2][14,1]*r[C][48][0,3]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A12B2I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(B,2),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[I,1])]*r[A][0][12,1]*r[C][15][0,3]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[I,1])]*r[A][0][12,1]*r[C][33][0,3]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[C,0],p[C,1])]*r[A][0][12,1]*r[C][15][0,3]*r[I][5][10,0]
        hv += g[dei(p[A,0],p[I,1],p[C,0],p[C,1])]*r[A][0][12,1]*r[C][30][0,3]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[C,1],p[C,0])]*r[A][0][12,1]*r[C][33][0,3]*r[I][5][10,0]
        hv += g[dei(p[A,0],p[I,1],p[C,1],p[C,0])]*r[A][0][12,1]*r[C][48][0,3]*r[I][5][10,0]
        hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[I,1])]*r[A][0][12,1]*r[C][15][0,3]*r[I][5][10,0]
        hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[I,1])]*r[A][0][12,1]*r[C][33][0,3]*r[I][5][10,0]
        hv += -1/2*g[dei(p[C,0],p[I,1],p[A,0],p[C,1])]*r[A][0][12,1]*r[C][15][0,3]*r[I][5][10,0]
        hv += -1/2*g[dei(p[C,1],p[I,1],p[A,0],p[C,0])]*r[A][0][12,1]*r[C][33][0,3]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A14B2I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(B,2),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[I,1])]*r[A][2][14,1]*r[C][30][0,3]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[I,1])]*r[A][2][14,1]*r[C][48][0,3]*r[I][7][8,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[C,0],p[C,1])]*r[A][2][14,1]*r[C][30][0,3]*r[I][7][8,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[C,1],p[C,0])]*r[A][2][14,1]*r[C][48][0,3]*r[I][7][8,0]
        hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[I,1])]*r[A][2][14,1]*r[C][30][0,3]*r[I][7][8,0]
        hv += g[dei(p[C,0],p[C,1],p[A,0],p[I,1])]*r[A][2][14,1]*r[C][15][0,3]*r[I][7][8,0]
        hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[I,1])]*r[A][2][14,1]*r[C][48][0,3]*r[I][7][8,0]
        hv += g[dei(p[C,1],p[C,0],p[A,0],p[I,1])]*r[A][2][14,1]*r[C][33][0,3]*r[I][7][8,0]
        hv += -1/2*g[dei(p[C,0],p[I,1],p[A,0],p[C,1])]*r[A][2][14,1]*r[C][30][0,3]*r[I][7][8,0]
        hv += -1/2*g[dei(p[C,1],p[I,1],p[A,0],p[C,0])]*r[A][2][14,1]*r[C][48][0,3]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A11B2I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(B,2),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[I,0])]*r[A][4][11,1]*r[C][15][0,3]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[I,0])]*r[A][4][11,1]*r[C][33][0,3]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[C,0],p[C,1])]*r[A][4][11,1]*r[C][15][0,3]*r[I][1][9,0]
        hv += g[dei(p[A,1],p[I,0],p[C,0],p[C,1])]*r[A][4][11,1]*r[C][30][0,3]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[C,1],p[C,0])]*r[A][4][11,1]*r[C][33][0,3]*r[I][1][9,0]
        hv += g[dei(p[A,1],p[I,0],p[C,1],p[C,0])]*r[A][4][11,1]*r[C][48][0,3]*r[I][1][9,0]
        hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[I,0])]*r[A][4][11,1]*r[C][15][0,3]*r[I][1][9,0]
        hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[I,0])]*r[A][4][11,1]*r[C][33][0,3]*r[I][1][9,0]
        hv += -1/2*g[dei(p[C,0],p[I,0],p[A,1],p[C,1])]*r[A][4][11,1]*r[C][15][0,3]*r[I][1][9,0]
        hv += -1/2*g[dei(p[C,1],p[I,0],p[A,1],p[C,0])]*r[A][4][11,1]*r[C][33][0,3]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A13B2I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(B,2),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[I,0])]*r[A][6][13,1]*r[C][30][0,3]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[I,0])]*r[A][6][13,1]*r[C][48][0,3]*r[I][3][7,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[C,0],p[C,1])]*r[A][6][13,1]*r[C][30][0,3]*r[I][3][7,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[C,1],p[C,0])]*r[A][6][13,1]*r[C][48][0,3]*r[I][3][7,0]
        hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[I,0])]*r[A][6][13,1]*r[C][30][0,3]*r[I][3][7,0]
        hv += g[dei(p[C,0],p[C,1],p[A,1],p[I,0])]*r[A][6][13,1]*r[C][15][0,3]*r[I][3][7,0]
        hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[I,0])]*r[A][6][13,1]*r[C][48][0,3]*r[I][3][7,0]
        hv += g[dei(p[C,1],p[C,0],p[A,1],p[I,0])]*r[A][6][13,1]*r[C][33][0,3]*r[I][3][7,0]
        hv += -1/2*g[dei(p[C,0],p[I,0],p[A,1],p[C,1])]*r[A][6][13,1]*r[C][30][0,3]*r[I][3][7,0]
        hv += -1/2*g[dei(p[C,1],p[I,0],p[A,1],p[C,0])]*r[A][6][13,1]*r[C][48][0,3]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A11B2I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(B,2),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[I,1])]*r[A][4][11,1]*r[C][15][0,3]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[I,1])]*r[A][4][11,1]*r[C][33][0,3]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[C,0],p[C,1])]*r[A][4][11,1]*r[C][15][0,3]*r[I][5][10,0]
        hv += g[dei(p[A,1],p[I,1],p[C,0],p[C,1])]*r[A][4][11,1]*r[C][30][0,3]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[C,1],p[C,0])]*r[A][4][11,1]*r[C][33][0,3]*r[I][5][10,0]
        hv += g[dei(p[A,1],p[I,1],p[C,1],p[C,0])]*r[A][4][11,1]*r[C][48][0,3]*r[I][5][10,0]
        hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[I,1])]*r[A][4][11,1]*r[C][15][0,3]*r[I][5][10,0]
        hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[I,1])]*r[A][4][11,1]*r[C][33][0,3]*r[I][5][10,0]
        hv += -1/2*g[dei(p[C,0],p[I,1],p[A,1],p[C,1])]*r[A][4][11,1]*r[C][15][0,3]*r[I][5][10,0]
        hv += -1/2*g[dei(p[C,1],p[I,1],p[A,1],p[C,0])]*r[A][4][11,1]*r[C][33][0,3]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A13B2I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(B,2),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[I,1])]*r[A][6][13,1]*r[C][30][0,3]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[I,1])]*r[A][6][13,1]*r[C][48][0,3]*r[I][7][8,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[C,0],p[C,1])]*r[A][6][13,1]*r[C][30][0,3]*r[I][7][8,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[C,1],p[C,0])]*r[A][6][13,1]*r[C][48][0,3]*r[I][7][8,0]
        hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[I,1])]*r[A][6][13,1]*r[C][30][0,3]*r[I][7][8,0]
        hv += g[dei(p[C,0],p[C,1],p[A,1],p[I,1])]*r[A][6][13,1]*r[C][15][0,3]*r[I][7][8,0]
        hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[I,1])]*r[A][6][13,1]*r[C][48][0,3]*r[I][7][8,0]
        hv += g[dei(p[C,1],p[C,0],p[A,1],p[I,1])]*r[A][6][13,1]*r[C][33][0,3]*r[I][7][8,0]
        hv += -1/2*g[dei(p[C,0],p[I,1],p[A,1],p[C,1])]*r[A][6][13,1]*r[C][30][0,3]*r[I][7][8,0]
        hv += -1/2*g[dei(p[C,1],p[I,1],p[A,1],p[C,0])]*r[A][6][13,1]*r[C][48][0,3]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B2C10I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,2),(C,10),(I,12)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,0],p[I,0],p[C,0])]*r[A][9][0,1]*r[C][1][10,3]*r[I][0][12,0]
        hv += -1/2*g[dei(p[A,1],p[A,1],p[I,0],p[C,0])]*r[A][39][0,1]*r[C][1][10,3]*r[I][0][12,0]
        hv += 1/2*g[dei(p[A,0],p[C,0],p[I,0],p[A,0])]*r[A][9][0,1]*r[C][1][10,3]*r[I][0][12,0]
        hv += 1/2*g[dei(p[A,1],p[C,0],p[I,0],p[A,1])]*r[A][39][0,1]*r[C][1][10,3]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[A,0],p[C,0])]*r[A][9][0,1]*r[C][1][10,3]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[A,1],p[C,0])]*r[A][39][0,1]*r[C][1][10,3]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[C][1][10,3]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][1][10,3]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[C][1][10,3]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][1][10,3]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B2C8I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,2),(C,8),(I,14)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,0],p[I,0],p[C,0])]*r[A][24][0,1]*r[C][3][8,3]*r[I][2][14,0]
        hv += -1*g[dei(p[A,0],p[A,0],p[I,0],p[C,0])]*r[A][9][0,1]*r[C][3][8,3]*r[I][2][14,0]
        hv += -1/2*g[dei(p[A,1],p[A,1],p[I,0],p[C,0])]*r[A][54][0,1]*r[C][3][8,3]*r[I][2][14,0]
        hv += -1*g[dei(p[A,1],p[A,1],p[I,0],p[C,0])]*r[A][39][0,1]*r[C][3][8,3]*r[I][2][14,0]
        hv += 1/2*g[dei(p[A,0],p[C,0],p[I,0],p[A,0])]*r[A][24][0,1]*r[C][3][8,3]*r[I][2][14,0]
        hv += 1/2*g[dei(p[A,1],p[C,0],p[I,0],p[A,1])]*r[A][54][0,1]*r[C][3][8,3]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[A,0],p[C,0])]*r[A][24][0,1]*r[C][3][8,3]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[A,1],p[C,0])]*r[A][54][0,1]*r[C][3][8,3]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][3][8,3]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][3][8,3]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B2C9I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,2),(C,9),(I,12)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,0],p[I,0],p[C,1])]*r[A][9][0,1]*r[C][5][9,3]*r[I][0][12,0]
        hv += -1/2*g[dei(p[A,1],p[A,1],p[I,0],p[C,1])]*r[A][39][0,1]*r[C][5][9,3]*r[I][0][12,0]
        hv += 1/2*g[dei(p[A,0],p[C,1],p[I,0],p[A,0])]*r[A][9][0,1]*r[C][5][9,3]*r[I][0][12,0]
        hv += 1/2*g[dei(p[A,1],p[C,1],p[I,0],p[A,1])]*r[A][39][0,1]*r[C][5][9,3]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[A,0],p[C,1])]*r[A][9][0,1]*r[C][5][9,3]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[A,1],p[C,1])]*r[A][39][0,1]*r[C][5][9,3]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[C][5][9,3]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[C,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][5][9,3]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[C][5][9,3]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[C,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][5][9,3]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B2C7I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,2),(C,7),(I,14)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,0],p[I,0],p[C,1])]*r[A][24][0,1]*r[C][7][7,3]*r[I][2][14,0]
        hv += -1*g[dei(p[A,0],p[A,0],p[I,0],p[C,1])]*r[A][9][0,1]*r[C][7][7,3]*r[I][2][14,0]
        hv += -1/2*g[dei(p[A,1],p[A,1],p[I,0],p[C,1])]*r[A][54][0,1]*r[C][7][7,3]*r[I][2][14,0]
        hv += -1*g[dei(p[A,1],p[A,1],p[I,0],p[C,1])]*r[A][39][0,1]*r[C][7][7,3]*r[I][2][14,0]
        hv += 1/2*g[dei(p[A,0],p[C,1],p[I,0],p[A,0])]*r[A][24][0,1]*r[C][7][7,3]*r[I][2][14,0]
        hv += 1/2*g[dei(p[A,1],p[C,1],p[I,0],p[A,1])]*r[A][54][0,1]*r[C][7][7,3]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[A,0],p[C,1])]*r[A][24][0,1]*r[C][7][7,3]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[A,1],p[C,1])]*r[A][54][0,1]*r[C][7][7,3]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][7][7,3]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][7][7,3]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B2C10I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,2),(C,10),(I,11)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,0],p[I,1],p[C,0])]*r[A][9][0,1]*r[C][1][10,3]*r[I][4][11,0]
        hv += -1/2*g[dei(p[A,1],p[A,1],p[I,1],p[C,0])]*r[A][39][0,1]*r[C][1][10,3]*r[I][4][11,0]
        hv += 1/2*g[dei(p[A,0],p[C,0],p[I,1],p[A,0])]*r[A][9][0,1]*r[C][1][10,3]*r[I][4][11,0]
        hv += 1/2*g[dei(p[A,1],p[C,0],p[I,1],p[A,1])]*r[A][39][0,1]*r[C][1][10,3]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[A,0],p[C,0])]*r[A][9][0,1]*r[C][1][10,3]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[A,1],p[C,0])]*r[A][39][0,1]*r[C][1][10,3]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[C][1][10,3]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][1][10,3]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[C][1][10,3]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][1][10,3]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B2C8I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,2),(C,8),(I,13)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,0],p[I,1],p[C,0])]*r[A][24][0,1]*r[C][3][8,3]*r[I][6][13,0]
        hv += -1*g[dei(p[A,0],p[A,0],p[I,1],p[C,0])]*r[A][9][0,1]*r[C][3][8,3]*r[I][6][13,0]
        hv += -1/2*g[dei(p[A,1],p[A,1],p[I,1],p[C,0])]*r[A][54][0,1]*r[C][3][8,3]*r[I][6][13,0]
        hv += -1*g[dei(p[A,1],p[A,1],p[I,1],p[C,0])]*r[A][39][0,1]*r[C][3][8,3]*r[I][6][13,0]
        hv += 1/2*g[dei(p[A,0],p[C,0],p[I,1],p[A,0])]*r[A][24][0,1]*r[C][3][8,3]*r[I][6][13,0]
        hv += 1/2*g[dei(p[A,1],p[C,0],p[I,1],p[A,1])]*r[A][54][0,1]*r[C][3][8,3]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[A,0],p[C,0])]*r[A][24][0,1]*r[C][3][8,3]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[A,1],p[C,0])]*r[A][54][0,1]*r[C][3][8,3]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][3][8,3]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][3][8,3]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B2C9I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,2),(C,9),(I,11)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,0],p[I,1],p[C,1])]*r[A][9][0,1]*r[C][5][9,3]*r[I][4][11,0]
        hv += -1/2*g[dei(p[A,1],p[A,1],p[I,1],p[C,1])]*r[A][39][0,1]*r[C][5][9,3]*r[I][4][11,0]
        hv += 1/2*g[dei(p[A,0],p[C,1],p[I,1],p[A,0])]*r[A][9][0,1]*r[C][5][9,3]*r[I][4][11,0]
        hv += 1/2*g[dei(p[A,1],p[C,1],p[I,1],p[A,1])]*r[A][39][0,1]*r[C][5][9,3]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[A,0],p[C,1])]*r[A][9][0,1]*r[C][5][9,3]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[A,1],p[C,1])]*r[A][39][0,1]*r[C][5][9,3]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[C][5][9,3]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[C,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][5][9,3]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[C][5][9,3]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[C,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][5][9,3]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B2C7I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,2),(C,7),(I,13)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,0],p[I,1],p[C,1])]*r[A][24][0,1]*r[C][7][7,3]*r[I][6][13,0]
        hv += -1*g[dei(p[A,0],p[A,0],p[I,1],p[C,1])]*r[A][9][0,1]*r[C][7][7,3]*r[I][6][13,0]
        hv += -1/2*g[dei(p[A,1],p[A,1],p[I,1],p[C,1])]*r[A][54][0,1]*r[C][7][7,3]*r[I][6][13,0]
        hv += -1*g[dei(p[A,1],p[A,1],p[I,1],p[C,1])]*r[A][39][0,1]*r[C][7][7,3]*r[I][6][13,0]
        hv += 1/2*g[dei(p[A,0],p[C,1],p[I,1],p[A,0])]*r[A][24][0,1]*r[C][7][7,3]*r[I][6][13,0]
        hv += 1/2*g[dei(p[A,1],p[C,1],p[I,1],p[A,1])]*r[A][54][0,1]*r[C][7][7,3]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[A,0],p[C,1])]*r[A][24][0,1]*r[C][7][7,3]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[A,1],p[C,1])]*r[A][54][0,1]*r[C][7][7,3]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[C][7][7,3]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[C][7][7,3]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A9B2I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(B,2),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[C,0],p[A,0],p[I,0],p[C,1])]*r[A][1][9,1]*r[C][15][0,3]*r[I][0][12,0]
        hv += 1/2*g[dei(p[C,1],p[A,0],p[I,0],p[C,0])]*r[A][1][9,1]*r[C][33][0,3]*r[I][0][12,0]
        hv += -1/2*g[dei(p[C,0],p[C,1],p[I,0],p[A,0])]*r[A][1][9,1]*r[C][15][0,3]*r[I][0][12,0]
        hv += -1/2*g[dei(p[C,1],p[C,0],p[I,0],p[A,0])]*r[A][1][9,1]*r[C][33][0,3]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[C,0],p[C,1])]*r[A][1][9,1]*r[C][15][0,3]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[A,0],p[C,0],p[C,1])]*r[A][1][9,1]*r[C][30][0,3]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[C,1],p[C,0])]*r[A][1][9,1]*r[C][33][0,3]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[A,0],p[C,1],p[C,0])]*r[A][1][9,1]*r[C][48][0,3]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[C,0],p[A,0])]*r[A][1][9,1]*r[C][15][0,3]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[C,1],p[A,0])]*r[A][1][9,1]*r[C][33][0,3]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A7B2I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(B,2),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[C,0],p[A,0],p[I,0],p[C,1])]*r[A][3][7,1]*r[C][30][0,3]*r[I][2][14,0]
        hv += 1/2*g[dei(p[C,1],p[A,0],p[I,0],p[C,0])]*r[A][3][7,1]*r[C][48][0,3]*r[I][2][14,0]
        hv += -1/2*g[dei(p[C,0],p[C,1],p[I,0],p[A,0])]*r[A][3][7,1]*r[C][30][0,3]*r[I][2][14,0]
        hv += -1*g[dei(p[C,0],p[C,1],p[I,0],p[A,0])]*r[A][3][7,1]*r[C][15][0,3]*r[I][2][14,0]
        hv += -1/2*g[dei(p[C,1],p[C,0],p[I,0],p[A,0])]*r[A][3][7,1]*r[C][48][0,3]*r[I][2][14,0]
        hv += -1*g[dei(p[C,1],p[C,0],p[I,0],p[A,0])]*r[A][3][7,1]*r[C][33][0,3]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[C,0],p[C,1])]*r[A][3][7,1]*r[C][30][0,3]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[C,1],p[C,0])]*r[A][3][7,1]*r[C][48][0,3]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[C,0],p[A,0])]*r[A][3][7,1]*r[C][30][0,3]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[C,1],p[A,0])]*r[A][3][7,1]*r[C][48][0,3]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A10B2I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(B,2),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[C,0],p[A,1],p[I,0],p[C,1])]*r[A][5][10,1]*r[C][15][0,3]*r[I][0][12,0]
        hv += 1/2*g[dei(p[C,1],p[A,1],p[I,0],p[C,0])]*r[A][5][10,1]*r[C][33][0,3]*r[I][0][12,0]
        hv += -1/2*g[dei(p[C,0],p[C,1],p[I,0],p[A,1])]*r[A][5][10,1]*r[C][15][0,3]*r[I][0][12,0]
        hv += -1/2*g[dei(p[C,1],p[C,0],p[I,0],p[A,1])]*r[A][5][10,1]*r[C][33][0,3]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[C,0],p[C,1])]*r[A][5][10,1]*r[C][15][0,3]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[A,1],p[C,0],p[C,1])]*r[A][5][10,1]*r[C][30][0,3]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[C,1],p[C,0])]*r[A][5][10,1]*r[C][33][0,3]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[A,1],p[C,1],p[C,0])]*r[A][5][10,1]*r[C][48][0,3]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[C,0],p[A,1])]*r[A][5][10,1]*r[C][15][0,3]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[C,1],p[A,1])]*r[A][5][10,1]*r[C][33][0,3]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A8B2I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(B,2),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[C,0],p[A,1],p[I,0],p[C,1])]*r[A][7][8,1]*r[C][30][0,3]*r[I][2][14,0]
        hv += 1/2*g[dei(p[C,1],p[A,1],p[I,0],p[C,0])]*r[A][7][8,1]*r[C][48][0,3]*r[I][2][14,0]
        hv += -1/2*g[dei(p[C,0],p[C,1],p[I,0],p[A,1])]*r[A][7][8,1]*r[C][30][0,3]*r[I][2][14,0]
        hv += -1*g[dei(p[C,0],p[C,1],p[I,0],p[A,1])]*r[A][7][8,1]*r[C][15][0,3]*r[I][2][14,0]
        hv += -1/2*g[dei(p[C,1],p[C,0],p[I,0],p[A,1])]*r[A][7][8,1]*r[C][48][0,3]*r[I][2][14,0]
        hv += -1*g[dei(p[C,1],p[C,0],p[I,0],p[A,1])]*r[A][7][8,1]*r[C][33][0,3]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[C,0],p[C,1])]*r[A][7][8,1]*r[C][30][0,3]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[C,1],p[C,0])]*r[A][7][8,1]*r[C][48][0,3]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[C,0],p[A,1])]*r[A][7][8,1]*r[C][30][0,3]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[C,1],p[A,1])]*r[A][7][8,1]*r[C][48][0,3]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A9B2I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(B,2),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[C,0],p[A,0],p[I,1],p[C,1])]*r[A][1][9,1]*r[C][15][0,3]*r[I][4][11,0]
        hv += 1/2*g[dei(p[C,1],p[A,0],p[I,1],p[C,0])]*r[A][1][9,1]*r[C][33][0,3]*r[I][4][11,0]
        hv += -1/2*g[dei(p[C,0],p[C,1],p[I,1],p[A,0])]*r[A][1][9,1]*r[C][15][0,3]*r[I][4][11,0]
        hv += -1/2*g[dei(p[C,1],p[C,0],p[I,1],p[A,0])]*r[A][1][9,1]*r[C][33][0,3]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[C,0],p[C,1])]*r[A][1][9,1]*r[C][15][0,3]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[A,0],p[C,0],p[C,1])]*r[A][1][9,1]*r[C][30][0,3]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[C,1],p[C,0])]*r[A][1][9,1]*r[C][33][0,3]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[A,0],p[C,1],p[C,0])]*r[A][1][9,1]*r[C][48][0,3]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[C,0],p[A,0])]*r[A][1][9,1]*r[C][15][0,3]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[C,1],p[A,0])]*r[A][1][9,1]*r[C][33][0,3]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A7B2I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(B,2),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[C,0],p[A,0],p[I,1],p[C,1])]*r[A][3][7,1]*r[C][30][0,3]*r[I][6][13,0]
        hv += 1/2*g[dei(p[C,1],p[A,0],p[I,1],p[C,0])]*r[A][3][7,1]*r[C][48][0,3]*r[I][6][13,0]
        hv += -1/2*g[dei(p[C,0],p[C,1],p[I,1],p[A,0])]*r[A][3][7,1]*r[C][30][0,3]*r[I][6][13,0]
        hv += -1*g[dei(p[C,0],p[C,1],p[I,1],p[A,0])]*r[A][3][7,1]*r[C][15][0,3]*r[I][6][13,0]
        hv += -1/2*g[dei(p[C,1],p[C,0],p[I,1],p[A,0])]*r[A][3][7,1]*r[C][48][0,3]*r[I][6][13,0]
        hv += -1*g[dei(p[C,1],p[C,0],p[I,1],p[A,0])]*r[A][3][7,1]*r[C][33][0,3]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[C,0],p[C,1])]*r[A][3][7,1]*r[C][30][0,3]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[C,1],p[C,0])]*r[A][3][7,1]*r[C][48][0,3]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[C,0],p[A,0])]*r[A][3][7,1]*r[C][30][0,3]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[C,1],p[A,0])]*r[A][3][7,1]*r[C][48][0,3]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A10B2I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(B,2),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[C,0],p[A,1],p[I,1],p[C,1])]*r[A][5][10,1]*r[C][15][0,3]*r[I][4][11,0]
        hv += 1/2*g[dei(p[C,1],p[A,1],p[I,1],p[C,0])]*r[A][5][10,1]*r[C][33][0,3]*r[I][4][11,0]
        hv += -1/2*g[dei(p[C,0],p[C,1],p[I,1],p[A,1])]*r[A][5][10,1]*r[C][15][0,3]*r[I][4][11,0]
        hv += -1/2*g[dei(p[C,1],p[C,0],p[I,1],p[A,1])]*r[A][5][10,1]*r[C][33][0,3]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[C,0],p[C,1])]*r[A][5][10,1]*r[C][15][0,3]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[A,1],p[C,0],p[C,1])]*r[A][5][10,1]*r[C][30][0,3]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[C,1],p[C,0])]*r[A][5][10,1]*r[C][33][0,3]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[A,1],p[C,1],p[C,0])]*r[A][5][10,1]*r[C][48][0,3]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[C,0],p[A,1])]*r[A][5][10,1]*r[C][15][0,3]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[C,1],p[A,1])]*r[A][5][10,1]*r[C][33][0,3]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A8B2I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(B,2),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[C,0],p[A,1],p[I,1],p[C,1])]*r[A][7][8,1]*r[C][30][0,3]*r[I][6][13,0]
        hv += 1/2*g[dei(p[C,1],p[A,1],p[I,1],p[C,0])]*r[A][7][8,1]*r[C][48][0,3]*r[I][6][13,0]
        hv += -1/2*g[dei(p[C,0],p[C,1],p[I,1],p[A,1])]*r[A][7][8,1]*r[C][30][0,3]*r[I][6][13,0]
        hv += -1*g[dei(p[C,0],p[C,1],p[I,1],p[A,1])]*r[A][7][8,1]*r[C][15][0,3]*r[I][6][13,0]
        hv += -1/2*g[dei(p[C,1],p[C,0],p[I,1],p[A,1])]*r[A][7][8,1]*r[C][48][0,3]*r[I][6][13,0]
        hv += -1*g[dei(p[C,1],p[C,0],p[I,1],p[A,1])]*r[A][7][8,1]*r[C][33][0,3]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[C,0],p[C,1])]*r[A][7][8,1]*r[C][30][0,3]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[C,1],p[C,0])]*r[A][7][8,1]*r[C][48][0,3]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[C,0],p[A,1])]*r[A][7][8,1]*r[C][30][0,3]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[C,1],p[A,1])]*r[A][7][8,1]*r[C][48][0,3]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1C11I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,11),(I,9)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[B,0],p[B,1],p[C,0],p[I,0])]*r[B][15][0,2]*r[C][0][11,3]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,1],p[B,0],p[C,0],p[I,0])]*r[B][33][0,2]*r[C][0][11,3]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[C,0],p[B,1])]*r[B][15][0,2]*r[C][0][11,3]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,1],p[I,0],p[C,0],p[B,0])]*r[B][33][0,2]*r[C][0][11,3]*r[I][1][9,0]
        hv += -1/2*g[dei(p[C,0],p[B,1],p[B,0],p[I,0])]*r[B][15][0,2]*r[C][0][11,3]*r[I][1][9,0]
        hv += -1/2*g[dei(p[C,0],p[B,0],p[B,1],p[I,0])]*r[B][33][0,2]*r[C][0][11,3]*r[I][1][9,0]
        hv += 1/2*g[dei(p[C,0],p[I,0],p[B,0],p[B,1])]*r[B][15][0,2]*r[C][0][11,3]*r[I][1][9,0]
        hv += g[dei(p[C,0],p[I,0],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][0][11,3]*r[I][1][9,0]
        hv += 1/2*g[dei(p[C,0],p[I,0],p[B,1],p[B,0])]*r[B][33][0,2]*r[C][0][11,3]*r[I][1][9,0]
        hv += g[dei(p[C,0],p[I,0],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][0][11,3]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1C13I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,13),(I,7)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[B,0],p[B,1],p[C,0],p[I,0])]*r[B][30][0,2]*r[C][2][13,3]*r[I][3][7,0]
        hv += g[dei(p[B,0],p[B,1],p[C,0],p[I,0])]*r[B][15][0,2]*r[C][2][13,3]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[B,0],p[C,0],p[I,0])]*r[B][48][0,2]*r[C][2][13,3]*r[I][3][7,0]
        hv += g[dei(p[B,1],p[B,0],p[C,0],p[I,0])]*r[B][33][0,2]*r[C][2][13,3]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[C,0],p[B,1])]*r[B][30][0,2]*r[C][2][13,3]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[I,0],p[C,0],p[B,0])]*r[B][48][0,2]*r[C][2][13,3]*r[I][3][7,0]
        hv += -1/2*g[dei(p[C,0],p[B,1],p[B,0],p[I,0])]*r[B][30][0,2]*r[C][2][13,3]*r[I][3][7,0]
        hv += -1/2*g[dei(p[C,0],p[B,0],p[B,1],p[I,0])]*r[B][48][0,2]*r[C][2][13,3]*r[I][3][7,0]
        hv += 1/2*g[dei(p[C,0],p[I,0],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][2][13,3]*r[I][3][7,0]
        hv += 1/2*g[dei(p[C,0],p[I,0],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][2][13,3]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1C11I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,11),(I,10)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[B,0],p[B,1],p[C,0],p[I,1])]*r[B][15][0,2]*r[C][0][11,3]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,1],p[B,0],p[C,0],p[I,1])]*r[B][33][0,2]*r[C][0][11,3]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[C,0],p[B,1])]*r[B][15][0,2]*r[C][0][11,3]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,1],p[I,1],p[C,0],p[B,0])]*r[B][33][0,2]*r[C][0][11,3]*r[I][5][10,0]
        hv += -1/2*g[dei(p[C,0],p[B,1],p[B,0],p[I,1])]*r[B][15][0,2]*r[C][0][11,3]*r[I][5][10,0]
        hv += -1/2*g[dei(p[C,0],p[B,0],p[B,1],p[I,1])]*r[B][33][0,2]*r[C][0][11,3]*r[I][5][10,0]
        hv += 1/2*g[dei(p[C,0],p[I,1],p[B,0],p[B,1])]*r[B][15][0,2]*r[C][0][11,3]*r[I][5][10,0]
        hv += g[dei(p[C,0],p[I,1],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][0][11,3]*r[I][5][10,0]
        hv += 1/2*g[dei(p[C,0],p[I,1],p[B,1],p[B,0])]*r[B][33][0,2]*r[C][0][11,3]*r[I][5][10,0]
        hv += g[dei(p[C,0],p[I,1],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][0][11,3]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1C13I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,13),(I,8)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[B,0],p[B,1],p[C,0],p[I,1])]*r[B][30][0,2]*r[C][2][13,3]*r[I][7][8,0]
        hv += g[dei(p[B,0],p[B,1],p[C,0],p[I,1])]*r[B][15][0,2]*r[C][2][13,3]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[B,0],p[C,0],p[I,1])]*r[B][48][0,2]*r[C][2][13,3]*r[I][7][8,0]
        hv += g[dei(p[B,1],p[B,0],p[C,0],p[I,1])]*r[B][33][0,2]*r[C][2][13,3]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[C,0],p[B,1])]*r[B][30][0,2]*r[C][2][13,3]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[I,1],p[C,0],p[B,0])]*r[B][48][0,2]*r[C][2][13,3]*r[I][7][8,0]
        hv += -1/2*g[dei(p[C,0],p[B,1],p[B,0],p[I,1])]*r[B][30][0,2]*r[C][2][13,3]*r[I][7][8,0]
        hv += -1/2*g[dei(p[C,0],p[B,0],p[B,1],p[I,1])]*r[B][48][0,2]*r[C][2][13,3]*r[I][7][8,0]
        hv += 1/2*g[dei(p[C,0],p[I,1],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][2][13,3]*r[I][7][8,0]
        hv += 1/2*g[dei(p[C,0],p[I,1],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][2][13,3]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1C12I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,12),(I,9)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[B,0],p[B,1],p[C,1],p[I,0])]*r[B][15][0,2]*r[C][4][12,3]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,1],p[B,0],p[C,1],p[I,0])]*r[B][33][0,2]*r[C][4][12,3]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[C,1],p[B,1])]*r[B][15][0,2]*r[C][4][12,3]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,1],p[I,0],p[C,1],p[B,0])]*r[B][33][0,2]*r[C][4][12,3]*r[I][1][9,0]
        hv += -1/2*g[dei(p[C,1],p[B,1],p[B,0],p[I,0])]*r[B][15][0,2]*r[C][4][12,3]*r[I][1][9,0]
        hv += -1/2*g[dei(p[C,1],p[B,0],p[B,1],p[I,0])]*r[B][33][0,2]*r[C][4][12,3]*r[I][1][9,0]
        hv += 1/2*g[dei(p[C,1],p[I,0],p[B,0],p[B,1])]*r[B][15][0,2]*r[C][4][12,3]*r[I][1][9,0]
        hv += g[dei(p[C,1],p[I,0],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][4][12,3]*r[I][1][9,0]
        hv += 1/2*g[dei(p[C,1],p[I,0],p[B,1],p[B,0])]*r[B][33][0,2]*r[C][4][12,3]*r[I][1][9,0]
        hv += g[dei(p[C,1],p[I,0],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][4][12,3]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1C14I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,14),(I,7)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[B,0],p[B,1],p[C,1],p[I,0])]*r[B][30][0,2]*r[C][6][14,3]*r[I][3][7,0]
        hv += g[dei(p[B,0],p[B,1],p[C,1],p[I,0])]*r[B][15][0,2]*r[C][6][14,3]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[B,0],p[C,1],p[I,0])]*r[B][48][0,2]*r[C][6][14,3]*r[I][3][7,0]
        hv += g[dei(p[B,1],p[B,0],p[C,1],p[I,0])]*r[B][33][0,2]*r[C][6][14,3]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[C,1],p[B,1])]*r[B][30][0,2]*r[C][6][14,3]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[I,0],p[C,1],p[B,0])]*r[B][48][0,2]*r[C][6][14,3]*r[I][3][7,0]
        hv += -1/2*g[dei(p[C,1],p[B,1],p[B,0],p[I,0])]*r[B][30][0,2]*r[C][6][14,3]*r[I][3][7,0]
        hv += -1/2*g[dei(p[C,1],p[B,0],p[B,1],p[I,0])]*r[B][48][0,2]*r[C][6][14,3]*r[I][3][7,0]
        hv += 1/2*g[dei(p[C,1],p[I,0],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][6][14,3]*r[I][3][7,0]
        hv += 1/2*g[dei(p[C,1],p[I,0],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][6][14,3]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1C12I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,12),(I,10)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[B,0],p[B,1],p[C,1],p[I,1])]*r[B][15][0,2]*r[C][4][12,3]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,1],p[B,0],p[C,1],p[I,1])]*r[B][33][0,2]*r[C][4][12,3]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[C,1],p[B,1])]*r[B][15][0,2]*r[C][4][12,3]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,1],p[I,1],p[C,1],p[B,0])]*r[B][33][0,2]*r[C][4][12,3]*r[I][5][10,0]
        hv += -1/2*g[dei(p[C,1],p[B,1],p[B,0],p[I,1])]*r[B][15][0,2]*r[C][4][12,3]*r[I][5][10,0]
        hv += -1/2*g[dei(p[C,1],p[B,0],p[B,1],p[I,1])]*r[B][33][0,2]*r[C][4][12,3]*r[I][5][10,0]
        hv += 1/2*g[dei(p[C,1],p[I,1],p[B,0],p[B,1])]*r[B][15][0,2]*r[C][4][12,3]*r[I][5][10,0]
        hv += g[dei(p[C,1],p[I,1],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][4][12,3]*r[I][5][10,0]
        hv += 1/2*g[dei(p[C,1],p[I,1],p[B,1],p[B,0])]*r[B][33][0,2]*r[C][4][12,3]*r[I][5][10,0]
        hv += g[dei(p[C,1],p[I,1],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][4][12,3]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1C14I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,14),(I,8)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[B,0],p[B,1],p[C,1],p[I,1])]*r[B][30][0,2]*r[C][6][14,3]*r[I][7][8,0]
        hv += g[dei(p[B,0],p[B,1],p[C,1],p[I,1])]*r[B][15][0,2]*r[C][6][14,3]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[B,0],p[C,1],p[I,1])]*r[B][48][0,2]*r[C][6][14,3]*r[I][7][8,0]
        hv += g[dei(p[B,1],p[B,0],p[C,1],p[I,1])]*r[B][33][0,2]*r[C][6][14,3]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[C,1],p[B,1])]*r[B][30][0,2]*r[C][6][14,3]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[I,1],p[C,1],p[B,0])]*r[B][48][0,2]*r[C][6][14,3]*r[I][7][8,0]
        hv += -1/2*g[dei(p[C,1],p[B,1],p[B,0],p[I,1])]*r[B][30][0,2]*r[C][6][14,3]*r[I][7][8,0]
        hv += -1/2*g[dei(p[C,1],p[B,0],p[B,1],p[I,1])]*r[B][48][0,2]*r[C][6][14,3]*r[I][7][8,0]
        hv += 1/2*g[dei(p[C,1],p[I,1],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][6][14,3]*r[I][7][8,0]
        hv += 1/2*g[dei(p[C,1],p[I,1],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][6][14,3]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1B11I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,11),(I,9)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1/2*g[dei(p[B,0],p[C,1],p[C,0],p[I,0])]*r[B][0][11,2]*r[C][15][0,3]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[C,1],p[I,0])]*r[B][0][11,2]*r[C][33][0,3]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[C,0],p[C,1])]*r[B][0][11,2]*r[C][15][0,3]*r[I][1][9,0]
        hv += g[dei(p[B,0],p[I,0],p[C,0],p[C,1])]*r[B][0][11,2]*r[C][30][0,3]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[C,1],p[C,0])]*r[B][0][11,2]*r[C][33][0,3]*r[I][1][9,0]
        hv += g[dei(p[B,0],p[I,0],p[C,1],p[C,0])]*r[B][0][11,2]*r[C][48][0,3]*r[I][1][9,0]
        hv += 1/2*g[dei(p[C,0],p[C,1],p[B,0],p[I,0])]*r[B][0][11,2]*r[C][15][0,3]*r[I][1][9,0]
        hv += 1/2*g[dei(p[C,1],p[C,0],p[B,0],p[I,0])]*r[B][0][11,2]*r[C][33][0,3]*r[I][1][9,0]
        hv += -1/2*g[dei(p[C,0],p[I,0],p[B,0],p[C,1])]*r[B][0][11,2]*r[C][15][0,3]*r[I][1][9,0]
        hv += -1/2*g[dei(p[C,1],p[I,0],p[B,0],p[C,0])]*r[B][0][11,2]*r[C][33][0,3]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1B13I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,13),(I,7)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1/2*g[dei(p[B,0],p[C,1],p[C,0],p[I,0])]*r[B][2][13,2]*r[C][30][0,3]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[C,1],p[I,0])]*r[B][2][13,2]*r[C][48][0,3]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[C,0],p[C,1])]*r[B][2][13,2]*r[C][30][0,3]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[C,1],p[C,0])]*r[B][2][13,2]*r[C][48][0,3]*r[I][3][7,0]
        hv += 1/2*g[dei(p[C,0],p[C,1],p[B,0],p[I,0])]*r[B][2][13,2]*r[C][30][0,3]*r[I][3][7,0]
        hv += g[dei(p[C,0],p[C,1],p[B,0],p[I,0])]*r[B][2][13,2]*r[C][15][0,3]*r[I][3][7,0]
        hv += 1/2*g[dei(p[C,1],p[C,0],p[B,0],p[I,0])]*r[B][2][13,2]*r[C][48][0,3]*r[I][3][7,0]
        hv += g[dei(p[C,1],p[C,0],p[B,0],p[I,0])]*r[B][2][13,2]*r[C][33][0,3]*r[I][3][7,0]
        hv += -1/2*g[dei(p[C,0],p[I,0],p[B,0],p[C,1])]*r[B][2][13,2]*r[C][30][0,3]*r[I][3][7,0]
        hv += -1/2*g[dei(p[C,1],p[I,0],p[B,0],p[C,0])]*r[B][2][13,2]*r[C][48][0,3]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1B11I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,11),(I,10)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1/2*g[dei(p[B,0],p[C,1],p[C,0],p[I,1])]*r[B][0][11,2]*r[C][15][0,3]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[C,1],p[I,1])]*r[B][0][11,2]*r[C][33][0,3]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[C,0],p[C,1])]*r[B][0][11,2]*r[C][15][0,3]*r[I][5][10,0]
        hv += g[dei(p[B,0],p[I,1],p[C,0],p[C,1])]*r[B][0][11,2]*r[C][30][0,3]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[C,1],p[C,0])]*r[B][0][11,2]*r[C][33][0,3]*r[I][5][10,0]
        hv += g[dei(p[B,0],p[I,1],p[C,1],p[C,0])]*r[B][0][11,2]*r[C][48][0,3]*r[I][5][10,0]
        hv += 1/2*g[dei(p[C,0],p[C,1],p[B,0],p[I,1])]*r[B][0][11,2]*r[C][15][0,3]*r[I][5][10,0]
        hv += 1/2*g[dei(p[C,1],p[C,0],p[B,0],p[I,1])]*r[B][0][11,2]*r[C][33][0,3]*r[I][5][10,0]
        hv += -1/2*g[dei(p[C,0],p[I,1],p[B,0],p[C,1])]*r[B][0][11,2]*r[C][15][0,3]*r[I][5][10,0]
        hv += -1/2*g[dei(p[C,1],p[I,1],p[B,0],p[C,0])]*r[B][0][11,2]*r[C][33][0,3]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1B13I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,13),(I,8)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1/2*g[dei(p[B,0],p[C,1],p[C,0],p[I,1])]*r[B][2][13,2]*r[C][30][0,3]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[C,1],p[I,1])]*r[B][2][13,2]*r[C][48][0,3]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[C,0],p[C,1])]*r[B][2][13,2]*r[C][30][0,3]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[C,1],p[C,0])]*r[B][2][13,2]*r[C][48][0,3]*r[I][7][8,0]
        hv += 1/2*g[dei(p[C,0],p[C,1],p[B,0],p[I,1])]*r[B][2][13,2]*r[C][30][0,3]*r[I][7][8,0]
        hv += g[dei(p[C,0],p[C,1],p[B,0],p[I,1])]*r[B][2][13,2]*r[C][15][0,3]*r[I][7][8,0]
        hv += 1/2*g[dei(p[C,1],p[C,0],p[B,0],p[I,1])]*r[B][2][13,2]*r[C][48][0,3]*r[I][7][8,0]
        hv += g[dei(p[C,1],p[C,0],p[B,0],p[I,1])]*r[B][2][13,2]*r[C][33][0,3]*r[I][7][8,0]
        hv += -1/2*g[dei(p[C,0],p[I,1],p[B,0],p[C,1])]*r[B][2][13,2]*r[C][30][0,3]*r[I][7][8,0]
        hv += -1/2*g[dei(p[C,1],p[I,1],p[B,0],p[C,0])]*r[B][2][13,2]*r[C][48][0,3]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1B12I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,12),(I,9)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1/2*g[dei(p[B,1],p[C,1],p[C,0],p[I,0])]*r[B][4][12,2]*r[C][15][0,3]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,1],p[C,0],p[C,1],p[I,0])]*r[B][4][12,2]*r[C][33][0,3]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[C,0],p[C,1])]*r[B][4][12,2]*r[C][15][0,3]*r[I][1][9,0]
        hv += g[dei(p[B,1],p[I,0],p[C,0],p[C,1])]*r[B][4][12,2]*r[C][30][0,3]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[C,1],p[C,0])]*r[B][4][12,2]*r[C][33][0,3]*r[I][1][9,0]
        hv += g[dei(p[B,1],p[I,0],p[C,1],p[C,0])]*r[B][4][12,2]*r[C][48][0,3]*r[I][1][9,0]
        hv += 1/2*g[dei(p[C,0],p[C,1],p[B,1],p[I,0])]*r[B][4][12,2]*r[C][15][0,3]*r[I][1][9,0]
        hv += 1/2*g[dei(p[C,1],p[C,0],p[B,1],p[I,0])]*r[B][4][12,2]*r[C][33][0,3]*r[I][1][9,0]
        hv += -1/2*g[dei(p[C,0],p[I,0],p[B,1],p[C,1])]*r[B][4][12,2]*r[C][15][0,3]*r[I][1][9,0]
        hv += -1/2*g[dei(p[C,1],p[I,0],p[B,1],p[C,0])]*r[B][4][12,2]*r[C][33][0,3]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1B14I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,14),(I,7)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1/2*g[dei(p[B,1],p[C,1],p[C,0],p[I,0])]*r[B][6][14,2]*r[C][30][0,3]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[C,0],p[C,1],p[I,0])]*r[B][6][14,2]*r[C][48][0,3]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[C,0],p[C,1])]*r[B][6][14,2]*r[C][30][0,3]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[C,1],p[C,0])]*r[B][6][14,2]*r[C][48][0,3]*r[I][3][7,0]
        hv += 1/2*g[dei(p[C,0],p[C,1],p[B,1],p[I,0])]*r[B][6][14,2]*r[C][30][0,3]*r[I][3][7,0]
        hv += g[dei(p[C,0],p[C,1],p[B,1],p[I,0])]*r[B][6][14,2]*r[C][15][0,3]*r[I][3][7,0]
        hv += 1/2*g[dei(p[C,1],p[C,0],p[B,1],p[I,0])]*r[B][6][14,2]*r[C][48][0,3]*r[I][3][7,0]
        hv += g[dei(p[C,1],p[C,0],p[B,1],p[I,0])]*r[B][6][14,2]*r[C][33][0,3]*r[I][3][7,0]
        hv += -1/2*g[dei(p[C,0],p[I,0],p[B,1],p[C,1])]*r[B][6][14,2]*r[C][30][0,3]*r[I][3][7,0]
        hv += -1/2*g[dei(p[C,1],p[I,0],p[B,1],p[C,0])]*r[B][6][14,2]*r[C][48][0,3]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1B12I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,12),(I,10)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1/2*g[dei(p[B,1],p[C,1],p[C,0],p[I,1])]*r[B][4][12,2]*r[C][15][0,3]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,1],p[C,0],p[C,1],p[I,1])]*r[B][4][12,2]*r[C][33][0,3]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[C,0],p[C,1])]*r[B][4][12,2]*r[C][15][0,3]*r[I][5][10,0]
        hv += g[dei(p[B,1],p[I,1],p[C,0],p[C,1])]*r[B][4][12,2]*r[C][30][0,3]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[C,1],p[C,0])]*r[B][4][12,2]*r[C][33][0,3]*r[I][5][10,0]
        hv += g[dei(p[B,1],p[I,1],p[C,1],p[C,0])]*r[B][4][12,2]*r[C][48][0,3]*r[I][5][10,0]
        hv += 1/2*g[dei(p[C,0],p[C,1],p[B,1],p[I,1])]*r[B][4][12,2]*r[C][15][0,3]*r[I][5][10,0]
        hv += 1/2*g[dei(p[C,1],p[C,0],p[B,1],p[I,1])]*r[B][4][12,2]*r[C][33][0,3]*r[I][5][10,0]
        hv += -1/2*g[dei(p[C,0],p[I,1],p[B,1],p[C,1])]*r[B][4][12,2]*r[C][15][0,3]*r[I][5][10,0]
        hv += -1/2*g[dei(p[C,1],p[I,1],p[B,1],p[C,0])]*r[B][4][12,2]*r[C][33][0,3]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1B14I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,14),(I,8)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1/2*g[dei(p[B,1],p[C,1],p[C,0],p[I,1])]*r[B][6][14,2]*r[C][30][0,3]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[C,0],p[C,1],p[I,1])]*r[B][6][14,2]*r[C][48][0,3]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[C,0],p[C,1])]*r[B][6][14,2]*r[C][30][0,3]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[C,1],p[C,0])]*r[B][6][14,2]*r[C][48][0,3]*r[I][7][8,0]
        hv += 1/2*g[dei(p[C,0],p[C,1],p[B,1],p[I,1])]*r[B][6][14,2]*r[C][30][0,3]*r[I][7][8,0]
        hv += g[dei(p[C,0],p[C,1],p[B,1],p[I,1])]*r[B][6][14,2]*r[C][15][0,3]*r[I][7][8,0]
        hv += 1/2*g[dei(p[C,1],p[C,0],p[B,1],p[I,1])]*r[B][6][14,2]*r[C][48][0,3]*r[I][7][8,0]
        hv += g[dei(p[C,1],p[C,0],p[B,1],p[I,1])]*r[B][6][14,2]*r[C][33][0,3]*r[I][7][8,0]
        hv += -1/2*g[dei(p[C,0],p[I,1],p[B,1],p[C,1])]*r[B][6][14,2]*r[C][30][0,3]*r[I][7][8,0]
        hv += -1/2*g[dei(p[C,1],p[I,1],p[B,1],p[C,0])]*r[B][6][14,2]*r[C][48][0,3]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1C10I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,10),(I,12)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1/2*g[dei(p[B,0],p[B,1],p[I,0],p[C,0])]*r[B][15][0,2]*r[C][1][10,3]*r[I][0][12,0]
        hv += -1/2*g[dei(p[B,1],p[B,0],p[I,0],p[C,0])]*r[B][33][0,2]*r[C][1][10,3]*r[I][0][12,0]
        hv += 1/2*g[dei(p[B,0],p[C,0],p[I,0],p[B,1])]*r[B][15][0,2]*r[C][1][10,3]*r[I][0][12,0]
        hv += 1/2*g[dei(p[B,1],p[C,0],p[I,0],p[B,0])]*r[B][33][0,2]*r[C][1][10,3]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[B,0],p[C,0])]*r[B][15][0,2]*r[C][1][10,3]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[B,1],p[C,0])]*r[B][33][0,2]*r[C][1][10,3]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[B,0],p[B,1])]*r[B][15][0,2]*r[C][1][10,3]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[C,0],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][1][10,3]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[B,1],p[B,0])]*r[B][33][0,2]*r[C][1][10,3]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[C,0],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][1][10,3]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1C8I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,8),(I,14)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1/2*g[dei(p[B,0],p[B,1],p[I,0],p[C,0])]*r[B][30][0,2]*r[C][3][8,3]*r[I][2][14,0]
        hv += -1*g[dei(p[B,0],p[B,1],p[I,0],p[C,0])]*r[B][15][0,2]*r[C][3][8,3]*r[I][2][14,0]
        hv += -1/2*g[dei(p[B,1],p[B,0],p[I,0],p[C,0])]*r[B][48][0,2]*r[C][3][8,3]*r[I][2][14,0]
        hv += -1*g[dei(p[B,1],p[B,0],p[I,0],p[C,0])]*r[B][33][0,2]*r[C][3][8,3]*r[I][2][14,0]
        hv += 1/2*g[dei(p[B,0],p[C,0],p[I,0],p[B,1])]*r[B][30][0,2]*r[C][3][8,3]*r[I][2][14,0]
        hv += 1/2*g[dei(p[B,1],p[C,0],p[I,0],p[B,0])]*r[B][48][0,2]*r[C][3][8,3]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[B,0],p[C,0])]*r[B][30][0,2]*r[C][3][8,3]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[B,1],p[C,0])]*r[B][48][0,2]*r[C][3][8,3]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][3][8,3]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][3][8,3]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1C9I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,9),(I,12)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1/2*g[dei(p[B,0],p[B,1],p[I,0],p[C,1])]*r[B][15][0,2]*r[C][5][9,3]*r[I][0][12,0]
        hv += -1/2*g[dei(p[B,1],p[B,0],p[I,0],p[C,1])]*r[B][33][0,2]*r[C][5][9,3]*r[I][0][12,0]
        hv += 1/2*g[dei(p[B,0],p[C,1],p[I,0],p[B,1])]*r[B][15][0,2]*r[C][5][9,3]*r[I][0][12,0]
        hv += 1/2*g[dei(p[B,1],p[C,1],p[I,0],p[B,0])]*r[B][33][0,2]*r[C][5][9,3]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[B,0],p[C,1])]*r[B][15][0,2]*r[C][5][9,3]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[B,1],p[C,1])]*r[B][33][0,2]*r[C][5][9,3]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[B,0],p[B,1])]*r[B][15][0,2]*r[C][5][9,3]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[C,1],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][5][9,3]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[B,1],p[B,0])]*r[B][33][0,2]*r[C][5][9,3]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[C,1],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][5][9,3]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1C7I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,7),(I,14)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1/2*g[dei(p[B,0],p[B,1],p[I,0],p[C,1])]*r[B][30][0,2]*r[C][7][7,3]*r[I][2][14,0]
        hv += -1*g[dei(p[B,0],p[B,1],p[I,0],p[C,1])]*r[B][15][0,2]*r[C][7][7,3]*r[I][2][14,0]
        hv += -1/2*g[dei(p[B,1],p[B,0],p[I,0],p[C,1])]*r[B][48][0,2]*r[C][7][7,3]*r[I][2][14,0]
        hv += -1*g[dei(p[B,1],p[B,0],p[I,0],p[C,1])]*r[B][33][0,2]*r[C][7][7,3]*r[I][2][14,0]
        hv += 1/2*g[dei(p[B,0],p[C,1],p[I,0],p[B,1])]*r[B][30][0,2]*r[C][7][7,3]*r[I][2][14,0]
        hv += 1/2*g[dei(p[B,1],p[C,1],p[I,0],p[B,0])]*r[B][48][0,2]*r[C][7][7,3]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[B,0],p[C,1])]*r[B][30][0,2]*r[C][7][7,3]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[B,1],p[C,1])]*r[B][48][0,2]*r[C][7][7,3]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][7][7,3]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][7][7,3]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1C10I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,10),(I,11)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1/2*g[dei(p[B,0],p[B,1],p[I,1],p[C,0])]*r[B][15][0,2]*r[C][1][10,3]*r[I][4][11,0]
        hv += -1/2*g[dei(p[B,1],p[B,0],p[I,1],p[C,0])]*r[B][33][0,2]*r[C][1][10,3]*r[I][4][11,0]
        hv += 1/2*g[dei(p[B,0],p[C,0],p[I,1],p[B,1])]*r[B][15][0,2]*r[C][1][10,3]*r[I][4][11,0]
        hv += 1/2*g[dei(p[B,1],p[C,0],p[I,1],p[B,0])]*r[B][33][0,2]*r[C][1][10,3]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[B,0],p[C,0])]*r[B][15][0,2]*r[C][1][10,3]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[B,1],p[C,0])]*r[B][33][0,2]*r[C][1][10,3]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[B,0],p[B,1])]*r[B][15][0,2]*r[C][1][10,3]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[C,0],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][1][10,3]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[B,1],p[B,0])]*r[B][33][0,2]*r[C][1][10,3]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[C,0],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][1][10,3]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1C8I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,8),(I,13)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1/2*g[dei(p[B,0],p[B,1],p[I,1],p[C,0])]*r[B][30][0,2]*r[C][3][8,3]*r[I][6][13,0]
        hv += -1*g[dei(p[B,0],p[B,1],p[I,1],p[C,0])]*r[B][15][0,2]*r[C][3][8,3]*r[I][6][13,0]
        hv += -1/2*g[dei(p[B,1],p[B,0],p[I,1],p[C,0])]*r[B][48][0,2]*r[C][3][8,3]*r[I][6][13,0]
        hv += -1*g[dei(p[B,1],p[B,0],p[I,1],p[C,0])]*r[B][33][0,2]*r[C][3][8,3]*r[I][6][13,0]
        hv += 1/2*g[dei(p[B,0],p[C,0],p[I,1],p[B,1])]*r[B][30][0,2]*r[C][3][8,3]*r[I][6][13,0]
        hv += 1/2*g[dei(p[B,1],p[C,0],p[I,1],p[B,0])]*r[B][48][0,2]*r[C][3][8,3]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[B,0],p[C,0])]*r[B][30][0,2]*r[C][3][8,3]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[B,1],p[C,0])]*r[B][48][0,2]*r[C][3][8,3]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][3][8,3]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][3][8,3]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1C9I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,9),(I,11)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1/2*g[dei(p[B,0],p[B,1],p[I,1],p[C,1])]*r[B][15][0,2]*r[C][5][9,3]*r[I][4][11,0]
        hv += -1/2*g[dei(p[B,1],p[B,0],p[I,1],p[C,1])]*r[B][33][0,2]*r[C][5][9,3]*r[I][4][11,0]
        hv += 1/2*g[dei(p[B,0],p[C,1],p[I,1],p[B,1])]*r[B][15][0,2]*r[C][5][9,3]*r[I][4][11,0]
        hv += 1/2*g[dei(p[B,1],p[C,1],p[I,1],p[B,0])]*r[B][33][0,2]*r[C][5][9,3]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[B,0],p[C,1])]*r[B][15][0,2]*r[C][5][9,3]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[B,1],p[C,1])]*r[B][33][0,2]*r[C][5][9,3]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[B,0],p[B,1])]*r[B][15][0,2]*r[C][5][9,3]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[C,1],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][5][9,3]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[B,1],p[B,0])]*r[B][33][0,2]*r[C][5][9,3]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[C,1],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][5][9,3]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1C7I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,7),(I,13)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1/2*g[dei(p[B,0],p[B,1],p[I,1],p[C,1])]*r[B][30][0,2]*r[C][7][7,3]*r[I][6][13,0]
        hv += -1*g[dei(p[B,0],p[B,1],p[I,1],p[C,1])]*r[B][15][0,2]*r[C][7][7,3]*r[I][6][13,0]
        hv += -1/2*g[dei(p[B,1],p[B,0],p[I,1],p[C,1])]*r[B][48][0,2]*r[C][7][7,3]*r[I][6][13,0]
        hv += -1*g[dei(p[B,1],p[B,0],p[I,1],p[C,1])]*r[B][33][0,2]*r[C][7][7,3]*r[I][6][13,0]
        hv += 1/2*g[dei(p[B,0],p[C,1],p[I,1],p[B,1])]*r[B][30][0,2]*r[C][7][7,3]*r[I][6][13,0]
        hv += 1/2*g[dei(p[B,1],p[C,1],p[I,1],p[B,0])]*r[B][48][0,2]*r[C][7][7,3]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[B,0],p[C,1])]*r[B][30][0,2]*r[C][7][7,3]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[B,1],p[C,1])]*r[B][48][0,2]*r[C][7][7,3]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[B,0],p[B,1])]*r[B][30][0,2]*r[C][7][7,3]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[B,1],p[B,0])]*r[B][48][0,2]*r[C][7][7,3]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1B10I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,10),(I,12)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[C,0],p[B,0],p[I,0],p[C,1])]*r[B][1][10,2]*r[C][15][0,3]*r[I][0][12,0]
        hv += 1/2*g[dei(p[C,1],p[B,0],p[I,0],p[C,0])]*r[B][1][10,2]*r[C][33][0,3]*r[I][0][12,0]
        hv += -1/2*g[dei(p[C,0],p[C,1],p[I,0],p[B,0])]*r[B][1][10,2]*r[C][15][0,3]*r[I][0][12,0]
        hv += -1/2*g[dei(p[C,1],p[C,0],p[I,0],p[B,0])]*r[B][1][10,2]*r[C][33][0,3]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[B,0],p[C,0],p[C,1])]*r[B][1][10,2]*r[C][15][0,3]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[B,0],p[C,0],p[C,1])]*r[B][1][10,2]*r[C][30][0,3]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[B,0],p[C,1],p[C,0])]*r[B][1][10,2]*r[C][33][0,3]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[B,0],p[C,1],p[C,0])]*r[B][1][10,2]*r[C][48][0,3]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[C,0],p[B,0])]*r[B][1][10,2]*r[C][15][0,3]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[C,1],p[B,0])]*r[B][1][10,2]*r[C][33][0,3]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1B8I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,8),(I,14)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[C,0],p[B,0],p[I,0],p[C,1])]*r[B][3][8,2]*r[C][30][0,3]*r[I][2][14,0]
        hv += 1/2*g[dei(p[C,1],p[B,0],p[I,0],p[C,0])]*r[B][3][8,2]*r[C][48][0,3]*r[I][2][14,0]
        hv += -1/2*g[dei(p[C,0],p[C,1],p[I,0],p[B,0])]*r[B][3][8,2]*r[C][30][0,3]*r[I][2][14,0]
        hv += -1*g[dei(p[C,0],p[C,1],p[I,0],p[B,0])]*r[B][3][8,2]*r[C][15][0,3]*r[I][2][14,0]
        hv += -1/2*g[dei(p[C,1],p[C,0],p[I,0],p[B,0])]*r[B][3][8,2]*r[C][48][0,3]*r[I][2][14,0]
        hv += -1*g[dei(p[C,1],p[C,0],p[I,0],p[B,0])]*r[B][3][8,2]*r[C][33][0,3]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[B,0],p[C,0],p[C,1])]*r[B][3][8,2]*r[C][30][0,3]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[B,0],p[C,1],p[C,0])]*r[B][3][8,2]*r[C][48][0,3]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[C,0],p[B,0])]*r[B][3][8,2]*r[C][30][0,3]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[C,1],p[B,0])]*r[B][3][8,2]*r[C][48][0,3]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1B9I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,9),(I,12)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[C,0],p[B,1],p[I,0],p[C,1])]*r[B][5][9,2]*r[C][15][0,3]*r[I][0][12,0]
        hv += 1/2*g[dei(p[C,1],p[B,1],p[I,0],p[C,0])]*r[B][5][9,2]*r[C][33][0,3]*r[I][0][12,0]
        hv += -1/2*g[dei(p[C,0],p[C,1],p[I,0],p[B,1])]*r[B][5][9,2]*r[C][15][0,3]*r[I][0][12,0]
        hv += -1/2*g[dei(p[C,1],p[C,0],p[I,0],p[B,1])]*r[B][5][9,2]*r[C][33][0,3]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[B,1],p[C,0],p[C,1])]*r[B][5][9,2]*r[C][15][0,3]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[B,1],p[C,0],p[C,1])]*r[B][5][9,2]*r[C][30][0,3]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[B,1],p[C,1],p[C,0])]*r[B][5][9,2]*r[C][33][0,3]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[B,1],p[C,1],p[C,0])]*r[B][5][9,2]*r[C][48][0,3]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[C,0],p[B,1])]*r[B][5][9,2]*r[C][15][0,3]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[C,1],p[B,1])]*r[B][5][9,2]*r[C][33][0,3]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1B7I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,7),(I,14)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[C,0],p[B,1],p[I,0],p[C,1])]*r[B][7][7,2]*r[C][30][0,3]*r[I][2][14,0]
        hv += 1/2*g[dei(p[C,1],p[B,1],p[I,0],p[C,0])]*r[B][7][7,2]*r[C][48][0,3]*r[I][2][14,0]
        hv += -1/2*g[dei(p[C,0],p[C,1],p[I,0],p[B,1])]*r[B][7][7,2]*r[C][30][0,3]*r[I][2][14,0]
        hv += -1*g[dei(p[C,0],p[C,1],p[I,0],p[B,1])]*r[B][7][7,2]*r[C][15][0,3]*r[I][2][14,0]
        hv += -1/2*g[dei(p[C,1],p[C,0],p[I,0],p[B,1])]*r[B][7][7,2]*r[C][48][0,3]*r[I][2][14,0]
        hv += -1*g[dei(p[C,1],p[C,0],p[I,0],p[B,1])]*r[B][7][7,2]*r[C][33][0,3]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[B,1],p[C,0],p[C,1])]*r[B][7][7,2]*r[C][30][0,3]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[B,1],p[C,1],p[C,0])]*r[B][7][7,2]*r[C][48][0,3]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[C,0],p[B,1])]*r[B][7][7,2]*r[C][30][0,3]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[C,1],p[B,1])]*r[B][7][7,2]*r[C][48][0,3]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1B10I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,10),(I,11)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[C,0],p[B,0],p[I,1],p[C,1])]*r[B][1][10,2]*r[C][15][0,3]*r[I][4][11,0]
        hv += 1/2*g[dei(p[C,1],p[B,0],p[I,1],p[C,0])]*r[B][1][10,2]*r[C][33][0,3]*r[I][4][11,0]
        hv += -1/2*g[dei(p[C,0],p[C,1],p[I,1],p[B,0])]*r[B][1][10,2]*r[C][15][0,3]*r[I][4][11,0]
        hv += -1/2*g[dei(p[C,1],p[C,0],p[I,1],p[B,0])]*r[B][1][10,2]*r[C][33][0,3]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[B,0],p[C,0],p[C,1])]*r[B][1][10,2]*r[C][15][0,3]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[B,0],p[C,0],p[C,1])]*r[B][1][10,2]*r[C][30][0,3]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[B,0],p[C,1],p[C,0])]*r[B][1][10,2]*r[C][33][0,3]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[B,0],p[C,1],p[C,0])]*r[B][1][10,2]*r[C][48][0,3]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[C,0],p[B,0])]*r[B][1][10,2]*r[C][15][0,3]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[C,1],p[B,0])]*r[B][1][10,2]*r[C][33][0,3]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1B8I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,8),(I,13)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[C,0],p[B,0],p[I,1],p[C,1])]*r[B][3][8,2]*r[C][30][0,3]*r[I][6][13,0]
        hv += 1/2*g[dei(p[C,1],p[B,0],p[I,1],p[C,0])]*r[B][3][8,2]*r[C][48][0,3]*r[I][6][13,0]
        hv += -1/2*g[dei(p[C,0],p[C,1],p[I,1],p[B,0])]*r[B][3][8,2]*r[C][30][0,3]*r[I][6][13,0]
        hv += -1*g[dei(p[C,0],p[C,1],p[I,1],p[B,0])]*r[B][3][8,2]*r[C][15][0,3]*r[I][6][13,0]
        hv += -1/2*g[dei(p[C,1],p[C,0],p[I,1],p[B,0])]*r[B][3][8,2]*r[C][48][0,3]*r[I][6][13,0]
        hv += -1*g[dei(p[C,1],p[C,0],p[I,1],p[B,0])]*r[B][3][8,2]*r[C][33][0,3]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[B,0],p[C,0],p[C,1])]*r[B][3][8,2]*r[C][30][0,3]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[B,0],p[C,1],p[C,0])]*r[B][3][8,2]*r[C][48][0,3]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[C,0],p[B,0])]*r[B][3][8,2]*r[C][30][0,3]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[C,1],p[B,0])]*r[B][3][8,2]*r[C][48][0,3]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1B9I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,9),(I,11)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[C,0],p[B,1],p[I,1],p[C,1])]*r[B][5][9,2]*r[C][15][0,3]*r[I][4][11,0]
        hv += 1/2*g[dei(p[C,1],p[B,1],p[I,1],p[C,0])]*r[B][5][9,2]*r[C][33][0,3]*r[I][4][11,0]
        hv += -1/2*g[dei(p[C,0],p[C,1],p[I,1],p[B,1])]*r[B][5][9,2]*r[C][15][0,3]*r[I][4][11,0]
        hv += -1/2*g[dei(p[C,1],p[C,0],p[I,1],p[B,1])]*r[B][5][9,2]*r[C][33][0,3]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[B,1],p[C,0],p[C,1])]*r[B][5][9,2]*r[C][15][0,3]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[B,1],p[C,0],p[C,1])]*r[B][5][9,2]*r[C][30][0,3]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[B,1],p[C,1],p[C,0])]*r[B][5][9,2]*r[C][33][0,3]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[B,1],p[C,1],p[C,0])]*r[B][5][9,2]*r[C][48][0,3]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[C,0],p[B,1])]*r[B][5][9,2]*r[C][15][0,3]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[C,1],p[B,1])]*r[B][5][9,2]*r[C][33][0,3]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A1B7I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,7),(I,13)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[C,0],p[B,1],p[I,1],p[C,1])]*r[B][7][7,2]*r[C][30][0,3]*r[I][6][13,0]
        hv += 1/2*g[dei(p[C,1],p[B,1],p[I,1],p[C,0])]*r[B][7][7,2]*r[C][48][0,3]*r[I][6][13,0]
        hv += -1/2*g[dei(p[C,0],p[C,1],p[I,1],p[B,1])]*r[B][7][7,2]*r[C][30][0,3]*r[I][6][13,0]
        hv += -1*g[dei(p[C,0],p[C,1],p[I,1],p[B,1])]*r[B][7][7,2]*r[C][15][0,3]*r[I][6][13,0]
        hv += -1/2*g[dei(p[C,1],p[C,0],p[I,1],p[B,1])]*r[B][7][7,2]*r[C][48][0,3]*r[I][6][13,0]
        hv += -1*g[dei(p[C,1],p[C,0],p[I,1],p[B,1])]*r[B][7][7,2]*r[C][33][0,3]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[B,1],p[C,0],p[C,1])]*r[B][7][7,2]*r[C][30][0,3]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[B,1],p[C,1],p[C,0])]*r[B][7][7,2]*r[C][48][0,3]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[C,0],p[B,1])]*r[B][7][7,2]*r[C][30][0,3]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[C,1],p[B,1])]*r[B][7][7,2]*r[C][48][0,3]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A15B10C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,15),(B,10),(C,8)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[A,0],p[B,0],p[A,0],p[C,0])]*r[A][11][15,1]*r[B][1][10,2]*r[C][3][8,3]
    hv += -1*g[dei(p[A,1],p[B,0],p[A,1],p[C,0])]*r[A][41][15,1]*r[B][1][10,2]*r[C][3][8,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A15B10C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,15),(B,10),(C,7)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[A,0],p[B,0],p[A,0],p[C,1])]*r[A][11][15,1]*r[B][1][10,2]*r[C][7][7,3]
    hv += -1*g[dei(p[A,1],p[B,0],p[A,1],p[C,1])]*r[A][41][15,1]*r[B][1][10,2]*r[C][7][7,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A15B9C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,15),(B,9),(C,8)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[A,0],p[B,1],p[A,0],p[C,0])]*r[A][11][15,1]*r[B][5][9,2]*r[C][3][8,3]
    hv += -1*g[dei(p[A,1],p[B,1],p[A,1],p[C,0])]*r[A][41][15,1]*r[B][5][9,2]*r[C][3][8,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A15B9C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,15),(B,9),(C,7)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[A,0],p[B,1],p[A,0],p[C,1])]*r[A][11][15,1]*r[B][5][9,2]*r[C][7][7,3]
    hv += -1*g[dei(p[A,1],p[B,1],p[A,1],p[C,1])]*r[A][41][15,1]*r[B][5][9,2]*r[C][7][7,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A15B8C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,15),(B,8),(C,10)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[A,0],p[C,0],p[A,0],p[B,0])]*r[A][11][15,1]*r[B][3][8,2]*r[C][1][10,3]
    hv += g[dei(p[A,1],p[C,0],p[A,1],p[B,0])]*r[A][41][15,1]*r[B][3][8,2]*r[C][1][10,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A15B7C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,15),(B,7),(C,10)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[A,0],p[C,0],p[A,0],p[B,1])]*r[A][11][15,1]*r[B][7][7,2]*r[C][1][10,3]
    hv += g[dei(p[A,1],p[C,0],p[A,1],p[B,1])]*r[A][41][15,1]*r[B][7][7,2]*r[C][1][10,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A15B8C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,15),(B,8),(C,9)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[A,0],p[C,1],p[A,0],p[B,0])]*r[A][11][15,1]*r[B][3][8,2]*r[C][5][9,3]
    hv += g[dei(p[A,1],p[C,1],p[A,1],p[B,0])]*r[A][41][15,1]*r[B][3][8,2]*r[C][5][9,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A15B7C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,15),(B,7),(C,9)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[A,0],p[C,1],p[A,0],p[B,1])]*r[A][11][15,1]*r[B][7][7,2]*r[C][5][9,3]
    hv += g[dei(p[A,1],p[C,1],p[A,1],p[B,1])]*r[A][41][15,1]*r[B][7][7,2]*r[C][5][9,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _B11C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(B,11),(C,10)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][9][0,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][39][0,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,0])]*r[A][9][0,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,1])]*r[A][39][0,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,0])]*r[A][9][0,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,0])]*r[A][39][0,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][0][11,2]*r[C][1][10,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _B13C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(B,13),(C,8)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][24][0,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][9][0,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][54][0,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][39][0,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,0])]*r[A][24][0,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,1])]*r[A][54][0,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,0])]*r[A][24][0,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,0])]*r[A][54][0,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][2][13,2]*r[C][3][8,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _B11C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(B,11),(C,9)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][9][0,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][39][0,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,0])]*r[A][9][0,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,1])]*r[A][39][0,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,1])]*r[A][9][0,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,1])]*r[A][39][0,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][0][11,2]*r[C][5][9,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _B13C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(B,13),(C,7)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][24][0,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][9][0,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][54][0,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][39][0,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,0])]*r[A][24][0,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,1])]*r[A][54][0,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,1])]*r[A][24][0,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,1])]*r[A][54][0,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][2][13,2]*r[C][7][7,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A2B11C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(B,11),(C,10)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][15][2,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][33][2,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,1])]*r[A][15][2,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,0])]*r[A][33][2,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,0])]*r[A][15][2,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,0])]*r[A][33][2,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][0][11,2]*r[C][1][10,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A3B11C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,11),(C,10)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][15][3,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][33][3,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,1])]*r[A][15][3,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,0])]*r[A][33][3,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,0])]*r[A][15][3,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,0])]*r[A][33][3,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][0][11,2]*r[C][1][10,3]
    hv += g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][0][11,2]*r[C][1][10,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A2B13C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(B,13),(C,8)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][30][2,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][15][2,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][48][2,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][33][2,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,1])]*r[A][30][2,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,0])]*r[A][48][2,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,0])]*r[A][30][2,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,0])]*r[A][48][2,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][2][13,2]*r[C][3][8,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A3B13C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,13),(C,8)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][30][3,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][15][3,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][48][3,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][33][3,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,1])]*r[A][30][3,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,0])]*r[A][48][3,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,0])]*r[A][30][3,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,0])]*r[A][48][3,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][2][13,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][2][13,2]*r[C][3][8,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A2B11C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(B,11),(C,9)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][15][2,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][33][2,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,1])]*r[A][15][2,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,0])]*r[A][33][2,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,1])]*r[A][15][2,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,1])]*r[A][33][2,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][0][11,2]*r[C][5][9,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A3B11C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,11),(C,9)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][15][3,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][33][3,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,1])]*r[A][15][3,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,0])]*r[A][33][3,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,1])]*r[A][15][3,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,1])]*r[A][33][3,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][0][11,2]*r[C][5][9,3]
    hv += g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][0][11,2]*r[C][5][9,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A2B13C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(B,13),(C,7)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][30][2,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][15][2,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][48][2,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][33][2,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,1])]*r[A][30][2,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,0])]*r[A][48][2,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,1])]*r[A][30][2,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,1])]*r[A][48][2,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][2][13,2]*r[C][7][7,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A3B13C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,13),(C,7)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][30][3,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][15][3,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][48][3,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][33][3,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,1])]*r[A][30][3,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,0])]*r[A][48][3,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,1])]*r[A][30][3,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,1])]*r[A][48][3,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][2][13,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][2][13,2]*r[C][7][7,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _B12C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(B,12),(C,10)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][9][0,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][39][0,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,0])]*r[A][9][0,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,1])]*r[A][39][0,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,0])]*r[A][9][0,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,0])]*r[A][39][0,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][4][12,2]*r[C][1][10,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _B14C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(B,14),(C,8)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][24][0,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][9][0,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][54][0,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][39][0,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,0])]*r[A][24][0,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,1])]*r[A][54][0,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,0])]*r[A][24][0,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,0])]*r[A][54][0,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][6][14,2]*r[C][3][8,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _B12C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(B,12),(C,9)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][9][0,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][39][0,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,0])]*r[A][9][0,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,1])]*r[A][39][0,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,1])]*r[A][9][0,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,1])]*r[A][39][0,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][4][12,2]*r[C][5][9,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _B14C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(B,14),(C,7)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][24][0,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][9][0,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][54][0,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][39][0,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,0])]*r[A][24][0,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,1])]*r[A][54][0,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,1])]*r[A][24][0,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,1])]*r[A][54][0,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][6][14,2]*r[C][7][7,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A2B12C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(B,12),(C,10)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][15][2,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][33][2,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,1])]*r[A][15][2,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,0])]*r[A][33][2,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,0])]*r[A][15][2,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,0])]*r[A][33][2,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][4][12,2]*r[C][1][10,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A3B12C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,12),(C,10)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][15][3,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][33][3,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,1])]*r[A][15][3,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,0])]*r[A][33][3,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,0])]*r[A][15][3,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,0])]*r[A][33][3,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][4][12,2]*r[C][1][10,3]
    hv += g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][4][12,2]*r[C][1][10,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A2B14C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(B,14),(C,8)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][30][2,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][15][2,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][48][2,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][33][2,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,1])]*r[A][30][2,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,0])]*r[A][48][2,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,0])]*r[A][30][2,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,0])]*r[A][48][2,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][6][14,2]*r[C][3][8,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A3B14C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,14),(C,8)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][30][3,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][15][3,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][48][3,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][33][3,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,1])]*r[A][30][3,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,0])]*r[A][48][3,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,0])]*r[A][30][3,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,0])]*r[A][48][3,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][6][14,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][6][14,2]*r[C][3][8,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A2B12C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(B,12),(C,9)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][15][2,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][33][2,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,1])]*r[A][15][2,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,0])]*r[A][33][2,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,1])]*r[A][15][2,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,1])]*r[A][33][2,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][4][12,2]*r[C][5][9,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A3B12C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,12),(C,9)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][15][3,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][33][3,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,1])]*r[A][15][3,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,0])]*r[A][33][3,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,1])]*r[A][15][3,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,1])]*r[A][33][3,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][4][12,2]*r[C][5][9,3]
    hv += g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][4][12,2]*r[C][5][9,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A2B14C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(B,14),(C,7)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][30][2,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][15][2,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][48][2,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][33][2,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,1])]*r[A][30][2,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,0])]*r[A][48][2,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,1])]*r[A][30][2,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,1])]*r[A][48][2,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][6][14,2]*r[C][7][7,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A3B14C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,14),(C,7)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][30][3,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][15][3,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][48][3,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][33][3,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,1])]*r[A][30][3,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,0])]*r[A][48][3,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,1])]*r[A][30][3,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,1])]*r[A][48][3,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][6][14,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][6][14,2]*r[C][7][7,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12B3C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,3),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[C,0])]*r[A][0][12,1]*r[B][9][3,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[C,0])]*r[A][0][12,1]*r[B][39][3,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[B,0])]*r[A][0][12,1]*r[B][9][3,2]*r[C][1][10,3]
    hv += g[dei(p[A,0],p[C,0],p[B,0],p[B,0])]*r[A][0][12,1]*r[B][24][3,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[B,1])]*r[A][0][12,1]*r[B][39][3,2]*r[C][1][10,3]
    hv += g[dei(p[A,0],p[C,0],p[B,1],p[B,1])]*r[A][0][12,1]*r[B][54][3,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[C,0])]*r[A][0][12,1]*r[B][9][3,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[C,0])]*r[A][0][12,1]*r[B][39][3,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[B,0])]*r[A][0][12,1]*r[B][9][3,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[B,1])]*r[A][0][12,1]*r[B][39][3,2]*r[C][1][10,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B3C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,3),(C,8)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[C,0])]*r[A][2][14,1]*r[B][24][3,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[C,0])]*r[A][2][14,1]*r[B][54][3,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[B,0])]*r[A][2][14,1]*r[B][24][3,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[B,1])]*r[A][2][14,1]*r[B][54][3,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][24][3,2]*r[C][3][8,3]
    hv += g[dei(p[B,0],p[B,0],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][9][3,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][54][3,2]*r[C][3][8,3]
    hv += g[dei(p[B,1],p[B,1],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][39][3,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][24][3,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][54][3,2]*r[C][3][8,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12B5C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,5),(C,8)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[A,0],p[B,0],p[B,0],p[C,0])]*r[A][0][12,1]*r[B][21][5,2]*r[C][3][8,3]
    hv += -1*g[dei(p[A,0],p[B,1],p[B,1],p[C,0])]*r[A][0][12,1]*r[B][51][5,2]*r[C][3][8,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12B3C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,3),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[C,1])]*r[A][0][12,1]*r[B][9][3,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[C,1])]*r[A][0][12,1]*r[B][39][3,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[B,0])]*r[A][0][12,1]*r[B][9][3,2]*r[C][5][9,3]
    hv += g[dei(p[A,0],p[C,1],p[B,0],p[B,0])]*r[A][0][12,1]*r[B][24][3,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[B,1])]*r[A][0][12,1]*r[B][39][3,2]*r[C][5][9,3]
    hv += g[dei(p[A,0],p[C,1],p[B,1],p[B,1])]*r[A][0][12,1]*r[B][54][3,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[C,1])]*r[A][0][12,1]*r[B][9][3,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[C,1])]*r[A][0][12,1]*r[B][39][3,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[B,0])]*r[A][0][12,1]*r[B][9][3,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[B,1])]*r[A][0][12,1]*r[B][39][3,2]*r[C][5][9,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B3C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,3),(C,7)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[C,1])]*r[A][2][14,1]*r[B][24][3,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[C,1])]*r[A][2][14,1]*r[B][54][3,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[B,0])]*r[A][2][14,1]*r[B][24][3,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[B,1])]*r[A][2][14,1]*r[B][54][3,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[C,1])]*r[A][2][14,1]*r[B][24][3,2]*r[C][7][7,3]
    hv += g[dei(p[B,0],p[B,0],p[A,0],p[C,1])]*r[A][2][14,1]*r[B][9][3,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[C,1])]*r[A][2][14,1]*r[B][54][3,2]*r[C][7][7,3]
    hv += g[dei(p[B,1],p[B,1],p[A,0],p[C,1])]*r[A][2][14,1]*r[B][39][3,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][24][3,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][54][3,2]*r[C][7][7,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12B5C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,5),(C,7)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[A,0],p[B,0],p[B,0],p[C,1])]*r[A][0][12,1]*r[B][21][5,2]*r[C][7][7,3]
    hv += -1*g[dei(p[A,0],p[B,1],p[B,1],p[C,1])]*r[A][0][12,1]*r[B][51][5,2]*r[C][7][7,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[C,0])]*r[A][0][12,1]*r[B][15][0,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[C,0])]*r[A][0][12,1]*r[B][33][0,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[B,1])]*r[A][0][12,1]*r[B][15][0,2]*r[C][1][10,3]
    hv += g[dei(p[A,0],p[C,0],p[B,0],p[B,1])]*r[A][0][12,1]*r[B][30][0,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[B,0])]*r[A][0][12,1]*r[B][33][0,2]*r[C][1][10,3]
    hv += g[dei(p[A,0],p[C,0],p[B,1],p[B,0])]*r[A][0][12,1]*r[B][48][0,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[C,0])]*r[A][0][12,1]*r[B][15][0,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[C,0])]*r[A][0][12,1]*r[B][33][0,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[B,1])]*r[A][0][12,1]*r[B][15][0,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[B,0])]*r[A][0][12,1]*r[B][33][0,2]*r[C][1][10,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12B1C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,1),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[C,0])]*r[A][0][12,1]*r[B][15][1,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[C,0])]*r[A][0][12,1]*r[B][33][1,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[B,1])]*r[A][0][12,1]*r[B][15][1,2]*r[C][1][10,3]
    hv += g[dei(p[A,0],p[C,0],p[B,0],p[B,1])]*r[A][0][12,1]*r[B][30][1,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[B,0])]*r[A][0][12,1]*r[B][33][1,2]*r[C][1][10,3]
    hv += g[dei(p[A,0],p[C,0],p[B,1],p[B,0])]*r[A][0][12,1]*r[B][48][1,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[C,0])]*r[A][0][12,1]*r[B][15][1,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[C,0])]*r[A][0][12,1]*r[B][33][1,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[B,1])]*r[A][0][12,1]*r[B][15][1,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[B,0])]*r[A][0][12,1]*r[B][33][1,2]*r[C][1][10,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(C,8)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[C,0])]*r[A][2][14,1]*r[B][30][0,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[C,0])]*r[A][2][14,1]*r[B][48][0,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[B,1])]*r[A][2][14,1]*r[B][30][0,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[B,0])]*r[A][2][14,1]*r[B][48][0,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][30][0,2]*r[C][3][8,3]
    hv += g[dei(p[B,0],p[B,1],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][15][0,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][48][0,2]*r[C][3][8,3]
    hv += g[dei(p[B,1],p[B,0],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][33][0,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][30][0,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][48][0,2]*r[C][3][8,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B1C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,1),(C,8)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[C,0])]*r[A][2][14,1]*r[B][30][1,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[C,0])]*r[A][2][14,1]*r[B][48][1,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[B,1])]*r[A][2][14,1]*r[B][30][1,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[B,0])]*r[A][2][14,1]*r[B][48][1,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][30][1,2]*r[C][3][8,3]
    hv += g[dei(p[B,0],p[B,1],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][15][1,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][48][1,2]*r[C][3][8,3]
    hv += g[dei(p[B,1],p[B,0],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][33][1,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][30][1,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][48][1,2]*r[C][3][8,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[C,1])]*r[A][0][12,1]*r[B][15][0,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[C,1])]*r[A][0][12,1]*r[B][33][0,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[B,1])]*r[A][0][12,1]*r[B][15][0,2]*r[C][5][9,3]
    hv += g[dei(p[A,0],p[C,1],p[B,0],p[B,1])]*r[A][0][12,1]*r[B][30][0,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[B,0])]*r[A][0][12,1]*r[B][33][0,2]*r[C][5][9,3]
    hv += g[dei(p[A,0],p[C,1],p[B,1],p[B,0])]*r[A][0][12,1]*r[B][48][0,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[C,1])]*r[A][0][12,1]*r[B][15][0,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[C,1])]*r[A][0][12,1]*r[B][33][0,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[B,1])]*r[A][0][12,1]*r[B][15][0,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[B,0])]*r[A][0][12,1]*r[B][33][0,2]*r[C][5][9,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12B1C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,1),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[C,1])]*r[A][0][12,1]*r[B][15][1,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[C,1])]*r[A][0][12,1]*r[B][33][1,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[B,1])]*r[A][0][12,1]*r[B][15][1,2]*r[C][5][9,3]
    hv += g[dei(p[A,0],p[C,1],p[B,0],p[B,1])]*r[A][0][12,1]*r[B][30][1,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[B,0])]*r[A][0][12,1]*r[B][33][1,2]*r[C][5][9,3]
    hv += g[dei(p[A,0],p[C,1],p[B,1],p[B,0])]*r[A][0][12,1]*r[B][48][1,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[C,1])]*r[A][0][12,1]*r[B][15][1,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[C,1])]*r[A][0][12,1]*r[B][33][1,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[B,1])]*r[A][0][12,1]*r[B][15][1,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[B,0])]*r[A][0][12,1]*r[B][33][1,2]*r[C][5][9,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(C,7)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[C,1])]*r[A][2][14,1]*r[B][30][0,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[C,1])]*r[A][2][14,1]*r[B][48][0,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[B,1])]*r[A][2][14,1]*r[B][30][0,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[B,0])]*r[A][2][14,1]*r[B][48][0,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[C,1])]*r[A][2][14,1]*r[B][30][0,2]*r[C][7][7,3]
    hv += g[dei(p[B,0],p[B,1],p[A,0],p[C,1])]*r[A][2][14,1]*r[B][15][0,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[C,1])]*r[A][2][14,1]*r[B][48][0,2]*r[C][7][7,3]
    hv += g[dei(p[B,1],p[B,0],p[A,0],p[C,1])]*r[A][2][14,1]*r[B][33][0,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][30][0,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][48][0,2]*r[C][7][7,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B1C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,1),(C,7)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[C,1])]*r[A][2][14,1]*r[B][30][1,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[C,1])]*r[A][2][14,1]*r[B][48][1,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[B,1])]*r[A][2][14,1]*r[B][30][1,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[B,0])]*r[A][2][14,1]*r[B][48][1,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[C,1])]*r[A][2][14,1]*r[B][30][1,2]*r[C][7][7,3]
    hv += g[dei(p[B,0],p[B,1],p[A,0],p[C,1])]*r[A][2][14,1]*r[B][15][1,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[C,1])]*r[A][2][14,1]*r[B][48][1,2]*r[C][7][7,3]
    hv += g[dei(p[B,1],p[B,0],p[A,0],p[C,1])]*r[A][2][14,1]*r[B][33][1,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][30][1,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][48][1,2]*r[C][7][7,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11B3C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,3),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[C,0])]*r[A][4][11,1]*r[B][9][3,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[C,0])]*r[A][4][11,1]*r[B][39][3,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[B,0])]*r[A][4][11,1]*r[B][9][3,2]*r[C][1][10,3]
    hv += g[dei(p[A,1],p[C,0],p[B,0],p[B,0])]*r[A][4][11,1]*r[B][24][3,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[B,1])]*r[A][4][11,1]*r[B][39][3,2]*r[C][1][10,3]
    hv += g[dei(p[A,1],p[C,0],p[B,1],p[B,1])]*r[A][4][11,1]*r[B][54][3,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[C,0])]*r[A][4][11,1]*r[B][9][3,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[C,0])]*r[A][4][11,1]*r[B][39][3,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[B,0])]*r[A][4][11,1]*r[B][9][3,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[B,1])]*r[A][4][11,1]*r[B][39][3,2]*r[C][1][10,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B3C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,3),(C,8)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[C,0])]*r[A][6][13,1]*r[B][24][3,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[C,0])]*r[A][6][13,1]*r[B][54][3,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[B,0])]*r[A][6][13,1]*r[B][24][3,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[B,1])]*r[A][6][13,1]*r[B][54][3,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][24][3,2]*r[C][3][8,3]
    hv += g[dei(p[B,0],p[B,0],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][9][3,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][54][3,2]*r[C][3][8,3]
    hv += g[dei(p[B,1],p[B,1],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][39][3,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][24][3,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][54][3,2]*r[C][3][8,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11B5C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,5),(C,8)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[A,1],p[B,0],p[B,0],p[C,0])]*r[A][4][11,1]*r[B][21][5,2]*r[C][3][8,3]
    hv += -1*g[dei(p[A,1],p[B,1],p[B,1],p[C,0])]*r[A][4][11,1]*r[B][51][5,2]*r[C][3][8,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11B3C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,3),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[C,1])]*r[A][4][11,1]*r[B][9][3,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[C,1])]*r[A][4][11,1]*r[B][39][3,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[B,0])]*r[A][4][11,1]*r[B][9][3,2]*r[C][5][9,3]
    hv += g[dei(p[A,1],p[C,1],p[B,0],p[B,0])]*r[A][4][11,1]*r[B][24][3,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[B,1])]*r[A][4][11,1]*r[B][39][3,2]*r[C][5][9,3]
    hv += g[dei(p[A,1],p[C,1],p[B,1],p[B,1])]*r[A][4][11,1]*r[B][54][3,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[C,1])]*r[A][4][11,1]*r[B][9][3,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[C,1])]*r[A][4][11,1]*r[B][39][3,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[B,0])]*r[A][4][11,1]*r[B][9][3,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[B,1])]*r[A][4][11,1]*r[B][39][3,2]*r[C][5][9,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B3C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,3),(C,7)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[C,1])]*r[A][6][13,1]*r[B][24][3,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[C,1])]*r[A][6][13,1]*r[B][54][3,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[B,0])]*r[A][6][13,1]*r[B][24][3,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[B,1])]*r[A][6][13,1]*r[B][54][3,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[C,1])]*r[A][6][13,1]*r[B][24][3,2]*r[C][7][7,3]
    hv += g[dei(p[B,0],p[B,0],p[A,1],p[C,1])]*r[A][6][13,1]*r[B][9][3,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[C,1])]*r[A][6][13,1]*r[B][54][3,2]*r[C][7][7,3]
    hv += g[dei(p[B,1],p[B,1],p[A,1],p[C,1])]*r[A][6][13,1]*r[B][39][3,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][24][3,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][54][3,2]*r[C][7][7,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11B5C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,5),(C,7)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[A,1],p[B,0],p[B,0],p[C,1])]*r[A][4][11,1]*r[B][21][5,2]*r[C][7][7,3]
    hv += -1*g[dei(p[A,1],p[B,1],p[B,1],p[C,1])]*r[A][4][11,1]*r[B][51][5,2]*r[C][7][7,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[C,0])]*r[A][4][11,1]*r[B][15][0,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[C,0])]*r[A][4][11,1]*r[B][33][0,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[B,1])]*r[A][4][11,1]*r[B][15][0,2]*r[C][1][10,3]
    hv += g[dei(p[A,1],p[C,0],p[B,0],p[B,1])]*r[A][4][11,1]*r[B][30][0,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[B,0])]*r[A][4][11,1]*r[B][33][0,2]*r[C][1][10,3]
    hv += g[dei(p[A,1],p[C,0],p[B,1],p[B,0])]*r[A][4][11,1]*r[B][48][0,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[C,0])]*r[A][4][11,1]*r[B][15][0,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[C,0])]*r[A][4][11,1]*r[B][33][0,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[B,1])]*r[A][4][11,1]*r[B][15][0,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[B,0])]*r[A][4][11,1]*r[B][33][0,2]*r[C][1][10,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11B1C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,1),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[C,0])]*r[A][4][11,1]*r[B][15][1,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[C,0])]*r[A][4][11,1]*r[B][33][1,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[B,1])]*r[A][4][11,1]*r[B][15][1,2]*r[C][1][10,3]
    hv += g[dei(p[A,1],p[C,0],p[B,0],p[B,1])]*r[A][4][11,1]*r[B][30][1,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[B,0])]*r[A][4][11,1]*r[B][33][1,2]*r[C][1][10,3]
    hv += g[dei(p[A,1],p[C,0],p[B,1],p[B,0])]*r[A][4][11,1]*r[B][48][1,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[C,0])]*r[A][4][11,1]*r[B][15][1,2]*r[C][1][10,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[C,0])]*r[A][4][11,1]*r[B][33][1,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[B,1])]*r[A][4][11,1]*r[B][15][1,2]*r[C][1][10,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[B,0])]*r[A][4][11,1]*r[B][33][1,2]*r[C][1][10,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(C,8)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[C,0])]*r[A][6][13,1]*r[B][30][0,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[C,0])]*r[A][6][13,1]*r[B][48][0,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[B,1])]*r[A][6][13,1]*r[B][30][0,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[B,0])]*r[A][6][13,1]*r[B][48][0,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][30][0,2]*r[C][3][8,3]
    hv += g[dei(p[B,0],p[B,1],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][15][0,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][48][0,2]*r[C][3][8,3]
    hv += g[dei(p[B,1],p[B,0],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][33][0,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][30][0,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][48][0,2]*r[C][3][8,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B1C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,1),(C,8)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[C,0])]*r[A][6][13,1]*r[B][30][1,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[C,0])]*r[A][6][13,1]*r[B][48][1,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[B,1])]*r[A][6][13,1]*r[B][30][1,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[B,0])]*r[A][6][13,1]*r[B][48][1,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][30][1,2]*r[C][3][8,3]
    hv += g[dei(p[B,0],p[B,1],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][15][1,2]*r[C][3][8,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][48][1,2]*r[C][3][8,3]
    hv += g[dei(p[B,1],p[B,0],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][33][1,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][30][1,2]*r[C][3][8,3]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][48][1,2]*r[C][3][8,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[C,1])]*r[A][4][11,1]*r[B][15][0,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[C,1])]*r[A][4][11,1]*r[B][33][0,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[B,1])]*r[A][4][11,1]*r[B][15][0,2]*r[C][5][9,3]
    hv += g[dei(p[A,1],p[C,1],p[B,0],p[B,1])]*r[A][4][11,1]*r[B][30][0,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[B,0])]*r[A][4][11,1]*r[B][33][0,2]*r[C][5][9,3]
    hv += g[dei(p[A,1],p[C,1],p[B,1],p[B,0])]*r[A][4][11,1]*r[B][48][0,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[C,1])]*r[A][4][11,1]*r[B][15][0,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[C,1])]*r[A][4][11,1]*r[B][33][0,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[B,1])]*r[A][4][11,1]*r[B][15][0,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[B,0])]*r[A][4][11,1]*r[B][33][0,2]*r[C][5][9,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11B1C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,1),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[C,1])]*r[A][4][11,1]*r[B][15][1,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[C,1])]*r[A][4][11,1]*r[B][33][1,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[B,1])]*r[A][4][11,1]*r[B][15][1,2]*r[C][5][9,3]
    hv += g[dei(p[A,1],p[C,1],p[B,0],p[B,1])]*r[A][4][11,1]*r[B][30][1,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[B,0])]*r[A][4][11,1]*r[B][33][1,2]*r[C][5][9,3]
    hv += g[dei(p[A,1],p[C,1],p[B,1],p[B,0])]*r[A][4][11,1]*r[B][48][1,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[C,1])]*r[A][4][11,1]*r[B][15][1,2]*r[C][5][9,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[C,1])]*r[A][4][11,1]*r[B][33][1,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[B,1])]*r[A][4][11,1]*r[B][15][1,2]*r[C][5][9,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[B,0])]*r[A][4][11,1]*r[B][33][1,2]*r[C][5][9,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(C,7)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[C,1])]*r[A][6][13,1]*r[B][30][0,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[C,1])]*r[A][6][13,1]*r[B][48][0,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[B,1])]*r[A][6][13,1]*r[B][30][0,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[B,0])]*r[A][6][13,1]*r[B][48][0,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[C,1])]*r[A][6][13,1]*r[B][30][0,2]*r[C][7][7,3]
    hv += g[dei(p[B,0],p[B,1],p[A,1],p[C,1])]*r[A][6][13,1]*r[B][15][0,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[C,1])]*r[A][6][13,1]*r[B][48][0,2]*r[C][7][7,3]
    hv += g[dei(p[B,1],p[B,0],p[A,1],p[C,1])]*r[A][6][13,1]*r[B][33][0,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][30][0,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][48][0,2]*r[C][7][7,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B1C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,1),(C,7)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[C,1])]*r[A][6][13,1]*r[B][30][1,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[C,1])]*r[A][6][13,1]*r[B][48][1,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[B,1])]*r[A][6][13,1]*r[B][30][1,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[B,0])]*r[A][6][13,1]*r[B][48][1,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[C,1])]*r[A][6][13,1]*r[B][30][1,2]*r[C][7][7,3]
    hv += g[dei(p[B,0],p[B,1],p[A,1],p[C,1])]*r[A][6][13,1]*r[B][15][1,2]*r[C][7][7,3]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[C,1])]*r[A][6][13,1]*r[B][48][1,2]*r[C][7][7,3]
    hv += g[dei(p[B,1],p[B,0],p[A,1],p[C,1])]*r[A][6][13,1]*r[B][33][1,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][30][1,2]*r[C][7][7,3]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][48][1,2]*r[C][7][7,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A4B13C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,4),(B,13),(C,10)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[A,0],p[C,0],p[B,0],p[A,1])]*r[A][18][4,1]*r[B][2][13,2]*r[C][1][10,3]
    hv += -1*g[dei(p[A,1],p[C,0],p[B,0],p[A,0])]*r[A][36][4,1]*r[B][2][13,2]*r[C][1][10,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A4B13C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,4),(B,13),(C,9)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[A,0],p[C,1],p[B,0],p[A,1])]*r[A][18][4,1]*r[B][2][13,2]*r[C][5][9,3]
    hv += -1*g[dei(p[A,1],p[C,1],p[B,0],p[A,0])]*r[A][36][4,1]*r[B][2][13,2]*r[C][5][9,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A4B14C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,4),(B,14),(C,10)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[A,0],p[C,0],p[B,1],p[A,1])]*r[A][18][4,1]*r[B][6][14,2]*r[C][1][10,3]
    hv += -1*g[dei(p[A,1],p[C,0],p[B,1],p[A,0])]*r[A][36][4,1]*r[B][6][14,2]*r[C][1][10,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A4B14C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,4),(B,14),(C,9)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[A,0],p[C,1],p[B,1],p[A,1])]*r[A][18][4,1]*r[B][6][14,2]*r[C][5][9,3]
    hv += -1*g[dei(p[A,1],p[C,1],p[B,1],p[A,0])]*r[A][36][4,1]*r[B][6][14,2]*r[C][5][9,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12B13C6(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,13),(C,6)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[A,0],p[C,0],p[B,0],p[C,1])]*r[A][0][12,1]*r[B][2][13,2]*r[C][46][6,3]
    hv += g[dei(p[A,0],p[C,1],p[B,0],p[C,0])]*r[A][0][12,1]*r[B][2][13,2]*r[C][28][6,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12B14C6(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,14),(C,6)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[A,0],p[C,0],p[B,1],p[C,1])]*r[A][0][12,1]*r[B][6][14,2]*r[C][46][6,3]
    hv += g[dei(p[A,0],p[C,1],p[B,1],p[C,0])]*r[A][0][12,1]*r[B][6][14,2]*r[C][28][6,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11B13C6(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,13),(C,6)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[A,1],p[C,0],p[B,0],p[C,1])]*r[A][4][11,1]*r[B][2][13,2]*r[C][46][6,3]
    hv += g[dei(p[A,1],p[C,1],p[B,0],p[C,0])]*r[A][4][11,1]*r[B][2][13,2]*r[C][28][6,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11B14C6(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,14),(C,6)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[A,1],p[C,0],p[B,1],p[C,1])]*r[A][4][11,1]*r[B][6][14,2]*r[C][46][6,3]
    hv += g[dei(p[A,1],p[C,1],p[B,1],p[C,0])]*r[A][4][11,1]*r[B][6][14,2]*r[C][28][6,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _B10C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(B,10),(C,11)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[C,0],p[B,0])]*r[A][9][0,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[C,0],p[B,0])]*r[A][39][0,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,0],p[A,0])]*r[A][9][0,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,0],p[A,1])]*r[A][39][0,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[A,0],p[B,0])]*r[A][9][0,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[A,1],p[B,0])]*r[A][39][0,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[B,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[B,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][1][10,2]*r[C][0][11,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _B8C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(B,8),(C,13)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[C,0],p[B,0])]*r[A][24][0,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += -1*g[dei(p[A,0],p[A,0],p[C,0],p[B,0])]*r[A][9][0,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[C,0],p[B,0])]*r[A][54][0,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += -1*g[dei(p[A,1],p[A,1],p[C,0],p[B,0])]*r[A][39][0,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,0],p[A,0])]*r[A][24][0,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,0],p[A,1])]*r[A][54][0,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[A,0],p[B,0])]*r[A][24][0,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[A,1],p[B,0])]*r[A][54][0,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][3][8,2]*r[C][2][13,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _B9C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(B,9),(C,11)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[C,0],p[B,1])]*r[A][9][0,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[C,0],p[B,1])]*r[A][39][0,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,0],p[A,0])]*r[A][9][0,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,0],p[A,1])]*r[A][39][0,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[A,0],p[B,1])]*r[A][9][0,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[A,1],p[B,1])]*r[A][39][0,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[B,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[B,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][5][9,2]*r[C][0][11,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _B7C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(B,7),(C,13)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[C,0],p[B,1])]*r[A][24][0,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += -1*g[dei(p[A,0],p[A,0],p[C,0],p[B,1])]*r[A][9][0,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[C,0],p[B,1])]*r[A][54][0,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += -1*g[dei(p[A,1],p[A,1],p[C,0],p[B,1])]*r[A][39][0,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,0],p[A,0])]*r[A][24][0,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,0],p[A,1])]*r[A][54][0,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[A,0],p[B,1])]*r[A][24][0,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[A,1],p[B,1])]*r[A][54][0,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][7][7,2]*r[C][2][13,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A2B10C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(B,10),(C,11)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[C,0],p[B,0])]*r[A][15][2,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[C,0],p[B,0])]*r[A][33][2,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,0],p[A,1])]*r[A][15][2,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,0],p[A,0])]*r[A][33][2,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[A,0],p[B,0])]*r[A][15][2,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[A,1],p[B,0])]*r[A][33][2,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[B,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[B,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][1][10,2]*r[C][0][11,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A3B10C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,10),(C,11)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[C,0],p[B,0])]*r[A][15][3,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[C,0],p[B,0])]*r[A][33][3,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,0],p[A,1])]*r[A][15][3,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,0],p[A,0])]*r[A][33][3,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[A,0],p[B,0])]*r[A][15][3,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[A,1],p[B,0])]*r[A][33][3,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[B,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][1][10,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[B,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][1][10,2]*r[C][0][11,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A2B8C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(B,8),(C,13)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[C,0],p[B,0])]*r[A][30][2,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += -1*g[dei(p[A,0],p[A,1],p[C,0],p[B,0])]*r[A][15][2,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[C,0],p[B,0])]*r[A][48][2,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += -1*g[dei(p[A,1],p[A,0],p[C,0],p[B,0])]*r[A][33][2,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,0],p[A,1])]*r[A][30][2,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,0],p[A,0])]*r[A][48][2,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[A,0],p[B,0])]*r[A][30][2,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[A,1],p[B,0])]*r[A][48][2,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][3][8,2]*r[C][2][13,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A3B8C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,8),(C,13)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[C,0],p[B,0])]*r[A][30][3,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += -1*g[dei(p[A,0],p[A,1],p[C,0],p[B,0])]*r[A][15][3,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[C,0],p[B,0])]*r[A][48][3,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += -1*g[dei(p[A,1],p[A,0],p[C,0],p[B,0])]*r[A][33][3,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,0],p[A,1])]*r[A][30][3,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,0],p[A,0])]*r[A][48][3,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[A,0],p[B,0])]*r[A][30][3,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[A,1],p[B,0])]*r[A][48][3,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][3][8,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][3][8,2]*r[C][2][13,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A2B9C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(B,9),(C,11)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[C,0],p[B,1])]*r[A][15][2,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[C,0],p[B,1])]*r[A][33][2,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,0],p[A,1])]*r[A][15][2,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,0],p[A,0])]*r[A][33][2,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[A,0],p[B,1])]*r[A][15][2,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[A,1],p[B,1])]*r[A][33][2,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[B,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[B,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][5][9,2]*r[C][0][11,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A3B9C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,9),(C,11)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[C,0],p[B,1])]*r[A][15][3,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[C,0],p[B,1])]*r[A][33][3,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,0],p[A,1])]*r[A][15][3,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,0],p[A,0])]*r[A][33][3,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[A,0],p[B,1])]*r[A][15][3,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[A,1],p[B,1])]*r[A][33][3,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[B,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][5][9,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[B,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][5][9,2]*r[C][0][11,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A2B7C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(B,7),(C,13)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[C,0],p[B,1])]*r[A][30][2,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += -1*g[dei(p[A,0],p[A,1],p[C,0],p[B,1])]*r[A][15][2,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[C,0],p[B,1])]*r[A][48][2,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += -1*g[dei(p[A,1],p[A,0],p[C,0],p[B,1])]*r[A][33][2,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,0],p[A,1])]*r[A][30][2,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,0],p[A,0])]*r[A][48][2,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[A,0],p[B,1])]*r[A][30][2,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[A,1],p[B,1])]*r[A][48][2,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][7][7,2]*r[C][2][13,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A3B7C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,7),(C,13)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[C,0],p[B,1])]*r[A][30][3,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += -1*g[dei(p[A,0],p[A,1],p[C,0],p[B,1])]*r[A][15][3,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[C,0],p[B,1])]*r[A][48][3,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += -1*g[dei(p[A,1],p[A,0],p[C,0],p[B,1])]*r[A][33][3,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,0],p[A,1])]*r[A][30][3,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,0],p[A,0])]*r[A][48][3,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[A,0],p[B,1])]*r[A][30][3,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[A,1],p[B,1])]*r[A][48][3,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][7][7,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][7][7,2]*r[C][2][13,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _B10C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(B,10),(C,12)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[C,1],p[B,0])]*r[A][9][0,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[C,1],p[B,0])]*r[A][39][0,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,1],p[A,0])]*r[A][9][0,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,1],p[A,1])]*r[A][39][0,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[A,0],p[B,0])]*r[A][9][0,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[A,1],p[B,0])]*r[A][39][0,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[B,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[B,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][1][10,2]*r[C][4][12,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _B8C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(B,8),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[C,1],p[B,0])]*r[A][24][0,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += -1*g[dei(p[A,0],p[A,0],p[C,1],p[B,0])]*r[A][9][0,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[C,1],p[B,0])]*r[A][54][0,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += -1*g[dei(p[A,1],p[A,1],p[C,1],p[B,0])]*r[A][39][0,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,1],p[A,0])]*r[A][24][0,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,1],p[A,1])]*r[A][54][0,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[A,0],p[B,0])]*r[A][24][0,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[A,1],p[B,0])]*r[A][54][0,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][3][8,2]*r[C][6][14,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _B9C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(B,9),(C,12)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[C,1],p[B,1])]*r[A][9][0,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[C,1],p[B,1])]*r[A][39][0,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,1],p[A,0])]*r[A][9][0,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,1],p[A,1])]*r[A][39][0,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[A,0],p[B,1])]*r[A][9][0,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[A,1],p[B,1])]*r[A][39][0,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,0],p[A,0])]*r[A][9][0,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[B,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,1],p[A,1])]*r[A][39][0,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[B,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][5][9,2]*r[C][4][12,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _B7C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(B,7),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[C,1],p[B,1])]*r[A][24][0,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += -1*g[dei(p[A,0],p[A,0],p[C,1],p[B,1])]*r[A][9][0,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[C,1],p[B,1])]*r[A][54][0,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += -1*g[dei(p[A,1],p[A,1],p[C,1],p[B,1])]*r[A][39][0,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,1],p[A,0])]*r[A][24][0,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,1],p[A,1])]*r[A][54][0,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[A,0],p[B,1])]*r[A][24][0,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[A,1],p[B,1])]*r[A][54][0,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,0],p[A,0])]*r[A][24][0,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,1],p[A,1])]*r[A][54][0,1]*r[B][7][7,2]*r[C][6][14,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A2B10C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(B,10),(C,12)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[C,1],p[B,0])]*r[A][15][2,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[C,1],p[B,0])]*r[A][33][2,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,1],p[A,1])]*r[A][15][2,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,1],p[A,0])]*r[A][33][2,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[A,0],p[B,0])]*r[A][15][2,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[A,1],p[B,0])]*r[A][33][2,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[B,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[B,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][1][10,2]*r[C][4][12,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A3B10C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,10),(C,12)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[C,1],p[B,0])]*r[A][15][3,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[C,1],p[B,0])]*r[A][33][3,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,1],p[A,1])]*r[A][15][3,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,1],p[A,0])]*r[A][33][3,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[A,0],p[B,0])]*r[A][15][3,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[A,1],p[B,0])]*r[A][33][3,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[B,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][1][10,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[B,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][1][10,2]*r[C][4][12,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A2B8C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(B,8),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[C,1],p[B,0])]*r[A][30][2,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += -1*g[dei(p[A,0],p[A,1],p[C,1],p[B,0])]*r[A][15][2,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[C,1],p[B,0])]*r[A][48][2,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += -1*g[dei(p[A,1],p[A,0],p[C,1],p[B,0])]*r[A][33][2,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,1],p[A,1])]*r[A][30][2,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,1],p[A,0])]*r[A][48][2,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[A,0],p[B,0])]*r[A][30][2,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[A,1],p[B,0])]*r[A][48][2,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][3][8,2]*r[C][6][14,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A3B8C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,8),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[C,1],p[B,0])]*r[A][30][3,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += -1*g[dei(p[A,0],p[A,1],p[C,1],p[B,0])]*r[A][15][3,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[C,1],p[B,0])]*r[A][48][3,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += -1*g[dei(p[A,1],p[A,0],p[C,1],p[B,0])]*r[A][33][3,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,1],p[A,1])]*r[A][30][3,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,1],p[A,0])]*r[A][48][3,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[A,0],p[B,0])]*r[A][30][3,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[A,1],p[B,0])]*r[A][48][3,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][3][8,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][3][8,2]*r[C][6][14,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A2B9C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(B,9),(C,12)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[C,1],p[B,1])]*r[A][15][2,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[C,1],p[B,1])]*r[A][33][2,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,1],p[A,1])]*r[A][15][2,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,1],p[A,0])]*r[A][33][2,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[A,0],p[B,1])]*r[A][15][2,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[A,1],p[B,1])]*r[A][33][2,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,0],p[A,1])]*r[A][15][2,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[B,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,1],p[A,0])]*r[A][33][2,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[B,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][5][9,2]*r[C][4][12,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A3B9C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,9),(C,12)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[C,1],p[B,1])]*r[A][15][3,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[C,1],p[B,1])]*r[A][33][3,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,1],p[A,1])]*r[A][15][3,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,1],p[A,0])]*r[A][33][3,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[A,0],p[B,1])]*r[A][15][3,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[A,1],p[B,1])]*r[A][33][3,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,0],p[A,1])]*r[A][15][3,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[B,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,1],p[A,0])]*r[A][33][3,1]*r[B][5][9,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[B,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][5][9,2]*r[C][4][12,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A2B7C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(B,7),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[C,1],p[B,1])]*r[A][30][2,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += -1*g[dei(p[A,0],p[A,1],p[C,1],p[B,1])]*r[A][15][2,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[C,1],p[B,1])]*r[A][48][2,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += -1*g[dei(p[A,1],p[A,0],p[C,1],p[B,1])]*r[A][33][2,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,1],p[A,1])]*r[A][30][2,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,1],p[A,0])]*r[A][48][2,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[A,0],p[B,1])]*r[A][30][2,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[A,1],p[B,1])]*r[A][48][2,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,0],p[A,1])]*r[A][30][2,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,1],p[A,0])]*r[A][48][2,1]*r[B][7][7,2]*r[C][6][14,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A3B7C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,7),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[C,1],p[B,1])]*r[A][30][3,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += -1*g[dei(p[A,0],p[A,1],p[C,1],p[B,1])]*r[A][15][3,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[C,1],p[B,1])]*r[A][48][3,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += -1*g[dei(p[A,1],p[A,0],p[C,1],p[B,1])]*r[A][33][3,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,1],p[A,1])]*r[A][30][3,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,1],p[A,0])]*r[A][48][3,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[A,0],p[B,1])]*r[A][30][3,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[A,1],p[B,1])]*r[A][48][3,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,0],p[A,1])]*r[A][30][3,1]*r[B][7][7,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,1],p[A,0])]*r[A][48][3,1]*r[B][7][7,2]*r[C][6][14,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A4B10C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,4),(B,10),(C,13)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[A,0],p[B,0],p[C,0],p[A,1])]*r[A][18][4,1]*r[B][1][10,2]*r[C][2][13,3]
    hv += g[dei(p[A,1],p[B,0],p[C,0],p[A,0])]*r[A][36][4,1]*r[B][1][10,2]*r[C][2][13,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A4B9C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,4),(B,9),(C,13)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[A,0],p[B,1],p[C,0],p[A,1])]*r[A][18][4,1]*r[B][5][9,2]*r[C][2][13,3]
    hv += g[dei(p[A,1],p[B,1],p[C,0],p[A,0])]*r[A][36][4,1]*r[B][5][9,2]*r[C][2][13,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A4B10C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,4),(B,10),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[A,0],p[B,0],p[C,1],p[A,1])]*r[A][18][4,1]*r[B][1][10,2]*r[C][6][14,3]
    hv += g[dei(p[A,1],p[B,0],p[C,1],p[A,0])]*r[A][36][4,1]*r[B][1][10,2]*r[C][6][14,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A4B9C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,4),(B,9),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[A,0],p[B,1],p[C,1],p[A,1])]*r[A][18][4,1]*r[B][5][9,2]*r[C][6][14,3]
    hv += g[dei(p[A,1],p[B,1],p[C,1],p[A,0])]*r[A][36][4,1]*r[B][5][9,2]*r[C][6][14,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12B6C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,6),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[A,0],p[B,0],p[C,0],p[B,1])]*r[A][0][12,1]*r[B][46][6,2]*r[C][2][13,3]
    hv += g[dei(p[A,0],p[B,1],p[C,0],p[B,0])]*r[A][0][12,1]*r[B][28][6,2]*r[C][2][13,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12B6C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,6),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[A,0],p[B,0],p[C,1],p[B,1])]*r[A][0][12,1]*r[B][46][6,2]*r[C][6][14,3]
    hv += g[dei(p[A,0],p[B,1],p[C,1],p[B,0])]*r[A][0][12,1]*r[B][28][6,2]*r[C][6][14,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11B6C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,6),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[A,1],p[B,0],p[C,0],p[B,1])]*r[A][4][11,1]*r[B][46][6,2]*r[C][2][13,3]
    hv += g[dei(p[A,1],p[B,1],p[C,0],p[B,0])]*r[A][4][11,1]*r[B][28][6,2]*r[C][2][13,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11B6C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,6),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[A,1],p[B,0],p[C,1],p[B,1])]*r[A][4][11,1]*r[B][46][6,2]*r[C][6][14,3]
    hv += g[dei(p[A,1],p[B,1],p[C,1],p[B,0])]*r[A][4][11,1]*r[B][28][6,2]*r[C][6][14,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12B10C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,10),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,0],p[C,0])]*r[A][0][12,1]*r[B][1][10,2]*r[C][9][2,3]
    hv += g[dei(p[A,0],p[B,0],p[C,0],p[C,0])]*r[A][0][12,1]*r[B][1][10,2]*r[C][24][2,3]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,1],p[C,1])]*r[A][0][12,1]*r[B][1][10,2]*r[C][39][2,3]
    hv += g[dei(p[A,0],p[B,0],p[C,1],p[C,1])]*r[A][0][12,1]*r[B][1][10,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[B,0])]*r[A][0][12,1]*r[B][1][10,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[B,0])]*r[A][0][12,1]*r[B][1][10,2]*r[C][39][2,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,0],p[C,0])]*r[A][0][12,1]*r[B][1][10,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,0],p[C,1])]*r[A][0][12,1]*r[B][1][10,2]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[B,0])]*r[A][0][12,1]*r[B][1][10,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[B,0])]*r[A][0][12,1]*r[B][1][10,2]*r[C][39][2,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B8C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,8),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,0],p[C,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][24][2,3]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,1],p[C,1])]*r[A][2][14,1]*r[B][3][8,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[B,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[B,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,0],p[C,1])]*r[A][2][14,1]*r[B][3][8,2]*r[C][54][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][24][2,3]
    hv += g[dei(p[C,0],p[C,0],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][54][2,3]
    hv += g[dei(p[C,1],p[C,1],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][39][2,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12B10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,10)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,0],p[C,1])]*r[A][0][12,1]*r[B][1][10,2]*r[C][15][0,3]
    hv += g[dei(p[A,0],p[B,0],p[C,0],p[C,1])]*r[A][0][12,1]*r[B][1][10,2]*r[C][30][0,3]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,1],p[C,0])]*r[A][0][12,1]*r[B][1][10,2]*r[C][33][0,3]
    hv += g[dei(p[A,0],p[B,0],p[C,1],p[C,0])]*r[A][0][12,1]*r[B][1][10,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[B,0])]*r[A][0][12,1]*r[B][1][10,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[B,0])]*r[A][0][12,1]*r[B][1][10,2]*r[C][33][0,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,0],p[C,1])]*r[A][0][12,1]*r[B][1][10,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,0],p[C,0])]*r[A][0][12,1]*r[B][1][10,2]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[B,0])]*r[A][0][12,1]*r[B][1][10,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[B,0])]*r[A][0][12,1]*r[B][1][10,2]*r[C][33][0,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12B10C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,10),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,0],p[C,1])]*r[A][0][12,1]*r[B][1][10,2]*r[C][15][1,3]
    hv += g[dei(p[A,0],p[B,0],p[C,0],p[C,1])]*r[A][0][12,1]*r[B][1][10,2]*r[C][30][1,3]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,1],p[C,0])]*r[A][0][12,1]*r[B][1][10,2]*r[C][33][1,3]
    hv += g[dei(p[A,0],p[B,0],p[C,1],p[C,0])]*r[A][0][12,1]*r[B][1][10,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[B,0])]*r[A][0][12,1]*r[B][1][10,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[B,0])]*r[A][0][12,1]*r[B][1][10,2]*r[C][33][1,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,0],p[C,1])]*r[A][0][12,1]*r[B][1][10,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,0],p[C,0])]*r[A][0][12,1]*r[B][1][10,2]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[B,0])]*r[A][0][12,1]*r[B][1][10,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[B,0])]*r[A][0][12,1]*r[B][1][10,2]*r[C][33][1,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,8)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,0],p[C,1])]*r[A][2][14,1]*r[B][3][8,2]*r[C][30][0,3]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,1],p[C,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[B,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[B,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,0],p[C,1])]*r[A][2][14,1]*r[B][3][8,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][48][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][30][0,3]
    hv += g[dei(p[C,0],p[C,1],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][48][0,3]
    hv += g[dei(p[C,1],p[C,0],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][33][0,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B8C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,8),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,0],p[C,1])]*r[A][2][14,1]*r[B][3][8,2]*r[C][30][1,3]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,1],p[C,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[B,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[B,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,0],p[C,1])]*r[A][2][14,1]*r[B][3][8,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][48][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][30][1,3]
    hv += g[dei(p[C,0],p[C,1],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][48][1,3]
    hv += g[dei(p[C,1],p[C,0],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][3][8,2]*r[C][33][1,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12B9C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,9),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,0],p[C,0])]*r[A][0][12,1]*r[B][5][9,2]*r[C][9][2,3]
    hv += g[dei(p[A,0],p[B,1],p[C,0],p[C,0])]*r[A][0][12,1]*r[B][5][9,2]*r[C][24][2,3]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,1],p[C,1])]*r[A][0][12,1]*r[B][5][9,2]*r[C][39][2,3]
    hv += g[dei(p[A,0],p[B,1],p[C,1],p[C,1])]*r[A][0][12,1]*r[B][5][9,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[B,1])]*r[A][0][12,1]*r[B][5][9,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[B,1])]*r[A][0][12,1]*r[B][5][9,2]*r[C][39][2,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,0],p[C,0])]*r[A][0][12,1]*r[B][5][9,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,0],p[C,1])]*r[A][0][12,1]*r[B][5][9,2]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[B,1])]*r[A][0][12,1]*r[B][5][9,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[B,1])]*r[A][0][12,1]*r[B][5][9,2]*r[C][39][2,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B7C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,7),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,0],p[C,0])]*r[A][2][14,1]*r[B][7][7,2]*r[C][24][2,3]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,1],p[C,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[B,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[B,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][7][7,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,0],p[C,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][54][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][24][2,3]
    hv += g[dei(p[C,0],p[C,0],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][54][2,3]
    hv += g[dei(p[C,1],p[C,1],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][39][2,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12B9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,9)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,0],p[C,1])]*r[A][0][12,1]*r[B][5][9,2]*r[C][15][0,3]
    hv += g[dei(p[A,0],p[B,1],p[C,0],p[C,1])]*r[A][0][12,1]*r[B][5][9,2]*r[C][30][0,3]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,1],p[C,0])]*r[A][0][12,1]*r[B][5][9,2]*r[C][33][0,3]
    hv += g[dei(p[A,0],p[B,1],p[C,1],p[C,0])]*r[A][0][12,1]*r[B][5][9,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[B,1])]*r[A][0][12,1]*r[B][5][9,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[B,1])]*r[A][0][12,1]*r[B][5][9,2]*r[C][33][0,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,0],p[C,1])]*r[A][0][12,1]*r[B][5][9,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,0],p[C,0])]*r[A][0][12,1]*r[B][5][9,2]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[B,1])]*r[A][0][12,1]*r[B][5][9,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[B,1])]*r[A][0][12,1]*r[B][5][9,2]*r[C][33][0,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12B9C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,9),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,0],p[C,1])]*r[A][0][12,1]*r[B][5][9,2]*r[C][15][1,3]
    hv += g[dei(p[A,0],p[B,1],p[C,0],p[C,1])]*r[A][0][12,1]*r[B][5][9,2]*r[C][30][1,3]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,1],p[C,0])]*r[A][0][12,1]*r[B][5][9,2]*r[C][33][1,3]
    hv += g[dei(p[A,0],p[B,1],p[C,1],p[C,0])]*r[A][0][12,1]*r[B][5][9,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[B,1])]*r[A][0][12,1]*r[B][5][9,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[B,1])]*r[A][0][12,1]*r[B][5][9,2]*r[C][33][1,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,0],p[C,1])]*r[A][0][12,1]*r[B][5][9,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,0],p[C,0])]*r[A][0][12,1]*r[B][5][9,2]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[B,1])]*r[A][0][12,1]*r[B][5][9,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[B,1])]*r[A][0][12,1]*r[B][5][9,2]*r[C][33][1,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,7)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,0],p[C,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][30][0,3]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,1],p[C,0])]*r[A][2][14,1]*r[B][7][7,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[B,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[B,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,0],p[C,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][7][7,2]*r[C][48][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][30][0,3]
    hv += g[dei(p[C,0],p[C,1],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][48][0,3]
    hv += g[dei(p[C,1],p[C,0],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][33][0,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B7C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,7),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,0],p[C,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][30][1,3]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,1],p[C,0])]*r[A][2][14,1]*r[B][7][7,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[B,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[B,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,0],p[C,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][7][7,2]*r[C][48][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][30][1,3]
    hv += g[dei(p[C,0],p[C,1],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][48][1,3]
    hv += g[dei(p[C,1],p[C,0],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][7][7,2]*r[C][33][1,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11B10C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,10),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,0],p[C,0])]*r[A][4][11,1]*r[B][1][10,2]*r[C][9][2,3]
    hv += g[dei(p[A,1],p[B,0],p[C,0],p[C,0])]*r[A][4][11,1]*r[B][1][10,2]*r[C][24][2,3]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,1],p[C,1])]*r[A][4][11,1]*r[B][1][10,2]*r[C][39][2,3]
    hv += g[dei(p[A,1],p[B,0],p[C,1],p[C,1])]*r[A][4][11,1]*r[B][1][10,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[B,0])]*r[A][4][11,1]*r[B][1][10,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[B,0])]*r[A][4][11,1]*r[B][1][10,2]*r[C][39][2,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,1],p[C,0])]*r[A][4][11,1]*r[B][1][10,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,1],p[C,1])]*r[A][4][11,1]*r[B][1][10,2]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[B,0])]*r[A][4][11,1]*r[B][1][10,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[B,0])]*r[A][4][11,1]*r[B][1][10,2]*r[C][39][2,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B8C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,8),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,0],p[C,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][24][2,3]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,1],p[C,1])]*r[A][6][13,1]*r[B][3][8,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[B,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[B,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,1],p[C,1])]*r[A][6][13,1]*r[B][3][8,2]*r[C][54][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][24][2,3]
    hv += g[dei(p[C,0],p[C,0],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][54][2,3]
    hv += g[dei(p[C,1],p[C,1],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][39][2,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11B10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,10)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,0],p[C,1])]*r[A][4][11,1]*r[B][1][10,2]*r[C][15][0,3]
    hv += g[dei(p[A,1],p[B,0],p[C,0],p[C,1])]*r[A][4][11,1]*r[B][1][10,2]*r[C][30][0,3]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,1],p[C,0])]*r[A][4][11,1]*r[B][1][10,2]*r[C][33][0,3]
    hv += g[dei(p[A,1],p[B,0],p[C,1],p[C,0])]*r[A][4][11,1]*r[B][1][10,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[B,0])]*r[A][4][11,1]*r[B][1][10,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[B,0])]*r[A][4][11,1]*r[B][1][10,2]*r[C][33][0,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,1],p[C,1])]*r[A][4][11,1]*r[B][1][10,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,1],p[C,0])]*r[A][4][11,1]*r[B][1][10,2]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[B,0])]*r[A][4][11,1]*r[B][1][10,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[B,0])]*r[A][4][11,1]*r[B][1][10,2]*r[C][33][0,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11B10C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,10),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,0],p[C,1])]*r[A][4][11,1]*r[B][1][10,2]*r[C][15][1,3]
    hv += g[dei(p[A,1],p[B,0],p[C,0],p[C,1])]*r[A][4][11,1]*r[B][1][10,2]*r[C][30][1,3]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,1],p[C,0])]*r[A][4][11,1]*r[B][1][10,2]*r[C][33][1,3]
    hv += g[dei(p[A,1],p[B,0],p[C,1],p[C,0])]*r[A][4][11,1]*r[B][1][10,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[B,0])]*r[A][4][11,1]*r[B][1][10,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[B,0])]*r[A][4][11,1]*r[B][1][10,2]*r[C][33][1,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,1],p[C,1])]*r[A][4][11,1]*r[B][1][10,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,1],p[C,0])]*r[A][4][11,1]*r[B][1][10,2]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[B,0])]*r[A][4][11,1]*r[B][1][10,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[B,0])]*r[A][4][11,1]*r[B][1][10,2]*r[C][33][1,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,8)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,0],p[C,1])]*r[A][6][13,1]*r[B][3][8,2]*r[C][30][0,3]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,1],p[C,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[B,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[B,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,1],p[C,1])]*r[A][6][13,1]*r[B][3][8,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][48][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][30][0,3]
    hv += g[dei(p[C,0],p[C,1],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][48][0,3]
    hv += g[dei(p[C,1],p[C,0],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][33][0,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B8C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,8),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,0],p[C,1])]*r[A][6][13,1]*r[B][3][8,2]*r[C][30][1,3]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,1],p[C,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[B,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[B,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,1],p[C,1])]*r[A][6][13,1]*r[B][3][8,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][48][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][30][1,3]
    hv += g[dei(p[C,0],p[C,1],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][48][1,3]
    hv += g[dei(p[C,1],p[C,0],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][3][8,2]*r[C][33][1,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11B9C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,9),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,0],p[C,0])]*r[A][4][11,1]*r[B][5][9,2]*r[C][9][2,3]
    hv += g[dei(p[A,1],p[B,1],p[C,0],p[C,0])]*r[A][4][11,1]*r[B][5][9,2]*r[C][24][2,3]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,1],p[C,1])]*r[A][4][11,1]*r[B][5][9,2]*r[C][39][2,3]
    hv += g[dei(p[A,1],p[B,1],p[C,1],p[C,1])]*r[A][4][11,1]*r[B][5][9,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[B,1])]*r[A][4][11,1]*r[B][5][9,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[B,1])]*r[A][4][11,1]*r[B][5][9,2]*r[C][39][2,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,1],p[C,0])]*r[A][4][11,1]*r[B][5][9,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,1],p[C,1])]*r[A][4][11,1]*r[B][5][9,2]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[B,1])]*r[A][4][11,1]*r[B][5][9,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[B,1])]*r[A][4][11,1]*r[B][5][9,2]*r[C][39][2,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B7C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,7),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,0],p[C,0])]*r[A][6][13,1]*r[B][7][7,2]*r[C][24][2,3]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,1],p[C,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[B,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[B,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][7][7,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,1],p[C,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][54][2,3]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][24][2,3]
    hv += g[dei(p[C,0],p[C,0],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][54][2,3]
    hv += g[dei(p[C,1],p[C,1],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][39][2,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11B9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,9)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,0],p[C,1])]*r[A][4][11,1]*r[B][5][9,2]*r[C][15][0,3]
    hv += g[dei(p[A,1],p[B,1],p[C,0],p[C,1])]*r[A][4][11,1]*r[B][5][9,2]*r[C][30][0,3]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,1],p[C,0])]*r[A][4][11,1]*r[B][5][9,2]*r[C][33][0,3]
    hv += g[dei(p[A,1],p[B,1],p[C,1],p[C,0])]*r[A][4][11,1]*r[B][5][9,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[B,1])]*r[A][4][11,1]*r[B][5][9,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[B,1])]*r[A][4][11,1]*r[B][5][9,2]*r[C][33][0,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,1],p[C,1])]*r[A][4][11,1]*r[B][5][9,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,1],p[C,0])]*r[A][4][11,1]*r[B][5][9,2]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[B,1])]*r[A][4][11,1]*r[B][5][9,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[B,1])]*r[A][4][11,1]*r[B][5][9,2]*r[C][33][0,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11B9C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,9),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,0],p[C,1])]*r[A][4][11,1]*r[B][5][9,2]*r[C][15][1,3]
    hv += g[dei(p[A,1],p[B,1],p[C,0],p[C,1])]*r[A][4][11,1]*r[B][5][9,2]*r[C][30][1,3]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,1],p[C,0])]*r[A][4][11,1]*r[B][5][9,2]*r[C][33][1,3]
    hv += g[dei(p[A,1],p[B,1],p[C,1],p[C,0])]*r[A][4][11,1]*r[B][5][9,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[B,1])]*r[A][4][11,1]*r[B][5][9,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[B,1])]*r[A][4][11,1]*r[B][5][9,2]*r[C][33][1,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,1],p[C,1])]*r[A][4][11,1]*r[B][5][9,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,1],p[C,0])]*r[A][4][11,1]*r[B][5][9,2]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[B,1])]*r[A][4][11,1]*r[B][5][9,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[B,1])]*r[A][4][11,1]*r[B][5][9,2]*r[C][33][1,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,7)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,0],p[C,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][30][0,3]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,1],p[C,0])]*r[A][6][13,1]*r[B][7][7,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[B,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[B,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,1],p[C,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][7][7,2]*r[C][48][0,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][30][0,3]
    hv += g[dei(p[C,0],p[C,1],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][48][0,3]
    hv += g[dei(p[C,1],p[C,0],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][33][0,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B7C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,7),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,0],p[C,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][30][1,3]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,1],p[C,0])]*r[A][6][13,1]*r[B][7][7,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[B,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[B,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,1],p[C,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][7][7,2]*r[C][48][1,3]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][30][1,3]
    hv += g[dei(p[C,0],p[C,1],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][48][1,3]
    hv += g[dei(p[C,1],p[C,0],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][7][7,2]*r[C][33][1,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12B8C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,8),(C,5)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[A,0],p[C,0],p[C,0],p[B,0])]*r[A][0][12,1]*r[B][3][8,2]*r[C][21][5,3]
    hv += -1*g[dei(p[A,0],p[C,1],p[C,1],p[B,0])]*r[A][0][12,1]*r[B][3][8,2]*r[C][51][5,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12B7C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,7),(C,5)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[A,0],p[C,0],p[C,0],p[B,1])]*r[A][0][12,1]*r[B][7][7,2]*r[C][21][5,3]
    hv += -1*g[dei(p[A,0],p[C,1],p[C,1],p[B,1])]*r[A][0][12,1]*r[B][7][7,2]*r[C][51][5,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11B8C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,8),(C,5)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[A,1],p[C,0],p[C,0],p[B,0])]*r[A][4][11,1]*r[B][3][8,2]*r[C][21][5,3]
    hv += -1*g[dei(p[A,1],p[C,1],p[C,1],p[B,0])]*r[A][4][11,1]*r[B][3][8,2]*r[C][51][5,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11B7C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,7),(C,5)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[A,1],p[C,0],p[C,0],p[B,1])]*r[A][4][11,1]*r[B][7][7,2]*r[C][21][5,3]
    hv += -1*g[dei(p[A,1],p[C,1],p[C,1],p[B,1])]*r[A][4][11,1]*r[B][7][7,2]*r[C][51][5,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A5B11C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,5),(B,11),(C,8)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[B,0],p[A,1],p[A,0],p[C,0])]*r[A][27][5,1]*r[B][0][11,2]*r[C][3][8,3]
    hv += -1*g[dei(p[B,0],p[A,0],p[A,1],p[C,0])]*r[A][45][5,1]*r[B][0][11,2]*r[C][3][8,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A5B11C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,5),(B,11),(C,7)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[B,0],p[A,1],p[A,0],p[C,1])]*r[A][27][5,1]*r[B][0][11,2]*r[C][7][7,3]
    hv += -1*g[dei(p[B,0],p[A,0],p[A,1],p[C,1])]*r[A][45][5,1]*r[B][0][11,2]*r[C][7][7,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A5B12C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,5),(B,12),(C,8)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[B,1],p[A,1],p[A,0],p[C,0])]*r[A][27][5,1]*r[B][4][12,2]*r[C][3][8,3]
    hv += -1*g[dei(p[B,1],p[A,0],p[A,1],p[C,0])]*r[A][45][5,1]*r[B][4][12,2]*r[C][3][8,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A5B12C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,5),(B,12),(C,7)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[B,1],p[A,1],p[A,0],p[C,1])]*r[A][27][5,1]*r[B][4][12,2]*r[C][7][7,3]
    hv += -1*g[dei(p[B,1],p[A,0],p[A,1],p[C,1])]*r[A][45][5,1]*r[B][4][12,2]*r[C][7][7,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B4C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,4),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,0],p[C,0],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][12][4,2]*r[C][1][10,3]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][42][4,2]*r[C][1][10,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B4C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,4),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][12][4,2]*r[C][5][9,3]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][42][4,2]*r[C][5][9,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B4C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,4),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,0],p[C,0],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][12][4,2]*r[C][1][10,3]
    hv += -1*g[dei(p[B,1],p[C,0],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][42][4,2]*r[C][1][10,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B4C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,4),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][12][4,2]*r[C][5][9,3]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][42][4,2]*r[C][5][9,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B11C6(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,11),(C,6)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,0],p[C,0],p[A,0],p[C,1])]*r[A][2][14,1]*r[B][0][11,2]*r[C][46][6,3]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][0][11,2]*r[C][28][6,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B11C6(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,11),(C,6)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,0],p[C,0],p[A,1],p[C,1])]*r[A][6][13,1]*r[B][0][11,2]*r[C][46][6,3]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][0][11,2]*r[C][28][6,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B12C6(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,12),(C,6)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,1],p[C,0],p[A,0],p[C,1])]*r[A][2][14,1]*r[B][4][12,2]*r[C][46][6,3]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][4][12,2]*r[C][28][6,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B12C6(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,12),(C,6)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,1],p[C,0],p[A,1],p[C,1])]*r[A][6][13,1]*r[B][4][12,2]*r[C][46][6,3]
    hv += -1*g[dei(p[B,1],p[C,1],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][4][12,2]*r[C][28][6,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B15C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,15),(C,8)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,0],p[A,0],p[B,1],p[C,0])]*r[A][1][9,1]*r[B][17][15,2]*r[C][3][8,3]
    hv += -1*g[dei(p[B,1],p[A,0],p[B,0],p[C,0])]*r[A][1][9,1]*r[B][35][15,2]*r[C][3][8,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B15C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,15),(C,7)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,0],p[A,0],p[B,1],p[C,1])]*r[A][1][9,1]*r[B][17][15,2]*r[C][7][7,3]
    hv += -1*g[dei(p[B,1],p[A,0],p[B,0],p[C,1])]*r[A][1][9,1]*r[B][35][15,2]*r[C][7][7,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B15C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,15),(C,8)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,0],p[A,1],p[B,1],p[C,0])]*r[A][5][10,1]*r[B][17][15,2]*r[C][3][8,3]
    hv += -1*g[dei(p[B,1],p[A,1],p[B,0],p[C,0])]*r[A][5][10,1]*r[B][35][15,2]*r[C][3][8,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B15C7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,15),(C,7)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,0],p[A,1],p[B,1],p[C,1])]*r[A][5][10,1]*r[B][17][15,2]*r[C][7][7,3]
    hv += -1*g[dei(p[B,1],p[A,1],p[B,0],p[C,1])]*r[A][5][10,1]*r[B][35][15,2]*r[C][7][7,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B15C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,15),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[B,0],p[C,0],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][17][15,2]*r[C][1][10,3]
    hv += g[dei(p[B,1],p[C,0],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][35][15,2]*r[C][1][10,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B15C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,15),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[B,0],p[C,0],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][17][15,2]*r[C][1][10,3]
    hv += g[dei(p[B,1],p[C,0],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][35][15,2]*r[C][1][10,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B15C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,15),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[B,0],p[C,1],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][17][15,2]*r[C][5][9,3]
    hv += g[dei(p[B,1],p[C,1],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][35][15,2]*r[C][5][9,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B15C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,15),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[B,0],p[C,1],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][17][15,2]*r[C][5][9,3]
    hv += g[dei(p[B,1],p[C,1],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][35][15,2]*r[C][5][9,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A6B11C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,6),(B,11),(C,13)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[B,0],p[A,0],p[C,0],p[A,0])]*r[A][22][6,1]*r[B][0][11,2]*r[C][2][13,3]
    hv += g[dei(p[B,0],p[A,1],p[C,0],p[A,1])]*r[A][52][6,1]*r[B][0][11,2]*r[C][2][13,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A6B11C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,6),(B,11),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[B,0],p[A,0],p[C,1],p[A,0])]*r[A][22][6,1]*r[B][0][11,2]*r[C][6][14,3]
    hv += g[dei(p[B,0],p[A,1],p[C,1],p[A,1])]*r[A][52][6,1]*r[B][0][11,2]*r[C][6][14,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A6B12C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,6),(B,12),(C,13)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[B,1],p[A,0],p[C,0],p[A,0])]*r[A][22][6,1]*r[B][4][12,2]*r[C][2][13,3]
    hv += g[dei(p[B,1],p[A,1],p[C,0],p[A,1])]*r[A][52][6,1]*r[B][4][12,2]*r[C][2][13,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A6B12C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,6),(B,12),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[B,1],p[A,0],p[C,1],p[A,0])]*r[A][22][6,1]*r[B][4][12,2]*r[C][6][14,3]
    hv += g[dei(p[B,1],p[A,1],p[C,1],p[A,1])]*r[A][52][6,1]*r[B][4][12,2]*r[C][6][14,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B3C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,3),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[B,0],p[A,0],p[C,0],p[B,0])]*r[A][1][9,1]*r[B][9][3,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[C,0],p[B,1])]*r[A][1][9,1]*r[B][39][3,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[B,0],p[B,0],p[C,0],p[A,0])]*r[A][1][9,1]*r[B][9][3,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[B,1],p[B,1],p[C,0],p[A,0])]*r[A][1][9,1]*r[B][39][3,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[B,0],p[B,0])]*r[A][1][9,1]*r[B][9][3,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[A,0],p[B,0],p[B,0])]*r[A][1][9,1]*r[B][24][3,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[B,1],p[B,1])]*r[A][1][9,1]*r[B][39][3,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[A,0],p[B,1],p[B,1])]*r[A][1][9,1]*r[B][54][3,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[B,0],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][9][3,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[B,1],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][39][3,2]*r[C][0][11,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B3C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,3),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[B,0],p[A,0],p[C,0],p[B,0])]*r[A][3][7,1]*r[B][24][3,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[C,0],p[B,1])]*r[A][3][7,1]*r[B][54][3,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[B,0],p[B,0],p[C,0],p[A,0])]*r[A][3][7,1]*r[B][24][3,2]*r[C][2][13,3]
    hv += -1*g[dei(p[B,0],p[B,0],p[C,0],p[A,0])]*r[A][3][7,1]*r[B][9][3,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[B,1],p[B,1],p[C,0],p[A,0])]*r[A][3][7,1]*r[B][54][3,2]*r[C][2][13,3]
    hv += -1*g[dei(p[B,1],p[B,1],p[C,0],p[A,0])]*r[A][3][7,1]*r[B][39][3,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[B,0],p[B,0])]*r[A][3][7,1]*r[B][24][3,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[B,1],p[B,1])]*r[A][3][7,1]*r[B][54][3,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[B,0],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][24][3,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[B,1],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][54][3,2]*r[C][2][13,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B4C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,4),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[B,0],p[A,0],p[C,0],p[B,0])]*r[A][1][9,1]*r[B][12][4,2]*r[C][2][13,3]
    hv += g[dei(p[B,1],p[A,0],p[C,0],p[B,1])]*r[A][1][9,1]*r[B][42][4,2]*r[C][2][13,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[B,0],p[A,0],p[C,0],p[B,1])]*r[A][1][9,1]*r[B][15][0,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[C,0],p[B,0])]*r[A][1][9,1]*r[B][33][0,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[B,0],p[B,1],p[C,0],p[A,0])]*r[A][1][9,1]*r[B][15][0,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[B,1],p[B,0],p[C,0],p[A,0])]*r[A][1][9,1]*r[B][33][0,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[B,0],p[B,1])]*r[A][1][9,1]*r[B][15][0,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[A,0],p[B,0],p[B,1])]*r[A][1][9,1]*r[B][30][0,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[B,1],p[B,0])]*r[A][1][9,1]*r[B][33][0,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[A,0],p[B,1],p[B,0])]*r[A][1][9,1]*r[B][48][0,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[B,1],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][15][0,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[B,0],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][33][0,2]*r[C][0][11,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B1C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,1),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[B,0],p[A,0],p[C,0],p[B,1])]*r[A][1][9,1]*r[B][15][1,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[C,0],p[B,0])]*r[A][1][9,1]*r[B][33][1,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[B,0],p[B,1],p[C,0],p[A,0])]*r[A][1][9,1]*r[B][15][1,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[B,1],p[B,0],p[C,0],p[A,0])]*r[A][1][9,1]*r[B][33][1,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[B,0],p[B,1])]*r[A][1][9,1]*r[B][15][1,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[A,0],p[B,0],p[B,1])]*r[A][1][9,1]*r[B][30][1,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[B,1],p[B,0])]*r[A][1][9,1]*r[B][33][1,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[A,0],p[B,1],p[B,0])]*r[A][1][9,1]*r[B][48][1,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[B,1],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][15][1,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[B,0],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][33][1,2]*r[C][0][11,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[B,0],p[A,0],p[C,0],p[B,1])]*r[A][3][7,1]*r[B][30][0,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[C,0],p[B,0])]*r[A][3][7,1]*r[B][48][0,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[B,0],p[B,1],p[C,0],p[A,0])]*r[A][3][7,1]*r[B][30][0,2]*r[C][2][13,3]
    hv += -1*g[dei(p[B,0],p[B,1],p[C,0],p[A,0])]*r[A][3][7,1]*r[B][15][0,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[B,1],p[B,0],p[C,0],p[A,0])]*r[A][3][7,1]*r[B][48][0,2]*r[C][2][13,3]
    hv += -1*g[dei(p[B,1],p[B,0],p[C,0],p[A,0])]*r[A][3][7,1]*r[B][33][0,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[B,0],p[B,1])]*r[A][3][7,1]*r[B][30][0,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[B,1],p[B,0])]*r[A][3][7,1]*r[B][48][0,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[B,1],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][30][0,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[B,0],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][48][0,2]*r[C][2][13,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B1C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,1),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[B,0],p[A,0],p[C,0],p[B,1])]*r[A][3][7,1]*r[B][30][1,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[C,0],p[B,0])]*r[A][3][7,1]*r[B][48][1,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[B,0],p[B,1],p[C,0],p[A,0])]*r[A][3][7,1]*r[B][30][1,2]*r[C][2][13,3]
    hv += -1*g[dei(p[B,0],p[B,1],p[C,0],p[A,0])]*r[A][3][7,1]*r[B][15][1,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[B,1],p[B,0],p[C,0],p[A,0])]*r[A][3][7,1]*r[B][48][1,2]*r[C][2][13,3]
    hv += -1*g[dei(p[B,1],p[B,0],p[C,0],p[A,0])]*r[A][3][7,1]*r[B][33][1,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[B,0],p[B,1])]*r[A][3][7,1]*r[B][30][1,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[B,1],p[B,0])]*r[A][3][7,1]*r[B][48][1,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[B,1],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][30][1,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[B,0],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][48][1,2]*r[C][2][13,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B3C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,3),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[B,0],p[A,1],p[C,0],p[B,0])]*r[A][5][10,1]*r[B][9][3,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[C,0],p[B,1])]*r[A][5][10,1]*r[B][39][3,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[B,0],p[B,0],p[C,0],p[A,1])]*r[A][5][10,1]*r[B][9][3,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[B,1],p[B,1],p[C,0],p[A,1])]*r[A][5][10,1]*r[B][39][3,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[B,0],p[B,0])]*r[A][5][10,1]*r[B][9][3,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[A,1],p[B,0],p[B,0])]*r[A][5][10,1]*r[B][24][3,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[B,1],p[B,1])]*r[A][5][10,1]*r[B][39][3,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[A,1],p[B,1],p[B,1])]*r[A][5][10,1]*r[B][54][3,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[B,0],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][9][3,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[B,1],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][39][3,2]*r[C][0][11,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B3C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,3),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[B,0],p[A,1],p[C,0],p[B,0])]*r[A][7][8,1]*r[B][24][3,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[C,0],p[B,1])]*r[A][7][8,1]*r[B][54][3,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[B,0],p[B,0],p[C,0],p[A,1])]*r[A][7][8,1]*r[B][24][3,2]*r[C][2][13,3]
    hv += -1*g[dei(p[B,0],p[B,0],p[C,0],p[A,1])]*r[A][7][8,1]*r[B][9][3,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[B,1],p[B,1],p[C,0],p[A,1])]*r[A][7][8,1]*r[B][54][3,2]*r[C][2][13,3]
    hv += -1*g[dei(p[B,1],p[B,1],p[C,0],p[A,1])]*r[A][7][8,1]*r[B][39][3,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[B,0],p[B,0])]*r[A][7][8,1]*r[B][24][3,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[B,1],p[B,1])]*r[A][7][8,1]*r[B][54][3,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[B,0],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][24][3,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[B,1],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][54][3,2]*r[C][2][13,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B4C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,4),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[B,0],p[A,1],p[C,0],p[B,0])]*r[A][5][10,1]*r[B][12][4,2]*r[C][2][13,3]
    hv += g[dei(p[B,1],p[A,1],p[C,0],p[B,1])]*r[A][5][10,1]*r[B][42][4,2]*r[C][2][13,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[B,0],p[A,1],p[C,0],p[B,1])]*r[A][5][10,1]*r[B][15][0,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[C,0],p[B,0])]*r[A][5][10,1]*r[B][33][0,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[B,0],p[B,1],p[C,0],p[A,1])]*r[A][5][10,1]*r[B][15][0,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[B,1],p[B,0],p[C,0],p[A,1])]*r[A][5][10,1]*r[B][33][0,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[B,0],p[B,1])]*r[A][5][10,1]*r[B][15][0,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[A,1],p[B,0],p[B,1])]*r[A][5][10,1]*r[B][30][0,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[B,1],p[B,0])]*r[A][5][10,1]*r[B][33][0,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[A,1],p[B,1],p[B,0])]*r[A][5][10,1]*r[B][48][0,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[B,1],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][15][0,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[B,0],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][33][0,2]*r[C][0][11,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B1C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,1),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[B,0],p[A,1],p[C,0],p[B,1])]*r[A][5][10,1]*r[B][15][1,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[C,0],p[B,0])]*r[A][5][10,1]*r[B][33][1,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[B,0],p[B,1],p[C,0],p[A,1])]*r[A][5][10,1]*r[B][15][1,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[B,1],p[B,0],p[C,0],p[A,1])]*r[A][5][10,1]*r[B][33][1,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[B,0],p[B,1])]*r[A][5][10,1]*r[B][15][1,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[A,1],p[B,0],p[B,1])]*r[A][5][10,1]*r[B][30][1,2]*r[C][0][11,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[B,1],p[B,0])]*r[A][5][10,1]*r[B][33][1,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[A,1],p[B,1],p[B,0])]*r[A][5][10,1]*r[B][48][1,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[B,1],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][15][1,2]*r[C][0][11,3]
    hv += 1/2*g[dei(p[C,0],p[B,0],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][33][1,2]*r[C][0][11,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[B,0],p[A,1],p[C,0],p[B,1])]*r[A][7][8,1]*r[B][30][0,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[C,0],p[B,0])]*r[A][7][8,1]*r[B][48][0,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[B,0],p[B,1],p[C,0],p[A,1])]*r[A][7][8,1]*r[B][30][0,2]*r[C][2][13,3]
    hv += -1*g[dei(p[B,0],p[B,1],p[C,0],p[A,1])]*r[A][7][8,1]*r[B][15][0,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[B,1],p[B,0],p[C,0],p[A,1])]*r[A][7][8,1]*r[B][48][0,2]*r[C][2][13,3]
    hv += -1*g[dei(p[B,1],p[B,0],p[C,0],p[A,1])]*r[A][7][8,1]*r[B][33][0,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[B,0],p[B,1])]*r[A][7][8,1]*r[B][30][0,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[B,1],p[B,0])]*r[A][7][8,1]*r[B][48][0,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[B,1],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][30][0,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[B,0],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][48][0,2]*r[C][2][13,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B1C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,1),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[B,0],p[A,1],p[C,0],p[B,1])]*r[A][7][8,1]*r[B][30][1,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[C,0],p[B,0])]*r[A][7][8,1]*r[B][48][1,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[B,0],p[B,1],p[C,0],p[A,1])]*r[A][7][8,1]*r[B][30][1,2]*r[C][2][13,3]
    hv += -1*g[dei(p[B,0],p[B,1],p[C,0],p[A,1])]*r[A][7][8,1]*r[B][15][1,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[B,1],p[B,0],p[C,0],p[A,1])]*r[A][7][8,1]*r[B][48][1,2]*r[C][2][13,3]
    hv += -1*g[dei(p[B,1],p[B,0],p[C,0],p[A,1])]*r[A][7][8,1]*r[B][33][1,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[B,0],p[B,1])]*r[A][7][8,1]*r[B][30][1,2]*r[C][2][13,3]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[B,1],p[B,0])]*r[A][7][8,1]*r[B][48][1,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[B,1],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][30][1,2]*r[C][2][13,3]
    hv += 1/2*g[dei(p[C,0],p[B,0],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][48][1,2]*r[C][2][13,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B3C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,3),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[B,0],p[A,0],p[C,1],p[B,0])]*r[A][1][9,1]*r[B][9][3,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[C,1],p[B,1])]*r[A][1][9,1]*r[B][39][3,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[B,0],p[B,0],p[C,1],p[A,0])]*r[A][1][9,1]*r[B][9][3,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[B,1],p[B,1],p[C,1],p[A,0])]*r[A][1][9,1]*r[B][39][3,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[B,0],p[B,0])]*r[A][1][9,1]*r[B][9][3,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[A,0],p[B,0],p[B,0])]*r[A][1][9,1]*r[B][24][3,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[B,1],p[B,1])]*r[A][1][9,1]*r[B][39][3,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[A,0],p[B,1],p[B,1])]*r[A][1][9,1]*r[B][54][3,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[B,0],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][9][3,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[B,1],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][39][3,2]*r[C][4][12,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B3C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,3),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[B,0],p[A,0],p[C,1],p[B,0])]*r[A][3][7,1]*r[B][24][3,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[C,1],p[B,1])]*r[A][3][7,1]*r[B][54][3,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[B,0],p[B,0],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][24][3,2]*r[C][6][14,3]
    hv += -1*g[dei(p[B,0],p[B,0],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][9][3,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[B,1],p[B,1],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][54][3,2]*r[C][6][14,3]
    hv += -1*g[dei(p[B,1],p[B,1],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][39][3,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[B,0],p[B,0])]*r[A][3][7,1]*r[B][24][3,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[B,1],p[B,1])]*r[A][3][7,1]*r[B][54][3,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[B,0],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][24][3,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[B,1],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][54][3,2]*r[C][6][14,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B4C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,4),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[B,0],p[A,0],p[C,1],p[B,0])]*r[A][1][9,1]*r[B][12][4,2]*r[C][6][14,3]
    hv += g[dei(p[B,1],p[A,0],p[C,1],p[B,1])]*r[A][1][9,1]*r[B][42][4,2]*r[C][6][14,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[B,0],p[A,0],p[C,1],p[B,1])]*r[A][1][9,1]*r[B][15][0,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[C,1],p[B,0])]*r[A][1][9,1]*r[B][33][0,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[B,0],p[B,1],p[C,1],p[A,0])]*r[A][1][9,1]*r[B][15][0,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[B,1],p[B,0],p[C,1],p[A,0])]*r[A][1][9,1]*r[B][33][0,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[B,0],p[B,1])]*r[A][1][9,1]*r[B][15][0,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[A,0],p[B,0],p[B,1])]*r[A][1][9,1]*r[B][30][0,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[B,1],p[B,0])]*r[A][1][9,1]*r[B][33][0,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[A,0],p[B,1],p[B,0])]*r[A][1][9,1]*r[B][48][0,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[B,1],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][15][0,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[B,0],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][33][0,2]*r[C][4][12,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B1C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,1),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[B,0],p[A,0],p[C,1],p[B,1])]*r[A][1][9,1]*r[B][15][1,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[C,1],p[B,0])]*r[A][1][9,1]*r[B][33][1,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[B,0],p[B,1],p[C,1],p[A,0])]*r[A][1][9,1]*r[B][15][1,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[B,1],p[B,0],p[C,1],p[A,0])]*r[A][1][9,1]*r[B][33][1,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[B,0],p[B,1])]*r[A][1][9,1]*r[B][15][1,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[A,0],p[B,0],p[B,1])]*r[A][1][9,1]*r[B][30][1,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[B,1],p[B,0])]*r[A][1][9,1]*r[B][33][1,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[A,0],p[B,1],p[B,0])]*r[A][1][9,1]*r[B][48][1,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[B,1],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][15][1,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[B,0],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][33][1,2]*r[C][4][12,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[B,0],p[A,0],p[C,1],p[B,1])]*r[A][3][7,1]*r[B][30][0,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[C,1],p[B,0])]*r[A][3][7,1]*r[B][48][0,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[B,0],p[B,1],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][30][0,2]*r[C][6][14,3]
    hv += -1*g[dei(p[B,0],p[B,1],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][15][0,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[B,1],p[B,0],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][48][0,2]*r[C][6][14,3]
    hv += -1*g[dei(p[B,1],p[B,0],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][33][0,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[B,0],p[B,1])]*r[A][3][7,1]*r[B][30][0,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[B,1],p[B,0])]*r[A][3][7,1]*r[B][48][0,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[B,1],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][30][0,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[B,0],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][48][0,2]*r[C][6][14,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B1C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,1),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[B,0],p[A,0],p[C,1],p[B,1])]*r[A][3][7,1]*r[B][30][1,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[C,1],p[B,0])]*r[A][3][7,1]*r[B][48][1,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[B,0],p[B,1],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][30][1,2]*r[C][6][14,3]
    hv += -1*g[dei(p[B,0],p[B,1],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][15][1,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[B,1],p[B,0],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][48][1,2]*r[C][6][14,3]
    hv += -1*g[dei(p[B,1],p[B,0],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][33][1,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[B,0],p[B,1])]*r[A][3][7,1]*r[B][30][1,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[B,1],p[B,0])]*r[A][3][7,1]*r[B][48][1,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[B,1],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][30][1,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[B,0],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][48][1,2]*r[C][6][14,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B3C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,3),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[B,0],p[A,1],p[C,1],p[B,0])]*r[A][5][10,1]*r[B][9][3,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[C,1],p[B,1])]*r[A][5][10,1]*r[B][39][3,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[B,0],p[B,0],p[C,1],p[A,1])]*r[A][5][10,1]*r[B][9][3,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[B,1],p[B,1],p[C,1],p[A,1])]*r[A][5][10,1]*r[B][39][3,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[B,0],p[B,0])]*r[A][5][10,1]*r[B][9][3,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[A,1],p[B,0],p[B,0])]*r[A][5][10,1]*r[B][24][3,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[B,1],p[B,1])]*r[A][5][10,1]*r[B][39][3,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[A,1],p[B,1],p[B,1])]*r[A][5][10,1]*r[B][54][3,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[B,0],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][9][3,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[B,1],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][39][3,2]*r[C][4][12,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B3C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,3),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[B,0],p[A,1],p[C,1],p[B,0])]*r[A][7][8,1]*r[B][24][3,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[C,1],p[B,1])]*r[A][7][8,1]*r[B][54][3,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[B,0],p[B,0],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][24][3,2]*r[C][6][14,3]
    hv += -1*g[dei(p[B,0],p[B,0],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][9][3,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[B,1],p[B,1],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][54][3,2]*r[C][6][14,3]
    hv += -1*g[dei(p[B,1],p[B,1],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][39][3,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[B,0],p[B,0])]*r[A][7][8,1]*r[B][24][3,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[B,1],p[B,1])]*r[A][7][8,1]*r[B][54][3,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[B,0],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][24][3,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[B,1],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][54][3,2]*r[C][6][14,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B4C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,4),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[B,0],p[A,1],p[C,1],p[B,0])]*r[A][5][10,1]*r[B][12][4,2]*r[C][6][14,3]
    hv += g[dei(p[B,1],p[A,1],p[C,1],p[B,1])]*r[A][5][10,1]*r[B][42][4,2]*r[C][6][14,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[B,0],p[A,1],p[C,1],p[B,1])]*r[A][5][10,1]*r[B][15][0,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[C,1],p[B,0])]*r[A][5][10,1]*r[B][33][0,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[B,0],p[B,1],p[C,1],p[A,1])]*r[A][5][10,1]*r[B][15][0,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[B,1],p[B,0],p[C,1],p[A,1])]*r[A][5][10,1]*r[B][33][0,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[B,0],p[B,1])]*r[A][5][10,1]*r[B][15][0,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[A,1],p[B,0],p[B,1])]*r[A][5][10,1]*r[B][30][0,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[B,1],p[B,0])]*r[A][5][10,1]*r[B][33][0,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[A,1],p[B,1],p[B,0])]*r[A][5][10,1]*r[B][48][0,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[B,1],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][15][0,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[B,0],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][33][0,2]*r[C][4][12,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B1C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,1),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[B,0],p[A,1],p[C,1],p[B,1])]*r[A][5][10,1]*r[B][15][1,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[C,1],p[B,0])]*r[A][5][10,1]*r[B][33][1,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[B,0],p[B,1],p[C,1],p[A,1])]*r[A][5][10,1]*r[B][15][1,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[B,1],p[B,0],p[C,1],p[A,1])]*r[A][5][10,1]*r[B][33][1,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[B,0],p[B,1])]*r[A][5][10,1]*r[B][15][1,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[A,1],p[B,0],p[B,1])]*r[A][5][10,1]*r[B][30][1,2]*r[C][4][12,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[B,1],p[B,0])]*r[A][5][10,1]*r[B][33][1,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[A,1],p[B,1],p[B,0])]*r[A][5][10,1]*r[B][48][1,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[B,1],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][15][1,2]*r[C][4][12,3]
    hv += 1/2*g[dei(p[C,1],p[B,0],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][33][1,2]*r[C][4][12,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[B,0],p[A,1],p[C,1],p[B,1])]*r[A][7][8,1]*r[B][30][0,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[C,1],p[B,0])]*r[A][7][8,1]*r[B][48][0,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[B,0],p[B,1],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][30][0,2]*r[C][6][14,3]
    hv += -1*g[dei(p[B,0],p[B,1],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][15][0,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[B,1],p[B,0],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][48][0,2]*r[C][6][14,3]
    hv += -1*g[dei(p[B,1],p[B,0],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][33][0,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[B,0],p[B,1])]*r[A][7][8,1]*r[B][30][0,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[B,1],p[B,0])]*r[A][7][8,1]*r[B][48][0,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[B,1],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][30][0,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[B,0],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][48][0,2]*r[C][6][14,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B1C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,1),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[B,0],p[A,1],p[C,1],p[B,1])]*r[A][7][8,1]*r[B][30][1,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[C,1],p[B,0])]*r[A][7][8,1]*r[B][48][1,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[B,0],p[B,1],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][30][1,2]*r[C][6][14,3]
    hv += -1*g[dei(p[B,0],p[B,1],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][15][1,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[B,1],p[B,0],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][48][1,2]*r[C][6][14,3]
    hv += -1*g[dei(p[B,1],p[B,0],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][33][1,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[B,0],p[B,1])]*r[A][7][8,1]*r[B][30][1,2]*r[C][6][14,3]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[B,1],p[B,0])]*r[A][7][8,1]*r[B][48][1,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[B,1],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][30][1,2]*r[C][6][14,3]
    hv += 1/2*g[dei(p[C,1],p[B,0],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][48][1,2]*r[C][6][14,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B11C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,11),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[B,0],p[A,0],p[C,0],p[C,0])]*r[A][1][9,1]*r[B][0][11,2]*r[C][9][2,3]
    hv += -1*g[dei(p[B,0],p[A,0],p[C,0],p[C,0])]*r[A][1][9,1]*r[B][0][11,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[C,1],p[C,1])]*r[A][1][9,1]*r[B][0][11,2]*r[C][39][2,3]
    hv += -1*g[dei(p[B,0],p[A,0],p[C,1],p[C,1])]*r[A][1][9,1]*r[B][0][11,2]*r[C][54][2,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[C,0],p[A,0])]*r[A][1][9,1]*r[B][0][11,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,1],p[A,0])]*r[A][1][9,1]*r[B][0][11,2]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[B,0],p[C,0])]*r[A][1][9,1]*r[B][0][11,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[B,0],p[C,1])]*r[A][1][9,1]*r[B][0][11,2]*r[C][39][2,3]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][11,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][11,2]*r[C][39][2,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B13C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,13),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[B,0],p[A,0],p[C,0],p[C,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[C,1],p[C,1])]*r[A][3][7,1]*r[B][2][13,2]*r[C][54][2,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[C,0],p[A,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][24][2,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][54][2,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[B,0],p[C,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][24][2,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[B,0],p[C,1])]*r[A][3][7,1]*r[B][2][13,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][24][2,3]
    hv += -1*g[dei(p[C,0],p[C,0],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][54][2,3]
    hv += -1*g[dei(p[C,1],p[C,1],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][39][2,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,11)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[B,0],p[A,0],p[C,0],p[C,1])]*r[A][1][9,1]*r[B][0][11,2]*r[C][15][0,3]
    hv += -1*g[dei(p[B,0],p[A,0],p[C,0],p[C,1])]*r[A][1][9,1]*r[B][0][11,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[C,1],p[C,0])]*r[A][1][9,1]*r[B][0][11,2]*r[C][33][0,3]
    hv += -1*g[dei(p[B,0],p[A,0],p[C,1],p[C,0])]*r[A][1][9,1]*r[B][0][11,2]*r[C][48][0,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,0],p[A,0])]*r[A][1][9,1]*r[B][0][11,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[C,1],p[A,0])]*r[A][1][9,1]*r[B][0][11,2]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[B,0],p[C,1])]*r[A][1][9,1]*r[B][0][11,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[B,0],p[C,0])]*r[A][1][9,1]*r[B][0][11,2]*r[C][33][0,3]
    hv += -1/2*g[dei(p[C,0],p[C,1],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][11,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[C,1],p[C,0],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][11,2]*r[C][33][0,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B11C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,11),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[B,0],p[A,0],p[C,0],p[C,1])]*r[A][1][9,1]*r[B][0][11,2]*r[C][15][1,3]
    hv += -1*g[dei(p[B,0],p[A,0],p[C,0],p[C,1])]*r[A][1][9,1]*r[B][0][11,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[C,1],p[C,0])]*r[A][1][9,1]*r[B][0][11,2]*r[C][33][1,3]
    hv += -1*g[dei(p[B,0],p[A,0],p[C,1],p[C,0])]*r[A][1][9,1]*r[B][0][11,2]*r[C][48][1,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,0],p[A,0])]*r[A][1][9,1]*r[B][0][11,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[C,1],p[A,0])]*r[A][1][9,1]*r[B][0][11,2]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[B,0],p[C,1])]*r[A][1][9,1]*r[B][0][11,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[B,0],p[C,0])]*r[A][1][9,1]*r[B][0][11,2]*r[C][33][1,3]
    hv += -1/2*g[dei(p[C,0],p[C,1],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][11,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[C,1],p[C,0],p[B,0],p[A,0])]*r[A][1][9,1]*r[B][0][11,2]*r[C][33][1,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,13)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[B,0],p[A,0],p[C,0],p[C,1])]*r[A][3][7,1]*r[B][2][13,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[C,1],p[C,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][48][0,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,0],p[A,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][30][0,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][48][0,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[B,0],p[C,1])]*r[A][3][7,1]*r[B][2][13,2]*r[C][30][0,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[B,0],p[C,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[C,0],p[C,1],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][30][0,3]
    hv += -1*g[dei(p[C,0],p[C,1],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[C,1],p[C,0],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][48][0,3]
    hv += -1*g[dei(p[C,1],p[C,0],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][33][0,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B13C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,13),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[B,0],p[A,0],p[C,0],p[C,1])]*r[A][3][7,1]*r[B][2][13,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[C,1],p[C,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][48][1,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,0],p[A,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][30][1,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][48][1,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[B,0],p[C,1])]*r[A][3][7,1]*r[B][2][13,2]*r[C][30][1,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[B,0],p[C,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[C,0],p[C,1],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][30][1,3]
    hv += -1*g[dei(p[C,0],p[C,1],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[C,1],p[C,0],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][48][1,3]
    hv += -1*g[dei(p[C,1],p[C,0],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][2][13,2]*r[C][33][1,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B11C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,11),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[B,0],p[A,1],p[C,0],p[C,0])]*r[A][5][10,1]*r[B][0][11,2]*r[C][9][2,3]
    hv += -1*g[dei(p[B,0],p[A,1],p[C,0],p[C,0])]*r[A][5][10,1]*r[B][0][11,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[C,1],p[C,1])]*r[A][5][10,1]*r[B][0][11,2]*r[C][39][2,3]
    hv += -1*g[dei(p[B,0],p[A,1],p[C,1],p[C,1])]*r[A][5][10,1]*r[B][0][11,2]*r[C][54][2,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[C,0],p[A,1])]*r[A][5][10,1]*r[B][0][11,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,1],p[A,1])]*r[A][5][10,1]*r[B][0][11,2]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[B,0],p[C,0])]*r[A][5][10,1]*r[B][0][11,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[B,0],p[C,1])]*r[A][5][10,1]*r[B][0][11,2]*r[C][39][2,3]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][11,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][11,2]*r[C][39][2,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B13C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,13),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[B,0],p[A,1],p[C,0],p[C,0])]*r[A][7][8,1]*r[B][2][13,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[C,1],p[C,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][54][2,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[C,0],p[A,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][24][2,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][54][2,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[B,0],p[C,0])]*r[A][7][8,1]*r[B][2][13,2]*r[C][24][2,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[B,0],p[C,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][24][2,3]
    hv += -1*g[dei(p[C,0],p[C,0],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][54][2,3]
    hv += -1*g[dei(p[C,1],p[C,1],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][39][2,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,11)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[B,0],p[A,1],p[C,0],p[C,1])]*r[A][5][10,1]*r[B][0][11,2]*r[C][15][0,3]
    hv += -1*g[dei(p[B,0],p[A,1],p[C,0],p[C,1])]*r[A][5][10,1]*r[B][0][11,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[C,1],p[C,0])]*r[A][5][10,1]*r[B][0][11,2]*r[C][33][0,3]
    hv += -1*g[dei(p[B,0],p[A,1],p[C,1],p[C,0])]*r[A][5][10,1]*r[B][0][11,2]*r[C][48][0,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,0],p[A,1])]*r[A][5][10,1]*r[B][0][11,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[C,1],p[A,1])]*r[A][5][10,1]*r[B][0][11,2]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[B,0],p[C,1])]*r[A][5][10,1]*r[B][0][11,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[B,0],p[C,0])]*r[A][5][10,1]*r[B][0][11,2]*r[C][33][0,3]
    hv += -1/2*g[dei(p[C,0],p[C,1],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][11,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[C,1],p[C,0],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][11,2]*r[C][33][0,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B11C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,11),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[B,0],p[A,1],p[C,0],p[C,1])]*r[A][5][10,1]*r[B][0][11,2]*r[C][15][1,3]
    hv += -1*g[dei(p[B,0],p[A,1],p[C,0],p[C,1])]*r[A][5][10,1]*r[B][0][11,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[C,1],p[C,0])]*r[A][5][10,1]*r[B][0][11,2]*r[C][33][1,3]
    hv += -1*g[dei(p[B,0],p[A,1],p[C,1],p[C,0])]*r[A][5][10,1]*r[B][0][11,2]*r[C][48][1,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,0],p[A,1])]*r[A][5][10,1]*r[B][0][11,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[C,1],p[A,1])]*r[A][5][10,1]*r[B][0][11,2]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[B,0],p[C,1])]*r[A][5][10,1]*r[B][0][11,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[B,0],p[C,0])]*r[A][5][10,1]*r[B][0][11,2]*r[C][33][1,3]
    hv += -1/2*g[dei(p[C,0],p[C,1],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][11,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[C,1],p[C,0],p[B,0],p[A,1])]*r[A][5][10,1]*r[B][0][11,2]*r[C][33][1,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,13)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[B,0],p[A,1],p[C,0],p[C,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[C,1],p[C,0])]*r[A][7][8,1]*r[B][2][13,2]*r[C][48][0,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,0],p[A,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][30][0,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][48][0,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[B,0],p[C,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][30][0,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[B,0],p[C,0])]*r[A][7][8,1]*r[B][2][13,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[C,0],p[C,1],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][30][0,3]
    hv += -1*g[dei(p[C,0],p[C,1],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[C,1],p[C,0],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][48][0,3]
    hv += -1*g[dei(p[C,1],p[C,0],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][33][0,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B13C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,13),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[B,0],p[A,1],p[C,0],p[C,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[C,1],p[C,0])]*r[A][7][8,1]*r[B][2][13,2]*r[C][48][1,3]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,0],p[A,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][30][1,3]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][48][1,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[B,0],p[C,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][30][1,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[B,0],p[C,0])]*r[A][7][8,1]*r[B][2][13,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[C,0],p[C,1],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][30][1,3]
    hv += -1*g[dei(p[C,0],p[C,1],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[C,1],p[C,0],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][48][1,3]
    hv += -1*g[dei(p[C,1],p[C,0],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][2][13,2]*r[C][33][1,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B12C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,12),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[B,1],p[A,0],p[C,0],p[C,0])]*r[A][1][9,1]*r[B][4][12,2]*r[C][9][2,3]
    hv += -1*g[dei(p[B,1],p[A,0],p[C,0],p[C,0])]*r[A][1][9,1]*r[B][4][12,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[C,1],p[C,1])]*r[A][1][9,1]*r[B][4][12,2]*r[C][39][2,3]
    hv += -1*g[dei(p[B,1],p[A,0],p[C,1],p[C,1])]*r[A][1][9,1]*r[B][4][12,2]*r[C][54][2,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,0],p[A,0])]*r[A][1][9,1]*r[B][4][12,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[C,1],p[A,0])]*r[A][1][9,1]*r[B][4][12,2]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[B,1],p[C,0])]*r[A][1][9,1]*r[B][4][12,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[B,1],p[C,1])]*r[A][1][9,1]*r[B][4][12,2]*r[C][39][2,3]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][4][12,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][4][12,2]*r[C][39][2,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B14C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,14),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[B,1],p[A,0],p[C,0],p[C,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[C,1],p[C,1])]*r[A][3][7,1]*r[B][6][14,2]*r[C][54][2,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,0],p[A,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][24][2,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][54][2,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[B,1],p[C,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][24][2,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[B,1],p[C,1])]*r[A][3][7,1]*r[B][6][14,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][24][2,3]
    hv += -1*g[dei(p[C,0],p[C,0],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][54][2,3]
    hv += -1*g[dei(p[C,1],p[C,1],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][39][2,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,12)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[B,1],p[A,0],p[C,0],p[C,1])]*r[A][1][9,1]*r[B][4][12,2]*r[C][15][0,3]
    hv += -1*g[dei(p[B,1],p[A,0],p[C,0],p[C,1])]*r[A][1][9,1]*r[B][4][12,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[C,1],p[C,0])]*r[A][1][9,1]*r[B][4][12,2]*r[C][33][0,3]
    hv += -1*g[dei(p[B,1],p[A,0],p[C,1],p[C,0])]*r[A][1][9,1]*r[B][4][12,2]*r[C][48][0,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[C,0],p[A,0])]*r[A][1][9,1]*r[B][4][12,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,1],p[A,0])]*r[A][1][9,1]*r[B][4][12,2]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[B,1],p[C,1])]*r[A][1][9,1]*r[B][4][12,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[B,1],p[C,0])]*r[A][1][9,1]*r[B][4][12,2]*r[C][33][0,3]
    hv += -1/2*g[dei(p[C,0],p[C,1],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][4][12,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[C,1],p[C,0],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][4][12,2]*r[C][33][0,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B12C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,12),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[B,1],p[A,0],p[C,0],p[C,1])]*r[A][1][9,1]*r[B][4][12,2]*r[C][15][1,3]
    hv += -1*g[dei(p[B,1],p[A,0],p[C,0],p[C,1])]*r[A][1][9,1]*r[B][4][12,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[C,1],p[C,0])]*r[A][1][9,1]*r[B][4][12,2]*r[C][33][1,3]
    hv += -1*g[dei(p[B,1],p[A,0],p[C,1],p[C,0])]*r[A][1][9,1]*r[B][4][12,2]*r[C][48][1,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[C,0],p[A,0])]*r[A][1][9,1]*r[B][4][12,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,1],p[A,0])]*r[A][1][9,1]*r[B][4][12,2]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[B,1],p[C,1])]*r[A][1][9,1]*r[B][4][12,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[B,1],p[C,0])]*r[A][1][9,1]*r[B][4][12,2]*r[C][33][1,3]
    hv += -1/2*g[dei(p[C,0],p[C,1],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][4][12,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[C,1],p[C,0],p[B,1],p[A,0])]*r[A][1][9,1]*r[B][4][12,2]*r[C][33][1,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,14)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[B,1],p[A,0],p[C,0],p[C,1])]*r[A][3][7,1]*r[B][6][14,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[C,1],p[C,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][48][0,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[C,0],p[A,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][30][0,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][48][0,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[B,1],p[C,1])]*r[A][3][7,1]*r[B][6][14,2]*r[C][30][0,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[B,1],p[C,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[C,0],p[C,1],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][30][0,3]
    hv += -1*g[dei(p[C,0],p[C,1],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[C,1],p[C,0],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][48][0,3]
    hv += -1*g[dei(p[C,1],p[C,0],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][33][0,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B14C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,14),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[B,1],p[A,0],p[C,0],p[C,1])]*r[A][3][7,1]*r[B][6][14,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[C,1],p[C,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][48][1,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[C,0],p[A,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][30][1,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][48][1,3]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[B,1],p[C,1])]*r[A][3][7,1]*r[B][6][14,2]*r[C][30][1,3]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[B,1],p[C,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[C,0],p[C,1],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][30][1,3]
    hv += -1*g[dei(p[C,0],p[C,1],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[C,1],p[C,0],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][48][1,3]
    hv += -1*g[dei(p[C,1],p[C,0],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][6][14,2]*r[C][33][1,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B12C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,12),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[B,1],p[A,1],p[C,0],p[C,0])]*r[A][5][10,1]*r[B][4][12,2]*r[C][9][2,3]
    hv += -1*g[dei(p[B,1],p[A,1],p[C,0],p[C,0])]*r[A][5][10,1]*r[B][4][12,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[C,1],p[C,1])]*r[A][5][10,1]*r[B][4][12,2]*r[C][39][2,3]
    hv += -1*g[dei(p[B,1],p[A,1],p[C,1],p[C,1])]*r[A][5][10,1]*r[B][4][12,2]*r[C][54][2,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,0],p[A,1])]*r[A][5][10,1]*r[B][4][12,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[C,1],p[A,1])]*r[A][5][10,1]*r[B][4][12,2]*r[C][39][2,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[B,1],p[C,0])]*r[A][5][10,1]*r[B][4][12,2]*r[C][9][2,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[B,1],p[C,1])]*r[A][5][10,1]*r[B][4][12,2]*r[C][39][2,3]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][4][12,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][4][12,2]*r[C][39][2,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B14C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,14),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[B,1],p[A,1],p[C,0],p[C,0])]*r[A][7][8,1]*r[B][6][14,2]*r[C][24][2,3]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[C,1],p[C,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][54][2,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,0],p[A,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][24][2,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][54][2,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[B,1],p[C,0])]*r[A][7][8,1]*r[B][6][14,2]*r[C][24][2,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[B,1],p[C,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][54][2,3]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][24][2,3]
    hv += -1*g[dei(p[C,0],p[C,0],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][9][2,3]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][54][2,3]
    hv += -1*g[dei(p[C,1],p[C,1],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][39][2,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,12)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[B,1],p[A,1],p[C,0],p[C,1])]*r[A][5][10,1]*r[B][4][12,2]*r[C][15][0,3]
    hv += -1*g[dei(p[B,1],p[A,1],p[C,0],p[C,1])]*r[A][5][10,1]*r[B][4][12,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[C,1],p[C,0])]*r[A][5][10,1]*r[B][4][12,2]*r[C][33][0,3]
    hv += -1*g[dei(p[B,1],p[A,1],p[C,1],p[C,0])]*r[A][5][10,1]*r[B][4][12,2]*r[C][48][0,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[C,0],p[A,1])]*r[A][5][10,1]*r[B][4][12,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,1],p[A,1])]*r[A][5][10,1]*r[B][4][12,2]*r[C][33][0,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[B,1],p[C,1])]*r[A][5][10,1]*r[B][4][12,2]*r[C][15][0,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[B,1],p[C,0])]*r[A][5][10,1]*r[B][4][12,2]*r[C][33][0,3]
    hv += -1/2*g[dei(p[C,0],p[C,1],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][4][12,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[C,1],p[C,0],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][4][12,2]*r[C][33][0,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B12C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,12),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[B,1],p[A,1],p[C,0],p[C,1])]*r[A][5][10,1]*r[B][4][12,2]*r[C][15][1,3]
    hv += -1*g[dei(p[B,1],p[A,1],p[C,0],p[C,1])]*r[A][5][10,1]*r[B][4][12,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[C,1],p[C,0])]*r[A][5][10,1]*r[B][4][12,2]*r[C][33][1,3]
    hv += -1*g[dei(p[B,1],p[A,1],p[C,1],p[C,0])]*r[A][5][10,1]*r[B][4][12,2]*r[C][48][1,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[C,0],p[A,1])]*r[A][5][10,1]*r[B][4][12,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,1],p[A,1])]*r[A][5][10,1]*r[B][4][12,2]*r[C][33][1,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[B,1],p[C,1])]*r[A][5][10,1]*r[B][4][12,2]*r[C][15][1,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[B,1],p[C,0])]*r[A][5][10,1]*r[B][4][12,2]*r[C][33][1,3]
    hv += -1/2*g[dei(p[C,0],p[C,1],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][4][12,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[C,1],p[C,0],p[B,1],p[A,1])]*r[A][5][10,1]*r[B][4][12,2]*r[C][33][1,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,14)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[B,1],p[A,1],p[C,0],p[C,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][30][0,3]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[C,1],p[C,0])]*r[A][7][8,1]*r[B][6][14,2]*r[C][48][0,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[C,0],p[A,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][30][0,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][48][0,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[B,1],p[C,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][30][0,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[B,1],p[C,0])]*r[A][7][8,1]*r[B][6][14,2]*r[C][48][0,3]
    hv += -1/2*g[dei(p[C,0],p[C,1],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][30][0,3]
    hv += -1*g[dei(p[C,0],p[C,1],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][15][0,3]
    hv += -1/2*g[dei(p[C,1],p[C,0],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][48][0,3]
    hv += -1*g[dei(p[C,1],p[C,0],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][33][0,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B14C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,14),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[B,1],p[A,1],p[C,0],p[C,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][30][1,3]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[C,1],p[C,0])]*r[A][7][8,1]*r[B][6][14,2]*r[C][48][1,3]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[C,0],p[A,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][30][1,3]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][48][1,3]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[B,1],p[C,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][30][1,3]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[B,1],p[C,0])]*r[A][7][8,1]*r[B][6][14,2]*r[C][48][1,3]
    hv += -1/2*g[dei(p[C,0],p[C,1],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][30][1,3]
    hv += -1*g[dei(p[C,0],p[C,1],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][15][1,3]
    hv += -1/2*g[dei(p[C,1],p[C,0],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][48][1,3]
    hv += -1*g[dei(p[C,1],p[C,0],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][6][14,2]*r[C][33][1,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B11C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,11),(C,5)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,0],p[C,0],p[C,0],p[A,0])]*r[A][3][7,1]*r[B][0][11,2]*r[C][21][5,3]
    hv += g[dei(p[B,0],p[C,1],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][0][11,2]*r[C][51][5,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B11C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,11),(C,5)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,0],p[C,0],p[C,0],p[A,1])]*r[A][7][8,1]*r[B][0][11,2]*r[C][21][5,3]
    hv += g[dei(p[B,0],p[C,1],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][0][11,2]*r[C][51][5,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B12C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,12),(C,5)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,1],p[C,0],p[C,0],p[A,0])]*r[A][3][7,1]*r[B][4][12,2]*r[C][21][5,3]
    hv += g[dei(p[B,1],p[C,1],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][4][12,2]*r[C][51][5,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B12C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,12),(C,5)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,1],p[C,0],p[C,0],p[A,1])]*r[A][7][8,1]*r[B][4][12,2]*r[C][21][5,3]
    hv += g[dei(p[B,1],p[C,1],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][4][12,2]*r[C][51][5,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A5B8C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,5),(B,8),(C,11)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[C,0],p[A,1],p[A,0],p[B,0])]*r[A][27][5,1]*r[B][3][8,2]*r[C][0][11,3]
    hv += g[dei(p[C,0],p[A,0],p[A,1],p[B,0])]*r[A][45][5,1]*r[B][3][8,2]*r[C][0][11,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A5B7C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,5),(B,7),(C,11)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[C,0],p[A,1],p[A,0],p[B,1])]*r[A][27][5,1]*r[B][7][7,2]*r[C][0][11,3]
    hv += g[dei(p[C,0],p[A,0],p[A,1],p[B,1])]*r[A][45][5,1]*r[B][7][7,2]*r[C][0][11,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A5B8C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,5),(B,8),(C,12)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[C,1],p[A,1],p[A,0],p[B,0])]*r[A][27][5,1]*r[B][3][8,2]*r[C][4][12,3]
    hv += g[dei(p[C,1],p[A,0],p[A,1],p[B,0])]*r[A][45][5,1]*r[B][3][8,2]*r[C][4][12,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A5B7C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,5),(B,7),(C,12)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[C,1],p[A,1],p[A,0],p[B,1])]*r[A][27][5,1]*r[B][7][7,2]*r[C][4][12,3]
    hv += g[dei(p[C,1],p[A,0],p[A,1],p[B,1])]*r[A][45][5,1]*r[B][7][7,2]*r[C][4][12,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B6C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,6),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[C,0],p[B,0],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][46][6,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[B,1],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][28][6,2]*r[C][0][11,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B6C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,6),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[C,0],p[B,0],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][46][6,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[B,1],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][28][6,2]*r[C][0][11,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B6C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,6),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[C,1],p[B,0],p[A,0],p[B,1])]*r[A][2][14,1]*r[B][46][6,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[B,1],p[A,0],p[B,0])]*r[A][2][14,1]*r[B][28][6,2]*r[C][4][12,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B6C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,6),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[C,1],p[B,0],p[A,1],p[B,1])]*r[A][6][13,1]*r[B][46][6,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[B,1],p[A,1],p[B,0])]*r[A][6][13,1]*r[B][28][6,2]*r[C][4][12,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B10C4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,10),(C,4)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[C,0],p[B,0],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][1][10,2]*r[C][12][4,3]
    hv += -1*g[dei(p[C,1],p[B,0],p[A,0],p[C,1])]*r[A][2][14,1]*r[B][1][10,2]*r[C][42][4,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B9C4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,9),(C,4)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[C,0],p[B,1],p[A,0],p[C,0])]*r[A][2][14,1]*r[B][5][9,2]*r[C][12][4,3]
    hv += -1*g[dei(p[C,1],p[B,1],p[A,0],p[C,1])]*r[A][2][14,1]*r[B][5][9,2]*r[C][42][4,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B10C4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,10),(C,4)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[C,0],p[B,0],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][1][10,2]*r[C][12][4,3]
    hv += -1*g[dei(p[C,1],p[B,0],p[A,1],p[C,1])]*r[A][6][13,1]*r[B][1][10,2]*r[C][42][4,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B9C4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,9),(C,4)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[C,0],p[B,1],p[A,1],p[C,0])]*r[A][6][13,1]*r[B][5][9,2]*r[C][12][4,3]
    hv += -1*g[dei(p[C,1],p[B,1],p[A,1],p[C,1])]*r[A][6][13,1]*r[B][5][9,2]*r[C][42][4,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A6B13C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,6),(B,13),(C,11)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[C,0],p[A,0],p[B,0],p[A,0])]*r[A][22][6,1]*r[B][2][13,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[A,1],p[B,0],p[A,1])]*r[A][52][6,1]*r[B][2][13,2]*r[C][0][11,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A6B14C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,6),(B,14),(C,11)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[C,0],p[A,0],p[B,1],p[A,0])]*r[A][22][6,1]*r[B][6][14,2]*r[C][0][11,3]
    hv += -1*g[dei(p[C,0],p[A,1],p[B,1],p[A,1])]*r[A][52][6,1]*r[B][6][14,2]*r[C][0][11,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A6B13C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,6),(B,13),(C,12)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[C,1],p[A,0],p[B,0],p[A,0])]*r[A][22][6,1]*r[B][2][13,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[A,1],p[B,0],p[A,1])]*r[A][52][6,1]*r[B][2][13,2]*r[C][4][12,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A6B14C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,6),(B,14),(C,12)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[C,1],p[A,0],p[B,1],p[A,0])]*r[A][22][6,1]*r[B][6][14,2]*r[C][4][12,3]
    hv += -1*g[dei(p[C,1],p[A,1],p[B,1],p[A,1])]*r[A][52][6,1]*r[B][6][14,2]*r[C][4][12,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B13C4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,13),(C,4)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[C,0],p[A,0],p[B,0],p[C,0])]*r[A][1][9,1]*r[B][2][13,2]*r[C][12][4,3]
    hv += g[dei(p[C,1],p[A,0],p[B,0],p[C,1])]*r[A][1][9,1]*r[B][2][13,2]*r[C][42][4,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B13C4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,13),(C,4)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[C,0],p[A,1],p[B,0],p[C,0])]*r[A][5][10,1]*r[B][2][13,2]*r[C][12][4,3]
    hv += g[dei(p[C,1],p[A,1],p[B,0],p[C,1])]*r[A][5][10,1]*r[B][2][13,2]*r[C][42][4,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B14C4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,14),(C,4)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[C,0],p[A,0],p[B,1],p[C,0])]*r[A][1][9,1]*r[B][6][14,2]*r[C][12][4,3]
    hv += g[dei(p[C,1],p[A,0],p[B,1],p[C,1])]*r[A][1][9,1]*r[B][6][14,2]*r[C][42][4,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B14C4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,14),(C,4)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[C,0],p[A,1],p[B,1],p[C,0])]*r[A][5][10,1]*r[B][6][14,2]*r[C][12][4,3]
    hv += g[dei(p[C,1],p[A,1],p[B,1],p[C,1])]*r[A][5][10,1]*r[B][6][14,2]*r[C][42][4,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B5C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,5),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,0],p[B,0],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][21][5,2]*r[C][0][11,3]
    hv += g[dei(p[C,0],p[B,1],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][51][5,2]*r[C][0][11,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B5C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,5),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,0],p[B,0],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][21][5,2]*r[C][0][11,3]
    hv += g[dei(p[C,0],p[B,1],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][51][5,2]*r[C][0][11,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B5C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,5),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,1],p[B,0],p[B,0],p[A,0])]*r[A][3][7,1]*r[B][21][5,2]*r[C][4][12,3]
    hv += g[dei(p[C,1],p[B,1],p[B,1],p[A,0])]*r[A][3][7,1]*r[B][51][5,2]*r[C][4][12,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B5C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,5),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,1],p[B,0],p[B,0],p[A,1])]*r[A][7][8,1]*r[B][21][5,2]*r[C][4][12,3]
    hv += g[dei(p[C,1],p[B,1],p[B,1],p[A,1])]*r[A][7][8,1]*r[B][51][5,2]*r[C][4][12,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B8C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,8),(C,15)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[C,0],p[A,0],p[C,1],p[B,0])]*r[A][1][9,1]*r[B][3][8,2]*r[C][17][15,3]
    hv += -1*g[dei(p[C,1],p[A,0],p[C,0],p[B,0])]*r[A][1][9,1]*r[B][3][8,2]*r[C][35][15,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B7C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,7),(C,15)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[C,0],p[A,0],p[C,1],p[B,1])]*r[A][1][9,1]*r[B][7][7,2]*r[C][17][15,3]
    hv += -1*g[dei(p[C,1],p[A,0],p[C,0],p[B,1])]*r[A][1][9,1]*r[B][7][7,2]*r[C][35][15,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B8C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,8),(C,15)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[C,0],p[A,1],p[C,1],p[B,0])]*r[A][5][10,1]*r[B][3][8,2]*r[C][17][15,3]
    hv += -1*g[dei(p[C,1],p[A,1],p[C,0],p[B,0])]*r[A][5][10,1]*r[B][3][8,2]*r[C][35][15,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B7C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,7),(C,15)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[C,0],p[A,1],p[C,1],p[B,1])]*r[A][5][10,1]*r[B][7][7,2]*r[C][17][15,3]
    hv += -1*g[dei(p[C,1],p[A,1],p[C,0],p[B,1])]*r[A][5][10,1]*r[B][7][7,2]*r[C][35][15,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B10C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,10),(C,15)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[C,0],p[B,0],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][1][10,2]*r[C][17][15,3]
    hv += g[dei(p[C,1],p[B,0],p[C,0],p[A,0])]*r[A][3][7,1]*r[B][1][10,2]*r[C][35][15,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B10C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,10),(C,15)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[C,0],p[B,0],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][1][10,2]*r[C][17][15,3]
    hv += g[dei(p[C,1],p[B,0],p[C,0],p[A,1])]*r[A][7][8,1]*r[B][1][10,2]*r[C][35][15,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B9C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,9),(C,15)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[C,0],p[B,1],p[C,1],p[A,0])]*r[A][3][7,1]*r[B][5][9,2]*r[C][17][15,3]
    hv += g[dei(p[C,1],p[B,1],p[C,0],p[A,0])]*r[A][3][7,1]*r[B][5][9,2]*r[C][35][15,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B9C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,9),(C,15)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[C,0],p[B,1],p[C,1],p[A,1])]*r[A][7][8,1]*r[B][5][9,2]*r[C][17][15,3]
    hv += g[dei(p[C,1],p[B,1],p[C,0],p[A,1])]*r[A][7][8,1]*r[B][5][9,2]*r[C][35][15,3]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def hm_A1B2C3(r, h, g, p, nc=0):
    np=len(p)
    hdd = {}
    
    for A in range(nc, np):
        for B in range(nc, np):
            if B in {A}: continue
            for C in range(nc, np):
                if C in {A,B}: continue
                u = tuple(sorted([(A,1),(B,2),(C,3)]))
                
                hd = {}
                for v,hv in _A1B2C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B2C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B2C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B3C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B1C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B2C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B2C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C3I1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C3I2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C3I3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C3I1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C3I2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C3I3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B2I1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B2I2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B2I3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B10C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B8C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B9C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B7C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B10C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B8C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B9C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B7C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B11C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B13C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B11C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B13C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B12C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B14C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B12C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B14C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A15B6C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B3C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B1C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B3C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B3C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B1C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B1C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A4B5C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A5B4C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A6B15C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B2C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B2C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B2C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B2C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B2C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B2C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B2C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B2C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B2C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B2C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B2C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B2C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B2C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B2C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B2C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B2C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A15B2C6(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B2C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B2C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B2C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B2C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A4B2C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A5B2C4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A6B2C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B11C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B13C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B11C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B13C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B12C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B14C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B12C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B14C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B10C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B8C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B9C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B7C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B10C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B8C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B9C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B7C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B15C6(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B3C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B3C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B1C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B1C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B4C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B5C4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B6C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B11C3I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B13C3I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B11C3I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B13C3I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B12C3I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B14C3I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B12C3I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B14C3I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12C3I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14C3I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12C3I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14C3I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11C3I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13C3I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11C3I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13C3I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B10C3I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B8C3I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B9C3I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B7C3I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B10C3I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B8C3I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B9C3I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B7C3I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9C3I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C3I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10C3I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C3I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9C3I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C3I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10C3I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C3I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C11I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C13I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C11I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C13I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C12I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C14I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C12I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C14I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B2I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B2I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B2I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B2I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B2I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B2I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B2I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B2I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C10I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C8I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C9I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C7I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C10I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C8I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C9I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C7I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B2I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B2I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B2I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B2I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B2I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B2I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B2I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B2I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C11I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C13I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C11I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C13I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C12I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C14I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C12I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C14I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B11I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B13I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B11I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B13I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B12I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B14I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B12I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B14I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C10I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C8I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C9I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C7I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C10I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C8I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C9I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C7I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B10I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B8I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B9I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B7I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B10I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B8I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B9I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B7I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A15B10C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A15B10C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A15B9C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A15B9C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A15B8C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A15B7C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A15B8C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A15B7C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B11C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B13C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B11C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B13C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B11C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B11C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B13C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B13C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B11C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B11C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B13C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B13C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B12C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B14C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B12C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B14C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B12C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B12C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B14C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B14C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B12C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B12C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B14C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B14C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B3C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B3C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B5C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B3C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B3C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B5C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B1C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B1C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B1C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B1C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B3C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B3C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B5C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B3C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B3C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B5C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B1C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B1C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B1C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B1C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A4B13C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A4B13C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A4B14C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A4B14C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B13C6(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B14C6(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B13C6(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B14C6(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B10C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B8C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B9C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B7C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B10C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B10C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B8C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B8C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B9C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B9C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B7C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B7C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B10C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B8C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B9C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B7C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B10C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B10C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B8C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B8C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B9C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B9C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B7C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B7C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A4B10C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A4B9C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A4B10C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A4B9C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B6C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B6C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B6C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B6C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B10C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B8C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B10C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B8C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B9C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B7C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B9C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B7C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B10C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B8C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B10C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B8C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B9C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B7C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B9C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B7C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B8C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B7C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B8C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B7C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A5B11C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A5B11C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A5B12C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A5B12C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B4C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B4C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B4C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B4C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B11C6(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B11C6(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B12C6(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B12C6(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B15C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B15C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B15C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B15C7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B15C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B15C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B15C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B15C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A6B11C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A6B11C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A6B12C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A6B12C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B3C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B3C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B4C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B1C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B1C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B3C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B3C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B4C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B1C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B1C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B3C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B3C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B4C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B1C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B1C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B3C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B3C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B4C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B1C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B1C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B11C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B13C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B11C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B13C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B11C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B13C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B11C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B13C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B12C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B14C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B12C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B14C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B12C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B14C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B12C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B14C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B11C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B11C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B12C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B12C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A5B8C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A5B7C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A5B8C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A5B7C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B6C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B6C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B6C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B6C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B10C4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B9C4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B10C4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B9C4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A6B13C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A6B14C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A6B13C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A6B14C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B13C4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B13C4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B14C4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B14C4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B5C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B5C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B5C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B5C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B8C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B7C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B8C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B7C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B10C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B10C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B9C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B9C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                
                hdd[u] = hd
                
    return hdd
    

