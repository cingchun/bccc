#!/usr/bin/env python 
# -*- coding: utf-8 -*- 
# 
# Author: Qingchun Wang @ NJU 
# E-mail: qingchun720@foxmail.com 
# 


import numpy
from bccc.pub import sign,dei


def _A3B4C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,4),(C,5)]))
    hv = 0.0
    
    hv += sum(h[p[I,0],p[I,0]]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(h[p[I,0],p[I,0]]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(h[p[I,1],p[I,1]]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(h[p[I,1],p[I,1]]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[I,0],p[I,0])]*r[I][194][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,1],p[I,0],p[I,1])]*r[I][199][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,0],p[I,1],p[I,0])]*r[I][274][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[I,1],p[I,1])]*r[I][279][0,0] for I in range(np) if I not in {A,B,C})
    hv += h[p[A,0],p[A,0]]*r[A][9][3,3]
    hv += h[p[A,0],p[A,0]]*r[A][24][3,3]
    hv += h[p[A,1],p[A,1]]*r[A][39][3,3]
    hv += h[p[A,1],p[A,1]]*r[A][54][3,3]
    hv += g[dei(p[A,0],p[A,0],p[A,1],p[A,1])]*r[A][214][3,3]
    hv += g[dei(p[A,0],p[A,1],p[A,1],p[A,0])]*r[A][211][3,3]
    hv += g[dei(p[A,1],p[A,0],p[A,0],p[A,1])]*r[A][262][3,3]
    hv += g[dei(p[A,1],p[A,1],p[A,0],p[A,0])]*r[A][259][3,3]
    hv += h[p[B,0],p[B,0]]*r[B][9][4,4]
    hv += h[p[B,1],p[B,1]]*r[B][39][4,4]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[B,1],p[B,1])]*r[B][204][4,4]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[B,1],p[B,0])]*r[B][201][4,4]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[B,0],p[B,1])]*r[B][252][4,4]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[B,0],p[B,0])]*r[B][249][4,4]
    hv += h[p[C,0],p[C,0]]*r[C][24][5,5]
    hv += h[p[C,1],p[C,1]]*r[C][54][5,5]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[C,1],p[C,1])]*r[C][246][5,5]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[C,1],p[C,0])]*r[C][243][5,5]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[C,0],p[C,1])]*r[C][294][5,5]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[C,0],p[C,0])]*r[C][291][5,5]
    hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][9][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][24][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][9][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][9][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][24][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][9][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][39][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][54][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][39][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][39][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][54][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][39][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,0])]*r[I][9][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,0])]*r[I][24][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,0])]*r[I][9][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,0])]*r[I][24][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,1])]*r[I][39][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,1])]*r[I][54][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,1])]*r[I][39][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,1])]*r[I][54][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,0],p[J,0])]*r[I][9][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,0],p[J,0])]*r[I][24][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,1],p[J,0])]*r[I][39][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,1],p[J,0])]*r[I][54][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,0],p[J,1])]*r[I][9][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,0],p[J,1])]*r[I][24][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,1],p[J,1])]*r[I][39][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,1],p[J,1])]*r[I][54][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[I][9][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[I][24][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[I][24][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[I][39][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[I][54][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[I][54][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[I][9][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[I][24][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[I][24][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[I][39][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[I][54][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[I][54][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][9][3,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][24][3,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][9][3,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][9][3,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][24][3,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][9][3,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,0],p[I,0])]*r[A][39][3,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,0],p[I,0])]*r[A][54][3,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,1],p[I,0],p[I,0])]*r[A][39][3,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,1],p[I,1])]*r[A][39][3,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,1],p[I,1])]*r[A][54][3,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,1],p[I,1],p[I,1])]*r[A][39][3,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,0])]*r[A][9][3,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,0])]*r[A][24][3,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,0])]*r[A][9][3,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,0])]*r[A][24][3,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,1])]*r[A][39][3,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,1])]*r[A][54][3,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,1])]*r[A][39][3,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,1])]*r[A][54][3,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,0])]*r[A][9][3,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,0])]*r[A][24][3,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,1],p[I,0])]*r[A][39][3,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,1],p[I,0])]*r[A][54][3,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,1])]*r[A][9][3,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,1])]*r[A][24][3,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,1],p[I,1])]*r[A][39][3,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,1],p[I,1])]*r[A][54][3,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][9][3,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][24][3,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][24][3,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,1])]*r[A][39][3,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,1])]*r[A][54][3,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,1],p[A,1])]*r[A][54][3,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][9][3,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][24][3,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][24][3,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,1])]*r[A][39][3,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,1])]*r[A][54][3,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,1],p[A,1])]*r[A][54][3,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[B,0],p[I,0],p[I,0])]*r[B][9][4,4]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,0],p[B,0],p[I,0],p[I,0])]*r[B][9][4,4]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[B,0],p[I,1],p[I,1])]*r[B][9][4,4]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,0],p[B,0],p[I,1],p[I,1])]*r[B][9][4,4]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[B,1],p[I,0],p[I,0])]*r[B][39][4,4]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,1],p[B,1],p[I,0],p[I,0])]*r[B][39][4,4]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[B,1],p[I,1],p[I,1])]*r[B][39][4,4]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,1],p[B,1],p[I,1],p[I,1])]*r[B][39][4,4]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,0],p[I,0],p[B,0])]*r[B][9][4,4]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,1],p[I,1],p[B,0])]*r[B][9][4,4]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,0],p[I,0],p[B,1])]*r[B][39][4,4]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,1],p[I,1],p[B,1])]*r[B][39][4,4]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,0],p[B,0],p[I,0])]*r[B][9][4,4]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,1],p[B,1],p[I,0])]*r[B][39][4,4]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,0],p[B,0],p[I,1])]*r[B][9][4,4]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,1],p[B,1],p[I,1])]*r[B][39][4,4]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,0],p[B,0])]*r[B][9][4,4]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,1],p[B,1])]*r[B][39][4,4]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,0],p[B,0])]*r[B][9][4,4]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,1],p[B,1])]*r[B][39][4,4]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[C,0],p[I,0],p[I,0])]*r[C][24][5,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[C,0],p[I,1],p[I,1])]*r[C][24][5,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[C,1],p[I,0],p[I,0])]*r[C][54][5,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[C,1],p[I,1],p[I,1])]*r[C][54][5,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,0],p[I,0],p[C,0])]*r[C][24][5,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,1],p[I,1],p[C,0])]*r[C][24][5,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,0],p[I,0],p[C,1])]*r[C][54][5,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,1],p[I,1],p[C,1])]*r[C][54][5,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,0],p[C,0],p[I,0])]*r[C][24][5,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,1],p[C,1],p[I,0])]*r[C][54][5,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,0],p[C,0],p[I,1])]*r[C][24][5,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,1],p[C,1],p[I,1])]*r[C][54][5,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,0],p[C,0])]*r[C][24][5,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[C,0],p[C,0])]*r[C][24][5,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,1],p[C,1])]*r[C][54][5,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[C,1],p[C,1])]*r[C][54][5,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,0],p[C,0])]*r[C][24][5,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[C,0],p[C,0])]*r[C][24][5,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,1],p[C,1])]*r[C][54][5,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[C,1],p[C,1])]*r[C][54][5,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[B,0])]*r[A][9][3,3]*r[B][9][4,4]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[B,1])]*r[A][9][3,3]*r[B][39][4,4]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[B,0])]*r[A][39][3,3]*r[B][9][4,4]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[B,1])]*r[A][39][3,3]*r[B][39][4,4]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[A,0])]*r[A][9][3,3]*r[B][9][4,4]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[A,0])]*r[A][9][3,3]*r[B][39][4,4]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[A,1])]*r[A][39][3,3]*r[B][9][4,4]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[A,1])]*r[A][39][3,3]*r[B][39][4,4]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[B,0])]*r[A][9][3,3]*r[B][9][4,4]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[B,0])]*r[A][39][3,3]*r[B][9][4,4]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[B,1])]*r[A][9][3,3]*r[B][39][4,4]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[B,1])]*r[A][39][3,3]*r[B][39][4,4]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[A,0])]*r[A][9][3,3]*r[B][9][4,4]
    hv += g[dei(p[B,0],p[B,0],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][9][4,4]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[A,1])]*r[A][39][3,3]*r[B][9][4,4]
    hv += g[dei(p[B,0],p[B,0],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][9][4,4]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[A,0])]*r[A][9][3,3]*r[B][39][4,4]
    hv += g[dei(p[B,1],p[B,1],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][39][4,4]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[A,1])]*r[A][39][3,3]*r[B][39][4,4]
    hv += g[dei(p[B,1],p[B,1],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][39][4,4]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[C,0])]*r[A][24][3,3]*r[C][24][5,5]
    hv += g[dei(p[A,0],p[A,0],p[C,0],p[C,0])]*r[A][9][3,3]*r[C][24][5,5]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[C,1])]*r[A][24][3,3]*r[C][54][5,5]
    hv += g[dei(p[A,0],p[A,0],p[C,1],p[C,1])]*r[A][9][3,3]*r[C][54][5,5]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[C,0])]*r[A][54][3,3]*r[C][24][5,5]
    hv += g[dei(p[A,1],p[A,1],p[C,0],p[C,0])]*r[A][39][3,3]*r[C][24][5,5]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[C,1])]*r[A][54][3,3]*r[C][54][5,5]
    hv += g[dei(p[A,1],p[A,1],p[C,1],p[C,1])]*r[A][39][3,3]*r[C][54][5,5]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,0])]*r[A][24][3,3]*r[C][24][5,5]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,0])]*r[A][24][3,3]*r[C][54][5,5]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,1])]*r[A][54][3,3]*r[C][24][5,5]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,1])]*r[A][54][3,3]*r[C][54][5,5]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[C,0])]*r[A][24][3,3]*r[C][24][5,5]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[C,0])]*r[A][54][3,3]*r[C][24][5,5]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[C,1])]*r[A][24][3,3]*r[C][54][5,5]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[C,1])]*r[A][54][3,3]*r[C][54][5,5]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,0])]*r[A][24][3,3]*r[C][24][5,5]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,1])]*r[A][54][3,3]*r[C][24][5,5]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,0])]*r[A][24][3,3]*r[C][54][5,5]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,1])]*r[A][54][3,3]*r[C][54][5,5]
    hv += g[dei(p[B,0],p[B,0],p[C,0],p[C,0])]*r[B][9][4,4]*r[C][24][5,5]
    hv += g[dei(p[B,0],p[B,0],p[C,1],p[C,1])]*r[B][9][4,4]*r[C][54][5,5]
    hv += g[dei(p[B,1],p[B,1],p[C,0],p[C,0])]*r[B][39][4,4]*r[C][24][5,5]
    hv += g[dei(p[B,1],p[B,1],p[C,1],p[C,1])]*r[B][39][4,4]*r[C][54][5,5]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A2B4C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(B,4),(C,5)]))
    hv = 0.0
    
    hv += h[p[A,0],p[A,0]]*r[A][9][2,3]
    hv += h[p[A,0],p[A,0]]*r[A][24][2,3]
    hv += h[p[A,1],p[A,1]]*r[A][39][2,3]
    hv += h[p[A,1],p[A,1]]*r[A][54][2,3]
    hv += g[dei(p[A,0],p[A,0],p[A,1],p[A,1])]*r[A][214][2,3]
    hv += g[dei(p[A,0],p[A,1],p[A,1],p[A,0])]*r[A][211][2,3]
    hv += g[dei(p[A,1],p[A,0],p[A,0],p[A,1])]*r[A][262][2,3]
    hv += g[dei(p[A,1],p[A,1],p[A,0],p[A,0])]*r[A][259][2,3]
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][9][2,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][24][2,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][9][2,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][9][2,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][24][2,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][9][2,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,0],p[I,0])]*r[A][39][2,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,0],p[I,0])]*r[A][54][2,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,1],p[I,0],p[I,0])]*r[A][39][2,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,1],p[I,1])]*r[A][39][2,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,1],p[I,1])]*r[A][54][2,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,1],p[I,1],p[I,1])]*r[A][39][2,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,0])]*r[A][9][2,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,0])]*r[A][24][2,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,0])]*r[A][9][2,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,0])]*r[A][24][2,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,1])]*r[A][39][2,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,1])]*r[A][54][2,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,1])]*r[A][39][2,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,1])]*r[A][54][2,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,0])]*r[A][9][2,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,0])]*r[A][24][2,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,1],p[I,0])]*r[A][39][2,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,1],p[I,0])]*r[A][54][2,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,1])]*r[A][9][2,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,1])]*r[A][24][2,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,1],p[I,1])]*r[A][39][2,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,1],p[I,1])]*r[A][54][2,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][9][2,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][24][2,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][24][2,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,1])]*r[A][39][2,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,1])]*r[A][54][2,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,1],p[A,1])]*r[A][54][2,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][9][2,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][24][2,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][24][2,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,1])]*r[A][39][2,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,1])]*r[A][54][2,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,1],p[A,1])]*r[A][54][2,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[B,0])]*r[A][9][2,3]*r[B][9][4,4]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[B,1])]*r[A][9][2,3]*r[B][39][4,4]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[B,0])]*r[A][39][2,3]*r[B][9][4,4]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[B,1])]*r[A][39][2,3]*r[B][39][4,4]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[A,0])]*r[A][9][2,3]*r[B][9][4,4]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[A,0])]*r[A][9][2,3]*r[B][39][4,4]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[A,1])]*r[A][39][2,3]*r[B][9][4,4]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[A,1])]*r[A][39][2,3]*r[B][39][4,4]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[B,0])]*r[A][9][2,3]*r[B][9][4,4]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[B,0])]*r[A][39][2,3]*r[B][9][4,4]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[B,1])]*r[A][9][2,3]*r[B][39][4,4]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[B,1])]*r[A][39][2,3]*r[B][39][4,4]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[A,0])]*r[A][9][2,3]*r[B][9][4,4]
    hv += g[dei(p[B,0],p[B,0],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][9][4,4]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[A,1])]*r[A][39][2,3]*r[B][9][4,4]
    hv += g[dei(p[B,0],p[B,0],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][9][4,4]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[A,0])]*r[A][9][2,3]*r[B][39][4,4]
    hv += g[dei(p[B,1],p[B,1],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][39][4,4]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[A,1])]*r[A][39][2,3]*r[B][39][4,4]
    hv += g[dei(p[B,1],p[B,1],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][39][4,4]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[C,0])]*r[A][24][2,3]*r[C][24][5,5]
    hv += g[dei(p[A,0],p[A,0],p[C,0],p[C,0])]*r[A][9][2,3]*r[C][24][5,5]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[C,1])]*r[A][24][2,3]*r[C][54][5,5]
    hv += g[dei(p[A,0],p[A,0],p[C,1],p[C,1])]*r[A][9][2,3]*r[C][54][5,5]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[C,0])]*r[A][54][2,3]*r[C][24][5,5]
    hv += g[dei(p[A,1],p[A,1],p[C,0],p[C,0])]*r[A][39][2,3]*r[C][24][5,5]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[C,1])]*r[A][54][2,3]*r[C][54][5,5]
    hv += g[dei(p[A,1],p[A,1],p[C,1],p[C,1])]*r[A][39][2,3]*r[C][54][5,5]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,0])]*r[A][24][2,3]*r[C][24][5,5]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,0])]*r[A][24][2,3]*r[C][54][5,5]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,1])]*r[A][54][2,3]*r[C][24][5,5]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,1])]*r[A][54][2,3]*r[C][54][5,5]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[C,0])]*r[A][24][2,3]*r[C][24][5,5]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[C,0])]*r[A][54][2,3]*r[C][24][5,5]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[C,1])]*r[A][24][2,3]*r[C][54][5,5]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[C,1])]*r[A][54][2,3]*r[C][54][5,5]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,0])]*r[A][24][2,3]*r[C][24][5,5]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,1])]*r[A][54][2,3]*r[C][24][5,5]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,0])]*r[A][24][2,3]*r[C][54][5,5]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,1])]*r[A][54][2,3]*r[C][54][5,5]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _B4C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(B,4),(C,5)]))
    hv = 0.0
    
    hv += h[p[A,0],p[A,1]]*r[A][15][0,3]
    hv += h[p[A,0],p[A,1]]*r[A][30][0,3]
    hv += h[p[A,1],p[A,0]]*r[A][33][0,3]
    hv += h[p[A,1],p[A,0]]*r[A][48][0,3]
    hv += g[dei(p[A,0],p[A,0],p[A,0],p[A,1])]*r[A][198][0,3]
    hv += g[dei(p[A,0],p[A,1],p[A,0],p[A,0])]*r[A][195][0,3]
    hv += g[dei(p[A,1],p[A,0],p[A,1],p[A,1])]*r[A][278][0,3]
    hv += g[dei(p[A,1],p[A,1],p[A,1],p[A,0])]*r[A][275][0,3]
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,0],p[I,0])]*r[A][15][0,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,0],p[I,0])]*r[A][30][0,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,1],p[I,0],p[I,0])]*r[A][15][0,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,1],p[I,1])]*r[A][15][0,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,1],p[I,1])]*r[A][30][0,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,1],p[I,1],p[I,1])]*r[A][15][0,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][33][0,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][48][0,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][33][0,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][33][0,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][48][0,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][33][0,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,1])]*r[A][15][0,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,1])]*r[A][30][0,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,1])]*r[A][15][0,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,1])]*r[A][30][0,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,0])]*r[A][33][0,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,0])]*r[A][48][0,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,0])]*r[A][33][0,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,0])]*r[A][48][0,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,0],p[I,0])]*r[A][15][0,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,0],p[I,0])]*r[A][30][0,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,0])]*r[A][33][0,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,0])]*r[A][48][0,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,0],p[I,1])]*r[A][15][0,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,0],p[I,1])]*r[A][30][0,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,1])]*r[A][33][0,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,1])]*r[A][48][0,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,1])]*r[A][15][0,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][33][0,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,1])]*r[A][15][0,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][33][0,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[B,0])]*r[A][15][0,3]*r[B][9][4,4]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[B,1])]*r[A][15][0,3]*r[B][39][4,4]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[B,0])]*r[A][33][0,3]*r[B][9][4,4]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[B,1])]*r[A][33][0,3]*r[B][39][4,4]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[A,1])]*r[A][15][0,3]*r[B][9][4,4]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[A,1])]*r[A][15][0,3]*r[B][39][4,4]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[A,0])]*r[A][33][0,3]*r[B][9][4,4]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[A,0])]*r[A][33][0,3]*r[B][39][4,4]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[B,0])]*r[A][15][0,3]*r[B][9][4,4]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[B,0])]*r[A][33][0,3]*r[B][9][4,4]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[B,1])]*r[A][15][0,3]*r[B][39][4,4]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[B,1])]*r[A][33][0,3]*r[B][39][4,4]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[A,1])]*r[A][15][0,3]*r[B][9][4,4]
    hv += g[dei(p[B,0],p[B,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][9][4,4]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[A,0])]*r[A][33][0,3]*r[B][9][4,4]
    hv += g[dei(p[B,0],p[B,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][9][4,4]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[A,1])]*r[A][15][0,3]*r[B][39][4,4]
    hv += g[dei(p[B,1],p[B,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][39][4,4]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[A,0])]*r[A][33][0,3]*r[B][39][4,4]
    hv += g[dei(p[B,1],p[B,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][39][4,4]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,0],p[C,0])]*r[A][30][0,3]*r[C][24][5,5]
    hv += g[dei(p[A,0],p[A,1],p[C,0],p[C,0])]*r[A][15][0,3]*r[C][24][5,5]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,1],p[C,1])]*r[A][30][0,3]*r[C][54][5,5]
    hv += g[dei(p[A,0],p[A,1],p[C,1],p[C,1])]*r[A][15][0,3]*r[C][54][5,5]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,0],p[C,0])]*r[A][48][0,3]*r[C][24][5,5]
    hv += g[dei(p[A,1],p[A,0],p[C,0],p[C,0])]*r[A][33][0,3]*r[C][24][5,5]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,1],p[C,1])]*r[A][48][0,3]*r[C][54][5,5]
    hv += g[dei(p[A,1],p[A,0],p[C,1],p[C,1])]*r[A][33][0,3]*r[C][54][5,5]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,1])]*r[A][30][0,3]*r[C][24][5,5]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,1])]*r[A][30][0,3]*r[C][54][5,5]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,0])]*r[A][48][0,3]*r[C][24][5,5]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,0])]*r[A][48][0,3]*r[C][54][5,5]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,0],p[C,0])]*r[A][30][0,3]*r[C][24][5,5]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,1],p[C,0])]*r[A][48][0,3]*r[C][24][5,5]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,0],p[C,1])]*r[A][30][0,3]*r[C][54][5,5]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,1],p[C,1])]*r[A][48][0,3]*r[C][54][5,5]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[C][24][5,5]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[C][24][5,5]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[C][54][5,5]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[C][54][5,5]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A1B4C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,4),(C,5)]))
    hv = 0.0
    
    hv += h[p[A,0],p[A,1]]*r[A][15][1,3]
    hv += h[p[A,0],p[A,1]]*r[A][30][1,3]
    hv += h[p[A,1],p[A,0]]*r[A][33][1,3]
    hv += h[p[A,1],p[A,0]]*r[A][48][1,3]
    hv += g[dei(p[A,0],p[A,0],p[A,0],p[A,1])]*r[A][198][1,3]
    hv += g[dei(p[A,0],p[A,1],p[A,0],p[A,0])]*r[A][195][1,3]
    hv += g[dei(p[A,1],p[A,0],p[A,1],p[A,1])]*r[A][278][1,3]
    hv += g[dei(p[A,1],p[A,1],p[A,1],p[A,0])]*r[A][275][1,3]
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,0],p[I,0])]*r[A][15][1,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,0],p[I,0])]*r[A][30][1,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,1],p[I,0],p[I,0])]*r[A][15][1,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,1],p[I,1])]*r[A][15][1,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,1],p[I,1])]*r[A][30][1,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,1],p[I,1],p[I,1])]*r[A][15][1,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][33][1,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][48][1,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][33][1,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][33][1,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][48][1,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][33][1,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,1])]*r[A][15][1,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,1])]*r[A][30][1,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,1])]*r[A][15][1,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,1])]*r[A][30][1,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,0])]*r[A][33][1,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,0])]*r[A][48][1,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,0])]*r[A][33][1,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,0])]*r[A][48][1,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,0],p[I,0])]*r[A][15][1,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,0],p[I,0])]*r[A][30][1,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,0])]*r[A][33][1,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,0])]*r[A][48][1,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,0],p[I,1])]*r[A][15][1,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,0],p[I,1])]*r[A][30][1,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,1])]*r[A][33][1,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,1])]*r[A][48][1,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,1])]*r[A][15][1,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,1])]*r[A][30][1,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,0],p[A,1])]*r[A][30][1,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][33][1,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][48][1,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][48][1,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,1])]*r[A][15][1,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,1])]*r[A][30][1,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,0],p[A,1])]*r[A][30][1,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][33][1,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][48][1,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][48][1,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[B,0])]*r[A][15][1,3]*r[B][9][4,4]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[B,1])]*r[A][15][1,3]*r[B][39][4,4]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[B,0])]*r[A][33][1,3]*r[B][9][4,4]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[B,1])]*r[A][33][1,3]*r[B][39][4,4]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[A,1])]*r[A][15][1,3]*r[B][9][4,4]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[A,1])]*r[A][15][1,3]*r[B][39][4,4]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[A,0])]*r[A][33][1,3]*r[B][9][4,4]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[A,0])]*r[A][33][1,3]*r[B][39][4,4]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[B,0])]*r[A][15][1,3]*r[B][9][4,4]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[B,0])]*r[A][33][1,3]*r[B][9][4,4]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[B,1])]*r[A][15][1,3]*r[B][39][4,4]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[B,1])]*r[A][33][1,3]*r[B][39][4,4]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[A,1])]*r[A][15][1,3]*r[B][9][4,4]
    hv += g[dei(p[B,0],p[B,0],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][9][4,4]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[A,0])]*r[A][33][1,3]*r[B][9][4,4]
    hv += g[dei(p[B,0],p[B,0],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][9][4,4]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[A,1])]*r[A][15][1,3]*r[B][39][4,4]
    hv += g[dei(p[B,1],p[B,1],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][39][4,4]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[A,0])]*r[A][33][1,3]*r[B][39][4,4]
    hv += g[dei(p[B,1],p[B,1],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][39][4,4]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,0],p[C,0])]*r[A][30][1,3]*r[C][24][5,5]
    hv += g[dei(p[A,0],p[A,1],p[C,0],p[C,0])]*r[A][15][1,3]*r[C][24][5,5]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,1],p[C,1])]*r[A][30][1,3]*r[C][54][5,5]
    hv += g[dei(p[A,0],p[A,1],p[C,1],p[C,1])]*r[A][15][1,3]*r[C][54][5,5]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,0],p[C,0])]*r[A][48][1,3]*r[C][24][5,5]
    hv += g[dei(p[A,1],p[A,0],p[C,0],p[C,0])]*r[A][33][1,3]*r[C][24][5,5]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,1],p[C,1])]*r[A][48][1,3]*r[C][54][5,5]
    hv += g[dei(p[A,1],p[A,0],p[C,1],p[C,1])]*r[A][33][1,3]*r[C][54][5,5]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,1])]*r[A][30][1,3]*r[C][24][5,5]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,1])]*r[A][30][1,3]*r[C][54][5,5]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,0])]*r[A][48][1,3]*r[C][24][5,5]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,0])]*r[A][48][1,3]*r[C][54][5,5]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,0],p[C,0])]*r[A][30][1,3]*r[C][24][5,5]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,1],p[C,0])]*r[A][48][1,3]*r[C][24][5,5]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,0],p[C,1])]*r[A][30][1,3]*r[C][54][5,5]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,1],p[C,1])]*r[A][48][1,3]*r[C][54][5,5]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,1])]*r[A][30][1,3]*r[C][24][5,5]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,0])]*r[A][48][1,3]*r[C][24][5,5]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,1])]*r[A][30][1,3]*r[C][54][5,5]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,0])]*r[A][48][1,3]*r[C][54][5,5]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _B4C5I1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,4),(C,5),(I,1)]))
        hv = 0.0
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,0],p[I,0])]*r[A][15][0,3]*r[I][9][1,0]
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,0],p[I,0])]*r[A][30][0,3]*r[I][24][1,0]
        hv += g[dei(p[A,0],p[A,1],p[I,0],p[I,0])]*r[A][15][0,3]*r[I][24][1,0]
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,1],p[I,1])]*r[A][15][0,3]*r[I][39][1,0]
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,1],p[I,1])]*r[A][30][0,3]*r[I][54][1,0]
        hv += g[dei(p[A,0],p[A,1],p[I,1],p[I,1])]*r[A][15][0,3]*r[I][54][1,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][33][0,3]*r[I][9][1,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][48][0,3]*r[I][24][1,0]
        hv += g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][33][0,3]*r[I][24][1,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][33][0,3]*r[I][39][1,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][48][0,3]*r[I][54][1,0]
        hv += g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][33][0,3]*r[I][54][1,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,1])]*r[A][15][0,3]*r[I][9][1,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,1])]*r[A][30][0,3]*r[I][24][1,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,1])]*r[A][15][0,3]*r[I][39][1,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,1])]*r[A][30][0,3]*r[I][54][1,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,0])]*r[A][33][0,3]*r[I][9][1,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,0])]*r[A][48][0,3]*r[I][24][1,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,0])]*r[A][33][0,3]*r[I][39][1,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,0])]*r[A][48][0,3]*r[I][54][1,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,0],p[I,0])]*r[A][15][0,3]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,0],p[I,0])]*r[A][30][0,3]*r[I][24][1,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,0])]*r[A][33][0,3]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,0])]*r[A][48][0,3]*r[I][24][1,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,0],p[I,1])]*r[A][15][0,3]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,0],p[I,1])]*r[A][30][0,3]*r[I][54][1,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,1])]*r[A][33][0,3]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,1])]*r[A][48][0,3]*r[I][54][1,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,1])]*r[A][15][0,3]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][24][1,0]
        hv += g[dei(p[I,0],p[I,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][33][0,3]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][24][1,0]
        hv += g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,1])]*r[A][15][0,3]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][54][1,0]
        hv += g[dei(p[I,1],p[I,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][33][0,3]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][54][1,0]
        hv += g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    return hd
    
def _B4C5I2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,4),(C,5),(I,2)]))
        hv = 0.0
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,0],p[I,1])]*r[A][15][0,3]*r[I][15][2,0]
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,0],p[I,1])]*r[A][30][0,3]*r[I][30][2,0]
        hv += g[dei(p[A,0],p[A,1],p[I,0],p[I,1])]*r[A][15][0,3]*r[I][30][2,0]
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,1],p[I,0])]*r[A][15][0,3]*r[I][33][2,0]
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,1],p[I,0])]*r[A][30][0,3]*r[I][48][2,0]
        hv += g[dei(p[A,0],p[A,1],p[I,1],p[I,0])]*r[A][15][0,3]*r[I][48][2,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,1])]*r[A][33][0,3]*r[I][15][2,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,1])]*r[A][48][0,3]*r[I][30][2,0]
        hv += g[dei(p[A,1],p[A,0],p[I,0],p[I,1])]*r[A][33][0,3]*r[I][30][2,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,0])]*r[A][33][0,3]*r[I][33][2,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,0])]*r[A][48][0,3]*r[I][48][2,0]
        hv += g[dei(p[A,1],p[A,0],p[I,1],p[I,0])]*r[A][33][0,3]*r[I][48][2,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[I,0],p[A,1])]*r[A][15][0,3]*r[I][15][2,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[I,0],p[A,1])]*r[A][30][0,3]*r[I][30][2,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[I,1],p[A,1])]*r[A][15][0,3]*r[I][33][2,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[I,1],p[A,1])]*r[A][30][0,3]*r[I][48][2,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[I,0],p[A,0])]*r[A][33][0,3]*r[I][15][2,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[I,0],p[A,0])]*r[A][48][0,3]*r[I][30][2,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[I,1],p[A,0])]*r[A][33][0,3]*r[I][33][2,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[I,1],p[A,0])]*r[A][48][0,3]*r[I][48][2,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,0],p[I,1])]*r[A][15][0,3]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,0],p[I,1])]*r[A][30][0,3]*r[I][30][2,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,1])]*r[A][33][0,3]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,1])]*r[A][48][0,3]*r[I][30][2,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,0],p[I,0])]*r[A][15][0,3]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,0],p[I,0])]*r[A][30][0,3]*r[I][48][2,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,0])]*r[A][33][0,3]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,0])]*r[A][48][0,3]*r[I][48][2,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,0],p[A,1])]*r[A][15][0,3]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][30][2,0]
        hv += g[dei(p[I,0],p[I,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,1],p[A,0])]*r[A][33][0,3]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][30][2,0]
        hv += g[dei(p[I,0],p[I,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,0],p[A,1])]*r[A][15][0,3]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][48][2,0]
        hv += g[dei(p[I,1],p[I,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,1],p[A,0])]*r[A][33][0,3]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][48][2,0]
        hv += g[dei(p[I,1],p[I,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    return hd
    
def _B4C5I3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,4),(C,5),(I,3)]))
        hv = 0.0
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,0],p[I,1])]*r[A][15][0,3]*r[I][15][3,0]
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,0],p[I,1])]*r[A][30][0,3]*r[I][30][3,0]
        hv += g[dei(p[A,0],p[A,1],p[I,0],p[I,1])]*r[A][15][0,3]*r[I][30][3,0]
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,1],p[I,0])]*r[A][15][0,3]*r[I][33][3,0]
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,1],p[I,0])]*r[A][30][0,3]*r[I][48][3,0]
        hv += g[dei(p[A,0],p[A,1],p[I,1],p[I,0])]*r[A][15][0,3]*r[I][48][3,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,1])]*r[A][33][0,3]*r[I][15][3,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,1])]*r[A][48][0,3]*r[I][30][3,0]
        hv += g[dei(p[A,1],p[A,0],p[I,0],p[I,1])]*r[A][33][0,3]*r[I][30][3,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,0])]*r[A][33][0,3]*r[I][33][3,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,0])]*r[A][48][0,3]*r[I][48][3,0]
        hv += g[dei(p[A,1],p[A,0],p[I,1],p[I,0])]*r[A][33][0,3]*r[I][48][3,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[I,0],p[A,1])]*r[A][15][0,3]*r[I][15][3,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[I,0],p[A,1])]*r[A][30][0,3]*r[I][30][3,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[I,1],p[A,1])]*r[A][15][0,3]*r[I][33][3,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[I,1],p[A,1])]*r[A][30][0,3]*r[I][48][3,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[I,0],p[A,0])]*r[A][33][0,3]*r[I][15][3,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[I,0],p[A,0])]*r[A][48][0,3]*r[I][30][3,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[I,1],p[A,0])]*r[A][33][0,3]*r[I][33][3,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[I,1],p[A,0])]*r[A][48][0,3]*r[I][48][3,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,0],p[I,1])]*r[A][15][0,3]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,0],p[I,1])]*r[A][30][0,3]*r[I][30][3,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,1])]*r[A][33][0,3]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,1])]*r[A][48][0,3]*r[I][30][3,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,0],p[I,0])]*r[A][15][0,3]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,0],p[I,0])]*r[A][30][0,3]*r[I][48][3,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,0])]*r[A][33][0,3]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,0])]*r[A][48][0,3]*r[I][48][3,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,0],p[A,1])]*r[A][15][0,3]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][30][3,0]
        hv += g[dei(p[I,0],p[I,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,1],p[A,0])]*r[A][33][0,3]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][30][3,0]
        hv += g[dei(p[I,0],p[I,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,0],p[A,1])]*r[A][15][0,3]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][48][3,0]
        hv += g[dei(p[I,1],p[I,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,1],p[A,0])]*r[A][33][0,3]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][48][3,0]
        hv += g[dei(p[I,1],p[I,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    return hd
    
def _A3C5I4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,5),(I,4)]))
        hv = 0.0
        
        hv += -1*g[dei(p[I,0],p[B,1],p[B,0],p[I,1])]*r[B][27][0,4]*r[I][18][4,0]
        hv += -1*g[dei(p[I,0],p[B,0],p[B,1],p[I,1])]*r[B][45][0,4]*r[I][18][4,0]
        hv += -1*g[dei(p[I,1],p[B,1],p[B,0],p[I,0])]*r[B][27][0,4]*r[I][36][4,0]
        hv += -1*g[dei(p[I,1],p[B,0],p[B,1],p[I,0])]*r[B][45][0,4]*r[I][36][4,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    return hd
    
def _A3B4I5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,4),(I,5)]))
        hv = 0.0
        
        hv += -1*g[dei(p[C,0],p[I,1],p[I,0],p[C,1])]*r[C][18][0,5]*r[I][27][5,0]
        hv += -1*g[dei(p[C,0],p[I,0],p[I,1],p[C,1])]*r[C][18][0,5]*r[I][45][5,0]
        hv += -1*g[dei(p[C,1],p[I,1],p[I,0],p[C,0])]*r[C][36][0,5]*r[I][27][5,0]
        hv += -1*g[dei(p[C,1],p[I,0],p[I,1],p[C,0])]*r[C][36][0,5]*r[I][45][5,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    return hd
    
def _A11B8C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,8),(C,5)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += h[p[A,0],p[B,0]]*r[A][0][11,3]*r[B][1][8,4]
    hv += -1/2*g[dei(p[A,0],p[A,1],p[A,1],p[B,0])]*r[A][76][11,3]*r[B][1][8,4]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[A,0],p[B,0])]*r[A][124][11,3]*r[B][1][8,4]
    hv += g[dei(p[A,0],p[B,0],p[A,0],p[A,0])]*r[A][66][11,3]*r[B][1][8,4]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[A,1],p[A,1])]*r[A][76][11,3]*r[B][1][8,4]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[A,0],p[A,1])]*r[A][124][11,3]*r[B][1][8,4]
    hv += g[dei(p[A,1],p[B,0],p[A,0],p[A,1])]*r[A][134][11,3]*r[B][1][8,4]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[B,1],p[B,1])]*r[A][0][11,3]*r[B][137][8,4]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[B,1],p[B,0])]*r[A][0][11,3]*r[B][125][8,4]
    hv += -1/2*g[dei(p[B,1],p[B,0],p[A,0],p[B,1])]*r[A][0][11,3]*r[B][137][8,4]
    hv += -1/2*g[dei(p[B,1],p[B,1],p[A,0],p[B,0])]*r[A][0][11,3]*r[B][125][8,4]
    hv += sum(1/2*g[dei(p[A,0],p[B,0],p[I,0],p[I,0])]*r[A][0][11,3]*r[B][1][8,4]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[B,0],p[I,0],p[I,0])]*r[A][0][11,3]*r[B][1][8,4]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[B,0],p[I,1],p[I,1])]*r[A][0][11,3]*r[B][1][8,4]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[B,0],p[I,1],p[I,1])]*r[A][0][11,3]*r[B][1][8,4]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[B,0])]*r[A][0][11,3]*r[B][1][8,4]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[B,0])]*r[A][0][11,3]*r[B][1][8,4]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,0],p[A,0],p[I,0])]*r[A][0][11,3]*r[B][1][8,4]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,0],p[A,0],p[I,1])]*r[A][0][11,3]*r[B][1][8,4]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[B,0])]*r[A][0][11,3]*r[B][1][8,4]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[B,0])]*r[A][0][11,3]*r[B][1][8,4]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += g[dei(p[A,0],p[B,0],p[C,0],p[C,0])]*r[A][0][11,3]*r[B][1][8,4]*r[C][24][5,5]
    hv += g[dei(p[A,0],p[B,0],p[C,1],p[C,1])]*r[A][0][11,3]*r[B][1][8,4]*r[C][54][5,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11B7C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,7),(C,5)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += h[p[A,0],p[B,1]]*r[A][0][11,3]*r[B][5][7,4]
    hv += -1/2*g[dei(p[A,0],p[A,1],p[A,1],p[B,1])]*r[A][76][11,3]*r[B][5][7,4]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[A,0],p[B,1])]*r[A][124][11,3]*r[B][5][7,4]
    hv += g[dei(p[A,0],p[B,1],p[A,0],p[A,0])]*r[A][66][11,3]*r[B][5][7,4]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[A,1],p[A,1])]*r[A][76][11,3]*r[B][5][7,4]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[A,0],p[A,1])]*r[A][124][11,3]*r[B][5][7,4]
    hv += g[dei(p[A,1],p[B,1],p[A,0],p[A,1])]*r[A][134][11,3]*r[B][5][7,4]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[B,0],p[B,1])]*r[A][0][11,3]*r[B][73][7,4]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[B,0],p[B,0])]*r[A][0][11,3]*r[B][61][7,4]
    hv += -1/2*g[dei(p[B,0],p[B,0],p[A,0],p[B,1])]*r[A][0][11,3]*r[B][73][7,4]
    hv += -1/2*g[dei(p[B,0],p[B,1],p[A,0],p[B,0])]*r[A][0][11,3]*r[B][61][7,4]
    hv += sum(1/2*g[dei(p[A,0],p[B,1],p[I,0],p[I,0])]*r[A][0][11,3]*r[B][5][7,4]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[B,1],p[I,0],p[I,0])]*r[A][0][11,3]*r[B][5][7,4]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[B,1],p[I,1],p[I,1])]*r[A][0][11,3]*r[B][5][7,4]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[B,1],p[I,1],p[I,1])]*r[A][0][11,3]*r[B][5][7,4]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[B,1])]*r[A][0][11,3]*r[B][5][7,4]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[B,1])]*r[A][0][11,3]*r[B][5][7,4]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,1],p[A,0],p[I,0])]*r[A][0][11,3]*r[B][5][7,4]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,1],p[A,0],p[I,1])]*r[A][0][11,3]*r[B][5][7,4]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[B,1])]*r[A][0][11,3]*r[B][5][7,4]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[B,1])]*r[A][0][11,3]*r[B][5][7,4]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += g[dei(p[A,0],p[B,1],p[C,0],p[C,0])]*r[A][0][11,3]*r[B][5][7,4]*r[C][24][5,5]
    hv += g[dei(p[A,0],p[B,1],p[C,1],p[C,1])]*r[A][0][11,3]*r[B][5][7,4]*r[C][54][5,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12B8C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,8),(C,5)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += h[p[A,1],p[B,0]]*r[A][4][12,3]*r[B][1][8,4]
    hv += -1/2*g[dei(p[A,0],p[A,0],p[A,1],p[B,0])]*r[A][72][12,3]*r[B][1][8,4]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[A,0],p[B,0])]*r[A][120][12,3]*r[B][1][8,4]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[A,1],p[A,0])]*r[A][72][12,3]*r[B][1][8,4]
    hv += g[dei(p[A,0],p[B,0],p[A,1],p[A,0])]*r[A][82][12,3]*r[B][1][8,4]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[A,0],p[A,0])]*r[A][120][12,3]*r[B][1][8,4]
    hv += g[dei(p[A,1],p[B,0],p[A,1],p[A,1])]*r[A][150][12,3]*r[B][1][8,4]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[B,1],p[B,1])]*r[A][4][12,3]*r[B][137][8,4]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[B,1],p[B,0])]*r[A][4][12,3]*r[B][125][8,4]
    hv += -1/2*g[dei(p[B,1],p[B,0],p[A,1],p[B,1])]*r[A][4][12,3]*r[B][137][8,4]
    hv += -1/2*g[dei(p[B,1],p[B,1],p[A,1],p[B,0])]*r[A][4][12,3]*r[B][125][8,4]
    hv += sum(1/2*g[dei(p[A,1],p[B,0],p[I,0],p[I,0])]*r[A][4][12,3]*r[B][1][8,4]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[B,0],p[I,0],p[I,0])]*r[A][4][12,3]*r[B][1][8,4]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[B,0],p[I,1],p[I,1])]*r[A][4][12,3]*r[B][1][8,4]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[B,0],p[I,1],p[I,1])]*r[A][4][12,3]*r[B][1][8,4]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[B,0])]*r[A][4][12,3]*r[B][1][8,4]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[B,0])]*r[A][4][12,3]*r[B][1][8,4]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,0],p[A,1],p[I,0])]*r[A][4][12,3]*r[B][1][8,4]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,0],p[A,1],p[I,1])]*r[A][4][12,3]*r[B][1][8,4]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[B,0])]*r[A][4][12,3]*r[B][1][8,4]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[B,0])]*r[A][4][12,3]*r[B][1][8,4]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += g[dei(p[A,1],p[B,0],p[C,0],p[C,0])]*r[A][4][12,3]*r[B][1][8,4]*r[C][24][5,5]
    hv += g[dei(p[A,1],p[B,0],p[C,1],p[C,1])]*r[A][4][12,3]*r[B][1][8,4]*r[C][54][5,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12B7C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,7),(C,5)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += h[p[A,1],p[B,1]]*r[A][4][12,3]*r[B][5][7,4]
    hv += -1/2*g[dei(p[A,0],p[A,0],p[A,1],p[B,1])]*r[A][72][12,3]*r[B][5][7,4]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[A,0],p[B,1])]*r[A][120][12,3]*r[B][5][7,4]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[A,1],p[A,0])]*r[A][72][12,3]*r[B][5][7,4]
    hv += g[dei(p[A,0],p[B,1],p[A,1],p[A,0])]*r[A][82][12,3]*r[B][5][7,4]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[A,0],p[A,0])]*r[A][120][12,3]*r[B][5][7,4]
    hv += g[dei(p[A,1],p[B,1],p[A,1],p[A,1])]*r[A][150][12,3]*r[B][5][7,4]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[B,0],p[B,1])]*r[A][4][12,3]*r[B][73][7,4]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[B,0],p[B,0])]*r[A][4][12,3]*r[B][61][7,4]
    hv += -1/2*g[dei(p[B,0],p[B,0],p[A,1],p[B,1])]*r[A][4][12,3]*r[B][73][7,4]
    hv += -1/2*g[dei(p[B,0],p[B,1],p[A,1],p[B,0])]*r[A][4][12,3]*r[B][61][7,4]
    hv += sum(1/2*g[dei(p[A,1],p[B,1],p[I,0],p[I,0])]*r[A][4][12,3]*r[B][5][7,4]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[B,1],p[I,0],p[I,0])]*r[A][4][12,3]*r[B][5][7,4]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[B,1],p[I,1],p[I,1])]*r[A][4][12,3]*r[B][5][7,4]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[B,1],p[I,1],p[I,1])]*r[A][4][12,3]*r[B][5][7,4]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[B,1])]*r[A][4][12,3]*r[B][5][7,4]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[B,1])]*r[A][4][12,3]*r[B][5][7,4]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,1],p[A,1],p[I,0])]*r[A][4][12,3]*r[B][5][7,4]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,1],p[A,1],p[I,1])]*r[A][4][12,3]*r[B][5][7,4]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[B,1])]*r[A][4][12,3]*r[B][5][7,4]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[B,1])]*r[A][4][12,3]*r[B][5][7,4]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += g[dei(p[A,1],p[B,1],p[C,0],p[C,0])]*r[A][4][12,3]*r[B][5][7,4]*r[C][24][5,5]
    hv += g[dei(p[A,1],p[B,1],p[C,1],p[C,1])]*r[A][4][12,3]*r[B][5][7,4]*r[C][54][5,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B11C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,11),(C,5)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[B,0],p[A,0]]*r[A][3][8,3]*r[B][2][11,4]
    hv += g[dei(p[A,1],p[A,0],p[B,0],p[A,1])]*r[A][145][8,3]*r[B][2][11,4]
    hv += g[dei(p[A,1],p[A,1],p[B,0],p[A,0])]*r[A][133][8,3]*r[B][2][11,4]
    hv += g[dei(p[B,0],p[B,0],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][64][11,4]
    hv += g[dei(p[B,1],p[B,1],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][132][11,4]
    hv += sum(-1/2*g[dei(p[B,0],p[A,0],p[I,0],p[I,0])]*r[A][3][8,3]*r[B][2][11,4]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[A,0],p[I,1],p[I,1])]*r[A][3][8,3]*r[B][2][11,4]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[A,0])]*r[A][3][8,3]*r[B][2][11,4]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[A,0])]*r[A][3][8,3]*r[B][2][11,4]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,0],p[B,0],p[I,0])]*r[A][3][8,3]*r[B][2][11,4]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,0],p[B,0],p[I,1])]*r[A][3][8,3]*r[B][2][11,4]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][2][11,4]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][2][11,4]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][2][11,4]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][2][11,4]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,0],p[A,0],p[C,0],p[C,0])]*r[A][3][8,3]*r[B][2][11,4]*r[C][24][5,5]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[C,1],p[C,1])]*r[A][3][8,3]*r[B][2][11,4]*r[C][54][5,5]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[C,0],p[A,0])]*r[A][3][8,3]*r[B][2][11,4]*r[C][24][5,5]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,1],p[A,0])]*r[A][3][8,3]*r[B][2][11,4]*r[C][54][5,5]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[B,0],p[C,0])]*r[A][3][8,3]*r[B][2][11,4]*r[C][24][5,5]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[B,0],p[C,1])]*r[A][3][8,3]*r[B][2][11,4]*r[C][54][5,5]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][2][11,4]*r[C][24][5,5]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][2][11,4]*r[C][54][5,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B11C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,11),(C,5)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[B,0],p[A,1]]*r[A][7][7,3]*r[B][2][11,4]
    hv += g[dei(p[A,0],p[A,0],p[B,0],p[A,1])]*r[A][81][7,3]*r[B][2][11,4]
    hv += g[dei(p[A,0],p[A,1],p[B,0],p[A,0])]*r[A][69][7,3]*r[B][2][11,4]
    hv += g[dei(p[B,0],p[B,0],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][64][11,4]
    hv += g[dei(p[B,1],p[B,1],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][132][11,4]
    hv += sum(-1/2*g[dei(p[B,0],p[A,1],p[I,0],p[I,0])]*r[A][7][7,3]*r[B][2][11,4]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[A,1],p[I,1],p[I,1])]*r[A][7][7,3]*r[B][2][11,4]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[A,1])]*r[A][7][7,3]*r[B][2][11,4]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[A,1])]*r[A][7][7,3]*r[B][2][11,4]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,1],p[B,0],p[I,0])]*r[A][7][7,3]*r[B][2][11,4]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,1],p[B,0],p[I,1])]*r[A][7][7,3]*r[B][2][11,4]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][2][11,4]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][2][11,4]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][2][11,4]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][2][11,4]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,0],p[A,1],p[C,0],p[C,0])]*r[A][7][7,3]*r[B][2][11,4]*r[C][24][5,5]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[C,1],p[C,1])]*r[A][7][7,3]*r[B][2][11,4]*r[C][54][5,5]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[C,0],p[A,1])]*r[A][7][7,3]*r[B][2][11,4]*r[C][24][5,5]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,1],p[A,1])]*r[A][7][7,3]*r[B][2][11,4]*r[C][54][5,5]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[B,0],p[C,0])]*r[A][7][7,3]*r[B][2][11,4]*r[C][24][5,5]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[B,0],p[C,1])]*r[A][7][7,3]*r[B][2][11,4]*r[C][54][5,5]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][2][11,4]*r[C][24][5,5]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][2][11,4]*r[C][54][5,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B12C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,12),(C,5)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[B,1],p[A,0]]*r[A][3][8,3]*r[B][6][12,4]
    hv += g[dei(p[A,1],p[A,0],p[B,1],p[A,1])]*r[A][145][8,3]*r[B][6][12,4]
    hv += g[dei(p[A,1],p[A,1],p[B,1],p[A,0])]*r[A][133][8,3]*r[B][6][12,4]
    hv += g[dei(p[B,0],p[B,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][80][12,4]
    hv += g[dei(p[B,1],p[B,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][148][12,4]
    hv += sum(-1/2*g[dei(p[B,1],p[A,0],p[I,0],p[I,0])]*r[A][3][8,3]*r[B][6][12,4]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[A,0],p[I,1],p[I,1])]*r[A][3][8,3]*r[B][6][12,4]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[A,0])]*r[A][3][8,3]*r[B][6][12,4]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[A,0])]*r[A][3][8,3]*r[B][6][12,4]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,0],p[B,1],p[I,0])]*r[A][3][8,3]*r[B][6][12,4]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,0],p[B,1],p[I,1])]*r[A][3][8,3]*r[B][6][12,4]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][12,4]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][12,4]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][12,4]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][12,4]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,1],p[A,0],p[C,0],p[C,0])]*r[A][3][8,3]*r[B][6][12,4]*r[C][24][5,5]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[C,1],p[C,1])]*r[A][3][8,3]*r[B][6][12,4]*r[C][54][5,5]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,0],p[A,0])]*r[A][3][8,3]*r[B][6][12,4]*r[C][24][5,5]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[C,1],p[A,0])]*r[A][3][8,3]*r[B][6][12,4]*r[C][54][5,5]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[B,1],p[C,0])]*r[A][3][8,3]*r[B][6][12,4]*r[C][24][5,5]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[B,1],p[C,1])]*r[A][3][8,3]*r[B][6][12,4]*r[C][54][5,5]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][12,4]*r[C][24][5,5]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][12,4]*r[C][54][5,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B12C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,12),(C,5)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[B,1],p[A,1]]*r[A][7][7,3]*r[B][6][12,4]
    hv += g[dei(p[A,0],p[A,0],p[B,1],p[A,1])]*r[A][81][7,3]*r[B][6][12,4]
    hv += g[dei(p[A,0],p[A,1],p[B,1],p[A,0])]*r[A][69][7,3]*r[B][6][12,4]
    hv += g[dei(p[B,0],p[B,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][80][12,4]
    hv += g[dei(p[B,1],p[B,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][148][12,4]
    hv += sum(-1/2*g[dei(p[B,1],p[A,1],p[I,0],p[I,0])]*r[A][7][7,3]*r[B][6][12,4]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[A,1],p[I,1],p[I,1])]*r[A][7][7,3]*r[B][6][12,4]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[A,1])]*r[A][7][7,3]*r[B][6][12,4]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[A,1])]*r[A][7][7,3]*r[B][6][12,4]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,1],p[B,1],p[I,0])]*r[A][7][7,3]*r[B][6][12,4]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,1],p[B,1],p[I,1])]*r[A][7][7,3]*r[B][6][12,4]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][12,4]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][12,4]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][12,4]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][12,4]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,1],p[A,1],p[C,0],p[C,0])]*r[A][7][7,3]*r[B][6][12,4]*r[C][24][5,5]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[C,1],p[C,1])]*r[A][7][7,3]*r[B][6][12,4]*r[C][54][5,5]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,0],p[A,1])]*r[A][7][7,3]*r[B][6][12,4]*r[C][24][5,5]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[C,1],p[A,1])]*r[A][7][7,3]*r[B][6][12,4]*r[C][54][5,5]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[B,1],p[C,0])]*r[A][7][7,3]*r[B][6][12,4]*r[C][24][5,5]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[B,1],p[C,1])]*r[A][7][7,3]*r[B][6][12,4]*r[C][54][5,5]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][12,4]*r[C][24][5,5]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][12,4]*r[C][54][5,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A4B2C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,4),(B,2),(C,5)]))
    hv = 0.0
    
    hv += -1*g[dei(p[A,0],p[B,0],p[B,0],p[A,0])]*r[A][12][4,3]*r[B][21][2,4]
    hv += -1*g[dei(p[A,0],p[B,1],p[B,1],p[A,0])]*r[A][12][4,3]*r[B][51][2,4]
    hv += -1*g[dei(p[A,1],p[B,0],p[B,0],p[A,1])]*r[A][42][4,3]*r[B][21][2,4]
    hv += -1*g[dei(p[A,1],p[B,1],p[B,1],p[A,1])]*r[A][42][4,3]*r[B][51][2,4]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A4B3C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,4),(B,3),(C,5)]))
    hv = 0.0
    
    hv += -1*g[dei(p[A,0],p[B,0],p[B,0],p[A,0])]*r[A][12][4,3]*r[B][21][3,4]
    hv += -1*g[dei(p[A,0],p[B,1],p[B,1],p[A,0])]*r[A][12][4,3]*r[B][51][3,4]
    hv += -1*g[dei(p[A,1],p[B,0],p[B,0],p[A,1])]*r[A][42][4,3]*r[B][21][3,4]
    hv += -1*g[dei(p[A,1],p[B,1],p[B,1],p[A,1])]*r[A][42][4,3]*r[B][51][3,4]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A4C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,4),(C,5)]))
    hv = 0.0
    
    hv += -1*g[dei(p[A,0],p[B,1],p[B,0],p[A,0])]*r[A][12][4,3]*r[B][27][0,4]
    hv += -1*g[dei(p[A,0],p[B,0],p[B,1],p[A,0])]*r[A][12][4,3]*r[B][45][0,4]
    hv += -1*g[dei(p[A,1],p[B,1],p[B,0],p[A,1])]*r[A][42][4,3]*r[B][27][0,4]
    hv += -1*g[dei(p[A,1],p[B,0],p[B,1],p[A,1])]*r[A][42][4,3]*r[B][45][0,4]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A4B1C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,4),(B,1),(C,5)]))
    hv = 0.0
    
    hv += -1*g[dei(p[A,0],p[B,1],p[B,0],p[A,0])]*r[A][12][4,3]*r[B][27][1,4]
    hv += -1*g[dei(p[A,0],p[B,0],p[B,1],p[A,0])]*r[A][12][4,3]*r[B][45][1,4]
    hv += -1*g[dei(p[A,1],p[B,1],p[B,0],p[A,1])]*r[A][42][4,3]*r[B][27][1,4]
    hv += -1*g[dei(p[A,1],p[B,0],p[B,1],p[A,1])]*r[A][42][4,3]*r[B][45][1,4]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A13B4C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,4),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += h[p[A,0],p[C,0]]*r[A][2][13,3]*r[C][3][10,5]
    hv += -1*g[dei(p[A,0],p[A,0],p[A,0],p[C,0])]*r[A][64][13,3]*r[C][3][10,5]
    hv += -1/2*g[dei(p[A,0],p[A,1],p[A,1],p[C,0])]*r[A][118][13,3]*r[C][3][10,5]
    hv += -1*g[dei(p[A,0],p[A,1],p[A,1],p[C,0])]*r[A][84][13,3]*r[C][3][10,5]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[A,0],p[C,0])]*r[A][166][13,3]*r[C][3][10,5]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[A,1],p[A,1])]*r[A][118][13,3]*r[C][3][10,5]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[A,0],p[A,1])]*r[A][166][13,3]*r[C][3][10,5]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[C,1],p[C,1])]*r[A][2][13,3]*r[C][179][10,5]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[C,1],p[C,0])]*r[A][2][13,3]*r[C][167][10,5]
    hv += -1/2*g[dei(p[C,1],p[C,0],p[A,0],p[C,1])]*r[A][2][13,3]*r[C][179][10,5]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][167][10,5]
    hv += sum(1/2*g[dei(p[A,0],p[C,0],p[I,0],p[I,0])]*r[A][2][13,3]*r[C][3][10,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[C,0],p[I,1],p[I,1])]*r[A][2][13,3]*r[C][3][10,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[C,0])]*r[A][2][13,3]*r[C][3][10,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[C,0])]*r[A][2][13,3]*r[C][3][10,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,0],p[A,0],p[I,0])]*r[A][2][13,3]*r[C][3][10,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,0],p[A,0],p[I,1])]*r[A][2][13,3]*r[C][3][10,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][3][10,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][3][10,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][3][10,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][3][10,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += g[dei(p[B,0],p[B,0],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][9][4,4]*r[C][3][10,5]
    hv += g[dei(p[B,1],p[B,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][39][4,4]*r[C][3][10,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B4C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,4),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += h[p[A,0],p[C,1]]*r[A][2][13,3]*r[C][7][9,5]
    hv += -1*g[dei(p[A,0],p[A,0],p[A,0],p[C,1])]*r[A][64][13,3]*r[C][7][9,5]
    hv += -1/2*g[dei(p[A,0],p[A,1],p[A,1],p[C,1])]*r[A][118][13,3]*r[C][7][9,5]
    hv += -1*g[dei(p[A,0],p[A,1],p[A,1],p[C,1])]*r[A][84][13,3]*r[C][7][9,5]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[A,0],p[C,1])]*r[A][166][13,3]*r[C][7][9,5]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[A,1],p[A,1])]*r[A][118][13,3]*r[C][7][9,5]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[A,0],p[A,1])]*r[A][166][13,3]*r[C][7][9,5]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[C,0],p[C,1])]*r[A][2][13,3]*r[C][115][9,5]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[C,0],p[C,0])]*r[A][2][13,3]*r[C][103][9,5]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[A,0],p[C,1])]*r[A][2][13,3]*r[C][115][9,5]
    hv += -1/2*g[dei(p[C,0],p[C,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][103][9,5]
    hv += sum(1/2*g[dei(p[A,0],p[C,1],p[I,0],p[I,0])]*r[A][2][13,3]*r[C][7][9,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[C,1],p[I,1],p[I,1])]*r[A][2][13,3]*r[C][7][9,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[C,1])]*r[A][2][13,3]*r[C][7][9,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[C,1])]*r[A][2][13,3]*r[C][7][9,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,1],p[A,0],p[I,0])]*r[A][2][13,3]*r[C][7][9,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,1],p[A,0],p[I,1])]*r[A][2][13,3]*r[C][7][9,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[C,1])]*r[A][2][13,3]*r[C][7][9,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,0],p[C,1])]*r[A][2][13,3]*r[C][7][9,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[C,1])]*r[A][2][13,3]*r[C][7][9,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,0],p[C,1])]*r[A][2][13,3]*r[C][7][9,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += g[dei(p[B,0],p[B,0],p[A,0],p[C,1])]*r[A][2][13,3]*r[B][9][4,4]*r[C][7][9,5]
    hv += g[dei(p[B,1],p[B,1],p[A,0],p[C,1])]*r[A][2][13,3]*r[B][39][4,4]*r[C][7][9,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B4C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,4),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += h[p[A,1],p[C,0]]*r[A][6][14,3]*r[C][3][10,5]
    hv += -1/2*g[dei(p[A,0],p[A,0],p[A,1],p[C,0])]*r[A][114][14,3]*r[C][3][10,5]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[A,0],p[C,0])]*r[A][162][14,3]*r[C][3][10,5]
    hv += -1*g[dei(p[A,1],p[A,0],p[A,0],p[C,0])]*r[A][128][14,3]*r[C][3][10,5]
    hv += -1*g[dei(p[A,1],p[A,1],p[A,1],p[C,0])]*r[A][148][14,3]*r[C][3][10,5]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[A,1],p[A,0])]*r[A][114][14,3]*r[C][3][10,5]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[A,0],p[A,0])]*r[A][162][14,3]*r[C][3][10,5]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[C,1],p[C,1])]*r[A][6][14,3]*r[C][179][10,5]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[C,1],p[C,0])]*r[A][6][14,3]*r[C][167][10,5]
    hv += -1/2*g[dei(p[C,1],p[C,0],p[A,1],p[C,1])]*r[A][6][14,3]*r[C][179][10,5]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][167][10,5]
    hv += sum(1/2*g[dei(p[A,1],p[C,0],p[I,0],p[I,0])]*r[A][6][14,3]*r[C][3][10,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[C,0],p[I,1],p[I,1])]*r[A][6][14,3]*r[C][3][10,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[C,0])]*r[A][6][14,3]*r[C][3][10,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[C,0])]*r[A][6][14,3]*r[C][3][10,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,0],p[A,1],p[I,0])]*r[A][6][14,3]*r[C][3][10,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,0],p[A,1],p[I,1])]*r[A][6][14,3]*r[C][3][10,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][3][10,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][3][10,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][3][10,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][3][10,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += g[dei(p[B,0],p[B,0],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][9][4,4]*r[C][3][10,5]
    hv += g[dei(p[B,1],p[B,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][39][4,4]*r[C][3][10,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B4C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,4),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += h[p[A,1],p[C,1]]*r[A][6][14,3]*r[C][7][9,5]
    hv += -1/2*g[dei(p[A,0],p[A,0],p[A,1],p[C,1])]*r[A][114][14,3]*r[C][7][9,5]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[A,0],p[C,1])]*r[A][162][14,3]*r[C][7][9,5]
    hv += -1*g[dei(p[A,1],p[A,0],p[A,0],p[C,1])]*r[A][128][14,3]*r[C][7][9,5]
    hv += -1*g[dei(p[A,1],p[A,1],p[A,1],p[C,1])]*r[A][148][14,3]*r[C][7][9,5]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[A,1],p[A,0])]*r[A][114][14,3]*r[C][7][9,5]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[A,0],p[A,0])]*r[A][162][14,3]*r[C][7][9,5]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[C,0],p[C,1])]*r[A][6][14,3]*r[C][115][9,5]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[C,0],p[C,0])]*r[A][6][14,3]*r[C][103][9,5]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[A,1],p[C,1])]*r[A][6][14,3]*r[C][115][9,5]
    hv += -1/2*g[dei(p[C,0],p[C,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][103][9,5]
    hv += sum(1/2*g[dei(p[A,1],p[C,1],p[I,0],p[I,0])]*r[A][6][14,3]*r[C][7][9,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[C,1],p[I,1],p[I,1])]*r[A][6][14,3]*r[C][7][9,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[C,1])]*r[A][6][14,3]*r[C][7][9,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[C,1])]*r[A][6][14,3]*r[C][7][9,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,1],p[A,1],p[I,0])]*r[A][6][14,3]*r[C][7][9,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,1],p[A,1],p[I,1])]*r[A][6][14,3]*r[C][7][9,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[C,1])]*r[A][6][14,3]*r[C][7][9,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,1],p[C,1])]*r[A][6][14,3]*r[C][7][9,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[C,1])]*r[A][6][14,3]*r[C][7][9,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,1],p[C,1])]*r[A][6][14,3]*r[C][7][9,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += g[dei(p[B,0],p[B,0],p[A,1],p[C,1])]*r[A][6][14,3]*r[B][9][4,4]*r[C][7][9,5]
    hv += g[dei(p[B,1],p[B,1],p[A,1],p[C,1])]*r[A][6][14,3]*r[B][39][4,4]*r[C][7][9,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B4C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,4),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[C,0],p[A,0]]*r[A][1][10,3]*r[C][0][13,5]
    hv += -1*g[dei(p[C,0],p[A,0],p[A,1],p[A,1])]*r[A][177][10,3]*r[C][0][13,5]
    hv += -1*g[dei(p[C,0],p[A,1],p[A,1],p[A,0])]*r[A][165][10,3]*r[C][0][13,5]
    hv += -1*g[dei(p[C,0],p[A,0],p[C,0],p[C,0])]*r[A][1][10,3]*r[C][66][13,5]
    hv += -1*g[dei(p[C,0],p[A,0],p[C,1],p[C,1])]*r[A][1][10,3]*r[C][86][13,5]
    hv += sum(-1/2*g[dei(p[C,0],p[A,0],p[I,0],p[I,0])]*r[A][1][10,3]*r[C][0][13,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,0],p[A,0],p[I,0],p[I,0])]*r[A][1][10,3]*r[C][0][13,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[A,0],p[I,1],p[I,1])]*r[A][1][10,3]*r[C][0][13,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,0],p[A,0],p[I,1],p[I,1])]*r[A][1][10,3]*r[C][0][13,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[I,0],p[I,0],p[A,0])]*r[A][1][10,3]*r[C][0][13,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[I,1],p[I,1],p[A,0])]*r[A][1][10,3]*r[C][0][13,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,0],p[C,0],p[I,0])]*r[A][1][10,3]*r[C][0][13,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,0],p[C,0],p[I,1])]*r[A][1][10,3]*r[C][0][13,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[C,0],p[A,0])]*r[A][1][10,3]*r[C][0][13,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[C,0],p[A,0])]*r[A][1][10,3]*r[C][0][13,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[B,0],p[A,0],p[C,0],p[B,0])]*r[A][1][10,3]*r[B][9][4,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[C,0],p[B,1])]*r[A][1][10,3]*r[B][39][4,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[B,0],p[B,0],p[C,0],p[A,0])]*r[A][1][10,3]*r[B][9][4,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[B,1],p[B,1],p[C,0],p[A,0])]*r[A][1][10,3]*r[B][39][4,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[B,0],p[B,0])]*r[A][1][10,3]*r[B][9][4,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[B,1],p[B,1])]*r[A][1][10,3]*r[B][39][4,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[C,0],p[B,0],p[B,0],p[A,0])]*r[A][1][10,3]*r[B][9][4,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[C,0],p[B,1],p[B,1],p[A,0])]*r[A][1][10,3]*r[B][39][4,4]*r[C][0][13,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B4C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,4),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[C,0],p[A,1]]*r[A][5][9,3]*r[C][0][13,5]
    hv += -1*g[dei(p[C,0],p[A,0],p[A,0],p[A,1])]*r[A][113][9,3]*r[C][0][13,5]
    hv += -1*g[dei(p[C,0],p[A,1],p[A,0],p[A,0])]*r[A][101][9,3]*r[C][0][13,5]
    hv += -1*g[dei(p[C,0],p[A,1],p[C,0],p[C,0])]*r[A][5][9,3]*r[C][66][13,5]
    hv += -1*g[dei(p[C,0],p[A,1],p[C,1],p[C,1])]*r[A][5][9,3]*r[C][86][13,5]
    hv += sum(-1/2*g[dei(p[C,0],p[A,1],p[I,0],p[I,0])]*r[A][5][9,3]*r[C][0][13,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,0],p[A,1],p[I,0],p[I,0])]*r[A][5][9,3]*r[C][0][13,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[A,1],p[I,1],p[I,1])]*r[A][5][9,3]*r[C][0][13,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,0],p[A,1],p[I,1],p[I,1])]*r[A][5][9,3]*r[C][0][13,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[I,0],p[I,0],p[A,1])]*r[A][5][9,3]*r[C][0][13,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[I,1],p[I,1],p[A,1])]*r[A][5][9,3]*r[C][0][13,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,1],p[C,0],p[I,0])]*r[A][5][9,3]*r[C][0][13,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,1],p[C,0],p[I,1])]*r[A][5][9,3]*r[C][0][13,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[C,0],p[A,1])]*r[A][5][9,3]*r[C][0][13,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[C,0],p[A,1])]*r[A][5][9,3]*r[C][0][13,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[B,0],p[A,1],p[C,0],p[B,0])]*r[A][5][9,3]*r[B][9][4,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[C,0],p[B,1])]*r[A][5][9,3]*r[B][39][4,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[B,0],p[B,0],p[C,0],p[A,1])]*r[A][5][9,3]*r[B][9][4,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[B,1],p[B,1],p[C,0],p[A,1])]*r[A][5][9,3]*r[B][39][4,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[B,0],p[B,0])]*r[A][5][9,3]*r[B][9][4,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[B,1],p[B,1])]*r[A][5][9,3]*r[B][39][4,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[C,0],p[B,0],p[B,0],p[A,1])]*r[A][5][9,3]*r[B][9][4,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[C,0],p[B,1],p[B,1],p[A,1])]*r[A][5][9,3]*r[B][39][4,4]*r[C][0][13,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B4C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,4),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[C,1],p[A,0]]*r[A][1][10,3]*r[C][4][14,5]
    hv += -1*g[dei(p[C,1],p[A,0],p[A,1],p[A,1])]*r[A][177][10,3]*r[C][4][14,5]
    hv += -1*g[dei(p[C,1],p[A,1],p[A,1],p[A,0])]*r[A][165][10,3]*r[C][4][14,5]
    hv += -1*g[dei(p[C,1],p[A,0],p[C,0],p[C,0])]*r[A][1][10,3]*r[C][130][14,5]
    hv += -1*g[dei(p[C,1],p[A,0],p[C,1],p[C,1])]*r[A][1][10,3]*r[C][150][14,5]
    hv += sum(-1/2*g[dei(p[C,1],p[A,0],p[I,0],p[I,0])]*r[A][1][10,3]*r[C][4][14,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,1],p[A,0],p[I,0],p[I,0])]*r[A][1][10,3]*r[C][4][14,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[A,0],p[I,1],p[I,1])]*r[A][1][10,3]*r[C][4][14,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,1],p[A,0],p[I,1],p[I,1])]*r[A][1][10,3]*r[C][4][14,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[I,0],p[I,0],p[A,0])]*r[A][1][10,3]*r[C][4][14,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[I,1],p[I,1],p[A,0])]*r[A][1][10,3]*r[C][4][14,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,0],p[C,1],p[I,0])]*r[A][1][10,3]*r[C][4][14,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,0],p[C,1],p[I,1])]*r[A][1][10,3]*r[C][4][14,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[C,1],p[A,0])]*r[A][1][10,3]*r[C][4][14,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[C,1],p[A,0])]*r[A][1][10,3]*r[C][4][14,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[B,0],p[A,0],p[C,1],p[B,0])]*r[A][1][10,3]*r[B][9][4,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[C,1],p[B,1])]*r[A][1][10,3]*r[B][39][4,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[B,0],p[B,0],p[C,1],p[A,0])]*r[A][1][10,3]*r[B][9][4,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[B,1],p[B,1],p[C,1],p[A,0])]*r[A][1][10,3]*r[B][39][4,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[B,0],p[B,0])]*r[A][1][10,3]*r[B][9][4,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[B,1],p[B,1])]*r[A][1][10,3]*r[B][39][4,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[C,1],p[B,0],p[B,0],p[A,0])]*r[A][1][10,3]*r[B][9][4,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[C,1],p[B,1],p[B,1],p[A,0])]*r[A][1][10,3]*r[B][39][4,4]*r[C][4][14,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B4C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,4),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[C,1],p[A,1]]*r[A][5][9,3]*r[C][4][14,5]
    hv += -1*g[dei(p[C,1],p[A,0],p[A,0],p[A,1])]*r[A][113][9,3]*r[C][4][14,5]
    hv += -1*g[dei(p[C,1],p[A,1],p[A,0],p[A,0])]*r[A][101][9,3]*r[C][4][14,5]
    hv += -1*g[dei(p[C,1],p[A,1],p[C,0],p[C,0])]*r[A][5][9,3]*r[C][130][14,5]
    hv += -1*g[dei(p[C,1],p[A,1],p[C,1],p[C,1])]*r[A][5][9,3]*r[C][150][14,5]
    hv += sum(-1/2*g[dei(p[C,1],p[A,1],p[I,0],p[I,0])]*r[A][5][9,3]*r[C][4][14,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,1],p[A,1],p[I,0],p[I,0])]*r[A][5][9,3]*r[C][4][14,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[A,1],p[I,1],p[I,1])]*r[A][5][9,3]*r[C][4][14,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,1],p[A,1],p[I,1],p[I,1])]*r[A][5][9,3]*r[C][4][14,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[I,0],p[I,0],p[A,1])]*r[A][5][9,3]*r[C][4][14,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[I,1],p[I,1],p[A,1])]*r[A][5][9,3]*r[C][4][14,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,1],p[C,1],p[I,0])]*r[A][5][9,3]*r[C][4][14,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,1],p[C,1],p[I,1])]*r[A][5][9,3]*r[C][4][14,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[C,1],p[A,1])]*r[A][5][9,3]*r[C][4][14,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[C,1],p[A,1])]*r[A][5][9,3]*r[C][4][14,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[B,0],p[A,1],p[C,1],p[B,0])]*r[A][5][9,3]*r[B][9][4,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[C,1],p[B,1])]*r[A][5][9,3]*r[B][39][4,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[B,0],p[B,0],p[C,1],p[A,1])]*r[A][5][9,3]*r[B][9][4,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[B,1],p[B,1],p[C,1],p[A,1])]*r[A][5][9,3]*r[B][39][4,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[B,0],p[B,0])]*r[A][5][9,3]*r[B][9][4,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[B,1],p[B,1])]*r[A][5][9,3]*r[B][39][4,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[C,1],p[B,0],p[B,0],p[A,1])]*r[A][5][9,3]*r[B][9][4,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[C,1],p[B,1],p[B,1],p[A,1])]*r[A][5][9,3]*r[B][39][4,4]*r[C][4][14,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A5B4C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,5),(B,4),(C,2)]))
    hv = 0.0
    
    hv += -1*g[dei(p[C,0],p[A,0],p[A,0],p[C,0])]*r[A][21][5,3]*r[C][12][2,5]
    hv += -1*g[dei(p[C,0],p[A,1],p[A,1],p[C,0])]*r[A][51][5,3]*r[C][12][2,5]
    hv += -1*g[dei(p[C,1],p[A,0],p[A,0],p[C,1])]*r[A][21][5,3]*r[C][42][2,5]
    hv += -1*g[dei(p[C,1],p[A,1],p[A,1],p[C,1])]*r[A][51][5,3]*r[C][42][2,5]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A5B4C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,5),(B,4),(C,3)]))
    hv = 0.0
    
    hv += -1*g[dei(p[C,0],p[A,0],p[A,0],p[C,0])]*r[A][21][5,3]*r[C][12][3,5]
    hv += -1*g[dei(p[C,0],p[A,1],p[A,1],p[C,0])]*r[A][51][5,3]*r[C][12][3,5]
    hv += -1*g[dei(p[C,1],p[A,0],p[A,0],p[C,1])]*r[A][21][5,3]*r[C][42][3,5]
    hv += -1*g[dei(p[C,1],p[A,1],p[A,1],p[C,1])]*r[A][51][5,3]*r[C][42][3,5]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A5B4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,5),(B,4)]))
    hv = 0.0
    
    hv += -1*g[dei(p[C,0],p[A,0],p[A,0],p[C,1])]*r[A][21][5,3]*r[C][18][0,5]
    hv += -1*g[dei(p[C,0],p[A,1],p[A,1],p[C,1])]*r[A][51][5,3]*r[C][18][0,5]
    hv += -1*g[dei(p[C,1],p[A,0],p[A,0],p[C,0])]*r[A][21][5,3]*r[C][36][0,5]
    hv += -1*g[dei(p[C,1],p[A,1],p[A,1],p[C,0])]*r[A][51][5,3]*r[C][36][0,5]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A5B4C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,5),(B,4),(C,1)]))
    hv = 0.0
    
    hv += -1*g[dei(p[C,0],p[A,0],p[A,0],p[C,1])]*r[A][21][5,3]*r[C][18][1,5]
    hv += -1*g[dei(p[C,0],p[A,1],p[A,1],p[C,1])]*r[A][51][5,3]*r[C][18][1,5]
    hv += -1*g[dei(p[C,1],p[A,0],p[A,0],p[C,0])]*r[A][21][5,3]*r[C][36][1,5]
    hv += -1*g[dei(p[C,1],p[A,1],p[A,1],p[C,0])]*r[A][51][5,3]*r[C][36][1,5]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A3B11C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,11),(C,10)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += h[p[B,0],p[C,0]]*r[B][2][11,4]*r[C][3][10,5]
    hv += -1*g[dei(p[B,0],p[B,0],p[B,0],p[C,0])]*r[B][64][11,4]*r[C][3][10,5]
    hv += -1*g[dei(p[B,1],p[B,1],p[B,0],p[C,0])]*r[B][132][11,4]*r[C][3][10,5]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[C,1],p[C,1])]*r[B][2][11,4]*r[C][179][10,5]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,1],p[C,0])]*r[B][2][11,4]*r[C][167][10,5]
    hv += -1/2*g[dei(p[C,1],p[C,0],p[B,0],p[C,1])]*r[B][2][11,4]*r[C][179][10,5]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,0],p[C,0])]*r[B][2][11,4]*r[C][167][10,5]
    hv += sum(1/2*g[dei(p[B,0],p[C,0],p[I,0],p[I,0])]*r[B][2][11,4]*r[C][3][10,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[C,0],p[I,1],p[I,1])]*r[B][2][11,4]*r[C][3][10,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,0],p[I,0],p[C,0])]*r[B][2][11,4]*r[C][3][10,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,1],p[I,1],p[C,0])]*r[B][2][11,4]*r[C][3][10,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,0],p[B,0],p[I,0])]*r[B][2][11,4]*r[C][3][10,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,0],p[B,0],p[I,1])]*r[B][2][11,4]*r[C][3][10,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,0],p[C,0])]*r[B][2][11,4]*r[C][3][10,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[B,0],p[C,0])]*r[B][2][11,4]*r[C][3][10,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,0],p[C,0])]*r[B][2][11,4]*r[C][3][10,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[B,0],p[C,0])]*r[B][2][11,4]*r[C][3][10,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][24][3,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][9][3,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][54][3,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][39][3,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,0])]*r[A][24][3,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,1])]*r[A][54][3,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,0])]*r[A][24][3,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,0])]*r[A][54][3,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][2][11,4]*r[C][3][10,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A3B11C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,11),(C,9)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += h[p[B,0],p[C,1]]*r[B][2][11,4]*r[C][7][9,5]
    hv += -1*g[dei(p[B,0],p[B,0],p[B,0],p[C,1])]*r[B][64][11,4]*r[C][7][9,5]
    hv += -1*g[dei(p[B,1],p[B,1],p[B,0],p[C,1])]*r[B][132][11,4]*r[C][7][9,5]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[C,0],p[C,1])]*r[B][2][11,4]*r[C][115][9,5]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,0],p[C,0])]*r[B][2][11,4]*r[C][103][9,5]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,0],p[C,1])]*r[B][2][11,4]*r[C][115][9,5]
    hv += -1/2*g[dei(p[C,0],p[C,1],p[B,0],p[C,0])]*r[B][2][11,4]*r[C][103][9,5]
    hv += sum(1/2*g[dei(p[B,0],p[C,1],p[I,0],p[I,0])]*r[B][2][11,4]*r[C][7][9,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[C,1],p[I,1],p[I,1])]*r[B][2][11,4]*r[C][7][9,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,0],p[I,0],p[C,1])]*r[B][2][11,4]*r[C][7][9,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,1],p[I,1],p[C,1])]*r[B][2][11,4]*r[C][7][9,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,1],p[B,0],p[I,0])]*r[B][2][11,4]*r[C][7][9,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,1],p[B,0],p[I,1])]*r[B][2][11,4]*r[C][7][9,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,0],p[C,1])]*r[B][2][11,4]*r[C][7][9,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[B,0],p[C,1])]*r[B][2][11,4]*r[C][7][9,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,0],p[C,1])]*r[B][2][11,4]*r[C][7][9,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[B,0],p[C,1])]*r[B][2][11,4]*r[C][7][9,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][24][3,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][9][3,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][54][3,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][39][3,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,0])]*r[A][24][3,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,1])]*r[A][54][3,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,1])]*r[A][24][3,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,1])]*r[A][54][3,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][2][11,4]*r[C][7][9,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A3B12C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,12),(C,10)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += h[p[B,1],p[C,0]]*r[B][6][12,4]*r[C][3][10,5]
    hv += -1*g[dei(p[B,0],p[B,0],p[B,1],p[C,0])]*r[B][80][12,4]*r[C][3][10,5]
    hv += -1*g[dei(p[B,1],p[B,1],p[B,1],p[C,0])]*r[B][148][12,4]*r[C][3][10,5]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,1],p[C,1])]*r[B][6][12,4]*r[C][179][10,5]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[C,1],p[C,0])]*r[B][6][12,4]*r[C][167][10,5]
    hv += -1/2*g[dei(p[C,1],p[C,0],p[B,1],p[C,1])]*r[B][6][12,4]*r[C][179][10,5]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,1],p[C,0])]*r[B][6][12,4]*r[C][167][10,5]
    hv += sum(1/2*g[dei(p[B,1],p[C,0],p[I,0],p[I,0])]*r[B][6][12,4]*r[C][3][10,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[C,0],p[I,1],p[I,1])]*r[B][6][12,4]*r[C][3][10,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,0],p[I,0],p[C,0])]*r[B][6][12,4]*r[C][3][10,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,1],p[I,1],p[C,0])]*r[B][6][12,4]*r[C][3][10,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,0],p[B,1],p[I,0])]*r[B][6][12,4]*r[C][3][10,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,0],p[B,1],p[I,1])]*r[B][6][12,4]*r[C][3][10,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,1],p[C,0])]*r[B][6][12,4]*r[C][3][10,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[B,1],p[C,0])]*r[B][6][12,4]*r[C][3][10,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,1],p[C,0])]*r[B][6][12,4]*r[C][3][10,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[B,1],p[C,0])]*r[B][6][12,4]*r[C][3][10,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][24][3,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][9][3,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][54][3,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][39][3,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,0])]*r[A][24][3,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,1])]*r[A][54][3,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,0])]*r[A][24][3,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,0])]*r[A][54][3,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][6][12,4]*r[C][3][10,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A3B12C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,12),(C,9)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += h[p[B,1],p[C,1]]*r[B][6][12,4]*r[C][7][9,5]
    hv += -1*g[dei(p[B,0],p[B,0],p[B,1],p[C,1])]*r[B][80][12,4]*r[C][7][9,5]
    hv += -1*g[dei(p[B,1],p[B,1],p[B,1],p[C,1])]*r[B][148][12,4]*r[C][7][9,5]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,0],p[C,1])]*r[B][6][12,4]*r[C][115][9,5]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[C,0],p[C,0])]*r[B][6][12,4]*r[C][103][9,5]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,1],p[C,1])]*r[B][6][12,4]*r[C][115][9,5]
    hv += -1/2*g[dei(p[C,0],p[C,1],p[B,1],p[C,0])]*r[B][6][12,4]*r[C][103][9,5]
    hv += sum(1/2*g[dei(p[B,1],p[C,1],p[I,0],p[I,0])]*r[B][6][12,4]*r[C][7][9,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[C,1],p[I,1],p[I,1])]*r[B][6][12,4]*r[C][7][9,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,0],p[I,0],p[C,1])]*r[B][6][12,4]*r[C][7][9,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,1],p[I,1],p[C,1])]*r[B][6][12,4]*r[C][7][9,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,1],p[B,1],p[I,0])]*r[B][6][12,4]*r[C][7][9,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,1],p[B,1],p[I,1])]*r[B][6][12,4]*r[C][7][9,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,1],p[C,1])]*r[B][6][12,4]*r[C][7][9,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[B,1],p[C,1])]*r[B][6][12,4]*r[C][7][9,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,1],p[C,1])]*r[B][6][12,4]*r[C][7][9,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[B,1],p[C,1])]*r[B][6][12,4]*r[C][7][9,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][24][3,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][9][3,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][54][3,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][39][3,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,0])]*r[A][24][3,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,1])]*r[A][54][3,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,1])]*r[A][24][3,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,1])]*r[A][54][3,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][6][12,4]*r[C][7][9,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A3B8C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,8),(C,13)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*h[p[C,0],p[B,0]]*r[B][1][8,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,0],p[B,1])]*r[B][137][8,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,0],p[B,0])]*r[B][125][8,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,1],p[B,1])]*r[B][137][8,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,1],p[B,0])]*r[B][125][8,4]*r[C][0][13,5]
    hv += -1*g[dei(p[C,0],p[B,0],p[C,0],p[C,0])]*r[B][1][8,4]*r[C][66][13,5]
    hv += -1*g[dei(p[C,0],p[B,0],p[C,1],p[C,1])]*r[B][1][8,4]*r[C][86][13,5]
    hv += sum(-1/2*g[dei(p[C,0],p[B,0],p[I,0],p[I,0])]*r[B][1][8,4]*r[C][0][13,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,0],p[B,0],p[I,0],p[I,0])]*r[B][1][8,4]*r[C][0][13,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[B,0],p[I,1],p[I,1])]*r[B][1][8,4]*r[C][0][13,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,0],p[B,0],p[I,1],p[I,1])]*r[B][1][8,4]*r[C][0][13,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[I,0],p[I,0],p[B,0])]*r[B][1][8,4]*r[C][0][13,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[I,1],p[I,1],p[B,0])]*r[B][1][8,4]*r[C][0][13,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[B,0],p[C,0],p[I,0])]*r[B][1][8,4]*r[C][0][13,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[B,0],p[C,0],p[I,1])]*r[B][1][8,4]*r[C][0][13,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[C,0],p[B,0])]*r[B][1][8,4]*r[C][0][13,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[C,0],p[B,0])]*r[B][1][8,4]*r[C][0][13,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[C,0],p[B,0])]*r[A][9][3,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[C,0],p[B,0])]*r[A][39][3,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,0],p[A,0])]*r[A][9][3,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,0],p[A,1])]*r[A][39][3,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[A,0],p[B,0])]*r[A][9][3,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[A,1],p[B,0])]*r[A][39][3,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,0],p[A,0])]*r[A][9][3,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += -1*g[dei(p[C,0],p[B,0],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,1],p[A,1])]*r[A][39][3,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += -1*g[dei(p[C,0],p[B,0],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][1][8,4]*r[C][0][13,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A3B7C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,7),(C,13)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*h[p[C,0],p[B,1]]*r[B][5][7,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,0],p[B,1])]*r[B][73][7,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,0],p[B,0])]*r[B][61][7,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[B,0],p[B,1])]*r[B][73][7,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,0],p[B,0])]*r[B][61][7,4]*r[C][0][13,5]
    hv += -1*g[dei(p[C,0],p[B,1],p[C,0],p[C,0])]*r[B][5][7,4]*r[C][66][13,5]
    hv += -1*g[dei(p[C,0],p[B,1],p[C,1],p[C,1])]*r[B][5][7,4]*r[C][86][13,5]
    hv += sum(-1/2*g[dei(p[C,0],p[B,1],p[I,0],p[I,0])]*r[B][5][7,4]*r[C][0][13,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,0],p[B,1],p[I,0],p[I,0])]*r[B][5][7,4]*r[C][0][13,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[B,1],p[I,1],p[I,1])]*r[B][5][7,4]*r[C][0][13,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,0],p[B,1],p[I,1],p[I,1])]*r[B][5][7,4]*r[C][0][13,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[I,0],p[I,0],p[B,1])]*r[B][5][7,4]*r[C][0][13,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[I,1],p[I,1],p[B,1])]*r[B][5][7,4]*r[C][0][13,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[B,1],p[C,0],p[I,0])]*r[B][5][7,4]*r[C][0][13,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[B,1],p[C,0],p[I,1])]*r[B][5][7,4]*r[C][0][13,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[C,0],p[B,1])]*r[B][5][7,4]*r[C][0][13,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[C,0],p[B,1])]*r[B][5][7,4]*r[C][0][13,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[C,0],p[B,1])]*r[A][9][3,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[C,0],p[B,1])]*r[A][39][3,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,0],p[A,0])]*r[A][9][3,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,0],p[A,1])]*r[A][39][3,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[A,0],p[B,1])]*r[A][9][3,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[A,1],p[B,1])]*r[A][39][3,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,0],p[A,0])]*r[A][9][3,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += -1*g[dei(p[C,0],p[B,1],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,1],p[A,1])]*r[A][39][3,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += -1*g[dei(p[C,0],p[B,1],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][5][7,4]*r[C][0][13,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A3B8C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,8),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*h[p[C,1],p[B,0]]*r[B][1][8,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[C,1],p[B,1])]*r[B][137][8,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,1],p[B,0])]*r[B][125][8,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,1],p[B,1])]*r[B][137][8,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,1],p[B,0])]*r[B][125][8,4]*r[C][4][14,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[C,0],p[C,0])]*r[B][1][8,4]*r[C][130][14,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[C,1],p[C,1])]*r[B][1][8,4]*r[C][150][14,5]
    hv += sum(-1/2*g[dei(p[C,1],p[B,0],p[I,0],p[I,0])]*r[B][1][8,4]*r[C][4][14,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,1],p[B,0],p[I,0],p[I,0])]*r[B][1][8,4]*r[C][4][14,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[B,0],p[I,1],p[I,1])]*r[B][1][8,4]*r[C][4][14,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,1],p[B,0],p[I,1],p[I,1])]*r[B][1][8,4]*r[C][4][14,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[I,0],p[I,0],p[B,0])]*r[B][1][8,4]*r[C][4][14,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[I,1],p[I,1],p[B,0])]*r[B][1][8,4]*r[C][4][14,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[B,0],p[C,1],p[I,0])]*r[B][1][8,4]*r[C][4][14,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[B,0],p[C,1],p[I,1])]*r[B][1][8,4]*r[C][4][14,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[C,1],p[B,0])]*r[B][1][8,4]*r[C][4][14,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[C,1],p[B,0])]*r[B][1][8,4]*r[C][4][14,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[C,1],p[B,0])]*r[A][9][3,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[C,1],p[B,0])]*r[A][39][3,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,1],p[A,0])]*r[A][9][3,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,1],p[A,1])]*r[A][39][3,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[A,0],p[B,0])]*r[A][9][3,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[A,1],p[B,0])]*r[A][39][3,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,0],p[A,0])]*r[A][9][3,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,1],p[A,1])]*r[A][39][3,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][1][8,4]*r[C][4][14,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A3B7C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,7),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*h[p[C,1],p[B,1]]*r[B][5][7,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[C,1],p[B,1])]*r[B][73][7,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,1],p[B,0])]*r[B][61][7,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[B,0],p[B,1])]*r[B][73][7,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,0],p[B,0])]*r[B][61][7,4]*r[C][4][14,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[C,0],p[C,0])]*r[B][5][7,4]*r[C][130][14,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[C,1],p[C,1])]*r[B][5][7,4]*r[C][150][14,5]
    hv += sum(-1/2*g[dei(p[C,1],p[B,1],p[I,0],p[I,0])]*r[B][5][7,4]*r[C][4][14,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,1],p[B,1],p[I,0],p[I,0])]*r[B][5][7,4]*r[C][4][14,5]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[B,1],p[I,1],p[I,1])]*r[B][5][7,4]*r[C][4][14,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[C,1],p[B,1],p[I,1],p[I,1])]*r[B][5][7,4]*r[C][4][14,5]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[I,0],p[I,0],p[B,1])]*r[B][5][7,4]*r[C][4][14,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[I,1],p[I,1],p[B,1])]*r[B][5][7,4]*r[C][4][14,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[B,1],p[C,1],p[I,0])]*r[B][5][7,4]*r[C][4][14,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[B,1],p[C,1],p[I,1])]*r[B][5][7,4]*r[C][4][14,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[C,1],p[B,1])]*r[B][5][7,4]*r[C][4][14,5]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[C,1],p[B,1])]*r[B][5][7,4]*r[C][4][14,5]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[C,1],p[B,1])]*r[A][9][3,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[C,1],p[B,1])]*r[A][39][3,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,1],p[A,0])]*r[A][9][3,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,1],p[A,1])]*r[A][39][3,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[A,0],p[B,1])]*r[A][9][3,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[A,1],p[B,1])]*r[A][39][3,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,0],p[A,0])]*r[A][9][3,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,1],p[A,1])]*r[A][39][3,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][5][7,4]*r[C][4][14,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A3B15C6(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,15),(C,6)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[B,0],p[C,0],p[B,1],p[C,1])]*r[B][29][15,4]*r[C][49][6,5]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[B,1],p[C,0])]*r[B][29][15,4]*r[C][31][6,5]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[B,0],p[C,1])]*r[B][47][15,4]*r[C][49][6,5]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[B,0],p[C,0])]*r[B][47][15,4]*r[C][31][6,5]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A3B2C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,2),(C,2)]))
    hv = 0.0
    
    hv += -1*g[dei(p[C,0],p[B,0],p[B,0],p[C,0])]*r[B][21][2,4]*r[C][12][2,5]
    hv += -1*g[dei(p[C,0],p[B,1],p[B,1],p[C,0])]*r[B][51][2,4]*r[C][12][2,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[B,0],p[C,1])]*r[B][21][2,4]*r[C][42][2,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[B,1],p[C,1])]*r[B][51][2,4]*r[C][42][2,5]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A3B2C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,2),(C,3)]))
    hv = 0.0
    
    hv += -1*g[dei(p[C,0],p[B,0],p[B,0],p[C,0])]*r[B][21][2,4]*r[C][12][3,5]
    hv += -1*g[dei(p[C,0],p[B,1],p[B,1],p[C,0])]*r[B][51][2,4]*r[C][12][3,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[B,0],p[C,1])]*r[B][21][2,4]*r[C][42][3,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[B,1],p[C,1])]*r[B][51][2,4]*r[C][42][3,5]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A3B3C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,3),(C,2)]))
    hv = 0.0
    
    hv += -1*g[dei(p[C,0],p[B,0],p[B,0],p[C,0])]*r[B][21][3,4]*r[C][12][2,5]
    hv += -1*g[dei(p[C,0],p[B,1],p[B,1],p[C,0])]*r[B][51][3,4]*r[C][12][2,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[B,0],p[C,1])]*r[B][21][3,4]*r[C][42][2,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[B,1],p[C,1])]*r[B][51][3,4]*r[C][42][2,5]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A3B3C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,3),(C,3)]))
    hv = 0.0
    
    hv += -1*g[dei(p[C,0],p[B,0],p[B,0],p[C,0])]*r[B][21][3,4]*r[C][12][3,5]
    hv += -1*g[dei(p[C,0],p[B,1],p[B,1],p[C,0])]*r[B][51][3,4]*r[C][12][3,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[B,0],p[C,1])]*r[B][21][3,4]*r[C][42][3,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[B,1],p[C,1])]*r[B][51][3,4]*r[C][42][3,5]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A3B2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,2)]))
    hv = 0.0
    
    hv += -1*g[dei(p[C,0],p[B,0],p[B,0],p[C,1])]*r[B][21][2,4]*r[C][18][0,5]
    hv += -1*g[dei(p[C,0],p[B,1],p[B,1],p[C,1])]*r[B][51][2,4]*r[C][18][0,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[B,0],p[C,0])]*r[B][21][2,4]*r[C][36][0,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[B,1],p[C,0])]*r[B][51][2,4]*r[C][36][0,5]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A3B2C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,2),(C,1)]))
    hv = 0.0
    
    hv += -1*g[dei(p[C,0],p[B,0],p[B,0],p[C,1])]*r[B][21][2,4]*r[C][18][1,5]
    hv += -1*g[dei(p[C,0],p[B,1],p[B,1],p[C,1])]*r[B][51][2,4]*r[C][18][1,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[B,0],p[C,0])]*r[B][21][2,4]*r[C][36][1,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[B,1],p[C,0])]*r[B][51][2,4]*r[C][36][1,5]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A3B3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,3)]))
    hv = 0.0
    
    hv += -1*g[dei(p[C,0],p[B,0],p[B,0],p[C,1])]*r[B][21][3,4]*r[C][18][0,5]
    hv += -1*g[dei(p[C,0],p[B,1],p[B,1],p[C,1])]*r[B][51][3,4]*r[C][18][0,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[B,0],p[C,0])]*r[B][21][3,4]*r[C][36][0,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[B,1],p[C,0])]*r[B][51][3,4]*r[C][36][0,5]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A3B3C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,3),(C,1)]))
    hv = 0.0
    
    hv += -1*g[dei(p[C,0],p[B,0],p[B,0],p[C,1])]*r[B][21][3,4]*r[C][18][1,5]
    hv += -1*g[dei(p[C,0],p[B,1],p[B,1],p[C,1])]*r[B][51][3,4]*r[C][18][1,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[B,0],p[C,0])]*r[B][21][3,4]*r[C][36][1,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[B,1],p[C,0])]*r[B][51][3,4]*r[C][36][1,5]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A3C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(C,2)]))
    hv = 0.0
    
    hv += -1*g[dei(p[C,0],p[B,1],p[B,0],p[C,0])]*r[B][27][0,4]*r[C][12][2,5]
    hv += -1*g[dei(p[C,0],p[B,0],p[B,1],p[C,0])]*r[B][45][0,4]*r[C][12][2,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[B,0],p[C,1])]*r[B][27][0,4]*r[C][42][2,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[B,1],p[C,1])]*r[B][45][0,4]*r[C][42][2,5]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A3C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(C,3)]))
    hv = 0.0
    
    hv += -1*g[dei(p[C,0],p[B,1],p[B,0],p[C,0])]*r[B][27][0,4]*r[C][12][3,5]
    hv += -1*g[dei(p[C,0],p[B,0],p[B,1],p[C,0])]*r[B][45][0,4]*r[C][12][3,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[B,0],p[C,1])]*r[B][27][0,4]*r[C][42][3,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[B,1],p[C,1])]*r[B][45][0,4]*r[C][42][3,5]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A3B1C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,1),(C,2)]))
    hv = 0.0
    
    hv += -1*g[dei(p[C,0],p[B,1],p[B,0],p[C,0])]*r[B][27][1,4]*r[C][12][2,5]
    hv += -1*g[dei(p[C,0],p[B,0],p[B,1],p[C,0])]*r[B][45][1,4]*r[C][12][2,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[B,0],p[C,1])]*r[B][27][1,4]*r[C][42][2,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[B,1],p[C,1])]*r[B][45][1,4]*r[C][42][2,5]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A3B1C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,1),(C,3)]))
    hv = 0.0
    
    hv += -1*g[dei(p[C,0],p[B,1],p[B,0],p[C,0])]*r[B][27][1,4]*r[C][12][3,5]
    hv += -1*g[dei(p[C,0],p[B,0],p[B,1],p[C,0])]*r[B][45][1,4]*r[C][12][3,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[B,0],p[C,1])]*r[B][27][1,4]*r[C][42][3,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[B,1],p[C,1])]*r[B][45][1,4]*r[C][42][3,5]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3)]))
    hv = 0.0
    
    hv += -1*g[dei(p[C,0],p[B,1],p[B,0],p[C,1])]*r[B][27][0,4]*r[C][18][0,5]
    hv += -1*g[dei(p[C,0],p[B,0],p[B,1],p[C,1])]*r[B][45][0,4]*r[C][18][0,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[B,0],p[C,0])]*r[B][27][0,4]*r[C][36][0,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[B,1],p[C,0])]*r[B][45][0,4]*r[C][36][0,5]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A3C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(C,1)]))
    hv = 0.0
    
    hv += -1*g[dei(p[C,0],p[B,1],p[B,0],p[C,1])]*r[B][27][0,4]*r[C][18][1,5]
    hv += -1*g[dei(p[C,0],p[B,0],p[B,1],p[C,1])]*r[B][45][0,4]*r[C][18][1,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[B,0],p[C,0])]*r[B][27][0,4]*r[C][36][1,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[B,1],p[C,0])]*r[B][45][0,4]*r[C][36][1,5]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A3B1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,1)]))
    hv = 0.0
    
    hv += -1*g[dei(p[C,0],p[B,1],p[B,0],p[C,1])]*r[B][27][1,4]*r[C][18][0,5]
    hv += -1*g[dei(p[C,0],p[B,0],p[B,1],p[C,1])]*r[B][45][1,4]*r[C][18][0,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[B,0],p[C,0])]*r[B][27][1,4]*r[C][36][0,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[B,1],p[C,0])]*r[B][45][1,4]*r[C][36][0,5]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A3B1C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,1),(C,1)]))
    hv = 0.0
    
    hv += -1*g[dei(p[C,0],p[B,1],p[B,0],p[C,1])]*r[B][27][1,4]*r[C][18][1,5]
    hv += -1*g[dei(p[C,0],p[B,0],p[B,1],p[C,1])]*r[B][45][1,4]*r[C][18][1,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[B,0],p[C,0])]*r[B][27][1,4]*r[C][36][1,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[B,1],p[C,0])]*r[B][45][1,4]*r[C][36][1,5]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _A3B6C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,3),(B,6),(C,15)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[C,0],p[B,0],p[C,1],p[B,1])]*r[B][34][6,4]*r[C][14][15,5]
    hv += 1/2*g[dei(p[C,0],p[B,1],p[C,1],p[B,0])]*r[B][16][6,4]*r[C][14][15,5]
    hv += 1/2*g[dei(p[C,1],p[B,0],p[C,0],p[B,1])]*r[B][34][6,4]*r[C][32][15,5]
    hv += 1/2*g[dei(p[C,1],p[B,1],p[C,0],p[B,0])]*r[B][16][6,4]*r[C][32][15,5]
    
    hd[v] = hd.get(v,0.0)+hv
    
    return hd
    
def _B11C5I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,11),(C,5),(I,7)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[I,0])]*r[A][30][0,3]*r[B][2][11,4]*r[I][3][7,0]
        hv += g[dei(p[A,0],p[A,1],p[B,0],p[I,0])]*r[A][15][0,3]*r[B][2][11,4]*r[I][3][7,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[I,0])]*r[A][48][0,3]*r[B][2][11,4]*r[I][3][7,0]
        hv += g[dei(p[A,1],p[A,0],p[B,0],p[I,0])]*r[A][33][0,3]*r[B][2][11,4]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,0],p[A,1])]*r[A][30][0,3]*r[B][2][11,4]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,0],p[A,0])]*r[A][48][0,3]*r[B][2][11,4]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[I,0])]*r[A][30][0,3]*r[B][2][11,4]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[I,0])]*r[A][48][0,3]*r[B][2][11,4]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][2][11,4]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][2][11,4]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B11C5I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,11),(C,5),(I,8)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[I,1])]*r[A][30][0,3]*r[B][2][11,4]*r[I][7][8,0]
        hv += g[dei(p[A,0],p[A,1],p[B,0],p[I,1])]*r[A][15][0,3]*r[B][2][11,4]*r[I][7][8,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[I,1])]*r[A][48][0,3]*r[B][2][11,4]*r[I][7][8,0]
        hv += g[dei(p[A,1],p[A,0],p[B,0],p[I,1])]*r[A][33][0,3]*r[B][2][11,4]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,0],p[A,1])]*r[A][30][0,3]*r[B][2][11,4]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,0],p[A,0])]*r[A][48][0,3]*r[B][2][11,4]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[I,1])]*r[A][30][0,3]*r[B][2][11,4]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[I,1])]*r[A][48][0,3]*r[B][2][11,4]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][2][11,4]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][2][11,4]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B12C5I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,12),(C,5),(I,7)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[I,0])]*r[A][30][0,3]*r[B][6][12,4]*r[I][3][7,0]
        hv += g[dei(p[A,0],p[A,1],p[B,1],p[I,0])]*r[A][15][0,3]*r[B][6][12,4]*r[I][3][7,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[I,0])]*r[A][48][0,3]*r[B][6][12,4]*r[I][3][7,0]
        hv += g[dei(p[A,1],p[A,0],p[B,1],p[I,0])]*r[A][33][0,3]*r[B][6][12,4]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,1],p[A,1])]*r[A][30][0,3]*r[B][6][12,4]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,1],p[A,0])]*r[A][48][0,3]*r[B][6][12,4]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[I,0])]*r[A][30][0,3]*r[B][6][12,4]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[I,0])]*r[A][48][0,3]*r[B][6][12,4]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][6][12,4]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][6][12,4]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B12C5I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,12),(C,5),(I,8)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[I,1])]*r[A][30][0,3]*r[B][6][12,4]*r[I][7][8,0]
        hv += g[dei(p[A,0],p[A,1],p[B,1],p[I,1])]*r[A][15][0,3]*r[B][6][12,4]*r[I][7][8,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[I,1])]*r[A][48][0,3]*r[B][6][12,4]*r[I][7][8,0]
        hv += g[dei(p[A,1],p[A,0],p[B,1],p[I,1])]*r[A][33][0,3]*r[B][6][12,4]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,1],p[A,1])]*r[A][30][0,3]*r[B][6][12,4]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,1],p[A,0])]*r[A][48][0,3]*r[B][6][12,4]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[I,1])]*r[A][30][0,3]*r[B][6][12,4]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[I,1])]*r[A][48][0,3]*r[B][6][12,4]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][6][12,4]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][6][12,4]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A11C5I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(C,5),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,0],p[B,1],p[B,0],p[I,0])]*r[A][0][11,3]*r[B][27][0,4]*r[I][3][7,0]
        hv += -1*g[dei(p[A,0],p[B,0],p[B,1],p[I,0])]*r[A][0][11,3]*r[B][45][0,4]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A11C5I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(C,5),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,0],p[B,1],p[B,0],p[I,1])]*r[A][0][11,3]*r[B][27][0,4]*r[I][7][8,0]
        hv += -1*g[dei(p[A,0],p[B,0],p[B,1],p[I,1])]*r[A][0][11,3]*r[B][45][0,4]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A12C5I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(C,5),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,1],p[B,1],p[B,0],p[I,0])]*r[A][4][12,3]*r[B][27][0,4]*r[I][3][7,0]
        hv += -1*g[dei(p[A,1],p[B,0],p[B,1],p[I,0])]*r[A][4][12,3]*r[B][45][0,4]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A12C5I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(C,5),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,1],p[B,1],p[B,0],p[I,1])]*r[A][4][12,3]*r[B][27][0,4]*r[I][7][8,0]
        hv += -1*g[dei(p[A,1],p[B,0],p[B,1],p[I,1])]*r[A][4][12,3]*r[B][45][0,4]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B8C5I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,8),(C,5),(I,12)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,1],p[I,0],p[B,0])]*r[A][15][0,3]*r[B][1][8,4]*r[I][0][12,0]
        hv += -1/2*g[dei(p[A,1],p[A,0],p[I,0],p[B,0])]*r[A][33][0,3]*r[B][1][8,4]*r[I][0][12,0]
        hv += 1/2*g[dei(p[A,0],p[B,0],p[I,0],p[A,1])]*r[A][15][0,3]*r[B][1][8,4]*r[I][0][12,0]
        hv += 1/2*g[dei(p[A,1],p[B,0],p[I,0],p[A,0])]*r[A][33][0,3]*r[B][1][8,4]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[A,0],p[B,0])]*r[A][15][0,3]*r[B][1][8,4]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[A,1],p[B,0])]*r[A][33][0,3]*r[B][1][8,4]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[B,0],p[A,0],p[A,1])]*r[A][15][0,3]*r[B][1][8,4]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[B,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][1][8,4]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[B,0],p[A,1],p[A,0])]*r[A][33][0,3]*r[B][1][8,4]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[B,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][1][8,4]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B7C5I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,7),(C,5),(I,12)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,1],p[I,0],p[B,1])]*r[A][15][0,3]*r[B][5][7,4]*r[I][0][12,0]
        hv += -1/2*g[dei(p[A,1],p[A,0],p[I,0],p[B,1])]*r[A][33][0,3]*r[B][5][7,4]*r[I][0][12,0]
        hv += 1/2*g[dei(p[A,0],p[B,1],p[I,0],p[A,1])]*r[A][15][0,3]*r[B][5][7,4]*r[I][0][12,0]
        hv += 1/2*g[dei(p[A,1],p[B,1],p[I,0],p[A,0])]*r[A][33][0,3]*r[B][5][7,4]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[A,0],p[B,1])]*r[A][15][0,3]*r[B][5][7,4]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[A,1],p[B,1])]*r[A][33][0,3]*r[B][5][7,4]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[B,1],p[A,0],p[A,1])]*r[A][15][0,3]*r[B][5][7,4]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[B,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][5][7,4]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[B,1],p[A,1],p[A,0])]*r[A][33][0,3]*r[B][5][7,4]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[B,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][5][7,4]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B8C5I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,8),(C,5),(I,11)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,1],p[I,1],p[B,0])]*r[A][15][0,3]*r[B][1][8,4]*r[I][4][11,0]
        hv += -1/2*g[dei(p[A,1],p[A,0],p[I,1],p[B,0])]*r[A][33][0,3]*r[B][1][8,4]*r[I][4][11,0]
        hv += 1/2*g[dei(p[A,0],p[B,0],p[I,1],p[A,1])]*r[A][15][0,3]*r[B][1][8,4]*r[I][4][11,0]
        hv += 1/2*g[dei(p[A,1],p[B,0],p[I,1],p[A,0])]*r[A][33][0,3]*r[B][1][8,4]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[A,0],p[B,0])]*r[A][15][0,3]*r[B][1][8,4]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[A,1],p[B,0])]*r[A][33][0,3]*r[B][1][8,4]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[B,0],p[A,0],p[A,1])]*r[A][15][0,3]*r[B][1][8,4]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[B,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][1][8,4]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[B,0],p[A,1],p[A,0])]*r[A][33][0,3]*r[B][1][8,4]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[B,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][1][8,4]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B7C5I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,7),(C,5),(I,11)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,1],p[I,1],p[B,1])]*r[A][15][0,3]*r[B][5][7,4]*r[I][4][11,0]
        hv += -1/2*g[dei(p[A,1],p[A,0],p[I,1],p[B,1])]*r[A][33][0,3]*r[B][5][7,4]*r[I][4][11,0]
        hv += 1/2*g[dei(p[A,0],p[B,1],p[I,1],p[A,1])]*r[A][15][0,3]*r[B][5][7,4]*r[I][4][11,0]
        hv += 1/2*g[dei(p[A,1],p[B,1],p[I,1],p[A,0])]*r[A][33][0,3]*r[B][5][7,4]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[A,0],p[B,1])]*r[A][15][0,3]*r[B][5][7,4]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[A,1],p[B,1])]*r[A][33][0,3]*r[B][5][7,4]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[B,1],p[A,0],p[A,1])]*r[A][15][0,3]*r[B][5][7,4]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[B,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][5][7,4]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[B,1],p[A,1],p[A,0])]*r[A][33][0,3]*r[B][5][7,4]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[B,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][5][7,4]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A8C5I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(C,5),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,0],p[B,1],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][27][0,4]*r[I][0][12,0]
        hv += g[dei(p[I,0],p[B,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][45][0,4]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A7C5I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(C,5),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,0],p[B,1],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][27][0,4]*r[I][0][12,0]
        hv += g[dei(p[I,0],p[B,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][45][0,4]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A8C5I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(C,5),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,1],p[B,1],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][27][0,4]*r[I][4][11,0]
        hv += g[dei(p[I,1],p[B,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][45][0,4]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A7C5I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(C,5),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,1],p[B,1],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][27][0,4]*r[I][4][11,0]
        hv += g[dei(p[I,1],p[B,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][45][0,4]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B4C13I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,4),(C,13),(I,9)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[C,0],p[I,0])]*r[A][15][0,3]*r[C][0][13,5]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[C,0],p[I,0])]*r[A][33][0,3]*r[C][0][13,5]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[C,0],p[A,1])]*r[A][15][0,3]*r[C][0][13,5]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[C,0],p[A,0])]*r[A][33][0,3]*r[C][0][13,5]*r[I][1][9,0]
        hv += -1/2*g[dei(p[C,0],p[A,1],p[A,0],p[I,0])]*r[A][15][0,3]*r[C][0][13,5]*r[I][1][9,0]
        hv += -1/2*g[dei(p[C,0],p[A,0],p[A,1],p[I,0])]*r[A][33][0,3]*r[C][0][13,5]*r[I][1][9,0]
        hv += 1/2*g[dei(p[C,0],p[I,0],p[A,0],p[A,1])]*r[A][15][0,3]*r[C][0][13,5]*r[I][1][9,0]
        hv += g[dei(p[C,0],p[I,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[C][0][13,5]*r[I][1][9,0]
        hv += 1/2*g[dei(p[C,0],p[I,0],p[A,1],p[A,0])]*r[A][33][0,3]*r[C][0][13,5]*r[I][1][9,0]
        hv += g[dei(p[C,0],p[I,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[C][0][13,5]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B4C13I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,4),(C,13),(I,10)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[C,0],p[I,1])]*r[A][15][0,3]*r[C][0][13,5]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[C,0],p[I,1])]*r[A][33][0,3]*r[C][0][13,5]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[C,0],p[A,1])]*r[A][15][0,3]*r[C][0][13,5]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[C,0],p[A,0])]*r[A][33][0,3]*r[C][0][13,5]*r[I][5][10,0]
        hv += -1/2*g[dei(p[C,0],p[A,1],p[A,0],p[I,1])]*r[A][15][0,3]*r[C][0][13,5]*r[I][5][10,0]
        hv += -1/2*g[dei(p[C,0],p[A,0],p[A,1],p[I,1])]*r[A][33][0,3]*r[C][0][13,5]*r[I][5][10,0]
        hv += 1/2*g[dei(p[C,0],p[I,1],p[A,0],p[A,1])]*r[A][15][0,3]*r[C][0][13,5]*r[I][5][10,0]
        hv += g[dei(p[C,0],p[I,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[C][0][13,5]*r[I][5][10,0]
        hv += 1/2*g[dei(p[C,0],p[I,1],p[A,1],p[A,0])]*r[A][33][0,3]*r[C][0][13,5]*r[I][5][10,0]
        hv += g[dei(p[C,0],p[I,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[C][0][13,5]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B4C14I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,4),(C,14),(I,9)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[C,1],p[I,0])]*r[A][15][0,3]*r[C][4][14,5]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[C,1],p[I,0])]*r[A][33][0,3]*r[C][4][14,5]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[C,1],p[A,1])]*r[A][15][0,3]*r[C][4][14,5]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[C,1],p[A,0])]*r[A][33][0,3]*r[C][4][14,5]*r[I][1][9,0]
        hv += -1/2*g[dei(p[C,1],p[A,1],p[A,0],p[I,0])]*r[A][15][0,3]*r[C][4][14,5]*r[I][1][9,0]
        hv += -1/2*g[dei(p[C,1],p[A,0],p[A,1],p[I,0])]*r[A][33][0,3]*r[C][4][14,5]*r[I][1][9,0]
        hv += 1/2*g[dei(p[C,1],p[I,0],p[A,0],p[A,1])]*r[A][15][0,3]*r[C][4][14,5]*r[I][1][9,0]
        hv += g[dei(p[C,1],p[I,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[C][4][14,5]*r[I][1][9,0]
        hv += 1/2*g[dei(p[C,1],p[I,0],p[A,1],p[A,0])]*r[A][33][0,3]*r[C][4][14,5]*r[I][1][9,0]
        hv += g[dei(p[C,1],p[I,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[C][4][14,5]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B4C14I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,4),(C,14),(I,10)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[C,1],p[I,1])]*r[A][15][0,3]*r[C][4][14,5]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[C,1],p[I,1])]*r[A][33][0,3]*r[C][4][14,5]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[C,1],p[A,1])]*r[A][15][0,3]*r[C][4][14,5]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[C,1],p[A,0])]*r[A][33][0,3]*r[C][4][14,5]*r[I][5][10,0]
        hv += -1/2*g[dei(p[C,1],p[A,1],p[A,0],p[I,1])]*r[A][15][0,3]*r[C][4][14,5]*r[I][5][10,0]
        hv += -1/2*g[dei(p[C,1],p[A,0],p[A,1],p[I,1])]*r[A][33][0,3]*r[C][4][14,5]*r[I][5][10,0]
        hv += 1/2*g[dei(p[C,1],p[I,1],p[A,0],p[A,1])]*r[A][15][0,3]*r[C][4][14,5]*r[I][5][10,0]
        hv += g[dei(p[C,1],p[I,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[C][4][14,5]*r[I][5][10,0]
        hv += 1/2*g[dei(p[C,1],p[I,1],p[A,1],p[A,0])]*r[A][33][0,3]*r[C][4][14,5]*r[I][5][10,0]
        hv += g[dei(p[C,1],p[I,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[C][4][14,5]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B4C10I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,4),(C,10),(I,14)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,1],p[I,0],p[C,0])]*r[A][30][0,3]*r[C][3][10,5]*r[I][2][14,0]
        hv += -1*g[dei(p[A,0],p[A,1],p[I,0],p[C,0])]*r[A][15][0,3]*r[C][3][10,5]*r[I][2][14,0]
        hv += -1/2*g[dei(p[A,1],p[A,0],p[I,0],p[C,0])]*r[A][48][0,3]*r[C][3][10,5]*r[I][2][14,0]
        hv += -1*g[dei(p[A,1],p[A,0],p[I,0],p[C,0])]*r[A][33][0,3]*r[C][3][10,5]*r[I][2][14,0]
        hv += 1/2*g[dei(p[A,0],p[C,0],p[I,0],p[A,1])]*r[A][30][0,3]*r[C][3][10,5]*r[I][2][14,0]
        hv += 1/2*g[dei(p[A,1],p[C,0],p[I,0],p[A,0])]*r[A][48][0,3]*r[C][3][10,5]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[A,0],p[C,0])]*r[A][30][0,3]*r[C][3][10,5]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[A,1],p[C,0])]*r[A][48][0,3]*r[C][3][10,5]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[C][3][10,5]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[C][3][10,5]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B4C9I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,4),(C,9),(I,14)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,1],p[I,0],p[C,1])]*r[A][30][0,3]*r[C][7][9,5]*r[I][2][14,0]
        hv += -1*g[dei(p[A,0],p[A,1],p[I,0],p[C,1])]*r[A][15][0,3]*r[C][7][9,5]*r[I][2][14,0]
        hv += -1/2*g[dei(p[A,1],p[A,0],p[I,0],p[C,1])]*r[A][48][0,3]*r[C][7][9,5]*r[I][2][14,0]
        hv += -1*g[dei(p[A,1],p[A,0],p[I,0],p[C,1])]*r[A][33][0,3]*r[C][7][9,5]*r[I][2][14,0]
        hv += 1/2*g[dei(p[A,0],p[C,1],p[I,0],p[A,1])]*r[A][30][0,3]*r[C][7][9,5]*r[I][2][14,0]
        hv += 1/2*g[dei(p[A,1],p[C,1],p[I,0],p[A,0])]*r[A][48][0,3]*r[C][7][9,5]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[A,0],p[C,1])]*r[A][30][0,3]*r[C][7][9,5]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[A,1],p[C,1])]*r[A][48][0,3]*r[C][7][9,5]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[C][7][9,5]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[C][7][9,5]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B4C10I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,4),(C,10),(I,13)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,1],p[I,1],p[C,0])]*r[A][30][0,3]*r[C][3][10,5]*r[I][6][13,0]
        hv += -1*g[dei(p[A,0],p[A,1],p[I,1],p[C,0])]*r[A][15][0,3]*r[C][3][10,5]*r[I][6][13,0]
        hv += -1/2*g[dei(p[A,1],p[A,0],p[I,1],p[C,0])]*r[A][48][0,3]*r[C][3][10,5]*r[I][6][13,0]
        hv += -1*g[dei(p[A,1],p[A,0],p[I,1],p[C,0])]*r[A][33][0,3]*r[C][3][10,5]*r[I][6][13,0]
        hv += 1/2*g[dei(p[A,0],p[C,0],p[I,1],p[A,1])]*r[A][30][0,3]*r[C][3][10,5]*r[I][6][13,0]
        hv += 1/2*g[dei(p[A,1],p[C,0],p[I,1],p[A,0])]*r[A][48][0,3]*r[C][3][10,5]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[A,0],p[C,0])]*r[A][30][0,3]*r[C][3][10,5]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[A,1],p[C,0])]*r[A][48][0,3]*r[C][3][10,5]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[C][3][10,5]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[C][3][10,5]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _B4C9I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,4),(C,9),(I,13)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,1],p[I,1],p[C,1])]*r[A][30][0,3]*r[C][7][9,5]*r[I][6][13,0]
        hv += -1*g[dei(p[A,0],p[A,1],p[I,1],p[C,1])]*r[A][15][0,3]*r[C][7][9,5]*r[I][6][13,0]
        hv += -1/2*g[dei(p[A,1],p[A,0],p[I,1],p[C,1])]*r[A][48][0,3]*r[C][7][9,5]*r[I][6][13,0]
        hv += -1*g[dei(p[A,1],p[A,0],p[I,1],p[C,1])]*r[A][33][0,3]*r[C][7][9,5]*r[I][6][13,0]
        hv += 1/2*g[dei(p[A,0],p[C,1],p[I,1],p[A,1])]*r[A][30][0,3]*r[C][7][9,5]*r[I][6][13,0]
        hv += 1/2*g[dei(p[A,1],p[C,1],p[I,1],p[A,0])]*r[A][48][0,3]*r[C][7][9,5]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[A,0],p[C,1])]*r[A][30][0,3]*r[C][7][9,5]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[A,1],p[C,1])]*r[A][48][0,3]*r[C][7][9,5]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[C][7][9,5]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[C][7][9,5]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A13B4I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(B,4),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[C,0],p[I,0],p[A,0],p[C,1])]*r[A][2][13,3]*r[C][18][0,5]*r[I][1][9,0]
        hv += -1*g[dei(p[C,1],p[I,0],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][36][0,5]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A13B4I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(B,4),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[C,0],p[I,1],p[A,0],p[C,1])]*r[A][2][13,3]*r[C][18][0,5]*r[I][5][10,0]
        hv += -1*g[dei(p[C,1],p[I,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][36][0,5]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A14B4I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(B,4),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[C,0],p[I,0],p[A,1],p[C,1])]*r[A][6][14,3]*r[C][18][0,5]*r[I][1][9,0]
        hv += -1*g[dei(p[C,1],p[I,0],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][36][0,5]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A14B4I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(B,4),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[C,0],p[I,1],p[A,1],p[C,1])]*r[A][6][14,3]*r[C][18][0,5]*r[I][5][10,0]
        hv += -1*g[dei(p[C,1],p[I,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][36][0,5]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A10B4I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(B,4),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[C,0],p[A,0],p[I,0],p[C,1])]*r[A][1][10,3]*r[C][18][0,5]*r[I][2][14,0]
        hv += g[dei(p[C,1],p[A,0],p[I,0],p[C,0])]*r[A][1][10,3]*r[C][36][0,5]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A9B4I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(B,4),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[C,0],p[A,1],p[I,0],p[C,1])]*r[A][5][9,3]*r[C][18][0,5]*r[I][2][14,0]
        hv += g[dei(p[C,1],p[A,1],p[I,0],p[C,0])]*r[A][5][9,3]*r[C][36][0,5]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A10B4I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(B,4),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[C,0],p[A,0],p[I,1],p[C,1])]*r[A][1][10,3]*r[C][18][0,5]*r[I][6][13,0]
        hv += g[dei(p[C,1],p[A,0],p[I,1],p[C,0])]*r[A][1][10,3]*r[C][36][0,5]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A9B4I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(B,4),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[C,0],p[A,1],p[I,1],p[C,1])]*r[A][5][9,3]*r[C][18][0,5]*r[I][6][13,0]
        hv += g[dei(p[C,1],p[A,1],p[I,1],p[C,0])]*r[A][5][9,3]*r[C][36][0,5]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A3C13I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,13),(I,7)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1*g[dei(p[C,0],p[B,1],p[B,0],p[I,0])]*r[B][27][0,4]*r[C][0][13,5]*r[I][3][7,0]
        hv += -1*g[dei(p[C,0],p[B,0],p[B,1],p[I,0])]*r[B][45][0,4]*r[C][0][13,5]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A3C13I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,13),(I,8)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1*g[dei(p[C,0],p[B,1],p[B,0],p[I,1])]*r[B][27][0,4]*r[C][0][13,5]*r[I][7][8,0]
        hv += -1*g[dei(p[C,0],p[B,0],p[B,1],p[I,1])]*r[B][45][0,4]*r[C][0][13,5]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A3C14I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,14),(I,7)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1*g[dei(p[C,1],p[B,1],p[B,0],p[I,0])]*r[B][27][0,4]*r[C][4][14,5]*r[I][3][7,0]
        hv += -1*g[dei(p[C,1],p[B,0],p[B,1],p[I,0])]*r[B][45][0,4]*r[C][4][14,5]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A3C14I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,14),(I,8)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1*g[dei(p[C,1],p[B,1],p[B,0],p[I,1])]*r[B][27][0,4]*r[C][4][14,5]*r[I][7][8,0]
        hv += -1*g[dei(p[C,1],p[B,0],p[B,1],p[I,1])]*r[B][45][0,4]*r[C][4][14,5]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A3B11I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,11),(I,9)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[C,0],p[I,0],p[B,0],p[C,1])]*r[B][2][11,4]*r[C][18][0,5]*r[I][1][9,0]
        hv += -1*g[dei(p[C,1],p[I,0],p[B,0],p[C,0])]*r[B][2][11,4]*r[C][36][0,5]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A3B11I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,11),(I,10)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[C,0],p[I,1],p[B,0],p[C,1])]*r[B][2][11,4]*r[C][18][0,5]*r[I][5][10,0]
        hv += -1*g[dei(p[C,1],p[I,1],p[B,0],p[C,0])]*r[B][2][11,4]*r[C][36][0,5]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A3B12I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,12),(I,9)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[C,0],p[I,0],p[B,1],p[C,1])]*r[B][6][12,4]*r[C][18][0,5]*r[I][1][9,0]
        hv += -1*g[dei(p[C,1],p[I,0],p[B,1],p[C,0])]*r[B][6][12,4]*r[C][36][0,5]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A3B12I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,12),(I,10)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[C,0],p[I,1],p[B,1],p[C,1])]*r[B][6][12,4]*r[C][18][0,5]*r[I][5][10,0]
        hv += -1*g[dei(p[C,1],p[I,1],p[B,1],p[C,0])]*r[B][6][12,4]*r[C][36][0,5]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A3B8I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,8),(I,14)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[C,0],p[B,0],p[I,0],p[C,1])]*r[B][1][8,4]*r[C][18][0,5]*r[I][2][14,0]
        hv += g[dei(p[C,1],p[B,0],p[I,0],p[C,0])]*r[B][1][8,4]*r[C][36][0,5]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A3B7I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,7),(I,14)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[C,0],p[B,1],p[I,0],p[C,1])]*r[B][5][7,4]*r[C][18][0,5]*r[I][2][14,0]
        hv += g[dei(p[C,1],p[B,1],p[I,0],p[C,0])]*r[B][5][7,4]*r[C][36][0,5]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A3B8I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,8),(I,13)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[C,0],p[B,0],p[I,1],p[C,1])]*r[B][1][8,4]*r[C][18][0,5]*r[I][6][13,0]
        hv += g[dei(p[C,1],p[B,0],p[I,1],p[C,0])]*r[B][1][8,4]*r[C][36][0,5]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A3B7I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,7),(I,13)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[C,0],p[B,1],p[I,1],p[C,1])]*r[B][5][7,4]*r[C][18][0,5]*r[I][6][13,0]
        hv += g[dei(p[C,1],p[B,1],p[I,1],p[C,0])]*r[B][5][7,4]*r[C][36][0,5]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A3C10I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,10),(I,12)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += g[dei(p[I,0],p[B,1],p[B,0],p[C,0])]*r[B][27][0,4]*r[C][3][10,5]*r[I][0][12,0]
        hv += g[dei(p[I,0],p[B,0],p[B,1],p[C,0])]*r[B][45][0,4]*r[C][3][10,5]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A3C9I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,9),(I,12)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += g[dei(p[I,0],p[B,1],p[B,0],p[C,1])]*r[B][27][0,4]*r[C][7][9,5]*r[I][0][12,0]
        hv += g[dei(p[I,0],p[B,0],p[B,1],p[C,1])]*r[B][45][0,4]*r[C][7][9,5]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A3C10I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,10),(I,11)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += g[dei(p[I,1],p[B,1],p[B,0],p[C,0])]*r[B][27][0,4]*r[C][3][10,5]*r[I][4][11,0]
        hv += g[dei(p[I,1],p[B,0],p[B,1],p[C,0])]*r[B][45][0,4]*r[C][3][10,5]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A3C9I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,9),(I,11)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += g[dei(p[I,1],p[B,1],p[B,0],p[C,1])]*r[B][27][0,4]*r[C][7][9,5]*r[I][4][11,0]
        hv += g[dei(p[I,1],p[B,0],p[B,1],p[C,1])]*r[B][45][0,4]*r[C][7][9,5]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    return hd
    
def _A15B8C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,15),(B,8),(C,10)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[A,0],p[B,0],p[A,1],p[C,0])]*r[A][17][15,3]*r[B][1][8,4]*r[C][3][10,5]
    hv += -1*g[dei(p[A,1],p[B,0],p[A,0],p[C,0])]*r[A][35][15,3]*r[B][1][8,4]*r[C][3][10,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A15B8C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,15),(B,8),(C,9)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[A,0],p[B,0],p[A,1],p[C,1])]*r[A][17][15,3]*r[B][1][8,4]*r[C][7][9,5]
    hv += -1*g[dei(p[A,1],p[B,0],p[A,0],p[C,1])]*r[A][35][15,3]*r[B][1][8,4]*r[C][7][9,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A15B7C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,15),(B,7),(C,10)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[A,0],p[B,1],p[A,1],p[C,0])]*r[A][17][15,3]*r[B][5][7,4]*r[C][3][10,5]
    hv += -1*g[dei(p[A,1],p[B,1],p[A,0],p[C,0])]*r[A][35][15,3]*r[B][5][7,4]*r[C][3][10,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A15B7C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,15),(B,7),(C,9)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[A,0],p[B,1],p[A,1],p[C,1])]*r[A][17][15,3]*r[B][5][7,4]*r[C][7][9,5]
    hv += -1*g[dei(p[A,1],p[B,1],p[A,0],p[C,1])]*r[A][35][15,3]*r[B][5][7,4]*r[C][7][9,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A2B11C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(B,11),(C,10)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][24][2,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][9][2,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][54][2,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][39][2,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,0])]*r[A][24][2,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,1])]*r[A][54][2,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,0])]*r[A][24][2,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,0])]*r[A][54][2,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][2][11,4]*r[C][3][10,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A2B11C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(B,11),(C,9)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][24][2,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][9][2,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][54][2,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][39][2,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,0])]*r[A][24][2,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,1])]*r[A][54][2,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,1])]*r[A][24][2,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,1])]*r[A][54][2,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][2][11,4]*r[C][7][9,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _B11C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(B,11),(C,10)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][30][0,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][15][0,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][48][0,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][33][0,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,1])]*r[A][30][0,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,0])]*r[A][48][0,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,0])]*r[A][30][0,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,0])]*r[A][48][0,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][2][11,4]*r[C][3][10,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A1B11C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,11),(C,10)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][30][1,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][15][1,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][48][1,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][33][1,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,1])]*r[A][30][1,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,0])]*r[A][48][1,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,0])]*r[A][30][1,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,0])]*r[A][48][1,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][2][11,4]*r[C][3][10,5]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][2][11,4]*r[C][3][10,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _B11C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(B,11),(C,9)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][30][0,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][15][0,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][48][0,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][33][0,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,1])]*r[A][30][0,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,0])]*r[A][48][0,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,1])]*r[A][30][0,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,1])]*r[A][48][0,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][2][11,4]*r[C][7][9,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A1B11C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,11),(C,9)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][30][1,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][15][1,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][48][1,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][33][1,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,1])]*r[A][30][1,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,0])]*r[A][48][1,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,1])]*r[A][30][1,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,1])]*r[A][48][1,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][2][11,4]*r[C][7][9,5]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][2][11,4]*r[C][7][9,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A2B12C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(B,12),(C,10)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][24][2,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][9][2,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][54][2,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][39][2,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,0])]*r[A][24][2,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,1])]*r[A][54][2,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,0])]*r[A][24][2,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,0])]*r[A][54][2,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][6][12,4]*r[C][3][10,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A2B12C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(B,12),(C,9)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][24][2,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][9][2,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][54][2,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][39][2,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,0])]*r[A][24][2,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,1])]*r[A][54][2,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,1])]*r[A][24][2,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,1])]*r[A][54][2,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][6][12,4]*r[C][7][9,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _B12C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(B,12),(C,10)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][30][0,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][15][0,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][48][0,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][33][0,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,1])]*r[A][30][0,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,0])]*r[A][48][0,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,0])]*r[A][30][0,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,0])]*r[A][48][0,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][6][12,4]*r[C][3][10,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A1B12C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,12),(C,10)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][30][1,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][15][1,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][48][1,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][33][1,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,1])]*r[A][30][1,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,0])]*r[A][48][1,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,0])]*r[A][30][1,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,0])]*r[A][48][1,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][6][12,4]*r[C][3][10,5]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][6][12,4]*r[C][3][10,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _B12C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(B,12),(C,9)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][30][0,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][15][0,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][48][0,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][33][0,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,1])]*r[A][30][0,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,0])]*r[A][48][0,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,1])]*r[A][30][0,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,1])]*r[A][48][0,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][6][12,4]*r[C][7][9,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A1B12C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,12),(C,9)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][30][1,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][15][1,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][48][1,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][33][1,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,1])]*r[A][30][1,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,0])]*r[A][48][1,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,1])]*r[A][30][1,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,1])]*r[A][48][1,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][6][12,4]*r[C][7][9,5]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][6][12,4]*r[C][7][9,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11B2C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,2),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[A,0],p[B,0],p[B,0],p[C,0])]*r[A][0][11,3]*r[B][21][2,4]*r[C][3][10,5]
    hv += -1*g[dei(p[A,0],p[B,1],p[B,1],p[C,0])]*r[A][0][11,3]*r[B][51][2,4]*r[C][3][10,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11B3C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,3),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[A,0],p[B,0],p[B,0],p[C,0])]*r[A][0][11,3]*r[B][21][3,4]*r[C][3][10,5]
    hv += -1*g[dei(p[A,0],p[B,1],p[B,1],p[C,0])]*r[A][0][11,3]*r[B][51][3,4]*r[C][3][10,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11B2C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,2),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[A,0],p[B,0],p[B,0],p[C,1])]*r[A][0][11,3]*r[B][21][2,4]*r[C][7][9,5]
    hv += -1*g[dei(p[A,0],p[B,1],p[B,1],p[C,1])]*r[A][0][11,3]*r[B][51][2,4]*r[C][7][9,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11B3C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,3),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[A,0],p[B,0],p[B,0],p[C,1])]*r[A][0][11,3]*r[B][21][3,4]*r[C][7][9,5]
    hv += -1*g[dei(p[A,0],p[B,1],p[B,1],p[C,1])]*r[A][0][11,3]*r[B][51][3,4]*r[C][7][9,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[A,0],p[B,1],p[B,0],p[C,0])]*r[A][0][11,3]*r[B][27][0,4]*r[C][3][10,5]
    hv += -1*g[dei(p[A,0],p[B,0],p[B,1],p[C,0])]*r[A][0][11,3]*r[B][45][0,4]*r[C][3][10,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11B1C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,1),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[A,0],p[B,1],p[B,0],p[C,0])]*r[A][0][11,3]*r[B][27][1,4]*r[C][3][10,5]
    hv += -1*g[dei(p[A,0],p[B,0],p[B,1],p[C,0])]*r[A][0][11,3]*r[B][45][1,4]*r[C][3][10,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[A,0],p[B,1],p[B,0],p[C,1])]*r[A][0][11,3]*r[B][27][0,4]*r[C][7][9,5]
    hv += -1*g[dei(p[A,0],p[B,0],p[B,1],p[C,1])]*r[A][0][11,3]*r[B][45][0,4]*r[C][7][9,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11B1C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,1),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[A,0],p[B,1],p[B,0],p[C,1])]*r[A][0][11,3]*r[B][27][1,4]*r[C][7][9,5]
    hv += -1*g[dei(p[A,0],p[B,0],p[B,1],p[C,1])]*r[A][0][11,3]*r[B][45][1,4]*r[C][7][9,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12B2C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,2),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[A,1],p[B,0],p[B,0],p[C,0])]*r[A][4][12,3]*r[B][21][2,4]*r[C][3][10,5]
    hv += -1*g[dei(p[A,1],p[B,1],p[B,1],p[C,0])]*r[A][4][12,3]*r[B][51][2,4]*r[C][3][10,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12B3C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,3),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[A,1],p[B,0],p[B,0],p[C,0])]*r[A][4][12,3]*r[B][21][3,4]*r[C][3][10,5]
    hv += -1*g[dei(p[A,1],p[B,1],p[B,1],p[C,0])]*r[A][4][12,3]*r[B][51][3,4]*r[C][3][10,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12B2C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,2),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[A,1],p[B,0],p[B,0],p[C,1])]*r[A][4][12,3]*r[B][21][2,4]*r[C][7][9,5]
    hv += -1*g[dei(p[A,1],p[B,1],p[B,1],p[C,1])]*r[A][4][12,3]*r[B][51][2,4]*r[C][7][9,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12B3C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,3),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[A,1],p[B,0],p[B,0],p[C,1])]*r[A][4][12,3]*r[B][21][3,4]*r[C][7][9,5]
    hv += -1*g[dei(p[A,1],p[B,1],p[B,1],p[C,1])]*r[A][4][12,3]*r[B][51][3,4]*r[C][7][9,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[A,1],p[B,1],p[B,0],p[C,0])]*r[A][4][12,3]*r[B][27][0,4]*r[C][3][10,5]
    hv += -1*g[dei(p[A,1],p[B,0],p[B,1],p[C,0])]*r[A][4][12,3]*r[B][45][0,4]*r[C][3][10,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12B1C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,1),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[A,1],p[B,1],p[B,0],p[C,0])]*r[A][4][12,3]*r[B][27][1,4]*r[C][3][10,5]
    hv += -1*g[dei(p[A,1],p[B,0],p[B,1],p[C,0])]*r[A][4][12,3]*r[B][45][1,4]*r[C][3][10,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[A,1],p[B,1],p[B,0],p[C,1])]*r[A][4][12,3]*r[B][27][0,4]*r[C][7][9,5]
    hv += -1*g[dei(p[A,1],p[B,0],p[B,1],p[C,1])]*r[A][4][12,3]*r[B][45][0,4]*r[C][7][9,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12B1C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,1),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[A,1],p[B,1],p[B,0],p[C,1])]*r[A][4][12,3]*r[B][27][1,4]*r[C][7][9,5]
    hv += -1*g[dei(p[A,1],p[B,0],p[B,1],p[C,1])]*r[A][4][12,3]*r[B][45][1,4]*r[C][7][9,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B11C6(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,11),(C,6)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[C,1])]*r[A][2][13,3]*r[B][2][11,4]*r[C][49][6,5]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[C,0])]*r[A][2][13,3]*r[B][2][11,4]*r[C][31][6,5]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[C,1])]*r[A][2][13,3]*r[B][2][11,4]*r[C][49][6,5]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][2][11,4]*r[C][31][6,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B12C6(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,12),(C,6)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[C,1])]*r[A][2][13,3]*r[B][6][12,4]*r[C][49][6,5]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[C,0])]*r[A][2][13,3]*r[B][6][12,4]*r[C][31][6,5]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[C,1])]*r[A][2][13,3]*r[B][6][12,4]*r[C][49][6,5]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][6][12,4]*r[C][31][6,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B11C6(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,11),(C,6)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[C,1])]*r[A][6][14,3]*r[B][2][11,4]*r[C][49][6,5]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[C,0])]*r[A][6][14,3]*r[B][2][11,4]*r[C][31][6,5]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[C,1])]*r[A][6][14,3]*r[B][2][11,4]*r[C][49][6,5]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][2][11,4]*r[C][31][6,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B12C6(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,12),(C,6)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[C,1])]*r[A][6][14,3]*r[B][6][12,4]*r[C][49][6,5]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[C,0])]*r[A][6][14,3]*r[B][6][12,4]*r[C][31][6,5]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[C,1])]*r[A][6][14,3]*r[B][6][12,4]*r[C][49][6,5]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][6][12,4]*r[C][31][6,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A2B8C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(B,8),(C,13)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[C,0],p[B,0])]*r[A][9][2,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[C,0],p[B,0])]*r[A][39][2,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,0],p[A,0])]*r[A][9][2,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,0],p[A,1])]*r[A][39][2,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[A,0],p[B,0])]*r[A][9][2,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[A,1],p[B,0])]*r[A][39][2,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,0],p[A,0])]*r[A][9][2,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += -1*g[dei(p[C,0],p[B,0],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,1],p[A,1])]*r[A][39][2,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += -1*g[dei(p[C,0],p[B,0],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][1][8,4]*r[C][0][13,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A2B7C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(B,7),(C,13)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[C,0],p[B,1])]*r[A][9][2,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[C,0],p[B,1])]*r[A][39][2,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,0],p[A,0])]*r[A][9][2,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,0],p[A,1])]*r[A][39][2,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[A,0],p[B,1])]*r[A][9][2,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[A,1],p[B,1])]*r[A][39][2,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,0],p[A,0])]*r[A][9][2,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += -1*g[dei(p[C,0],p[B,1],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,1],p[A,1])]*r[A][39][2,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += -1*g[dei(p[C,0],p[B,1],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][5][7,4]*r[C][0][13,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _B8C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(B,8),(C,13)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[C,0],p[B,0])]*r[A][15][0,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[C,0],p[B,0])]*r[A][33][0,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,0],p[A,1])]*r[A][15][0,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,0],p[A,0])]*r[A][33][0,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[A,0],p[B,0])]*r[A][15][0,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[A,1],p[B,0])]*r[A][33][0,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,0],p[A,1])]*r[A][15][0,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += -1*g[dei(p[C,0],p[B,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,1],p[A,0])]*r[A][33][0,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += -1*g[dei(p[C,0],p[B,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][1][8,4]*r[C][0][13,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A1B8C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,8),(C,13)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[C,0],p[B,0])]*r[A][15][1,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[C,0],p[B,0])]*r[A][33][1,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,0],p[A,1])]*r[A][15][1,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,0],p[A,0])]*r[A][33][1,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[A,0],p[B,0])]*r[A][15][1,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[A,1],p[B,0])]*r[A][33][1,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,0],p[A,1])]*r[A][15][1,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += -1*g[dei(p[C,0],p[B,0],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,1],p[A,0])]*r[A][33][1,3]*r[B][1][8,4]*r[C][0][13,5]
    hv += -1*g[dei(p[C,0],p[B,0],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][1][8,4]*r[C][0][13,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _B7C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(B,7),(C,13)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[C,0],p[B,1])]*r[A][15][0,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[C,0],p[B,1])]*r[A][33][0,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,0],p[A,1])]*r[A][15][0,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,0],p[A,0])]*r[A][33][0,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[A,0],p[B,1])]*r[A][15][0,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[A,1],p[B,1])]*r[A][33][0,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,0],p[A,1])]*r[A][15][0,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += -1*g[dei(p[C,0],p[B,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,1],p[A,0])]*r[A][33][0,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += -1*g[dei(p[C,0],p[B,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][5][7,4]*r[C][0][13,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A1B7C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,7),(C,13)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[C,0],p[B,1])]*r[A][15][1,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[C,0],p[B,1])]*r[A][33][1,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,0],p[A,1])]*r[A][15][1,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,0],p[A,0])]*r[A][33][1,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[A,0],p[B,1])]*r[A][15][1,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[A,1],p[B,1])]*r[A][33][1,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,0],p[A,1])]*r[A][15][1,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += -1*g[dei(p[C,0],p[B,1],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,1],p[A,0])]*r[A][33][1,3]*r[B][5][7,4]*r[C][0][13,5]
    hv += -1*g[dei(p[C,0],p[B,1],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][5][7,4]*r[C][0][13,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A2B8C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(B,8),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[C,1],p[B,0])]*r[A][9][2,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[C,1],p[B,0])]*r[A][39][2,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,1],p[A,0])]*r[A][9][2,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,1],p[A,1])]*r[A][39][2,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[A,0],p[B,0])]*r[A][9][2,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[A,1],p[B,0])]*r[A][39][2,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,0],p[A,0])]*r[A][9][2,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,1],p[A,1])]*r[A][39][2,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][1][8,4]*r[C][4][14,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A2B7C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,2),(B,7),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[C,1],p[B,1])]*r[A][9][2,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[C,1],p[B,1])]*r[A][39][2,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,1],p[A,0])]*r[A][9][2,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,1],p[A,1])]*r[A][39][2,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[A,0],p[B,1])]*r[A][9][2,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[A,1],p[B,1])]*r[A][39][2,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,0],p[A,0])]*r[A][9][2,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,1],p[A,1])]*r[A][39][2,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][5][7,4]*r[C][4][14,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _B8C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(B,8),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[C,1],p[B,0])]*r[A][15][0,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[C,1],p[B,0])]*r[A][33][0,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,1],p[A,1])]*r[A][15][0,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,1],p[A,0])]*r[A][33][0,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[A,0],p[B,0])]*r[A][15][0,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[A,1],p[B,0])]*r[A][33][0,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,0],p[A,1])]*r[A][15][0,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,1],p[A,0])]*r[A][33][0,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][1][8,4]*r[C][4][14,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A1B8C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,8),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[C,1],p[B,0])]*r[A][15][1,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[C,1],p[B,0])]*r[A][33][1,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,1],p[A,1])]*r[A][15][1,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,1],p[A,0])]*r[A][33][1,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[A,0],p[B,0])]*r[A][15][1,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[A,1],p[B,0])]*r[A][33][1,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,0],p[A,1])]*r[A][15][1,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,1],p[A,0])]*r[A][33][1,3]*r[B][1][8,4]*r[C][4][14,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][1][8,4]*r[C][4][14,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _B7C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(B,7),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[C,1],p[B,1])]*r[A][15][0,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[C,1],p[B,1])]*r[A][33][0,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,1],p[A,1])]*r[A][15][0,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,1],p[A,0])]*r[A][33][0,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[A,0],p[B,1])]*r[A][15][0,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[A,1],p[B,1])]*r[A][33][0,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,0],p[A,1])]*r[A][15][0,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,1],p[A,0])]*r[A][33][0,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][5][7,4]*r[C][4][14,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A1B7C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,1),(B,7),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[C,1],p[B,1])]*r[A][15][1,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[C,1],p[B,1])]*r[A][33][1,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,1],p[A,1])]*r[A][15][1,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,1],p[A,0])]*r[A][33][1,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[A,0],p[B,1])]*r[A][15][1,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[A,1],p[B,1])]*r[A][33][1,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,0],p[A,1])]*r[A][15][1,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,1],p[A,0])]*r[A][33][1,3]*r[B][5][7,4]*r[C][4][14,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][5][7,4]*r[C][4][14,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11B6C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,6),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,0],p[B,1])]*r[A][0][11,3]*r[B][34][6,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,0],p[B,0])]*r[A][0][11,3]*r[B][16][6,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,0],p[B,1])]*r[A][0][11,3]*r[B][34][6,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,0],p[B,0])]*r[A][0][11,3]*r[B][16][6,4]*r[C][0][13,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A11B6C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,11),(B,6),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[A,0],p[B,0],p[C,1],p[B,1])]*r[A][0][11,3]*r[B][34][6,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,1],p[B,0])]*r[A][0][11,3]*r[B][16][6,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,0],p[B,1])]*r[A][0][11,3]*r[B][34][6,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,0],p[B,0])]*r[A][0][11,3]*r[B][16][6,4]*r[C][4][14,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12B6C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,6),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,0],p[B,1])]*r[A][4][12,3]*r[B][34][6,4]*r[C][0][13,5]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,0],p[B,0])]*r[A][4][12,3]*r[B][16][6,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[C,0],p[B,0],p[A,1],p[B,1])]*r[A][4][12,3]*r[B][34][6,4]*r[C][0][13,5]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,1],p[B,0])]*r[A][4][12,3]*r[B][16][6,4]*r[C][0][13,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A12B6C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,12),(B,6),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[A,1],p[B,0],p[C,1],p[B,1])]*r[A][4][12,3]*r[B][34][6,4]*r[C][4][14,5]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,1],p[B,0])]*r[A][4][12,3]*r[B][16][6,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[C,1],p[B,0],p[A,1],p[B,1])]*r[A][4][12,3]*r[B][34][6,4]*r[C][4][14,5]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,1],p[B,0])]*r[A][4][12,3]*r[B][16][6,4]*r[C][4][14,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B15C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,15),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[B,0],p[A,0],p[B,1],p[C,0])]*r[A][3][8,3]*r[B][29][15,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[B,0],p[C,0])]*r[A][3][8,3]*r[B][47][15,4]*r[C][3][10,5]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][29][15,4]*r[C][3][10,5]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][47][15,4]*r[C][3][10,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B15C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,15),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[B,0],p[A,0],p[B,1],p[C,1])]*r[A][3][8,3]*r[B][29][15,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[B,0],p[C,1])]*r[A][3][8,3]*r[B][47][15,4]*r[C][7][9,5]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][29][15,4]*r[C][7][9,5]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][47][15,4]*r[C][7][9,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B15C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,15),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[B,0],p[A,1],p[B,1],p[C,0])]*r[A][7][7,3]*r[B][29][15,4]*r[C][3][10,5]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[B,0],p[C,0])]*r[A][7][7,3]*r[B][47][15,4]*r[C][3][10,5]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][29][15,4]*r[C][3][10,5]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][47][15,4]*r[C][3][10,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B15C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,15),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[B,0],p[A,1],p[B,1],p[C,1])]*r[A][7][7,3]*r[B][29][15,4]*r[C][7][9,5]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[B,0],p[C,1])]*r[A][7][7,3]*r[B][47][15,4]*r[C][7][9,5]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][29][15,4]*r[C][7][9,5]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][47][15,4]*r[C][7][9,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B8C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,8),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[C,0],p[B,0],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][1][8,4]*r[C][12][2,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[A,0],p[C,1])]*r[A][2][13,3]*r[B][1][8,4]*r[C][42][2,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B8C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,8),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[C,0],p[B,0],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][1][8,4]*r[C][12][3,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[A,0],p[C,1])]*r[A][2][13,3]*r[B][1][8,4]*r[C][42][3,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,8)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[C,0],p[B,0],p[A,0],p[C,1])]*r[A][2][13,3]*r[B][1][8,4]*r[C][18][0,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][1][8,4]*r[C][36][0,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B8C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,8),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[C,0],p[B,0],p[A,0],p[C,1])]*r[A][2][13,3]*r[B][1][8,4]*r[C][18][1,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][1][8,4]*r[C][36][1,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B7C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,7),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[C,0],p[B,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][5][7,4]*r[C][12][2,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[A,0],p[C,1])]*r[A][2][13,3]*r[B][5][7,4]*r[C][42][2,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B7C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,7),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[C,0],p[B,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][5][7,4]*r[C][12][3,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[A,0],p[C,1])]*r[A][2][13,3]*r[B][5][7,4]*r[C][42][3,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,7)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[C,0],p[B,1],p[A,0],p[C,1])]*r[A][2][13,3]*r[B][5][7,4]*r[C][18][0,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][5][7,4]*r[C][36][0,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A13B7C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,13),(B,7),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[C,0],p[B,1],p[A,0],p[C,1])]*r[A][2][13,3]*r[B][5][7,4]*r[C][18][1,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][5][7,4]*r[C][36][1,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B8C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,8),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[C,0],p[B,0],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][1][8,4]*r[C][12][2,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[A,1],p[C,1])]*r[A][6][14,3]*r[B][1][8,4]*r[C][42][2,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B8C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,8),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[C,0],p[B,0],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][1][8,4]*r[C][12][3,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[A,1],p[C,1])]*r[A][6][14,3]*r[B][1][8,4]*r[C][42][3,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,8)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[C,0],p[B,0],p[A,1],p[C,1])]*r[A][6][14,3]*r[B][1][8,4]*r[C][18][0,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][1][8,4]*r[C][36][0,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B8C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,8),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[C,0],p[B,0],p[A,1],p[C,1])]*r[A][6][14,3]*r[B][1][8,4]*r[C][18][1,5]
    hv += -1*g[dei(p[C,1],p[B,0],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][1][8,4]*r[C][36][1,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B7C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,7),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[C,0],p[B,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][5][7,4]*r[C][12][2,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[A,1],p[C,1])]*r[A][6][14,3]*r[B][5][7,4]*r[C][42][2,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B7C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,7),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[C,0],p[B,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][5][7,4]*r[C][12][3,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[A,1],p[C,1])]*r[A][6][14,3]*r[B][5][7,4]*r[C][42][3,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,7)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[C,0],p[B,1],p[A,1],p[C,1])]*r[A][6][14,3]*r[B][5][7,4]*r[C][18][0,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][5][7,4]*r[C][36][0,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A14B7C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,14),(B,7),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[C,0],p[B,1],p[A,1],p[C,1])]*r[A][6][14,3]*r[B][5][7,4]*r[C][18][1,5]
    hv += -1*g[dei(p[C,1],p[B,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][5][7,4]*r[C][36][1,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A6B11C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,6),(B,11),(C,13)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[C,0],p[A,0],p[B,0],p[A,1])]*r[A][46][6,3]*r[B][2][11,4]*r[C][0][13,5]
    hv += -1*g[dei(p[C,0],p[A,1],p[B,0],p[A,0])]*r[A][28][6,3]*r[B][2][11,4]*r[C][0][13,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A6B12C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,6),(B,12),(C,13)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[C,0],p[A,0],p[B,1],p[A,1])]*r[A][46][6,3]*r[B][6][12,4]*r[C][0][13,5]
    hv += -1*g[dei(p[C,0],p[A,1],p[B,1],p[A,0])]*r[A][28][6,3]*r[B][6][12,4]*r[C][0][13,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A6B11C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,6),(B,11),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[C,1],p[A,0],p[B,0],p[A,1])]*r[A][46][6,3]*r[B][2][11,4]*r[C][4][14,5]
    hv += -1*g[dei(p[C,1],p[A,1],p[B,0],p[A,0])]*r[A][28][6,3]*r[B][2][11,4]*r[C][4][14,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A6B12C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,6),(B,12),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[C,1],p[A,0],p[B,1],p[A,1])]*r[A][46][6,3]*r[B][6][12,4]*r[C][4][14,5]
    hv += -1*g[dei(p[C,1],p[A,1],p[B,1],p[A,0])]*r[A][28][6,3]*r[B][6][12,4]*r[C][4][14,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B11C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,11),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[C,0],p[A,0],p[B,0],p[C,0])]*r[A][1][10,3]*r[B][2][11,4]*r[C][12][2,5]
    hv += g[dei(p[C,1],p[A,0],p[B,0],p[C,1])]*r[A][1][10,3]*r[B][2][11,4]*r[C][42][2,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B11C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,11),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[C,0],p[A,0],p[B,0],p[C,0])]*r[A][1][10,3]*r[B][2][11,4]*r[C][12][3,5]
    hv += g[dei(p[C,1],p[A,0],p[B,0],p[C,1])]*r[A][1][10,3]*r[B][2][11,4]*r[C][42][3,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,11)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[C,0],p[A,0],p[B,0],p[C,1])]*r[A][1][10,3]*r[B][2][11,4]*r[C][18][0,5]
    hv += g[dei(p[C,1],p[A,0],p[B,0],p[C,0])]*r[A][1][10,3]*r[B][2][11,4]*r[C][36][0,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B11C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,11),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[C,0],p[A,0],p[B,0],p[C,1])]*r[A][1][10,3]*r[B][2][11,4]*r[C][18][1,5]
    hv += g[dei(p[C,1],p[A,0],p[B,0],p[C,0])]*r[A][1][10,3]*r[B][2][11,4]*r[C][36][1,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B11C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,11),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[C,0],p[A,1],p[B,0],p[C,0])]*r[A][5][9,3]*r[B][2][11,4]*r[C][12][2,5]
    hv += g[dei(p[C,1],p[A,1],p[B,0],p[C,1])]*r[A][5][9,3]*r[B][2][11,4]*r[C][42][2,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B11C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,11),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[C,0],p[A,1],p[B,0],p[C,0])]*r[A][5][9,3]*r[B][2][11,4]*r[C][12][3,5]
    hv += g[dei(p[C,1],p[A,1],p[B,0],p[C,1])]*r[A][5][9,3]*r[B][2][11,4]*r[C][42][3,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,11)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[C,0],p[A,1],p[B,0],p[C,1])]*r[A][5][9,3]*r[B][2][11,4]*r[C][18][0,5]
    hv += g[dei(p[C,1],p[A,1],p[B,0],p[C,0])]*r[A][5][9,3]*r[B][2][11,4]*r[C][36][0,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B11C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,11),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[C,0],p[A,1],p[B,0],p[C,1])]*r[A][5][9,3]*r[B][2][11,4]*r[C][18][1,5]
    hv += g[dei(p[C,1],p[A,1],p[B,0],p[C,0])]*r[A][5][9,3]*r[B][2][11,4]*r[C][36][1,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B12C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,12),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[C,0],p[A,0],p[B,1],p[C,0])]*r[A][1][10,3]*r[B][6][12,4]*r[C][12][2,5]
    hv += g[dei(p[C,1],p[A,0],p[B,1],p[C,1])]*r[A][1][10,3]*r[B][6][12,4]*r[C][42][2,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B12C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,12),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[C,0],p[A,0],p[B,1],p[C,0])]*r[A][1][10,3]*r[B][6][12,4]*r[C][12][3,5]
    hv += g[dei(p[C,1],p[A,0],p[B,1],p[C,1])]*r[A][1][10,3]*r[B][6][12,4]*r[C][42][3,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,12)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[C,0],p[A,0],p[B,1],p[C,1])]*r[A][1][10,3]*r[B][6][12,4]*r[C][18][0,5]
    hv += g[dei(p[C,1],p[A,0],p[B,1],p[C,0])]*r[A][1][10,3]*r[B][6][12,4]*r[C][36][0,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B12C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,12),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[C,0],p[A,0],p[B,1],p[C,1])]*r[A][1][10,3]*r[B][6][12,4]*r[C][18][1,5]
    hv += g[dei(p[C,1],p[A,0],p[B,1],p[C,0])]*r[A][1][10,3]*r[B][6][12,4]*r[C][36][1,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B12C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,12),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[C,0],p[A,1],p[B,1],p[C,0])]*r[A][5][9,3]*r[B][6][12,4]*r[C][12][2,5]
    hv += g[dei(p[C,1],p[A,1],p[B,1],p[C,1])]*r[A][5][9,3]*r[B][6][12,4]*r[C][42][2,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B12C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,12),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[C,0],p[A,1],p[B,1],p[C,0])]*r[A][5][9,3]*r[B][6][12,4]*r[C][12][3,5]
    hv += g[dei(p[C,1],p[A,1],p[B,1],p[C,1])]*r[A][5][9,3]*r[B][6][12,4]*r[C][42][3,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,12)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[C,0],p[A,1],p[B,1],p[C,1])]*r[A][5][9,3]*r[B][6][12,4]*r[C][18][0,5]
    hv += g[dei(p[C,1],p[A,1],p[B,1],p[C,0])]*r[A][5][9,3]*r[B][6][12,4]*r[C][36][0,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B12C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,12),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[C,0],p[A,1],p[B,1],p[C,1])]*r[A][5][9,3]*r[B][6][12,4]*r[C][18][1,5]
    hv += g[dei(p[C,1],p[A,1],p[B,1],p[C,0])]*r[A][5][9,3]*r[B][6][12,4]*r[C][36][1,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B2C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,2),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,0],p[B,0],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][21][2,4]*r[C][0][13,5]
    hv += g[dei(p[C,0],p[B,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][51][2,4]*r[C][0][13,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B3C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,3),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,0],p[B,0],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][21][3,4]*r[C][0][13,5]
    hv += g[dei(p[C,0],p[B,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][51][3,4]*r[C][0][13,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B2C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,2),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,0],p[B,0],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][21][2,4]*r[C][0][13,5]
    hv += g[dei(p[C,0],p[B,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][51][2,4]*r[C][0][13,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B3C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,3),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,0],p[B,0],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][21][3,4]*r[C][0][13,5]
    hv += g[dei(p[C,0],p[B,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][51][3,4]*r[C][0][13,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,0],p[B,1],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][27][0,4]*r[C][0][13,5]
    hv += g[dei(p[C,0],p[B,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][45][0,4]*r[C][0][13,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B1C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,1),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,0],p[B,1],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][27][1,4]*r[C][0][13,5]
    hv += g[dei(p[C,0],p[B,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][45][1,4]*r[C][0][13,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,0],p[B,1],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][27][0,4]*r[C][0][13,5]
    hv += g[dei(p[C,0],p[B,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][45][0,4]*r[C][0][13,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B1C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,1),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,0],p[B,1],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][27][1,4]*r[C][0][13,5]
    hv += g[dei(p[C,0],p[B,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][45][1,4]*r[C][0][13,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B2C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,2),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,1],p[B,0],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][21][2,4]*r[C][4][14,5]
    hv += g[dei(p[C,1],p[B,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][51][2,4]*r[C][4][14,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B3C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,3),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,1],p[B,0],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][21][3,4]*r[C][4][14,5]
    hv += g[dei(p[C,1],p[B,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][51][3,4]*r[C][4][14,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B2C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,2),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,1],p[B,0],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][21][2,4]*r[C][4][14,5]
    hv += g[dei(p[C,1],p[B,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][51][2,4]*r[C][4][14,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B3C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,3),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,1],p[B,0],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][21][3,4]*r[C][4][14,5]
    hv += g[dei(p[C,1],p[B,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][51][3,4]*r[C][4][14,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,1],p[B,1],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][27][0,4]*r[C][4][14,5]
    hv += g[dei(p[C,1],p[B,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][45][0,4]*r[C][4][14,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A8B1C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,8),(B,1),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,1],p[B,1],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][27][1,4]*r[C][4][14,5]
    hv += g[dei(p[C,1],p[B,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][45][1,4]*r[C][4][14,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,1],p[B,1],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][27][0,4]*r[C][4][14,5]
    hv += g[dei(p[C,1],p[B,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][45][0,4]*r[C][4][14,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A7B1C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,7),(B,1),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,1],p[B,1],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][27][1,4]*r[C][4][14,5]
    hv += g[dei(p[C,1],p[B,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][45][1,4]*r[C][4][14,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B8C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,8),(C,15)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[C,0],p[A,0],p[C,1],p[B,0])]*r[A][1][10,3]*r[B][1][8,4]*r[C][14][15,5]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[C,0],p[B,0])]*r[A][1][10,3]*r[B][1][8,4]*r[C][32][15,5]
    hv += 1/2*g[dei(p[C,0],p[B,0],p[C,1],p[A,0])]*r[A][1][10,3]*r[B][1][8,4]*r[C][14][15,5]
    hv += 1/2*g[dei(p[C,1],p[B,0],p[C,0],p[A,0])]*r[A][1][10,3]*r[B][1][8,4]*r[C][32][15,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A10B7C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,10),(B,7),(C,15)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[C,0],p[A,0],p[C,1],p[B,1])]*r[A][1][10,3]*r[B][5][7,4]*r[C][14][15,5]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[C,0],p[B,1])]*r[A][1][10,3]*r[B][5][7,4]*r[C][32][15,5]
    hv += 1/2*g[dei(p[C,0],p[B,1],p[C,1],p[A,0])]*r[A][1][10,3]*r[B][5][7,4]*r[C][14][15,5]
    hv += 1/2*g[dei(p[C,1],p[B,1],p[C,0],p[A,0])]*r[A][1][10,3]*r[B][5][7,4]*r[C][32][15,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B8C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,8),(C,15)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[C,0],p[A,1],p[C,1],p[B,0])]*r[A][5][9,3]*r[B][1][8,4]*r[C][14][15,5]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[C,0],p[B,0])]*r[A][5][9,3]*r[B][1][8,4]*r[C][32][15,5]
    hv += 1/2*g[dei(p[C,0],p[B,0],p[C,1],p[A,1])]*r[A][5][9,3]*r[B][1][8,4]*r[C][14][15,5]
    hv += 1/2*g[dei(p[C,1],p[B,0],p[C,0],p[A,1])]*r[A][5][9,3]*r[B][1][8,4]*r[C][32][15,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def _A9B7C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    
    v = tuple(sorted([(A,9),(B,7),(C,15)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[C,0],p[A,1],p[C,1],p[B,1])]*r[A][5][9,3]*r[B][5][7,4]*r[C][14][15,5]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[C,0],p[B,1])]*r[A][5][9,3]*r[B][5][7,4]*r[C][32][15,5]
    hv += 1/2*g[dei(p[C,0],p[B,1],p[C,1],p[A,1])]*r[A][5][9,3]*r[B][5][7,4]*r[C][14][15,5]
    hv += 1/2*g[dei(p[C,1],p[B,1],p[C,0],p[A,1])]*r[A][5][9,3]*r[B][5][7,4]*r[C][32][15,5]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    return hd
    
def hm_A3B4C5(r, h, g, p, nc=0):
    np=len(p)
    hdd = {}
    
    for A in range(nc, np):
        for B in range(nc, np):
            if B in {A}: continue
            for C in range(nc, np):
                if C in {A,B}: continue
                u = tuple(sorted([(A,3),(B,4),(C,5)]))
                
                hd = {}
                for v,hv in _A3B4C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B4C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B4C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B4C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B4C5I1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B4C5I2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B4C5I3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C5I4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B4I5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B8C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B7C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B8C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B7C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B11C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B11C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B12C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B12C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A4B2C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A4B3C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A4C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A4B1C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B4C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B4C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B4C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B4C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B4C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B4C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B4C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B4C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A5B4C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A5B4C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A5B4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A5B4C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B11C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B11C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B12C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B12C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B8C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B7C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B8C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B7C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B15C6(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B2C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B2C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B3C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B3C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B2C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B3C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B1C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B1C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B1C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B6C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B11C5I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B11C5I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B12C5I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B12C5I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11C5I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11C5I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12C5I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12C5I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B8C5I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B7C5I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B8C5I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B7C5I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C5I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C5I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C5I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C5I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B4C13I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B4C13I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B4C14I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B4C14I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B4C10I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B4C9I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B4C10I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B4C9I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B4I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B4I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B4I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B4I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B4I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B4I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B4I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B4I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C13I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C13I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C14I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C14I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B11I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B11I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B12I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B12I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B8I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B7I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B8I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B7I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C10I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C9I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C10I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C9I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A15B8C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A15B8C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A15B7C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A15B7C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B11C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B11C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B11C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B11C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B11C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B11C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B12C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B12C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B12C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B12C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B12C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B12C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B2C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B3C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B2C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B3C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B1C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B1C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B2C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B3C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B2C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B3C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B1C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B1C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B11C6(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B12C6(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B11C6(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B12C6(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B8C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B7C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B8C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B8C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B7C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B7C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B8C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B7C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B8C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B8C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B7C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B7C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B6C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B6C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B6C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B6C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B15C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B15C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B15C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B15C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B8C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B8C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B8C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B7C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B7C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B7C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B8C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B8C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B8C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B7C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B7C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B7C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A6B11C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A6B12C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A6B11C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A6B12C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B11C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B11C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B11C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B11C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B11C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B11C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B12C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B12C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B12C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B12C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B12C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B12C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B2C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B3C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B2C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B3C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B1C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B1C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B2C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B3C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B2C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B3C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B1C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B1C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B8C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B7C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B8C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B7C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                
                hdd[u] = hd
                
    return hdd
    

