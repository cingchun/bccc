#!/usr/bin/env python 
# -*- coding: utf-8 -*- 
#
#      Copyright:   Qingchun Wang @ NJU
#      File Name:   __init__.py
#            Des:   __init__
#           Mail:   qingchun720@foxmail.com
#   Created Time:   9:46 四月-14/2019 
#


__version__ = '1.0'
__author__ = 'Qingchun Wang'
    
    











    
if __name__ == '__main__':


    print('End successfully')




