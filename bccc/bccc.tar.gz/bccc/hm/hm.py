#!/usr/bin/env python 
# -*- coding: utf-8 -*- 
# 
# Author: Qingchun Wang @ NJU 
# E-mail: qingchun720@foxmail.com 
# 


from multiprocessing import Pool, Manager
from importlib import import_module


def cal(braf, r, h, g, p, nc=0):
    module = F'bccc.hm.{braf}'
    lib = import_module(module)
    fun = getattr(lib, braf)
    hd = fun(r, h, g, p, nc)
    return hd


def hm(r, h, g, p, nt=4, nc=0):
    hdd = {}
    
    # bra wavefunction list
    # ground state
    from bccc.hm.hm_ import hm_
    brafl = (hm_,)
    # 2-block excited types
    from bccc.hm.hm_A1B1 import hm_A1B1
    from bccc.hm.hm_A1B2 import hm_A1B2
    from bccc.hm.hm_A1B3 import hm_A1B3
    from bccc.hm.hm_A2B2 import hm_A2B2
    from bccc.hm.hm_A2B3 import hm_A2B3
    from bccc.hm.hm_A3B3 import hm_A3B3
    from bccc.hm.hm_A4B5 import hm_A4B5
    from bccc.hm.hm_A6B15 import hm_A6B15
    from bccc.hm.hm_A7B13 import hm_A7B13
    from bccc.hm.hm_A7B14 import hm_A7B14
    from bccc.hm.hm_A8B13 import hm_A8B13
    from bccc.hm.hm_A8B14 import hm_A8B14
    from bccc.hm.hm_A9B11 import hm_A9B11
    from bccc.hm.hm_A9B12 import hm_A9B12
    from bccc.hm.hm_A10B11 import hm_A10B11
    from bccc.hm.hm_A10B12 import hm_A10B12
    brafl += (
            hm_A1B1,hm_A1B2,hm_A1B3,hm_A2B2,hm_A2B3,hm_A3B3,hm_A4B5,hm_A6B15,hm_A7B13,hm_A7B14,
            hm_A8B13,hm_A8B14,hm_A9B11,hm_A9B12,hm_A10B11,hm_A10B12,
            )
    # 3-block excited types
    from bccc.hm.hm_A1B1C1 import hm_A1B1C1
    from bccc.hm.hm_A1B1C2 import hm_A1B1C2
    from bccc.hm.hm_A1B1C3 import hm_A1B1C3
    from bccc.hm.hm_A1B2C2 import hm_A1B2C2
    from bccc.hm.hm_A1B2C3 import hm_A1B2C3
    from bccc.hm.hm_A1B3C3 import hm_A1B3C3
    from bccc.hm.hm_A1B4C5 import hm_A1B4C5
    from bccc.hm.hm_A1B6C15 import hm_A1B6C15
    from bccc.hm.hm_A1B7C13 import hm_A1B7C13
    from bccc.hm.hm_A1B7C14 import hm_A1B7C14
    from bccc.hm.hm_A1B8C13 import hm_A1B8C13
    from bccc.hm.hm_A1B8C14 import hm_A1B8C14
    from bccc.hm.hm_A1B9C11 import hm_A1B9C11
    from bccc.hm.hm_A1B9C12 import hm_A1B9C12
    from bccc.hm.hm_A1B10C11 import hm_A1B10C11
    from bccc.hm.hm_A1B10C12 import hm_A1B10C12
    from bccc.hm.hm_A2B2C2 import hm_A2B2C2
    from bccc.hm.hm_A2B2C3 import hm_A2B2C3
    from bccc.hm.hm_A2B3C3 import hm_A2B3C3
    from bccc.hm.hm_A2B4C5 import hm_A2B4C5
    from bccc.hm.hm_A2B6C15 import hm_A2B6C15
    from bccc.hm.hm_A2B7C13 import hm_A2B7C13
    from bccc.hm.hm_A2B7C14 import hm_A2B7C14
    from bccc.hm.hm_A2B8C13 import hm_A2B8C13
    from bccc.hm.hm_A2B8C14 import hm_A2B8C14
    from bccc.hm.hm_A2B9C11 import hm_A2B9C11
    from bccc.hm.hm_A2B9C12 import hm_A2B9C12
    from bccc.hm.hm_A2B10C11 import hm_A2B10C11
    from bccc.hm.hm_A2B10C12 import hm_A2B10C12
    from bccc.hm.hm_A3B3C3 import hm_A3B3C3
    from bccc.hm.hm_A3B4C5 import hm_A3B4C5
    from bccc.hm.hm_A3B6C15 import hm_A3B6C15
    from bccc.hm.hm_A3B7C13 import hm_A3B7C13
    from bccc.hm.hm_A3B7C14 import hm_A3B7C14
    from bccc.hm.hm_A3B8C13 import hm_A3B8C13
    from bccc.hm.hm_A3B8C14 import hm_A3B8C14
    from bccc.hm.hm_A3B9C11 import hm_A3B9C11
    from bccc.hm.hm_A3B9C12 import hm_A3B9C12
    from bccc.hm.hm_A3B10C11 import hm_A3B10C11
    from bccc.hm.hm_A3B10C12 import hm_A3B10C12
    from bccc.hm.hm_A4B9C13 import hm_A4B9C13
    from bccc.hm.hm_A4B9C14 import hm_A4B9C14
    from bccc.hm.hm_A4B10C13 import hm_A4B10C13
    from bccc.hm.hm_A4B10C14 import hm_A4B10C14
    from bccc.hm.hm_A5B7C11 import hm_A5B7C11
    from bccc.hm.hm_A5B7C12 import hm_A5B7C12
    from bccc.hm.hm_A5B8C11 import hm_A5B8C11
    from bccc.hm.hm_A5B8C12 import hm_A5B8C12
    from bccc.hm.hm_A6B11C13 import hm_A6B11C13
    from bccc.hm.hm_A6B11C14 import hm_A6B11C14
    from bccc.hm.hm_A6B12C13 import hm_A6B12C13
    from bccc.hm.hm_A6B12C14 import hm_A6B12C14
    from bccc.hm.hm_A7B9C15 import hm_A7B9C15
    from bccc.hm.hm_A7B10C15 import hm_A7B10C15
    from bccc.hm.hm_A8B9C15 import hm_A8B9C15
    from bccc.hm.hm_A8B10C15 import hm_A8B10C15
    brafl += (
            hm_A1B1C1,hm_A1B1C2,hm_A1B1C3,hm_A1B2C2,hm_A1B2C3,hm_A1B3C3,hm_A1B4C5,hm_A1B6C15,hm_A1B7C13,hm_A1B7C14,
            hm_A1B8C13,hm_A1B8C14,hm_A1B9C11,hm_A1B9C12,hm_A1B10C11,hm_A1B10C12,hm_A2B2C2,hm_A2B2C3,hm_A2B3C3,hm_A2B4C5,
            hm_A2B6C15,hm_A2B7C13,hm_A2B7C14,hm_A2B8C13,hm_A2B8C14,hm_A2B9C11,hm_A2B9C12,hm_A2B10C11,hm_A2B10C12,hm_A3B3C3,
            hm_A3B4C5,hm_A3B6C15,hm_A3B7C13,hm_A3B7C14,hm_A3B8C13,hm_A3B8C14,hm_A3B9C11,hm_A3B9C12,hm_A3B10C11,hm_A3B10C12,
            hm_A4B9C13,hm_A4B9C14,hm_A4B10C13,hm_A4B10C14,hm_A5B7C11,hm_A5B7C12,hm_A5B8C11,hm_A5B8C12,hm_A6B11C13,hm_A6B11C14,
            hm_A6B12C13,hm_A6B12C14,hm_A7B9C15,hm_A7B10C15,hm_A8B9C15,hm_A8B10C15,
            )
    
    pool = Pool()
    pl = tuple(pool.apply_async(braf, (r, h, g, p, nc)) for braf in brafl)
    pool.close()
    pool.join()
    for p in pl: hdd.update(p.get())
    
    return hdd
    

