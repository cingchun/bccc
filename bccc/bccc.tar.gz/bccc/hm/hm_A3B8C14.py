#!/usr/bin/env python 
# -*- coding: utf-8 -*- 
# 
# Author: Qingchun Wang @ NJU 
# E-mail: qingchun720@foxmail.com 
# 


import numpy
from bccc.pub import sign,dei


def _A3B8C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,8),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += sum(h[p[I,0],p[I,0]]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(h[p[I,0],p[I,0]]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(h[p[I,1],p[I,1]]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(h[p[I,1],p[I,1]]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[I,0],p[I,0])]*r[I][194][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,1],p[I,0],p[I,1])]*r[I][199][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,0],p[I,1],p[I,0])]*r[I][274][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[I,1],p[I,1])]*r[I][279][0,0] for I in range(np) if I not in {A,B,C})
    hv += h[p[A,0],p[A,0]]*r[A][9][3,3]
    hv += h[p[A,0],p[A,0]]*r[A][24][3,3]
    hv += h[p[A,1],p[A,1]]*r[A][39][3,3]
    hv += h[p[A,1],p[A,1]]*r[A][54][3,3]
    hv += g[dei(p[A,0],p[A,0],p[A,1],p[A,1])]*r[A][214][3,3]
    hv += g[dei(p[A,0],p[A,1],p[A,1],p[A,0])]*r[A][211][3,3]
    hv += g[dei(p[A,1],p[A,0],p[A,0],p[A,1])]*r[A][262][3,3]
    hv += g[dei(p[A,1],p[A,1],p[A,0],p[A,0])]*r[A][259][3,3]
    hv += h[p[B,1],p[B,1]]*r[B][39][8,8]
    hv += h[p[C,0],p[C,0]]*r[C][24][14,14]
    hv += h[p[C,1],p[C,1]]*r[C][39][14,14]
    hv += h[p[C,1],p[C,1]]*r[C][54][14,14]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[C,1],p[C,1])]*r[C][246][14,14]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[C,1],p[C,0])]*r[C][243][14,14]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[C,0],p[C,1])]*r[C][294][14,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[C,0],p[C,0])]*r[C][291][14,14]
    hv += g[dei(p[C,1],p[C,1],p[C,0],p[C,0])]*r[C][259][14,14]
    hv += g[dei(p[C,1],p[C,1],p[C,1],p[C,1])]*r[C][279][14,14]
    hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][9][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][24][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][9][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][9][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][24][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][9][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][39][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][54][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][39][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][39][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][54][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][39][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,0])]*r[I][9][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,0])]*r[I][24][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,0])]*r[I][9][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,0])]*r[I][24][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,1])]*r[I][39][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,1])]*r[I][54][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,1])]*r[I][39][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,1])]*r[I][54][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,0],p[J,0])]*r[I][9][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,0],p[J,0])]*r[I][24][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,1],p[J,0])]*r[I][39][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,1],p[J,0])]*r[I][54][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,0],p[J,1])]*r[I][9][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,0],p[J,1])]*r[I][24][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,1],p[J,1])]*r[I][39][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,1],p[J,1])]*r[I][54][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[I][9][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[I][24][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[I][24][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[I][39][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[I][54][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[I][54][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[I][9][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[I][24][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[I][24][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[I][39][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[I][54][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[I][54][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B,C} for J in range(np) if J not in {A,B,C,I})
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][9][3,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][24][3,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][9][3,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][9][3,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][24][3,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][9][3,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,0],p[I,0])]*r[A][39][3,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,0],p[I,0])]*r[A][54][3,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,1],p[I,0],p[I,0])]*r[A][39][3,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,1],p[I,1])]*r[A][39][3,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,1],p[I,1])]*r[A][54][3,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,1],p[I,1],p[I,1])]*r[A][39][3,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,0])]*r[A][9][3,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,0])]*r[A][24][3,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,0])]*r[A][9][3,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,0])]*r[A][24][3,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,1])]*r[A][39][3,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,1])]*r[A][54][3,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,1])]*r[A][39][3,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,1])]*r[A][54][3,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,0])]*r[A][9][3,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,0])]*r[A][24][3,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,1],p[I,0])]*r[A][39][3,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,1],p[I,0])]*r[A][54][3,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,1])]*r[A][9][3,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,1])]*r[A][24][3,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,1],p[I,1])]*r[A][39][3,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,1],p[I,1])]*r[A][54][3,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][9][3,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][24][3,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][24][3,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,1])]*r[A][39][3,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,1])]*r[A][54][3,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,1],p[A,1])]*r[A][54][3,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][9][3,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][24][3,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][24][3,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,1])]*r[A][39][3,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,1])]*r[A][54][3,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,1],p[A,1])]*r[A][54][3,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[B,1],p[I,0],p[I,0])]*r[B][39][8,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,1],p[B,1],p[I,0],p[I,0])]*r[B][39][8,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[B,1],p[I,1],p[I,1])]*r[B][39][8,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,1],p[B,1],p[I,1],p[I,1])]*r[B][39][8,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,0],p[I,0],p[B,1])]*r[B][39][8,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[I,1],p[I,1],p[B,1])]*r[B][39][8,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,1],p[B,1],p[I,0])]*r[B][39][8,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,1],p[B,1],p[I,1])]*r[B][39][8,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,1],p[B,1])]*r[B][39][8,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,1],p[B,1])]*r[B][39][8,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[C,0],p[I,0],p[I,0])]*r[C][24][14,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[C,0],p[I,1],p[I,1])]*r[C][24][14,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[C,1],p[I,0],p[I,0])]*r[C][39][14,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[C,1],p[I,0],p[I,0])]*r[C][54][14,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[C,1],p[C,1],p[I,0],p[I,0])]*r[C][39][14,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[C,1],p[I,1],p[I,1])]*r[C][39][14,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,1],p[C,1],p[I,1],p[I,1])]*r[C][54][14,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[C,1],p[C,1],p[I,1],p[I,1])]*r[C][39][14,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,0],p[I,0],p[C,0])]*r[C][24][14,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,1],p[I,1],p[C,0])]*r[C][24][14,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,0],p[I,0],p[C,1])]*r[C][39][14,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,0],p[I,0],p[C,1])]*r[C][54][14,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,1],p[I,1],p[C,1])]*r[C][39][14,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,1],p[I,1],p[I,1],p[C,1])]*r[C][54][14,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,0],p[C,0],p[I,0])]*r[C][24][14,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,1],p[C,1],p[I,0])]*r[C][39][14,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,1],p[C,1],p[I,0])]*r[C][54][14,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,0],p[C,0],p[I,1])]*r[C][24][14,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,1],p[C,1],p[I,1])]*r[C][39][14,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,1],p[C,1],p[I,1])]*r[C][54][14,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,0],p[C,0])]*r[C][24][14,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[C,0],p[C,0])]*r[C][24][14,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,1],p[C,1])]*r[C][39][14,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,1],p[C,1])]*r[C][54][14,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[C,1],p[C,1])]*r[C][54][14,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,0],p[C,0])]*r[C][24][14,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[C,0],p[C,0])]*r[C][24][14,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,1],p[C,1])]*r[C][39][14,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,1],p[C,1])]*r[C][54][14,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[C,1],p[C,1])]*r[C][54][14,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[B,1])]*r[A][9][3,3]*r[B][39][8,8]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[B,1])]*r[A][39][3,3]*r[B][39][8,8]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[A,0])]*r[A][9][3,3]*r[B][39][8,8]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[A,1])]*r[A][39][3,3]*r[B][39][8,8]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[B,1])]*r[A][9][3,3]*r[B][39][8,8]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[B,1])]*r[A][39][3,3]*r[B][39][8,8]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[A,0])]*r[A][9][3,3]*r[B][39][8,8]
    hv += g[dei(p[B,1],p[B,1],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][39][8,8]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[A,1])]*r[A][39][3,3]*r[B][39][8,8]
    hv += g[dei(p[B,1],p[B,1],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][39][8,8]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[C,0])]*r[A][24][3,3]*r[C][24][14,14]
    hv += g[dei(p[A,0],p[A,0],p[C,0],p[C,0])]*r[A][9][3,3]*r[C][24][14,14]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[C,1])]*r[A][9][3,3]*r[C][39][14,14]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[C,1])]*r[A][24][3,3]*r[C][54][14,14]
    hv += g[dei(p[A,0],p[A,0],p[C,1],p[C,1])]*r[A][9][3,3]*r[C][54][14,14]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[C,0])]*r[A][54][3,3]*r[C][24][14,14]
    hv += g[dei(p[A,1],p[A,1],p[C,0],p[C,0])]*r[A][39][3,3]*r[C][24][14,14]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[C,1])]*r[A][39][3,3]*r[C][39][14,14]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[C,1])]*r[A][54][3,3]*r[C][54][14,14]
    hv += g[dei(p[A,1],p[A,1],p[C,1],p[C,1])]*r[A][39][3,3]*r[C][54][14,14]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,0])]*r[A][24][3,3]*r[C][24][14,14]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,0])]*r[A][9][3,3]*r[C][39][14,14]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,0])]*r[A][24][3,3]*r[C][54][14,14]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,1])]*r[A][54][3,3]*r[C][24][14,14]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,1])]*r[A][39][3,3]*r[C][39][14,14]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,1])]*r[A][54][3,3]*r[C][54][14,14]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[C,0])]*r[A][24][3,3]*r[C][24][14,14]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[C,0])]*r[A][54][3,3]*r[C][24][14,14]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[C,1])]*r[A][9][3,3]*r[C][39][14,14]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[C,1])]*r[A][24][3,3]*r[C][54][14,14]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[C,1])]*r[A][39][3,3]*r[C][39][14,14]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[C,1])]*r[A][54][3,3]*r[C][54][14,14]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,0])]*r[A][24][3,3]*r[C][24][14,14]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,1])]*r[A][54][3,3]*r[C][24][14,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,0])]*r[A][9][3,3]*r[C][39][14,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,0])]*r[A][24][3,3]*r[C][54][14,14]
    hv += g[dei(p[C,1],p[C,1],p[A,0],p[A,0])]*r[A][24][3,3]*r[C][39][14,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,1])]*r[A][39][3,3]*r[C][39][14,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,1])]*r[A][54][3,3]*r[C][54][14,14]
    hv += g[dei(p[C,1],p[C,1],p[A,1],p[A,1])]*r[A][54][3,3]*r[C][39][14,14]
    hv += g[dei(p[B,1],p[B,1],p[C,0],p[C,0])]*r[B][39][8,8]*r[C][24][14,14]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,1],p[C,1])]*r[B][39][8,8]*r[C][39][14,14]
    hv += g[dei(p[B,1],p[B,1],p[C,1],p[C,1])]*r[B][39][8,8]*r[C][54][14,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,1],p[B,1])]*r[B][39][8,8]*r[C][39][14,14]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,1],p[C,1])]*r[B][39][8,8]*r[C][39][14,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,1],p[B,1])]*r[B][39][8,8]*r[C][39][14,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B8C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,8),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += h[p[A,0],p[A,0]]*r[A][9][2,3]
    hv += h[p[A,0],p[A,0]]*r[A][24][2,3]
    hv += h[p[A,1],p[A,1]]*r[A][39][2,3]
    hv += h[p[A,1],p[A,1]]*r[A][54][2,3]
    hv += g[dei(p[A,0],p[A,0],p[A,1],p[A,1])]*r[A][214][2,3]
    hv += g[dei(p[A,0],p[A,1],p[A,1],p[A,0])]*r[A][211][2,3]
    hv += g[dei(p[A,1],p[A,0],p[A,0],p[A,1])]*r[A][262][2,3]
    hv += g[dei(p[A,1],p[A,1],p[A,0],p[A,0])]*r[A][259][2,3]
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][9][2,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][24][2,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][9][2,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][9][2,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][24][2,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][9][2,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,0],p[I,0])]*r[A][39][2,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,0],p[I,0])]*r[A][54][2,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,1],p[I,0],p[I,0])]*r[A][39][2,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,1],p[I,1])]*r[A][39][2,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,1],p[I,1],p[I,1])]*r[A][54][2,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,1],p[I,1],p[I,1])]*r[A][39][2,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,0])]*r[A][9][2,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,0])]*r[A][24][2,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,0])]*r[A][9][2,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,0])]*r[A][24][2,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,1])]*r[A][39][2,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,1])]*r[A][54][2,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,1])]*r[A][39][2,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,1])]*r[A][54][2,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,0])]*r[A][9][2,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,0])]*r[A][24][2,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,1],p[I,0])]*r[A][39][2,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,1],p[I,0])]*r[A][54][2,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,1])]*r[A][9][2,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,1])]*r[A][24][2,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,1],p[I,1])]*r[A][39][2,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,1],p[I,1])]*r[A][54][2,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][9][2,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][24][2,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][24][2,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,1])]*r[A][39][2,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,1])]*r[A][54][2,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,1],p[A,1])]*r[A][54][2,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][9][2,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][24][2,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][24][2,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,1])]*r[A][39][2,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,1])]*r[A][54][2,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,1],p[A,1])]*r[A][54][2,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[B,1])]*r[A][9][2,3]*r[B][39][8,8]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[B,1])]*r[A][39][2,3]*r[B][39][8,8]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[A,0])]*r[A][9][2,3]*r[B][39][8,8]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[A,1])]*r[A][39][2,3]*r[B][39][8,8]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[B,1])]*r[A][9][2,3]*r[B][39][8,8]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[B,1])]*r[A][39][2,3]*r[B][39][8,8]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[A,0])]*r[A][9][2,3]*r[B][39][8,8]
    hv += g[dei(p[B,1],p[B,1],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][39][8,8]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[A,1])]*r[A][39][2,3]*r[B][39][8,8]
    hv += g[dei(p[B,1],p[B,1],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][39][8,8]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[C,0])]*r[A][24][2,3]*r[C][24][14,14]
    hv += g[dei(p[A,0],p[A,0],p[C,0],p[C,0])]*r[A][9][2,3]*r[C][24][14,14]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[C,1])]*r[A][9][2,3]*r[C][39][14,14]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,1],p[C,1])]*r[A][24][2,3]*r[C][54][14,14]
    hv += g[dei(p[A,0],p[A,0],p[C,1],p[C,1])]*r[A][9][2,3]*r[C][54][14,14]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[C,0])]*r[A][54][2,3]*r[C][24][14,14]
    hv += g[dei(p[A,1],p[A,1],p[C,0],p[C,0])]*r[A][39][2,3]*r[C][24][14,14]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[C,1])]*r[A][39][2,3]*r[C][39][14,14]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,1],p[C,1])]*r[A][54][2,3]*r[C][54][14,14]
    hv += g[dei(p[A,1],p[A,1],p[C,1],p[C,1])]*r[A][39][2,3]*r[C][54][14,14]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,0])]*r[A][24][2,3]*r[C][24][14,14]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,0])]*r[A][9][2,3]*r[C][39][14,14]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,0])]*r[A][24][2,3]*r[C][54][14,14]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,1])]*r[A][54][2,3]*r[C][24][14,14]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,1])]*r[A][39][2,3]*r[C][39][14,14]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,1])]*r[A][54][2,3]*r[C][54][14,14]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[C,0])]*r[A][24][2,3]*r[C][24][14,14]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[C,0])]*r[A][54][2,3]*r[C][24][14,14]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[C,1])]*r[A][9][2,3]*r[C][39][14,14]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,0],p[C,1])]*r[A][24][2,3]*r[C][54][14,14]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[C,1])]*r[A][39][2,3]*r[C][39][14,14]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,1],p[C,1])]*r[A][54][2,3]*r[C][54][14,14]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,0])]*r[A][24][2,3]*r[C][24][14,14]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,1])]*r[A][54][2,3]*r[C][24][14,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,0])]*r[A][9][2,3]*r[C][39][14,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,0])]*r[A][24][2,3]*r[C][54][14,14]
    hv += g[dei(p[C,1],p[C,1],p[A,0],p[A,0])]*r[A][24][2,3]*r[C][39][14,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,1])]*r[A][39][2,3]*r[C][39][14,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,1])]*r[A][54][2,3]*r[C][54][14,14]
    hv += g[dei(p[C,1],p[C,1],p[A,1],p[A,1])]*r[A][54][2,3]*r[C][39][14,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B8C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,8),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += h[p[A,0],p[A,1]]*r[A][15][0,3]
    hv += h[p[A,0],p[A,1]]*r[A][30][0,3]
    hv += h[p[A,1],p[A,0]]*r[A][33][0,3]
    hv += h[p[A,1],p[A,0]]*r[A][48][0,3]
    hv += g[dei(p[A,0],p[A,0],p[A,0],p[A,1])]*r[A][198][0,3]
    hv += g[dei(p[A,0],p[A,1],p[A,0],p[A,0])]*r[A][195][0,3]
    hv += g[dei(p[A,1],p[A,0],p[A,1],p[A,1])]*r[A][278][0,3]
    hv += g[dei(p[A,1],p[A,1],p[A,1],p[A,0])]*r[A][275][0,3]
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,0],p[I,0])]*r[A][15][0,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,0],p[I,0])]*r[A][30][0,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,1],p[I,0],p[I,0])]*r[A][15][0,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,1],p[I,1])]*r[A][15][0,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,1],p[I,1])]*r[A][30][0,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,1],p[I,1],p[I,1])]*r[A][15][0,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][33][0,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][48][0,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][33][0,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][33][0,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][48][0,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][33][0,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,1])]*r[A][15][0,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,1])]*r[A][30][0,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,1])]*r[A][15][0,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,1])]*r[A][30][0,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,0])]*r[A][33][0,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,0])]*r[A][48][0,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,0])]*r[A][33][0,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,0])]*r[A][48][0,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,0],p[I,0])]*r[A][15][0,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,0],p[I,0])]*r[A][30][0,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,0])]*r[A][33][0,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,0])]*r[A][48][0,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,0],p[I,1])]*r[A][15][0,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,0],p[I,1])]*r[A][30][0,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,1])]*r[A][33][0,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,1])]*r[A][48][0,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,1])]*r[A][15][0,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][33][0,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,1])]*r[A][15][0,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][33][0,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[B,1])]*r[A][15][0,3]*r[B][39][8,8]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[B,1])]*r[A][33][0,3]*r[B][39][8,8]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[A,1])]*r[A][15][0,3]*r[B][39][8,8]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[A,0])]*r[A][33][0,3]*r[B][39][8,8]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[B,1])]*r[A][15][0,3]*r[B][39][8,8]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[B,1])]*r[A][33][0,3]*r[B][39][8,8]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[A,1])]*r[A][15][0,3]*r[B][39][8,8]
    hv += g[dei(p[B,1],p[B,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][39][8,8]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[A,0])]*r[A][33][0,3]*r[B][39][8,8]
    hv += g[dei(p[B,1],p[B,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][39][8,8]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,0],p[C,0])]*r[A][30][0,3]*r[C][24][14,14]
    hv += g[dei(p[A,0],p[A,1],p[C,0],p[C,0])]*r[A][15][0,3]*r[C][24][14,14]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,1],p[C,1])]*r[A][15][0,3]*r[C][39][14,14]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,1],p[C,1])]*r[A][30][0,3]*r[C][54][14,14]
    hv += g[dei(p[A,0],p[A,1],p[C,1],p[C,1])]*r[A][15][0,3]*r[C][54][14,14]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,0],p[C,0])]*r[A][48][0,3]*r[C][24][14,14]
    hv += g[dei(p[A,1],p[A,0],p[C,0],p[C,0])]*r[A][33][0,3]*r[C][24][14,14]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,1],p[C,1])]*r[A][33][0,3]*r[C][39][14,14]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,1],p[C,1])]*r[A][48][0,3]*r[C][54][14,14]
    hv += g[dei(p[A,1],p[A,0],p[C,1],p[C,1])]*r[A][33][0,3]*r[C][54][14,14]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,1])]*r[A][30][0,3]*r[C][24][14,14]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,1])]*r[A][15][0,3]*r[C][39][14,14]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,1])]*r[A][30][0,3]*r[C][54][14,14]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,0])]*r[A][48][0,3]*r[C][24][14,14]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,0])]*r[A][33][0,3]*r[C][39][14,14]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,0])]*r[A][48][0,3]*r[C][54][14,14]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,0],p[C,0])]*r[A][30][0,3]*r[C][24][14,14]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,1],p[C,0])]*r[A][48][0,3]*r[C][24][14,14]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,0],p[C,1])]*r[A][15][0,3]*r[C][39][14,14]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,0],p[C,1])]*r[A][30][0,3]*r[C][54][14,14]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,1],p[C,1])]*r[A][33][0,3]*r[C][39][14,14]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,1],p[C,1])]*r[A][48][0,3]*r[C][54][14,14]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[C][24][14,14]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[C][24][14,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,1])]*r[A][15][0,3]*r[C][39][14,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[C][54][14,14]
    hv += g[dei(p[C,1],p[C,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[C][39][14,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,0])]*r[A][33][0,3]*r[C][39][14,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[C][54][14,14]
    hv += g[dei(p[C,1],p[C,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[C][39][14,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B8C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,8),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += h[p[A,0],p[A,1]]*r[A][15][1,3]
    hv += h[p[A,0],p[A,1]]*r[A][30][1,3]
    hv += h[p[A,1],p[A,0]]*r[A][33][1,3]
    hv += h[p[A,1],p[A,0]]*r[A][48][1,3]
    hv += g[dei(p[A,0],p[A,0],p[A,0],p[A,1])]*r[A][198][1,3]
    hv += g[dei(p[A,0],p[A,1],p[A,0],p[A,0])]*r[A][195][1,3]
    hv += g[dei(p[A,1],p[A,0],p[A,1],p[A,1])]*r[A][278][1,3]
    hv += g[dei(p[A,1],p[A,1],p[A,1],p[A,0])]*r[A][275][1,3]
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,0],p[I,0])]*r[A][15][1,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,0],p[I,0])]*r[A][30][1,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,1],p[I,0],p[I,0])]*r[A][15][1,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,1],p[I,1])]*r[A][15][1,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[A,1],p[I,1],p[I,1])]*r[A][30][1,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[A,1],p[I,1],p[I,1])]*r[A][15][1,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][33][1,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][48][1,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][33][1,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][33][1,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][48][1,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][33][1,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,1])]*r[A][15][1,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,1])]*r[A][30][1,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,1])]*r[A][15][1,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,1])]*r[A][30][1,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,0])]*r[A][33][1,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,0])]*r[A][48][1,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,0])]*r[A][33][1,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,0])]*r[A][48][1,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,0],p[I,0])]*r[A][15][1,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[A,0],p[I,0])]*r[A][30][1,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,0])]*r[A][33][1,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,0])]*r[A][48][1,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,0],p[I,1])]*r[A][15][1,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[A,0],p[I,1])]*r[A][30][1,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,1])]*r[A][33][1,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,1])]*r[A][48][1,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,1])]*r[A][15][1,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,1])]*r[A][30][1,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,0],p[A,1])]*r[A][30][1,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][33][1,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][48][1,3]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][48][1,3]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,1])]*r[A][15][1,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,1])]*r[A][30][1,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,0],p[A,1])]*r[A][30][1,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][33][1,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][48][1,3]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][48][1,3]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[B,1])]*r[A][15][1,3]*r[B][39][8,8]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[B,1])]*r[A][33][1,3]*r[B][39][8,8]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[A,1])]*r[A][15][1,3]*r[B][39][8,8]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[A,0])]*r[A][33][1,3]*r[B][39][8,8]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[B,1])]*r[A][15][1,3]*r[B][39][8,8]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[B,1])]*r[A][33][1,3]*r[B][39][8,8]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[A,1])]*r[A][15][1,3]*r[B][39][8,8]
    hv += g[dei(p[B,1],p[B,1],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][39][8,8]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[A,0])]*r[A][33][1,3]*r[B][39][8,8]
    hv += g[dei(p[B,1],p[B,1],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][39][8,8]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,0],p[C,0])]*r[A][30][1,3]*r[C][24][14,14]
    hv += g[dei(p[A,0],p[A,1],p[C,0],p[C,0])]*r[A][15][1,3]*r[C][24][14,14]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,1],p[C,1])]*r[A][15][1,3]*r[C][39][14,14]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,1],p[C,1])]*r[A][30][1,3]*r[C][54][14,14]
    hv += g[dei(p[A,0],p[A,1],p[C,1],p[C,1])]*r[A][15][1,3]*r[C][54][14,14]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,0],p[C,0])]*r[A][48][1,3]*r[C][24][14,14]
    hv += g[dei(p[A,1],p[A,0],p[C,0],p[C,0])]*r[A][33][1,3]*r[C][24][14,14]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,1],p[C,1])]*r[A][33][1,3]*r[C][39][14,14]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,1],p[C,1])]*r[A][48][1,3]*r[C][54][14,14]
    hv += g[dei(p[A,1],p[A,0],p[C,1],p[C,1])]*r[A][33][1,3]*r[C][54][14,14]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[A,1])]*r[A][30][1,3]*r[C][24][14,14]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,1])]*r[A][15][1,3]*r[C][39][14,14]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[A,1])]*r[A][30][1,3]*r[C][54][14,14]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[A,0])]*r[A][48][1,3]*r[C][24][14,14]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,0])]*r[A][33][1,3]*r[C][39][14,14]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[A,0])]*r[A][48][1,3]*r[C][54][14,14]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,0],p[C,0])]*r[A][30][1,3]*r[C][24][14,14]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,1],p[C,0])]*r[A][48][1,3]*r[C][24][14,14]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,0],p[C,1])]*r[A][15][1,3]*r[C][39][14,14]
    hv += -1/2*g[dei(p[C,1],p[A,1],p[A,0],p[C,1])]*r[A][30][1,3]*r[C][54][14,14]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,1],p[C,1])]*r[A][33][1,3]*r[C][39][14,14]
    hv += -1/2*g[dei(p[C,1],p[A,0],p[A,1],p[C,1])]*r[A][48][1,3]*r[C][54][14,14]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[A,1])]*r[A][30][1,3]*r[C][24][14,14]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[A,0])]*r[A][48][1,3]*r[C][24][14,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,1])]*r[A][15][1,3]*r[C][39][14,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[A,1])]*r[A][30][1,3]*r[C][54][14,14]
    hv += g[dei(p[C,1],p[C,1],p[A,0],p[A,1])]*r[A][30][1,3]*r[C][39][14,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,0])]*r[A][33][1,3]*r[C][39][14,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[A,0])]*r[A][48][1,3]*r[C][54][14,14]
    hv += g[dei(p[C,1],p[C,1],p[A,1],p[A,0])]*r[A][48][1,3]*r[C][39][14,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B7C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,7),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += h[p[B,0],p[B,1]]*r[B][15][7,8]
    hv += sum(1/2*g[dei(p[B,0],p[B,1],p[I,0],p[I,0])]*r[B][15][7,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,0],p[B,1],p[I,0],p[I,0])]*r[B][15][7,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[B,1],p[I,1],p[I,1])]*r[B][15][7,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[B,0],p[B,1],p[I,1],p[I,1])]*r[B][15][7,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,0],p[I,0],p[B,1])]*r[B][15][7,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[I,1],p[I,1],p[B,1])]*r[B][15][7,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,1],p[B,0],p[I,0])]*r[B][15][7,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,1],p[B,0],p[I,1])]*r[B][15][7,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,0],p[B,1])]*r[B][15][7,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,0],p[B,1])]*r[B][15][7,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[B,1])]*r[A][9][3,3]*r[B][15][7,8]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[B,1])]*r[A][39][3,3]*r[B][15][7,8]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[A,0])]*r[A][9][3,3]*r[B][15][7,8]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[A,1])]*r[A][39][3,3]*r[B][15][7,8]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[B,1])]*r[A][9][3,3]*r[B][15][7,8]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[B,1])]*r[A][39][3,3]*r[B][15][7,8]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[A,0])]*r[A][9][3,3]*r[B][15][7,8]
    hv += g[dei(p[B,0],p[B,1],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][15][7,8]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[A,1])]*r[A][39][3,3]*r[B][15][7,8]
    hv += g[dei(p[B,0],p[B,1],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][15][7,8]
    hv += g[dei(p[B,0],p[B,1],p[C,0],p[C,0])]*r[B][15][7,8]*r[C][24][14,14]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,1],p[C,1])]*r[B][15][7,8]*r[C][39][14,14]
    hv += g[dei(p[B,0],p[B,1],p[C,1],p[C,1])]*r[B][15][7,8]*r[C][54][14,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,1],p[B,1])]*r[B][15][7,8]*r[C][39][14,14]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[B,0],p[C,1])]*r[B][15][7,8]*r[C][39][14,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,0],p[B,1])]*r[B][15][7,8]*r[C][39][14,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B8C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,8),(C,13)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += h[p[C,0],p[C,1]]*r[C][15][13,14]
    hv += g[dei(p[C,0],p[C,1],p[C,0],p[C,0])]*r[C][195][13,14]
    hv += g[dei(p[C,0],p[C,1],p[C,1],p[C,1])]*r[C][215][13,14]
    hv += sum(1/2*g[dei(p[C,0],p[C,1],p[I,0],p[I,0])]*r[C][15][13,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[C,0],p[C,1],p[I,0],p[I,0])]*r[C][15][13,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[C,1],p[I,1],p[I,1])]*r[C][15][13,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[C,0],p[C,1],p[I,1],p[I,1])]*r[C][15][13,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,0],p[I,0],p[C,1])]*r[C][15][13,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,1],p[I,1],p[C,1])]*r[C][15][13,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[C,1],p[C,0],p[I,0])]*r[C][15][13,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[C,1],p[C,0],p[I,1])]*r[C][15][13,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,0],p[C,1])]*r[C][15][13,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,0],p[C,1])]*r[C][15][13,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[C,1])]*r[A][9][3,3]*r[C][15][13,14]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[C,1])]*r[A][39][3,3]*r[C][15][13,14]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[A,0])]*r[A][9][3,3]*r[C][15][13,14]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[A,1])]*r[A][39][3,3]*r[C][15][13,14]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[C,1])]*r[A][9][3,3]*r[C][15][13,14]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[C,1])]*r[A][39][3,3]*r[C][15][13,14]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[A,0])]*r[A][9][3,3]*r[C][15][13,14]
    hv += g[dei(p[C,0],p[C,1],p[A,0],p[A,0])]*r[A][24][3,3]*r[C][15][13,14]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[A,1])]*r[A][39][3,3]*r[C][15][13,14]
    hv += g[dei(p[C,0],p[C,1],p[A,1],p[A,1])]*r[A][54][3,3]*r[C][15][13,14]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,0],p[C,1])]*r[B][39][8,8]*r[C][15][13,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,0],p[B,1])]*r[B][39][8,8]*r[C][15][13,14]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,1],p[C,1])]*r[B][39][8,8]*r[C][15][13,14]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,1],p[B,1])]*r[B][39][8,8]*r[C][15][13,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B8C14I1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,8),(C,14),(I,1)]))
        hv = 0.0
        sket = sign([B,C])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,0],p[I,0])]*r[A][15][0,3]*r[I][9][1,0]
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,0],p[I,0])]*r[A][30][0,3]*r[I][24][1,0]
        hv += g[dei(p[A,0],p[A,1],p[I,0],p[I,0])]*r[A][15][0,3]*r[I][24][1,0]
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,1],p[I,1])]*r[A][15][0,3]*r[I][39][1,0]
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,1],p[I,1])]*r[A][30][0,3]*r[I][54][1,0]
        hv += g[dei(p[A,0],p[A,1],p[I,1],p[I,1])]*r[A][15][0,3]*r[I][54][1,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][33][0,3]*r[I][9][1,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][48][0,3]*r[I][24][1,0]
        hv += g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][33][0,3]*r[I][24][1,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][33][0,3]*r[I][39][1,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][48][0,3]*r[I][54][1,0]
        hv += g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][33][0,3]*r[I][54][1,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,1])]*r[A][15][0,3]*r[I][9][1,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,1])]*r[A][30][0,3]*r[I][24][1,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,1])]*r[A][15][0,3]*r[I][39][1,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,1])]*r[A][30][0,3]*r[I][54][1,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,0])]*r[A][33][0,3]*r[I][9][1,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,0])]*r[A][48][0,3]*r[I][24][1,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,0])]*r[A][33][0,3]*r[I][39][1,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,0])]*r[A][48][0,3]*r[I][54][1,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,0],p[I,0])]*r[A][15][0,3]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,0],p[I,0])]*r[A][30][0,3]*r[I][24][1,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,0])]*r[A][33][0,3]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,0])]*r[A][48][0,3]*r[I][24][1,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,0],p[I,1])]*r[A][15][0,3]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,0],p[I,1])]*r[A][30][0,3]*r[I][54][1,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,1])]*r[A][33][0,3]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,1])]*r[A][48][0,3]*r[I][54][1,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,1])]*r[A][15][0,3]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][24][1,0]
        hv += g[dei(p[I,0],p[I,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][33][0,3]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][24][1,0]
        hv += g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,1])]*r[A][15][0,3]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][54][1,0]
        hv += g[dei(p[I,1],p[I,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][33][0,3]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][54][1,0]
        hv += g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B8C14I2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,8),(C,14),(I,2)]))
        hv = 0.0
        sket = sign([B,C])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,0],p[I,1])]*r[A][15][0,3]*r[I][15][2,0]
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,0],p[I,1])]*r[A][30][0,3]*r[I][30][2,0]
        hv += g[dei(p[A,0],p[A,1],p[I,0],p[I,1])]*r[A][15][0,3]*r[I][30][2,0]
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,1],p[I,0])]*r[A][15][0,3]*r[I][33][2,0]
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,1],p[I,0])]*r[A][30][0,3]*r[I][48][2,0]
        hv += g[dei(p[A,0],p[A,1],p[I,1],p[I,0])]*r[A][15][0,3]*r[I][48][2,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,1])]*r[A][33][0,3]*r[I][15][2,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,1])]*r[A][48][0,3]*r[I][30][2,0]
        hv += g[dei(p[A,1],p[A,0],p[I,0],p[I,1])]*r[A][33][0,3]*r[I][30][2,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,0])]*r[A][33][0,3]*r[I][33][2,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,0])]*r[A][48][0,3]*r[I][48][2,0]
        hv += g[dei(p[A,1],p[A,0],p[I,1],p[I,0])]*r[A][33][0,3]*r[I][48][2,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[I,0],p[A,1])]*r[A][15][0,3]*r[I][15][2,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[I,0],p[A,1])]*r[A][30][0,3]*r[I][30][2,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[I,1],p[A,1])]*r[A][15][0,3]*r[I][33][2,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[I,1],p[A,1])]*r[A][30][0,3]*r[I][48][2,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[I,0],p[A,0])]*r[A][33][0,3]*r[I][15][2,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[I,0],p[A,0])]*r[A][48][0,3]*r[I][30][2,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[I,1],p[A,0])]*r[A][33][0,3]*r[I][33][2,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[I,1],p[A,0])]*r[A][48][0,3]*r[I][48][2,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,0],p[I,1])]*r[A][15][0,3]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,0],p[I,1])]*r[A][30][0,3]*r[I][30][2,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,1])]*r[A][33][0,3]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,1])]*r[A][48][0,3]*r[I][30][2,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,0],p[I,0])]*r[A][15][0,3]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,0],p[I,0])]*r[A][30][0,3]*r[I][48][2,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,0])]*r[A][33][0,3]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,0])]*r[A][48][0,3]*r[I][48][2,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,0],p[A,1])]*r[A][15][0,3]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][30][2,0]
        hv += g[dei(p[I,0],p[I,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,1],p[A,0])]*r[A][33][0,3]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][30][2,0]
        hv += g[dei(p[I,0],p[I,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,0],p[A,1])]*r[A][15][0,3]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][48][2,0]
        hv += g[dei(p[I,1],p[I,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,1],p[A,0])]*r[A][33][0,3]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][48][2,0]
        hv += g[dei(p[I,1],p[I,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B8C14I3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,8),(C,14),(I,3)]))
        hv = 0.0
        sket = sign([B,C])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,0],p[I,1])]*r[A][15][0,3]*r[I][15][3,0]
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,0],p[I,1])]*r[A][30][0,3]*r[I][30][3,0]
        hv += g[dei(p[A,0],p[A,1],p[I,0],p[I,1])]*r[A][15][0,3]*r[I][30][3,0]
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,1],p[I,0])]*r[A][15][0,3]*r[I][33][3,0]
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,1],p[I,0])]*r[A][30][0,3]*r[I][48][3,0]
        hv += g[dei(p[A,0],p[A,1],p[I,1],p[I,0])]*r[A][15][0,3]*r[I][48][3,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,1])]*r[A][33][0,3]*r[I][15][3,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,1])]*r[A][48][0,3]*r[I][30][3,0]
        hv += g[dei(p[A,1],p[A,0],p[I,0],p[I,1])]*r[A][33][0,3]*r[I][30][3,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,0])]*r[A][33][0,3]*r[I][33][3,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,0])]*r[A][48][0,3]*r[I][48][3,0]
        hv += g[dei(p[A,1],p[A,0],p[I,1],p[I,0])]*r[A][33][0,3]*r[I][48][3,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[I,0],p[A,1])]*r[A][15][0,3]*r[I][15][3,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[I,0],p[A,1])]*r[A][30][0,3]*r[I][30][3,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[I,1],p[A,1])]*r[A][15][0,3]*r[I][33][3,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[I,1],p[A,1])]*r[A][30][0,3]*r[I][48][3,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[I,0],p[A,0])]*r[A][33][0,3]*r[I][15][3,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[I,0],p[A,0])]*r[A][48][0,3]*r[I][30][3,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[I,1],p[A,0])]*r[A][33][0,3]*r[I][33][3,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[I,1],p[A,0])]*r[A][48][0,3]*r[I][48][3,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,0],p[I,1])]*r[A][15][0,3]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,0],p[I,1])]*r[A][30][0,3]*r[I][30][3,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,1])]*r[A][33][0,3]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,1])]*r[A][48][0,3]*r[I][30][3,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,0],p[I,0])]*r[A][15][0,3]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,0],p[I,0])]*r[A][30][0,3]*r[I][48][3,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,0])]*r[A][33][0,3]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,0])]*r[A][48][0,3]*r[I][48][3,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,0],p[A,1])]*r[A][15][0,3]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][30][3,0]
        hv += g[dei(p[I,0],p[I,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,1],p[A,0])]*r[A][33][0,3]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][30][3,0]
        hv += g[dei(p[I,0],p[I,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,0],p[A,1])]*r[A][15][0,3]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][48][3,0]
        hv += g[dei(p[I,1],p[I,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,1],p[A,0])]*r[A][33][0,3]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][48][3,0]
        hv += g[dei(p[I,1],p[I,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C14I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,14),(I,7)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += h[p[B,1],p[I,0]]*r[B][6][0,8]*r[I][3][7,0]
        hv += -1*g[dei(p[B,0],p[B,1],p[B,0],p[I,0])]*r[B][68][0,8]*r[I][3][7,0]
        hv += -1*g[dei(p[B,1],p[B,1],p[B,1],p[I,0])]*r[B][148][0,8]*r[I][3][7,0]
        hv += -1*g[dei(p[I,0],p[I,0],p[B,1],p[I,0])]*r[B][6][0,8]*r[I][65][7,0]
        hv += -1*g[dei(p[I,0],p[I,1],p[B,1],p[I,1])]*r[B][6][0,8]*r[I][85][7,0]
        hv += sum(-1/4*g[dei(p[B,1],p[J,0],p[J,0],p[I,0])]*r[B][6][0,8]*r[J][24][0,0]*r[I][3][7,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[B,1],p[J,1],p[J,1],p[I,0])]*r[B][6][0,8]*r[J][54][0,0]*r[I][3][7,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[B,1],p[I,0],p[J,0],p[J,0])]*r[B][6][0,8]*r[J][24][0,0]*r[I][3][7,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[B,1],p[I,0],p[J,1],p[J,1])]*r[B][6][0,8]*r[J][54][0,0]*r[I][3][7,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[B,1],p[I,0])]*r[B][6][0,8]*r[J][24][0,0]*r[I][3][7,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[B,1],p[I,0])]*r[B][6][0,8]*r[J][9][0,0]*r[I][3][7,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[B,1],p[I,0])]*r[B][6][0,8]*r[J][54][0,0]*r[I][3][7,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[B,1],p[I,0])]*r[B][6][0,8]*r[J][39][0,0]*r[I][3][7,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[B,1],p[J,0])]*r[B][6][0,8]*r[J][24][0,0]*r[I][3][7,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[B,1],p[J,1])]*r[B][6][0,8]*r[J][54][0,0]*r[I][3][7,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[B,1],p[I,0],p[J,0],p[J,0])]*r[B][6][0,8]*r[I][3][7,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[B,1],p[I,0],p[J,1],p[J,1])]*r[B][6][0,8]*r[I][3][7,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[B,1],p[J,0],p[J,0],p[I,0])]*r[B][6][0,8]*r[I][3][7,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[B,1],p[J,1],p[J,1],p[I,0])]*r[B][6][0,8]*r[I][3][7,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[B,1],p[J,0])]*r[B][6][0,8]*r[I][3][7,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[B,1],p[J,1])]*r[B][6][0,8]*r[I][3][7,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[B,1],p[I,0])]*r[B][6][0,8]*r[I][3][7,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[B,1],p[I,0])]*r[B][6][0,8]*r[I][3][7,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[B,1],p[I,0])]*r[B][6][0,8]*r[I][3][7,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[B,1],p[I,0])]*r[B][6][0,8]*r[I][3][7,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[I,0])]*r[A][24][3,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += g[dei(p[A,0],p[A,0],p[B,1],p[I,0])]*r[A][9][3,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[I,0])]*r[A][54][3,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += g[dei(p[A,1],p[A,1],p[B,1],p[I,0])]*r[A][39][3,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,1],p[A,0])]*r[A][24][3,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,1],p[A,1])]*r[A][54][3,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[I,0])]*r[A][24][3,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[I,0])]*r[A][54][3,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[C,0],p[C,0],p[I,0])]*r[B][6][0,8]*r[C][24][14,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[C,1],p[C,1],p[I,0])]*r[B][6][0,8]*r[C][54][14,14]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[C,0],p[C,0])]*r[B][6][0,8]*r[C][24][14,14]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[C,1],p[C,1])]*r[B][6][0,8]*r[C][54][14,14]*r[I][3][7,0]
        hv += 1/2*g[dei(p[C,0],p[C,0],p[B,1],p[I,0])]*r[B][6][0,8]*r[C][24][14,14]*r[I][3][7,0]
        hv += 1/2*g[dei(p[C,1],p[C,1],p[B,1],p[I,0])]*r[B][6][0,8]*r[C][54][14,14]*r[I][3][7,0]
        hv += g[dei(p[C,1],p[C,1],p[B,1],p[I,0])]*r[B][6][0,8]*r[C][39][14,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[C,0],p[I,0],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][24][14,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[C,1],p[I,0],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][54][14,14]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C14I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,14),(I,8)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += h[p[B,1],p[I,1]]*r[B][6][0,8]*r[I][7][8,0]
        hv += -1*g[dei(p[B,0],p[B,1],p[B,0],p[I,1])]*r[B][68][0,8]*r[I][7][8,0]
        hv += -1*g[dei(p[B,1],p[B,1],p[B,1],p[I,1])]*r[B][148][0,8]*r[I][7][8,0]
        hv += -1*g[dei(p[I,1],p[I,0],p[B,1],p[I,0])]*r[B][6][0,8]*r[I][129][8,0]
        hv += -1*g[dei(p[I,1],p[I,1],p[B,1],p[I,1])]*r[B][6][0,8]*r[I][149][8,0]
        hv += sum(-1/4*g[dei(p[B,1],p[J,0],p[J,0],p[I,1])]*r[B][6][0,8]*r[J][24][0,0]*r[I][7][8,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[B,1],p[J,1],p[J,1],p[I,1])]*r[B][6][0,8]*r[J][54][0,0]*r[I][7][8,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[B,1],p[I,1],p[J,0],p[J,0])]*r[B][6][0,8]*r[J][24][0,0]*r[I][7][8,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[B,1],p[I,1],p[J,1],p[J,1])]*r[B][6][0,8]*r[J][54][0,0]*r[I][7][8,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[B,1],p[I,1])]*r[B][6][0,8]*r[J][24][0,0]*r[I][7][8,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[B,1],p[I,1])]*r[B][6][0,8]*r[J][9][0,0]*r[I][7][8,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[B,1],p[I,1])]*r[B][6][0,8]*r[J][54][0,0]*r[I][7][8,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[B,1],p[I,1])]*r[B][6][0,8]*r[J][39][0,0]*r[I][7][8,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[B,1],p[J,0])]*r[B][6][0,8]*r[J][24][0,0]*r[I][7][8,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[B,1],p[J,1])]*r[B][6][0,8]*r[J][54][0,0]*r[I][7][8,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[B,1],p[I,1],p[J,0],p[J,0])]*r[B][6][0,8]*r[I][7][8,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[B,1],p[I,1],p[J,1],p[J,1])]*r[B][6][0,8]*r[I][7][8,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[B,1],p[J,0],p[J,0],p[I,1])]*r[B][6][0,8]*r[I][7][8,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[B,1],p[J,1],p[J,1],p[I,1])]*r[B][6][0,8]*r[I][7][8,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[B,1],p[J,0])]*r[B][6][0,8]*r[I][7][8,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[B,1],p[J,1])]*r[B][6][0,8]*r[I][7][8,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[B,1],p[I,1])]*r[B][6][0,8]*r[I][7][8,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[B,1],p[I,1])]*r[B][6][0,8]*r[I][7][8,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[B,1],p[I,1])]*r[B][6][0,8]*r[I][7][8,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[B,1],p[I,1])]*r[B][6][0,8]*r[I][7][8,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[I,1])]*r[A][24][3,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += g[dei(p[A,0],p[A,0],p[B,1],p[I,1])]*r[A][9][3,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[I,1])]*r[A][54][3,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += g[dei(p[A,1],p[A,1],p[B,1],p[I,1])]*r[A][39][3,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,1],p[A,0])]*r[A][24][3,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,1],p[A,1])]*r[A][54][3,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[I,1])]*r[A][24][3,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[I,1])]*r[A][54][3,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[C,0],p[C,0],p[I,1])]*r[B][6][0,8]*r[C][24][14,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[C,1],p[C,1],p[I,1])]*r[B][6][0,8]*r[C][54][14,14]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[C,0],p[C,0])]*r[B][6][0,8]*r[C][24][14,14]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[C,1],p[C,1])]*r[B][6][0,8]*r[C][54][14,14]*r[I][7][8,0]
        hv += 1/2*g[dei(p[C,0],p[C,0],p[B,1],p[I,1])]*r[B][6][0,8]*r[C][24][14,14]*r[I][7][8,0]
        hv += 1/2*g[dei(p[C,1],p[C,1],p[B,1],p[I,1])]*r[B][6][0,8]*r[C][54][14,14]*r[I][7][8,0]
        hv += g[dei(p[C,1],p[C,1],p[B,1],p[I,1])]*r[B][6][0,8]*r[C][39][14,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[C,0],p[I,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][24][14,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[C,1],p[I,1],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][54][14,14]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B8I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,8),(I,14)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += h[p[I,0],p[C,0]]*r[C][3][0,14]*r[I][2][14,0]
        hv += -1*g[dei(p[C,0],p[C,1],p[I,0],p[C,1])]*r[C][85][0,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[C,1],p[C,0],p[I,0],p[C,1])]*r[C][179][0,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[C,1],p[C,1],p[I,0],p[C,0])]*r[C][167][0,14]*r[I][2][14,0]
        hv += -1*g[dei(p[C,1],p[C,1],p[I,0],p[C,0])]*r[C][133][0,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[C,1],p[C,1])]*r[C][179][0,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[C,1],p[C,0])]*r[C][167][0,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[I,1],p[I,1])]*r[C][3][0,14]*r[I][118][14,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[I,0],p[I,1])]*r[C][3][0,14]*r[I][166][14,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[I,1],p[C,0])]*r[C][3][0,14]*r[I][118][14,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[I,0],p[C,0])]*r[C][3][0,14]*r[I][166][14,0]
        hv += -1*g[dei(p[I,1],p[I,1],p[I,0],p[C,0])]*r[C][3][0,14]*r[I][132][14,0]
        hv += -1*g[dei(p[I,1],p[I,0],p[I,1],p[C,0])]*r[C][3][0,14]*r[I][144][14,0]
        hv += sum(-1/4*g[dei(p[J,0],p[C,0],p[I,0],p[J,0])]*r[C][3][0,14]*r[J][24][0,0]*r[I][2][14,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[J,1],p[C,0],p[I,0],p[J,1])]*r[C][3][0,14]*r[J][54][0,0]*r[I][2][14,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[C,0])]*r[C][3][0,14]*r[J][24][0,0]*r[I][2][14,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,0],p[C,0])]*r[C][3][0,14]*r[J][9][0,0]*r[I][2][14,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[C,0])]*r[C][3][0,14]*r[J][54][0,0]*r[I][2][14,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,0],p[C,0])]*r[C][3][0,14]*r[J][39][0,0]*r[I][2][14,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[I,0],p[C,0],p[J,0],p[J,0])]*r[C][3][0,14]*r[J][24][0,0]*r[I][2][14,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[I,0],p[C,0],p[J,1],p[J,1])]*r[C][3][0,14]*r[J][54][0,0]*r[I][2][14,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[C,0])]*r[C][3][0,14]*r[J][24][0,0]*r[I][2][14,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[C,0])]*r[C][3][0,14]*r[J][54][0,0]*r[I][2][14,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[I,0],p[C,0],p[J,0],p[J,0])]*r[C][3][0,14]*r[I][2][14,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[I,0],p[C,0],p[J,1],p[J,1])]*r[C][3][0,14]*r[I][2][14,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[C,0])]*r[C][3][0,14]*r[I][2][14,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[C,0])]*r[C][3][0,14]*r[I][2][14,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[J,0],p[C,0],p[I,0],p[J,0])]*r[C][3][0,14]*r[I][2][14,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[J,1],p[C,0],p[I,0],p[J,1])]*r[C][3][0,14]*r[I][2][14,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[C,0])]*r[C][3][0,14]*r[I][2][14,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,0],p[C,0])]*r[C][3][0,14]*r[I][2][14,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[C,0])]*r[C][3][0,14]*r[I][2][14,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,0],p[C,0])]*r[C][3][0,14]*r[I][2][14,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,0],p[C,0])]*r[A][24][3,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += g[dei(p[A,0],p[A,0],p[I,0],p[C,0])]*r[A][9][3,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,0],p[C,0])]*r[A][54][3,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += g[dei(p[A,1],p[A,1],p[I,0],p[C,0])]*r[A][39][3,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[A,0],p[C,0],p[I,0],p[A,0])]*r[A][24][3,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[A,1],p[C,0],p[I,0],p[A,1])]*r[A][54][3,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,0],p[C,0])]*r[A][24][3,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,1],p[C,0])]*r[A][54][3,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[A,0],p[A,0])]*r[A][24][3,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[A,1],p[A,1])]*r[A][54][3,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += g[dei(p[B,1],p[B,1],p[I,0],p[C,0])]*r[B][39][8,8]*r[C][3][0,14]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B8I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,8),(I,13)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += h[p[I,1],p[C,0]]*r[C][3][0,14]*r[I][6][13,0]
        hv += -1*g[dei(p[C,0],p[C,1],p[I,1],p[C,1])]*r[C][85][0,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[C,1],p[C,0],p[I,1],p[C,1])]*r[C][179][0,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[C,1],p[C,1],p[I,1],p[C,0])]*r[C][167][0,14]*r[I][6][13,0]
        hv += -1*g[dei(p[C,1],p[C,1],p[I,1],p[C,0])]*r[C][133][0,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[C,1],p[C,1])]*r[C][179][0,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[C,1],p[C,0])]*r[C][167][0,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[I,1],p[I,0])]*r[C][3][0,14]*r[I][114][13,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[I,0],p[I,0])]*r[C][3][0,14]*r[I][162][13,0]
        hv += -1*g[dei(p[I,0],p[I,1],p[I,0],p[C,0])]*r[C][3][0,14]*r[I][68][13,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[I,1],p[C,0])]*r[C][3][0,14]*r[I][114][13,0]
        hv += -1*g[dei(p[I,0],p[I,0],p[I,1],p[C,0])]*r[C][3][0,14]*r[I][80][13,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[I,0],p[C,0])]*r[C][3][0,14]*r[I][162][13,0]
        hv += sum(-1/4*g[dei(p[J,0],p[C,0],p[I,1],p[J,0])]*r[C][3][0,14]*r[J][24][0,0]*r[I][6][13,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[J,1],p[C,0],p[I,1],p[J,1])]*r[C][3][0,14]*r[J][54][0,0]*r[I][6][13,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[C,0])]*r[C][3][0,14]*r[J][24][0,0]*r[I][6][13,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,1],p[C,0])]*r[C][3][0,14]*r[J][9][0,0]*r[I][6][13,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[C,0])]*r[C][3][0,14]*r[J][54][0,0]*r[I][6][13,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,1],p[C,0])]*r[C][3][0,14]*r[J][39][0,0]*r[I][6][13,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[I,1],p[C,0],p[J,0],p[J,0])]*r[C][3][0,14]*r[J][24][0,0]*r[I][6][13,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[I,1],p[C,0],p[J,1],p[J,1])]*r[C][3][0,14]*r[J][54][0,0]*r[I][6][13,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[C,0])]*r[C][3][0,14]*r[J][24][0,0]*r[I][6][13,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[C,0])]*r[C][3][0,14]*r[J][54][0,0]*r[I][6][13,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[I,1],p[C,0],p[J,0],p[J,0])]*r[C][3][0,14]*r[I][6][13,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[I,1],p[C,0],p[J,1],p[J,1])]*r[C][3][0,14]*r[I][6][13,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[C,0])]*r[C][3][0,14]*r[I][6][13,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[C,0])]*r[C][3][0,14]*r[I][6][13,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[J,0],p[C,0],p[I,1],p[J,0])]*r[C][3][0,14]*r[I][6][13,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(-1/4*g[dei(p[J,1],p[C,0],p[I,1],p[J,1])]*r[C][3][0,14]*r[I][6][13,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[C,0])]*r[C][3][0,14]*r[I][6][13,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,1],p[C,0])]*r[C][3][0,14]*r[I][6][13,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[C,0])]*r[C][3][0,14]*r[I][6][13,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,1],p[C,0])]*r[C][3][0,14]*r[I][6][13,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,C,I})
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,1],p[C,0])]*r[A][24][3,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += g[dei(p[A,0],p[A,0],p[I,1],p[C,0])]*r[A][9][3,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,1],p[C,0])]*r[A][54][3,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += g[dei(p[A,1],p[A,1],p[I,1],p[C,0])]*r[A][39][3,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[A,0],p[C,0],p[I,1],p[A,0])]*r[A][24][3,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[A,1],p[C,0],p[I,1],p[A,1])]*r[A][54][3,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,0],p[C,0])]*r[A][24][3,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,1],p[C,0])]*r[A][54][3,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[A,0],p[A,0])]*r[A][24][3,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[A,1],p[A,1])]*r[A][54][3,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += g[dei(p[B,1],p[B,1],p[I,1],p[C,0])]*r[B][39][8,8]*r[C][3][0,14]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B6C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,6),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += h[p[A,0],p[B,1]]*r[A][0][11,3]*r[B][5][6,8]
    hv += -1/2*g[dei(p[A,0],p[A,1],p[A,1],p[B,1])]*r[A][76][11,3]*r[B][5][6,8]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[A,0],p[B,1])]*r[A][124][11,3]*r[B][5][6,8]
    hv += g[dei(p[A,0],p[B,1],p[A,0],p[A,0])]*r[A][66][11,3]*r[B][5][6,8]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[A,1],p[A,1])]*r[A][76][11,3]*r[B][5][6,8]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[A,0],p[A,1])]*r[A][124][11,3]*r[B][5][6,8]
    hv += g[dei(p[A,1],p[B,1],p[A,0],p[A,1])]*r[A][134][11,3]*r[B][5][6,8]
    hv += sum(1/2*g[dei(p[A,0],p[B,1],p[I,0],p[I,0])]*r[A][0][11,3]*r[B][5][6,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[B,1],p[I,0],p[I,0])]*r[A][0][11,3]*r[B][5][6,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[B,1],p[I,1],p[I,1])]*r[A][0][11,3]*r[B][5][6,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,0],p[B,1],p[I,1],p[I,1])]*r[A][0][11,3]*r[B][5][6,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[B,1])]*r[A][0][11,3]*r[B][5][6,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[B,1])]*r[A][0][11,3]*r[B][5][6,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,1],p[A,0],p[I,0])]*r[A][0][11,3]*r[B][5][6,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,1],p[A,0],p[I,1])]*r[A][0][11,3]*r[B][5][6,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[B,1])]*r[A][0][11,3]*r[B][5][6,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[B,1])]*r[A][0][11,3]*r[B][5][6,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += g[dei(p[A,0],p[B,1],p[C,0],p[C,0])]*r[A][0][11,3]*r[B][5][6,8]*r[C][24][14,14]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,1],p[C,1])]*r[A][0][11,3]*r[B][5][6,8]*r[C][39][14,14]
    hv += g[dei(p[A,0],p[B,1],p[C,1],p[C,1])]*r[A][0][11,3]*r[B][5][6,8]*r[C][54][14,14]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[B,1])]*r[A][0][11,3]*r[B][5][6,8]*r[C][39][14,14]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,0],p[C,1])]*r[A][0][11,3]*r[B][5][6,8]*r[C][39][14,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[B,1])]*r[A][0][11,3]*r[B][5][6,8]*r[C][39][14,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B6C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,6),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += h[p[A,1],p[B,1]]*r[A][4][12,3]*r[B][5][6,8]
    hv += -1/2*g[dei(p[A,0],p[A,0],p[A,1],p[B,1])]*r[A][72][12,3]*r[B][5][6,8]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[A,0],p[B,1])]*r[A][120][12,3]*r[B][5][6,8]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[A,1],p[A,0])]*r[A][72][12,3]*r[B][5][6,8]
    hv += g[dei(p[A,0],p[B,1],p[A,1],p[A,0])]*r[A][82][12,3]*r[B][5][6,8]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[A,0],p[A,0])]*r[A][120][12,3]*r[B][5][6,8]
    hv += g[dei(p[A,1],p[B,1],p[A,1],p[A,1])]*r[A][150][12,3]*r[B][5][6,8]
    hv += sum(1/2*g[dei(p[A,1],p[B,1],p[I,0],p[I,0])]*r[A][4][12,3]*r[B][5][6,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[B,1],p[I,0],p[I,0])]*r[A][4][12,3]*r[B][5][6,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[B,1],p[I,1],p[I,1])]*r[A][4][12,3]*r[B][5][6,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[A,1],p[B,1],p[I,1],p[I,1])]*r[A][4][12,3]*r[B][5][6,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[B,1])]*r[A][4][12,3]*r[B][5][6,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[B,1])]*r[A][4][12,3]*r[B][5][6,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,1],p[A,1],p[I,0])]*r[A][4][12,3]*r[B][5][6,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,1],p[A,1],p[I,1])]*r[A][4][12,3]*r[B][5][6,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[B,1])]*r[A][4][12,3]*r[B][5][6,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[B,1])]*r[A][4][12,3]*r[B][5][6,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += g[dei(p[A,1],p[B,1],p[C,0],p[C,0])]*r[A][4][12,3]*r[B][5][6,8]*r[C][24][14,14]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,1],p[C,1])]*r[A][4][12,3]*r[B][5][6,8]*r[C][39][14,14]
    hv += g[dei(p[A,1],p[B,1],p[C,1],p[C,1])]*r[A][4][12,3]*r[B][5][6,8]*r[C][54][14,14]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[B,1])]*r[A][4][12,3]*r[B][5][6,8]*r[C][39][14,14]
    hv += -1/2*g[dei(p[C,1],p[B,1],p[A,1],p[C,1])]*r[A][4][12,3]*r[B][5][6,8]*r[C][39][14,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[B,1])]*r[A][4][12,3]*r[B][5][6,8]*r[C][39][14,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B4C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,4),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[B,0],p[A,0]]*r[A][1][10,3]*r[B][0][4,8]
    hv += -1*g[dei(p[B,0],p[A,0],p[A,1],p[A,1])]*r[A][177][10,3]*r[B][0][4,8]
    hv += -1*g[dei(p[B,0],p[A,1],p[A,1],p[A,0])]*r[A][165][10,3]*r[B][0][4,8]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[B,1],p[B,1])]*r[A][1][10,3]*r[B][76][4,8]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[B,0],p[B,1])]*r[A][1][10,3]*r[B][124][4,8]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[B,1],p[A,0])]*r[A][1][10,3]*r[B][76][4,8]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[B,0],p[A,0])]*r[A][1][10,3]*r[B][124][4,8]
    hv += sum(-1/2*g[dei(p[B,0],p[A,0],p[I,0],p[I,0])]*r[A][1][10,3]*r[B][0][4,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[A,0],p[I,0],p[I,0])]*r[A][1][10,3]*r[B][0][4,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[A,0],p[I,1],p[I,1])]*r[A][1][10,3]*r[B][0][4,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[A,0],p[I,1],p[I,1])]*r[A][1][10,3]*r[B][0][4,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[A,0])]*r[A][1][10,3]*r[B][0][4,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[A,0])]*r[A][1][10,3]*r[B][0][4,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,0],p[B,0],p[I,0])]*r[A][1][10,3]*r[B][0][4,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,0],p[B,0],p[I,1])]*r[A][1][10,3]*r[B][0][4,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[A,0])]*r[A][1][10,3]*r[B][0][4,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[A,0])]*r[A][1][10,3]*r[B][0][4,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1*g[dei(p[B,0],p[A,0],p[C,0],p[C,0])]*r[A][1][10,3]*r[B][0][4,8]*r[C][24][14,14]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[C,1],p[C,1])]*r[A][1][10,3]*r[B][0][4,8]*r[C][39][14,14]
    hv += -1*g[dei(p[B,0],p[A,0],p[C,1],p[C,1])]*r[A][1][10,3]*r[B][0][4,8]*r[C][54][14,14]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,1],p[A,0])]*r[A][1][10,3]*r[B][0][4,8]*r[C][39][14,14]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[B,0],p[C,1])]*r[A][1][10,3]*r[B][0][4,8]*r[C][39][14,14]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,0],p[A,0])]*r[A][1][10,3]*r[B][0][4,8]*r[C][39][14,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B2C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,2),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[B,0],p[A,0]]*r[A][3][8,3]*r[B][2][2,8]
    hv += g[dei(p[A,1],p[A,0],p[B,0],p[A,1])]*r[A][145][8,3]*r[B][2][2,8]
    hv += g[dei(p[A,1],p[A,1],p[B,0],p[A,0])]*r[A][133][8,3]*r[B][2][2,8]
    hv += g[dei(p[B,0],p[B,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][84][2,8]
    hv += g[dei(p[B,1],p[B,1],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][132][2,8]
    hv += sum(-1/2*g[dei(p[B,0],p[A,0],p[I,0],p[I,0])]*r[A][3][8,3]*r[B][2][2,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[A,0],p[I,1],p[I,1])]*r[A][3][8,3]*r[B][2][2,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[A,0])]*r[A][3][8,3]*r[B][2][2,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[A,0])]*r[A][3][8,3]*r[B][2][2,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,0],p[B,0],p[I,0])]*r[A][3][8,3]*r[B][2][2,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,0],p[B,0],p[I,1])]*r[A][3][8,3]*r[B][2][2,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][2][2,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][2][2,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][2][2,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][2][2,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,0],p[A,0],p[C,0],p[C,0])]*r[A][3][8,3]*r[B][2][2,8]*r[C][24][14,14]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[C,1],p[C,1])]*r[A][3][8,3]*r[B][2][2,8]*r[C][54][14,14]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[C,0],p[A,0])]*r[A][3][8,3]*r[B][2][2,8]*r[C][24][14,14]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,1],p[A,0])]*r[A][3][8,3]*r[B][2][2,8]*r[C][54][14,14]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[B,0],p[C,0])]*r[A][3][8,3]*r[B][2][2,8]*r[C][24][14,14]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[B,0],p[C,1])]*r[A][3][8,3]*r[B][2][2,8]*r[C][54][14,14]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][2][2,8]*r[C][24][14,14]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][2][2,8]*r[C][54][14,14]
    hv += -1*g[dei(p[C,1],p[C,1],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][2][2,8]*r[C][39][14,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B3C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,3),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[B,0],p[A,0]]*r[A][3][8,3]*r[B][2][3,8]
    hv += g[dei(p[A,1],p[A,0],p[B,0],p[A,1])]*r[A][145][8,3]*r[B][2][3,8]
    hv += g[dei(p[A,1],p[A,1],p[B,0],p[A,0])]*r[A][133][8,3]*r[B][2][3,8]
    hv += g[dei(p[B,0],p[B,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][84][3,8]
    hv += g[dei(p[B,1],p[B,1],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][132][3,8]
    hv += sum(-1/2*g[dei(p[B,0],p[A,0],p[I,0],p[I,0])]*r[A][3][8,3]*r[B][2][3,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[A,0],p[I,1],p[I,1])]*r[A][3][8,3]*r[B][2][3,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[A,0])]*r[A][3][8,3]*r[B][2][3,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[A,0])]*r[A][3][8,3]*r[B][2][3,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,0],p[B,0],p[I,0])]*r[A][3][8,3]*r[B][2][3,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,0],p[B,0],p[I,1])]*r[A][3][8,3]*r[B][2][3,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][2][3,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][2][3,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][2][3,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][2][3,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,0],p[A,0],p[C,0],p[C,0])]*r[A][3][8,3]*r[B][2][3,8]*r[C][24][14,14]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[C,1],p[C,1])]*r[A][3][8,3]*r[B][2][3,8]*r[C][54][14,14]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[C,0],p[A,0])]*r[A][3][8,3]*r[B][2][3,8]*r[C][24][14,14]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,1],p[A,0])]*r[A][3][8,3]*r[B][2][3,8]*r[C][54][14,14]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[B,0],p[C,0])]*r[A][3][8,3]*r[B][2][3,8]*r[C][24][14,14]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[B,0],p[C,1])]*r[A][3][8,3]*r[B][2][3,8]*r[C][54][14,14]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][2][3,8]*r[C][24][14,14]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][2][3,8]*r[C][54][14,14]
    hv += -1*g[dei(p[C,1],p[C,1],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][2][3,8]*r[C][39][14,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B4C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,4),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[B,0],p[A,1]]*r[A][5][9,3]*r[B][0][4,8]
    hv += -1*g[dei(p[B,0],p[A,0],p[A,0],p[A,1])]*r[A][113][9,3]*r[B][0][4,8]
    hv += -1*g[dei(p[B,0],p[A,1],p[A,0],p[A,0])]*r[A][101][9,3]*r[B][0][4,8]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[B,1],p[B,1])]*r[A][5][9,3]*r[B][76][4,8]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[B,0],p[B,1])]*r[A][5][9,3]*r[B][124][4,8]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[B,1],p[A,1])]*r[A][5][9,3]*r[B][76][4,8]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[B,0],p[A,1])]*r[A][5][9,3]*r[B][124][4,8]
    hv += sum(-1/2*g[dei(p[B,0],p[A,1],p[I,0],p[I,0])]*r[A][5][9,3]*r[B][0][4,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[A,1],p[I,0],p[I,0])]*r[A][5][9,3]*r[B][0][4,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[A,1],p[I,1],p[I,1])]*r[A][5][9,3]*r[B][0][4,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[A,1],p[I,1],p[I,1])]*r[A][5][9,3]*r[B][0][4,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[A,1])]*r[A][5][9,3]*r[B][0][4,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[A,1])]*r[A][5][9,3]*r[B][0][4,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,1],p[B,0],p[I,0])]*r[A][5][9,3]*r[B][0][4,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,1],p[B,0],p[I,1])]*r[A][5][9,3]*r[B][0][4,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[A,1])]*r[A][5][9,3]*r[B][0][4,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[A,1])]*r[A][5][9,3]*r[B][0][4,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1*g[dei(p[B,0],p[A,1],p[C,0],p[C,0])]*r[A][5][9,3]*r[B][0][4,8]*r[C][24][14,14]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[C,1],p[C,1])]*r[A][5][9,3]*r[B][0][4,8]*r[C][39][14,14]
    hv += -1*g[dei(p[B,0],p[A,1],p[C,1],p[C,1])]*r[A][5][9,3]*r[B][0][4,8]*r[C][54][14,14]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,1],p[A,1])]*r[A][5][9,3]*r[B][0][4,8]*r[C][39][14,14]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[B,0],p[C,1])]*r[A][5][9,3]*r[B][0][4,8]*r[C][39][14,14]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,0],p[A,1])]*r[A][5][9,3]*r[B][0][4,8]*r[C][39][14,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B2C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,2),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[B,0],p[A,1]]*r[A][7][7,3]*r[B][2][2,8]
    hv += g[dei(p[A,0],p[A,0],p[B,0],p[A,1])]*r[A][81][7,3]*r[B][2][2,8]
    hv += g[dei(p[A,0],p[A,1],p[B,0],p[A,0])]*r[A][69][7,3]*r[B][2][2,8]
    hv += g[dei(p[B,0],p[B,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][84][2,8]
    hv += g[dei(p[B,1],p[B,1],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][132][2,8]
    hv += sum(-1/2*g[dei(p[B,0],p[A,1],p[I,0],p[I,0])]*r[A][7][7,3]*r[B][2][2,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[A,1],p[I,1],p[I,1])]*r[A][7][7,3]*r[B][2][2,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[A,1])]*r[A][7][7,3]*r[B][2][2,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[A,1])]*r[A][7][7,3]*r[B][2][2,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,1],p[B,0],p[I,0])]*r[A][7][7,3]*r[B][2][2,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,1],p[B,0],p[I,1])]*r[A][7][7,3]*r[B][2][2,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][2][2,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][2][2,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][2][2,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][2][2,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,0],p[A,1],p[C,0],p[C,0])]*r[A][7][7,3]*r[B][2][2,8]*r[C][24][14,14]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[C,1],p[C,1])]*r[A][7][7,3]*r[B][2][2,8]*r[C][54][14,14]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[C,0],p[A,1])]*r[A][7][7,3]*r[B][2][2,8]*r[C][24][14,14]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,1],p[A,1])]*r[A][7][7,3]*r[B][2][2,8]*r[C][54][14,14]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[B,0],p[C,0])]*r[A][7][7,3]*r[B][2][2,8]*r[C][24][14,14]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[B,0],p[C,1])]*r[A][7][7,3]*r[B][2][2,8]*r[C][54][14,14]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][2][2,8]*r[C][24][14,14]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][2][2,8]*r[C][54][14,14]
    hv += -1*g[dei(p[C,1],p[C,1],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][2][2,8]*r[C][39][14,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B3C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,3),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[B,0],p[A,1]]*r[A][7][7,3]*r[B][2][3,8]
    hv += g[dei(p[A,0],p[A,0],p[B,0],p[A,1])]*r[A][81][7,3]*r[B][2][3,8]
    hv += g[dei(p[A,0],p[A,1],p[B,0],p[A,0])]*r[A][69][7,3]*r[B][2][3,8]
    hv += g[dei(p[B,0],p[B,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][84][3,8]
    hv += g[dei(p[B,1],p[B,1],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][132][3,8]
    hv += sum(-1/2*g[dei(p[B,0],p[A,1],p[I,0],p[I,0])]*r[A][7][7,3]*r[B][2][3,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[A,1],p[I,1],p[I,1])]*r[A][7][7,3]*r[B][2][3,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[A,1])]*r[A][7][7,3]*r[B][2][3,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[A,1])]*r[A][7][7,3]*r[B][2][3,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,1],p[B,0],p[I,0])]*r[A][7][7,3]*r[B][2][3,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,1],p[B,0],p[I,1])]*r[A][7][7,3]*r[B][2][3,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][2][3,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][2][3,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][2][3,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][2][3,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,0],p[A,1],p[C,0],p[C,0])]*r[A][7][7,3]*r[B][2][3,8]*r[C][24][14,14]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[C,1],p[C,1])]*r[A][7][7,3]*r[B][2][3,8]*r[C][54][14,14]
    hv += 1/2*g[dei(p[B,0],p[C,0],p[C,0],p[A,1])]*r[A][7][7,3]*r[B][2][3,8]*r[C][24][14,14]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,1],p[A,1])]*r[A][7][7,3]*r[B][2][3,8]*r[C][54][14,14]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[B,0],p[C,0])]*r[A][7][7,3]*r[B][2][3,8]*r[C][24][14,14]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[B,0],p[C,1])]*r[A][7][7,3]*r[B][2][3,8]*r[C][54][14,14]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][2][3,8]*r[C][24][14,14]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][2][3,8]*r[C][54][14,14]
    hv += -1*g[dei(p[C,1],p[C,1],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][2][3,8]*r[C][39][14,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[B,1],p[A,0]]*r[A][3][8,3]*r[B][6][0,8]
    hv += g[dei(p[A,1],p[A,0],p[B,1],p[A,1])]*r[A][145][8,3]*r[B][6][0,8]
    hv += g[dei(p[A,1],p[A,1],p[B,1],p[A,0])]*r[A][133][8,3]*r[B][6][0,8]
    hv += g[dei(p[B,0],p[B,1],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][68][0,8]
    hv += g[dei(p[B,1],p[B,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][148][0,8]
    hv += sum(-1/2*g[dei(p[B,1],p[A,0],p[I,0],p[I,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[A,0],p[I,1],p[I,1])]*r[A][3][8,3]*r[B][6][0,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,0],p[B,1],p[I,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,0],p[B,1],p[I,1])]*r[A][3][8,3]*r[B][6][0,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,1],p[A,0],p[C,0],p[C,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][24][14,14]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[C,1],p[C,1])]*r[A][3][8,3]*r[B][6][0,8]*r[C][54][14,14]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,0],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][24][14,14]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[C,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][54][14,14]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[B,1],p[C,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][24][14,14]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[B,1],p[C,1])]*r[A][3][8,3]*r[B][6][0,8]*r[C][54][14,14]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][24][14,14]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][54][14,14]
    hv += -1*g[dei(p[C,1],p[C,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][39][14,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B1C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,1),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[B,1],p[A,0]]*r[A][3][8,3]*r[B][6][1,8]
    hv += g[dei(p[A,1],p[A,0],p[B,1],p[A,1])]*r[A][145][8,3]*r[B][6][1,8]
    hv += g[dei(p[A,1],p[A,1],p[B,1],p[A,0])]*r[A][133][8,3]*r[B][6][1,8]
    hv += g[dei(p[B,0],p[B,1],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][68][1,8]
    hv += g[dei(p[B,1],p[B,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][148][1,8]
    hv += sum(-1/2*g[dei(p[B,1],p[A,0],p[I,0],p[I,0])]*r[A][3][8,3]*r[B][6][1,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[A,0],p[I,1],p[I,1])]*r[A][3][8,3]*r[B][6][1,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[A,0])]*r[A][3][8,3]*r[B][6][1,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[A,0])]*r[A][3][8,3]*r[B][6][1,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,0],p[B,1],p[I,0])]*r[A][3][8,3]*r[B][6][1,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,0],p[B,1],p[I,1])]*r[A][3][8,3]*r[B][6][1,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][1,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][1,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][1,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][1,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,1],p[A,0],p[C,0],p[C,0])]*r[A][3][8,3]*r[B][6][1,8]*r[C][24][14,14]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[C,1],p[C,1])]*r[A][3][8,3]*r[B][6][1,8]*r[C][54][14,14]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,0],p[A,0])]*r[A][3][8,3]*r[B][6][1,8]*r[C][24][14,14]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[C,1],p[A,0])]*r[A][3][8,3]*r[B][6][1,8]*r[C][54][14,14]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[B,1],p[C,0])]*r[A][3][8,3]*r[B][6][1,8]*r[C][24][14,14]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[B,1],p[C,1])]*r[A][3][8,3]*r[B][6][1,8]*r[C][54][14,14]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][1,8]*r[C][24][14,14]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][1,8]*r[C][54][14,14]
    hv += -1*g[dei(p[C,1],p[C,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][1,8]*r[C][39][14,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[B,1],p[A,1]]*r[A][7][7,3]*r[B][6][0,8]
    hv += g[dei(p[A,0],p[A,0],p[B,1],p[A,1])]*r[A][81][7,3]*r[B][6][0,8]
    hv += g[dei(p[A,0],p[A,1],p[B,1],p[A,0])]*r[A][69][7,3]*r[B][6][0,8]
    hv += g[dei(p[B,0],p[B,1],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][68][0,8]
    hv += g[dei(p[B,1],p[B,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][148][0,8]
    hv += sum(-1/2*g[dei(p[B,1],p[A,1],p[I,0],p[I,0])]*r[A][7][7,3]*r[B][6][0,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[A,1],p[I,1],p[I,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,1],p[B,1],p[I,0])]*r[A][7][7,3]*r[B][6][0,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,1],p[B,1],p[I,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,1],p[A,1],p[C,0],p[C,0])]*r[A][7][7,3]*r[B][6][0,8]*r[C][24][14,14]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[C,1],p[C,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][54][14,14]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,0],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][24][14,14]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[C,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][54][14,14]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[B,1],p[C,0])]*r[A][7][7,3]*r[B][6][0,8]*r[C][24][14,14]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[B,1],p[C,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][54][14,14]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][24][14,14]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][54][14,14]
    hv += -1*g[dei(p[C,1],p[C,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][39][14,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B1C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,1),(C,14)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*h[p[B,1],p[A,1]]*r[A][7][7,3]*r[B][6][1,8]
    hv += g[dei(p[A,0],p[A,0],p[B,1],p[A,1])]*r[A][81][7,3]*r[B][6][1,8]
    hv += g[dei(p[A,0],p[A,1],p[B,1],p[A,0])]*r[A][69][7,3]*r[B][6][1,8]
    hv += g[dei(p[B,0],p[B,1],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][68][1,8]
    hv += g[dei(p[B,1],p[B,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][148][1,8]
    hv += sum(-1/2*g[dei(p[B,1],p[A,1],p[I,0],p[I,0])]*r[A][7][7,3]*r[B][6][1,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[A,1],p[I,1],p[I,1])]*r[A][7][7,3]*r[B][6][1,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[A,1])]*r[A][7][7,3]*r[B][6][1,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[A,1])]*r[A][7][7,3]*r[B][6][1,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[A,1],p[B,1],p[I,0])]*r[A][7][7,3]*r[B][6][1,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[A,1],p[B,1],p[I,1])]*r[A][7][7,3]*r[B][6][1,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][1,8]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][1,8]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][1,8]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][1,8]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,1],p[A,1],p[C,0],p[C,0])]*r[A][7][7,3]*r[B][6][1,8]*r[C][24][14,14]
    hv += -1/2*g[dei(p[B,1],p[A,1],p[C,1],p[C,1])]*r[A][7][7,3]*r[B][6][1,8]*r[C][54][14,14]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[C,0],p[A,1])]*r[A][7][7,3]*r[B][6][1,8]*r[C][24][14,14]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[C,1],p[A,1])]*r[A][7][7,3]*r[B][6][1,8]*r[C][54][14,14]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[B,1],p[C,0])]*r[A][7][7,3]*r[B][6][1,8]*r[C][24][14,14]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[B,1],p[C,1])]*r[A][7][7,3]*r[B][6][1,8]*r[C][54][14,14]
    hv += -1/2*g[dei(p[C,0],p[C,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][1,8]*r[C][24][14,14]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][1,8]*r[C][54][14,14]
    hv += -1*g[dei(p[C,1],p[C,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][1,8]*r[C][39][14,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B7C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,7),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[B,1])]*r[A][9][2,3]*r[B][15][7,8]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[B,0],p[B,1])]*r[A][39][2,3]*r[B][15][7,8]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[A,0])]*r[A][9][2,3]*r[B][15][7,8]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[A,1])]*r[A][39][2,3]*r[B][15][7,8]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[B,1])]*r[A][9][2,3]*r[B][15][7,8]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,1],p[B,1])]*r[A][39][2,3]*r[B][15][7,8]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[A,0])]*r[A][9][2,3]*r[B][15][7,8]
    hv += g[dei(p[B,0],p[B,1],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][15][7,8]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[A,1])]*r[A][39][2,3]*r[B][15][7,8]
    hv += g[dei(p[B,0],p[B,1],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][15][7,8]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B7C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,7),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[B,1])]*r[A][15][0,3]*r[B][15][7,8]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[B,1])]*r[A][33][0,3]*r[B][15][7,8]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[A,1])]*r[A][15][0,3]*r[B][15][7,8]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[A,0])]*r[A][33][0,3]*r[B][15][7,8]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[B,1])]*r[A][15][0,3]*r[B][15][7,8]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[B,1])]*r[A][33][0,3]*r[B][15][7,8]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[A,1])]*r[A][15][0,3]*r[B][15][7,8]
    hv += g[dei(p[B,0],p[B,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][15][7,8]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[A,0])]*r[A][33][0,3]*r[B][15][7,8]
    hv += g[dei(p[B,0],p[B,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][15][7,8]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B7C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,7),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[B,1])]*r[A][15][1,3]*r[B][15][7,8]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[B,1])]*r[A][33][1,3]*r[B][15][7,8]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[A,1])]*r[A][15][1,3]*r[B][15][7,8]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[A,0])]*r[A][33][1,3]*r[B][15][7,8]
    hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[B,1])]*r[A][15][1,3]*r[B][15][7,8]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[B,1])]*r[A][33][1,3]*r[B][15][7,8]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[A,1])]*r[A][15][1,3]*r[B][15][7,8]
    hv += g[dei(p[B,0],p[B,1],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][15][7,8]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[A,0])]*r[A][33][1,3]*r[B][15][7,8]
    hv += g[dei(p[B,0],p[B,1],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][15][7,8]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A4B9C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,4),(B,9),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[A,0],p[B,1],p[B,0],p[A,0])]*r[A][12][4,3]*r[B][27][9,8]
    hv += -1*g[dei(p[A,1],p[B,1],p[B,0],p[A,1])]*r[A][42][4,3]*r[B][27][9,8]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A4B10C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,4),(B,10),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[A,0],p[B,1],p[B,1],p[A,0])]*r[A][12][4,3]*r[B][51][10,8]
    hv += -1*g[dei(p[A,1],p[B,1],p[B,1],p[A,1])]*r[A][42][4,3]*r[B][51][10,8]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6B11C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,6),(B,11),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[B,0],p[A,0],p[B,0],p[A,1])]*r[A][46][6,3]*r[B][11][11,8]
    hv += g[dei(p[B,0],p[A,1],p[B,0],p[A,0])]*r[A][28][6,3]*r[B][11][11,8]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6B12C14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,6),(B,12),(C,14)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[B,0],p[A,0],p[B,1],p[A,1])]*r[A][46][6,3]*r[B][17][12,8]
    hv += g[dei(p[B,0],p[A,1],p[B,1],p[A,0])]*r[A][28][6,3]*r[B][17][12,8]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,8)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[A,0],p[C,0]]*r[A][2][13,3]*r[C][3][0,14]
    hv += g[dei(p[A,0],p[A,0],p[A,0],p[C,0])]*r[A][64][13,3]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[A,1],p[C,0])]*r[A][118][13,3]*r[C][3][0,14]
    hv += g[dei(p[A,0],p[A,1],p[A,1],p[C,0])]*r[A][84][13,3]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[A,0],p[C,0])]*r[A][166][13,3]*r[C][3][0,14]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[A,1],p[A,1])]*r[A][118][13,3]*r[C][3][0,14]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[A,0],p[A,1])]*r[A][166][13,3]*r[C][3][0,14]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[C,1])]*r[A][2][13,3]*r[C][179][0,14]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[C,0])]*r[A][2][13,3]*r[C][167][0,14]
    hv += g[dei(p[C,0],p[C,1],p[A,0],p[C,1])]*r[A][2][13,3]*r[C][85][0,14]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[C,1])]*r[A][2][13,3]*r[C][179][0,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][167][0,14]
    hv += g[dei(p[C,1],p[C,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][133][0,14]
    hv += sum(-1/2*g[dei(p[A,0],p[C,0],p[I,0],p[I,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[C,0],p[I,1],p[I,1])]*r[A][2][13,3]*r[C][3][0,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[I,0],p[I,0],p[C,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[I,1],p[I,1],p[C,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,0],p[A,0],p[I,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,0],p[A,0],p[I,1])]*r[A][2][13,3]*r[C][3][0,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1*g[dei(p[B,1],p[B,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][39][8,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B8C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,8),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[A,0],p[C,0]]*r[A][2][13,3]*r[C][3][1,14]
    hv += g[dei(p[A,0],p[A,0],p[A,0],p[C,0])]*r[A][64][13,3]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[A,1],p[C,0])]*r[A][118][13,3]*r[C][3][1,14]
    hv += g[dei(p[A,0],p[A,1],p[A,1],p[C,0])]*r[A][84][13,3]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[A,0],p[C,0])]*r[A][166][13,3]*r[C][3][1,14]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[A,1],p[A,1])]*r[A][118][13,3]*r[C][3][1,14]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[A,0],p[A,1])]*r[A][166][13,3]*r[C][3][1,14]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,1],p[C,1])]*r[A][2][13,3]*r[C][179][1,14]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,1],p[C,0])]*r[A][2][13,3]*r[C][167][1,14]
    hv += g[dei(p[C,0],p[C,1],p[A,0],p[C,1])]*r[A][2][13,3]*r[C][85][1,14]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,0],p[C,1])]*r[A][2][13,3]*r[C][179][1,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][167][1,14]
    hv += g[dei(p[C,1],p[C,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][133][1,14]
    hv += sum(-1/2*g[dei(p[A,0],p[C,0],p[I,0],p[I,0])]*r[A][2][13,3]*r[C][3][1,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[C,0],p[I,1],p[I,1])]*r[A][2][13,3]*r[C][3][1,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[I,0],p[I,0],p[C,0])]*r[A][2][13,3]*r[C][3][1,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[I,1],p[I,1],p[C,0])]*r[A][2][13,3]*r[C][3][1,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,0],p[A,0],p[I,0])]*r[A][2][13,3]*r[C][3][1,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,0],p[A,0],p[I,1])]*r[A][2][13,3]*r[C][3][1,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][3][1,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][3][1,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][3][1,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][3][1,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1*g[dei(p[B,1],p[B,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][39][8,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B8C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,8),(C,5)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[A,0],p[C,1]]*r[A][0][11,3]*r[C][5][5,14]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[A,1],p[C,1])]*r[A][76][11,3]*r[C][5][5,14]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[A,0],p[C,1])]*r[A][124][11,3]*r[C][5][5,14]
    hv += -1*g[dei(p[A,0],p[C,1],p[A,0],p[A,0])]*r[A][66][11,3]*r[C][5][5,14]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[A,1],p[A,1])]*r[A][76][11,3]*r[C][5][5,14]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[A,0],p[A,1])]*r[A][124][11,3]*r[C][5][5,14]
    hv += -1*g[dei(p[A,1],p[C,1],p[A,0],p[A,1])]*r[A][134][11,3]*r[C][5][5,14]
    hv += -1*g[dei(p[A,0],p[C,1],p[C,0],p[C,0])]*r[A][0][11,3]*r[C][101][5,14]
    hv += -1*g[dei(p[A,0],p[C,1],p[C,1],p[C,1])]*r[A][0][11,3]*r[C][181][5,14]
    hv += sum(-1/2*g[dei(p[A,0],p[C,1],p[I,0],p[I,0])]*r[A][0][11,3]*r[C][5][5,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[A,0],p[C,1],p[I,0],p[I,0])]*r[A][0][11,3]*r[C][5][5,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[C,1],p[I,1],p[I,1])]*r[A][0][11,3]*r[C][5][5,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[A,0],p[C,1],p[I,1],p[I,1])]*r[A][0][11,3]*r[C][5][5,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[I,0],p[I,0],p[C,1])]*r[A][0][11,3]*r[C][5][5,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[I,1],p[I,1],p[C,1])]*r[A][0][11,3]*r[C][5][5,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,1],p[A,0],p[I,0])]*r[A][0][11,3]*r[C][5][5,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,1],p[A,0],p[I,1])]*r[A][0][11,3]*r[C][5][5,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,0],p[C,1])]*r[A][0][11,3]*r[C][5][5,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,0],p[C,1])]*r[A][0][11,3]*r[C][5][5,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[B,1],p[B,1],p[C,1])]*r[A][0][11,3]*r[B][39][8,8]*r[C][5][5,14]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[B,1],p[B,1])]*r[A][0][11,3]*r[B][39][8,8]*r[C][5][5,14]
    hv += -1/2*g[dei(p[B,1],p[B,1],p[A,0],p[C,1])]*r[A][0][11,3]*r[B][39][8,8]*r[C][5][5,14]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[A,0],p[B,1])]*r[A][0][11,3]*r[B][39][8,8]*r[C][5][5,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B8C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,8),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[A,0],p[C,1]]*r[A][2][13,3]*r[C][7][2,14]
    hv += g[dei(p[A,0],p[A,0],p[A,0],p[C,1])]*r[A][64][13,3]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[A,1],p[C,1])]*r[A][118][13,3]*r[C][7][2,14]
    hv += g[dei(p[A,0],p[A,1],p[A,1],p[C,1])]*r[A][84][13,3]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[A,0],p[C,1])]*r[A][166][13,3]*r[C][7][2,14]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[A,1],p[A,1])]*r[A][118][13,3]*r[C][7][2,14]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[A,0],p[A,1])]*r[A][166][13,3]*r[C][7][2,14]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[C,1])]*r[A][2][13,3]*r[C][115][2,14]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[C,0])]*r[A][2][13,3]*r[C][103][2,14]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[C,1])]*r[A][2][13,3]*r[C][115][2,14]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][103][2,14]
    hv += g[dei(p[C,0],p[C,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][69][2,14]
    hv += g[dei(p[C,1],p[C,1],p[A,0],p[C,1])]*r[A][2][13,3]*r[C][149][2,14]
    hv += sum(-1/2*g[dei(p[A,0],p[C,1],p[I,0],p[I,0])]*r[A][2][13,3]*r[C][7][2,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[C,1],p[I,1],p[I,1])]*r[A][2][13,3]*r[C][7][2,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[I,0],p[I,0],p[C,1])]*r[A][2][13,3]*r[C][7][2,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[I,1],p[I,1],p[C,1])]*r[A][2][13,3]*r[C][7][2,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,1],p[A,0],p[I,0])]*r[A][2][13,3]*r[C][7][2,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,1],p[A,0],p[I,1])]*r[A][2][13,3]*r[C][7][2,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,0],p[C,1])]*r[A][2][13,3]*r[C][7][2,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[A,0],p[C,1])]*r[A][2][13,3]*r[C][7][2,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,0],p[C,1])]*r[A][2][13,3]*r[C][7][2,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[A,0],p[C,1])]*r[A][2][13,3]*r[C][7][2,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1*g[dei(p[B,1],p[B,1],p[A,0],p[C,1])]*r[A][2][13,3]*r[B][39][8,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B8C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,8),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[A,0],p[C,1]]*r[A][2][13,3]*r[C][7][3,14]
    hv += g[dei(p[A,0],p[A,0],p[A,0],p[C,1])]*r[A][64][13,3]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,0],p[A,1],p[A,1],p[C,1])]*r[A][118][13,3]*r[C][7][3,14]
    hv += g[dei(p[A,0],p[A,1],p[A,1],p[C,1])]*r[A][84][13,3]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[A,0],p[C,1])]*r[A][166][13,3]*r[C][7][3,14]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[A,1],p[A,1])]*r[A][118][13,3]*r[C][7][3,14]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[A,0],p[A,1])]*r[A][166][13,3]*r[C][7][3,14]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[C,0],p[C,1])]*r[A][2][13,3]*r[C][115][3,14]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[C,0])]*r[A][2][13,3]*r[C][103][3,14]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,0],p[C,1])]*r[A][2][13,3]*r[C][115][3,14]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][103][3,14]
    hv += g[dei(p[C,0],p[C,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][69][3,14]
    hv += g[dei(p[C,1],p[C,1],p[A,0],p[C,1])]*r[A][2][13,3]*r[C][149][3,14]
    hv += sum(-1/2*g[dei(p[A,0],p[C,1],p[I,0],p[I,0])]*r[A][2][13,3]*r[C][7][3,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,0],p[C,1],p[I,1],p[I,1])]*r[A][2][13,3]*r[C][7][3,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[I,0],p[I,0],p[C,1])]*r[A][2][13,3]*r[C][7][3,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,0],p[I,1],p[I,1],p[C,1])]*r[A][2][13,3]*r[C][7][3,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,1],p[A,0],p[I,0])]*r[A][2][13,3]*r[C][7][3,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,1],p[A,0],p[I,1])]*r[A][2][13,3]*r[C][7][3,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,0],p[C,1])]*r[A][2][13,3]*r[C][7][3,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[A,0],p[C,1])]*r[A][2][13,3]*r[C][7][3,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,0],p[C,1])]*r[A][2][13,3]*r[C][7][3,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[A,0],p[C,1])]*r[A][2][13,3]*r[C][7][3,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1*g[dei(p[B,1],p[B,1],p[A,0],p[C,1])]*r[A][2][13,3]*r[B][39][8,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,8)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[A,1],p[C,0]]*r[A][6][14,3]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[A,1],p[C,0])]*r[A][114][14,3]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[A,0],p[C,0])]*r[A][162][14,3]*r[C][3][0,14]
    hv += g[dei(p[A,1],p[A,0],p[A,0],p[C,0])]*r[A][128][14,3]*r[C][3][0,14]
    hv += g[dei(p[A,1],p[A,1],p[A,1],p[C,0])]*r[A][148][14,3]*r[C][3][0,14]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[A,1],p[A,0])]*r[A][114][14,3]*r[C][3][0,14]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[A,0],p[A,0])]*r[A][162][14,3]*r[C][3][0,14]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[C,1])]*r[A][6][14,3]*r[C][179][0,14]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[C,0])]*r[A][6][14,3]*r[C][167][0,14]
    hv += g[dei(p[C,0],p[C,1],p[A,1],p[C,1])]*r[A][6][14,3]*r[C][85][0,14]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[C,1])]*r[A][6][14,3]*r[C][179][0,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][167][0,14]
    hv += g[dei(p[C,1],p[C,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][133][0,14]
    hv += sum(-1/2*g[dei(p[A,1],p[C,0],p[I,0],p[I,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[C,0],p[I,1],p[I,1])]*r[A][6][14,3]*r[C][3][0,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[I,0],p[I,0],p[C,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[I,1],p[I,1],p[C,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,0],p[A,1],p[I,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,0],p[A,1],p[I,1])]*r[A][6][14,3]*r[C][3][0,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1*g[dei(p[B,1],p[B,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][39][8,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B8C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,8),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[A,1],p[C,0]]*r[A][6][14,3]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[A,1],p[C,0])]*r[A][114][14,3]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[A,0],p[C,0])]*r[A][162][14,3]*r[C][3][1,14]
    hv += g[dei(p[A,1],p[A,0],p[A,0],p[C,0])]*r[A][128][14,3]*r[C][3][1,14]
    hv += g[dei(p[A,1],p[A,1],p[A,1],p[C,0])]*r[A][148][14,3]*r[C][3][1,14]
    hv += -1/2*g[dei(p[A,0],p[C,0],p[A,1],p[A,0])]*r[A][114][14,3]*r[C][3][1,14]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[A,0],p[A,0])]*r[A][162][14,3]*r[C][3][1,14]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,1],p[C,1])]*r[A][6][14,3]*r[C][179][1,14]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,1],p[C,0])]*r[A][6][14,3]*r[C][167][1,14]
    hv += g[dei(p[C,0],p[C,1],p[A,1],p[C,1])]*r[A][6][14,3]*r[C][85][1,14]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[A,1],p[C,1])]*r[A][6][14,3]*r[C][179][1,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][167][1,14]
    hv += g[dei(p[C,1],p[C,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][133][1,14]
    hv += sum(-1/2*g[dei(p[A,1],p[C,0],p[I,0],p[I,0])]*r[A][6][14,3]*r[C][3][1,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[C,0],p[I,1],p[I,1])]*r[A][6][14,3]*r[C][3][1,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[I,0],p[I,0],p[C,0])]*r[A][6][14,3]*r[C][3][1,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[I,1],p[I,1],p[C,0])]*r[A][6][14,3]*r[C][3][1,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,0],p[A,1],p[I,0])]*r[A][6][14,3]*r[C][3][1,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,0],p[A,1],p[I,1])]*r[A][6][14,3]*r[C][3][1,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][3][1,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][3][1,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][3][1,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][3][1,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1*g[dei(p[B,1],p[B,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][39][8,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B8C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,8),(C,5)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[A,1],p[C,1]]*r[A][4][12,3]*r[C][5][5,14]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[A,1],p[C,1])]*r[A][72][12,3]*r[C][5][5,14]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[A,0],p[C,1])]*r[A][120][12,3]*r[C][5][5,14]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[A,1],p[A,0])]*r[A][72][12,3]*r[C][5][5,14]
    hv += -1*g[dei(p[A,0],p[C,1],p[A,1],p[A,0])]*r[A][82][12,3]*r[C][5][5,14]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[A,0],p[A,0])]*r[A][120][12,3]*r[C][5][5,14]
    hv += -1*g[dei(p[A,1],p[C,1],p[A,1],p[A,1])]*r[A][150][12,3]*r[C][5][5,14]
    hv += -1*g[dei(p[A,1],p[C,1],p[C,0],p[C,0])]*r[A][4][12,3]*r[C][101][5,14]
    hv += -1*g[dei(p[A,1],p[C,1],p[C,1],p[C,1])]*r[A][4][12,3]*r[C][181][5,14]
    hv += sum(-1/2*g[dei(p[A,1],p[C,1],p[I,0],p[I,0])]*r[A][4][12,3]*r[C][5][5,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[A,1],p[C,1],p[I,0],p[I,0])]*r[A][4][12,3]*r[C][5][5,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[C,1],p[I,1],p[I,1])]*r[A][4][12,3]*r[C][5][5,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[A,1],p[C,1],p[I,1],p[I,1])]*r[A][4][12,3]*r[C][5][5,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[I,0],p[I,0],p[C,1])]*r[A][4][12,3]*r[C][5][5,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[I,1],p[I,1],p[C,1])]*r[A][4][12,3]*r[C][5][5,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,1],p[A,1],p[I,0])]*r[A][4][12,3]*r[C][5][5,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,1],p[A,1],p[I,1])]*r[A][4][12,3]*r[C][5][5,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,1],p[C,1])]*r[A][4][12,3]*r[C][5][5,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,1],p[C,1])]*r[A][4][12,3]*r[C][5][5,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,1],p[B,1],p[B,1],p[C,1])]*r[A][4][12,3]*r[B][39][8,8]*r[C][5][5,14]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[B,1],p[B,1])]*r[A][4][12,3]*r[B][39][8,8]*r[C][5][5,14]
    hv += -1/2*g[dei(p[B,1],p[B,1],p[A,1],p[C,1])]*r[A][4][12,3]*r[B][39][8,8]*r[C][5][5,14]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[A,1],p[B,1])]*r[A][4][12,3]*r[B][39][8,8]*r[C][5][5,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B8C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,8),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[A,1],p[C,1]]*r[A][6][14,3]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[A,1],p[C,1])]*r[A][114][14,3]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[A,0],p[C,1])]*r[A][162][14,3]*r[C][7][2,14]
    hv += g[dei(p[A,1],p[A,0],p[A,0],p[C,1])]*r[A][128][14,3]*r[C][7][2,14]
    hv += g[dei(p[A,1],p[A,1],p[A,1],p[C,1])]*r[A][148][14,3]*r[C][7][2,14]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[A,1],p[A,0])]*r[A][114][14,3]*r[C][7][2,14]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[A,0],p[A,0])]*r[A][162][14,3]*r[C][7][2,14]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[C,1])]*r[A][6][14,3]*r[C][115][2,14]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[C,0])]*r[A][6][14,3]*r[C][103][2,14]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[C,1])]*r[A][6][14,3]*r[C][115][2,14]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][103][2,14]
    hv += g[dei(p[C,0],p[C,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][69][2,14]
    hv += g[dei(p[C,1],p[C,1],p[A,1],p[C,1])]*r[A][6][14,3]*r[C][149][2,14]
    hv += sum(-1/2*g[dei(p[A,1],p[C,1],p[I,0],p[I,0])]*r[A][6][14,3]*r[C][7][2,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[C,1],p[I,1],p[I,1])]*r[A][6][14,3]*r[C][7][2,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[I,0],p[I,0],p[C,1])]*r[A][6][14,3]*r[C][7][2,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[I,1],p[I,1],p[C,1])]*r[A][6][14,3]*r[C][7][2,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,1],p[A,1],p[I,0])]*r[A][6][14,3]*r[C][7][2,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,1],p[A,1],p[I,1])]*r[A][6][14,3]*r[C][7][2,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,1],p[C,1])]*r[A][6][14,3]*r[C][7][2,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[A,1],p[C,1])]*r[A][6][14,3]*r[C][7][2,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,1],p[C,1])]*r[A][6][14,3]*r[C][7][2,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[A,1],p[C,1])]*r[A][6][14,3]*r[C][7][2,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1*g[dei(p[B,1],p[B,1],p[A,1],p[C,1])]*r[A][6][14,3]*r[B][39][8,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B8C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,8),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*h[p[A,1],p[C,1]]*r[A][6][14,3]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[A,1],p[C,1])]*r[A][114][14,3]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[A,0],p[C,1])]*r[A][162][14,3]*r[C][7][3,14]
    hv += g[dei(p[A,1],p[A,0],p[A,0],p[C,1])]*r[A][128][14,3]*r[C][7][3,14]
    hv += g[dei(p[A,1],p[A,1],p[A,1],p[C,1])]*r[A][148][14,3]*r[C][7][3,14]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[A,1],p[A,0])]*r[A][114][14,3]*r[C][7][3,14]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[A,0],p[A,0])]*r[A][162][14,3]*r[C][7][3,14]
    hv += -1/2*g[dei(p[A,1],p[C,0],p[C,0],p[C,1])]*r[A][6][14,3]*r[C][115][3,14]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[C,0])]*r[A][6][14,3]*r[C][103][3,14]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[A,1],p[C,1])]*r[A][6][14,3]*r[C][115][3,14]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][103][3,14]
    hv += g[dei(p[C,0],p[C,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][69][3,14]
    hv += g[dei(p[C,1],p[C,1],p[A,1],p[C,1])]*r[A][6][14,3]*r[C][149][3,14]
    hv += sum(-1/2*g[dei(p[A,1],p[C,1],p[I,0],p[I,0])]*r[A][6][14,3]*r[C][7][3,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[A,1],p[C,1],p[I,1],p[I,1])]*r[A][6][14,3]*r[C][7][3,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[I,0],p[I,0],p[C,1])]*r[A][6][14,3]*r[C][7][3,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[A,1],p[I,1],p[I,1],p[C,1])]*r[A][6][14,3]*r[C][7][3,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,1],p[A,1],p[I,0])]*r[A][6][14,3]*r[C][7][3,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,1],p[A,1],p[I,1])]*r[A][6][14,3]*r[C][7][3,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,1],p[C,1])]*r[A][6][14,3]*r[C][7][3,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[A,1],p[C,1])]*r[A][6][14,3]*r[C][7][3,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,1],p[C,1])]*r[A][6][14,3]*r[C][7][3,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[A,1],p[C,1])]*r[A][6][14,3]*r[C][7][3,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1*g[dei(p[B,1],p[B,1],p[A,1],p[C,1])]*r[A][6][14,3]*r[B][39][8,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B8C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,8),(C,15)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += h[p[C,0],p[A,0]]*r[A][1][10,3]*r[C][0][15,14]
    hv += g[dei(p[C,0],p[A,0],p[A,1],p[A,1])]*r[A][177][10,3]*r[C][0][15,14]
    hv += g[dei(p[C,0],p[A,1],p[A,1],p[A,0])]*r[A][165][10,3]*r[C][0][15,14]
    hv += g[dei(p[C,0],p[A,0],p[C,0],p[C,0])]*r[A][1][10,3]*r[C][66][15,14]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[C,1],p[C,1])]*r[A][1][10,3]*r[C][76][15,14]
    hv += g[dei(p[C,0],p[A,0],p[C,1],p[C,1])]*r[A][1][10,3]*r[C][86][15,14]
    hv += 1/2*g[dei(p[C,1],p[A,0],p[C,0],p[C,1])]*r[A][1][10,3]*r[C][124][15,14]
    hv += -1/2*g[dei(p[C,0],p[C,1],p[C,1],p[A,0])]*r[A][1][10,3]*r[C][76][15,14]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[C,0],p[A,0])]*r[A][1][10,3]*r[C][124][15,14]
    hv += sum(1/2*g[dei(p[C,0],p[A,0],p[I,0],p[I,0])]*r[A][1][10,3]*r[C][0][15,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[C,0],p[A,0],p[I,0],p[I,0])]*r[A][1][10,3]*r[C][0][15,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[A,0],p[I,1],p[I,1])]*r[A][1][10,3]*r[C][0][15,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[C,0],p[A,0],p[I,1],p[I,1])]*r[A][1][10,3]*r[C][0][15,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,0],p[I,0],p[A,0])]*r[A][1][10,3]*r[C][0][15,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,1],p[I,1],p[A,0])]*r[A][1][10,3]*r[C][0][15,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[C,0],p[I,0])]*r[A][1][10,3]*r[C][0][15,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[C,0],p[I,1])]*r[A][1][10,3]*r[C][0][15,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,0],p[A,0])]*r[A][1][10,3]*r[C][0][15,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,0],p[A,0])]*r[A][1][10,3]*r[C][0][15,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,1],p[A,0],p[C,0],p[B,1])]*r[A][1][10,3]*r[B][39][8,8]*r[C][0][15,14]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,0],p[A,0])]*r[A][1][10,3]*r[B][39][8,8]*r[C][0][15,14]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[B,1],p[B,1])]*r[A][1][10,3]*r[B][39][8,8]*r[C][0][15,14]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,1],p[A,0])]*r[A][1][10,3]*r[B][39][8,8]*r[C][0][15,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B8C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,8),(C,15)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += h[p[C,0],p[A,1]]*r[A][5][9,3]*r[C][0][15,14]
    hv += g[dei(p[C,0],p[A,0],p[A,0],p[A,1])]*r[A][113][9,3]*r[C][0][15,14]
    hv += g[dei(p[C,0],p[A,1],p[A,0],p[A,0])]*r[A][101][9,3]*r[C][0][15,14]
    hv += g[dei(p[C,0],p[A,1],p[C,0],p[C,0])]*r[A][5][9,3]*r[C][66][15,14]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[C,1],p[C,1])]*r[A][5][9,3]*r[C][76][15,14]
    hv += g[dei(p[C,0],p[A,1],p[C,1],p[C,1])]*r[A][5][9,3]*r[C][86][15,14]
    hv += 1/2*g[dei(p[C,1],p[A,1],p[C,0],p[C,1])]*r[A][5][9,3]*r[C][124][15,14]
    hv += -1/2*g[dei(p[C,0],p[C,1],p[C,1],p[A,1])]*r[A][5][9,3]*r[C][76][15,14]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[C,0],p[A,1])]*r[A][5][9,3]*r[C][124][15,14]
    hv += sum(1/2*g[dei(p[C,0],p[A,1],p[I,0],p[I,0])]*r[A][5][9,3]*r[C][0][15,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[C,0],p[A,1],p[I,0],p[I,0])]*r[A][5][9,3]*r[C][0][15,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[A,1],p[I,1],p[I,1])]*r[A][5][9,3]*r[C][0][15,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[C,0],p[A,1],p[I,1],p[I,1])]*r[A][5][9,3]*r[C][0][15,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,0],p[I,0],p[A,1])]*r[A][5][9,3]*r[C][0][15,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,1],p[I,1],p[A,1])]*r[A][5][9,3]*r[C][0][15,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[A,1],p[C,0],p[I,0])]*r[A][5][9,3]*r[C][0][15,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[A,1],p[C,0],p[I,1])]*r[A][5][9,3]*r[C][0][15,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,0],p[A,1])]*r[A][5][9,3]*r[C][0][15,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,0],p[A,1])]*r[A][5][9,3]*r[C][0][15,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[B,1],p[A,1],p[C,0],p[B,1])]*r[A][5][9,3]*r[B][39][8,8]*r[C][0][15,14]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[C,0],p[A,1])]*r[A][5][9,3]*r[B][39][8,8]*r[C][0][15,14]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[B,1],p[B,1])]*r[A][5][9,3]*r[B][39][8,8]*r[C][0][15,14]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,1],p[A,1])]*r[A][5][9,3]*r[B][39][8,8]*r[C][0][15,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A15B8C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,15),(B,8),(C,10)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[A,0],p[C,1],p[A,1],p[C,0])]*r[A][17][15,3]*r[C][28][10,14]
    hv += g[dei(p[A,1],p[C,1],p[A,0],p[C,0])]*r[A][35][15,3]*r[C][28][10,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A15B8C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,15),(B,8),(C,9)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[A,0],p[C,1],p[A,1],p[C,1])]*r[A][17][15,3]*r[C][52][9,14]
    hv += g[dei(p[A,1],p[C,1],p[A,0],p[C,1])]*r[A][35][15,3]*r[C][52][9,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B8C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,8),(C,13)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[C,1])]*r[A][9][2,3]*r[C][15][13,14]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[C,1])]*r[A][39][2,3]*r[C][15][13,14]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[A,0])]*r[A][9][2,3]*r[C][15][13,14]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[A,1])]*r[A][39][2,3]*r[C][15][13,14]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[C,1])]*r[A][9][2,3]*r[C][15][13,14]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[C,1])]*r[A][39][2,3]*r[C][15][13,14]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[A,0])]*r[A][9][2,3]*r[C][15][13,14]
    hv += g[dei(p[C,0],p[C,1],p[A,0],p[A,0])]*r[A][24][2,3]*r[C][15][13,14]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[A,1])]*r[A][39][2,3]*r[C][15][13,14]
    hv += g[dei(p[C,0],p[C,1],p[A,1],p[A,1])]*r[A][54][2,3]*r[C][15][13,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B8C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,8),(C,13)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,0],p[C,1])]*r[A][15][0,3]*r[C][15][13,14]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,0],p[C,1])]*r[A][33][0,3]*r[C][15][13,14]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[A,1])]*r[A][15][0,3]*r[C][15][13,14]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[A,0])]*r[A][33][0,3]*r[C][15][13,14]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,0],p[C,1])]*r[A][15][0,3]*r[C][15][13,14]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,1],p[C,1])]*r[A][33][0,3]*r[C][15][13,14]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[A,1])]*r[A][15][0,3]*r[C][15][13,14]
    hv += g[dei(p[C,0],p[C,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[C][15][13,14]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[A,0])]*r[A][33][0,3]*r[C][15][13,14]
    hv += g[dei(p[C,0],p[C,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[C][15][13,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B8C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,8),(C,13)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,0],p[C,1])]*r[A][15][1,3]*r[C][15][13,14]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,0],p[C,1])]*r[A][33][1,3]*r[C][15][13,14]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[A,1])]*r[A][15][1,3]*r[C][15][13,14]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[A,0])]*r[A][33][1,3]*r[C][15][13,14]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,0],p[C,1])]*r[A][15][1,3]*r[C][15][13,14]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,1],p[C,1])]*r[A][33][1,3]*r[C][15][13,14]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[A,1])]*r[A][15][1,3]*r[C][15][13,14]
    hv += g[dei(p[C,0],p[C,1],p[A,0],p[A,1])]*r[A][30][1,3]*r[C][15][13,14]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[A,0])]*r[A][33][1,3]*r[C][15][13,14]
    hv += g[dei(p[C,0],p[C,1],p[A,1],p[A,0])]*r[A][48][1,3]*r[C][15][13,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5B8C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,5),(B,8),(C,12)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[C,0],p[A,0],p[A,0],p[C,0])]*r[A][21][5,3]*r[C][12][12,14]
    hv += -1*g[dei(p[C,0],p[A,1],p[A,1],p[C,0])]*r[A][51][5,3]*r[C][12][12,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5B8C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,5),(B,8),(C,11)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[C,0],p[A,0],p[A,0],p[C,1])]*r[A][21][5,3]*r[C][18][11,14]
    hv += -1*g[dei(p[C,0],p[A,1],p[A,1],p[C,1])]*r[A][51][5,3]*r[C][18][11,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,2)]))
    hv = 0.0
    
    hv += -1*h[p[B,0],p[C,0]]*r[B][2][2,8]*r[C][3][0,14]
    hv += g[dei(p[B,0],p[B,1],p[B,1],p[C,0])]*r[B][84][2,8]*r[C][3][0,14]
    hv += g[dei(p[B,1],p[B,1],p[B,0],p[C,0])]*r[B][132][2,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,1],p[C,1])]*r[B][2][2,8]*r[C][179][0,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,1],p[C,0])]*r[B][2][2,8]*r[C][167][0,14]
    hv += g[dei(p[C,0],p[C,1],p[B,0],p[C,1])]*r[B][2][2,8]*r[C][85][0,14]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,0],p[C,1])]*r[B][2][2,8]*r[C][179][0,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,0],p[C,0])]*r[B][2][2,8]*r[C][167][0,14]
    hv += g[dei(p[C,1],p[C,1],p[B,0],p[C,0])]*r[B][2][2,8]*r[C][133][0,14]
    hv += sum(-1/2*g[dei(p[B,0],p[C,0],p[I,0],p[I,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[C,0],p[I,1],p[I,1])]*r[B][2][2,8]*r[C][3][0,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[C,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[C,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,0],p[B,0],p[I,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,0],p[B,0],p[I,1])]*r[B][2][2,8]*r[C][3][0,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[C,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,0],p[C,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[C,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,0],p[C,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][24][3,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][9][3,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][54][3,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][39][3,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,0])]*r[A][24][3,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,1])]*r[A][54][3,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,0])]*r[A][24][3,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,0])]*r[A][54][3,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][2][2,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B2C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,2),(C,1)]))
    hv = 0.0
    
    hv += -1*h[p[B,0],p[C,0]]*r[B][2][2,8]*r[C][3][1,14]
    hv += g[dei(p[B,0],p[B,1],p[B,1],p[C,0])]*r[B][84][2,8]*r[C][3][1,14]
    hv += g[dei(p[B,1],p[B,1],p[B,0],p[C,0])]*r[B][132][2,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,1],p[C,1])]*r[B][2][2,8]*r[C][179][1,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,1],p[C,0])]*r[B][2][2,8]*r[C][167][1,14]
    hv += g[dei(p[C,0],p[C,1],p[B,0],p[C,1])]*r[B][2][2,8]*r[C][85][1,14]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,0],p[C,1])]*r[B][2][2,8]*r[C][179][1,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,0],p[C,0])]*r[B][2][2,8]*r[C][167][1,14]
    hv += g[dei(p[C,1],p[C,1],p[B,0],p[C,0])]*r[B][2][2,8]*r[C][133][1,14]
    hv += sum(-1/2*g[dei(p[B,0],p[C,0],p[I,0],p[I,0])]*r[B][2][2,8]*r[C][3][1,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[C,0],p[I,1],p[I,1])]*r[B][2][2,8]*r[C][3][1,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[C,0])]*r[B][2][2,8]*r[C][3][1,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[C,0])]*r[B][2][2,8]*r[C][3][1,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,0],p[B,0],p[I,0])]*r[B][2][2,8]*r[C][3][1,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,0],p[B,0],p[I,1])]*r[B][2][2,8]*r[C][3][1,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[C,0])]*r[B][2][2,8]*r[C][3][1,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,0],p[C,0])]*r[B][2][2,8]*r[C][3][1,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[C,0])]*r[B][2][2,8]*r[C][3][1,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,0],p[C,0])]*r[B][2][2,8]*r[C][3][1,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][24][3,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][9][3,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][54][3,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][39][3,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,0])]*r[A][24][3,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,1])]*r[A][54][3,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,0])]*r[A][24][3,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,0])]*r[A][54][3,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][2][2,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,3)]))
    hv = 0.0
    
    hv += -1*h[p[B,0],p[C,0]]*r[B][2][3,8]*r[C][3][0,14]
    hv += g[dei(p[B,0],p[B,1],p[B,1],p[C,0])]*r[B][84][3,8]*r[C][3][0,14]
    hv += g[dei(p[B,1],p[B,1],p[B,0],p[C,0])]*r[B][132][3,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,1],p[C,1])]*r[B][2][3,8]*r[C][179][0,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,1],p[C,0])]*r[B][2][3,8]*r[C][167][0,14]
    hv += g[dei(p[C,0],p[C,1],p[B,0],p[C,1])]*r[B][2][3,8]*r[C][85][0,14]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,0],p[C,1])]*r[B][2][3,8]*r[C][179][0,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,0],p[C,0])]*r[B][2][3,8]*r[C][167][0,14]
    hv += g[dei(p[C,1],p[C,1],p[B,0],p[C,0])]*r[B][2][3,8]*r[C][133][0,14]
    hv += sum(-1/2*g[dei(p[B,0],p[C,0],p[I,0],p[I,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[C,0],p[I,1],p[I,1])]*r[B][2][3,8]*r[C][3][0,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[C,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[C,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,0],p[B,0],p[I,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,0],p[B,0],p[I,1])]*r[B][2][3,8]*r[C][3][0,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[C,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,0],p[C,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[C,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,0],p[C,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][24][3,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][9][3,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][54][3,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][39][3,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,0])]*r[A][24][3,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,1])]*r[A][54][3,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,0])]*r[A][24][3,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,0])]*r[A][54][3,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][2][3,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B3C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,3),(C,1)]))
    hv = 0.0
    
    hv += -1*h[p[B,0],p[C,0]]*r[B][2][3,8]*r[C][3][1,14]
    hv += g[dei(p[B,0],p[B,1],p[B,1],p[C,0])]*r[B][84][3,8]*r[C][3][1,14]
    hv += g[dei(p[B,1],p[B,1],p[B,0],p[C,0])]*r[B][132][3,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,1],p[C,1])]*r[B][2][3,8]*r[C][179][1,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,1],p[C,0])]*r[B][2][3,8]*r[C][167][1,14]
    hv += g[dei(p[C,0],p[C,1],p[B,0],p[C,1])]*r[B][2][3,8]*r[C][85][1,14]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,0],p[C,1])]*r[B][2][3,8]*r[C][179][1,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,0],p[C,0])]*r[B][2][3,8]*r[C][167][1,14]
    hv += g[dei(p[C,1],p[C,1],p[B,0],p[C,0])]*r[B][2][3,8]*r[C][133][1,14]
    hv += sum(-1/2*g[dei(p[B,0],p[C,0],p[I,0],p[I,0])]*r[B][2][3,8]*r[C][3][1,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[C,0],p[I,1],p[I,1])]*r[B][2][3,8]*r[C][3][1,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[C,0])]*r[B][2][3,8]*r[C][3][1,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[C,0])]*r[B][2][3,8]*r[C][3][1,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,0],p[B,0],p[I,0])]*r[B][2][3,8]*r[C][3][1,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,0],p[B,0],p[I,1])]*r[B][2][3,8]*r[C][3][1,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[C,0])]*r[B][2][3,8]*r[C][3][1,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,0],p[C,0])]*r[B][2][3,8]*r[C][3][1,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[C,0])]*r[B][2][3,8]*r[C][3][1,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,0],p[C,0])]*r[B][2][3,8]*r[C][3][1,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][24][3,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][9][3,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][54][3,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][39][3,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,0])]*r[A][24][3,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,1])]*r[A][54][3,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,0])]*r[A][24][3,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,0])]*r[A][54][3,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][2][3,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B4C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,4),(C,5)]))
    hv = 0.0
    
    hv += -1*h[p[B,0],p[C,1]]*r[B][0][4,8]*r[C][5][5,14]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[B,1],p[C,1])]*r[B][76][4,8]*r[C][5][5,14]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[B,0],p[C,1])]*r[B][124][4,8]*r[C][5][5,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[B,1],p[B,1])]*r[B][76][4,8]*r[C][5][5,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[B,0],p[B,1])]*r[B][124][4,8]*r[C][5][5,14]
    hv += -1*g[dei(p[B,0],p[C,1],p[C,0],p[C,0])]*r[B][0][4,8]*r[C][101][5,14]
    hv += -1*g[dei(p[B,0],p[C,1],p[C,1],p[C,1])]*r[B][0][4,8]*r[C][181][5,14]
    hv += sum(-1/2*g[dei(p[B,0],p[C,1],p[I,0],p[I,0])]*r[B][0][4,8]*r[C][5][5,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[C,1],p[I,0],p[I,0])]*r[B][0][4,8]*r[C][5][5,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[C,1],p[I,1],p[I,1])]*r[B][0][4,8]*r[C][5][5,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[B,0],p[C,1],p[I,1],p[I,1])]*r[B][0][4,8]*r[C][5][5,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[C,1])]*r[B][0][4,8]*r[C][5][5,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[C,1])]*r[B][0][4,8]*r[C][5][5,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,1],p[B,0],p[I,0])]*r[B][0][4,8]*r[C][5][5,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,1],p[B,0],p[I,1])]*r[B][0][4,8]*r[C][5][5,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[C,1])]*r[B][0][4,8]*r[C][5][5,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[C,1])]*r[B][0][4,8]*r[C][5][5,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][9][3,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][39][3,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,0])]*r[A][9][3,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,1])]*r[A][39][3,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,1])]*r[A][9][3,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,1])]*r[A][39][3,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][9][3,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][39][3,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][0][4,8]*r[C][5][5,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B2C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,2),(C,2)]))
    hv = 0.0
    
    hv += -1*h[p[B,0],p[C,1]]*r[B][2][2,8]*r[C][7][2,14]
    hv += g[dei(p[B,0],p[B,1],p[B,1],p[C,1])]*r[B][84][2,8]*r[C][7][2,14]
    hv += g[dei(p[B,1],p[B,1],p[B,0],p[C,1])]*r[B][132][2,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,0],p[C,1])]*r[B][2][2,8]*r[C][115][2,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,0],p[C,0])]*r[B][2][2,8]*r[C][103][2,14]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,0],p[C,1])]*r[B][2][2,8]*r[C][115][2,14]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,0],p[C,0])]*r[B][2][2,8]*r[C][103][2,14]
    hv += g[dei(p[C,0],p[C,1],p[B,0],p[C,0])]*r[B][2][2,8]*r[C][69][2,14]
    hv += g[dei(p[C,1],p[C,1],p[B,0],p[C,1])]*r[B][2][2,8]*r[C][149][2,14]
    hv += sum(-1/2*g[dei(p[B,0],p[C,1],p[I,0],p[I,0])]*r[B][2][2,8]*r[C][7][2,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[C,1],p[I,1],p[I,1])]*r[B][2][2,8]*r[C][7][2,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[C,1])]*r[B][2][2,8]*r[C][7][2,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[C,1])]*r[B][2][2,8]*r[C][7][2,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,1],p[B,0],p[I,0])]*r[B][2][2,8]*r[C][7][2,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,1],p[B,0],p[I,1])]*r[B][2][2,8]*r[C][7][2,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[C,1])]*r[B][2][2,8]*r[C][7][2,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,0],p[C,1])]*r[B][2][2,8]*r[C][7][2,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[C,1])]*r[B][2][2,8]*r[C][7][2,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,0],p[C,1])]*r[B][2][2,8]*r[C][7][2,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][24][3,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][9][3,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][54][3,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][39][3,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,0])]*r[A][24][3,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,1])]*r[A][54][3,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,1])]*r[A][24][3,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,1])]*r[A][54][3,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][2][2,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B2C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,2),(C,3)]))
    hv = 0.0
    
    hv += -1*h[p[B,0],p[C,1]]*r[B][2][2,8]*r[C][7][3,14]
    hv += g[dei(p[B,0],p[B,1],p[B,1],p[C,1])]*r[B][84][2,8]*r[C][7][3,14]
    hv += g[dei(p[B,1],p[B,1],p[B,0],p[C,1])]*r[B][132][2,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,0],p[C,1])]*r[B][2][2,8]*r[C][115][3,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,0],p[C,0])]*r[B][2][2,8]*r[C][103][3,14]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,0],p[C,1])]*r[B][2][2,8]*r[C][115][3,14]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,0],p[C,0])]*r[B][2][2,8]*r[C][103][3,14]
    hv += g[dei(p[C,0],p[C,1],p[B,0],p[C,0])]*r[B][2][2,8]*r[C][69][3,14]
    hv += g[dei(p[C,1],p[C,1],p[B,0],p[C,1])]*r[B][2][2,8]*r[C][149][3,14]
    hv += sum(-1/2*g[dei(p[B,0],p[C,1],p[I,0],p[I,0])]*r[B][2][2,8]*r[C][7][3,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[C,1],p[I,1],p[I,1])]*r[B][2][2,8]*r[C][7][3,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[C,1])]*r[B][2][2,8]*r[C][7][3,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[C,1])]*r[B][2][2,8]*r[C][7][3,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,1],p[B,0],p[I,0])]*r[B][2][2,8]*r[C][7][3,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,1],p[B,0],p[I,1])]*r[B][2][2,8]*r[C][7][3,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[C,1])]*r[B][2][2,8]*r[C][7][3,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,0],p[C,1])]*r[B][2][2,8]*r[C][7][3,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[C,1])]*r[B][2][2,8]*r[C][7][3,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,0],p[C,1])]*r[B][2][2,8]*r[C][7][3,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][24][3,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][9][3,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][54][3,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][39][3,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,0])]*r[A][24][3,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,1])]*r[A][54][3,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,1])]*r[A][24][3,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,1])]*r[A][54][3,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][2][2,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B3C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,3),(C,2)]))
    hv = 0.0
    
    hv += -1*h[p[B,0],p[C,1]]*r[B][2][3,8]*r[C][7][2,14]
    hv += g[dei(p[B,0],p[B,1],p[B,1],p[C,1])]*r[B][84][3,8]*r[C][7][2,14]
    hv += g[dei(p[B,1],p[B,1],p[B,0],p[C,1])]*r[B][132][3,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,0],p[C,1])]*r[B][2][3,8]*r[C][115][2,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,0],p[C,0])]*r[B][2][3,8]*r[C][103][2,14]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,0],p[C,1])]*r[B][2][3,8]*r[C][115][2,14]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,0],p[C,0])]*r[B][2][3,8]*r[C][103][2,14]
    hv += g[dei(p[C,0],p[C,1],p[B,0],p[C,0])]*r[B][2][3,8]*r[C][69][2,14]
    hv += g[dei(p[C,1],p[C,1],p[B,0],p[C,1])]*r[B][2][3,8]*r[C][149][2,14]
    hv += sum(-1/2*g[dei(p[B,0],p[C,1],p[I,0],p[I,0])]*r[B][2][3,8]*r[C][7][2,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[C,1],p[I,1],p[I,1])]*r[B][2][3,8]*r[C][7][2,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[C,1])]*r[B][2][3,8]*r[C][7][2,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[C,1])]*r[B][2][3,8]*r[C][7][2,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,1],p[B,0],p[I,0])]*r[B][2][3,8]*r[C][7][2,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,1],p[B,0],p[I,1])]*r[B][2][3,8]*r[C][7][2,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[C,1])]*r[B][2][3,8]*r[C][7][2,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,0],p[C,1])]*r[B][2][3,8]*r[C][7][2,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[C,1])]*r[B][2][3,8]*r[C][7][2,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,0],p[C,1])]*r[B][2][3,8]*r[C][7][2,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][24][3,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][9][3,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][54][3,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][39][3,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,0])]*r[A][24][3,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,1])]*r[A][54][3,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,1])]*r[A][24][3,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,1])]*r[A][54][3,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][2][3,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B3C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,3),(C,3)]))
    hv = 0.0
    
    hv += -1*h[p[B,0],p[C,1]]*r[B][2][3,8]*r[C][7][3,14]
    hv += g[dei(p[B,0],p[B,1],p[B,1],p[C,1])]*r[B][84][3,8]*r[C][7][3,14]
    hv += g[dei(p[B,1],p[B,1],p[B,0],p[C,1])]*r[B][132][3,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[C,0],p[C,1])]*r[B][2][3,8]*r[C][115][3,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,0],p[C,0])]*r[B][2][3,8]*r[C][103][3,14]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,0],p[C,1])]*r[B][2][3,8]*r[C][115][3,14]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,0],p[C,0])]*r[B][2][3,8]*r[C][103][3,14]
    hv += g[dei(p[C,0],p[C,1],p[B,0],p[C,0])]*r[B][2][3,8]*r[C][69][3,14]
    hv += g[dei(p[C,1],p[C,1],p[B,0],p[C,1])]*r[B][2][3,8]*r[C][149][3,14]
    hv += sum(-1/2*g[dei(p[B,0],p[C,1],p[I,0],p[I,0])]*r[B][2][3,8]*r[C][7][3,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,0],p[C,1],p[I,1],p[I,1])]*r[B][2][3,8]*r[C][7][3,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,0],p[I,0],p[C,1])]*r[B][2][3,8]*r[C][7][3,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,0],p[I,1],p[I,1],p[C,1])]*r[B][2][3,8]*r[C][7][3,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,1],p[B,0],p[I,0])]*r[B][2][3,8]*r[C][7][3,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,1],p[B,0],p[I,1])]*r[B][2][3,8]*r[C][7][3,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,0],p[C,1])]*r[B][2][3,8]*r[C][7][3,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,0],p[C,1])]*r[B][2][3,8]*r[C][7][3,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,0],p[C,1])]*r[B][2][3,8]*r[C][7][3,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,0],p[C,1])]*r[B][2][3,8]*r[C][7][3,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][24][3,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][9][3,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][54][3,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][39][3,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,0])]*r[A][24][3,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,1])]*r[A][54][3,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,1])]*r[A][24][3,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,1])]*r[A][54][3,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][2][3,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3)]))
    hv = 0.0
    
    hv += -1*h[p[B,1],p[C,0]]*r[B][6][0,8]*r[C][3][0,14]
    hv += g[dei(p[B,0],p[B,1],p[B,0],p[C,0])]*r[B][68][0,8]*r[C][3][0,14]
    hv += g[dei(p[B,1],p[B,1],p[B,1],p[C,0])]*r[B][148][0,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,1],p[C,1])]*r[B][6][0,8]*r[C][179][0,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,1],p[C,0])]*r[B][6][0,8]*r[C][167][0,14]
    hv += g[dei(p[C,0],p[C,1],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][85][0,14]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][179][0,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][167][0,14]
    hv += g[dei(p[C,1],p[C,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][133][0,14]
    hv += sum(-1/2*g[dei(p[B,1],p[C,0],p[I,0],p[I,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[C,0],p[I,1],p[I,1])]*r[B][6][0,8]*r[C][3][0,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,0],p[B,1],p[I,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,0],p[B,1],p[I,1])]*r[B][6][0,8]*r[C][3][0,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][24][3,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][9][3,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][54][3,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][39][3,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,0])]*r[A][24][3,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,1])]*r[A][54][3,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,0])]*r[A][24][3,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,0])]*r[A][54][3,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][6][0,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(C,1)]))
    hv = 0.0
    
    hv += -1*h[p[B,1],p[C,0]]*r[B][6][0,8]*r[C][3][1,14]
    hv += g[dei(p[B,0],p[B,1],p[B,0],p[C,0])]*r[B][68][0,8]*r[C][3][1,14]
    hv += g[dei(p[B,1],p[B,1],p[B,1],p[C,0])]*r[B][148][0,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,1],p[C,1])]*r[B][6][0,8]*r[C][179][1,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,1],p[C,0])]*r[B][6][0,8]*r[C][167][1,14]
    hv += g[dei(p[C,0],p[C,1],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][85][1,14]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][179][1,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][167][1,14]
    hv += g[dei(p[C,1],p[C,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][133][1,14]
    hv += sum(-1/2*g[dei(p[B,1],p[C,0],p[I,0],p[I,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[C,0],p[I,1],p[I,1])]*r[B][6][0,8]*r[C][3][1,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[C,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[C,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,0],p[B,1],p[I,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,0],p[B,1],p[I,1])]*r[B][6][0,8]*r[C][3][1,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][24][3,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][9][3,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][54][3,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][39][3,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,0])]*r[A][24][3,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,1])]*r[A][54][3,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,0])]*r[A][24][3,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,0])]*r[A][54][3,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][6][0,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,1)]))
    hv = 0.0
    
    hv += -1*h[p[B,1],p[C,0]]*r[B][6][1,8]*r[C][3][0,14]
    hv += g[dei(p[B,0],p[B,1],p[B,0],p[C,0])]*r[B][68][1,8]*r[C][3][0,14]
    hv += g[dei(p[B,1],p[B,1],p[B,1],p[C,0])]*r[B][148][1,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,1],p[C,1])]*r[B][6][1,8]*r[C][179][0,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,1],p[C,0])]*r[B][6][1,8]*r[C][167][0,14]
    hv += g[dei(p[C,0],p[C,1],p[B,1],p[C,1])]*r[B][6][1,8]*r[C][85][0,14]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,1],p[C,1])]*r[B][6][1,8]*r[C][179][0,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,1],p[C,0])]*r[B][6][1,8]*r[C][167][0,14]
    hv += g[dei(p[C,1],p[C,1],p[B,1],p[C,0])]*r[B][6][1,8]*r[C][133][0,14]
    hv += sum(-1/2*g[dei(p[B,1],p[C,0],p[I,0],p[I,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[C,0],p[I,1],p[I,1])]*r[B][6][1,8]*r[C][3][0,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[C,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[C,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,0],p[B,1],p[I,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,0],p[B,1],p[I,1])]*r[B][6][1,8]*r[C][3][0,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[C,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,1],p[C,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[C,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,1],p[C,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][24][3,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][9][3,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][54][3,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][39][3,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,0])]*r[A][24][3,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,1])]*r[A][54][3,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,0])]*r[A][24][3,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,0])]*r[A][54][3,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][6][1,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B1C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,1),(C,1)]))
    hv = 0.0
    
    hv += -1*h[p[B,1],p[C,0]]*r[B][6][1,8]*r[C][3][1,14]
    hv += g[dei(p[B,0],p[B,1],p[B,0],p[C,0])]*r[B][68][1,8]*r[C][3][1,14]
    hv += g[dei(p[B,1],p[B,1],p[B,1],p[C,0])]*r[B][148][1,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,1],p[C,1])]*r[B][6][1,8]*r[C][179][1,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,1],p[C,0])]*r[B][6][1,8]*r[C][167][1,14]
    hv += g[dei(p[C,0],p[C,1],p[B,1],p[C,1])]*r[B][6][1,8]*r[C][85][1,14]
    hv += 1/2*g[dei(p[C,1],p[C,0],p[B,1],p[C,1])]*r[B][6][1,8]*r[C][179][1,14]
    hv += 1/2*g[dei(p[C,1],p[C,1],p[B,1],p[C,0])]*r[B][6][1,8]*r[C][167][1,14]
    hv += g[dei(p[C,1],p[C,1],p[B,1],p[C,0])]*r[B][6][1,8]*r[C][133][1,14]
    hv += sum(-1/2*g[dei(p[B,1],p[C,0],p[I,0],p[I,0])]*r[B][6][1,8]*r[C][3][1,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[C,0],p[I,1],p[I,1])]*r[B][6][1,8]*r[C][3][1,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[C,0])]*r[B][6][1,8]*r[C][3][1,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[C,0])]*r[B][6][1,8]*r[C][3][1,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,0],p[B,1],p[I,0])]*r[B][6][1,8]*r[C][3][1,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,0],p[B,1],p[I,1])]*r[B][6][1,8]*r[C][3][1,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[C,0])]*r[B][6][1,8]*r[C][3][1,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,1],p[C,0])]*r[B][6][1,8]*r[C][3][1,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[C,0])]*r[B][6][1,8]*r[C][3][1,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,1],p[C,0])]*r[B][6][1,8]*r[C][3][1,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][24][3,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][9][3,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][54][3,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][39][3,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,0])]*r[A][24][3,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,1])]*r[A][54][3,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,0])]*r[A][24][3,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,0])]*r[A][54][3,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][6][1,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(C,2)]))
    hv = 0.0
    
    hv += -1*h[p[B,1],p[C,1]]*r[B][6][0,8]*r[C][7][2,14]
    hv += g[dei(p[B,0],p[B,1],p[B,0],p[C,1])]*r[B][68][0,8]*r[C][7][2,14]
    hv += g[dei(p[B,1],p[B,1],p[B,1],p[C,1])]*r[B][148][0,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,0],p[C,1])]*r[B][6][0,8]*r[C][115][2,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,0],p[C,0])]*r[B][6][0,8]*r[C][103][2,14]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][115][2,14]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][103][2,14]
    hv += g[dei(p[C,0],p[C,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][69][2,14]
    hv += g[dei(p[C,1],p[C,1],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][149][2,14]
    hv += sum(-1/2*g[dei(p[B,1],p[C,1],p[I,0],p[I,0])]*r[B][6][0,8]*r[C][7][2,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[C,1],p[I,1],p[I,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[C,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[C,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,1],p[B,1],p[I,0])]*r[B][6][0,8]*r[C][7][2,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,1],p[B,1],p[I,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][24][3,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][9][3,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][54][3,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][39][3,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,0])]*r[A][24][3,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,1])]*r[A][54][3,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,1])]*r[A][24][3,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,1])]*r[A][54][3,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][6][0,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(C,3)]))
    hv = 0.0
    
    hv += -1*h[p[B,1],p[C,1]]*r[B][6][0,8]*r[C][7][3,14]
    hv += g[dei(p[B,0],p[B,1],p[B,0],p[C,1])]*r[B][68][0,8]*r[C][7][3,14]
    hv += g[dei(p[B,1],p[B,1],p[B,1],p[C,1])]*r[B][148][0,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,0],p[C,1])]*r[B][6][0,8]*r[C][115][3,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,0],p[C,0])]*r[B][6][0,8]*r[C][103][3,14]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][115][3,14]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][103][3,14]
    hv += g[dei(p[C,0],p[C,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][69][3,14]
    hv += g[dei(p[C,1],p[C,1],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][149][3,14]
    hv += sum(-1/2*g[dei(p[B,1],p[C,1],p[I,0],p[I,0])]*r[B][6][0,8]*r[C][7][3,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[C,1],p[I,1],p[I,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[C,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[C,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,1],p[B,1],p[I,0])]*r[B][6][0,8]*r[C][7][3,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,1],p[B,1],p[I,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][24][3,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][9][3,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][54][3,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][39][3,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,0])]*r[A][24][3,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,1])]*r[A][54][3,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,1])]*r[A][24][3,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,1])]*r[A][54][3,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][6][0,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B1C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,1),(C,2)]))
    hv = 0.0
    
    hv += -1*h[p[B,1],p[C,1]]*r[B][6][1,8]*r[C][7][2,14]
    hv += g[dei(p[B,0],p[B,1],p[B,0],p[C,1])]*r[B][68][1,8]*r[C][7][2,14]
    hv += g[dei(p[B,1],p[B,1],p[B,1],p[C,1])]*r[B][148][1,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,0],p[C,1])]*r[B][6][1,8]*r[C][115][2,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,0],p[C,0])]*r[B][6][1,8]*r[C][103][2,14]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,1],p[C,1])]*r[B][6][1,8]*r[C][115][2,14]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,1],p[C,0])]*r[B][6][1,8]*r[C][103][2,14]
    hv += g[dei(p[C,0],p[C,1],p[B,1],p[C,0])]*r[B][6][1,8]*r[C][69][2,14]
    hv += g[dei(p[C,1],p[C,1],p[B,1],p[C,1])]*r[B][6][1,8]*r[C][149][2,14]
    hv += sum(-1/2*g[dei(p[B,1],p[C,1],p[I,0],p[I,0])]*r[B][6][1,8]*r[C][7][2,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[C,1],p[I,1],p[I,1])]*r[B][6][1,8]*r[C][7][2,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[C,1])]*r[B][6][1,8]*r[C][7][2,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[C,1])]*r[B][6][1,8]*r[C][7][2,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,1],p[B,1],p[I,0])]*r[B][6][1,8]*r[C][7][2,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,1],p[B,1],p[I,1])]*r[B][6][1,8]*r[C][7][2,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[C,1])]*r[B][6][1,8]*r[C][7][2,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,1],p[C,1])]*r[B][6][1,8]*r[C][7][2,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[C,1])]*r[B][6][1,8]*r[C][7][2,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,1],p[C,1])]*r[B][6][1,8]*r[C][7][2,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][24][3,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][9][3,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][54][3,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][39][3,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,0])]*r[A][24][3,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,1])]*r[A][54][3,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,1])]*r[A][24][3,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,1])]*r[A][54][3,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][6][1,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B1C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,1),(C,3)]))
    hv = 0.0
    
    hv += -1*h[p[B,1],p[C,1]]*r[B][6][1,8]*r[C][7][3,14]
    hv += g[dei(p[B,0],p[B,1],p[B,0],p[C,1])]*r[B][68][1,8]*r[C][7][3,14]
    hv += g[dei(p[B,1],p[B,1],p[B,1],p[C,1])]*r[B][148][1,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[C,0],p[C,1])]*r[B][6][1,8]*r[C][115][3,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[C,0],p[C,0])]*r[B][6][1,8]*r[C][103][3,14]
    hv += 1/2*g[dei(p[C,0],p[C,0],p[B,1],p[C,1])]*r[B][6][1,8]*r[C][115][3,14]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,1],p[C,0])]*r[B][6][1,8]*r[C][103][3,14]
    hv += g[dei(p[C,0],p[C,1],p[B,1],p[C,0])]*r[B][6][1,8]*r[C][69][3,14]
    hv += g[dei(p[C,1],p[C,1],p[B,1],p[C,1])]*r[B][6][1,8]*r[C][149][3,14]
    hv += sum(-1/2*g[dei(p[B,1],p[C,1],p[I,0],p[I,0])]*r[B][6][1,8]*r[C][7][3,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[B,1],p[C,1],p[I,1],p[I,1])]*r[B][6][1,8]*r[C][7][3,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,0],p[I,0],p[C,1])]*r[B][6][1,8]*r[C][7][3,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[B,1],p[I,1],p[I,1],p[C,1])]*r[B][6][1,8]*r[C][7][3,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[C,1],p[B,1],p[I,0])]*r[B][6][1,8]*r[C][7][3,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[C,1],p[B,1],p[I,1])]*r[B][6][1,8]*r[C][7][3,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[B,1],p[C,1])]*r[B][6][1,8]*r[C][7][3,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[B,1],p[C,1])]*r[B][6][1,8]*r[C][7][3,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[B,1],p[C,1])]*r[B][6][1,8]*r[C][7][3,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[B,1],p[C,1])]*r[B][6][1,8]*r[C][7][3,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][24][3,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][9][3,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][54][3,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][39][3,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,0])]*r[A][24][3,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,1])]*r[A][54][3,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,1])]*r[A][24][3,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,1])]*r[A][54][3,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][6][1,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B6C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,6),(C,15)]))
    hv = 0.0
    
    hv += h[p[C,0],p[B,1]]*r[B][5][6,8]*r[C][0][15,14]
    hv += g[dei(p[C,0],p[B,1],p[C,0],p[C,0])]*r[B][5][6,8]*r[C][66][15,14]
    hv += 1/2*g[dei(p[C,0],p[B,1],p[C,1],p[C,1])]*r[B][5][6,8]*r[C][76][15,14]
    hv += g[dei(p[C,0],p[B,1],p[C,1],p[C,1])]*r[B][5][6,8]*r[C][86][15,14]
    hv += 1/2*g[dei(p[C,1],p[B,1],p[C,0],p[C,1])]*r[B][5][6,8]*r[C][124][15,14]
    hv += -1/2*g[dei(p[C,0],p[C,1],p[C,1],p[B,1])]*r[B][5][6,8]*r[C][76][15,14]
    hv += -1/2*g[dei(p[C,1],p[C,1],p[C,0],p[B,1])]*r[B][5][6,8]*r[C][124][15,14]
    hv += sum(1/2*g[dei(p[C,0],p[B,1],p[I,0],p[I,0])]*r[B][5][6,8]*r[C][0][15,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[C,0],p[B,1],p[I,0],p[I,0])]*r[B][5][6,8]*r[C][0][15,14]*r[I][24][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[C,0],p[B,1],p[I,1],p[I,1])]*r[B][5][6,8]*r[C][0][15,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(g[dei(p[C,0],p[B,1],p[I,1],p[I,1])]*r[B][5][6,8]*r[C][0][15,14]*r[I][54][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,0],p[I,0],p[B,1])]*r[B][5][6,8]*r[C][0][15,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[C,0],p[I,1],p[I,1],p[B,1])]*r[B][5][6,8]*r[C][0][15,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,0],p[B,1],p[C,0],p[I,0])]*r[B][5][6,8]*r[C][0][15,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(-1/2*g[dei(p[I,1],p[B,1],p[C,0],p[I,1])]*r[B][5][6,8]*r[C][0][15,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[C,0],p[B,1])]*r[B][5][6,8]*r[C][0][15,14]*r[I][9][0,0] for I in range(np) if I not in {A,B,C})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[C,0],p[B,1])]*r[B][5][6,8]*r[C][0][15,14]*r[I][39][0,0] for I in range(np) if I not in {A,B,C})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[B,1])]*r[A][9][3,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[B,1])]*r[A][39][3,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[C,0],p[A,0])]*r[A][9][3,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[C,0],p[A,1])]*r[A][39][3,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[B,1])]*r[A][9][3,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[B,1])]*r[A][39][3,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += 1/2*g[dei(p[C,0],p[B,1],p[A,0],p[A,0])]*r[A][9][3,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += g[dei(p[C,0],p[B,1],p[A,0],p[A,0])]*r[A][24][3,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += 1/2*g[dei(p[C,0],p[B,1],p[A,1],p[A,1])]*r[A][39][3,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += g[dei(p[C,0],p[B,1],p[A,1],p[A,1])]*r[A][54][3,3]*r[B][5][6,8]*r[C][0][15,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B11C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,11),(C,10)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[B,0],p[C,1],p[B,0],p[C,0])]*r[B][11][11,8]*r[C][28][10,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B11C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,11),(C,9)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[B,0],p[C,1],p[B,0],p[C,1])]*r[B][11][11,8]*r[C][52][9,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B14C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,14),(C,8)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[B,0],p[C,0],p[B,1],p[C,1])]*r[B][29][14,8]*r[C][49][8,14]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[B,1],p[C,0])]*r[B][29][14,8]*r[C][31][8,14]
    hv += 1/2*g[dei(p[B,1],p[C,0],p[B,0],p[C,1])]*r[B][47][14,8]*r[C][49][8,14]
    hv += 1/2*g[dei(p[B,1],p[C,1],p[B,0],p[C,0])]*r[B][47][14,8]*r[C][31][8,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B12C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,12),(C,10)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[B,0],p[C,1],p[B,1],p[C,0])]*r[B][17][12,8]*r[C][28][10,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B12C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,12),(C,9)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += g[dei(p[B,0],p[C,1],p[B,1],p[C,1])]*r[B][17][12,8]*r[C][52][9,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B7C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,7),(C,13)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,0],p[C,1])]*r[B][15][7,8]*r[C][15][13,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[C,0],p[B,1])]*r[B][15][7,8]*r[C][15][13,14]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,0],p[C,1])]*r[B][15][7,8]*r[C][15][13,14]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[B,0],p[B,1])]*r[B][15][7,8]*r[C][15][13,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B9C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,9),(C,12)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[C,0],p[B,1],p[B,0],p[C,0])]*r[B][27][9,8]*r[C][12][12,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B9C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,9),(C,11)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[C,0],p[B,1],p[B,0],p[C,1])]*r[B][27][9,8]*r[C][18][11,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B10C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,10),(C,12)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[C,0],p[B,1],p[B,1],p[C,0])]*r[B][51][10,8]*r[C][12][12,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B10C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,3),(B,10),(C,11)]))
    hv = 0.0
    sket = sign([B,C])
    
    hv += -1*g[dei(p[C,0],p[B,1],p[B,1],p[C,1])]*r[B][51][10,8]*r[C][18][11,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B4C14I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,4),(C,14),(I,9)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[I,0])]*r[A][15][0,3]*r[B][0][4,8]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[I,0])]*r[A][33][0,3]*r[B][0][4,8]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,0],p[A,1])]*r[A][15][0,3]*r[B][0][4,8]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,0],p[A,0])]*r[A][33][0,3]*r[B][0][4,8]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[I,0])]*r[A][15][0,3]*r[B][0][4,8]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[I,0])]*r[A][33][0,3]*r[B][0][4,8]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,0],p[A,1])]*r[A][15][0,3]*r[B][0][4,8]*r[I][1][9,0]
        hv += g[dei(p[B,0],p[I,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][0][4,8]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,1],p[A,0])]*r[A][33][0,3]*r[B][0][4,8]*r[I][1][9,0]
        hv += g[dei(p[B,0],p[I,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][0][4,8]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2C14I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,2),(C,14),(I,7)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[I,0])]*r[A][30][0,3]*r[B][2][2,8]*r[I][3][7,0]
        hv += g[dei(p[A,0],p[A,1],p[B,0],p[I,0])]*r[A][15][0,3]*r[B][2][2,8]*r[I][3][7,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[I,0])]*r[A][48][0,3]*r[B][2][2,8]*r[I][3][7,0]
        hv += g[dei(p[A,1],p[A,0],p[B,0],p[I,0])]*r[A][33][0,3]*r[B][2][2,8]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,0],p[A,1])]*r[A][30][0,3]*r[B][2][2,8]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,0],p[A,0])]*r[A][48][0,3]*r[B][2][2,8]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[I,0])]*r[A][30][0,3]*r[B][2][2,8]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[I,0])]*r[A][48][0,3]*r[B][2][2,8]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][2][2,8]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][2][2,8]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3C14I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,3),(C,14),(I,7)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[I,0])]*r[A][30][0,3]*r[B][2][3,8]*r[I][3][7,0]
        hv += g[dei(p[A,0],p[A,1],p[B,0],p[I,0])]*r[A][15][0,3]*r[B][2][3,8]*r[I][3][7,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[I,0])]*r[A][48][0,3]*r[B][2][3,8]*r[I][3][7,0]
        hv += g[dei(p[A,1],p[A,0],p[B,0],p[I,0])]*r[A][33][0,3]*r[B][2][3,8]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,0],p[A,1])]*r[A][30][0,3]*r[B][2][3,8]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,0],p[A,0])]*r[A][48][0,3]*r[B][2][3,8]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[I,0])]*r[A][30][0,3]*r[B][2][3,8]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[I,0])]*r[A][48][0,3]*r[B][2][3,8]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][2][3,8]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][2][3,8]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B4C14I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,4),(C,14),(I,10)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[I,1])]*r[A][15][0,3]*r[B][0][4,8]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[I,1])]*r[A][33][0,3]*r[B][0][4,8]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,0],p[A,1])]*r[A][15][0,3]*r[B][0][4,8]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,0],p[A,0])]*r[A][33][0,3]*r[B][0][4,8]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[I,1])]*r[A][15][0,3]*r[B][0][4,8]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[I,1])]*r[A][33][0,3]*r[B][0][4,8]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,0],p[A,1])]*r[A][15][0,3]*r[B][0][4,8]*r[I][5][10,0]
        hv += g[dei(p[B,0],p[I,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][0][4,8]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,1],p[A,0])]*r[A][33][0,3]*r[B][0][4,8]*r[I][5][10,0]
        hv += g[dei(p[B,0],p[I,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][0][4,8]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2C14I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,2),(C,14),(I,8)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[I,1])]*r[A][30][0,3]*r[B][2][2,8]*r[I][7][8,0]
        hv += g[dei(p[A,0],p[A,1],p[B,0],p[I,1])]*r[A][15][0,3]*r[B][2][2,8]*r[I][7][8,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[I,1])]*r[A][48][0,3]*r[B][2][2,8]*r[I][7][8,0]
        hv += g[dei(p[A,1],p[A,0],p[B,0],p[I,1])]*r[A][33][0,3]*r[B][2][2,8]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,0],p[A,1])]*r[A][30][0,3]*r[B][2][2,8]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,0],p[A,0])]*r[A][48][0,3]*r[B][2][2,8]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[I,1])]*r[A][30][0,3]*r[B][2][2,8]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[I,1])]*r[A][48][0,3]*r[B][2][2,8]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][2][2,8]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][2][2,8]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3C14I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,3),(C,14),(I,8)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[B,0],p[I,1])]*r[A][30][0,3]*r[B][2][3,8]*r[I][7][8,0]
        hv += g[dei(p[A,0],p[A,1],p[B,0],p[I,1])]*r[A][15][0,3]*r[B][2][3,8]*r[I][7][8,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[I,1])]*r[A][48][0,3]*r[B][2][3,8]*r[I][7][8,0]
        hv += g[dei(p[A,1],p[A,0],p[B,0],p[I,1])]*r[A][33][0,3]*r[B][2][3,8]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,0],p[A,1])]*r[A][30][0,3]*r[B][2][3,8]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,0],p[A,0])]*r[A][48][0,3]*r[B][2][3,8]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,0],p[A,1],p[A,0],p[I,1])]*r[A][30][0,3]*r[B][2][3,8]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[I,1])]*r[A][48][0,3]*r[B][2][3,8]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][2][3,8]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][2][3,8]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2C14I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,2),(C,14),(I,7)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[I,0])]*r[A][24][2,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += g[dei(p[A,0],p[A,0],p[B,1],p[I,0])]*r[A][9][2,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[I,0])]*r[A][54][2,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += g[dei(p[A,1],p[A,1],p[B,1],p[I,0])]*r[A][39][2,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,1],p[A,0])]*r[A][24][2,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,1],p[A,1])]*r[A][54][2,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[I,0])]*r[A][24][2,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[I,0])]*r[A][54][2,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][6][0,8]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2C14I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,2),(C,14),(I,8)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[I,1])]*r[A][24][2,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += g[dei(p[A,0],p[A,0],p[B,1],p[I,1])]*r[A][9][2,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[B,1],p[I,1])]*r[A][54][2,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += g[dei(p[A,1],p[A,1],p[B,1],p[I,1])]*r[A][39][2,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,1],p[A,0])]*r[A][24][2,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,1],p[A,1])]*r[A][54][2,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[I,1])]*r[A][24][2,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[A,1],p[A,1],p[I,1])]*r[A][54][2,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][6][0,8]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _C14I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(C,14),(I,7)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[I,0])]*r[A][30][0,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += g[dei(p[A,0],p[A,1],p[B,1],p[I,0])]*r[A][15][0,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[I,0])]*r[A][48][0,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += g[dei(p[A,1],p[A,0],p[B,1],p[I,0])]*r[A][33][0,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,1],p[A,1])]*r[A][30][0,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,1],p[A,0])]*r[A][48][0,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[I,0])]*r[A][30][0,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[I,0])]*r[A][48][0,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][6][0,8]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1C14I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,1),(C,14),(I,7)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[I,0])]*r[A][30][0,3]*r[B][6][1,8]*r[I][3][7,0]
        hv += g[dei(p[A,0],p[A,1],p[B,1],p[I,0])]*r[A][15][0,3]*r[B][6][1,8]*r[I][3][7,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[I,0])]*r[A][48][0,3]*r[B][6][1,8]*r[I][3][7,0]
        hv += g[dei(p[A,1],p[A,0],p[B,1],p[I,0])]*r[A][33][0,3]*r[B][6][1,8]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,1],p[A,1])]*r[A][30][0,3]*r[B][6][1,8]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,1],p[A,0])]*r[A][48][0,3]*r[B][6][1,8]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[I,0])]*r[A][30][0,3]*r[B][6][1,8]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[I,0])]*r[A][48][0,3]*r[B][6][1,8]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][6][1,8]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][6][1,8]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C14I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,14),(I,7)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[I,0])]*r[A][30][1,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += g[dei(p[A,0],p[A,1],p[B,1],p[I,0])]*r[A][15][1,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[I,0])]*r[A][48][1,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += g[dei(p[A,1],p[A,0],p[B,1],p[I,0])]*r[A][33][1,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,1],p[A,1])]*r[A][30][1,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,1],p[A,0])]*r[A][48][1,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[I,0])]*r[A][30][1,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[I,0])]*r[A][48][1,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][6][0,8]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][6][0,8]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _C14I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(C,14),(I,8)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[I,1])]*r[A][30][0,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += g[dei(p[A,0],p[A,1],p[B,1],p[I,1])]*r[A][15][0,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[I,1])]*r[A][48][0,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += g[dei(p[A,1],p[A,0],p[B,1],p[I,1])]*r[A][33][0,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,1],p[A,1])]*r[A][30][0,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,1],p[A,0])]*r[A][48][0,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[I,1])]*r[A][30][0,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[I,1])]*r[A][48][0,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][6][0,8]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1C14I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,1),(C,14),(I,8)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[I,1])]*r[A][30][0,3]*r[B][6][1,8]*r[I][7][8,0]
        hv += g[dei(p[A,0],p[A,1],p[B,1],p[I,1])]*r[A][15][0,3]*r[B][6][1,8]*r[I][7][8,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[I,1])]*r[A][48][0,3]*r[B][6][1,8]*r[I][7][8,0]
        hv += g[dei(p[A,1],p[A,0],p[B,1],p[I,1])]*r[A][33][0,3]*r[B][6][1,8]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,1],p[A,1])]*r[A][30][0,3]*r[B][6][1,8]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,1],p[A,0])]*r[A][48][0,3]*r[B][6][1,8]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[I,1])]*r[A][30][0,3]*r[B][6][1,8]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[I,1])]*r[A][48][0,3]*r[B][6][1,8]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][6][1,8]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][6][1,8]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C14I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(C,14),(I,8)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[B,1],p[I,1])]*r[A][30][1,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += g[dei(p[A,0],p[A,1],p[B,1],p[I,1])]*r[A][15][1,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[I,1])]*r[A][48][1,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += g[dei(p[A,1],p[A,0],p[B,1],p[I,1])]*r[A][33][1,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,1],p[A,1])]*r[A][30][1,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,1],p[A,0])]*r[A][48][1,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[A,1],p[A,0],p[I,1])]*r[A][30][1,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[I,1])]*r[A][48][1,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][6][0,8]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][6][0,8]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A4C14I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,4),(C,14),(I,9)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1*g[dei(p[A,0],p[I,0],p[B,1],p[A,0])]*r[A][12][4,3]*r[B][6][0,8]*r[I][1][9,0]
        hv += -1*g[dei(p[A,1],p[I,0],p[B,1],p[A,1])]*r[A][42][4,3]*r[B][6][0,8]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A4C14I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,4),(C,14),(I,10)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1*g[dei(p[A,0],p[I,1],p[B,1],p[A,0])]*r[A][12][4,3]*r[B][6][0,8]*r[I][5][10,0]
        hv += -1*g[dei(p[A,1],p[I,1],p[B,1],p[A,1])]*r[A][42][4,3]*r[B][6][0,8]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11C14I6(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(C,14),(I,6)]))
        hv = 0.0
        sket = sign([A,C])
        
        hv += g[dei(p[A,0],p[I,0],p[B,1],p[I,0])]*r[A][0][11,3]*r[B][6][0,8]*r[I][22][6,0]
        hv += g[dei(p[A,0],p[I,1],p[B,1],p[I,1])]*r[A][0][11,3]*r[B][6][0,8]*r[I][52][6,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12C14I6(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(C,14),(I,6)]))
        hv = 0.0
        sket = sign([A,C])
        
        hv += g[dei(p[A,1],p[I,0],p[B,1],p[I,0])]*r[A][4][12,3]*r[B][6][0,8]*r[I][22][6,0]
        hv += g[dei(p[A,1],p[I,1],p[B,1],p[I,1])]*r[A][4][12,3]*r[B][6][0,8]*r[I][52][6,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B6C14I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,6),(C,14),(I,12)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,1],p[I,0],p[B,1])]*r[A][15][0,3]*r[B][5][6,8]*r[I][0][12,0]
        hv += -1/2*g[dei(p[A,1],p[A,0],p[I,0],p[B,1])]*r[A][33][0,3]*r[B][5][6,8]*r[I][0][12,0]
        hv += 1/2*g[dei(p[A,0],p[B,1],p[I,0],p[A,1])]*r[A][15][0,3]*r[B][5][6,8]*r[I][0][12,0]
        hv += 1/2*g[dei(p[A,1],p[B,1],p[I,0],p[A,0])]*r[A][33][0,3]*r[B][5][6,8]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[A,0],p[B,1])]*r[A][15][0,3]*r[B][5][6,8]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[A,1],p[B,1])]*r[A][33][0,3]*r[B][5][6,8]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[B,1],p[A,0],p[A,1])]*r[A][15][0,3]*r[B][5][6,8]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[B,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][5][6,8]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[B,1],p[A,1],p[A,0])]*r[A][33][0,3]*r[B][5][6,8]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[B,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][5][6,8]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B6C14I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,6),(C,14),(I,11)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,1],p[I,1],p[B,1])]*r[A][15][0,3]*r[B][5][6,8]*r[I][4][11,0]
        hv += -1/2*g[dei(p[A,1],p[A,0],p[I,1],p[B,1])]*r[A][33][0,3]*r[B][5][6,8]*r[I][4][11,0]
        hv += 1/2*g[dei(p[A,0],p[B,1],p[I,1],p[A,1])]*r[A][15][0,3]*r[B][5][6,8]*r[I][4][11,0]
        hv += 1/2*g[dei(p[A,1],p[B,1],p[I,1],p[A,0])]*r[A][33][0,3]*r[B][5][6,8]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[A,0],p[B,1])]*r[A][15][0,3]*r[B][5][6,8]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[A,1],p[B,1])]*r[A][33][0,3]*r[B][5][6,8]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[B,1],p[A,0],p[A,1])]*r[A][15][0,3]*r[B][5][6,8]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[B,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][5][6,8]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[B,1],p[A,1],p[A,0])]*r[A][33][0,3]*r[B][5][6,8]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[B,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][5][6,8]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8C14I1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(C,14),(I,1)]))
        hv = 0.0
        sket = sign([A,C])
        
        hv += -1/2*g[dei(p[B,1],p[A,0],p[I,0],p[I,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][24][1,0]
        hv += -1/2*g[dei(p[B,1],p[A,0],p[I,1],p[I,1])]*r[A][3][8,3]*r[B][6][0,8]*r[I][54][1,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[I,0],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][24][1,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[I,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][54][1,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[B,1],p[I,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][24][1,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[B,1],p[I,1])]*r[A][3][8,3]*r[B][6][0,8]*r[I][54][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][24][1,0]
        hv += -1*g[dei(p[I,0],p[I,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][54][1,0]
        hv += -1*g[dei(p[I,1],p[I,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8C14I2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(C,14),(I,2)]))
        hv = 0.0
        sket = sign([A,C])
        
        hv += -1/2*g[dei(p[B,1],p[A,0],p[I,0],p[I,1])]*r[A][3][8,3]*r[B][6][0,8]*r[I][30][2,0]
        hv += -1/2*g[dei(p[B,1],p[A,0],p[I,1],p[I,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][48][2,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[I,0],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][30][2,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[I,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][48][2,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[B,1],p[I,1])]*r[A][3][8,3]*r[B][6][0,8]*r[I][30][2,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[B,1],p[I,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][48][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][30][2,0]
        hv += -1*g[dei(p[I,0],p[I,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][48][2,0]
        hv += -1*g[dei(p[I,1],p[I,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8C14I3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(C,14),(I,3)]))
        hv = 0.0
        sket = sign([A,C])
        
        hv += -1/2*g[dei(p[B,1],p[A,0],p[I,0],p[I,1])]*r[A][3][8,3]*r[B][6][0,8]*r[I][30][3,0]
        hv += -1/2*g[dei(p[B,1],p[A,0],p[I,1],p[I,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][48][3,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[I,0],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][30][3,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[I,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][48][3,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[B,1],p[I,1])]*r[A][3][8,3]*r[B][6][0,8]*r[I][30][3,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[B,1],p[I,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][48][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][30][3,0]
        hv += -1*g[dei(p[I,0],p[I,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][48][3,0]
        hv += -1*g[dei(p[I,1],p[I,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7C14I1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(C,14),(I,1)]))
        hv = 0.0
        sket = sign([A,C])
        
        hv += -1/2*g[dei(p[B,1],p[A,1],p[I,0],p[I,0])]*r[A][7][7,3]*r[B][6][0,8]*r[I][24][1,0]
        hv += -1/2*g[dei(p[B,1],p[A,1],p[I,1],p[I,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][54][1,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[I,0],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][24][1,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[I,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][54][1,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[B,1],p[I,0])]*r[A][7][7,3]*r[B][6][0,8]*r[I][24][1,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[B,1],p[I,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][54][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][24][1,0]
        hv += -1*g[dei(p[I,0],p[I,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][54][1,0]
        hv += -1*g[dei(p[I,1],p[I,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7C14I2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(C,14),(I,2)]))
        hv = 0.0
        sket = sign([A,C])
        
        hv += -1/2*g[dei(p[B,1],p[A,1],p[I,0],p[I,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][30][2,0]
        hv += -1/2*g[dei(p[B,1],p[A,1],p[I,1],p[I,0])]*r[A][7][7,3]*r[B][6][0,8]*r[I][48][2,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[I,0],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][30][2,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[I,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][48][2,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[B,1],p[I,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][30][2,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[B,1],p[I,0])]*r[A][7][7,3]*r[B][6][0,8]*r[I][48][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][30][2,0]
        hv += -1*g[dei(p[I,0],p[I,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][48][2,0]
        hv += -1*g[dei(p[I,1],p[I,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7C14I3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(C,14),(I,3)]))
        hv = 0.0
        sket = sign([A,C])
        
        hv += -1/2*g[dei(p[B,1],p[A,1],p[I,0],p[I,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][30][3,0]
        hv += -1/2*g[dei(p[B,1],p[A,1],p[I,1],p[I,0])]*r[A][7][7,3]*r[B][6][0,8]*r[I][48][3,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[I,0],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][30][3,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[I,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][48][3,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[B,1],p[I,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][30][3,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[B,1],p[I,0])]*r[A][7][7,3]*r[B][6][0,8]*r[I][48][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][30][3,0]
        hv += -1*g[dei(p[I,0],p[I,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][48][3,0]
        hv += -1*g[dei(p[I,1],p[I,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6C14I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,6),(C,14),(I,12)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1*g[dei(p[I,0],p[A,0],p[B,1],p[A,1])]*r[A][46][6,3]*r[B][6][0,8]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[A,1],p[B,1],p[A,0])]*r[A][28][6,3]*r[B][6][0,8]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6C14I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,6),(C,14),(I,11)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1*g[dei(p[I,1],p[A,0],p[B,1],p[A,1])]*r[A][46][6,3]*r[B][6][0,8]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[A,1],p[B,1],p[A,0])]*r[A][28][6,3]*r[B][6][0,8]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10C14I4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(C,14),(I,4)]))
        hv = 0.0
        sket = sign([A,C])
        
        hv += g[dei(p[I,0],p[A,0],p[B,1],p[I,1])]*r[A][1][10,3]*r[B][6][0,8]*r[I][18][4,0]
        hv += g[dei(p[I,1],p[A,0],p[B,1],p[I,0])]*r[A][1][10,3]*r[B][6][0,8]*r[I][36][4,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9C14I4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(C,14),(I,4)]))
        hv = 0.0
        sket = sign([A,C])
        
        hv += g[dei(p[I,0],p[A,1],p[B,1],p[I,1])]*r[A][5][9,3]*r[B][6][0,8]*r[I][18][4,0]
        hv += g[dei(p[I,1],p[A,1],p[B,1],p[I,0])]*r[A][5][9,3]*r[B][6][0,8]*r[I][36][4,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A15B8I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,15),(B,8),(I,9)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[A,0],p[I,0],p[A,1],p[C,0])]*r[A][17][15,3]*r[C][3][0,14]*r[I][1][9,0]
        hv += -1*g[dei(p[A,1],p[I,0],p[A,0],p[C,0])]*r[A][35][15,3]*r[C][3][0,14]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A15B8I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,15),(B,8),(I,10)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[A,0],p[I,1],p[A,1],p[C,0])]*r[A][17][15,3]*r[C][3][0,14]*r[I][5][10,0]
        hv += -1*g[dei(p[A,1],p[I,1],p[A,0],p[C,0])]*r[A][35][15,3]*r[C][3][0,14]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B8C15I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,8),(C,15),(I,9)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,1],p[C,0],p[I,0])]*r[A][15][0,3]*r[C][0][15,14]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,1],p[A,0],p[C,0],p[I,0])]*r[A][33][0,3]*r[C][0][15,14]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[C,0],p[A,1])]*r[A][15][0,3]*r[C][0][15,14]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[C,0],p[A,0])]*r[A][33][0,3]*r[C][0][15,14]*r[I][1][9,0]
        hv += 1/2*g[dei(p[C,0],p[A,1],p[A,0],p[I,0])]*r[A][15][0,3]*r[C][0][15,14]*r[I][1][9,0]
        hv += 1/2*g[dei(p[C,0],p[A,0],p[A,1],p[I,0])]*r[A][33][0,3]*r[C][0][15,14]*r[I][1][9,0]
        hv += -1/2*g[dei(p[C,0],p[I,0],p[A,0],p[A,1])]*r[A][15][0,3]*r[C][0][15,14]*r[I][1][9,0]
        hv += -1*g[dei(p[C,0],p[I,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[C][0][15,14]*r[I][1][9,0]
        hv += -1/2*g[dei(p[C,0],p[I,0],p[A,1],p[A,0])]*r[A][33][0,3]*r[C][0][15,14]*r[I][1][9,0]
        hv += -1*g[dei(p[C,0],p[I,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[C][0][15,14]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B8C15I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,8),(C,15),(I,10)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1/2*g[dei(p[A,0],p[A,1],p[C,0],p[I,1])]*r[A][15][0,3]*r[C][0][15,14]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,1],p[A,0],p[C,0],p[I,1])]*r[A][33][0,3]*r[C][0][15,14]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[C,0],p[A,1])]*r[A][15][0,3]*r[C][0][15,14]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[C,0],p[A,0])]*r[A][33][0,3]*r[C][0][15,14]*r[I][5][10,0]
        hv += 1/2*g[dei(p[C,0],p[A,1],p[A,0],p[I,1])]*r[A][15][0,3]*r[C][0][15,14]*r[I][5][10,0]
        hv += 1/2*g[dei(p[C,0],p[A,0],p[A,1],p[I,1])]*r[A][33][0,3]*r[C][0][15,14]*r[I][5][10,0]
        hv += -1/2*g[dei(p[C,0],p[I,1],p[A,0],p[A,1])]*r[A][15][0,3]*r[C][0][15,14]*r[I][5][10,0]
        hv += -1*g[dei(p[C,0],p[I,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[C][0][15,14]*r[I][5][10,0]
        hv += -1/2*g[dei(p[C,0],p[I,1],p[A,1],p[A,0])]*r[A][33][0,3]*r[C][0][15,14]*r[I][5][10,0]
        hv += -1*g[dei(p[C,0],p[I,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[C][0][15,14]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B8I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,2),(B,8),(I,14)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,0],p[C,0])]*r[A][24][2,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += g[dei(p[A,0],p[A,0],p[I,0],p[C,0])]*r[A][9][2,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,0],p[C,0])]*r[A][54][2,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += g[dei(p[A,1],p[A,1],p[I,0],p[C,0])]*r[A][39][2,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[A,0],p[C,0],p[I,0],p[A,0])]*r[A][24][2,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[A,1],p[C,0],p[I,0],p[A,1])]*r[A][54][2,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,0],p[C,0])]*r[A][24][2,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,1],p[C,0])]*r[A][54][2,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[A,0],p[A,0])]*r[A][24][2,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[A,1],p[A,1])]*r[A][54][2,3]*r[C][3][0,14]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B8I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,8),(I,14)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,0],p[C,0])]*r[A][30][0,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += g[dei(p[A,0],p[A,1],p[I,0],p[C,0])]*r[A][15][0,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,0],p[C,0])]*r[A][48][0,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += g[dei(p[A,1],p[A,0],p[I,0],p[C,0])]*r[A][33][0,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[A,0],p[C,0],p[I,0],p[A,1])]*r[A][30][0,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[A,1],p[C,0],p[I,0],p[A,0])]*r[A][48][0,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,0],p[C,0])]*r[A][30][0,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,1],p[C,0])]*r[A][48][0,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[C][3][0,14]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B8C1I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,8),(C,1),(I,14)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,0],p[C,0])]*r[A][30][0,3]*r[C][3][1,14]*r[I][2][14,0]
        hv += g[dei(p[A,0],p[A,1],p[I,0],p[C,0])]*r[A][15][0,3]*r[C][3][1,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,0],p[C,0])]*r[A][48][0,3]*r[C][3][1,14]*r[I][2][14,0]
        hv += g[dei(p[A,1],p[A,0],p[I,0],p[C,0])]*r[A][33][0,3]*r[C][3][1,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[A,0],p[C,0],p[I,0],p[A,1])]*r[A][30][0,3]*r[C][3][1,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[A,1],p[C,0],p[I,0],p[A,0])]*r[A][48][0,3]*r[C][3][1,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,0],p[C,0])]*r[A][30][0,3]*r[C][3][1,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,1],p[C,0])]*r[A][48][0,3]*r[C][3][1,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[C][3][1,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[C][3][1,14]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B8I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,8),(I,14)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,0],p[C,0])]*r[A][30][1,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += g[dei(p[A,0],p[A,1],p[I,0],p[C,0])]*r[A][15][1,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,0],p[C,0])]*r[A][48][1,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += g[dei(p[A,1],p[A,0],p[I,0],p[C,0])]*r[A][33][1,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[A,0],p[C,0],p[I,0],p[A,1])]*r[A][30][1,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[A,1],p[C,0],p[I,0],p[A,0])]*r[A][48][1,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,0],p[C,0])]*r[A][30][1,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,1],p[C,0])]*r[A][48][1,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[A,0],p[A,1])]*r[A][30][1,3]*r[C][3][0,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[A,1],p[A,0])]*r[A][48][1,3]*r[C][3][0,14]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B8C5I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,8),(C,5),(I,12)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,0],p[C,1])]*r[A][15][0,3]*r[C][5][5,14]*r[I][0][12,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,0],p[C,1])]*r[A][33][0,3]*r[C][5][5,14]*r[I][0][12,0]
        hv += -1/2*g[dei(p[A,0],p[C,1],p[I,0],p[A,1])]*r[A][15][0,3]*r[C][5][5,14]*r[I][0][12,0]
        hv += -1/2*g[dei(p[A,1],p[C,1],p[I,0],p[A,0])]*r[A][33][0,3]*r[C][5][5,14]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,0],p[C,1])]*r[A][15][0,3]*r[C][5][5,14]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,1],p[C,1])]*r[A][33][0,3]*r[C][5][5,14]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[A,0],p[A,1])]*r[A][15][0,3]*r[C][5][5,14]*r[I][0][12,0]
        hv += g[dei(p[I,0],p[C,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[C][5][5,14]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[A,1],p[A,0])]*r[A][33][0,3]*r[C][5][5,14]*r[I][0][12,0]
        hv += g[dei(p[I,0],p[C,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[C][5][5,14]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B8C2I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,8),(C,2),(I,14)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,0],p[C,1])]*r[A][30][0,3]*r[C][7][2,14]*r[I][2][14,0]
        hv += g[dei(p[A,0],p[A,1],p[I,0],p[C,1])]*r[A][15][0,3]*r[C][7][2,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,0],p[C,1])]*r[A][48][0,3]*r[C][7][2,14]*r[I][2][14,0]
        hv += g[dei(p[A,1],p[A,0],p[I,0],p[C,1])]*r[A][33][0,3]*r[C][7][2,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[A,0],p[C,1],p[I,0],p[A,1])]*r[A][30][0,3]*r[C][7][2,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[A,1],p[C,1],p[I,0],p[A,0])]*r[A][48][0,3]*r[C][7][2,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,0],p[C,1])]*r[A][30][0,3]*r[C][7][2,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,1],p[C,1])]*r[A][48][0,3]*r[C][7][2,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[C][7][2,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[C][7][2,14]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B8C3I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,8),(C,3),(I,14)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,0],p[C,1])]*r[A][30][0,3]*r[C][7][3,14]*r[I][2][14,0]
        hv += g[dei(p[A,0],p[A,1],p[I,0],p[C,1])]*r[A][15][0,3]*r[C][7][3,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,0],p[C,1])]*r[A][48][0,3]*r[C][7][3,14]*r[I][2][14,0]
        hv += g[dei(p[A,1],p[A,0],p[I,0],p[C,1])]*r[A][33][0,3]*r[C][7][3,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[A,0],p[C,1],p[I,0],p[A,1])]*r[A][30][0,3]*r[C][7][3,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[A,1],p[C,1],p[I,0],p[A,0])]*r[A][48][0,3]*r[C][7][3,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[A,1],p[A,0],p[C,1])]*r[A][30][0,3]*r[C][7][3,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,1],p[C,1])]*r[A][48][0,3]*r[C][7][3,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[C][7][3,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[C][7][3,14]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B8I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,2),(B,8),(I,13)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,1],p[C,0])]*r[A][24][2,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += g[dei(p[A,0],p[A,0],p[I,1],p[C,0])]*r[A][9][2,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[A,1],p[A,1],p[I,1],p[C,0])]*r[A][54][2,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += g[dei(p[A,1],p[A,1],p[I,1],p[C,0])]*r[A][39][2,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[A,0],p[C,0],p[I,1],p[A,0])]*r[A][24][2,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[A,1],p[C,0],p[I,1],p[A,1])]*r[A][54][2,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,0],p[C,0])]*r[A][24][2,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,1],p[C,0])]*r[A][54][2,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[A,0],p[A,0])]*r[A][24][2,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[A,1],p[A,1])]*r[A][54][2,3]*r[C][3][0,14]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B8I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,8),(I,13)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,1],p[C,0])]*r[A][30][0,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += g[dei(p[A,0],p[A,1],p[I,1],p[C,0])]*r[A][15][0,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,1],p[C,0])]*r[A][48][0,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += g[dei(p[A,1],p[A,0],p[I,1],p[C,0])]*r[A][33][0,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[A,0],p[C,0],p[I,1],p[A,1])]*r[A][30][0,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[A,1],p[C,0],p[I,1],p[A,0])]*r[A][48][0,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,0],p[C,0])]*r[A][30][0,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,1],p[C,0])]*r[A][48][0,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[C][3][0,14]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B8C1I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,8),(C,1),(I,13)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,1],p[C,0])]*r[A][30][0,3]*r[C][3][1,14]*r[I][6][13,0]
        hv += g[dei(p[A,0],p[A,1],p[I,1],p[C,0])]*r[A][15][0,3]*r[C][3][1,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,1],p[C,0])]*r[A][48][0,3]*r[C][3][1,14]*r[I][6][13,0]
        hv += g[dei(p[A,1],p[A,0],p[I,1],p[C,0])]*r[A][33][0,3]*r[C][3][1,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[A,0],p[C,0],p[I,1],p[A,1])]*r[A][30][0,3]*r[C][3][1,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[A,1],p[C,0],p[I,1],p[A,0])]*r[A][48][0,3]*r[C][3][1,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,0],p[C,0])]*r[A][30][0,3]*r[C][3][1,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,1],p[C,0])]*r[A][48][0,3]*r[C][3][1,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[C][3][1,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[C][3][1,14]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B8I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,1),(B,8),(I,13)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,1],p[C,0])]*r[A][30][1,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += g[dei(p[A,0],p[A,1],p[I,1],p[C,0])]*r[A][15][1,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,1],p[C,0])]*r[A][48][1,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += g[dei(p[A,1],p[A,0],p[I,1],p[C,0])]*r[A][33][1,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[A,0],p[C,0],p[I,1],p[A,1])]*r[A][30][1,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[A,1],p[C,0],p[I,1],p[A,0])]*r[A][48][1,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,0],p[C,0])]*r[A][30][1,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,1],p[C,0])]*r[A][48][1,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[A,0],p[A,1])]*r[A][30][1,3]*r[C][3][0,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[A,1],p[A,0])]*r[A][48][1,3]*r[C][3][0,14]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B8C5I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,8),(C,5),(I,11)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,1],p[C,1])]*r[A][15][0,3]*r[C][5][5,14]*r[I][4][11,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,1],p[C,1])]*r[A][33][0,3]*r[C][5][5,14]*r[I][4][11,0]
        hv += -1/2*g[dei(p[A,0],p[C,1],p[I,1],p[A,1])]*r[A][15][0,3]*r[C][5][5,14]*r[I][4][11,0]
        hv += -1/2*g[dei(p[A,1],p[C,1],p[I,1],p[A,0])]*r[A][33][0,3]*r[C][5][5,14]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,0],p[C,1])]*r[A][15][0,3]*r[C][5][5,14]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,1],p[C,1])]*r[A][33][0,3]*r[C][5][5,14]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[A,0],p[A,1])]*r[A][15][0,3]*r[C][5][5,14]*r[I][4][11,0]
        hv += g[dei(p[I,1],p[C,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[C][5][5,14]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[A,1],p[A,0])]*r[A][33][0,3]*r[C][5][5,14]*r[I][4][11,0]
        hv += g[dei(p[I,1],p[C,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[C][5][5,14]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B8C2I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,8),(C,2),(I,13)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,1],p[C,1])]*r[A][30][0,3]*r[C][7][2,14]*r[I][6][13,0]
        hv += g[dei(p[A,0],p[A,1],p[I,1],p[C,1])]*r[A][15][0,3]*r[C][7][2,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,1],p[C,1])]*r[A][48][0,3]*r[C][7][2,14]*r[I][6][13,0]
        hv += g[dei(p[A,1],p[A,0],p[I,1],p[C,1])]*r[A][33][0,3]*r[C][7][2,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[A,0],p[C,1],p[I,1],p[A,1])]*r[A][30][0,3]*r[C][7][2,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[A,1],p[C,1],p[I,1],p[A,0])]*r[A][48][0,3]*r[C][7][2,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,0],p[C,1])]*r[A][30][0,3]*r[C][7][2,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,1],p[C,1])]*r[A][48][0,3]*r[C][7][2,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[C][7][2,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[C][7][2,14]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B8C3I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(B,8),(C,3),(I,13)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[A,1],p[I,1],p[C,1])]*r[A][30][0,3]*r[C][7][3,14]*r[I][6][13,0]
        hv += g[dei(p[A,0],p[A,1],p[I,1],p[C,1])]*r[A][15][0,3]*r[C][7][3,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,1],p[C,1])]*r[A][48][0,3]*r[C][7][3,14]*r[I][6][13,0]
        hv += g[dei(p[A,1],p[A,0],p[I,1],p[C,1])]*r[A][33][0,3]*r[C][7][3,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[A,0],p[C,1],p[I,1],p[A,1])]*r[A][30][0,3]*r[C][7][3,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[A,1],p[C,1],p[I,1],p[A,0])]*r[A][48][0,3]*r[C][7][3,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[A,1],p[A,0],p[C,1])]*r[A][30][0,3]*r[C][7][3,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,1],p[C,1])]*r[A][48][0,3]*r[C][7][3,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[C][7][3,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[C][7][3,14]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B8I1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(B,8),(I,1)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += -1/2*g[dei(p[A,0],p[C,0],p[I,0],p[I,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][24][1,0]
        hv += -1/2*g[dei(p[A,0],p[C,0],p[I,1],p[I,1])]*r[A][2][13,3]*r[C][3][0,14]*r[I][54][1,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[I,0],p[C,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][24][1,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[I,1],p[C,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][54][1,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[A,0],p[I,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][24][1,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[A,0],p[I,1])]*r[A][2][13,3]*r[C][3][0,14]*r[I][54][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][24][1,0]
        hv += -1*g[dei(p[I,0],p[I,0],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][54][1,0]
        hv += -1*g[dei(p[I,1],p[I,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B8I2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(B,8),(I,2)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += -1/2*g[dei(p[A,0],p[C,0],p[I,0],p[I,1])]*r[A][2][13,3]*r[C][3][0,14]*r[I][30][2,0]
        hv += -1/2*g[dei(p[A,0],p[C,0],p[I,1],p[I,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][48][2,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[I,0],p[C,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][30][2,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[I,1],p[C,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][48][2,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[A,0],p[I,1])]*r[A][2][13,3]*r[C][3][0,14]*r[I][30][2,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[A,0],p[I,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][48][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][30][2,0]
        hv += -1*g[dei(p[I,0],p[I,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][48][2,0]
        hv += -1*g[dei(p[I,1],p[I,0],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B8I3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(B,8),(I,3)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += -1/2*g[dei(p[A,0],p[C,0],p[I,0],p[I,1])]*r[A][2][13,3]*r[C][3][0,14]*r[I][30][3,0]
        hv += -1/2*g[dei(p[A,0],p[C,0],p[I,1],p[I,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][48][3,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[I,0],p[C,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][30][3,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[I,1],p[C,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][48][3,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[A,0],p[I,1])]*r[A][2][13,3]*r[C][3][0,14]*r[I][30][3,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[A,0],p[I,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][48][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][30][3,0]
        hv += -1*g[dei(p[I,0],p[I,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][48][3,0]
        hv += -1*g[dei(p[I,1],p[I,0],p[A,0],p[C,0])]*r[A][2][13,3]*r[C][3][0,14]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B8I1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(B,8),(I,1)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += -1/2*g[dei(p[A,1],p[C,0],p[I,0],p[I,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][24][1,0]
        hv += -1/2*g[dei(p[A,1],p[C,0],p[I,1],p[I,1])]*r[A][6][14,3]*r[C][3][0,14]*r[I][54][1,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,0],p[C,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][24][1,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,1],p[C,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][54][1,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[A,1],p[I,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][24][1,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[A,1],p[I,1])]*r[A][6][14,3]*r[C][3][0,14]*r[I][54][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][24][1,0]
        hv += -1*g[dei(p[I,0],p[I,0],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][54][1,0]
        hv += -1*g[dei(p[I,1],p[I,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B8I2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(B,8),(I,2)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += -1/2*g[dei(p[A,1],p[C,0],p[I,0],p[I,1])]*r[A][6][14,3]*r[C][3][0,14]*r[I][30][2,0]
        hv += -1/2*g[dei(p[A,1],p[C,0],p[I,1],p[I,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][48][2,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,0],p[C,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][30][2,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,1],p[C,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][48][2,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[A,1],p[I,1])]*r[A][6][14,3]*r[C][3][0,14]*r[I][30][2,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[A,1],p[I,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][48][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][30][2,0]
        hv += -1*g[dei(p[I,0],p[I,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][48][2,0]
        hv += -1*g[dei(p[I,1],p[I,0],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B8I3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(B,8),(I,3)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += -1/2*g[dei(p[A,1],p[C,0],p[I,0],p[I,1])]*r[A][6][14,3]*r[C][3][0,14]*r[I][30][3,0]
        hv += -1/2*g[dei(p[A,1],p[C,0],p[I,1],p[I,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][48][3,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,0],p[C,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][30][3,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,1],p[C,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][48][3,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[A,1],p[I,1])]*r[A][6][14,3]*r[C][3][0,14]*r[I][30][3,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[A,1],p[I,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][48][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][30][3,0]
        hv += -1*g[dei(p[I,0],p[I,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][48][3,0]
        hv += -1*g[dei(p[I,1],p[I,0],p[A,1],p[C,0])]*r[A][6][14,3]*r[C][3][0,14]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B8I5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(B,8),(I,5)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += g[dei(p[A,0],p[I,1],p[I,0],p[C,0])]*r[A][0][11,3]*r[C][3][0,14]*r[I][27][5,0]
        hv += g[dei(p[A,0],p[I,0],p[I,1],p[C,0])]*r[A][0][11,3]*r[C][3][0,14]*r[I][45][5,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B8I5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(B,8),(I,5)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += g[dei(p[A,1],p[I,1],p[I,0],p[C,0])]*r[A][4][12,3]*r[C][3][0,14]*r[I][27][5,0]
        hv += g[dei(p[A,1],p[I,0],p[I,1],p[C,0])]*r[A][4][12,3]*r[C][3][0,14]*r[I][45][5,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5B8I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,5),(B,8),(I,12)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[I,0],p[A,0],p[A,0],p[C,0])]*r[A][21][5,3]*r[C][3][0,14]*r[I][0][12,0]
        hv += -1*g[dei(p[I,0],p[A,1],p[A,1],p[C,0])]*r[A][51][5,3]*r[C][3][0,14]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5B8I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,5),(B,8),(I,11)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[I,1],p[A,0],p[A,0],p[C,0])]*r[A][21][5,3]*r[C][3][0,14]*r[I][4][11,0]
        hv += -1*g[dei(p[I,1],p[A,1],p[A,1],p[C,0])]*r[A][51][5,3]*r[C][3][0,14]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B8I15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(B,8),(I,15)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += g[dei(p[I,0],p[A,0],p[I,0],p[C,0])]*r[A][1][10,3]*r[C][3][0,14]*r[I][11][15,0]
        hv += g[dei(p[I,1],p[A,0],p[I,1],p[C,0])]*r[A][1][10,3]*r[C][3][0,14]*r[I][41][15,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B8I15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(B,8),(I,15)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += g[dei(p[I,0],p[A,1],p[I,0],p[C,0])]*r[A][5][9,3]*r[C][3][0,14]*r[I][11][15,0]
        hv += g[dei(p[I,1],p[A,1],p[I,1],p[C,0])]*r[A][5][9,3]*r[C][3][0,14]*r[I][41][15,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B14I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,14),(I,7)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[B,0],p[C,0],p[B,1],p[I,0])]*r[B][29][14,8]*r[C][3][0,14]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[C,0],p[B,0],p[I,0])]*r[B][47][14,8]*r[C][3][0,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[B,1],p[C,0])]*r[B][29][14,8]*r[C][3][0,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[I,0],p[B,0],p[C,0])]*r[B][47][14,8]*r[C][3][0,14]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B14I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,14),(I,8)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[B,0],p[C,0],p[B,1],p[I,1])]*r[B][29][14,8]*r[C][3][0,14]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[C,0],p[B,0],p[I,1])]*r[B][47][14,8]*r[C][3][0,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[B,1],p[C,0])]*r[B][29][14,8]*r[C][3][0,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[I,1],p[B,0],p[C,0])]*r[B][47][14,8]*r[C][3][0,14]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B11I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,11),(I,9)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[B,0],p[I,0],p[B,0],p[C,0])]*r[B][11][11,8]*r[C][3][0,14]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B11I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,11),(I,10)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[B,0],p[I,1],p[B,0],p[C,0])]*r[B][11][11,8]*r[C][3][0,14]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B12I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,12),(I,9)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[B,0],p[I,0],p[B,1],p[C,0])]*r[B][17][12,8]*r[C][3][0,14]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B12I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,12),(I,10)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[B,0],p[I,1],p[B,1],p[C,0])]*r[B][17][12,8]*r[C][3][0,14]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B7I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,7),(I,14)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[B,0],p[B,1],p[I,0],p[C,0])]*r[B][15][7,8]*r[C][3][0,14]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B7I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,7),(I,13)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[B,0],p[B,1],p[I,1],p[C,0])]*r[B][15][7,8]*r[C][3][0,14]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C8I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,8),(I,14)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[B,1],p[C,0],p[I,0],p[C,1])]*r[B][6][0,8]*r[C][49][8,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[B,1],p[C,1],p[I,0],p[C,0])]*r[B][6][0,8]*r[C][31][8,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][49][8,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][31][8,14]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C8I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,8),(I,13)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += 1/2*g[dei(p[B,1],p[C,0],p[I,1],p[C,1])]*r[B][6][0,8]*r[C][49][8,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[B,1],p[C,1],p[I,1],p[C,0])]*r[B][6][0,8]*r[C][31][8,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][49][8,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][31][8,14]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B2I1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,2),(I,1)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,0],p[C,0],p[I,0],p[I,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][24][1,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[I,1],p[I,1])]*r[B][2][2,8]*r[C][3][0,14]*r[I][54][1,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[I,0],p[C,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][24][1,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[I,1],p[C,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][54][1,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[B,0],p[I,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][24][1,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[B,0],p[I,1])]*r[B][2][2,8]*r[C][3][0,14]*r[I][54][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[B,0],p[C,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][24][1,0]
        hv += -1*g[dei(p[I,0],p[I,0],p[B,0],p[C,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[B,0],p[C,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][54][1,0]
        hv += -1*g[dei(p[I,1],p[I,1],p[B,0],p[C,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B3I1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,3),(I,1)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,0],p[C,0],p[I,0],p[I,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][24][1,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[I,1],p[I,1])]*r[B][2][3,8]*r[C][3][0,14]*r[I][54][1,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[I,0],p[C,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][24][1,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[I,1],p[C,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][54][1,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[B,0],p[I,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][24][1,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[B,0],p[I,1])]*r[B][2][3,8]*r[C][3][0,14]*r[I][54][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[B,0],p[C,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][24][1,0]
        hv += -1*g[dei(p[I,0],p[I,0],p[B,0],p[C,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[B,0],p[C,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][54][1,0]
        hv += -1*g[dei(p[I,1],p[I,1],p[B,0],p[C,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B2I2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,2),(I,2)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,0],p[C,0],p[I,0],p[I,1])]*r[B][2][2,8]*r[C][3][0,14]*r[I][30][2,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[I,1],p[I,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][48][2,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[I,0],p[C,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][30][2,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[I,1],p[C,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][48][2,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[B,0],p[I,1])]*r[B][2][2,8]*r[C][3][0,14]*r[I][30][2,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[B,0],p[I,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][48][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,0],p[C,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][30][2,0]
        hv += -1*g[dei(p[I,0],p[I,1],p[B,0],p[C,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,0],p[C,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][48][2,0]
        hv += -1*g[dei(p[I,1],p[I,0],p[B,0],p[C,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B2I3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,2),(I,3)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,0],p[C,0],p[I,0],p[I,1])]*r[B][2][2,8]*r[C][3][0,14]*r[I][30][3,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[I,1],p[I,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][48][3,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[I,0],p[C,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][30][3,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[I,1],p[C,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][48][3,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[B,0],p[I,1])]*r[B][2][2,8]*r[C][3][0,14]*r[I][30][3,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[B,0],p[I,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][48][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,0],p[C,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][30][3,0]
        hv += -1*g[dei(p[I,0],p[I,1],p[B,0],p[C,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,0],p[C,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][48][3,0]
        hv += -1*g[dei(p[I,1],p[I,0],p[B,0],p[C,0])]*r[B][2][2,8]*r[C][3][0,14]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B3I2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,3),(I,2)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,0],p[C,0],p[I,0],p[I,1])]*r[B][2][3,8]*r[C][3][0,14]*r[I][30][2,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[I,1],p[I,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][48][2,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[I,0],p[C,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][30][2,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[I,1],p[C,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][48][2,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[B,0],p[I,1])]*r[B][2][3,8]*r[C][3][0,14]*r[I][30][2,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[B,0],p[I,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][48][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,0],p[C,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][30][2,0]
        hv += -1*g[dei(p[I,0],p[I,1],p[B,0],p[C,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,0],p[C,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][48][2,0]
        hv += -1*g[dei(p[I,1],p[I,0],p[B,0],p[C,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B3I3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,3),(I,3)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,0],p[C,0],p[I,0],p[I,1])]*r[B][2][3,8]*r[C][3][0,14]*r[I][30][3,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[I,1],p[I,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][48][3,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[I,0],p[C,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][30][3,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[I,1],p[C,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][48][3,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[B,0],p[I,1])]*r[B][2][3,8]*r[C][3][0,14]*r[I][30][3,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[B,0],p[I,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][48][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,0],p[C,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][30][3,0]
        hv += -1*g[dei(p[I,0],p[I,1],p[B,0],p[C,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,0],p[C,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][48][3,0]
        hv += -1*g[dei(p[I,1],p[I,0],p[B,0],p[C,0])]*r[B][2][3,8]*r[C][3][0,14]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(I,1)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,1],p[C,0],p[I,0],p[I,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][24][1,0]
        hv += -1/2*g[dei(p[B,1],p[C,0],p[I,1],p[I,1])]*r[B][6][0,8]*r[C][3][0,14]*r[I][54][1,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[I,0],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][24][1,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[I,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][54][1,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[B,1],p[I,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][24][1,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[B,1],p[I,1])]*r[B][6][0,8]*r[C][3][0,14]*r[I][54][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][24][1,0]
        hv += -1*g[dei(p[I,0],p[I,0],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][54][1,0]
        hv += -1*g[dei(p[I,1],p[I,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C1I1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,1),(I,1)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,1],p[C,0],p[I,0],p[I,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][24][1,0]
        hv += -1/2*g[dei(p[B,1],p[C,0],p[I,1],p[I,1])]*r[B][6][0,8]*r[C][3][1,14]*r[I][54][1,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[I,0],p[C,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][24][1,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[I,1],p[C,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][54][1,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[B,1],p[I,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][24][1,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[B,1],p[I,1])]*r[B][6][0,8]*r[C][3][1,14]*r[I][54][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][24][1,0]
        hv += -1*g[dei(p[I,0],p[I,0],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][54][1,0]
        hv += -1*g[dei(p[I,1],p[I,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B1I1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,1),(I,1)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,1],p[C,0],p[I,0],p[I,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][24][1,0]
        hv += -1/2*g[dei(p[B,1],p[C,0],p[I,1],p[I,1])]*r[B][6][1,8]*r[C][3][0,14]*r[I][54][1,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[I,0],p[C,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][24][1,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[I,1],p[C,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][54][1,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[B,1],p[I,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][24][1,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[B,1],p[I,1])]*r[B][6][1,8]*r[C][3][0,14]*r[I][54][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[B,1],p[C,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][24][1,0]
        hv += -1*g[dei(p[I,0],p[I,0],p[B,1],p[C,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[B,1],p[C,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][54][1,0]
        hv += -1*g[dei(p[I,1],p[I,1],p[B,1],p[C,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(I,2)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,1],p[C,0],p[I,0],p[I,1])]*r[B][6][0,8]*r[C][3][0,14]*r[I][30][2,0]
        hv += -1/2*g[dei(p[B,1],p[C,0],p[I,1],p[I,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][48][2,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[I,0],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][30][2,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[I,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][48][2,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[B,1],p[I,1])]*r[B][6][0,8]*r[C][3][0,14]*r[I][30][2,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[B,1],p[I,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][48][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][30][2,0]
        hv += -1*g[dei(p[I,0],p[I,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][48][2,0]
        hv += -1*g[dei(p[I,1],p[I,0],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(I,3)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,1],p[C,0],p[I,0],p[I,1])]*r[B][6][0,8]*r[C][3][0,14]*r[I][30][3,0]
        hv += -1/2*g[dei(p[B,1],p[C,0],p[I,1],p[I,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][48][3,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[I,0],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][30][3,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[I,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][48][3,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[B,1],p[I,1])]*r[B][6][0,8]*r[C][3][0,14]*r[I][30][3,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[B,1],p[I,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][48][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][30][3,0]
        hv += -1*g[dei(p[I,0],p[I,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][48][3,0]
        hv += -1*g[dei(p[I,1],p[I,0],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C1I2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,1),(I,2)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,1],p[C,0],p[I,0],p[I,1])]*r[B][6][0,8]*r[C][3][1,14]*r[I][30][2,0]
        hv += -1/2*g[dei(p[B,1],p[C,0],p[I,1],p[I,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][48][2,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[I,0],p[C,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][30][2,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[I,1],p[C,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][48][2,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[B,1],p[I,1])]*r[B][6][0,8]*r[C][3][1,14]*r[I][30][2,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[B,1],p[I,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][48][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][30][2,0]
        hv += -1*g[dei(p[I,0],p[I,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][48][2,0]
        hv += -1*g[dei(p[I,1],p[I,0],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C1I3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,1),(I,3)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,1],p[C,0],p[I,0],p[I,1])]*r[B][6][0,8]*r[C][3][1,14]*r[I][30][3,0]
        hv += -1/2*g[dei(p[B,1],p[C,0],p[I,1],p[I,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][48][3,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[I,0],p[C,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][30][3,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[I,1],p[C,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][48][3,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[B,1],p[I,1])]*r[B][6][0,8]*r[C][3][1,14]*r[I][30][3,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[B,1],p[I,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][48][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][30][3,0]
        hv += -1*g[dei(p[I,0],p[I,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][48][3,0]
        hv += -1*g[dei(p[I,1],p[I,0],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][1,14]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B1I2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,1),(I,2)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,1],p[C,0],p[I,0],p[I,1])]*r[B][6][1,8]*r[C][3][0,14]*r[I][30][2,0]
        hv += -1/2*g[dei(p[B,1],p[C,0],p[I,1],p[I,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][48][2,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[I,0],p[C,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][30][2,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[I,1],p[C,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][48][2,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[B,1],p[I,1])]*r[B][6][1,8]*r[C][3][0,14]*r[I][30][2,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[B,1],p[I,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][48][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,1],p[C,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][30][2,0]
        hv += -1*g[dei(p[I,0],p[I,1],p[B,1],p[C,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,1],p[C,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][48][2,0]
        hv += -1*g[dei(p[I,1],p[I,0],p[B,1],p[C,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B1I3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,1),(I,3)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,1],p[C,0],p[I,0],p[I,1])]*r[B][6][1,8]*r[C][3][0,14]*r[I][30][3,0]
        hv += -1/2*g[dei(p[B,1],p[C,0],p[I,1],p[I,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][48][3,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[I,0],p[C,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][30][3,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[I,1],p[C,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][48][3,0]
        hv += 1/2*g[dei(p[I,0],p[C,0],p[B,1],p[I,1])]*r[B][6][1,8]*r[C][3][0,14]*r[I][30][3,0]
        hv += 1/2*g[dei(p[I,1],p[C,0],p[B,1],p[I,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][48][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,1],p[C,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][30][3,0]
        hv += -1*g[dei(p[I,0],p[I,1],p[B,1],p[C,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,1],p[C,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][48][3,0]
        hv += -1*g[dei(p[I,1],p[I,0],p[B,1],p[C,0])]*r[B][6][1,8]*r[C][3][0,14]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C2I1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,2),(I,1)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,1],p[C,1],p[I,0],p[I,0])]*r[B][6][0,8]*r[C][7][2,14]*r[I][24][1,0]
        hv += -1/2*g[dei(p[B,1],p[C,1],p[I,1],p[I,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][54][1,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[I,0],p[C,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][24][1,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[I,1],p[C,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][54][1,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[B,1],p[I,0])]*r[B][6][0,8]*r[C][7][2,14]*r[I][24][1,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[B,1],p[I,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][54][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][24][1,0]
        hv += -1*g[dei(p[I,0],p[I,0],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][54][1,0]
        hv += -1*g[dei(p[I,1],p[I,1],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C3I1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,3),(I,1)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,1],p[C,1],p[I,0],p[I,0])]*r[B][6][0,8]*r[C][7][3,14]*r[I][24][1,0]
        hv += -1/2*g[dei(p[B,1],p[C,1],p[I,1],p[I,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][54][1,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[I,0],p[C,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][24][1,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[I,1],p[C,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][54][1,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[B,1],p[I,0])]*r[B][6][0,8]*r[C][7][3,14]*r[I][24][1,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[B,1],p[I,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][54][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][24][1,0]
        hv += -1*g[dei(p[I,0],p[I,0],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][54][1,0]
        hv += -1*g[dei(p[I,1],p[I,1],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C2I2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,2),(I,2)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,1],p[C,1],p[I,0],p[I,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][30][2,0]
        hv += -1/2*g[dei(p[B,1],p[C,1],p[I,1],p[I,0])]*r[B][6][0,8]*r[C][7][2,14]*r[I][48][2,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[I,0],p[C,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][30][2,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[I,1],p[C,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][48][2,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[B,1],p[I,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][30][2,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[B,1],p[I,0])]*r[B][6][0,8]*r[C][7][2,14]*r[I][48][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][30][2,0]
        hv += -1*g[dei(p[I,0],p[I,1],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][48][2,0]
        hv += -1*g[dei(p[I,1],p[I,0],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C2I3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,2),(I,3)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,1],p[C,1],p[I,0],p[I,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][30][3,0]
        hv += -1/2*g[dei(p[B,1],p[C,1],p[I,1],p[I,0])]*r[B][6][0,8]*r[C][7][2,14]*r[I][48][3,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[I,0],p[C,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][30][3,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[I,1],p[C,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][48][3,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[B,1],p[I,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][30][3,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[B,1],p[I,0])]*r[B][6][0,8]*r[C][7][2,14]*r[I][48][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][30][3,0]
        hv += -1*g[dei(p[I,0],p[I,1],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][48][3,0]
        hv += -1*g[dei(p[I,1],p[I,0],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][2,14]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C3I2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,3),(I,2)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,1],p[C,1],p[I,0],p[I,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][30][2,0]
        hv += -1/2*g[dei(p[B,1],p[C,1],p[I,1],p[I,0])]*r[B][6][0,8]*r[C][7][3,14]*r[I][48][2,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[I,0],p[C,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][30][2,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[I,1],p[C,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][48][2,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[B,1],p[I,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][30][2,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[B,1],p[I,0])]*r[B][6][0,8]*r[C][7][3,14]*r[I][48][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][30][2,0]
        hv += -1*g[dei(p[I,0],p[I,1],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][48][2,0]
        hv += -1*g[dei(p[I,1],p[I,0],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C3I3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,3),(I,3)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[B,1],p[C,1],p[I,0],p[I,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][30][3,0]
        hv += -1/2*g[dei(p[B,1],p[C,1],p[I,1],p[I,0])]*r[B][6][0,8]*r[C][7][3,14]*r[I][48][3,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[I,0],p[C,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][30][3,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[I,1],p[C,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][48][3,0]
        hv += 1/2*g[dei(p[I,0],p[C,1],p[B,1],p[I,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][30][3,0]
        hv += 1/2*g[dei(p[I,1],p[C,1],p[B,1],p[I,0])]*r[B][6][0,8]*r[C][7][3,14]*r[I][48][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][30][3,0]
        hv += -1*g[dei(p[I,0],p[I,1],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][48][3,0]
        hv += -1*g[dei(p[I,1],p[I,0],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][7][3,14]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B4I5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,4),(I,5)]))
        hv = 0.0
        
        hv += g[dei(p[B,0],p[I,1],p[I,0],p[C,0])]*r[B][0][4,8]*r[C][3][0,14]*r[I][27][5,0]
        hv += g[dei(p[B,0],p[I,0],p[I,1],p[C,0])]*r[B][0][4,8]*r[C][3][0,14]*r[I][45][5,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C13I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,13),(I,7)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += g[dei(p[C,0],p[C,1],p[B,1],p[I,0])]*r[B][6][0,8]*r[C][15][13,14]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C13I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,13),(I,8)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += g[dei(p[C,0],p[C,1],p[B,1],p[I,1])]*r[B][6][0,8]*r[C][15][13,14]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C12I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,12),(I,9)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1*g[dei(p[C,0],p[I,0],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][12][12,14]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C11I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,11),(I,9)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1*g[dei(p[C,0],p[I,0],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][18][11,14]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C12I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,12),(I,10)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1*g[dei(p[C,0],p[I,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][12][12,14]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C11I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,11),(I,10)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1*g[dei(p[C,0],p[I,1],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][18][11,14]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C15I6(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,15),(I,6)]))
        hv = 0.0
        
        hv += g[dei(p[C,0],p[I,0],p[B,1],p[I,0])]*r[B][6][0,8]*r[C][0][15,14]*r[I][22][6,0]
        hv += g[dei(p[C,0],p[I,1],p[B,1],p[I,1])]*r[B][6][0,8]*r[C][0][15,14]*r[I][52][6,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B9I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,9),(I,12)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[I,0],p[B,1],p[B,0],p[C,0])]*r[B][27][9,8]*r[C][3][0,14]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B10I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,10),(I,12)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[I,0],p[B,1],p[B,1],p[C,0])]*r[B][51][10,8]*r[C][3][0,14]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B9I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,9),(I,11)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[I,1],p[B,1],p[B,0],p[C,0])]*r[B][27][9,8]*r[C][3][0,14]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B10I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,10),(I,11)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[I,1],p[B,1],p[B,1],p[C,0])]*r[B][51][10,8]*r[C][3][0,14]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C10I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,10),(I,12)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1*g[dei(p[I,0],p[C,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][28][10,14]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C9I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,9),(I,12)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1*g[dei(p[I,0],p[C,1],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][52][9,14]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C10I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,10),(I,11)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1*g[dei(p[I,1],p[C,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][28][10,14]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C9I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,9),(I,11)]))
        hv = 0.0
        sket = sign([C,I])
        
        hv += -1*g[dei(p[I,1],p[C,1],p[B,1],p[C,1])]*r[B][6][0,8]*r[C][52][9,14]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3C5I4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(C,5),(I,4)]))
        hv = 0.0
        
        hv += g[dei(p[I,0],p[C,1],p[B,1],p[I,1])]*r[B][6][0,8]*r[C][5][5,14]*r[I][18][4,0]
        hv += g[dei(p[I,1],p[C,1],p[B,1],p[I,0])]*r[B][6][0,8]*r[C][5][5,14]*r[I][36][4,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B6I15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,3),(B,6),(I,15)]))
        hv = 0.0
        
        hv += g[dei(p[I,0],p[B,1],p[I,0],p[C,0])]*r[B][5][6,8]*r[C][3][0,14]*r[I][11][15,0]
        hv += g[dei(p[I,1],p[B,1],p[I,1],p[C,0])]*r[B][5][6,8]*r[C][3][0,14]*r[I][41][15,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A15B6(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,15),(B,6)]))
    hv = 0.0
    
    hv += g[dei(p[A,0],p[B,1],p[A,1],p[C,0])]*r[A][17][15,3]*r[B][5][6,8]*r[C][3][0,14]
    hv += g[dei(p[A,1],p[B,1],p[A,0],p[C,0])]*r[A][35][15,3]*r[B][5][6,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A15B6C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,15),(B,6),(C,1)]))
    hv = 0.0
    
    hv += g[dei(p[A,0],p[B,1],p[A,1],p[C,0])]*r[A][17][15,3]*r[B][5][6,8]*r[C][3][1,14]
    hv += g[dei(p[A,1],p[B,1],p[A,0],p[C,0])]*r[A][35][15,3]*r[B][5][6,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A15B6C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,15),(B,6),(C,2)]))
    hv = 0.0
    
    hv += g[dei(p[A,0],p[B,1],p[A,1],p[C,1])]*r[A][17][15,3]*r[B][5][6,8]*r[C][7][2,14]
    hv += g[dei(p[A,1],p[B,1],p[A,0],p[C,1])]*r[A][35][15,3]*r[B][5][6,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A15B6C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,15),(B,6),(C,3)]))
    hv = 0.0
    
    hv += g[dei(p[A,0],p[B,1],p[A,1],p[C,1])]*r[A][17][15,3]*r[B][5][6,8]*r[C][7][3,14]
    hv += g[dei(p[A,1],p[B,1],p[A,0],p[C,1])]*r[A][35][15,3]*r[B][5][6,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][24][2,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][9][2,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][54][2,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][39][2,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,0])]*r[A][24][2,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,1])]*r[A][54][2,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,0])]*r[A][24][2,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,0])]*r[A][54][2,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][2][2,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B2C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,2),(C,1)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][24][2,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][9][2,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][54][2,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][39][2,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,0])]*r[A][24][2,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,1])]*r[A][54][2,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,0])]*r[A][24][2,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,0])]*r[A][54][2,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][2][2,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,3)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][24][2,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][9][2,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][54][2,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][39][2,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,0])]*r[A][24][2,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,1])]*r[A][54][2,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,0])]*r[A][24][2,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,0])]*r[A][54][2,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][2][3,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B3C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,3),(C,1)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][24][2,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,0],p[C,0])]*r[A][9][2,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][54][2,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,0],p[C,0])]*r[A][39][2,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,0])]*r[A][24][2,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,1])]*r[A][54][2,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,0])]*r[A][24][2,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,0])]*r[A][54][2,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][2][3,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B4C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,4),(C,5)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][9][2,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][39][2,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,0])]*r[A][9][2,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,1])]*r[A][39][2,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,1])]*r[A][9][2,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,1])]*r[A][39][2,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][9][2,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][39][2,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][0][4,8]*r[C][5][5,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B2C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,2),(C,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][24][2,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][9][2,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][54][2,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][39][2,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,0])]*r[A][24][2,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,1])]*r[A][54][2,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,1])]*r[A][24][2,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,1])]*r[A][54][2,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][2][2,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B2C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,2),(C,3)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][24][2,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][9][2,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][54][2,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][39][2,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,0])]*r[A][24][2,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,1])]*r[A][54][2,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,1])]*r[A][24][2,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,1])]*r[A][54][2,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][2][2,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B3C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,3),(C,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][24][2,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][9][2,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][54][2,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][39][2,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,0])]*r[A][24][2,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,1])]*r[A][54][2,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,1])]*r[A][24][2,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,1])]*r[A][54][2,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][2][3,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B3C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,3),(C,3)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][24][2,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,0],p[C,1])]*r[A][9][2,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][54][2,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,0],p[C,1])]*r[A][39][2,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,0])]*r[A][24][2,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,1])]*r[A][54][2,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[C,1])]*r[A][24][2,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,1],p[C,1])]*r[A][54][2,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][2][3,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][30][0,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][15][0,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][48][0,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][33][0,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,1])]*r[A][30][0,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,0])]*r[A][48][0,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,0])]*r[A][30][0,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,0])]*r[A][48][0,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][2][2,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,2),(C,1)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][30][0,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][15][0,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][48][0,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][33][0,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,1])]*r[A][30][0,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,0])]*r[A][48][0,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,0])]*r[A][30][0,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,0])]*r[A][48][0,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][2][2,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,3)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][30][0,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][15][0,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][48][0,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][33][0,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,1])]*r[A][30][0,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,0])]*r[A][48][0,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,0])]*r[A][30][0,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,0])]*r[A][48][0,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][2][3,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,3),(C,1)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][30][0,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][15][0,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][48][0,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][33][0,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,1])]*r[A][30][0,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,0])]*r[A][48][0,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,0])]*r[A][30][0,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,0])]*r[A][48][0,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][2][3,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][30][1,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][15][1,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][48][1,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][33][1,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,1])]*r[A][30][1,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,0])]*r[A][48][1,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,0])]*r[A][30][1,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,0])]*r[A][48][1,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][2][2,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][2][2,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B2C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,2),(C,1)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][30][1,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][15][1,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][48][1,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][33][1,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,1])]*r[A][30][1,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,0])]*r[A][48][1,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,0])]*r[A][30][1,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,0])]*r[A][48][1,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][2][2,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][2][2,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,3)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][30][1,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][15][1,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][48][1,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][33][1,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,1])]*r[A][30][1,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,0])]*r[A][48][1,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,0])]*r[A][30][1,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,0])]*r[A][48][1,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][2][3,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][2][3,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B3C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,3),(C,1)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][30][1,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,0],p[C,0])]*r[A][15][1,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][48][1,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,0],p[C,0])]*r[A][33][1,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[A,1])]*r[A][30][1,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[A,0])]*r[A][48][1,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,0])]*r[A][30][1,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,0])]*r[A][48][1,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][2][3,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][2][3,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B4C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,4),(C,5)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][15][0,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][33][0,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,1])]*r[A][15][0,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,0])]*r[A][33][0,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,1])]*r[A][15][0,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,1])]*r[A][33][0,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][15][0,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][33][0,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][0][4,8]*r[C][5][5,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B4C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,4),(C,5)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][15][1,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][33][1,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,1])]*r[A][15][1,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,0])]*r[A][33][1,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,1])]*r[A][15][1,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,1])]*r[A][33][1,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][15][1,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][33][1,3]*r[B][0][4,8]*r[C][5][5,14]
    hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][0][4,8]*r[C][5][5,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,2),(C,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][30][0,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][15][0,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][48][0,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][33][0,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,1])]*r[A][30][0,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,0])]*r[A][48][0,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,1])]*r[A][30][0,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,1])]*r[A][48][0,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][2][2,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,2),(C,3)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][30][0,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][15][0,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][48][0,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][33][0,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,1])]*r[A][30][0,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,0])]*r[A][48][0,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,1])]*r[A][30][0,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,1])]*r[A][48][0,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][2][2,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,3),(C,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][30][0,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][15][0,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][48][0,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][33][0,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,1])]*r[A][30][0,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,0])]*r[A][48][0,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,1])]*r[A][30][0,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,1])]*r[A][48][0,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][2][3,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,3),(C,3)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][30][0,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][15][0,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][48][0,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][33][0,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,1])]*r[A][30][0,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,0])]*r[A][48][0,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,1])]*r[A][30][0,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,1])]*r[A][48][0,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][2][3,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B2C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,2),(C,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][30][1,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][15][1,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][48][1,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][33][1,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,1])]*r[A][30][1,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,0])]*r[A][48][1,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,1])]*r[A][30][1,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,1])]*r[A][48][1,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][2][2,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][2][2,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B2C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,2),(C,3)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][30][1,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][15][1,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][48][1,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][33][1,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,1])]*r[A][30][1,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,0])]*r[A][48][1,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,1])]*r[A][30][1,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,1])]*r[A][48][1,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][2][2,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][2][2,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B3C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,3),(C,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][30][1,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][15][1,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][48][1,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][33][1,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,1])]*r[A][30][1,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,0])]*r[A][48][1,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,1])]*r[A][30][1,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,1])]*r[A][48][1,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][2][3,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][2][3,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B3C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,3),(C,3)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][30][1,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,0],p[C,1])]*r[A][15][1,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][48][1,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,0],p[C,1])]*r[A][33][1,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[A,1])]*r[A][30][1,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[A,0])]*r[A][48][1,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,0],p[A,1],p[A,0],p[C,1])]*r[A][30][1,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[C,1])]*r[A][48][1,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][2][3,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][2][3,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][24][2,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][9][2,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][54][2,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][39][2,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,0])]*r[A][24][2,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,1])]*r[A][54][2,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,0])]*r[A][24][2,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,0])]*r[A][54][2,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][6][0,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(C,1)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][24][2,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][9][2,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][54][2,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][39][2,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,0])]*r[A][24][2,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,1])]*r[A][54][2,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,0])]*r[A][24][2,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,0])]*r[A][54][2,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][6][0,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,1)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][24][2,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][9][2,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][54][2,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][39][2,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,0])]*r[A][24][2,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,1])]*r[A][54][2,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,0])]*r[A][24][2,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,0])]*r[A][54][2,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][6][1,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B1C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,1),(C,1)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][24][2,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,1],p[C,0])]*r[A][9][2,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][54][2,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,1],p[C,0])]*r[A][39][2,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,0])]*r[A][24][2,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,1])]*r[A][54][2,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,0])]*r[A][24][2,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,0])]*r[A][54][2,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][6][1,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(C,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][24][2,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][9][2,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][54][2,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][39][2,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,0])]*r[A][24][2,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,1])]*r[A][54][2,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,1])]*r[A][24][2,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,1])]*r[A][54][2,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][6][0,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(C,3)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][24][2,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][9][2,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][54][2,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][39][2,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,0])]*r[A][24][2,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,1])]*r[A][54][2,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,1])]*r[A][24][2,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,1])]*r[A][54][2,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][6][0,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B1C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,1),(C,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][24][2,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][9][2,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][54][2,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][39][2,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,0])]*r[A][24][2,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,1])]*r[A][54][2,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,1])]*r[A][24][2,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,1])]*r[A][54][2,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][6][1,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B1C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,1),(C,3)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][24][2,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,0],p[A,0],p[B,1],p[C,1])]*r[A][9][2,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][54][2,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,1],p[A,1],p[B,1],p[C,1])]*r[A][39][2,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,0])]*r[A][24][2,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,1])]*r[A][54][2,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,0],p[C,1])]*r[A][24][2,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,1],p[C,1])]*r[A][54][2,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][6][1,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][30][0,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][15][0,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][48][0,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][33][0,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,1])]*r[A][30][0,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,0])]*r[A][48][0,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,0])]*r[A][30][0,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,0])]*r[A][48][0,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][6][0,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(C,1)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][30][0,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][15][0,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][48][0,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][33][0,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,1])]*r[A][30][0,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,0])]*r[A][48][0,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,0])]*r[A][30][0,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,0])]*r[A][48][0,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][6][0,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,1)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][30][0,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][15][0,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][48][0,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][33][0,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,1])]*r[A][30][0,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,0])]*r[A][48][0,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,0])]*r[A][30][0,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,0])]*r[A][48][0,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][6][1,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,1),(C,1)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][30][0,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][15][0,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][48][0,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][33][0,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,1])]*r[A][30][0,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,0])]*r[A][48][0,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,0])]*r[A][30][0,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,0])]*r[A][48][0,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][6][1,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][30][1,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][15][1,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][48][1,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][33][1,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,1])]*r[A][30][1,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,0])]*r[A][48][1,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,0])]*r[A][30][1,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,0])]*r[A][48][1,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][6][0,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][6][0,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(C,1)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][30][1,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][15][1,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][48][1,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][33][1,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,1])]*r[A][30][1,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,0])]*r[A][48][1,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,0])]*r[A][30][1,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,0])]*r[A][48][1,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][6][0,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][6][0,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,1)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][30][1,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][15][1,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][48][1,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][33][1,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,1])]*r[A][30][1,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,0])]*r[A][48][1,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,0])]*r[A][30][1,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,0])]*r[A][48][1,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][6][1,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][6][1,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B1C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,1),(C,1)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][30][1,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,1],p[C,0])]*r[A][15][1,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][48][1,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,1],p[C,0])]*r[A][33][1,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[A,1])]*r[A][30][1,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[A,0])]*r[A][48][1,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,0])]*r[A][30][1,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,0])]*r[A][48][1,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][6][1,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][6][1,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(C,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][30][0,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][15][0,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][48][0,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][33][0,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,1])]*r[A][30][0,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,0])]*r[A][48][0,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,1])]*r[A][30][0,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,1])]*r[A][48][0,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][6][0,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(C,3)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][30][0,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][15][0,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][48][0,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][33][0,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,1])]*r[A][30][0,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,0])]*r[A][48][0,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,1])]*r[A][30][0,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,1])]*r[A][48][0,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][6][0,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,1),(C,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][30][0,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][15][0,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][48][0,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][33][0,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,1])]*r[A][30][0,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,0])]*r[A][48][0,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,1])]*r[A][30][0,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,1])]*r[A][48][0,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][6][1,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,1),(C,3)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][30][0,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][15][0,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][48][0,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][33][0,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,1])]*r[A][30][0,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,0])]*r[A][48][0,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,1])]*r[A][30][0,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,1])]*r[A][48][0,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][6][1,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(C,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][30][1,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][15][1,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][48][1,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][33][1,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,1])]*r[A][30][1,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,0])]*r[A][48][1,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,1])]*r[A][30][1,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,1])]*r[A][48][1,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][6][0,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][6][0,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(C,3)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][30][1,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][15][1,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][48][1,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][33][1,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,1])]*r[A][30][1,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,0])]*r[A][48][1,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,1])]*r[A][30][1,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,1])]*r[A][48][1,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][6][0,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][6][0,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B1C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,1),(C,2)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][30][1,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][15][1,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][48][1,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][33][1,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,1])]*r[A][30][1,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,0])]*r[A][48][1,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,1])]*r[A][30][1,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,1])]*r[A][48][1,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][6][1,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][6][1,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B1C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,1),(C,3)]))
    hv = 0.0
    
    hv += -1/2*g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][30][1,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,0],p[A,1],p[B,1],p[C,1])]*r[A][15][1,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][48][1,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += -1*g[dei(p[A,1],p[A,0],p[B,1],p[C,1])]*r[A][33][1,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[A,1])]*r[A][30][1,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[A,0])]*r[A][48][1,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[A,0],p[C,1])]*r[A][30][1,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[A,1],p[C,1])]*r[A][48][1,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][6][1,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][6][1,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,9)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[A,0],p[B,1],p[B,0],p[C,0])]*r[A][0][11,3]*r[B][27][9,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B9C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,9),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[A,0],p[B,1],p[B,0],p[C,0])]*r[A][0][11,3]*r[B][27][9,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B7C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,7),(C,5)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,0],p[B,1],p[B,0],p[C,1])]*r[A][0][11,3]*r[B][15][7,8]*r[C][5][5,14]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[B,0],p[B,1])]*r[A][0][11,3]*r[B][15][7,8]*r[C][5][5,14]
    hv += -1/2*g[dei(p[B,0],p[B,1],p[A,0],p[C,1])]*r[A][0][11,3]*r[B][15][7,8]*r[C][5][5,14]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[A,0],p[B,1])]*r[A][0][11,3]*r[B][15][7,8]*r[C][5][5,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B9C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,9),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[A,0],p[B,1],p[B,0],p[C,1])]*r[A][0][11,3]*r[B][27][9,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B9C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,9),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[A,0],p[B,1],p[B,0],p[C,1])]*r[A][0][11,3]*r[B][27][9,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,10)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[A,0],p[B,1],p[B,1],p[C,0])]*r[A][0][11,3]*r[B][51][10,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B10C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,10),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[A,0],p[B,1],p[B,1],p[C,0])]*r[A][0][11,3]*r[B][51][10,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B10C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,10),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[A,0],p[B,1],p[B,1],p[C,1])]*r[A][0][11,3]*r[B][51][10,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B10C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,10),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[A,0],p[B,1],p[B,1],p[C,1])]*r[A][0][11,3]*r[B][51][10,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,9)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[A,1],p[B,1],p[B,0],p[C,0])]*r[A][4][12,3]*r[B][27][9,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B9C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,9),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[A,1],p[B,1],p[B,0],p[C,0])]*r[A][4][12,3]*r[B][27][9,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B7C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,7),(C,5)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,1],p[B,1],p[B,0],p[C,1])]*r[A][4][12,3]*r[B][15][7,8]*r[C][5][5,14]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[B,0],p[B,1])]*r[A][4][12,3]*r[B][15][7,8]*r[C][5][5,14]
    hv += -1/2*g[dei(p[B,0],p[B,1],p[A,1],p[C,1])]*r[A][4][12,3]*r[B][15][7,8]*r[C][5][5,14]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[A,1],p[B,1])]*r[A][4][12,3]*r[B][15][7,8]*r[C][5][5,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B9C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,9),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[A,1],p[B,1],p[B,0],p[C,1])]*r[A][4][12,3]*r[B][27][9,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B9C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,9),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[A,1],p[B,1],p[B,0],p[C,1])]*r[A][4][12,3]*r[B][27][9,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,10)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[A,1],p[B,1],p[B,1],p[C,0])]*r[A][4][12,3]*r[B][51][10,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B10C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,10),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[A,1],p[B,1],p[B,1],p[C,0])]*r[A][4][12,3]*r[B][51][10,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B10C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,10),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[A,1],p[B,1],p[B,1],p[C,1])]*r[A][4][12,3]*r[B][51][10,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B10C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,10),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[A,1],p[B,1],p[B,1],p[C,1])]*r[A][4][12,3]*r[B][51][10,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A4B2C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,4),(B,2),(C,5)]))
    hv = 0.0
    
    hv += g[dei(p[A,0],p[C,1],p[B,0],p[A,0])]*r[A][12][4,3]*r[B][2][2,8]*r[C][5][5,14]
    hv += g[dei(p[A,1],p[C,1],p[B,0],p[A,1])]*r[A][42][4,3]*r[B][2][2,8]*r[C][5][5,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A4B3C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,4),(B,3),(C,5)]))
    hv = 0.0
    
    hv += g[dei(p[A,0],p[C,1],p[B,0],p[A,0])]*r[A][12][4,3]*r[B][2][3,8]*r[C][5][5,14]
    hv += g[dei(p[A,1],p[C,1],p[B,0],p[A,1])]*r[A][42][4,3]*r[B][2][3,8]*r[C][5][5,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A4C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,4),(C,5)]))
    hv = 0.0
    
    hv += g[dei(p[A,0],p[C,1],p[B,1],p[A,0])]*r[A][12][4,3]*r[B][6][0,8]*r[C][5][5,14]
    hv += g[dei(p[A,1],p[C,1],p[B,1],p[A,1])]*r[A][42][4,3]*r[B][6][0,8]*r[C][5][5,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A4B1C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,4),(B,1),(C,5)]))
    hv = 0.0
    
    hv += g[dei(p[A,0],p[C,1],p[B,1],p[A,0])]*r[A][12][4,3]*r[B][6][1,8]*r[C][5][5,14]
    hv += g[dei(p[A,1],p[C,1],p[B,1],p[A,1])]*r[A][42][4,3]*r[B][6][1,8]*r[C][5][5,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B2C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,2),(C,8)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[C,1])]*r[A][2][13,3]*r[B][2][2,8]*r[C][49][8,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[C,0])]*r[A][2][13,3]*r[B][2][2,8]*r[C][31][8,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[C,1])]*r[A][2][13,3]*r[B][2][2,8]*r[C][49][8,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][2][2,8]*r[C][31][8,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B3C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,3),(C,8)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[C,1])]*r[A][2][13,3]*r[B][2][3,8]*r[C][49][8,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,0],p[C,0])]*r[A][2][13,3]*r[B][2][3,8]*r[C][31][8,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[C,1])]*r[A][2][13,3]*r[B][2][3,8]*r[C][49][8,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][2][3,8]*r[C][31][8,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B2C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,2),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[A,0],p[C,1],p[B,0],p[C,0])]*r[A][0][11,3]*r[B][2][2,8]*r[C][28][10,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B3C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,3),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[A,0],p[C,1],p[B,0],p[C,0])]*r[A][0][11,3]*r[B][2][3,8]*r[C][28][10,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B2C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,2),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[A,0],p[C,1],p[B,0],p[C,1])]*r[A][0][11,3]*r[B][2][2,8]*r[C][52][9,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B3C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,3),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[A,0],p[C,1],p[B,0],p[C,1])]*r[A][0][11,3]*r[B][2][3,8]*r[C][52][9,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(C,8)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[C,1])]*r[A][2][13,3]*r[B][6][0,8]*r[C][49][8,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[C,0])]*r[A][2][13,3]*r[B][6][0,8]*r[C][31][8,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[C,1])]*r[A][2][13,3]*r[B][6][0,8]*r[C][49][8,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][6][0,8]*r[C][31][8,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B1C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,1),(C,8)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[C,1])]*r[A][2][13,3]*r[B][6][1,8]*r[C][49][8,14]
    hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[C,0])]*r[A][2][13,3]*r[B][6][1,8]*r[C][31][8,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[C,1])]*r[A][2][13,3]*r[B][6][1,8]*r[C][49][8,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][6][1,8]*r[C][31][8,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[A,0],p[C,1],p[B,1],p[C,0])]*r[A][0][11,3]*r[B][6][0,8]*r[C][28][10,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B1C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,1),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[A,0],p[C,1],p[B,1],p[C,0])]*r[A][0][11,3]*r[B][6][1,8]*r[C][28][10,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[A,0],p[C,1],p[B,1],p[C,1])]*r[A][0][11,3]*r[B][6][0,8]*r[C][52][9,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B1C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,1),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[A,0],p[C,1],p[B,1],p[C,1])]*r[A][0][11,3]*r[B][6][1,8]*r[C][52][9,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B2C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,2),(C,8)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[C,1])]*r[A][6][14,3]*r[B][2][2,8]*r[C][49][8,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[C,0])]*r[A][6][14,3]*r[B][2][2,8]*r[C][31][8,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[C,1])]*r[A][6][14,3]*r[B][2][2,8]*r[C][49][8,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][2][2,8]*r[C][31][8,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B3C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,3),(C,8)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[C,1])]*r[A][6][14,3]*r[B][2][3,8]*r[C][49][8,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,0],p[C,0])]*r[A][6][14,3]*r[B][2][3,8]*r[C][31][8,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[C,1])]*r[A][6][14,3]*r[B][2][3,8]*r[C][49][8,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][2][3,8]*r[C][31][8,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B2C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,2),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[A,1],p[C,1],p[B,0],p[C,0])]*r[A][4][12,3]*r[B][2][2,8]*r[C][28][10,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B3C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,3),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[A,1],p[C,1],p[B,0],p[C,0])]*r[A][4][12,3]*r[B][2][3,8]*r[C][28][10,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B2C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,2),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[A,1],p[C,1],p[B,0],p[C,1])]*r[A][4][12,3]*r[B][2][2,8]*r[C][52][9,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B3C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,3),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[A,1],p[C,1],p[B,0],p[C,1])]*r[A][4][12,3]*r[B][2][3,8]*r[C][52][9,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(C,8)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[C,1])]*r[A][6][14,3]*r[B][6][0,8]*r[C][49][8,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[C,0])]*r[A][6][14,3]*r[B][6][0,8]*r[C][31][8,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[C,1])]*r[A][6][14,3]*r[B][6][0,8]*r[C][49][8,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][6][0,8]*r[C][31][8,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B1C8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,1),(C,8)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[C,1])]*r[A][6][14,3]*r[B][6][1,8]*r[C][49][8,14]
    hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[C,0])]*r[A][6][14,3]*r[B][6][1,8]*r[C][31][8,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[C,1])]*r[A][6][14,3]*r[B][6][1,8]*r[C][49][8,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][6][1,8]*r[C][31][8,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[A,1],p[C,1],p[B,1],p[C,0])]*r[A][4][12,3]*r[B][6][0,8]*r[C][28][10,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B1C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,1),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[A,1],p[C,1],p[B,1],p[C,0])]*r[A][4][12,3]*r[B][6][1,8]*r[C][28][10,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[A,1],p[C,1],p[B,1],p[C,1])]*r[A][4][12,3]*r[B][6][0,8]*r[C][52][9,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B1C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,1),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[A,1],p[C,1],p[B,1],p[C,1])]*r[A][4][12,3]*r[B][6][1,8]*r[C][52][9,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B6C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,2),(B,6),(C,15)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[A,0],p[A,0],p[C,0],p[B,1])]*r[A][9][2,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += 1/2*g[dei(p[A,1],p[A,1],p[C,0],p[B,1])]*r[A][39][2,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[C,0],p[A,0])]*r[A][9][2,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[C,0],p[A,1])]*r[A][39][2,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,0],p[B,1])]*r[A][9][2,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,1],p[B,1])]*r[A][39][2,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += 1/2*g[dei(p[C,0],p[B,1],p[A,0],p[A,0])]*r[A][9][2,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += g[dei(p[C,0],p[B,1],p[A,0],p[A,0])]*r[A][24][2,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += 1/2*g[dei(p[C,0],p[B,1],p[A,1],p[A,1])]*r[A][39][2,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += g[dei(p[C,0],p[B,1],p[A,1],p[A,1])]*r[A][54][2,3]*r[B][5][6,8]*r[C][0][15,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B6C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(B,6),(C,15)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,0],p[B,1])]*r[A][15][0,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,0],p[B,1])]*r[A][33][0,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[C,0],p[A,1])]*r[A][15][0,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[C,0],p[A,0])]*r[A][33][0,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,0],p[B,1])]*r[A][15][0,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,1],p[B,1])]*r[A][33][0,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += 1/2*g[dei(p[C,0],p[B,1],p[A,0],p[A,1])]*r[A][15][0,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += g[dei(p[C,0],p[B,1],p[A,0],p[A,1])]*r[A][30][0,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += 1/2*g[dei(p[C,0],p[B,1],p[A,1],p[A,0])]*r[A][33][0,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += g[dei(p[C,0],p[B,1],p[A,1],p[A,0])]*r[A][48][0,3]*r[B][5][6,8]*r[C][0][15,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B6C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,1),(B,6),(C,15)]))
    hv = 0.0
    
    hv += 1/2*g[dei(p[A,0],p[A,1],p[C,0],p[B,1])]*r[A][15][1,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[C,0],p[B,1])]*r[A][33][1,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[C,0],p[A,1])]*r[A][15][1,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[C,0],p[A,0])]*r[A][33][1,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += -1/2*g[dei(p[C,0],p[A,1],p[A,0],p[B,1])]*r[A][15][1,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += -1/2*g[dei(p[C,0],p[A,0],p[A,1],p[B,1])]*r[A][33][1,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += 1/2*g[dei(p[C,0],p[B,1],p[A,0],p[A,1])]*r[A][15][1,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += g[dei(p[C,0],p[B,1],p[A,0],p[A,1])]*r[A][30][1,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += 1/2*g[dei(p[C,0],p[B,1],p[A,1],p[A,0])]*r[A][33][1,3]*r[B][5][6,8]*r[C][0][15,14]
    hv += g[dei(p[C,0],p[B,1],p[A,1],p[A,0])]*r[A][48][1,3]*r[B][5][6,8]*r[C][0][15,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B6C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,11),(B,6),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[A,0],p[B,1],p[C,0],p[C,1])]*r[A][0][11,3]*r[B][5][6,8]*r[C][15][13,14]
    hv += -1/2*g[dei(p[A,0],p[C,1],p[C,0],p[B,1])]*r[A][0][11,3]*r[B][5][6,8]*r[C][15][13,14]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,0],p[C,1])]*r[A][0][11,3]*r[B][5][6,8]*r[C][15][13,14]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,0],p[B,1])]*r[A][0][11,3]*r[B][5][6,8]*r[C][15][13,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B6C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,12),(B,6),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += 1/2*g[dei(p[A,1],p[B,1],p[C,0],p[C,1])]*r[A][4][12,3]*r[B][5][6,8]*r[C][15][13,14]
    hv += -1/2*g[dei(p[A,1],p[C,1],p[C,0],p[B,1])]*r[A][4][12,3]*r[B][5][6,8]*r[C][15][13,14]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[A,1],p[C,1])]*r[A][4][12,3]*r[B][5][6,8]*r[C][15][13,14]
    hv += 1/2*g[dei(p[C,0],p[C,1],p[A,1],p[B,1])]*r[A][4][12,3]*r[B][5][6,8]*r[C][15][13,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5B4(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,5),(B,4)]))
    hv = 0.0
    
    hv += g[dei(p[B,0],p[A,0],p[A,0],p[C,0])]*r[A][21][5,3]*r[B][0][4,8]*r[C][3][0,14]
    hv += g[dei(p[B,0],p[A,1],p[A,1],p[C,0])]*r[A][51][5,3]*r[B][0][4,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5B4C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,5),(B,4),(C,1)]))
    hv = 0.0
    
    hv += g[dei(p[B,0],p[A,0],p[A,0],p[C,0])]*r[A][21][5,3]*r[B][0][4,8]*r[C][3][1,14]
    hv += g[dei(p[B,0],p[A,1],p[A,1],p[C,0])]*r[A][51][5,3]*r[B][0][4,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5B4C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,5),(B,4),(C,2)]))
    hv = 0.0
    
    hv += g[dei(p[B,0],p[A,0],p[A,0],p[C,1])]*r[A][21][5,3]*r[B][0][4,8]*r[C][7][2,14]
    hv += g[dei(p[B,0],p[A,1],p[A,1],p[C,1])]*r[A][51][5,3]*r[B][0][4,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5B4C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,5),(B,4),(C,3)]))
    hv = 0.0
    
    hv += g[dei(p[B,0],p[A,0],p[A,0],p[C,1])]*r[A][21][5,3]*r[B][0][4,8]*r[C][7][3,14]
    hv += g[dei(p[B,0],p[A,1],p[A,1],p[C,1])]*r[A][51][5,3]*r[B][0][4,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,7)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,0],p[B,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][15][7,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B7C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,7),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,0],p[B,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][15][7,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B7C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,7),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,0],p[B,1],p[A,0],p[C,1])]*r[A][2][13,3]*r[B][15][7,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B7C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,7),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,0],p[B,1],p[A,0],p[C,1])]*r[A][2][13,3]*r[B][15][7,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,7)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,0],p[B,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][15][7,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B7C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,7),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,0],p[B,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][15][7,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B7C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,7),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,0],p[B,1],p[A,1],p[C,1])]*r[A][6][14,3]*r[B][15][7,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B7C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,7),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,0],p[B,1],p[A,1],p[C,1])]*r[A][6][14,3]*r[B][15][7,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B4C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,4),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][0][4,8]*r[C][28][10,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B4C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,4),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,0],p[C,1],p[A,0],p[C,1])]*r[A][2][13,3]*r[B][0][4,8]*r[C][52][9,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B4C10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,4),(C,10)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][0][4,8]*r[C][28][10,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B4C9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,4),(C,9)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[B,0],p[C,1],p[A,1],p[C,1])]*r[A][6][14,3]*r[B][0][4,8]*r[C][52][9,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,11)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,0],p[A,0],p[B,0],p[C,0])]*r[A][1][10,3]*r[B][11][11,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B11C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,11),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,0],p[A,0],p[B,0],p[C,0])]*r[A][1][10,3]*r[B][11][11,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B11C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,11),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,0],p[A,0],p[B,0],p[C,1])]*r[A][1][10,3]*r[B][11][11,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B11C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,11),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,0],p[A,0],p[B,0],p[C,1])]*r[A][1][10,3]*r[B][11][11,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,11)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,0],p[A,1],p[B,0],p[C,0])]*r[A][5][9,3]*r[B][11][11,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B11C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,11),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,0],p[A,1],p[B,0],p[C,0])]*r[A][5][9,3]*r[B][11][11,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B11C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,11),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,0],p[A,1],p[B,0],p[C,1])]*r[A][5][9,3]*r[B][11][11,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B11C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,11),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,0],p[A,1],p[B,0],p[C,1])]*r[A][5][9,3]*r[B][11][11,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,14)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[B,0],p[A,0],p[B,1],p[C,0])]*r[A][3][8,3]*r[B][29][14,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[B,0],p[C,0])]*r[A][3][8,3]*r[B][47][14,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][29][14,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][47][14,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B14C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,14),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[B,0],p[A,0],p[B,1],p[C,0])]*r[A][3][8,3]*r[B][29][14,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[B,0],p[C,0])]*r[A][3][8,3]*r[B][47][14,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][29][14,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][47][14,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,12)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,0],p[A,0],p[B,1],p[C,0])]*r[A][1][10,3]*r[B][17][12,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B12C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,12),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,0],p[A,0],p[B,1],p[C,0])]*r[A][1][10,3]*r[B][17][12,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B14C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,14),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[B,0],p[A,0],p[B,1],p[C,1])]*r[A][3][8,3]*r[B][29][14,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[B,0],p[C,1])]*r[A][3][8,3]*r[B][47][14,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][29][14,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][47][14,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B14C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,14),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[B,0],p[A,0],p[B,1],p[C,1])]*r[A][3][8,3]*r[B][29][14,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[B,0],p[C,1])]*r[A][3][8,3]*r[B][47][14,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][29][14,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][47][14,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B12C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,12),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,0],p[A,0],p[B,1],p[C,1])]*r[A][1][10,3]*r[B][17][12,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B12C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,12),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,0],p[A,0],p[B,1],p[C,1])]*r[A][1][10,3]*r[B][17][12,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,14)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[B,0],p[A,1],p[B,1],p[C,0])]*r[A][7][7,3]*r[B][29][14,8]*r[C][3][0,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[B,0],p[C,0])]*r[A][7][7,3]*r[B][47][14,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][29][14,8]*r[C][3][0,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][47][14,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B14C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,14),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[B,0],p[A,1],p[B,1],p[C,0])]*r[A][7][7,3]*r[B][29][14,8]*r[C][3][1,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[B,0],p[C,0])]*r[A][7][7,3]*r[B][47][14,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,0],p[C,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][29][14,8]*r[C][3][1,14]
    hv += -1/2*g[dei(p[B,1],p[C,0],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][47][14,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,12)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,0],p[A,1],p[B,1],p[C,0])]*r[A][5][9,3]*r[B][17][12,8]*r[C][3][0,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B12C1(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,12),(C,1)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,0],p[A,1],p[B,1],p[C,0])]*r[A][5][9,3]*r[B][17][12,8]*r[C][3][1,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B14C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,14),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[B,0],p[A,1],p[B,1],p[C,1])]*r[A][7][7,3]*r[B][29][14,8]*r[C][7][2,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[B,0],p[C,1])]*r[A][7][7,3]*r[B][47][14,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][29][14,8]*r[C][7][2,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][47][14,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B14C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,14),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[B,0],p[A,1],p[B,1],p[C,1])]*r[A][7][7,3]*r[B][29][14,8]*r[C][7][3,14]
    hv += 1/2*g[dei(p[B,1],p[A,1],p[B,0],p[C,1])]*r[A][7][7,3]*r[B][47][14,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,0],p[C,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][29][14,8]*r[C][7][3,14]
    hv += -1/2*g[dei(p[B,1],p[C,1],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][47][14,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B12C2(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,12),(C,2)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,0],p[A,1],p[B,1],p[C,1])]*r[A][5][9,3]*r[B][17][12,8]*r[C][7][2,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B12C3(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,12),(C,3)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[B,0],p[A,1],p[B,1],p[C,1])]*r[A][5][9,3]*r[B][17][12,8]*r[C][7][3,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B11C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,11),(C,5)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,0],p[C,1],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][11][11,8]*r[C][5][5,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B11C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,11),(C,5)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,0],p[C,1],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][11][11,8]*r[C][5][5,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B12C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,12),(C,5)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,0],p[C,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][17][12,8]*r[C][5][5,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B12C5(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,12),(C,5)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[B,0],p[C,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][17][12,8]*r[C][5][5,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B7C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,7),(C,15)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[B,0],p[A,0],p[C,0],p[B,1])]*r[A][1][10,3]*r[B][15][7,8]*r[C][0][15,14]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,0],p[A,0])]*r[A][1][10,3]*r[B][15][7,8]*r[C][0][15,14]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[B,0],p[B,1])]*r[A][1][10,3]*r[B][15][7,8]*r[C][0][15,14]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,0],p[A,0])]*r[A][1][10,3]*r[B][15][7,8]*r[C][0][15,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B7C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,7),(C,15)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1/2*g[dei(p[B,0],p[A,1],p[C,0],p[B,1])]*r[A][5][9,3]*r[B][15][7,8]*r[C][0][15,14]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[C,0],p[A,1])]*r[A][5][9,3]*r[B][15][7,8]*r[C][0][15,14]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[B,0],p[B,1])]*r[A][5][9,3]*r[B][15][7,8]*r[C][0][15,14]
    hv += -1/2*g[dei(p[C,0],p[B,1],p[B,0],p[A,1])]*r[A][5][9,3]*r[B][15][7,8]*r[C][0][15,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B4C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,4),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[B,0],p[A,0],p[C,0],p[C,1])]*r[A][1][10,3]*r[B][0][4,8]*r[C][15][13,14]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,0],p[A,0])]*r[A][1][10,3]*r[B][0][4,8]*r[C][15][13,14]
    hv += 1/2*g[dei(p[C,0],p[A,0],p[B,0],p[C,1])]*r[A][1][10,3]*r[B][0][4,8]*r[C][15][13,14]
    hv += -1/2*g[dei(p[C,0],p[C,1],p[B,0],p[A,0])]*r[A][1][10,3]*r[B][0][4,8]*r[C][15][13,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B4C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,4),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1/2*g[dei(p[B,0],p[A,1],p[C,0],p[C,1])]*r[A][5][9,3]*r[B][0][4,8]*r[C][15][13,14]
    hv += 1/2*g[dei(p[B,0],p[C,1],p[C,0],p[A,1])]*r[A][5][9,3]*r[B][0][4,8]*r[C][15][13,14]
    hv += 1/2*g[dei(p[C,0],p[A,1],p[B,0],p[C,1])]*r[A][5][9,3]*r[B][0][4,8]*r[C][15][13,14]
    hv += -1/2*g[dei(p[C,0],p[C,1],p[B,0],p[A,1])]*r[A][5][9,3]*r[B][0][4,8]*r[C][15][13,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B6C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,6),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[C,0],p[B,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][5][6,8]*r[C][12][12,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B6C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,13),(B,6),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[C,0],p[B,1],p[A,0],p[C,1])]*r[A][2][13,3]*r[B][5][6,8]*r[C][18][11,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B6C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,6),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[C,0],p[B,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][5][6,8]*r[C][12][12,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B6C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,14),(B,6),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[C,0],p[B,1],p[A,1],p[C,1])]*r[A][6][14,3]*r[B][5][6,8]*r[C][18][11,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6B2C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,6),(B,2),(C,15)]))
    hv = 0.0
    
    hv += g[dei(p[C,0],p[A,0],p[B,0],p[A,1])]*r[A][46][6,3]*r[B][2][2,8]*r[C][0][15,14]
    hv += g[dei(p[C,0],p[A,1],p[B,0],p[A,0])]*r[A][28][6,3]*r[B][2][2,8]*r[C][0][15,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6B3C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,6),(B,3),(C,15)]))
    hv = 0.0
    
    hv += g[dei(p[C,0],p[A,0],p[B,0],p[A,1])]*r[A][46][6,3]*r[B][2][3,8]*r[C][0][15,14]
    hv += g[dei(p[C,0],p[A,1],p[B,0],p[A,0])]*r[A][28][6,3]*r[B][2][3,8]*r[C][0][15,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,6),(C,15)]))
    hv = 0.0
    
    hv += g[dei(p[C,0],p[A,0],p[B,1],p[A,1])]*r[A][46][6,3]*r[B][6][0,8]*r[C][0][15,14]
    hv += g[dei(p[C,0],p[A,1],p[B,1],p[A,0])]*r[A][28][6,3]*r[B][6][0,8]*r[C][0][15,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6B1C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,6),(B,1),(C,15)]))
    hv = 0.0
    
    hv += g[dei(p[C,0],p[A,0],p[B,1],p[A,1])]*r[A][46][6,3]*r[B][6][1,8]*r[C][0][15,14]
    hv += g[dei(p[C,0],p[A,1],p[B,1],p[A,0])]*r[A][28][6,3]*r[B][6][1,8]*r[C][0][15,14]
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B2C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,2),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,0],p[A,0],p[B,0],p[C,0])]*r[A][1][10,3]*r[B][2][2,8]*r[C][12][12,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B3C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,3),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,0],p[A,0],p[B,0],p[C,0])]*r[A][1][10,3]*r[B][2][3,8]*r[C][12][12,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B2C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,2),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,0],p[A,0],p[B,0],p[C,1])]*r[A][1][10,3]*r[B][2][2,8]*r[C][18][11,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B3C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,3),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,0],p[A,0],p[B,0],p[C,1])]*r[A][1][10,3]*r[B][2][3,8]*r[C][18][11,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B2C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,2),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,0],p[A,1],p[B,0],p[C,0])]*r[A][5][9,3]*r[B][2][2,8]*r[C][12][12,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B3C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,3),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,0],p[A,1],p[B,0],p[C,0])]*r[A][5][9,3]*r[B][2][3,8]*r[C][12][12,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B2C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,2),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,0],p[A,1],p[B,0],p[C,1])]*r[A][5][9,3]*r[B][2][2,8]*r[C][18][11,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B3C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,3),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,0],p[A,1],p[B,0],p[C,1])]*r[A][5][9,3]*r[B][2][3,8]*r[C][18][11,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,0],p[A,0],p[B,1],p[C,0])]*r[A][1][10,3]*r[B][6][0,8]*r[C][12][12,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B1C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,1),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,0],p[A,0],p[B,1],p[C,0])]*r[A][1][10,3]*r[B][6][1,8]*r[C][12][12,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,0],p[A,0],p[B,1],p[C,1])]*r[A][1][10,3]*r[B][6][0,8]*r[C][18][11,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B1C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,10),(B,1),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,0],p[A,0],p[B,1],p[C,1])]*r[A][1][10,3]*r[B][6][1,8]*r[C][18][11,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,0],p[A,1],p[B,1],p[C,0])]*r[A][5][9,3]*r[B][6][0,8]*r[C][12][12,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B1C12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,1),(C,12)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,0],p[A,1],p[B,1],p[C,0])]*r[A][5][9,3]*r[B][6][1,8]*r[C][12][12,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,0],p[A,1],p[B,1],p[C,1])]*r[A][5][9,3]*r[B][6][0,8]*r[C][18][11,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B1C11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,9),(B,1),(C,11)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += g[dei(p[C,0],p[A,1],p[B,1],p[C,1])]*r[A][5][9,3]*r[B][6][1,8]*r[C][18][11,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B9C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,9),(C,15)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[C,0],p[B,1],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][27][9,8]*r[C][0][15,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B9C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,9),(C,15)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[C,0],p[B,1],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][27][9,8]*r[C][0][15,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B10C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,10),(C,15)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[C,0],p[B,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][51][10,8]*r[C][0][15,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B10C15(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,10),(C,15)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[C,0],p[B,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][51][10,8]*r[C][0][15,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B2C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,2),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[C,0],p[C,1],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][2][2,8]*r[C][15][13,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B3C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,3),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[C,0],p[C,1],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][2][3,8]*r[C][15][13,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B2C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,2),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[C,0],p[C,1],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][2][2,8]*r[C][15][13,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B3C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,3),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[C,0],p[C,1],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][2][3,8]*r[C][15][13,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[C,0],p[C,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][15][13,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B1C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,8),(B,1),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[C,0],p[C,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][1,8]*r[C][15][13,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[C,0],p[C,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][15][13,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B1C13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    v = tuple(sorted([(A,7),(B,1),(C,13)]))
    hv = 0.0
    sket = sign([A,C])
    
    hv += -1*g[dei(p[C,0],p[C,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][1,8]*r[C][15][13,14]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I14J7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,3),(I,14),(J,7)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[B,1],p[C,0],p[I,0],p[J,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][2][14,0]*r[J][3][7,0]
            hv += 1/4*g[dei(p[B,1],p[J,0],p[I,0],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][2][14,0]*r[J][3][7,0]
            hv += 1/4*g[dei(p[I,0],p[C,0],p[B,1],p[J,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][2][14,0]*r[J][3][7,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][2][14,0]*r[J][3][7,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I14J8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,3),(I,14),(J,8)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[B,1],p[C,0],p[I,0],p[J,1])]*r[B][6][0,8]*r[C][3][0,14]*r[I][2][14,0]*r[J][7][8,0]
            hv += 1/4*g[dei(p[B,1],p[J,1],p[I,0],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][2][14,0]*r[J][7][8,0]
            hv += 1/4*g[dei(p[I,0],p[C,0],p[B,1],p[J,1])]*r[B][6][0,8]*r[C][3][0,14]*r[I][2][14,0]*r[J][7][8,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][2][14,0]*r[J][7][8,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I13J7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,3),(I,13),(J,7)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[B,1],p[C,0],p[I,1],p[J,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][6][13,0]*r[J][3][7,0]
            hv += 1/4*g[dei(p[B,1],p[J,0],p[I,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][6][13,0]*r[J][3][7,0]
            hv += 1/4*g[dei(p[I,1],p[C,0],p[B,1],p[J,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][6][13,0]*r[J][3][7,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][6][13,0]*r[J][3][7,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I13J8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,3),(I,13),(J,8)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[B,1],p[C,0],p[I,1],p[J,1])]*r[B][6][0,8]*r[C][3][0,14]*r[I][6][13,0]*r[J][7][8,0]
            hv += 1/4*g[dei(p[B,1],p[J,1],p[I,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][6][13,0]*r[J][7][8,0]
            hv += 1/4*g[dei(p[I,1],p[C,0],p[B,1],p[J,1])]*r[B][6][0,8]*r[C][3][0,14]*r[I][6][13,0]*r[J][7][8,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][6][13,0]*r[J][7][8,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I7J14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,3),(I,7),(J,14)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[B,1],p[C,0],p[J,0],p[I,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][3][7,0]*r[J][2][14,0]
            hv += -1/4*g[dei(p[B,1],p[I,0],p[J,0],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][3][7,0]*r[J][2][14,0]
            hv += -1/4*g[dei(p[J,0],p[C,0],p[B,1],p[I,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][3][7,0]*r[J][2][14,0]
            hv += 1/4*g[dei(p[J,0],p[I,0],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][3][7,0]*r[J][2][14,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I8J14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,3),(I,8),(J,14)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[B,1],p[C,0],p[J,0],p[I,1])]*r[B][6][0,8]*r[C][3][0,14]*r[I][7][8,0]*r[J][2][14,0]
            hv += -1/4*g[dei(p[B,1],p[I,1],p[J,0],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][7][8,0]*r[J][2][14,0]
            hv += -1/4*g[dei(p[J,0],p[C,0],p[B,1],p[I,1])]*r[B][6][0,8]*r[C][3][0,14]*r[I][7][8,0]*r[J][2][14,0]
            hv += 1/4*g[dei(p[J,0],p[I,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][7][8,0]*r[J][2][14,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I7J13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,3),(I,7),(J,13)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[B,1],p[C,0],p[J,1],p[I,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][3][7,0]*r[J][6][13,0]
            hv += -1/4*g[dei(p[B,1],p[I,0],p[J,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][3][7,0]*r[J][6][13,0]
            hv += -1/4*g[dei(p[J,1],p[C,0],p[B,1],p[I,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][3][7,0]*r[J][6][13,0]
            hv += 1/4*g[dei(p[J,1],p[I,0],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][3][7,0]*r[J][6][13,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I8J13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,3),(I,8),(J,13)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[B,1],p[C,0],p[J,1],p[I,1])]*r[B][6][0,8]*r[C][3][0,14]*r[I][7][8,0]*r[J][6][13,0]
            hv += -1/4*g[dei(p[B,1],p[I,1],p[J,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][7][8,0]*r[J][6][13,0]
            hv += -1/4*g[dei(p[J,1],p[C,0],p[B,1],p[I,1])]*r[B][6][0,8]*r[C][3][0,14]*r[I][7][8,0]*r[J][6][13,0]
            hv += 1/4*g[dei(p[J,1],p[I,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][7][8,0]*r[J][6][13,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I12J9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,3),(I,12),(J,9)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[I,0],p[J,0],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][0][12,0]*r[J][1][9,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I12J10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,3),(I,12),(J,10)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[I,0],p[J,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][0][12,0]*r[J][5][10,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I11J9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,3),(I,11),(J,9)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[I,1],p[J,0],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][4][11,0]*r[J][1][9,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I11J10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,3),(I,11),(J,10)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[I,1],p[J,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][4][11,0]*r[J][5][10,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I9J12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,3),(I,9),(J,12)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[J,0],p[I,0],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][1][9,0]*r[J][0][12,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I10J12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,3),(I,10),(J,12)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[J,0],p[I,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][5][10,0]*r[J][0][12,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I9J11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,3),(I,9),(J,11)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[J,1],p[I,0],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][1][9,0]*r[J][4][11,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I10J11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        for J in range(nc, np):
            if J in {A,B,C,I}: continue
            v = tuple(sorted([(A,3),(I,10),(J,11)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[J,1],p[I,1],p[B,1],p[C,0])]*r[B][6][0,8]*r[C][3][0,14]*r[I][5][10,0]*r[J][4][11,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B2I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(B,2),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[I,0])]*r[A][2][13,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,0],p[C,0])]*r[A][2][13,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[I,0])]*r[A][2][13,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B3I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(B,3),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[I,0])]*r[A][2][13,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,0],p[C,0])]*r[A][2][13,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[I,0])]*r[A][2][13,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B2I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(B,2),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[I,1])]*r[A][2][13,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,0],p[C,0])]*r[A][2][13,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[I,1])]*r[A][2][13,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B3I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(B,3),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[C,0],p[B,0],p[I,1])]*r[A][2][13,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,0],p[C,0])]*r[A][2][13,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[A,0],p[I,1])]*r[A][2][13,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[I,0])]*r[A][2][13,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,1],p[C,0])]*r[A][2][13,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[I,0])]*r[A][2][13,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13C1I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(C,1),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[I,0])]*r[A][2][13,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,1],p[C,0])]*r[A][2][13,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[I,0])]*r[A][2][13,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B1I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(B,1),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[I,0])]*r[A][2][13,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,1],p[C,0])]*r[A][2][13,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[I,0])]*r[A][2][13,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[I,1])]*r[A][2][13,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,1],p[C,0])]*r[A][2][13,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[I,1])]*r[A][2][13,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13C1I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(C,1),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[I,1])]*r[A][2][13,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,1],p[C,0])]*r[A][2][13,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[I,1])]*r[A][2][13,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B1I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(B,1),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[C,0],p[B,1],p[I,1])]*r[A][2][13,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,1],p[C,0])]*r[A][2][13,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[C,0],p[A,0],p[I,1])]*r[A][2][13,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13C2I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(C,2),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[I,0])]*r[A][2][13,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,1],p[C,1])]*r[A][2][13,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[I,0])]*r[A][2][13,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,0],p[C,1])]*r[A][2][13,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13C3I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(C,3),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[I,0])]*r[A][2][13,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[B,1],p[C,1])]*r[A][2][13,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[I,0])]*r[A][2][13,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,0],p[C,1])]*r[A][2][13,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11C5I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(C,5),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,0],p[C,1],p[B,1],p[I,0])]*r[A][0][11,3]*r[B][6][0,8]*r[C][5][5,14]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13C2I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(C,2),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[I,1])]*r[A][2][13,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,1],p[C,1])]*r[A][2][13,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[I,1])]*r[A][2][13,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,0],p[C,1])]*r[A][2][13,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13C3I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(C,3),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[C,1],p[B,1],p[I,1])]*r[A][2][13,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[B,1],p[C,1])]*r[A][2][13,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[C,1],p[A,0],p[I,1])]*r[A][2][13,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,0],p[C,1])]*r[A][2][13,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11C5I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(C,5),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,0],p[C,1],p[B,1],p[I,1])]*r[A][0][11,3]*r[B][6][0,8]*r[C][5][5,14]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B2I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(B,2),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[I,0])]*r[A][6][14,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,0],p[C,0])]*r[A][6][14,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[I,0])]*r[A][6][14,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B3I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(B,3),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[I,0])]*r[A][6][14,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,0],p[C,0])]*r[A][6][14,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[I,0])]*r[A][6][14,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,0],p[I,0],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B2I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(B,2),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[I,1])]*r[A][6][14,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,0],p[C,0])]*r[A][6][14,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[I,1])]*r[A][6][14,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B3I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(B,3),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,1],p[C,0],p[B,0],p[I,1])]*r[A][6][14,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,0],p[C,0])]*r[A][6][14,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,0],p[C,0],p[A,1],p[I,1])]*r[A][6][14,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,0],p[I,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[I,0])]*r[A][6][14,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,1],p[C,0])]*r[A][6][14,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[I,0])]*r[A][6][14,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14C1I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(C,1),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[I,0])]*r[A][6][14,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,1],p[C,0])]*r[A][6][14,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[I,0])]*r[A][6][14,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B1I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(B,1),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[I,0])]*r[A][6][14,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,1],p[C,0])]*r[A][6][14,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[I,0])]*r[A][6][14,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[I,1])]*r[A][6][14,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,1],p[C,0])]*r[A][6][14,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[I,1])]*r[A][6][14,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14C1I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(C,1),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[I,1])]*r[A][6][14,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,1],p[C,0])]*r[A][6][14,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[I,1])]*r[A][6][14,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B1I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(B,1),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,1],p[C,0],p[B,1],p[I,1])]*r[A][6][14,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,1],p[C,0])]*r[A][6][14,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[C,0],p[A,1],p[I,1])]*r[A][6][14,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14C2I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(C,2),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[I,0])]*r[A][6][14,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,1],p[C,1])]*r[A][6][14,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[I,0])]*r[A][6][14,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,1],p[C,1])]*r[A][6][14,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14C3I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(C,3),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[I,0])]*r[A][6][14,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[B,1],p[C,1])]*r[A][6][14,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[I,0])]*r[A][6][14,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[I,0],p[A,1],p[C,1])]*r[A][6][14,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12C5I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(C,5),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,1],p[C,1],p[B,1],p[I,0])]*r[A][4][12,3]*r[B][6][0,8]*r[C][5][5,14]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14C2I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(C,2),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[I,1])]*r[A][6][14,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,1],p[C,1])]*r[A][6][14,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[I,1])]*r[A][6][14,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,1],p[C,1])]*r[A][6][14,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14C3I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(C,3),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,1],p[C,1],p[B,1],p[I,1])]*r[A][6][14,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[B,1],p[C,1])]*r[A][6][14,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[C,1],p[A,1],p[I,1])]*r[A][6][14,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[I,1],p[A,1],p[C,1])]*r[A][6][14,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12C5I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(C,5),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,1],p[C,1],p[B,1],p[I,1])]*r[A][4][12,3]*r[B][6][0,8]*r[C][5][5,14]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B2I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(B,2),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,0],p[I,0],p[B,0],p[C,0])]*r[A][0][11,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B3I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(B,3),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,0],p[I,0],p[B,0],p[C,0])]*r[A][0][11,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B2I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(B,2),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,0],p[I,1],p[B,0],p[C,0])]*r[A][0][11,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B3I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(B,3),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,0],p[I,1],p[B,0],p[C,0])]*r[A][0][11,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,0],p[I,0],p[B,1],p[C,0])]*r[A][0][11,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11C1I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(C,1),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,0],p[I,0],p[B,1],p[C,0])]*r[A][0][11,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B1I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(B,1),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,0],p[I,0],p[B,1],p[C,0])]*r[A][0][11,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11C2I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(C,2),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,0],p[I,0],p[B,1],p[C,1])]*r[A][0][11,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11C3I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(C,3),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,0],p[I,0],p[B,1],p[C,1])]*r[A][0][11,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,0],p[I,1],p[B,1],p[C,0])]*r[A][0][11,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11C1I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(C,1),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,0],p[I,1],p[B,1],p[C,0])]*r[A][0][11,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B1I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(B,1),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,0],p[I,1],p[B,1],p[C,0])]*r[A][0][11,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11C2I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(C,2),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,0],p[I,1],p[B,1],p[C,1])]*r[A][0][11,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11C3I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(C,3),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,0],p[I,1],p[B,1],p[C,1])]*r[A][0][11,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B2I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(B,2),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,1],p[I,0],p[B,0],p[C,0])]*r[A][4][12,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B3I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(B,3),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,1],p[I,0],p[B,0],p[C,0])]*r[A][4][12,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B2I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(B,2),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,1],p[I,1],p[B,0],p[C,0])]*r[A][4][12,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B3I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(B,3),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,1],p[I,1],p[B,0],p[C,0])]*r[A][4][12,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,1],p[I,0],p[B,1],p[C,0])]*r[A][4][12,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12C1I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(C,1),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,1],p[I,0],p[B,1],p[C,0])]*r[A][4][12,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B1I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(B,1),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,1],p[I,0],p[B,1],p[C,0])]*r[A][4][12,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12C2I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(C,2),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,1],p[I,0],p[B,1],p[C,1])]*r[A][4][12,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12C3I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(C,3),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,1],p[I,0],p[B,1],p[C,1])]*r[A][4][12,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,1],p[I,1],p[B,1],p[C,0])]*r[A][4][12,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12C1I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(C,1),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,1],p[I,1],p[B,1],p[C,0])]*r[A][4][12,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B1I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(B,1),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,1],p[I,1],p[B,1],p[C,0])]*r[A][4][12,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12C2I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(C,2),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,1],p[I,1],p[B,1],p[C,1])]*r[A][4][12,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12C3I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(C,3),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,1],p[I,1],p[B,1],p[C,1])]*r[A][4][12,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B6I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(B,6),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,0],p[B,1],p[I,0],p[C,0])]*r[A][0][11,3]*r[B][5][6,8]*r[C][3][0,14]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B6I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,11),(B,6),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,0],p[B,1],p[I,1],p[C,0])]*r[A][0][11,3]*r[B][5][6,8]*r[C][3][0,14]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B6I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(B,6),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,1],p[B,1],p[I,0],p[C,0])]*r[A][4][12,3]*r[B][5][6,8]*r[C][3][0,14]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A12B6I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,12),(B,6),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,1],p[B,1],p[I,1],p[C,0])]*r[A][4][12,3]*r[B][5][6,8]*r[C][3][0,14]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B4I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(B,4),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[I,0],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][0][4,8]*r[C][3][0,14]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B4I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(B,4),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[I,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][0][4,8]*r[C][3][0,14]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B4I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(B,4),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[I,0],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][0][4,8]*r[C][3][0,14]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B4I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(B,4),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[B,0],p[I,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][0][4,8]*r[C][3][0,14]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B2I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(B,2),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,0],p[A,0],p[I,0],p[C,0])]*r[A][3][8,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[B,0],p[C,0],p[I,0],p[A,0])]*r[A][3][8,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[B,0],p[C,0])]*r[A][3][8,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B3I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(B,3),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,0],p[A,0],p[I,0],p[C,0])]*r[A][3][8,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[B,0],p[C,0],p[I,0],p[A,0])]*r[A][3][8,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[B,0],p[C,0])]*r[A][3][8,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B4I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(B,4),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[A,0],p[I,0],p[C,0])]*r[A][1][10,3]*r[B][0][4,8]*r[C][3][0,14]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B2I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(B,2),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,0],p[A,1],p[I,0],p[C,0])]*r[A][7][7,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[B,0],p[C,0],p[I,0],p[A,1])]*r[A][7][7,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[B,0],p[C,0])]*r[A][7][7,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B3I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(B,3),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,0],p[A,1],p[I,0],p[C,0])]*r[A][7][7,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[B,0],p[C,0],p[I,0],p[A,1])]*r[A][7][7,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[B,0],p[C,0])]*r[A][7][7,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B4I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(B,4),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[A,1],p[I,0],p[C,0])]*r[A][5][9,3]*r[B][0][4,8]*r[C][3][0,14]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B2I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(B,2),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,0],p[A,0],p[I,1],p[C,0])]*r[A][3][8,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[B,0],p[C,0],p[I,1],p[A,0])]*r[A][3][8,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[B,0],p[C,0])]*r[A][3][8,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B3I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(B,3),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,0],p[A,0],p[I,1],p[C,0])]*r[A][3][8,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[B,0],p[C,0],p[I,1],p[A,0])]*r[A][3][8,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[B,0],p[C,0])]*r[A][3][8,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[B,0],p[A,0])]*r[A][3][8,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B4I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(B,4),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[A,0],p[I,1],p[C,0])]*r[A][1][10,3]*r[B][0][4,8]*r[C][3][0,14]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B2I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(B,2),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,0],p[A,1],p[I,1],p[C,0])]*r[A][7][7,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[B,0],p[C,0],p[I,1],p[A,1])]*r[A][7][7,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[B,0],p[C,0])]*r[A][7][7,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B3I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(B,3),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,0],p[A,1],p[I,1],p[C,0])]*r[A][7][7,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[B,0],p[C,0],p[I,1],p[A,1])]*r[A][7][7,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[B,0],p[C,0])]*r[A][7][7,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[B,0],p[A,1])]*r[A][7][7,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B4I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(B,4),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[B,0],p[A,1],p[I,1],p[C,0])]*r[A][5][9,3]*r[B][0][4,8]*r[C][3][0,14]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,1],p[A,0],p[I,0],p[C,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[B,1],p[C,0],p[I,0],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[B,1],p[C,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8C1I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(C,1),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,1],p[A,0],p[I,0],p[C,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[B,1],p[C,0],p[I,0],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[B,1],p[C,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B1I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(B,1),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,1],p[A,0],p[I,0],p[C,0])]*r[A][3][8,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[B,1],p[C,0],p[I,0],p[A,0])]*r[A][3][8,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[B,1],p[C,0])]*r[A][3][8,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8C2I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(C,2),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,1],p[A,0],p[I,0],p[C,1])]*r[A][3][8,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[B,1],p[C,1],p[I,0],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[B,1],p[C,1])]*r[A][3][8,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8C3I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(C,3),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,1],p[A,0],p[I,0],p[C,1])]*r[A][3][8,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[B,1],p[C,1],p[I,0],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[A,0],p[B,1],p[C,1])]*r[A][3][8,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,1],p[A,1],p[I,0],p[C,0])]*r[A][7][7,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[B,1],p[C,0],p[I,0],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[B,1],p[C,0])]*r[A][7][7,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7C1I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(C,1),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,1],p[A,1],p[I,0],p[C,0])]*r[A][7][7,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[B,1],p[C,0],p[I,0],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[B,1],p[C,0])]*r[A][7][7,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B1I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(B,1),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,1],p[A,1],p[I,0],p[C,0])]*r[A][7][7,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[B,1],p[C,0],p[I,0],p[A,1])]*r[A][7][7,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[B,1],p[C,0])]*r[A][7][7,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[C,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7C2I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(C,2),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,1],p[A,1],p[I,0],p[C,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[B,1],p[C,1],p[I,0],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[B,1],p[C,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7C3I14(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(C,3),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,1],p[A,1],p[I,0],p[C,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[B,1],p[C,1],p[I,0],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[A,1],p[B,1],p[C,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[C,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,1],p[A,0],p[I,1],p[C,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[B,1],p[C,0],p[I,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[B,1],p[C,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8C1I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(C,1),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,1],p[A,0],p[I,1],p[C,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[B,1],p[C,0],p[I,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[B,1],p[C,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B1I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(B,1),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,1],p[A,0],p[I,1],p[C,0])]*r[A][3][8,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[B,1],p[C,0],p[I,1],p[A,0])]*r[A][3][8,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[B,1],p[C,0])]*r[A][3][8,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8C2I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(C,2),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,1],p[A,0],p[I,1],p[C,1])]*r[A][3][8,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[B,1],p[C,1],p[I,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[B,1],p[C,1])]*r[A][3][8,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8C3I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(C,3),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,1],p[A,0],p[I,1],p[C,1])]*r[A][3][8,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[B,1],p[C,1],p[I,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[A,0],p[B,1],p[C,1])]*r[A][3][8,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,1],p[A,1],p[I,1],p[C,0])]*r[A][7][7,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[B,1],p[C,0],p[I,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[B,1],p[C,0])]*r[A][7][7,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7C1I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(C,1),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,1],p[A,1],p[I,1],p[C,0])]*r[A][7][7,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[B,1],p[C,0],p[I,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[B,1],p[C,0])]*r[A][7][7,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B1I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(B,1),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,1],p[A,1],p[I,1],p[C,0])]*r[A][7][7,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[B,1],p[C,0],p[I,1],p[A,1])]*r[A][7][7,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[B,1],p[C,0])]*r[A][7][7,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[C,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7C2I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(C,2),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,1],p[A,1],p[I,1],p[C,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[B,1],p[C,1],p[I,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[B,1],p[C,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7C3I13(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(C,3),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[B,1],p[A,1],p[I,1],p[C,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[B,1],p[C,1],p[I,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[A,1],p[B,1],p[C,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[C,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10C15I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(C,15),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[C,0],p[A,0],p[B,1],p[I,0])]*r[A][1][10,3]*r[B][6][0,8]*r[C][0][15,14]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10C15I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(C,15),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[C,0],p[A,0],p[B,1],p[I,1])]*r[A][1][10,3]*r[B][6][0,8]*r[C][0][15,14]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9C15I7(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(C,15),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[C,0],p[A,1],p[B,1],p[I,0])]*r[A][5][9,3]*r[B][6][0,8]*r[C][0][15,14]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9C15I8(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(C,15),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[C,0],p[A,1],p[B,1],p[I,1])]*r[A][5][9,3]*r[B][6][0,8]*r[C][0][15,14]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8C15I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(C,15),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[C,0],p[I,0],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][0][15,14]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7C15I9(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(C,15),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[C,0],p[I,0],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][0][15,14]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8C15I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(C,15),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[C,0],p[I,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][0][15,14]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7C15I10(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(C,15),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[C,0],p[I,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][0][15,14]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B6I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(B,6),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[I,0],p[B,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][5][6,8]*r[C][3][0,14]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B6I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(B,6),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[I,0],p[B,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][5][6,8]*r[C][3][0,14]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B6I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,13),(B,6),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[I,1],p[B,1],p[A,0],p[C,0])]*r[A][2][13,3]*r[B][5][6,8]*r[C][3][0,14]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B6I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,14),(B,6),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[I,1],p[B,1],p[A,1],p[C,0])]*r[A][6][14,3]*r[B][5][6,8]*r[C][3][0,14]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B2I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(B,2),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,0],p[A,0],p[B,0],p[C,0])]*r[A][1][10,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B3I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(B,3),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,0],p[A,0],p[B,0],p[C,0])]*r[A][1][10,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B2I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(B,2),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,0],p[A,1],p[B,0],p[C,0])]*r[A][5][9,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B3I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(B,3),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,0],p[A,1],p[B,0],p[C,0])]*r[A][5][9,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,0],p[A,0],p[B,1],p[C,0])]*r[A][1][10,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10C1I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(C,1),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,0],p[A,0],p[B,1],p[C,0])]*r[A][1][10,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B1I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(B,1),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,0],p[A,0],p[B,1],p[C,0])]*r[A][1][10,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10C2I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(C,2),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,0],p[A,0],p[B,1],p[C,1])]*r[A][1][10,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10C3I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(C,3),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,0],p[A,0],p[B,1],p[C,1])]*r[A][1][10,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,0],p[A,1],p[B,1],p[C,0])]*r[A][5][9,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9C1I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(C,1),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,0],p[A,1],p[B,1],p[C,0])]*r[A][5][9,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B1I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(B,1),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,0],p[A,1],p[B,1],p[C,0])]*r[A][5][9,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9C2I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(C,2),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,0],p[A,1],p[B,1],p[C,1])]*r[A][5][9,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9C3I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(C,3),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,0],p[A,1],p[B,1],p[C,1])]*r[A][5][9,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B2I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(B,2),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,1],p[A,0],p[B,0],p[C,0])]*r[A][1][10,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B3I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(B,3),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,1],p[A,0],p[B,0],p[C,0])]*r[A][1][10,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B2I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(B,2),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,1],p[A,1],p[B,0],p[C,0])]*r[A][5][9,3]*r[B][2][2,8]*r[C][3][0,14]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B3I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(B,3),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,1],p[A,1],p[B,0],p[C,0])]*r[A][5][9,3]*r[B][2][3,8]*r[C][3][0,14]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,1],p[A,0],p[B,1],p[C,0])]*r[A][1][10,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10C1I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(C,1),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,1],p[A,0],p[B,1],p[C,0])]*r[A][1][10,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B1I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(B,1),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,1],p[A,0],p[B,1],p[C,0])]*r[A][1][10,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10C2I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(C,2),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,1],p[A,0],p[B,1],p[C,1])]*r[A][1][10,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10C3I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,10),(C,3),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,1],p[A,0],p[B,1],p[C,1])]*r[A][1][10,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,1],p[A,1],p[B,1],p[C,0])]*r[A][5][9,3]*r[B][6][0,8]*r[C][3][0,14]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9C1I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(C,1),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,1],p[A,1],p[B,1],p[C,0])]*r[A][5][9,3]*r[B][6][0,8]*r[C][3][1,14]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B1I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(B,1),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,1],p[A,1],p[B,1],p[C,0])]*r[A][5][9,3]*r[B][6][1,8]*r[C][3][0,14]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9C2I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(C,2),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,1],p[A,1],p[B,1],p[C,1])]*r[A][5][9,3]*r[B][6][0,8]*r[C][7][2,14]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9C3I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,9),(C,3),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,1],p[A,1],p[B,1],p[C,1])]*r[A][5][9,3]*r[B][6][0,8]*r[C][7][3,14]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8C5I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(C,5),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[I,0],p[C,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][5][5,14]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7C5I12(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(C,5),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[I,0],p[C,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][5][5,14]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8C5I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,8),(C,5),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[I,1],p[C,1],p[B,1],p[A,0])]*r[A][3][8,3]*r[B][6][0,8]*r[C][5][5,14]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7C5I11(A, B, C, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([B,C])
    
    for I in range(nc, np):
        if I in {A,B,C}: continue
        v = tuple(sorted([(A,7),(C,5),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[I,1],p[C,1],p[B,1],p[A,1])]*r[A][7][7,3]*r[B][6][0,8]*r[C][5][5,14]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def hm_A3B8C14(r, h, g, p, nc=0):
    np=len(p)
    hdd = {}
    
    for A in range(nc, np):
        for B in range(nc, np):
            if B in {A}: continue
            for C in range(nc, np):
                if C in {A,B}: continue
                u = tuple(sorted([(A,3),(B,8),(C,14)]))
                
                hd = {}
                for v,hv in _A3B8C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B8C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B8C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B8C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B7C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B8C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B8C14I1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B8C14I2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B8C14I3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C14I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C14I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B8I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B8I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B6C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B6C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B4C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B2C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B3C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B4C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B2C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B3C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B1C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B1C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B7C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B7C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B7C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A4B9C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A4B10C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A6B11C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A6B12C14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B8C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B8C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B8C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B8C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B8C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B8C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B8C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B8C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B8C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B8C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A15B8C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A15B8C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B8C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B8C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B8C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A5B8C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A5B8C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B2C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B3C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B4C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B2C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B2C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B3C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B3C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B1C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B1C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B1C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B6C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B11C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B11C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B14C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B12C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B12C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B7C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B9C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B9C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B10C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B10C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B4C14I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C14I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B3C14I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B4C14I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C14I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B3C14I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2C14I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2C14I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _C14I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B1C14I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C14I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _C14I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B1C14I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C14I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A4C14I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A4C14I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11C14I6(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12C14I6(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B6C14I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B6C14I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C14I1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C14I2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C14I3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C14I1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C14I2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C14I3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A6C14I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A6C14I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10C14I4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9C14I4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A15B8I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A15B8I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B8C15I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B8C15I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B8I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B8I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B8C1I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B8I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B8C5I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B8C2I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B8C3I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B8I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B8I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B8C1I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B8I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B8C5I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B8C2I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B8C3I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B8I1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B8I2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B8I3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B8I1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B8I2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B8I3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B8I5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B8I5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A5B8I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A5B8I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B8I15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B8I15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B14I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B14I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B11I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B11I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B12I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B12I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B7I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B7I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C8I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C8I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B2I1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B3I1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B2I2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B2I3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B3I2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B3I3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3I1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C1I1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B1I1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3I2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3I3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C1I2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C1I3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B1I2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B1I3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C2I1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C3I1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C2I2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C2I3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C3I2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C3I3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B4I5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C13I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C13I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C12I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C11I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C12I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C11I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C15I6(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B9I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B10I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B9I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B10I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C10I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C9I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C10I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C9I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3C5I4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3B6I15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A15B6(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A15B6C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A15B6C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A15B6C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B2C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B3C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B4C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B2C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B2C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B3C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B3C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B3C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B2C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B3C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B4C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B4C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B2C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B3C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B3C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B2C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B2C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B3C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B3C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B1C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B1C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B1C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B1C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B1C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B1C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B1C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B1C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B1C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B9C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B7C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B9C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B9C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B10C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B10C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B10C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B9C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B7C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B9C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B9C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B10C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B10C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B10C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A4B2C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A4B3C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A4C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A4B1C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B2C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B3C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B2C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B3C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B2C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B3C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B1C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B1C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B1C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B2C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B3C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B2C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B3C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B2C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B3C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B1C8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B1C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B1C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A2B6C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _B6C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A1B6C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B6C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B6C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A5B4(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A5B4C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A5B4C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A5B4C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B7C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B7C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B7C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B7C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B7C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B7C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B4C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B4C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B4C10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B4C9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B11C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B11C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B11C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B11C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B11C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B11C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B14C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B12C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B14C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B14C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B12C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B12C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B14C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B12C1(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B14C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B14C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B12C2(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B12C3(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B11C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B11C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B12C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B12C5(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B7C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B7C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B4C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B4C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B6C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B6C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B6C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B6C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A6B2C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A6B3C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A6C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A6B1C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B2C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B3C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B2C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B3C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B2C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B3C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B2C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B3C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B1C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B1C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B1C12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B1C11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B9C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B9C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B10C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B10C15(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B2C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B3C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B2C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B3C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B1C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B1C13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3I14J7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3I14J8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3I13J7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3I13J8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3I7J14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3I8J14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3I7J13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3I8J13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3I12J9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3I12J10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3I11J9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3I11J10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3I9J12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3I10J12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3I9J11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A3I10J11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B2I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B3I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B2I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B3I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13C1I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B1I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13C1I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B1I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13C2I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13C3I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11C5I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13C2I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13C3I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11C5I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B2I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B3I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B2I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B3I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14C1I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B1I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14C1I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B1I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14C2I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14C3I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12C5I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14C2I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14C3I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12C5I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B2I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B3I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B2I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B3I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11C1I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B1I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11C2I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11C3I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11C1I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B1I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11C2I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11C3I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B2I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B3I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B2I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B3I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12C1I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B1I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12C2I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12C3I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12C1I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B1I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12C2I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12C3I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B6I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A11B6I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B6I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A12B6I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B4I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B4I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B4I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B4I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B2I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B3I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B4I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B2I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B3I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B4I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B2I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B3I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B4I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B2I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B3I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B4I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C1I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B1I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C2I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C3I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C1I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B1I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C2I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C3I14(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C1I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8B1I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C2I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C3I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C1I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7B1I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C2I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C3I13(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10C15I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10C15I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9C15I7(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9C15I8(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C15I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C15I9(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C15I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C15I10(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B6I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B6I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A13B6I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A14B6I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B2I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B3I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B2I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B3I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10C1I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B1I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10C2I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10C3I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9C1I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B1I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9C2I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9C3I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B2I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B3I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B2I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B3I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10C1I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10B1I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10C2I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A10C3I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9C1I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9B1I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9C2I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A9C3I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C5I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C5I12(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A8C5I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                for v,hv in _A7C5I11(A, B, C, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
                
                hdd[u] = hd
                
    return hdd
    

