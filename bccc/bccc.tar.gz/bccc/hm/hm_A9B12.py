#!/usr/bin/env python 
# -*- coding: utf-8 -*- 
# 
# Author: Qingchun Wang @ NJU 
# E-mail: qingchun720@foxmail.com 
# 


import numpy
from bccc.pub import sign,dei


def _A9B12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    v = tuple(sorted([(A,9),(B,12)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += sum(h[p[I,0],p[I,0]]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(h[p[I,0],p[I,0]]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(h[p[I,1],p[I,1]]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(h[p[I,1],p[I,1]]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(g[dei(p[I,0],p[I,0],p[I,0],p[I,0])]*r[I][194][0,0] for I in range(np) if I not in {A,B})
    hv += sum(g[dei(p[I,0],p[I,1],p[I,0],p[I,1])]*r[I][199][0,0] for I in range(np) if I not in {A,B})
    hv += sum(g[dei(p[I,1],p[I,0],p[I,1],p[I,0])]*r[I][274][0,0] for I in range(np) if I not in {A,B})
    hv += sum(g[dei(p[I,1],p[I,1],p[I,1],p[I,1])]*r[I][279][0,0] for I in range(np) if I not in {A,B})
    hv += h[p[A,0],p[A,0]]*r[A][24][9,9]
    hv += h[p[B,0],p[B,0]]*r[B][9][12,12]
    hv += h[p[B,1],p[B,1]]*r[B][39][12,12]
    hv += h[p[B,1],p[B,1]]*r[B][54][12,12]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[B,1],p[B,1])]*r[B][204][12,12]
    hv += g[dei(p[B,0],p[B,0],p[B,1],p[B,1])]*r[B][214][12,12]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[B,1],p[B,0])]*r[B][201][12,12]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[B,0],p[B,1])]*r[B][252][12,12]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[B,0],p[B,0])]*r[B][249][12,12]
    hv += g[dei(p[B,1],p[B,1],p[B,1],p[B,1])]*r[B][279][12,12]
    hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][9][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][24][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][9][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][9][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][24][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][9][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][39][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][54][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][39][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][39][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][54][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][39][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,0])]*r[I][9][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,0])]*r[I][24][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,0])]*r[I][9][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,0])]*r[I][24][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,1])]*r[I][39][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,1])]*r[I][54][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,1])]*r[I][39][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,1])]*r[I][54][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,0],p[J,0])]*r[I][9][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,0],p[J,0])]*r[I][24][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,1],p[J,0])]*r[I][39][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,1],p[J,0])]*r[I][54][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,0],p[J,1])]*r[I][9][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,0],p[J,1])]*r[I][24][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,1],p[J,1])]*r[I][39][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,1],p[J,1])]*r[I][54][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[I][9][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[I][24][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[I][24][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[I][39][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[I][54][0,0]*r[J][24][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[I][54][0,0]*r[J][9][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[I][9][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[I][24][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[I][24][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[I][39][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[I][54][0,0]*r[J][54][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[I][54][0,0]*r[J][39][0,0] for I in range(np) if I not in {A,B} for J in range(np) if J not in {A,B,I})
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][24][9,9]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][24][9,9]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,0])]*r[A][24][9,9]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,0])]*r[A][24][9,9]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,0])]*r[A][24][9,9]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,1])]*r[A][24][9,9]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][24][9,9]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][24][9,9]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][24][9,9]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][24][9,9]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[B,0],p[B,0],p[I,0],p[I,0])]*r[B][9][12,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(g[dei(p[B,0],p[B,0],p[I,0],p[I,0])]*r[B][9][12,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[B,0],p[B,0],p[I,1],p[I,1])]*r[B][9][12,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(g[dei(p[B,0],p[B,0],p[I,1],p[I,1])]*r[B][9][12,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[B,1],p[B,1],p[I,0],p[I,0])]*r[B][39][12,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[B,1],p[B,1],p[I,0],p[I,0])]*r[B][54][12,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(g[dei(p[B,1],p[B,1],p[I,0],p[I,0])]*r[B][39][12,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[B,1],p[B,1],p[I,1],p[I,1])]*r[B][39][12,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[B,1],p[B,1],p[I,1],p[I,1])]*r[B][54][12,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(g[dei(p[B,1],p[B,1],p[I,1],p[I,1])]*r[B][39][12,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[B,0],p[I,0],p[I,0],p[B,0])]*r[B][9][12,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[B,0],p[I,1],p[I,1],p[B,0])]*r[B][9][12,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[B,1],p[I,0],p[I,0],p[B,1])]*r[B][39][12,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[B,1],p[I,0],p[I,0],p[B,1])]*r[B][54][12,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[B,1],p[I,1],p[I,1],p[B,1])]*r[B][39][12,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[B,1],p[I,1],p[I,1],p[B,1])]*r[B][54][12,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,0],p[B,0],p[B,0],p[I,0])]*r[B][9][12,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,0],p[B,1],p[B,1],p[I,0])]*r[B][39][12,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,0],p[B,1],p[B,1],p[I,0])]*r[B][54][12,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,1],p[B,0],p[B,0],p[I,1])]*r[B][9][12,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,1],p[B,1],p[B,1],p[I,1])]*r[B][39][12,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,1],p[B,1],p[B,1],p[I,1])]*r[B][54][12,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,0],p[B,0])]*r[B][9][12,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,1],p[B,1])]*r[B][39][12,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,1],p[B,1])]*r[B][54][12,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(g[dei(p[I,0],p[I,0],p[B,1],p[B,1])]*r[B][54][12,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,0],p[B,0])]*r[B][9][12,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,1],p[B,1])]*r[B][39][12,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,1],p[B,1])]*r[B][54][12,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(g[dei(p[I,1],p[I,1],p[B,1],p[B,1])]*r[B][54][12,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,1],p[B,1])]*r[A][24][9,9]*r[B][54][12,12]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[A,0])]*r[A][24][9,9]*r[B][54][12,12]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,0],p[B,1])]*r[A][24][9,9]*r[B][54][12,12]
    hv += g[dei(p[B,0],p[B,0],p[A,0],p[A,0])]*r[A][24][9,9]*r[B][9][12,12]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[A,0])]*r[A][24][9,9]*r[B][54][12,12]
    hv += g[dei(p[B,1],p[B,1],p[A,0],p[A,0])]*r[A][24][9,9]*r[B][39][12,12]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B12I1(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,9),(B,12),(I,1)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += h[p[I,0],p[I,0]]*r[I][9][1,0]
        hv += h[p[I,0],p[I,0]]*r[I][24][1,0]
        hv += h[p[I,1],p[I,1]]*r[I][39][1,0]
        hv += h[p[I,1],p[I,1]]*r[I][54][1,0]
        hv += g[dei(p[I,0],p[I,0],p[I,0],p[I,0])]*r[I][194][1,0]
        hv += g[dei(p[I,0],p[I,1],p[I,0],p[I,1])]*r[I][199][1,0]
        hv += g[dei(p[I,1],p[I,0],p[I,1],p[I,0])]*r[I][274][1,0]
        hv += g[dei(p[I,1],p[I,1],p[I,1],p[I,1])]*r[I][279][1,0]
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[J][9][0,0]*r[I][9][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[J][24][0,0]*r[I][24][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[J][9][0,0]*r[I][24][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[J][9][0,0]*r[I][39][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[J][24][0,0]*r[I][54][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[J][9][0,0]*r[I][54][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[J][39][0,0]*r[I][9][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[J][54][0,0]*r[I][24][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[J][39][0,0]*r[I][24][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[J][39][0,0]*r[I][39][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[J][54][0,0]*r[I][54][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[J][39][0,0]*r[I][54][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,0],p[J,0])]*r[J][9][0,0]*r[I][9][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,0],p[J,0])]*r[J][24][0,0]*r[I][24][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,1],p[J,0])]*r[J][9][0,0]*r[I][39][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,1],p[J,0])]*r[J][24][0,0]*r[I][54][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,0],p[J,1])]*r[J][39][0,0]*r[I][9][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,0],p[J,1])]*r[J][54][0,0]*r[I][24][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,1],p[J,1])]*r[J][39][0,0]*r[I][39][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,1],p[J,1])]*r[J][54][0,0]*r[I][54][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,0])]*r[J][9][0,0]*r[I][9][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,0])]*r[J][24][0,0]*r[I][24][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,0])]*r[J][39][0,0]*r[I][9][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,0])]*r[J][54][0,0]*r[I][24][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,1])]*r[J][9][0,0]*r[I][39][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,1])]*r[J][24][0,0]*r[I][54][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,1])]*r[J][39][0,0]*r[I][39][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,1])]*r[J][54][0,0]*r[I][54][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[J][9][0,0]*r[I][9][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[J][24][0,0]*r[I][24][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[J][24][0,0]*r[I][9][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[J][39][0,0]*r[I][9][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[J][54][0,0]*r[I][24][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[J][54][0,0]*r[I][9][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[J][9][0,0]*r[I][39][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[J][24][0,0]*r[I][54][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[J][24][0,0]*r[I][39][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[J][39][0,0]*r[I][39][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[J][54][0,0]*r[I][54][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[J][54][0,0]*r[I][39][1,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][9][1,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][24][1,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][9][1,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][9][1,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][24][1,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][9][1,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][39][1,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][54][1,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][39][1,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][39][1,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][54][1,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][39][1,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,0])]*r[I][9][1,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,0])]*r[I][24][1,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,0])]*r[I][9][1,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,0])]*r[I][24][1,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,1])]*r[I][39][1,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,1])]*r[I][54][1,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,1])]*r[I][39][1,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,1])]*r[I][54][1,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,0],p[J,0])]*r[I][9][1,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,0],p[J,0])]*r[I][24][1,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,1],p[J,0])]*r[I][39][1,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,1],p[J,0])]*r[I][54][1,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,0],p[J,1])]*r[I][9][1,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,0],p[J,1])]*r[I][24][1,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,1],p[J,1])]*r[I][39][1,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,1],p[J,1])]*r[I][54][1,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[I][9][1,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[I][39][1,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[I][9][1,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[I][24][1,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[I][39][1,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[I][54][1,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,0])]*r[A][24][9,9]*r[I][24][1,0]
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,1])]*r[A][24][9,9]*r[I][54][1,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[I,0],p[A,0])]*r[A][24][9,9]*r[I][24][1,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[I,1],p[A,0])]*r[A][24][9,9]*r[I][54][1,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,0])]*r[A][24][9,9]*r[I][24][1,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,1])]*r[A][24][9,9]*r[I][54][1,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][24][9,9]*r[I][24][1,0]
        hv += g[dei(p[I,0],p[I,0],p[A,0],p[A,0])]*r[A][24][9,9]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][24][9,9]*r[I][54][1,0]
        hv += g[dei(p[I,1],p[I,1],p[A,0],p[A,0])]*r[A][24][9,9]*r[I][39][1,0]
        hv += 1/2*g[dei(p[B,0],p[B,0],p[I,0],p[I,0])]*r[B][9][12,12]*r[I][9][1,0]
        hv += g[dei(p[B,0],p[B,0],p[I,0],p[I,0])]*r[B][9][12,12]*r[I][24][1,0]
        hv += 1/2*g[dei(p[B,0],p[B,0],p[I,1],p[I,1])]*r[B][9][12,12]*r[I][39][1,0]
        hv += g[dei(p[B,0],p[B,0],p[I,1],p[I,1])]*r[B][9][12,12]*r[I][54][1,0]
        hv += 1/2*g[dei(p[B,1],p[B,1],p[I,0],p[I,0])]*r[B][39][12,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[B,1],p[B,1],p[I,0],p[I,0])]*r[B][54][12,12]*r[I][24][1,0]
        hv += g[dei(p[B,1],p[B,1],p[I,0],p[I,0])]*r[B][39][12,12]*r[I][24][1,0]
        hv += 1/2*g[dei(p[B,1],p[B,1],p[I,1],p[I,1])]*r[B][39][12,12]*r[I][39][1,0]
        hv += 1/2*g[dei(p[B,1],p[B,1],p[I,1],p[I,1])]*r[B][54][12,12]*r[I][54][1,0]
        hv += g[dei(p[B,1],p[B,1],p[I,1],p[I,1])]*r[B][39][12,12]*r[I][54][1,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[I,0],p[B,0])]*r[B][9][12,12]*r[I][9][1,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[I,1],p[B,0])]*r[B][9][12,12]*r[I][39][1,0]
        hv += -1/2*g[dei(p[B,1],p[I,0],p[I,0],p[B,1])]*r[B][39][12,12]*r[I][9][1,0]
        hv += -1/2*g[dei(p[B,1],p[I,0],p[I,0],p[B,1])]*r[B][54][12,12]*r[I][24][1,0]
        hv += -1/2*g[dei(p[B,1],p[I,1],p[I,1],p[B,1])]*r[B][39][12,12]*r[I][39][1,0]
        hv += -1/2*g[dei(p[B,1],p[I,1],p[I,1],p[B,1])]*r[B][54][12,12]*r[I][54][1,0]
        hv += -1/2*g[dei(p[I,0],p[B,0],p[B,0],p[I,0])]*r[B][9][12,12]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,0],p[B,1],p[B,1],p[I,0])]*r[B][39][12,12]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,0],p[B,1],p[B,1],p[I,0])]*r[B][54][12,12]*r[I][24][1,0]
        hv += -1/2*g[dei(p[I,1],p[B,0],p[B,0],p[I,1])]*r[B][9][12,12]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,1],p[B,1],p[B,1],p[I,1])]*r[B][39][12,12]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,1],p[B,1],p[B,1],p[I,1])]*r[B][54][12,12]*r[I][54][1,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[B,0],p[B,0])]*r[B][9][12,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[B,1],p[B,1])]*r[B][39][12,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[B,1],p[B,1])]*r[B][54][12,12]*r[I][24][1,0]
        hv += g[dei(p[I,0],p[I,0],p[B,1],p[B,1])]*r[B][54][12,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[B,0],p[B,0])]*r[B][9][12,12]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[B,1],p[B,1])]*r[B][39][12,12]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[B,1],p[B,1])]*r[B][54][12,12]*r[I][54][1,0]
        hv += g[dei(p[I,1],p[I,1],p[B,1],p[B,1])]*r[B][54][12,12]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B12I2(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,9),(B,12),(I,2)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += h[p[I,0],p[I,1]]*r[I][15][2,0]
        hv += h[p[I,0],p[I,1]]*r[I][30][2,0]
        hv += h[p[I,1],p[I,0]]*r[I][33][2,0]
        hv += h[p[I,1],p[I,0]]*r[I][48][2,0]
        hv += g[dei(p[I,0],p[I,0],p[I,1],p[I,0])]*r[I][210][2,0]
        hv += g[dei(p[I,0],p[I,1],p[I,1],p[I,1])]*r[I][215][2,0]
        hv += g[dei(p[I,1],p[I,0],p[I,0],p[I,0])]*r[I][258][2,0]
        hv += g[dei(p[I,1],p[I,1],p[I,0],p[I,1])]*r[I][263][2,0]
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,1])]*r[J][9][0,0]*r[I][15][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,1])]*r[J][24][0,0]*r[I][30][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,0],p[I,1])]*r[J][9][0,0]*r[I][30][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,0])]*r[J][9][0,0]*r[I][33][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,0])]*r[J][24][0,0]*r[I][48][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,1],p[I,0])]*r[J][9][0,0]*r[I][48][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,1])]*r[J][39][0,0]*r[I][15][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,1])]*r[J][54][0,0]*r[I][30][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,0],p[I,1])]*r[J][39][0,0]*r[I][30][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,0])]*r[J][39][0,0]*r[I][33][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,0])]*r[J][54][0,0]*r[I][48][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,1],p[I,0])]*r[J][39][0,0]*r[I][48][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,0],p[J,0])]*r[J][9][0,0]*r[I][15][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,0],p[J,0])]*r[J][24][0,0]*r[I][30][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,1],p[J,0])]*r[J][9][0,0]*r[I][33][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,1],p[J,0])]*r[J][24][0,0]*r[I][48][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,0],p[J,1])]*r[J][39][0,0]*r[I][15][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,0],p[J,1])]*r[J][54][0,0]*r[I][30][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,1],p[J,1])]*r[J][39][0,0]*r[I][33][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,1],p[J,1])]*r[J][54][0,0]*r[I][48][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,1])]*r[J][9][0,0]*r[I][15][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,1])]*r[J][24][0,0]*r[I][30][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,1])]*r[J][39][0,0]*r[I][15][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,1])]*r[J][54][0,0]*r[I][30][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,0])]*r[J][9][0,0]*r[I][33][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,0])]*r[J][24][0,0]*r[I][48][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,0])]*r[J][39][0,0]*r[I][33][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,0])]*r[J][54][0,0]*r[I][48][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[J][9][0,0]*r[I][15][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[J][24][0,0]*r[I][30][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[J][24][0,0]*r[I][15][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[J][39][0,0]*r[I][15][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[J][54][0,0]*r[I][30][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[J][54][0,0]*r[I][15][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,0],p[J,0])]*r[J][9][0,0]*r[I][33][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,0],p[J,0])]*r[J][24][0,0]*r[I][48][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,1],p[I,0],p[J,0],p[J,0])]*r[J][24][0,0]*r[I][33][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,1],p[J,1])]*r[J][39][0,0]*r[I][33][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,1],p[J,1])]*r[J][54][0,0]*r[I][48][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,1],p[I,0],p[J,1],p[J,1])]*r[J][54][0,0]*r[I][33][2,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][15][2,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][30][2,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][15][2,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][15][2,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][30][2,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][15][2,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,0],p[J,0])]*r[I][33][2,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,0],p[J,0])]*r[I][48][2,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,1],p[I,0],p[J,0],p[J,0])]*r[I][33][2,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,1],p[J,1])]*r[I][33][2,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,1],p[J,1])]*r[I][48][2,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,1],p[I,0],p[J,1],p[J,1])]*r[I][33][2,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,1])]*r[I][15][2,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,1])]*r[I][30][2,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,1])]*r[I][15][2,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,1])]*r[I][30][2,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,0])]*r[I][33][2,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,0])]*r[I][48][2,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,0])]*r[I][33][2,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,0])]*r[I][48][2,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,0],p[J,0])]*r[I][15][2,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,0],p[J,0])]*r[I][30][2,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,1],p[J,0])]*r[I][33][2,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,1],p[J,0])]*r[I][48][2,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,0],p[J,1])]*r[I][15][2,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,0],p[J,1])]*r[I][30][2,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,1],p[J,1])]*r[I][33][2,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,1],p[J,1])]*r[I][48][2,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,1])]*r[I][15][2,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,0])]*r[I][33][2,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,1])]*r[I][15][2,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,0],p[I,1])]*r[I][30][2,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,0])]*r[I][33][2,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,1],p[I,0])]*r[I][48][2,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,1])]*r[A][24][9,9]*r[I][30][2,0]
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,0])]*r[A][24][9,9]*r[I][48][2,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[I,0],p[A,0])]*r[A][24][9,9]*r[I][30][2,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[I,1],p[A,0])]*r[A][24][9,9]*r[I][48][2,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,1])]*r[A][24][9,9]*r[I][30][2,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,0])]*r[A][24][9,9]*r[I][48][2,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,0],p[A,0])]*r[A][24][9,9]*r[I][30][2,0]
        hv += g[dei(p[I,0],p[I,1],p[A,0],p[A,0])]*r[A][24][9,9]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,0],p[A,0])]*r[A][24][9,9]*r[I][48][2,0]
        hv += g[dei(p[I,1],p[I,0],p[A,0],p[A,0])]*r[A][24][9,9]*r[I][33][2,0]
        hv += 1/2*g[dei(p[B,0],p[B,0],p[I,0],p[I,1])]*r[B][9][12,12]*r[I][15][2,0]
        hv += g[dei(p[B,0],p[B,0],p[I,0],p[I,1])]*r[B][9][12,12]*r[I][30][2,0]
        hv += 1/2*g[dei(p[B,0],p[B,0],p[I,1],p[I,0])]*r[B][9][12,12]*r[I][33][2,0]
        hv += g[dei(p[B,0],p[B,0],p[I,1],p[I,0])]*r[B][9][12,12]*r[I][48][2,0]
        hv += 1/2*g[dei(p[B,1],p[B,1],p[I,0],p[I,1])]*r[B][39][12,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[B,1],p[B,1],p[I,0],p[I,1])]*r[B][54][12,12]*r[I][30][2,0]
        hv += g[dei(p[B,1],p[B,1],p[I,0],p[I,1])]*r[B][39][12,12]*r[I][30][2,0]
        hv += 1/2*g[dei(p[B,1],p[B,1],p[I,1],p[I,0])]*r[B][39][12,12]*r[I][33][2,0]
        hv += 1/2*g[dei(p[B,1],p[B,1],p[I,1],p[I,0])]*r[B][54][12,12]*r[I][48][2,0]
        hv += g[dei(p[B,1],p[B,1],p[I,1],p[I,0])]*r[B][39][12,12]*r[I][48][2,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[I,0],p[B,0])]*r[B][9][12,12]*r[I][15][2,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[I,1],p[B,0])]*r[B][9][12,12]*r[I][33][2,0]
        hv += -1/2*g[dei(p[B,1],p[I,1],p[I,0],p[B,1])]*r[B][39][12,12]*r[I][15][2,0]
        hv += -1/2*g[dei(p[B,1],p[I,1],p[I,0],p[B,1])]*r[B][54][12,12]*r[I][30][2,0]
        hv += -1/2*g[dei(p[B,1],p[I,0],p[I,1],p[B,1])]*r[B][39][12,12]*r[I][33][2,0]
        hv += -1/2*g[dei(p[B,1],p[I,0],p[I,1],p[B,1])]*r[B][54][12,12]*r[I][48][2,0]
        hv += -1/2*g[dei(p[I,0],p[B,0],p[B,0],p[I,1])]*r[B][9][12,12]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,0],p[B,1],p[B,1],p[I,1])]*r[B][39][12,12]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,0],p[B,1],p[B,1],p[I,1])]*r[B][54][12,12]*r[I][30][2,0]
        hv += -1/2*g[dei(p[I,1],p[B,0],p[B,0],p[I,0])]*r[B][9][12,12]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,1],p[B,1],p[B,1],p[I,0])]*r[B][39][12,12]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,1],p[B,1],p[B,1],p[I,0])]*r[B][54][12,12]*r[I][48][2,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[B,0],p[B,0])]*r[B][9][12,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[B,1],p[B,1])]*r[B][39][12,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[B,1],p[B,1])]*r[B][54][12,12]*r[I][30][2,0]
        hv += g[dei(p[I,0],p[I,1],p[B,1],p[B,1])]*r[B][54][12,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[B,0],p[B,0])]*r[B][9][12,12]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[B,1],p[B,1])]*r[B][39][12,12]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[B,1],p[B,1])]*r[B][54][12,12]*r[I][48][2,0]
        hv += g[dei(p[I,1],p[I,0],p[B,1],p[B,1])]*r[B][54][12,12]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B12I3(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,9),(B,12),(I,3)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += h[p[I,0],p[I,1]]*r[I][15][3,0]
        hv += h[p[I,0],p[I,1]]*r[I][30][3,0]
        hv += h[p[I,1],p[I,0]]*r[I][33][3,0]
        hv += h[p[I,1],p[I,0]]*r[I][48][3,0]
        hv += g[dei(p[I,0],p[I,0],p[I,1],p[I,0])]*r[I][210][3,0]
        hv += g[dei(p[I,0],p[I,1],p[I,1],p[I,1])]*r[I][215][3,0]
        hv += g[dei(p[I,1],p[I,0],p[I,0],p[I,0])]*r[I][258][3,0]
        hv += g[dei(p[I,1],p[I,1],p[I,0],p[I,1])]*r[I][263][3,0]
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,1])]*r[J][9][0,0]*r[I][15][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,1])]*r[J][24][0,0]*r[I][30][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,0],p[I,1])]*r[J][9][0,0]*r[I][30][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,0])]*r[J][9][0,0]*r[I][33][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,0])]*r[J][24][0,0]*r[I][48][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,1],p[I,0])]*r[J][9][0,0]*r[I][48][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,1])]*r[J][39][0,0]*r[I][15][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,1])]*r[J][54][0,0]*r[I][30][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,0],p[I,1])]*r[J][39][0,0]*r[I][30][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,0])]*r[J][39][0,0]*r[I][33][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,0])]*r[J][54][0,0]*r[I][48][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,1],p[I,0])]*r[J][39][0,0]*r[I][48][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,0],p[J,0])]*r[J][9][0,0]*r[I][15][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,0],p[J,0])]*r[J][24][0,0]*r[I][30][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,1],p[J,0])]*r[J][9][0,0]*r[I][33][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,1],p[J,0])]*r[J][24][0,0]*r[I][48][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,0],p[J,1])]*r[J][39][0,0]*r[I][15][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,0],p[J,1])]*r[J][54][0,0]*r[I][30][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,1],p[J,1])]*r[J][39][0,0]*r[I][33][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,1],p[J,1])]*r[J][54][0,0]*r[I][48][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,1])]*r[J][9][0,0]*r[I][15][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,1])]*r[J][24][0,0]*r[I][30][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,1])]*r[J][39][0,0]*r[I][15][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,1])]*r[J][54][0,0]*r[I][30][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,0])]*r[J][9][0,0]*r[I][33][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,0])]*r[J][24][0,0]*r[I][48][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,0])]*r[J][39][0,0]*r[I][33][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,0])]*r[J][54][0,0]*r[I][48][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[J][9][0,0]*r[I][15][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[J][24][0,0]*r[I][30][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[J][24][0,0]*r[I][15][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[J][39][0,0]*r[I][15][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[J][54][0,0]*r[I][30][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[J][54][0,0]*r[I][15][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,0],p[J,0])]*r[J][9][0,0]*r[I][33][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,0],p[J,0])]*r[J][24][0,0]*r[I][48][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,1],p[I,0],p[J,0],p[J,0])]*r[J][24][0,0]*r[I][33][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,1],p[J,1])]*r[J][39][0,0]*r[I][33][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,1],p[J,1])]*r[J][54][0,0]*r[I][48][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,1],p[I,0],p[J,1],p[J,1])]*r[J][54][0,0]*r[I][33][3,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][15][3,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][30][3,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][15][3,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][15][3,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][30][3,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][15][3,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,0],p[J,0])]*r[I][33][3,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,0],p[J,0])]*r[I][48][3,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,1],p[I,0],p[J,0],p[J,0])]*r[I][33][3,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,1],p[J,1])]*r[I][33][3,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[I,0],p[J,1],p[J,1])]*r[I][48][3,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,1],p[I,0],p[J,1],p[J,1])]*r[I][33][3,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,1])]*r[I][15][3,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,1])]*r[I][30][3,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,1])]*r[I][15][3,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,1])]*r[I][30][3,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,0])]*r[I][33][3,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,0])]*r[I][48][3,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,0])]*r[I][33][3,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,0])]*r[I][48][3,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,0],p[J,0])]*r[I][15][3,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,0],p[J,0])]*r[I][30][3,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,1],p[J,0])]*r[I][33][3,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,1],p[J,0])]*r[I][48][3,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,0],p[J,1])]*r[I][15][3,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,0],p[J,1])]*r[I][30][3,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,1],p[J,1])]*r[I][33][3,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,1],p[J,1])]*r[I][48][3,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,1])]*r[I][15][3,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,0])]*r[I][33][3,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,1])]*r[I][15][3,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,0],p[I,1])]*r[I][30][3,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,0])]*r[I][33][3,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,1],p[I,0])]*r[I][48][3,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,0],p[I,1])]*r[A][24][9,9]*r[I][30][3,0]
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,1],p[I,0])]*r[A][24][9,9]*r[I][48][3,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[I,0],p[A,0])]*r[A][24][9,9]*r[I][30][3,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[I,1],p[A,0])]*r[A][24][9,9]*r[I][48][3,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,0],p[I,1])]*r[A][24][9,9]*r[I][30][3,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,0],p[I,0])]*r[A][24][9,9]*r[I][48][3,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,0],p[A,0])]*r[A][24][9,9]*r[I][30][3,0]
        hv += g[dei(p[I,0],p[I,1],p[A,0],p[A,0])]*r[A][24][9,9]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,0],p[A,0])]*r[A][24][9,9]*r[I][48][3,0]
        hv += g[dei(p[I,1],p[I,0],p[A,0],p[A,0])]*r[A][24][9,9]*r[I][33][3,0]
        hv += 1/2*g[dei(p[B,0],p[B,0],p[I,0],p[I,1])]*r[B][9][12,12]*r[I][15][3,0]
        hv += g[dei(p[B,0],p[B,0],p[I,0],p[I,1])]*r[B][9][12,12]*r[I][30][3,0]
        hv += 1/2*g[dei(p[B,0],p[B,0],p[I,1],p[I,0])]*r[B][9][12,12]*r[I][33][3,0]
        hv += g[dei(p[B,0],p[B,0],p[I,1],p[I,0])]*r[B][9][12,12]*r[I][48][3,0]
        hv += 1/2*g[dei(p[B,1],p[B,1],p[I,0],p[I,1])]*r[B][39][12,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[B,1],p[B,1],p[I,0],p[I,1])]*r[B][54][12,12]*r[I][30][3,0]
        hv += g[dei(p[B,1],p[B,1],p[I,0],p[I,1])]*r[B][39][12,12]*r[I][30][3,0]
        hv += 1/2*g[dei(p[B,1],p[B,1],p[I,1],p[I,0])]*r[B][39][12,12]*r[I][33][3,0]
        hv += 1/2*g[dei(p[B,1],p[B,1],p[I,1],p[I,0])]*r[B][54][12,12]*r[I][48][3,0]
        hv += g[dei(p[B,1],p[B,1],p[I,1],p[I,0])]*r[B][39][12,12]*r[I][48][3,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[I,0],p[B,0])]*r[B][9][12,12]*r[I][15][3,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[I,1],p[B,0])]*r[B][9][12,12]*r[I][33][3,0]
        hv += -1/2*g[dei(p[B,1],p[I,1],p[I,0],p[B,1])]*r[B][39][12,12]*r[I][15][3,0]
        hv += -1/2*g[dei(p[B,1],p[I,1],p[I,0],p[B,1])]*r[B][54][12,12]*r[I][30][3,0]
        hv += -1/2*g[dei(p[B,1],p[I,0],p[I,1],p[B,1])]*r[B][39][12,12]*r[I][33][3,0]
        hv += -1/2*g[dei(p[B,1],p[I,0],p[I,1],p[B,1])]*r[B][54][12,12]*r[I][48][3,0]
        hv += -1/2*g[dei(p[I,0],p[B,0],p[B,0],p[I,1])]*r[B][9][12,12]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,0],p[B,1],p[B,1],p[I,1])]*r[B][39][12,12]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,0],p[B,1],p[B,1],p[I,1])]*r[B][54][12,12]*r[I][30][3,0]
        hv += -1/2*g[dei(p[I,1],p[B,0],p[B,0],p[I,0])]*r[B][9][12,12]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,1],p[B,1],p[B,1],p[I,0])]*r[B][39][12,12]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,1],p[B,1],p[B,1],p[I,0])]*r[B][54][12,12]*r[I][48][3,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[B,0],p[B,0])]*r[B][9][12,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[B,1],p[B,1])]*r[B][39][12,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[B,1],p[B,1])]*r[B][54][12,12]*r[I][30][3,0]
        hv += g[dei(p[I,0],p[I,1],p[B,1],p[B,1])]*r[B][54][12,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[B,0],p[B,0])]*r[B][9][12,12]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[B,1],p[B,1])]*r[B][39][12,12]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[B,1],p[B,1])]*r[B][54][12,12]*r[I][48][3,0]
        hv += g[dei(p[I,1],p[I,0],p[B,1],p[B,1])]*r[B][54][12,12]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    v = tuple(sorted([(A,10),(B,12)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += h[p[A,1],p[A,0]]*r[A][48][10,9]
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][48][10,9]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][48][10,9]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,0])]*r[A][48][10,9]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,0])]*r[A][48][10,9]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,0])]*r[A][48][10,9]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,1])]*r[A][48][10,9]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][48][10,9]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][48][10,9]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][48][10,9]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][48][10,9]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,1],p[B,1])]*r[A][48][10,9]*r[B][54][12,12]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[A,0])]*r[A][48][10,9]*r[B][54][12,12]
    hv += -1/2*g[dei(p[B,1],p[A,0],p[A,1],p[B,1])]*r[A][48][10,9]*r[B][54][12,12]
    hv += g[dei(p[B,0],p[B,0],p[A,1],p[A,0])]*r[A][48][10,9]*r[B][9][12,12]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[A,0])]*r[A][48][10,9]*r[B][54][12,12]
    hv += g[dei(p[B,1],p[B,1],p[A,1],p[A,0])]*r[A][48][10,9]*r[B][39][12,12]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    v = tuple(sorted([(A,9),(B,11)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += h[p[B,0],p[B,1]]*r[B][30][11,12]
    hv += g[dei(p[B,0],p[B,0],p[B,0],p[B,1])]*r[B][198][11,12]
    hv += g[dei(p[B,1],p[B,1],p[B,0],p[B,1])]*r[B][263][11,12]
    hv += sum(1/2*g[dei(p[B,0],p[B,1],p[I,0],p[I,0])]*r[B][30][11,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[B,0],p[B,1],p[I,1],p[I,1])]*r[B][30][11,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[B,0],p[I,0],p[I,0],p[B,1])]*r[B][30][11,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[B,0],p[I,1],p[I,1],p[B,1])]*r[B][30][11,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,0],p[B,1],p[B,0],p[I,0])]*r[B][30][11,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,1],p[B,1],p[B,0],p[I,1])]*r[B][30][11,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,0],p[B,1])]*r[B][30][11,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(g[dei(p[I,0],p[I,0],p[B,0],p[B,1])]*r[B][30][11,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,0],p[B,1])]*r[B][30][11,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(g[dei(p[I,1],p[I,1],p[B,0],p[B,1])]*r[B][30][11,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += 1/2*g[dei(p[A,0],p[A,0],p[B,0],p[B,1])]*r[A][24][9,9]*r[B][30][11,12]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[A,0])]*r[A][24][9,9]*r[B][30][11,12]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,0],p[B,1])]*r[A][24][9,9]*r[B][30][11,12]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[A,0])]*r[A][24][9,9]*r[B][30][11,12]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B12I9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(B,12),(I,9)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += h[p[A,0],p[I,0]]*r[A][0][0,9]*r[I][1][9,0]
        hv += g[dei(p[A,0],p[I,0],p[A,0],p[A,0])]*r[A][66][0,9]*r[I][1][9,0]
        hv += g[dei(p[A,1],p[I,0],p[A,1],p[A,0])]*r[A][146][0,9]*r[I][1][9,0]
        hv += g[dei(p[A,0],p[I,0],p[I,0],p[I,0])]*r[A][0][0,9]*r[I][97][9,0]
        hv += g[dei(p[A,0],p[I,1],p[I,0],p[I,1])]*r[A][0][0,9]*r[I][117][9,0]
        hv += sum(-1/4*g[dei(p[A,0],p[J,0],p[J,0],p[I,0])]*r[A][0][0,9]*r[J][9][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[A,0],p[J,1],p[J,1],p[I,0])]*r[A][0][0,9]*r[J][39][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,0],p[I,0],p[J,0],p[J,0])]*r[A][0][0,9]*r[J][9][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,0],p[I,0],p[J,0],p[J,0])]*r[A][0][0,9]*r[J][24][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,0],p[I,0],p[J,1],p[J,1])]*r[A][0][0,9]*r[J][39][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,0],p[I,0],p[J,1],p[J,1])]*r[A][0][0,9]*r[J][54][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[A,0],p[I,0])]*r[A][0][0,9]*r[J][9][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[A,0],p[I,0])]*r[A][0][0,9]*r[J][39][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[A,0],p[J,0])]*r[A][0][0,9]*r[J][9][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[A,0],p[J,1])]*r[A][0][0,9]*r[J][39][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,0],p[I,0],p[J,0],p[J,0])]*r[A][0][0,9]*r[I][1][9,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,0],p[I,0],p[J,0],p[J,0])]*r[A][0][0,9]*r[I][1][9,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,0],p[I,0],p[J,1],p[J,1])]*r[A][0][0,9]*r[I][1][9,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,0],p[I,0],p[J,1],p[J,1])]*r[A][0][0,9]*r[I][1][9,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[A,0],p[J,0],p[J,0],p[I,0])]*r[A][0][0,9]*r[I][1][9,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[A,0],p[J,1],p[J,1],p[I,0])]*r[A][0][0,9]*r[I][1][9,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[A,0],p[J,0])]*r[A][0][0,9]*r[I][1][9,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[A,0],p[J,1])]*r[A][0][0,9]*r[I][1][9,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[A,0],p[I,0])]*r[A][0][0,9]*r[I][1][9,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[A,0],p[I,0])]*r[A][0][0,9]*r[I][1][9,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[I,0])]*r[A][0][0,9]*r[B][9][12,12]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[I,0])]*r[A][0][0,9]*r[B][39][12,12]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[B,0],p[B,0])]*r[A][0][0,9]*r[B][9][12,12]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[B,1],p[B,1])]*r[A][0][0,9]*r[B][39][12,12]*r[I][1][9,0]
        hv += g[dei(p[A,0],p[I,0],p[B,1],p[B,1])]*r[A][0][0,9]*r[B][54][12,12]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[I,0])]*r[A][0][0,9]*r[B][9][12,12]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[I,0])]*r[A][0][0,9]*r[B][39][12,12]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][9][12,12]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,1],p[I,0],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][39][12,12]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B12I9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,1),(B,12),(I,9)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += h[p[A,0],p[I,0]]*r[A][0][1,9]*r[I][1][9,0]
        hv += g[dei(p[A,0],p[I,0],p[A,0],p[A,0])]*r[A][66][1,9]*r[I][1][9,0]
        hv += g[dei(p[A,1],p[I,0],p[A,1],p[A,0])]*r[A][146][1,9]*r[I][1][9,0]
        hv += g[dei(p[A,0],p[I,0],p[I,0],p[I,0])]*r[A][0][1,9]*r[I][97][9,0]
        hv += g[dei(p[A,0],p[I,1],p[I,0],p[I,1])]*r[A][0][1,9]*r[I][117][9,0]
        hv += sum(-1/4*g[dei(p[A,0],p[J,0],p[J,0],p[I,0])]*r[A][0][1,9]*r[J][9][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[A,0],p[J,1],p[J,1],p[I,0])]*r[A][0][1,9]*r[J][39][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,0],p[I,0],p[J,0],p[J,0])]*r[A][0][1,9]*r[J][9][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,0],p[I,0],p[J,0],p[J,0])]*r[A][0][1,9]*r[J][24][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,0],p[I,0],p[J,1],p[J,1])]*r[A][0][1,9]*r[J][39][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,0],p[I,0],p[J,1],p[J,1])]*r[A][0][1,9]*r[J][54][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[A,0],p[I,0])]*r[A][0][1,9]*r[J][9][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[A,0],p[I,0])]*r[A][0][1,9]*r[J][39][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[A,0],p[J,0])]*r[A][0][1,9]*r[J][9][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[A,0],p[J,1])]*r[A][0][1,9]*r[J][39][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,0],p[I,0],p[J,0],p[J,0])]*r[A][0][1,9]*r[I][1][9,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,0],p[I,0],p[J,0],p[J,0])]*r[A][0][1,9]*r[I][1][9,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,0],p[I,0],p[J,1],p[J,1])]*r[A][0][1,9]*r[I][1][9,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,0],p[I,0],p[J,1],p[J,1])]*r[A][0][1,9]*r[I][1][9,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[A,0],p[J,0],p[J,0],p[I,0])]*r[A][0][1,9]*r[I][1][9,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[A,0],p[J,1],p[J,1],p[I,0])]*r[A][0][1,9]*r[I][1][9,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[A,0],p[J,0])]*r[A][0][1,9]*r[I][1][9,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[A,0],p[J,1])]*r[A][0][1,9]*r[I][1][9,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[A,0],p[I,0])]*r[A][0][1,9]*r[I][1][9,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[A,0],p[I,0])]*r[A][0][1,9]*r[I][1][9,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[I,0])]*r[A][0][1,9]*r[B][9][12,12]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[I,0])]*r[A][0][1,9]*r[B][39][12,12]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[B,0],p[B,0])]*r[A][0][1,9]*r[B][9][12,12]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[B,1],p[B,1])]*r[A][0][1,9]*r[B][39][12,12]*r[I][1][9,0]
        hv += g[dei(p[A,0],p[I,0],p[B,1],p[B,1])]*r[A][0][1,9]*r[B][54][12,12]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[I,0])]*r[A][0][1,9]*r[B][9][12,12]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[I,0])]*r[A][0][1,9]*r[B][39][12,12]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][9][12,12]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,1],p[I,0],p[A,0],p[B,1])]*r[A][0][1,9]*r[B][39][12,12]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B12I10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(B,12),(I,10)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += h[p[A,0],p[I,1]]*r[A][0][0,9]*r[I][5][10,0]
        hv += g[dei(p[A,0],p[I,1],p[A,0],p[A,0])]*r[A][66][0,9]*r[I][5][10,0]
        hv += g[dei(p[A,1],p[I,1],p[A,1],p[A,0])]*r[A][146][0,9]*r[I][5][10,0]
        hv += g[dei(p[A,0],p[I,0],p[I,1],p[I,0])]*r[A][0][0,9]*r[I][161][10,0]
        hv += g[dei(p[A,0],p[I,1],p[I,1],p[I,1])]*r[A][0][0,9]*r[I][181][10,0]
        hv += sum(-1/4*g[dei(p[A,0],p[J,0],p[J,0],p[I,1])]*r[A][0][0,9]*r[J][9][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[A,0],p[J,1],p[J,1],p[I,1])]*r[A][0][0,9]*r[J][39][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,0],p[I,1],p[J,0],p[J,0])]*r[A][0][0,9]*r[J][9][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,0],p[I,1],p[J,0],p[J,0])]*r[A][0][0,9]*r[J][24][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,0],p[I,1],p[J,1],p[J,1])]*r[A][0][0,9]*r[J][39][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,0],p[I,1],p[J,1],p[J,1])]*r[A][0][0,9]*r[J][54][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[A,0],p[I,1])]*r[A][0][0,9]*r[J][9][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[A,0],p[I,1])]*r[A][0][0,9]*r[J][39][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[A,0],p[J,0])]*r[A][0][0,9]*r[J][9][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[A,0],p[J,1])]*r[A][0][0,9]*r[J][39][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,0],p[I,1],p[J,0],p[J,0])]*r[A][0][0,9]*r[I][5][10,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,0],p[I,1],p[J,0],p[J,0])]*r[A][0][0,9]*r[I][5][10,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,0],p[I,1],p[J,1],p[J,1])]*r[A][0][0,9]*r[I][5][10,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,0],p[I,1],p[J,1],p[J,1])]*r[A][0][0,9]*r[I][5][10,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[A,0],p[J,0],p[J,0],p[I,1])]*r[A][0][0,9]*r[I][5][10,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[A,0],p[J,1],p[J,1],p[I,1])]*r[A][0][0,9]*r[I][5][10,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[A,0],p[J,0])]*r[A][0][0,9]*r[I][5][10,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[A,0],p[J,1])]*r[A][0][0,9]*r[I][5][10,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[A,0],p[I,1])]*r[A][0][0,9]*r[I][5][10,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[A,0],p[I,1])]*r[A][0][0,9]*r[I][5][10,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[I,1])]*r[A][0][0,9]*r[B][9][12,12]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[I,1])]*r[A][0][0,9]*r[B][39][12,12]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[B,0],p[B,0])]*r[A][0][0,9]*r[B][9][12,12]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[B,1],p[B,1])]*r[A][0][0,9]*r[B][39][12,12]*r[I][5][10,0]
        hv += g[dei(p[A,0],p[I,1],p[B,1],p[B,1])]*r[A][0][0,9]*r[B][54][12,12]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[I,1])]*r[A][0][0,9]*r[B][9][12,12]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[I,1])]*r[A][0][0,9]*r[B][39][12,12]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][9][12,12]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,1],p[I,1],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][39][12,12]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B12I10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,1),(B,12),(I,10)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += h[p[A,0],p[I,1]]*r[A][0][1,9]*r[I][5][10,0]
        hv += g[dei(p[A,0],p[I,1],p[A,0],p[A,0])]*r[A][66][1,9]*r[I][5][10,0]
        hv += g[dei(p[A,1],p[I,1],p[A,1],p[A,0])]*r[A][146][1,9]*r[I][5][10,0]
        hv += g[dei(p[A,0],p[I,0],p[I,1],p[I,0])]*r[A][0][1,9]*r[I][161][10,0]
        hv += g[dei(p[A,0],p[I,1],p[I,1],p[I,1])]*r[A][0][1,9]*r[I][181][10,0]
        hv += sum(-1/4*g[dei(p[A,0],p[J,0],p[J,0],p[I,1])]*r[A][0][1,9]*r[J][9][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[A,0],p[J,1],p[J,1],p[I,1])]*r[A][0][1,9]*r[J][39][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,0],p[I,1],p[J,0],p[J,0])]*r[A][0][1,9]*r[J][9][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,0],p[I,1],p[J,0],p[J,0])]*r[A][0][1,9]*r[J][24][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,0],p[I,1],p[J,1],p[J,1])]*r[A][0][1,9]*r[J][39][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,0],p[I,1],p[J,1],p[J,1])]*r[A][0][1,9]*r[J][54][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[A,0],p[I,1])]*r[A][0][1,9]*r[J][9][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[A,0],p[I,1])]*r[A][0][1,9]*r[J][39][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[A,0],p[J,0])]*r[A][0][1,9]*r[J][9][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[A,0],p[J,1])]*r[A][0][1,9]*r[J][39][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,0],p[I,1],p[J,0],p[J,0])]*r[A][0][1,9]*r[I][5][10,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,0],p[I,1],p[J,0],p[J,0])]*r[A][0][1,9]*r[I][5][10,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,0],p[I,1],p[J,1],p[J,1])]*r[A][0][1,9]*r[I][5][10,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,0],p[I,1],p[J,1],p[J,1])]*r[A][0][1,9]*r[I][5][10,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[A,0],p[J,0],p[J,0],p[I,1])]*r[A][0][1,9]*r[I][5][10,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[A,0],p[J,1],p[J,1],p[I,1])]*r[A][0][1,9]*r[I][5][10,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[A,0],p[J,0])]*r[A][0][1,9]*r[I][5][10,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[A,0],p[J,1])]*r[A][0][1,9]*r[I][5][10,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[A,0],p[I,1])]*r[A][0][1,9]*r[I][5][10,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[A,0],p[I,1])]*r[A][0][1,9]*r[I][5][10,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[I,1])]*r[A][0][1,9]*r[B][9][12,12]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[I,1])]*r[A][0][1,9]*r[B][39][12,12]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[B,0],p[B,0])]*r[A][0][1,9]*r[B][9][12,12]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[B,1],p[B,1])]*r[A][0][1,9]*r[B][39][12,12]*r[I][5][10,0]
        hv += g[dei(p[A,0],p[I,1],p[B,1],p[B,1])]*r[A][0][1,9]*r[B][54][12,12]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[I,1])]*r[A][0][1,9]*r[B][9][12,12]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[I,1])]*r[A][0][1,9]*r[B][39][12,12]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][9][12,12]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,1],p[I,1],p[A,0],p[B,1])]*r[A][0][1,9]*r[B][39][12,12]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B12I9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,2),(B,12),(I,9)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += h[p[A,1],p[I,0]]*r[A][4][2,9]*r[I][1][9,0]
        hv += g[dei(p[A,0],p[I,0],p[A,1],p[A,0])]*r[A][82][2,9]*r[I][1][9,0]
        hv += g[dei(p[A,1],p[I,0],p[A,0],p[A,0])]*r[A][130][2,9]*r[I][1][9,0]
        hv += g[dei(p[A,1],p[I,0],p[I,0],p[I,0])]*r[A][4][2,9]*r[I][97][9,0]
        hv += g[dei(p[A,1],p[I,1],p[I,0],p[I,1])]*r[A][4][2,9]*r[I][117][9,0]
        hv += sum(-1/4*g[dei(p[A,1],p[J,0],p[J,0],p[I,0])]*r[A][4][2,9]*r[J][9][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[A,1],p[J,1],p[J,1],p[I,0])]*r[A][4][2,9]*r[J][39][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,1],p[I,0],p[J,0],p[J,0])]*r[A][4][2,9]*r[J][9][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,1],p[I,0],p[J,0],p[J,0])]*r[A][4][2,9]*r[J][24][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,1],p[I,0],p[J,1],p[J,1])]*r[A][4][2,9]*r[J][39][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,1],p[I,0],p[J,1],p[J,1])]*r[A][4][2,9]*r[J][54][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[A,1],p[I,0])]*r[A][4][2,9]*r[J][9][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[A,1],p[I,0])]*r[A][4][2,9]*r[J][39][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[A,1],p[J,0])]*r[A][4][2,9]*r[J][9][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[A,1],p[J,1])]*r[A][4][2,9]*r[J][39][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,1],p[I,0],p[J,0],p[J,0])]*r[A][4][2,9]*r[I][1][9,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,1],p[I,0],p[J,0],p[J,0])]*r[A][4][2,9]*r[I][1][9,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,1],p[I,0],p[J,1],p[J,1])]*r[A][4][2,9]*r[I][1][9,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,1],p[I,0],p[J,1],p[J,1])]*r[A][4][2,9]*r[I][1][9,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[A,1],p[J,0],p[J,0],p[I,0])]*r[A][4][2,9]*r[I][1][9,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[A,1],p[J,1],p[J,1],p[I,0])]*r[A][4][2,9]*r[I][1][9,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[A,1],p[J,0])]*r[A][4][2,9]*r[I][1][9,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[A,1],p[J,1])]*r[A][4][2,9]*r[I][1][9,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[A,1],p[I,0])]*r[A][4][2,9]*r[I][1][9,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[A,1],p[I,0])]*r[A][4][2,9]*r[I][1][9,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[I,0])]*r[A][4][2,9]*r[B][9][12,12]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[I,0])]*r[A][4][2,9]*r[B][39][12,12]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[B,0],p[B,0])]*r[A][4][2,9]*r[B][9][12,12]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[B,1],p[B,1])]*r[A][4][2,9]*r[B][39][12,12]*r[I][1][9,0]
        hv += g[dei(p[A,1],p[I,0],p[B,1],p[B,1])]*r[A][4][2,9]*r[B][54][12,12]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[I,0])]*r[A][4][2,9]*r[B][9][12,12]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[I,0])]*r[A][4][2,9]*r[B][39][12,12]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][9][12,12]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,1],p[I,0],p[A,1],p[B,1])]*r[A][4][2,9]*r[B][39][12,12]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B12I9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,3),(B,12),(I,9)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += h[p[A,1],p[I,0]]*r[A][4][3,9]*r[I][1][9,0]
        hv += g[dei(p[A,0],p[I,0],p[A,1],p[A,0])]*r[A][82][3,9]*r[I][1][9,0]
        hv += g[dei(p[A,1],p[I,0],p[A,0],p[A,0])]*r[A][130][3,9]*r[I][1][9,0]
        hv += g[dei(p[A,1],p[I,0],p[I,0],p[I,0])]*r[A][4][3,9]*r[I][97][9,0]
        hv += g[dei(p[A,1],p[I,1],p[I,0],p[I,1])]*r[A][4][3,9]*r[I][117][9,0]
        hv += sum(-1/4*g[dei(p[A,1],p[J,0],p[J,0],p[I,0])]*r[A][4][3,9]*r[J][9][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[A,1],p[J,1],p[J,1],p[I,0])]*r[A][4][3,9]*r[J][39][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,1],p[I,0],p[J,0],p[J,0])]*r[A][4][3,9]*r[J][9][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,1],p[I,0],p[J,0],p[J,0])]*r[A][4][3,9]*r[J][24][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,1],p[I,0],p[J,1],p[J,1])]*r[A][4][3,9]*r[J][39][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,1],p[I,0],p[J,1],p[J,1])]*r[A][4][3,9]*r[J][54][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[A,1],p[I,0])]*r[A][4][3,9]*r[J][9][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[A,1],p[I,0])]*r[A][4][3,9]*r[J][39][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[A,1],p[J,0])]*r[A][4][3,9]*r[J][9][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[A,1],p[J,1])]*r[A][4][3,9]*r[J][39][0,0]*r[I][1][9,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,1],p[I,0],p[J,0],p[J,0])]*r[A][4][3,9]*r[I][1][9,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,1],p[I,0],p[J,0],p[J,0])]*r[A][4][3,9]*r[I][1][9,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,1],p[I,0],p[J,1],p[J,1])]*r[A][4][3,9]*r[I][1][9,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,1],p[I,0],p[J,1],p[J,1])]*r[A][4][3,9]*r[I][1][9,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[A,1],p[J,0],p[J,0],p[I,0])]*r[A][4][3,9]*r[I][1][9,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[A,1],p[J,1],p[J,1],p[I,0])]*r[A][4][3,9]*r[I][1][9,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[A,1],p[J,0])]*r[A][4][3,9]*r[I][1][9,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[A,1],p[J,1])]*r[A][4][3,9]*r[I][1][9,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[A,1],p[I,0])]*r[A][4][3,9]*r[I][1][9,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[A,1],p[I,0])]*r[A][4][3,9]*r[I][1][9,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[I,0])]*r[A][4][3,9]*r[B][9][12,12]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[I,0])]*r[A][4][3,9]*r[B][39][12,12]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[B,0],p[B,0])]*r[A][4][3,9]*r[B][9][12,12]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[B,1],p[B,1])]*r[A][4][3,9]*r[B][39][12,12]*r[I][1][9,0]
        hv += g[dei(p[A,1],p[I,0],p[B,1],p[B,1])]*r[A][4][3,9]*r[B][54][12,12]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[I,0])]*r[A][4][3,9]*r[B][9][12,12]*r[I][1][9,0]
        hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[I,0])]*r[A][4][3,9]*r[B][39][12,12]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][9][12,12]*r[I][1][9,0]
        hv += -1/2*g[dei(p[B,1],p[I,0],p[A,1],p[B,1])]*r[A][4][3,9]*r[B][39][12,12]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5B12I7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,5),(B,12),(I,7)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += h[p[A,1],p[I,0]]*r[A][6][5,9]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,0],p[A,0],p[A,1],p[I,0])]*r[A][114][5,9]*r[I][3][7,0]
        hv += -1/2*g[dei(p[A,1],p[A,0],p[A,0],p[I,0])]*r[A][162][5,9]*r[I][3][7,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[A,1],p[A,0])]*r[A][114][5,9]*r[I][3][7,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[A,0],p[A,0])]*r[A][162][5,9]*r[I][3][7,0]
        hv += -1*g[dei(p[I,0],p[I,0],p[A,1],p[I,0])]*r[A][6][5,9]*r[I][65][7,0]
        hv += -1*g[dei(p[I,0],p[I,1],p[A,1],p[I,1])]*r[A][6][5,9]*r[I][85][7,0]
        hv += sum(-1/4*g[dei(p[A,1],p[J,0],p[J,0],p[I,0])]*r[A][6][5,9]*r[J][24][0,0]*r[I][3][7,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[A,1],p[J,1],p[J,1],p[I,0])]*r[A][6][5,9]*r[J][54][0,0]*r[I][3][7,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,1],p[I,0],p[J,0],p[J,0])]*r[A][6][5,9]*r[J][24][0,0]*r[I][3][7,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,1],p[I,0],p[J,1],p[J,1])]*r[A][6][5,9]*r[J][54][0,0]*r[I][3][7,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[A,1],p[I,0])]*r[A][6][5,9]*r[J][24][0,0]*r[I][3][7,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[A,1],p[I,0])]*r[A][6][5,9]*r[J][9][0,0]*r[I][3][7,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[A,1],p[I,0])]*r[A][6][5,9]*r[J][54][0,0]*r[I][3][7,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[A,1],p[I,0])]*r[A][6][5,9]*r[J][39][0,0]*r[I][3][7,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[A,1],p[J,0])]*r[A][6][5,9]*r[J][24][0,0]*r[I][3][7,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[A,1],p[J,1])]*r[A][6][5,9]*r[J][54][0,0]*r[I][3][7,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,1],p[I,0],p[J,0],p[J,0])]*r[A][6][5,9]*r[I][3][7,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,1],p[I,0],p[J,1],p[J,1])]*r[A][6][5,9]*r[I][3][7,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[A,1],p[J,0],p[J,0],p[I,0])]*r[A][6][5,9]*r[I][3][7,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[A,1],p[J,1],p[J,1],p[I,0])]*r[A][6][5,9]*r[I][3][7,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,0],p[A,1],p[J,0])]*r[A][6][5,9]*r[I][3][7,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,0],p[A,1],p[J,1])]*r[A][6][5,9]*r[I][3][7,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[A,1],p[I,0])]*r[A][6][5,9]*r[I][3][7,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[A,1],p[I,0])]*r[A][6][5,9]*r[I][3][7,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[A,1],p[I,0])]*r[A][6][5,9]*r[I][3][7,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[A,1],p[I,0])]*r[A][6][5,9]*r[I][3][7,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[I,0])]*r[A][6][5,9]*r[B][54][12,12]*r[I][3][7,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[B,1],p[B,1])]*r[A][6][5,9]*r[B][54][12,12]*r[I][3][7,0]
        hv += g[dei(p[B,0],p[B,0],p[A,1],p[I,0])]*r[A][6][5,9]*r[B][9][12,12]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[I,0])]*r[A][6][5,9]*r[B][54][12,12]*r[I][3][7,0]
        hv += g[dei(p[B,1],p[B,1],p[A,1],p[I,0])]*r[A][6][5,9]*r[B][39][12,12]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[I,0],p[A,1],p[B,1])]*r[A][6][5,9]*r[B][54][12,12]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B12I10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,2),(B,12),(I,10)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += h[p[A,1],p[I,1]]*r[A][4][2,9]*r[I][5][10,0]
        hv += g[dei(p[A,0],p[I,1],p[A,1],p[A,0])]*r[A][82][2,9]*r[I][5][10,0]
        hv += g[dei(p[A,1],p[I,1],p[A,0],p[A,0])]*r[A][130][2,9]*r[I][5][10,0]
        hv += g[dei(p[A,1],p[I,0],p[I,1],p[I,0])]*r[A][4][2,9]*r[I][161][10,0]
        hv += g[dei(p[A,1],p[I,1],p[I,1],p[I,1])]*r[A][4][2,9]*r[I][181][10,0]
        hv += sum(-1/4*g[dei(p[A,1],p[J,0],p[J,0],p[I,1])]*r[A][4][2,9]*r[J][9][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[A,1],p[J,1],p[J,1],p[I,1])]*r[A][4][2,9]*r[J][39][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,1],p[I,1],p[J,0],p[J,0])]*r[A][4][2,9]*r[J][9][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,1],p[I,1],p[J,0],p[J,0])]*r[A][4][2,9]*r[J][24][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,1],p[I,1],p[J,1],p[J,1])]*r[A][4][2,9]*r[J][39][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,1],p[I,1],p[J,1],p[J,1])]*r[A][4][2,9]*r[J][54][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[A,1],p[I,1])]*r[A][4][2,9]*r[J][9][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[A,1],p[I,1])]*r[A][4][2,9]*r[J][39][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[A,1],p[J,0])]*r[A][4][2,9]*r[J][9][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[A,1],p[J,1])]*r[A][4][2,9]*r[J][39][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,1],p[I,1],p[J,0],p[J,0])]*r[A][4][2,9]*r[I][5][10,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,1],p[I,1],p[J,0],p[J,0])]*r[A][4][2,9]*r[I][5][10,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,1],p[I,1],p[J,1],p[J,1])]*r[A][4][2,9]*r[I][5][10,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,1],p[I,1],p[J,1],p[J,1])]*r[A][4][2,9]*r[I][5][10,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[A,1],p[J,0],p[J,0],p[I,1])]*r[A][4][2,9]*r[I][5][10,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[A,1],p[J,1],p[J,1],p[I,1])]*r[A][4][2,9]*r[I][5][10,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[A,1],p[J,0])]*r[A][4][2,9]*r[I][5][10,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[A,1],p[J,1])]*r[A][4][2,9]*r[I][5][10,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[A,1],p[I,1])]*r[A][4][2,9]*r[I][5][10,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[A,1],p[I,1])]*r[A][4][2,9]*r[I][5][10,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[I,1])]*r[A][4][2,9]*r[B][9][12,12]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[I,1])]*r[A][4][2,9]*r[B][39][12,12]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[B,0],p[B,0])]*r[A][4][2,9]*r[B][9][12,12]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[B,1],p[B,1])]*r[A][4][2,9]*r[B][39][12,12]*r[I][5][10,0]
        hv += g[dei(p[A,1],p[I,1],p[B,1],p[B,1])]*r[A][4][2,9]*r[B][54][12,12]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[I,1])]*r[A][4][2,9]*r[B][9][12,12]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[I,1])]*r[A][4][2,9]*r[B][39][12,12]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][9][12,12]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,1],p[I,1],p[A,1],p[B,1])]*r[A][4][2,9]*r[B][39][12,12]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B12I10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,3),(B,12),(I,10)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += h[p[A,1],p[I,1]]*r[A][4][3,9]*r[I][5][10,0]
        hv += g[dei(p[A,0],p[I,1],p[A,1],p[A,0])]*r[A][82][3,9]*r[I][5][10,0]
        hv += g[dei(p[A,1],p[I,1],p[A,0],p[A,0])]*r[A][130][3,9]*r[I][5][10,0]
        hv += g[dei(p[A,1],p[I,0],p[I,1],p[I,0])]*r[A][4][3,9]*r[I][161][10,0]
        hv += g[dei(p[A,1],p[I,1],p[I,1],p[I,1])]*r[A][4][3,9]*r[I][181][10,0]
        hv += sum(-1/4*g[dei(p[A,1],p[J,0],p[J,0],p[I,1])]*r[A][4][3,9]*r[J][9][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[A,1],p[J,1],p[J,1],p[I,1])]*r[A][4][3,9]*r[J][39][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,1],p[I,1],p[J,0],p[J,0])]*r[A][4][3,9]*r[J][9][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,1],p[I,1],p[J,0],p[J,0])]*r[A][4][3,9]*r[J][24][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,1],p[I,1],p[J,1],p[J,1])]*r[A][4][3,9]*r[J][39][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,1],p[I,1],p[J,1],p[J,1])]*r[A][4][3,9]*r[J][54][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[A,1],p[I,1])]*r[A][4][3,9]*r[J][9][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[A,1],p[I,1])]*r[A][4][3,9]*r[J][39][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[A,1],p[J,0])]*r[A][4][3,9]*r[J][9][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[A,1],p[J,1])]*r[A][4][3,9]*r[J][39][0,0]*r[I][5][10,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,1],p[I,1],p[J,0],p[J,0])]*r[A][4][3,9]*r[I][5][10,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,1],p[I,1],p[J,0],p[J,0])]*r[A][4][3,9]*r[I][5][10,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,1],p[I,1],p[J,1],p[J,1])]*r[A][4][3,9]*r[I][5][10,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[A,1],p[I,1],p[J,1],p[J,1])]*r[A][4][3,9]*r[I][5][10,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[A,1],p[J,0],p[J,0],p[I,1])]*r[A][4][3,9]*r[I][5][10,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[A,1],p[J,1],p[J,1],p[I,1])]*r[A][4][3,9]*r[I][5][10,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[A,1],p[J,0])]*r[A][4][3,9]*r[I][5][10,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[A,1],p[J,1])]*r[A][4][3,9]*r[I][5][10,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[A,1],p[I,1])]*r[A][4][3,9]*r[I][5][10,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[A,1],p[I,1])]*r[A][4][3,9]*r[I][5][10,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[I,1])]*r[A][4][3,9]*r[B][9][12,12]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[I,1])]*r[A][4][3,9]*r[B][39][12,12]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[B,0],p[B,0])]*r[A][4][3,9]*r[B][9][12,12]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[B,1],p[B,1])]*r[A][4][3,9]*r[B][39][12,12]*r[I][5][10,0]
        hv += g[dei(p[A,1],p[I,1],p[B,1],p[B,1])]*r[A][4][3,9]*r[B][54][12,12]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[I,1])]*r[A][4][3,9]*r[B][9][12,12]*r[I][5][10,0]
        hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[I,1])]*r[A][4][3,9]*r[B][39][12,12]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][9][12,12]*r[I][5][10,0]
        hv += -1/2*g[dei(p[B,1],p[I,1],p[A,1],p[B,1])]*r[A][4][3,9]*r[B][39][12,12]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5B12I8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,5),(B,12),(I,8)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += h[p[A,1],p[I,1]]*r[A][6][5,9]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,0],p[A,0],p[A,1],p[I,1])]*r[A][114][5,9]*r[I][7][8,0]
        hv += -1/2*g[dei(p[A,1],p[A,0],p[A,0],p[I,1])]*r[A][162][5,9]*r[I][7][8,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[A,1],p[A,0])]*r[A][114][5,9]*r[I][7][8,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[A,0],p[A,0])]*r[A][162][5,9]*r[I][7][8,0]
        hv += -1*g[dei(p[I,1],p[I,0],p[A,1],p[I,0])]*r[A][6][5,9]*r[I][129][8,0]
        hv += -1*g[dei(p[I,1],p[I,1],p[A,1],p[I,1])]*r[A][6][5,9]*r[I][149][8,0]
        hv += sum(-1/4*g[dei(p[A,1],p[J,0],p[J,0],p[I,1])]*r[A][6][5,9]*r[J][24][0,0]*r[I][7][8,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[A,1],p[J,1],p[J,1],p[I,1])]*r[A][6][5,9]*r[J][54][0,0]*r[I][7][8,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,1],p[I,1],p[J,0],p[J,0])]*r[A][6][5,9]*r[J][24][0,0]*r[I][7][8,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,1],p[I,1],p[J,1],p[J,1])]*r[A][6][5,9]*r[J][54][0,0]*r[I][7][8,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[A,1],p[I,1])]*r[A][6][5,9]*r[J][24][0,0]*r[I][7][8,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[A,1],p[I,1])]*r[A][6][5,9]*r[J][9][0,0]*r[I][7][8,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[A,1],p[I,1])]*r[A][6][5,9]*r[J][54][0,0]*r[I][7][8,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[A,1],p[I,1])]*r[A][6][5,9]*r[J][39][0,0]*r[I][7][8,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[A,1],p[J,0])]*r[A][6][5,9]*r[J][24][0,0]*r[I][7][8,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[A,1],p[J,1])]*r[A][6][5,9]*r[J][54][0,0]*r[I][7][8,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,1],p[I,1],p[J,0],p[J,0])]*r[A][6][5,9]*r[I][7][8,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[A,1],p[I,1],p[J,1],p[J,1])]*r[A][6][5,9]*r[I][7][8,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[A,1],p[J,0],p[J,0],p[I,1])]*r[A][6][5,9]*r[I][7][8,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[A,1],p[J,1],p[J,1],p[I,1])]*r[A][6][5,9]*r[I][7][8,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[I,1],p[A,1],p[J,0])]*r[A][6][5,9]*r[I][7][8,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[I,1],p[A,1],p[J,1])]*r[A][6][5,9]*r[I][7][8,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[A,1],p[I,1])]*r[A][6][5,9]*r[I][7][8,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[A,1],p[I,1])]*r[A][6][5,9]*r[I][7][8,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[A,1],p[I,1])]*r[A][6][5,9]*r[I][7][8,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[A,1],p[I,1])]*r[A][6][5,9]*r[I][7][8,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[I,1])]*r[A][6][5,9]*r[B][54][12,12]*r[I][7][8,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[B,1],p[B,1])]*r[A][6][5,9]*r[B][54][12,12]*r[I][7][8,0]
        hv += g[dei(p[B,0],p[B,0],p[A,1],p[I,1])]*r[A][6][5,9]*r[B][9][12,12]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[I,1])]*r[A][6][5,9]*r[B][54][12,12]*r[I][7][8,0]
        hv += g[dei(p[B,1],p[B,1],p[A,1],p[I,1])]*r[A][6][5,9]*r[B][39][12,12]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[I,1],p[A,1],p[B,1])]*r[A][6][5,9]*r[B][54][12,12]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6B12I14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,6),(B,12),(I,14)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*h[p[I,0],p[A,0]]*r[A][3][6,9]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[I,1],p[I,1])]*r[A][3][6,9]*r[I][118][14,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[I,0],p[I,1])]*r[A][3][6,9]*r[I][166][14,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[I,1],p[A,0])]*r[A][3][6,9]*r[I][118][14,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[I,0],p[A,0])]*r[A][3][6,9]*r[I][166][14,0]
        hv += g[dei(p[I,1],p[I,1],p[I,0],p[A,0])]*r[A][3][6,9]*r[I][132][14,0]
        hv += g[dei(p[I,1],p[I,0],p[I,1],p[A,0])]*r[A][3][6,9]*r[I][144][14,0]
        hv += sum(1/4*g[dei(p[J,0],p[A,0],p[I,0],p[J,0])]*r[A][3][6,9]*r[J][24][0,0]*r[I][2][14,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[A,0],p[I,0],p[J,1])]*r[A][3][6,9]*r[J][54][0,0]*r[I][2][14,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[J,0],p[I,0],p[A,0])]*r[A][3][6,9]*r[J][24][0,0]*r[I][2][14,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/2*g[dei(p[J,0],p[J,0],p[I,0],p[A,0])]*r[A][3][6,9]*r[J][9][0,0]*r[I][2][14,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[J,1],p[I,0],p[A,0])]*r[A][3][6,9]*r[J][54][0,0]*r[I][2][14,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/2*g[dei(p[J,1],p[J,1],p[I,0],p[A,0])]*r[A][3][6,9]*r[J][39][0,0]*r[I][2][14,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[A,0],p[J,0],p[J,0])]*r[A][3][6,9]*r[J][24][0,0]*r[I][2][14,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[A,0],p[J,1],p[J,1])]*r[A][3][6,9]*r[J][54][0,0]*r[I][2][14,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[J,0],p[J,0],p[A,0])]*r[A][3][6,9]*r[J][24][0,0]*r[I][2][14,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[J,1],p[J,1],p[A,0])]*r[A][3][6,9]*r[J][54][0,0]*r[I][2][14,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[A,0],p[J,0],p[J,0])]*r[A][3][6,9]*r[I][2][14,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[A,0],p[J,1],p[J,1])]*r[A][3][6,9]*r[I][2][14,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[J,0],p[J,0],p[A,0])]*r[A][3][6,9]*r[I][2][14,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[J,1],p[J,1],p[A,0])]*r[A][3][6,9]*r[I][2][14,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[A,0],p[I,0],p[J,0])]*r[A][3][6,9]*r[I][2][14,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[A,0],p[I,0],p[J,1])]*r[A][3][6,9]*r[I][2][14,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[J,0],p[I,0],p[A,0])]*r[A][3][6,9]*r[I][2][14,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/2*g[dei(p[J,0],p[J,0],p[I,0],p[A,0])]*r[A][3][6,9]*r[I][2][14,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[J,1],p[I,0],p[A,0])]*r[A][3][6,9]*r[I][2][14,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/2*g[dei(p[J,1],p[J,1],p[I,0],p[A,0])]*r[A][3][6,9]*r[I][2][14,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += 1/2*g[dei(p[B,1],p[A,0],p[I,0],p[B,1])]*r[A][3][6,9]*r[B][54][12,12]*r[I][2][14,0]
        hv += -1*g[dei(p[B,0],p[B,0],p[I,0],p[A,0])]*r[A][3][6,9]*r[B][9][12,12]*r[I][2][14,0]
        hv += -1/2*g[dei(p[B,1],p[B,1],p[I,0],p[A,0])]*r[A][3][6,9]*r[B][54][12,12]*r[I][2][14,0]
        hv += -1*g[dei(p[B,1],p[B,1],p[I,0],p[A,0])]*r[A][3][6,9]*r[B][39][12,12]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[B,1],p[B,1])]*r[A][3][6,9]*r[B][54][12,12]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[B,1],p[A,0])]*r[A][3][6,9]*r[B][54][12,12]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6B12I13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,6),(B,12),(I,13)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*h[p[I,1],p[A,0]]*r[A][3][6,9]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[I,1],p[I,0])]*r[A][3][6,9]*r[I][114][13,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[I,0],p[I,0])]*r[A][3][6,9]*r[I][162][13,0]
        hv += g[dei(p[I,0],p[I,1],p[I,0],p[A,0])]*r[A][3][6,9]*r[I][68][13,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[I,1],p[A,0])]*r[A][3][6,9]*r[I][114][13,0]
        hv += g[dei(p[I,0],p[I,0],p[I,1],p[A,0])]*r[A][3][6,9]*r[I][80][13,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[I,0],p[A,0])]*r[A][3][6,9]*r[I][162][13,0]
        hv += sum(1/4*g[dei(p[J,0],p[A,0],p[I,1],p[J,0])]*r[A][3][6,9]*r[J][24][0,0]*r[I][6][13,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[A,0],p[I,1],p[J,1])]*r[A][3][6,9]*r[J][54][0,0]*r[I][6][13,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[J,0],p[I,1],p[A,0])]*r[A][3][6,9]*r[J][24][0,0]*r[I][6][13,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/2*g[dei(p[J,0],p[J,0],p[I,1],p[A,0])]*r[A][3][6,9]*r[J][9][0,0]*r[I][6][13,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[J,1],p[I,1],p[A,0])]*r[A][3][6,9]*r[J][54][0,0]*r[I][6][13,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/2*g[dei(p[J,1],p[J,1],p[I,1],p[A,0])]*r[A][3][6,9]*r[J][39][0,0]*r[I][6][13,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[A,0],p[J,0],p[J,0])]*r[A][3][6,9]*r[J][24][0,0]*r[I][6][13,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[A,0],p[J,1],p[J,1])]*r[A][3][6,9]*r[J][54][0,0]*r[I][6][13,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[J,0],p[J,0],p[A,0])]*r[A][3][6,9]*r[J][24][0,0]*r[I][6][13,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[J,1],p[J,1],p[A,0])]*r[A][3][6,9]*r[J][54][0,0]*r[I][6][13,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[A,0],p[J,0],p[J,0])]*r[A][3][6,9]*r[I][6][13,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[A,0],p[J,1],p[J,1])]*r[A][3][6,9]*r[I][6][13,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[J,0],p[J,0],p[A,0])]*r[A][3][6,9]*r[I][6][13,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[J,1],p[J,1],p[A,0])]*r[A][3][6,9]*r[I][6][13,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[A,0],p[I,1],p[J,0])]*r[A][3][6,9]*r[I][6][13,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[A,0],p[I,1],p[J,1])]*r[A][3][6,9]*r[I][6][13,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[J,0],p[I,1],p[A,0])]*r[A][3][6,9]*r[I][6][13,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/2*g[dei(p[J,0],p[J,0],p[I,1],p[A,0])]*r[A][3][6,9]*r[I][6][13,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[J,1],p[I,1],p[A,0])]*r[A][3][6,9]*r[I][6][13,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/2*g[dei(p[J,1],p[J,1],p[I,1],p[A,0])]*r[A][3][6,9]*r[I][6][13,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += 1/2*g[dei(p[B,1],p[A,0],p[I,1],p[B,1])]*r[A][3][6,9]*r[B][54][12,12]*r[I][6][13,0]
        hv += -1*g[dei(p[B,0],p[B,0],p[I,1],p[A,0])]*r[A][3][6,9]*r[B][9][12,12]*r[I][6][13,0]
        hv += -1/2*g[dei(p[B,1],p[B,1],p[I,1],p[A,0])]*r[A][3][6,9]*r[B][54][12,12]*r[I][6][13,0]
        hv += -1*g[dei(p[B,1],p[B,1],p[I,1],p[A,0])]*r[A][3][6,9]*r[B][39][12,12]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[B,1],p[B,1])]*r[A][3][6,9]*r[B][54][12,12]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[B,1],p[A,0])]*r[A][3][6,9]*r[B][54][12,12]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B12I6(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,13),(B,12),(I,6)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += g[dei(p[A,0],p[I,0],p[A,1],p[I,0])]*r[A][17][13,9]*r[I][22][6,0]
        hv += g[dei(p[A,0],p[I,1],p[A,1],p[I,1])]*r[A][17][13,9]*r[I][52][6,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B12I6(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,14),(B,12),(I,6)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += g[dei(p[A,1],p[I,0],p[A,1],p[I,0])]*r[A][41][14,9]*r[I][22][6,0]
        hv += g[dei(p[A,1],p[I,1],p[A,1],p[I,1])]*r[A][41][14,9]*r[I][52][6,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B12I1(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,10),(B,12),(I,1)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,0])]*r[A][48][10,9]*r[I][24][1,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,1])]*r[A][48][10,9]*r[I][54][1,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[I,0],p[A,0])]*r[A][48][10,9]*r[I][24][1,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[I,1],p[A,0])]*r[A][48][10,9]*r[I][54][1,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,0])]*r[A][48][10,9]*r[I][24][1,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,1])]*r[A][48][10,9]*r[I][54][1,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][48][10,9]*r[I][24][1,0]
        hv += g[dei(p[I,0],p[I,0],p[A,1],p[A,0])]*r[A][48][10,9]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][48][10,9]*r[I][54][1,0]
        hv += g[dei(p[I,1],p[I,1],p[A,1],p[A,0])]*r[A][48][10,9]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B12I2(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,10),(B,12),(I,2)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,1])]*r[A][48][10,9]*r[I][30][2,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,0])]*r[A][48][10,9]*r[I][48][2,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[I,0],p[A,0])]*r[A][48][10,9]*r[I][30][2,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[I,1],p[A,0])]*r[A][48][10,9]*r[I][48][2,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,1])]*r[A][48][10,9]*r[I][30][2,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,0])]*r[A][48][10,9]*r[I][48][2,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,1],p[A,0])]*r[A][48][10,9]*r[I][30][2,0]
        hv += g[dei(p[I,0],p[I,1],p[A,1],p[A,0])]*r[A][48][10,9]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,1],p[A,0])]*r[A][48][10,9]*r[I][48][2,0]
        hv += g[dei(p[I,1],p[I,0],p[A,1],p[A,0])]*r[A][48][10,9]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B12I3(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,10),(B,12),(I,3)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,0],p[I,1])]*r[A][48][10,9]*r[I][30][3,0]
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,1],p[I,0])]*r[A][48][10,9]*r[I][48][3,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[I,0],p[A,0])]*r[A][48][10,9]*r[I][30][3,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[I,1],p[A,0])]*r[A][48][10,9]*r[I][48][3,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,1],p[I,1])]*r[A][48][10,9]*r[I][30][3,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,1],p[I,0])]*r[A][48][10,9]*r[I][48][3,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[A,1],p[A,0])]*r[A][48][10,9]*r[I][30][3,0]
        hv += g[dei(p[I,0],p[I,1],p[A,1],p[A,0])]*r[A][48][10,9]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[A,1],p[A,0])]*r[A][48][10,9]*r[I][48][3,0]
        hv += g[dei(p[I,1],p[I,0],p[A,1],p[A,0])]*r[A][48][10,9]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B12I5(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,7),(B,12),(I,5)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += -1*g[dei(p[A,0],p[I,1],p[I,0],p[A,0])]*r[A][12][7,9]*r[I][27][5,0]
        hv += -1*g[dei(p[A,0],p[I,0],p[I,1],p[A,0])]*r[A][12][7,9]*r[I][45][5,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B12I5(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,8),(B,12),(I,5)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += -1*g[dei(p[A,1],p[I,1],p[I,0],p[A,0])]*r[A][36][8,9]*r[I][27][5,0]
        hv += -1*g[dei(p[A,1],p[I,0],p[I,1],p[A,0])]*r[A][36][8,9]*r[I][45][5,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B15I7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,9),(B,15),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*h[p[B,0],p[I,0]]*r[B][2][15,12]*r[I][3][7,0]
        hv += g[dei(p[B,0],p[B,0],p[B,0],p[I,0])]*r[B][64][15,12]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,0],p[B,1],p[B,1],p[I,0])]*r[B][118][15,12]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,1],p[B,1],p[B,0],p[I,0])]*r[B][166][15,12]*r[I][3][7,0]
        hv += g[dei(p[B,1],p[B,1],p[B,0],p[I,0])]*r[B][132][15,12]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[B,1],p[B,1])]*r[B][118][15,12]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,1],p[I,0],p[B,0],p[B,1])]*r[B][166][15,12]*r[I][3][7,0]
        hv += g[dei(p[I,0],p[I,0],p[B,0],p[I,0])]*r[B][2][15,12]*r[I][65][7,0]
        hv += g[dei(p[I,0],p[I,1],p[B,0],p[I,1])]*r[B][2][15,12]*r[I][85][7,0]
        hv += sum(1/4*g[dei(p[B,0],p[J,0],p[J,0],p[I,0])]*r[B][2][15,12]*r[J][24][0,0]*r[I][3][7,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[B,0],p[J,1],p[J,1],p[I,0])]*r[B][2][15,12]*r[J][54][0,0]*r[I][3][7,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[B,0],p[I,0],p[J,0],p[J,0])]*r[B][2][15,12]*r[J][24][0,0]*r[I][3][7,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[B,0],p[I,0],p[J,1],p[J,1])]*r[B][2][15,12]*r[J][54][0,0]*r[I][3][7,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[J,0],p[B,0],p[I,0])]*r[B][2][15,12]*r[J][24][0,0]*r[I][3][7,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/2*g[dei(p[J,0],p[J,0],p[B,0],p[I,0])]*r[B][2][15,12]*r[J][9][0,0]*r[I][3][7,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[J,1],p[B,0],p[I,0])]*r[B][2][15,12]*r[J][54][0,0]*r[I][3][7,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/2*g[dei(p[J,1],p[J,1],p[B,0],p[I,0])]*r[B][2][15,12]*r[J][39][0,0]*r[I][3][7,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[I,0],p[B,0],p[J,0])]*r[B][2][15,12]*r[J][24][0,0]*r[I][3][7,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[I,0],p[B,0],p[J,1])]*r[B][2][15,12]*r[J][54][0,0]*r[I][3][7,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[B,0],p[I,0],p[J,0],p[J,0])]*r[B][2][15,12]*r[I][3][7,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[B,0],p[I,0],p[J,1],p[J,1])]*r[B][2][15,12]*r[I][3][7,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[B,0],p[J,0],p[J,0],p[I,0])]*r[B][2][15,12]*r[I][3][7,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[B,0],p[J,1],p[J,1],p[I,0])]*r[B][2][15,12]*r[I][3][7,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[I,0],p[B,0],p[J,0])]*r[B][2][15,12]*r[I][3][7,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[I,0],p[B,0],p[J,1])]*r[B][2][15,12]*r[I][3][7,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[J,0],p[B,0],p[I,0])]*r[B][2][15,12]*r[I][3][7,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/2*g[dei(p[J,0],p[J,0],p[B,0],p[I,0])]*r[B][2][15,12]*r[I][3][7,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[J,1],p[B,0],p[I,0])]*r[B][2][15,12]*r[I][3][7,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/2*g[dei(p[J,1],p[J,1],p[B,0],p[I,0])]*r[B][2][15,12]*r[I][3][7,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[I,0])]*r[A][24][9,9]*r[B][2][15,12]*r[I][3][7,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[B,0],p[A,0])]*r[A][24][9,9]*r[B][2][15,12]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[I,0])]*r[A][24][9,9]*r[B][2][15,12]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[A,0],p[A,0])]*r[A][24][9,9]*r[B][2][15,12]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B15I8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,9),(B,15),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*h[p[B,0],p[I,1]]*r[B][2][15,12]*r[I][7][8,0]
        hv += g[dei(p[B,0],p[B,0],p[B,0],p[I,1])]*r[B][64][15,12]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,0],p[B,1],p[B,1],p[I,1])]*r[B][118][15,12]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,1],p[B,1],p[B,0],p[I,1])]*r[B][166][15,12]*r[I][7][8,0]
        hv += g[dei(p[B,1],p[B,1],p[B,0],p[I,1])]*r[B][132][15,12]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[B,1],p[B,1])]*r[B][118][15,12]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,1],p[I,1],p[B,0],p[B,1])]*r[B][166][15,12]*r[I][7][8,0]
        hv += g[dei(p[I,1],p[I,0],p[B,0],p[I,0])]*r[B][2][15,12]*r[I][129][8,0]
        hv += g[dei(p[I,1],p[I,1],p[B,0],p[I,1])]*r[B][2][15,12]*r[I][149][8,0]
        hv += sum(1/4*g[dei(p[B,0],p[J,0],p[J,0],p[I,1])]*r[B][2][15,12]*r[J][24][0,0]*r[I][7][8,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[B,0],p[J,1],p[J,1],p[I,1])]*r[B][2][15,12]*r[J][54][0,0]*r[I][7][8,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[B,0],p[I,1],p[J,0],p[J,0])]*r[B][2][15,12]*r[J][24][0,0]*r[I][7][8,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[B,0],p[I,1],p[J,1],p[J,1])]*r[B][2][15,12]*r[J][54][0,0]*r[I][7][8,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[J,0],p[B,0],p[I,1])]*r[B][2][15,12]*r[J][24][0,0]*r[I][7][8,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/2*g[dei(p[J,0],p[J,0],p[B,0],p[I,1])]*r[B][2][15,12]*r[J][9][0,0]*r[I][7][8,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[J,1],p[B,0],p[I,1])]*r[B][2][15,12]*r[J][54][0,0]*r[I][7][8,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/2*g[dei(p[J,1],p[J,1],p[B,0],p[I,1])]*r[B][2][15,12]*r[J][39][0,0]*r[I][7][8,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[I,1],p[B,0],p[J,0])]*r[B][2][15,12]*r[J][24][0,0]*r[I][7][8,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[I,1],p[B,0],p[J,1])]*r[B][2][15,12]*r[J][54][0,0]*r[I][7][8,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[B,0],p[I,1],p[J,0],p[J,0])]*r[B][2][15,12]*r[I][7][8,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[B,0],p[I,1],p[J,1],p[J,1])]*r[B][2][15,12]*r[I][7][8,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[B,0],p[J,0],p[J,0],p[I,1])]*r[B][2][15,12]*r[I][7][8,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[B,0],p[J,1],p[J,1],p[I,1])]*r[B][2][15,12]*r[I][7][8,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[I,1],p[B,0],p[J,0])]*r[B][2][15,12]*r[I][7][8,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[I,1],p[B,0],p[J,1])]*r[B][2][15,12]*r[I][7][8,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[J,0],p[B,0],p[I,1])]*r[B][2][15,12]*r[I][7][8,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/2*g[dei(p[J,0],p[J,0],p[B,0],p[I,1])]*r[B][2][15,12]*r[I][7][8,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[J,1],p[B,0],p[I,1])]*r[B][2][15,12]*r[I][7][8,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/2*g[dei(p[J,1],p[J,1],p[B,0],p[I,1])]*r[B][2][15,12]*r[I][7][8,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += -1/2*g[dei(p[A,0],p[A,0],p[B,0],p[I,1])]*r[A][24][9,9]*r[B][2][15,12]*r[I][7][8,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[B,0],p[A,0])]*r[A][24][9,9]*r[B][2][15,12]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,0],p[A,0],p[A,0],p[I,1])]*r[A][24][9,9]*r[B][2][15,12]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[A,0],p[A,0])]*r[A][24][9,9]*r[B][2][15,12]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9I12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,9),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += h[p[I,0],p[B,0]]*r[B][1][0,12]*r[I][0][12,0]
        hv += -1/2*g[dei(p[B,1],p[B,0],p[I,0],p[B,1])]*r[B][137][0,12]*r[I][0][12,0]
        hv += -1/2*g[dei(p[B,1],p[B,1],p[I,0],p[B,0])]*r[B][125][0,12]*r[I][0][12,0]
        hv += g[dei(p[I,0],p[B,1],p[B,0],p[B,1])]*r[B][117][0,12]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[B,1],p[B,1])]*r[B][137][0,12]*r[I][0][12,0]
        hv += g[dei(p[I,0],p[B,0],p[B,1],p[B,1])]*r[B][177][0,12]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[B,1],p[B,0])]*r[B][125][0,12]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[I,1],p[I,1])]*r[B][1][0,12]*r[I][76][12,0]
        hv += g[dei(p[I,0],p[B,0],p[I,1],p[I,1])]*r[B][1][0,12]*r[I][86][12,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[I,0],p[I,1])]*r[B][1][0,12]*r[I][124][12,0]
        hv += g[dei(p[I,1],p[B,0],p[I,1],p[I,0])]*r[B][1][0,12]*r[I][146][12,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[I,1],p[B,0])]*r[B][1][0,12]*r[I][76][12,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[I,0],p[B,0])]*r[B][1][0,12]*r[I][124][12,0]
        hv += sum(-1/4*g[dei(p[J,0],p[B,0],p[I,0],p[J,0])]*r[B][1][0,12]*r[J][9][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[B,0],p[I,0],p[J,1])]*r[B][1][0,12]*r[J][39][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[B,0])]*r[B][1][0,12]*r[J][9][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[B,0])]*r[B][1][0,12]*r[J][39][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[B,0],p[J,0],p[J,0])]*r[B][1][0,12]*r[J][9][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,0],p[B,0],p[J,0],p[J,0])]*r[B][1][0,12]*r[J][24][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[B,0],p[J,1],p[J,1])]*r[B][1][0,12]*r[J][39][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,0],p[B,0],p[J,1],p[J,1])]*r[B][1][0,12]*r[J][54][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[B,0])]*r[B][1][0,12]*r[J][9][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[B,0])]*r[B][1][0,12]*r[J][39][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[B,0],p[J,0],p[J,0])]*r[B][1][0,12]*r[I][0][12,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,0],p[B,0],p[J,0],p[J,0])]*r[B][1][0,12]*r[I][0][12,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[B,0],p[J,1],p[J,1])]*r[B][1][0,12]*r[I][0][12,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,0],p[B,0],p[J,1],p[J,1])]*r[B][1][0,12]*r[I][0][12,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[B,0])]*r[B][1][0,12]*r[I][0][12,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[B,0])]*r[B][1][0,12]*r[I][0][12,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[B,0],p[I,0],p[J,0])]*r[B][1][0,12]*r[I][0][12,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[B,0],p[I,0],p[J,1])]*r[B][1][0,12]*r[I][0][12,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[B,0])]*r[B][1][0,12]*r[I][0][12,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[B,0])]*r[B][1][0,12]*r[I][0][12,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += g[dei(p[I,0],p[B,0],p[A,0],p[A,0])]*r[A][24][9,9]*r[B][1][0,12]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B1I12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,9),(B,1),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += h[p[I,0],p[B,0]]*r[B][1][1,12]*r[I][0][12,0]
        hv += -1/2*g[dei(p[B,1],p[B,0],p[I,0],p[B,1])]*r[B][137][1,12]*r[I][0][12,0]
        hv += -1/2*g[dei(p[B,1],p[B,1],p[I,0],p[B,0])]*r[B][125][1,12]*r[I][0][12,0]
        hv += g[dei(p[I,0],p[B,1],p[B,0],p[B,1])]*r[B][117][1,12]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[B,1],p[B,1])]*r[B][137][1,12]*r[I][0][12,0]
        hv += g[dei(p[I,0],p[B,0],p[B,1],p[B,1])]*r[B][177][1,12]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[B,1],p[B,0])]*r[B][125][1,12]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[I,1],p[I,1])]*r[B][1][1,12]*r[I][76][12,0]
        hv += g[dei(p[I,0],p[B,0],p[I,1],p[I,1])]*r[B][1][1,12]*r[I][86][12,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[I,0],p[I,1])]*r[B][1][1,12]*r[I][124][12,0]
        hv += g[dei(p[I,1],p[B,0],p[I,1],p[I,0])]*r[B][1][1,12]*r[I][146][12,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[I,1],p[B,0])]*r[B][1][1,12]*r[I][76][12,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[I,0],p[B,0])]*r[B][1][1,12]*r[I][124][12,0]
        hv += sum(-1/4*g[dei(p[J,0],p[B,0],p[I,0],p[J,0])]*r[B][1][1,12]*r[J][9][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[B,0],p[I,0],p[J,1])]*r[B][1][1,12]*r[J][39][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[B,0])]*r[B][1][1,12]*r[J][9][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[B,0])]*r[B][1][1,12]*r[J][39][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[B,0],p[J,0],p[J,0])]*r[B][1][1,12]*r[J][9][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,0],p[B,0],p[J,0],p[J,0])]*r[B][1][1,12]*r[J][24][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[B,0],p[J,1],p[J,1])]*r[B][1][1,12]*r[J][39][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,0],p[B,0],p[J,1],p[J,1])]*r[B][1][1,12]*r[J][54][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[B,0])]*r[B][1][1,12]*r[J][9][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[B,0])]*r[B][1][1,12]*r[J][39][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[B,0],p[J,0],p[J,0])]*r[B][1][1,12]*r[I][0][12,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,0],p[B,0],p[J,0],p[J,0])]*r[B][1][1,12]*r[I][0][12,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[B,0],p[J,1],p[J,1])]*r[B][1][1,12]*r[I][0][12,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,0],p[B,0],p[J,1],p[J,1])]*r[B][1][1,12]*r[I][0][12,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[B,0])]*r[B][1][1,12]*r[I][0][12,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[B,0])]*r[B][1][1,12]*r[I][0][12,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[B,0],p[I,0],p[J,0])]*r[B][1][1,12]*r[I][0][12,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[B,0],p[I,0],p[J,1])]*r[B][1][1,12]*r[I][0][12,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[B,0])]*r[B][1][1,12]*r[I][0][12,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[B,0])]*r[B][1][1,12]*r[I][0][12,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += g[dei(p[I,0],p[B,0],p[A,0],p[A,0])]*r[A][24][9,9]*r[B][1][1,12]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B2I12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,9),(B,2),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += h[p[I,0],p[B,1]]*r[B][5][2,12]*r[I][0][12,0]
        hv += -1/2*g[dei(p[B,0],p[B,0],p[I,0],p[B,1])]*r[B][73][2,12]*r[I][0][12,0]
        hv += -1/2*g[dei(p[B,0],p[B,1],p[I,0],p[B,0])]*r[B][61][2,12]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[B,0],p[B,1])]*r[B][73][2,12]*r[I][0][12,0]
        hv += g[dei(p[I,0],p[B,0],p[B,0],p[B,1])]*r[B][113][2,12]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[B,0],p[B,0])]*r[B][61][2,12]*r[I][0][12,0]
        hv += g[dei(p[I,0],p[B,1],p[B,1],p[B,1])]*r[B][181][2,12]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[I,1],p[I,1])]*r[B][5][2,12]*r[I][76][12,0]
        hv += g[dei(p[I,0],p[B,1],p[I,1],p[I,1])]*r[B][5][2,12]*r[I][86][12,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[I,0],p[I,1])]*r[B][5][2,12]*r[I][124][12,0]
        hv += g[dei(p[I,1],p[B,1],p[I,1],p[I,0])]*r[B][5][2,12]*r[I][146][12,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[I,1],p[B,1])]*r[B][5][2,12]*r[I][76][12,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[I,0],p[B,1])]*r[B][5][2,12]*r[I][124][12,0]
        hv += sum(-1/4*g[dei(p[J,0],p[B,1],p[I,0],p[J,0])]*r[B][5][2,12]*r[J][9][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[B,1],p[I,0],p[J,1])]*r[B][5][2,12]*r[J][39][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[B,1])]*r[B][5][2,12]*r[J][9][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[B,1])]*r[B][5][2,12]*r[J][39][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[B,1],p[J,0],p[J,0])]*r[B][5][2,12]*r[J][9][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,0],p[B,1],p[J,0],p[J,0])]*r[B][5][2,12]*r[J][24][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[B,1],p[J,1],p[J,1])]*r[B][5][2,12]*r[J][39][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,0],p[B,1],p[J,1],p[J,1])]*r[B][5][2,12]*r[J][54][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[B,1])]*r[B][5][2,12]*r[J][9][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[B,1])]*r[B][5][2,12]*r[J][39][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[B,1],p[J,0],p[J,0])]*r[B][5][2,12]*r[I][0][12,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,0],p[B,1],p[J,0],p[J,0])]*r[B][5][2,12]*r[I][0][12,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[B,1],p[J,1],p[J,1])]*r[B][5][2,12]*r[I][0][12,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,0],p[B,1],p[J,1],p[J,1])]*r[B][5][2,12]*r[I][0][12,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[B,1])]*r[B][5][2,12]*r[I][0][12,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[B,1])]*r[B][5][2,12]*r[I][0][12,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[B,1],p[I,0],p[J,0])]*r[B][5][2,12]*r[I][0][12,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[B,1],p[I,0],p[J,1])]*r[B][5][2,12]*r[I][0][12,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[B,1])]*r[B][5][2,12]*r[I][0][12,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[B,1])]*r[B][5][2,12]*r[I][0][12,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += g[dei(p[I,0],p[B,1],p[A,0],p[A,0])]*r[A][24][9,9]*r[B][5][2,12]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B3I12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,9),(B,3),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += h[p[I,0],p[B,1]]*r[B][5][3,12]*r[I][0][12,0]
        hv += -1/2*g[dei(p[B,0],p[B,0],p[I,0],p[B,1])]*r[B][73][3,12]*r[I][0][12,0]
        hv += -1/2*g[dei(p[B,0],p[B,1],p[I,0],p[B,0])]*r[B][61][3,12]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[B,0],p[B,1])]*r[B][73][3,12]*r[I][0][12,0]
        hv += g[dei(p[I,0],p[B,0],p[B,0],p[B,1])]*r[B][113][3,12]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[B,0],p[B,0])]*r[B][61][3,12]*r[I][0][12,0]
        hv += g[dei(p[I,0],p[B,1],p[B,1],p[B,1])]*r[B][181][3,12]*r[I][0][12,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[I,1],p[I,1])]*r[B][5][3,12]*r[I][76][12,0]
        hv += g[dei(p[I,0],p[B,1],p[I,1],p[I,1])]*r[B][5][3,12]*r[I][86][12,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[I,0],p[I,1])]*r[B][5][3,12]*r[I][124][12,0]
        hv += g[dei(p[I,1],p[B,1],p[I,1],p[I,0])]*r[B][5][3,12]*r[I][146][12,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[I,1],p[B,1])]*r[B][5][3,12]*r[I][76][12,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[I,0],p[B,1])]*r[B][5][3,12]*r[I][124][12,0]
        hv += sum(-1/4*g[dei(p[J,0],p[B,1],p[I,0],p[J,0])]*r[B][5][3,12]*r[J][9][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[B,1],p[I,0],p[J,1])]*r[B][5][3,12]*r[J][39][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[B,1])]*r[B][5][3,12]*r[J][9][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[B,1])]*r[B][5][3,12]*r[J][39][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[B,1],p[J,0],p[J,0])]*r[B][5][3,12]*r[J][9][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,0],p[B,1],p[J,0],p[J,0])]*r[B][5][3,12]*r[J][24][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[B,1],p[J,1],p[J,1])]*r[B][5][3,12]*r[J][39][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,0],p[B,1],p[J,1],p[J,1])]*r[B][5][3,12]*r[J][54][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[B,1])]*r[B][5][3,12]*r[J][9][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[B,1])]*r[B][5][3,12]*r[J][39][0,0]*r[I][0][12,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[B,1],p[J,0],p[J,0])]*r[B][5][3,12]*r[I][0][12,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,0],p[B,1],p[J,0],p[J,0])]*r[B][5][3,12]*r[I][0][12,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[B,1],p[J,1],p[J,1])]*r[B][5][3,12]*r[I][0][12,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,0],p[B,1],p[J,1],p[J,1])]*r[B][5][3,12]*r[I][0][12,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[B,1])]*r[B][5][3,12]*r[I][0][12,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[B,1])]*r[B][5][3,12]*r[I][0][12,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[B,1],p[I,0],p[J,0])]*r[B][5][3,12]*r[I][0][12,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[B,1],p[I,0],p[J,1])]*r[B][5][3,12]*r[I][0][12,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[B,1])]*r[B][5][3,12]*r[I][0][12,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[B,1])]*r[B][5][3,12]*r[I][0][12,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += g[dei(p[I,0],p[B,1],p[A,0],p[A,0])]*r[A][24][9,9]*r[B][5][3,12]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B4I14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,9),(B,4),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += h[p[I,0],p[B,1]]*r[B][7][4,12]*r[I][2][14,0]
        hv += -1*g[dei(p[B,0],p[B,0],p[I,0],p[B,1])]*r[B][81][4,12]*r[I][2][14,0]
        hv += -1*g[dei(p[B,1],p[B,1],p[I,0],p[B,1])]*r[B][149][4,12]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[I,1],p[I,1])]*r[B][7][4,12]*r[I][118][14,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[I,0],p[I,1])]*r[B][7][4,12]*r[I][166][14,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[I,1],p[B,1])]*r[B][7][4,12]*r[I][118][14,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[I,0],p[B,1])]*r[B][7][4,12]*r[I][166][14,0]
        hv += -1*g[dei(p[I,1],p[I,1],p[I,0],p[B,1])]*r[B][7][4,12]*r[I][132][14,0]
        hv += -1*g[dei(p[I,1],p[I,0],p[I,1],p[B,1])]*r[B][7][4,12]*r[I][144][14,0]
        hv += sum(-1/4*g[dei(p[J,0],p[B,1],p[I,0],p[J,0])]*r[B][7][4,12]*r[J][24][0,0]*r[I][2][14,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[B,1],p[I,0],p[J,1])]*r[B][7][4,12]*r[J][54][0,0]*r[I][2][14,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[B,1])]*r[B][7][4,12]*r[J][24][0,0]*r[I][2][14,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,0],p[B,1])]*r[B][7][4,12]*r[J][9][0,0]*r[I][2][14,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[B,1])]*r[B][7][4,12]*r[J][54][0,0]*r[I][2][14,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,0],p[B,1])]*r[B][7][4,12]*r[J][39][0,0]*r[I][2][14,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[B,1],p[J,0],p[J,0])]*r[B][7][4,12]*r[J][24][0,0]*r[I][2][14,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[B,1],p[J,1],p[J,1])]*r[B][7][4,12]*r[J][54][0,0]*r[I][2][14,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[B,1])]*r[B][7][4,12]*r[J][24][0,0]*r[I][2][14,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[B,1])]*r[B][7][4,12]*r[J][54][0,0]*r[I][2][14,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[B,1],p[J,0],p[J,0])]*r[B][7][4,12]*r[I][2][14,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,0],p[B,1],p[J,1],p[J,1])]*r[B][7][4,12]*r[I][2][14,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[B,1])]*r[B][7][4,12]*r[I][2][14,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[B,1])]*r[B][7][4,12]*r[I][2][14,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[B,1],p[I,0],p[J,0])]*r[B][7][4,12]*r[I][2][14,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[B,1],p[I,0],p[J,1])]*r[B][7][4,12]*r[I][2][14,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[B,1])]*r[B][7][4,12]*r[I][2][14,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,0],p[B,1])]*r[B][7][4,12]*r[I][2][14,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[B,1])]*r[B][7][4,12]*r[I][2][14,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,0],p[B,1])]*r[B][7][4,12]*r[I][2][14,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,0],p[B,1])]*r[A][24][9,9]*r[B][7][4,12]*r[I][2][14,0]
        hv += -1/2*g[dei(p[A,0],p[B,1],p[I,0],p[A,0])]*r[A][24][9,9]*r[B][7][4,12]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,0],p[B,1])]*r[A][24][9,9]*r[B][7][4,12]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[A,0],p[A,0])]*r[A][24][9,9]*r[B][7][4,12]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9I11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,9),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += h[p[I,1],p[B,0]]*r[B][1][0,12]*r[I][4][11,0]
        hv += -1/2*g[dei(p[B,1],p[B,0],p[I,1],p[B,1])]*r[B][137][0,12]*r[I][4][11,0]
        hv += -1/2*g[dei(p[B,1],p[B,1],p[I,1],p[B,0])]*r[B][125][0,12]*r[I][4][11,0]
        hv += g[dei(p[I,1],p[B,1],p[B,0],p[B,1])]*r[B][117][0,12]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[B,1],p[B,1])]*r[B][137][0,12]*r[I][4][11,0]
        hv += g[dei(p[I,1],p[B,0],p[B,1],p[B,1])]*r[B][177][0,12]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[B,1],p[B,0])]*r[B][125][0,12]*r[I][4][11,0]
        hv += g[dei(p[I,0],p[B,0],p[I,0],p[I,1])]*r[B][1][0,12]*r[I][70][11,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[I,1],p[I,0])]*r[B][1][0,12]*r[I][72][11,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[I,0],p[I,0])]*r[B][1][0,12]*r[I][120][11,0]
        hv += g[dei(p[I,1],p[B,0],p[I,0],p[I,0])]*r[B][1][0,12]*r[I][130][11,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[I,1],p[B,0])]*r[B][1][0,12]*r[I][72][11,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[I,0],p[B,0])]*r[B][1][0,12]*r[I][120][11,0]
        hv += sum(-1/4*g[dei(p[J,0],p[B,0],p[I,1],p[J,0])]*r[B][1][0,12]*r[J][9][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[B,0],p[I,1],p[J,1])]*r[B][1][0,12]*r[J][39][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[B,0])]*r[B][1][0,12]*r[J][9][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[B,0])]*r[B][1][0,12]*r[J][39][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[B,0],p[J,0],p[J,0])]*r[B][1][0,12]*r[J][9][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,1],p[B,0],p[J,0],p[J,0])]*r[B][1][0,12]*r[J][24][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[B,0],p[J,1],p[J,1])]*r[B][1][0,12]*r[J][39][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,1],p[B,0],p[J,1],p[J,1])]*r[B][1][0,12]*r[J][54][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[B,0])]*r[B][1][0,12]*r[J][9][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[B,0])]*r[B][1][0,12]*r[J][39][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[B,0],p[J,0],p[J,0])]*r[B][1][0,12]*r[I][4][11,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,1],p[B,0],p[J,0],p[J,0])]*r[B][1][0,12]*r[I][4][11,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[B,0],p[J,1],p[J,1])]*r[B][1][0,12]*r[I][4][11,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,1],p[B,0],p[J,1],p[J,1])]*r[B][1][0,12]*r[I][4][11,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[B,0])]*r[B][1][0,12]*r[I][4][11,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[B,0])]*r[B][1][0,12]*r[I][4][11,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[B,0],p[I,1],p[J,0])]*r[B][1][0,12]*r[I][4][11,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[B,0],p[I,1],p[J,1])]*r[B][1][0,12]*r[I][4][11,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[B,0])]*r[B][1][0,12]*r[I][4][11,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[B,0])]*r[B][1][0,12]*r[I][4][11,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += g[dei(p[I,1],p[B,0],p[A,0],p[A,0])]*r[A][24][9,9]*r[B][1][0,12]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B1I11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,9),(B,1),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += h[p[I,1],p[B,0]]*r[B][1][1,12]*r[I][4][11,0]
        hv += -1/2*g[dei(p[B,1],p[B,0],p[I,1],p[B,1])]*r[B][137][1,12]*r[I][4][11,0]
        hv += -1/2*g[dei(p[B,1],p[B,1],p[I,1],p[B,0])]*r[B][125][1,12]*r[I][4][11,0]
        hv += g[dei(p[I,1],p[B,1],p[B,0],p[B,1])]*r[B][117][1,12]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[B,1],p[B,1])]*r[B][137][1,12]*r[I][4][11,0]
        hv += g[dei(p[I,1],p[B,0],p[B,1],p[B,1])]*r[B][177][1,12]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[B,1],p[B,0])]*r[B][125][1,12]*r[I][4][11,0]
        hv += g[dei(p[I,0],p[B,0],p[I,0],p[I,1])]*r[B][1][1,12]*r[I][70][11,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[I,1],p[I,0])]*r[B][1][1,12]*r[I][72][11,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[I,0],p[I,0])]*r[B][1][1,12]*r[I][120][11,0]
        hv += g[dei(p[I,1],p[B,0],p[I,0],p[I,0])]*r[B][1][1,12]*r[I][130][11,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[I,1],p[B,0])]*r[B][1][1,12]*r[I][72][11,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[I,0],p[B,0])]*r[B][1][1,12]*r[I][120][11,0]
        hv += sum(-1/4*g[dei(p[J,0],p[B,0],p[I,1],p[J,0])]*r[B][1][1,12]*r[J][9][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[B,0],p[I,1],p[J,1])]*r[B][1][1,12]*r[J][39][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[B,0])]*r[B][1][1,12]*r[J][9][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[B,0])]*r[B][1][1,12]*r[J][39][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[B,0],p[J,0],p[J,0])]*r[B][1][1,12]*r[J][9][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,1],p[B,0],p[J,0],p[J,0])]*r[B][1][1,12]*r[J][24][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[B,0],p[J,1],p[J,1])]*r[B][1][1,12]*r[J][39][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,1],p[B,0],p[J,1],p[J,1])]*r[B][1][1,12]*r[J][54][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[B,0])]*r[B][1][1,12]*r[J][9][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[B,0])]*r[B][1][1,12]*r[J][39][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[B,0],p[J,0],p[J,0])]*r[B][1][1,12]*r[I][4][11,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,1],p[B,0],p[J,0],p[J,0])]*r[B][1][1,12]*r[I][4][11,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[B,0],p[J,1],p[J,1])]*r[B][1][1,12]*r[I][4][11,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,1],p[B,0],p[J,1],p[J,1])]*r[B][1][1,12]*r[I][4][11,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[B,0])]*r[B][1][1,12]*r[I][4][11,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[B,0])]*r[B][1][1,12]*r[I][4][11,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[B,0],p[I,1],p[J,0])]*r[B][1][1,12]*r[I][4][11,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[B,0],p[I,1],p[J,1])]*r[B][1][1,12]*r[I][4][11,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[B,0])]*r[B][1][1,12]*r[I][4][11,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[B,0])]*r[B][1][1,12]*r[I][4][11,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += g[dei(p[I,1],p[B,0],p[A,0],p[A,0])]*r[A][24][9,9]*r[B][1][1,12]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B2I11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,9),(B,2),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += h[p[I,1],p[B,1]]*r[B][5][2,12]*r[I][4][11,0]
        hv += -1/2*g[dei(p[B,0],p[B,0],p[I,1],p[B,1])]*r[B][73][2,12]*r[I][4][11,0]
        hv += -1/2*g[dei(p[B,0],p[B,1],p[I,1],p[B,0])]*r[B][61][2,12]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[B,0],p[B,1])]*r[B][73][2,12]*r[I][4][11,0]
        hv += g[dei(p[I,1],p[B,0],p[B,0],p[B,1])]*r[B][113][2,12]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[B,0],p[B,0])]*r[B][61][2,12]*r[I][4][11,0]
        hv += g[dei(p[I,1],p[B,1],p[B,1],p[B,1])]*r[B][181][2,12]*r[I][4][11,0]
        hv += g[dei(p[I,0],p[B,1],p[I,0],p[I,1])]*r[B][5][2,12]*r[I][70][11,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[I,1],p[I,0])]*r[B][5][2,12]*r[I][72][11,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[I,0],p[I,0])]*r[B][5][2,12]*r[I][120][11,0]
        hv += g[dei(p[I,1],p[B,1],p[I,0],p[I,0])]*r[B][5][2,12]*r[I][130][11,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[I,1],p[B,1])]*r[B][5][2,12]*r[I][72][11,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[I,0],p[B,1])]*r[B][5][2,12]*r[I][120][11,0]
        hv += sum(-1/4*g[dei(p[J,0],p[B,1],p[I,1],p[J,0])]*r[B][5][2,12]*r[J][9][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[B,1],p[I,1],p[J,1])]*r[B][5][2,12]*r[J][39][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[B,1])]*r[B][5][2,12]*r[J][9][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[B,1])]*r[B][5][2,12]*r[J][39][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[B,1],p[J,0],p[J,0])]*r[B][5][2,12]*r[J][9][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,1],p[B,1],p[J,0],p[J,0])]*r[B][5][2,12]*r[J][24][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[B,1],p[J,1],p[J,1])]*r[B][5][2,12]*r[J][39][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,1],p[B,1],p[J,1],p[J,1])]*r[B][5][2,12]*r[J][54][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[B,1])]*r[B][5][2,12]*r[J][9][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[B,1])]*r[B][5][2,12]*r[J][39][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[B,1],p[J,0],p[J,0])]*r[B][5][2,12]*r[I][4][11,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,1],p[B,1],p[J,0],p[J,0])]*r[B][5][2,12]*r[I][4][11,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[B,1],p[J,1],p[J,1])]*r[B][5][2,12]*r[I][4][11,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,1],p[B,1],p[J,1],p[J,1])]*r[B][5][2,12]*r[I][4][11,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[B,1])]*r[B][5][2,12]*r[I][4][11,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[B,1])]*r[B][5][2,12]*r[I][4][11,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[B,1],p[I,1],p[J,0])]*r[B][5][2,12]*r[I][4][11,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[B,1],p[I,1],p[J,1])]*r[B][5][2,12]*r[I][4][11,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[B,1])]*r[B][5][2,12]*r[I][4][11,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[B,1])]*r[B][5][2,12]*r[I][4][11,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += g[dei(p[I,1],p[B,1],p[A,0],p[A,0])]*r[A][24][9,9]*r[B][5][2,12]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B3I11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,9),(B,3),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += h[p[I,1],p[B,1]]*r[B][5][3,12]*r[I][4][11,0]
        hv += -1/2*g[dei(p[B,0],p[B,0],p[I,1],p[B,1])]*r[B][73][3,12]*r[I][4][11,0]
        hv += -1/2*g[dei(p[B,0],p[B,1],p[I,1],p[B,0])]*r[B][61][3,12]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[B,0],p[B,1])]*r[B][73][3,12]*r[I][4][11,0]
        hv += g[dei(p[I,1],p[B,0],p[B,0],p[B,1])]*r[B][113][3,12]*r[I][4][11,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[B,0],p[B,0])]*r[B][61][3,12]*r[I][4][11,0]
        hv += g[dei(p[I,1],p[B,1],p[B,1],p[B,1])]*r[B][181][3,12]*r[I][4][11,0]
        hv += g[dei(p[I,0],p[B,1],p[I,0],p[I,1])]*r[B][5][3,12]*r[I][70][11,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[I,1],p[I,0])]*r[B][5][3,12]*r[I][72][11,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[I,0],p[I,0])]*r[B][5][3,12]*r[I][120][11,0]
        hv += g[dei(p[I,1],p[B,1],p[I,0],p[I,0])]*r[B][5][3,12]*r[I][130][11,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[I,1],p[B,1])]*r[B][5][3,12]*r[I][72][11,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[I,0],p[B,1])]*r[B][5][3,12]*r[I][120][11,0]
        hv += sum(-1/4*g[dei(p[J,0],p[B,1],p[I,1],p[J,0])]*r[B][5][3,12]*r[J][9][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[B,1],p[I,1],p[J,1])]*r[B][5][3,12]*r[J][39][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[B,1])]*r[B][5][3,12]*r[J][9][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[B,1])]*r[B][5][3,12]*r[J][39][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[B,1],p[J,0],p[J,0])]*r[B][5][3,12]*r[J][9][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,1],p[B,1],p[J,0],p[J,0])]*r[B][5][3,12]*r[J][24][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[B,1],p[J,1],p[J,1])]*r[B][5][3,12]*r[J][39][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,1],p[B,1],p[J,1],p[J,1])]*r[B][5][3,12]*r[J][54][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[B,1])]*r[B][5][3,12]*r[J][9][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[B,1])]*r[B][5][3,12]*r[J][39][0,0]*r[I][4][11,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[B,1],p[J,0],p[J,0])]*r[B][5][3,12]*r[I][4][11,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,1],p[B,1],p[J,0],p[J,0])]*r[B][5][3,12]*r[I][4][11,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[B,1],p[J,1],p[J,1])]*r[B][5][3,12]*r[I][4][11,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[I,1],p[B,1],p[J,1],p[J,1])]*r[B][5][3,12]*r[I][4][11,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[B,1])]*r[B][5][3,12]*r[I][4][11,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[B,1])]*r[B][5][3,12]*r[I][4][11,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[B,1],p[I,1],p[J,0])]*r[B][5][3,12]*r[I][4][11,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[B,1],p[I,1],p[J,1])]*r[B][5][3,12]*r[I][4][11,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[B,1])]*r[B][5][3,12]*r[I][4][11,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[B,1])]*r[B][5][3,12]*r[I][4][11,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += g[dei(p[I,1],p[B,1],p[A,0],p[A,0])]*r[A][24][9,9]*r[B][5][3,12]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B4I13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,9),(B,4),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += h[p[I,1],p[B,1]]*r[B][7][4,12]*r[I][6][13,0]
        hv += -1*g[dei(p[B,0],p[B,0],p[I,1],p[B,1])]*r[B][81][4,12]*r[I][6][13,0]
        hv += -1*g[dei(p[B,1],p[B,1],p[I,1],p[B,1])]*r[B][149][4,12]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[I,1],p[I,0])]*r[B][7][4,12]*r[I][114][13,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[I,0],p[I,0])]*r[B][7][4,12]*r[I][162][13,0]
        hv += -1*g[dei(p[I,0],p[I,1],p[I,0],p[B,1])]*r[B][7][4,12]*r[I][68][13,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[I,1],p[B,1])]*r[B][7][4,12]*r[I][114][13,0]
        hv += -1*g[dei(p[I,0],p[I,0],p[I,1],p[B,1])]*r[B][7][4,12]*r[I][80][13,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[I,0],p[B,1])]*r[B][7][4,12]*r[I][162][13,0]
        hv += sum(-1/4*g[dei(p[J,0],p[B,1],p[I,1],p[J,0])]*r[B][7][4,12]*r[J][24][0,0]*r[I][6][13,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[B,1],p[I,1],p[J,1])]*r[B][7][4,12]*r[J][54][0,0]*r[I][6][13,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[B,1])]*r[B][7][4,12]*r[J][24][0,0]*r[I][6][13,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,1],p[B,1])]*r[B][7][4,12]*r[J][9][0,0]*r[I][6][13,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[B,1])]*r[B][7][4,12]*r[J][54][0,0]*r[I][6][13,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,1],p[B,1])]*r[B][7][4,12]*r[J][39][0,0]*r[I][6][13,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[B,1],p[J,0],p[J,0])]*r[B][7][4,12]*r[J][24][0,0]*r[I][6][13,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[B,1],p[J,1],p[J,1])]*r[B][7][4,12]*r[J][54][0,0]*r[I][6][13,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[B,1])]*r[B][7][4,12]*r[J][24][0,0]*r[I][6][13,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[B,1])]*r[B][7][4,12]*r[J][54][0,0]*r[I][6][13,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[B,1],p[J,0],p[J,0])]*r[B][7][4,12]*r[I][6][13,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[I,1],p[B,1],p[J,1],p[J,1])]*r[B][7][4,12]*r[I][6][13,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[B,1])]*r[B][7][4,12]*r[I][6][13,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[B,1])]*r[B][7][4,12]*r[I][6][13,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,0],p[B,1],p[I,1],p[J,0])]*r[B][7][4,12]*r[I][6][13,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(-1/4*g[dei(p[J,1],p[B,1],p[I,1],p[J,1])]*r[B][7][4,12]*r[I][6][13,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[B,1])]*r[B][7][4,12]*r[I][6][13,0]*r[J][24][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,0],p[J,0],p[I,1],p[B,1])]*r[B][7][4,12]*r[I][6][13,0]*r[J][9][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[B,1])]*r[B][7][4,12]*r[I][6][13,0]*r[J][54][0,0] for J in range(np) if J not in {A,B,I})
        hv += sum(1/2*g[dei(p[J,1],p[J,1],p[I,1],p[B,1])]*r[B][7][4,12]*r[I][6][13,0]*r[J][39][0,0] for J in range(np) if J not in {A,B,I})
        hv += 1/2*g[dei(p[A,0],p[A,0],p[I,1],p[B,1])]*r[A][24][9,9]*r[B][7][4,12]*r[I][6][13,0]
        hv += -1/2*g[dei(p[A,0],p[B,1],p[I,1],p[A,0])]*r[A][24][9,9]*r[B][7][4,12]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,0],p[B,1])]*r[A][24][9,9]*r[B][7][4,12]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[A,0],p[A,0])]*r[A][24][9,9]*r[B][7][4,12]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B11I1(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,9),(B,11),(I,1)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += 1/2*g[dei(p[B,0],p[B,1],p[I,0],p[I,0])]*r[B][30][11,12]*r[I][24][1,0]
        hv += 1/2*g[dei(p[B,0],p[B,1],p[I,1],p[I,1])]*r[B][30][11,12]*r[I][54][1,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[I,0],p[B,1])]*r[B][30][11,12]*r[I][24][1,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[I,1],p[B,1])]*r[B][30][11,12]*r[I][54][1,0]
        hv += -1/2*g[dei(p[I,0],p[B,1],p[B,0],p[I,0])]*r[B][30][11,12]*r[I][24][1,0]
        hv += -1/2*g[dei(p[I,1],p[B,1],p[B,0],p[I,1])]*r[B][30][11,12]*r[I][54][1,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[B,0],p[B,1])]*r[B][30][11,12]*r[I][24][1,0]
        hv += g[dei(p[I,0],p[I,0],p[B,0],p[B,1])]*r[B][30][11,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[B,0],p[B,1])]*r[B][30][11,12]*r[I][54][1,0]
        hv += g[dei(p[I,1],p[I,1],p[B,0],p[B,1])]*r[B][30][11,12]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B11I2(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,9),(B,11),(I,2)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += 1/2*g[dei(p[B,0],p[B,1],p[I,0],p[I,1])]*r[B][30][11,12]*r[I][30][2,0]
        hv += 1/2*g[dei(p[B,0],p[B,1],p[I,1],p[I,0])]*r[B][30][11,12]*r[I][48][2,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[I,0],p[B,1])]*r[B][30][11,12]*r[I][30][2,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[I,1],p[B,1])]*r[B][30][11,12]*r[I][48][2,0]
        hv += -1/2*g[dei(p[I,0],p[B,1],p[B,0],p[I,1])]*r[B][30][11,12]*r[I][30][2,0]
        hv += -1/2*g[dei(p[I,1],p[B,1],p[B,0],p[I,0])]*r[B][30][11,12]*r[I][48][2,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[B,0],p[B,1])]*r[B][30][11,12]*r[I][30][2,0]
        hv += g[dei(p[I,0],p[I,1],p[B,0],p[B,1])]*r[B][30][11,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[B,0],p[B,1])]*r[B][30][11,12]*r[I][48][2,0]
        hv += g[dei(p[I,1],p[I,0],p[B,0],p[B,1])]*r[B][30][11,12]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B11I3(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,9),(B,11),(I,3)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += 1/2*g[dei(p[B,0],p[B,1],p[I,0],p[I,1])]*r[B][30][11,12]*r[I][30][3,0]
        hv += 1/2*g[dei(p[B,0],p[B,1],p[I,1],p[I,0])]*r[B][30][11,12]*r[I][48][3,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[I,0],p[B,1])]*r[B][30][11,12]*r[I][30][3,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[I,1],p[B,1])]*r[B][30][11,12]*r[I][48][3,0]
        hv += -1/2*g[dei(p[I,0],p[B,1],p[B,0],p[I,1])]*r[B][30][11,12]*r[I][30][3,0]
        hv += -1/2*g[dei(p[I,1],p[B,1],p[B,0],p[I,0])]*r[B][30][11,12]*r[I][48][3,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[B,0],p[B,1])]*r[B][30][11,12]*r[I][30][3,0]
        hv += g[dei(p[I,0],p[I,1],p[B,0],p[B,1])]*r[B][30][11,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[B,0],p[B,1])]*r[B][30][11,12]*r[I][48][3,0]
        hv += g[dei(p[I,1],p[I,0],p[B,0],p[B,1])]*r[B][30][11,12]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B14I4(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,9),(B,14),(I,4)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += -1*g[dei(p[I,0],p[B,0],p[B,0],p[I,1])]*r[B][21][14,12]*r[I][18][4,0]
        hv += -1*g[dei(p[I,1],p[B,0],p[B,0],p[I,0])]*r[B][21][14,12]*r[I][36][4,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B13I4(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,9),(B,13),(I,4)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += -1*g[dei(p[I,0],p[B,1],p[B,0],p[I,1])]*r[B][27][13,12]*r[I][18][4,0]
        hv += -1*g[dei(p[I,1],p[B,1],p[B,0],p[I,0])]*r[B][27][13,12]*r[I][36][4,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B8I15(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,9),(B,8),(I,15)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += g[dei(p[I,0],p[B,0],p[I,0],p[B,1])]*r[B][46][8,12]*r[I][11][15,0]
        hv += g[dei(p[I,1],p[B,0],p[I,1],p[B,1])]*r[B][46][8,12]*r[I][41][15,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9B7I15(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,9),(B,7),(I,15)]))
        hv = 0.0
        sket = sign([A,B])
        
        hv += g[dei(p[I,0],p[B,1],p[I,0],p[B,1])]*r[B][52][7,12]*r[I][11][15,0]
        hv += g[dei(p[I,1],p[B,1],p[I,1],p[B,1])]*r[B][52][7,12]*r[I][41][15,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    v = tuple(sorted([]))
    hv = 0.0
    
    hv += -1*h[p[A,0],p[B,0]]*r[A][0][0,9]*r[B][1][0,12]
    hv += -1*g[dei(p[A,0],p[B,0],p[A,0],p[A,0])]*r[A][66][0,9]*r[B][1][0,12]
    hv += -1*g[dei(p[A,1],p[B,0],p[A,1],p[A,0])]*r[A][146][0,9]*r[B][1][0,12]
    hv += -1*g[dei(p[A,0],p[B,1],p[B,0],p[B,1])]*r[A][0][0,9]*r[B][117][0,12]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[B,1])]*r[A][0][0,9]*r[B][137][0,12]
    hv += -1*g[dei(p[A,0],p[B,0],p[B,1],p[B,1])]*r[A][0][0,9]*r[B][177][0,12]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[B,0])]*r[A][0][0,9]*r[B][125][0,12]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][137][0,12]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][125][0,12]
    hv += sum(-1/2*g[dei(p[A,0],p[B,0],p[I,0],p[I,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,0],p[B,0],p[I,0],p[I,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[A,0],p[B,0],p[I,1],p[I,1])]*r[A][0][0,9]*r[B][1][0,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,0],p[B,0],p[I,1],p[I,1])]*r[A][0][0,9]*r[B][1][0,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,0],p[I,0],p[I,0],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,0],p[I,1],p[I,1],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,0],p[B,0],p[A,0],p[I,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,1],p[B,0],p[A,0],p[I,1])]*r[A][0][0,9]*r[B][1][0,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    v = tuple(sorted([(B,1)]))
    hv = 0.0
    
    hv += -1*h[p[A,0],p[B,0]]*r[A][0][0,9]*r[B][1][1,12]
    hv += -1*g[dei(p[A,0],p[B,0],p[A,0],p[A,0])]*r[A][66][0,9]*r[B][1][1,12]
    hv += -1*g[dei(p[A,1],p[B,0],p[A,1],p[A,0])]*r[A][146][0,9]*r[B][1][1,12]
    hv += -1*g[dei(p[A,0],p[B,1],p[B,0],p[B,1])]*r[A][0][0,9]*r[B][117][1,12]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[B,1])]*r[A][0][0,9]*r[B][137][1,12]
    hv += -1*g[dei(p[A,0],p[B,0],p[B,1],p[B,1])]*r[A][0][0,9]*r[B][177][1,12]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[B,0])]*r[A][0][0,9]*r[B][125][1,12]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][137][1,12]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][125][1,12]
    hv += sum(-1/2*g[dei(p[A,0],p[B,0],p[I,0],p[I,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,0],p[B,0],p[I,0],p[I,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[A,0],p[B,0],p[I,1],p[I,1])]*r[A][0][0,9]*r[B][1][1,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,0],p[B,0],p[I,1],p[I,1])]*r[A][0][0,9]*r[B][1][1,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,0],p[I,0],p[I,0],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,0],p[I,1],p[I,1],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,0],p[B,0],p[A,0],p[I,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,1],p[B,0],p[A,0],p[I,1])]*r[A][0][0,9]*r[B][1][1,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    v = tuple(sorted([(A,1)]))
    hv = 0.0
    
    hv += -1*h[p[A,0],p[B,0]]*r[A][0][1,9]*r[B][1][0,12]
    hv += -1*g[dei(p[A,0],p[B,0],p[A,0],p[A,0])]*r[A][66][1,9]*r[B][1][0,12]
    hv += -1*g[dei(p[A,1],p[B,0],p[A,1],p[A,0])]*r[A][146][1,9]*r[B][1][0,12]
    hv += -1*g[dei(p[A,0],p[B,1],p[B,0],p[B,1])]*r[A][0][1,9]*r[B][117][0,12]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[B,1])]*r[A][0][1,9]*r[B][137][0,12]
    hv += -1*g[dei(p[A,0],p[B,0],p[B,1],p[B,1])]*r[A][0][1,9]*r[B][177][0,12]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[B,0])]*r[A][0][1,9]*r[B][125][0,12]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[B,1])]*r[A][0][1,9]*r[B][137][0,12]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][125][0,12]
    hv += sum(-1/2*g[dei(p[A,0],p[B,0],p[I,0],p[I,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,0],p[B,0],p[I,0],p[I,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[A,0],p[B,0],p[I,1],p[I,1])]*r[A][0][1,9]*r[B][1][0,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,0],p[B,0],p[I,1],p[I,1])]*r[A][0][1,9]*r[B][1][0,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,0],p[I,0],p[I,0],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,0],p[I,1],p[I,1],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,0],p[B,0],p[A,0],p[I,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,1],p[B,0],p[A,0],p[I,1])]*r[A][0][1,9]*r[B][1][0,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B1(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    v = tuple(sorted([(A,1),(B,1)]))
    hv = 0.0
    
    hv += -1*h[p[A,0],p[B,0]]*r[A][0][1,9]*r[B][1][1,12]
    hv += -1*g[dei(p[A,0],p[B,0],p[A,0],p[A,0])]*r[A][66][1,9]*r[B][1][1,12]
    hv += -1*g[dei(p[A,1],p[B,0],p[A,1],p[A,0])]*r[A][146][1,9]*r[B][1][1,12]
    hv += -1*g[dei(p[A,0],p[B,1],p[B,0],p[B,1])]*r[A][0][1,9]*r[B][117][1,12]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,1],p[B,1])]*r[A][0][1,9]*r[B][137][1,12]
    hv += -1*g[dei(p[A,0],p[B,0],p[B,1],p[B,1])]*r[A][0][1,9]*r[B][177][1,12]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,1],p[B,0])]*r[A][0][1,9]*r[B][125][1,12]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,0],p[B,1])]*r[A][0][1,9]*r[B][137][1,12]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][125][1,12]
    hv += sum(-1/2*g[dei(p[A,0],p[B,0],p[I,0],p[I,0])]*r[A][0][1,9]*r[B][1][1,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,0],p[B,0],p[I,0],p[I,0])]*r[A][0][1,9]*r[B][1][1,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[A,0],p[B,0],p[I,1],p[I,1])]*r[A][0][1,9]*r[B][1][1,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,0],p[B,0],p[I,1],p[I,1])]*r[A][0][1,9]*r[B][1][1,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,0],p[I,0],p[I,0],p[B,0])]*r[A][0][1,9]*r[B][1][1,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,0],p[I,1],p[I,1],p[B,0])]*r[A][0][1,9]*r[B][1][1,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,0],p[B,0],p[A,0],p[I,0])]*r[A][0][1,9]*r[B][1][1,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,1],p[B,0],p[A,0],p[I,1])]*r[A][0][1,9]*r[B][1][1,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][1][1,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][1][1,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    v = tuple(sorted([(B,2)]))
    hv = 0.0
    
    hv += -1*h[p[A,0],p[B,1]]*r[A][0][0,9]*r[B][5][2,12]
    hv += -1*g[dei(p[A,0],p[B,1],p[A,0],p[A,0])]*r[A][66][0,9]*r[B][5][2,12]
    hv += -1*g[dei(p[A,1],p[B,1],p[A,1],p[A,0])]*r[A][146][0,9]*r[B][5][2,12]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[B,1])]*r[A][0][0,9]*r[B][73][2,12]
    hv += -1*g[dei(p[A,0],p[B,0],p[B,0],p[B,1])]*r[A][0][0,9]*r[B][113][2,12]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[B,0])]*r[A][0][0,9]*r[B][61][2,12]
    hv += -1*g[dei(p[A,0],p[B,1],p[B,1],p[B,1])]*r[A][0][0,9]*r[B][181][2,12]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][73][2,12]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][61][2,12]
    hv += sum(-1/2*g[dei(p[A,0],p[B,1],p[I,0],p[I,0])]*r[A][0][0,9]*r[B][5][2,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,0],p[B,1],p[I,0],p[I,0])]*r[A][0][0,9]*r[B][5][2,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[A,0],p[B,1],p[I,1],p[I,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,0],p[B,1],p[I,1],p[I,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,0],p[I,0],p[I,0],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,0],p[I,1],p[I,1],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,0],p[B,1],p[A,0],p[I,0])]*r[A][0][0,9]*r[B][5][2,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,1],p[B,1],p[A,0],p[I,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    v = tuple(sorted([(B,3)]))
    hv = 0.0
    
    hv += -1*h[p[A,0],p[B,1]]*r[A][0][0,9]*r[B][5][3,12]
    hv += -1*g[dei(p[A,0],p[B,1],p[A,0],p[A,0])]*r[A][66][0,9]*r[B][5][3,12]
    hv += -1*g[dei(p[A,1],p[B,1],p[A,1],p[A,0])]*r[A][146][0,9]*r[B][5][3,12]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[B,1])]*r[A][0][0,9]*r[B][73][3,12]
    hv += -1*g[dei(p[A,0],p[B,0],p[B,0],p[B,1])]*r[A][0][0,9]*r[B][113][3,12]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[B,0])]*r[A][0][0,9]*r[B][61][3,12]
    hv += -1*g[dei(p[A,0],p[B,1],p[B,1],p[B,1])]*r[A][0][0,9]*r[B][181][3,12]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][73][3,12]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][61][3,12]
    hv += sum(-1/2*g[dei(p[A,0],p[B,1],p[I,0],p[I,0])]*r[A][0][0,9]*r[B][5][3,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,0],p[B,1],p[I,0],p[I,0])]*r[A][0][0,9]*r[B][5][3,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[A,0],p[B,1],p[I,1],p[I,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,0],p[B,1],p[I,1],p[I,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,0],p[I,0],p[I,0],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,0],p[I,1],p[I,1],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,0],p[B,1],p[A,0],p[I,0])]*r[A][0][0,9]*r[B][5][3,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,1],p[B,1],p[A,0],p[I,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B2(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    v = tuple(sorted([(A,1),(B,2)]))
    hv = 0.0
    
    hv += -1*h[p[A,0],p[B,1]]*r[A][0][1,9]*r[B][5][2,12]
    hv += -1*g[dei(p[A,0],p[B,1],p[A,0],p[A,0])]*r[A][66][1,9]*r[B][5][2,12]
    hv += -1*g[dei(p[A,1],p[B,1],p[A,1],p[A,0])]*r[A][146][1,9]*r[B][5][2,12]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[B,1])]*r[A][0][1,9]*r[B][73][2,12]
    hv += -1*g[dei(p[A,0],p[B,0],p[B,0],p[B,1])]*r[A][0][1,9]*r[B][113][2,12]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[B,0])]*r[A][0][1,9]*r[B][61][2,12]
    hv += -1*g[dei(p[A,0],p[B,1],p[B,1],p[B,1])]*r[A][0][1,9]*r[B][181][2,12]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[B,1])]*r[A][0][1,9]*r[B][73][2,12]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][61][2,12]
    hv += sum(-1/2*g[dei(p[A,0],p[B,1],p[I,0],p[I,0])]*r[A][0][1,9]*r[B][5][2,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,0],p[B,1],p[I,0],p[I,0])]*r[A][0][1,9]*r[B][5][2,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[A,0],p[B,1],p[I,1],p[I,1])]*r[A][0][1,9]*r[B][5][2,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,0],p[B,1],p[I,1],p[I,1])]*r[A][0][1,9]*r[B][5][2,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,0],p[I,0],p[I,0],p[B,1])]*r[A][0][1,9]*r[B][5][2,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,0],p[I,1],p[I,1],p[B,1])]*r[A][0][1,9]*r[B][5][2,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,0],p[B,1],p[A,0],p[I,0])]*r[A][0][1,9]*r[B][5][2,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,1],p[B,1],p[A,0],p[I,1])]*r[A][0][1,9]*r[B][5][2,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,0],p[B,1])]*r[A][0][1,9]*r[B][5][2,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,0],p[B,1])]*r[A][0][1,9]*r[B][5][2,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B3(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    v = tuple(sorted([(A,1),(B,3)]))
    hv = 0.0
    
    hv += -1*h[p[A,0],p[B,1]]*r[A][0][1,9]*r[B][5][3,12]
    hv += -1*g[dei(p[A,0],p[B,1],p[A,0],p[A,0])]*r[A][66][1,9]*r[B][5][3,12]
    hv += -1*g[dei(p[A,1],p[B,1],p[A,1],p[A,0])]*r[A][146][1,9]*r[B][5][3,12]
    hv += -1/2*g[dei(p[A,0],p[B,0],p[B,0],p[B,1])]*r[A][0][1,9]*r[B][73][3,12]
    hv += -1*g[dei(p[A,0],p[B,0],p[B,0],p[B,1])]*r[A][0][1,9]*r[B][113][3,12]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[B,0],p[B,0])]*r[A][0][1,9]*r[B][61][3,12]
    hv += -1*g[dei(p[A,0],p[B,1],p[B,1],p[B,1])]*r[A][0][1,9]*r[B][181][3,12]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,0],p[B,1])]*r[A][0][1,9]*r[B][73][3,12]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][61][3,12]
    hv += sum(-1/2*g[dei(p[A,0],p[B,1],p[I,0],p[I,0])]*r[A][0][1,9]*r[B][5][3,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,0],p[B,1],p[I,0],p[I,0])]*r[A][0][1,9]*r[B][5][3,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[A,0],p[B,1],p[I,1],p[I,1])]*r[A][0][1,9]*r[B][5][3,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,0],p[B,1],p[I,1],p[I,1])]*r[A][0][1,9]*r[B][5][3,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,0],p[I,0],p[I,0],p[B,1])]*r[A][0][1,9]*r[B][5][3,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,0],p[I,1],p[I,1],p[B,1])]*r[A][0][1,9]*r[B][5][3,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,0],p[B,1],p[A,0],p[I,0])]*r[A][0][1,9]*r[B][5][3,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,1],p[B,1],p[A,0],p[I,1])]*r[A][0][1,9]*r[B][5][3,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,0],p[B,1])]*r[A][0][1,9]*r[B][5][3,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,0],p[B,1])]*r[A][0][1,9]*r[B][5][3,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    v = tuple(sorted([(A,2)]))
    hv = 0.0
    
    hv += -1*h[p[A,1],p[B,0]]*r[A][4][2,9]*r[B][1][0,12]
    hv += -1*g[dei(p[A,0],p[B,0],p[A,1],p[A,0])]*r[A][82][2,9]*r[B][1][0,12]
    hv += -1*g[dei(p[A,1],p[B,0],p[A,0],p[A,0])]*r[A][130][2,9]*r[B][1][0,12]
    hv += -1*g[dei(p[A,1],p[B,1],p[B,0],p[B,1])]*r[A][4][2,9]*r[B][117][0,12]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[B,1])]*r[A][4][2,9]*r[B][137][0,12]
    hv += -1*g[dei(p[A,1],p[B,0],p[B,1],p[B,1])]*r[A][4][2,9]*r[B][177][0,12]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[B,0])]*r[A][4][2,9]*r[B][125][0,12]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[B,1])]*r[A][4][2,9]*r[B][137][0,12]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][125][0,12]
    hv += sum(-1/2*g[dei(p[A,1],p[B,0],p[I,0],p[I,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,1],p[B,0],p[I,0],p[I,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[A,1],p[B,0],p[I,1],p[I,1])]*r[A][4][2,9]*r[B][1][0,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,1],p[B,0],p[I,1],p[I,1])]*r[A][4][2,9]*r[B][1][0,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,1],p[I,0],p[I,0],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,1],p[I,1],p[I,1],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,0],p[B,0],p[A,1],p[I,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,1],p[B,0],p[A,1],p[I,1])]*r[A][4][2,9]*r[B][1][0,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B1(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    v = tuple(sorted([(A,2),(B,1)]))
    hv = 0.0
    
    hv += -1*h[p[A,1],p[B,0]]*r[A][4][2,9]*r[B][1][1,12]
    hv += -1*g[dei(p[A,0],p[B,0],p[A,1],p[A,0])]*r[A][82][2,9]*r[B][1][1,12]
    hv += -1*g[dei(p[A,1],p[B,0],p[A,0],p[A,0])]*r[A][130][2,9]*r[B][1][1,12]
    hv += -1*g[dei(p[A,1],p[B,1],p[B,0],p[B,1])]*r[A][4][2,9]*r[B][117][1,12]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[B,1])]*r[A][4][2,9]*r[B][137][1,12]
    hv += -1*g[dei(p[A,1],p[B,0],p[B,1],p[B,1])]*r[A][4][2,9]*r[B][177][1,12]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[B,0])]*r[A][4][2,9]*r[B][125][1,12]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[B,1])]*r[A][4][2,9]*r[B][137][1,12]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][125][1,12]
    hv += sum(-1/2*g[dei(p[A,1],p[B,0],p[I,0],p[I,0])]*r[A][4][2,9]*r[B][1][1,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,1],p[B,0],p[I,0],p[I,0])]*r[A][4][2,9]*r[B][1][1,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[A,1],p[B,0],p[I,1],p[I,1])]*r[A][4][2,9]*r[B][1][1,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,1],p[B,0],p[I,1],p[I,1])]*r[A][4][2,9]*r[B][1][1,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,1],p[I,0],p[I,0],p[B,0])]*r[A][4][2,9]*r[B][1][1,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,1],p[I,1],p[I,1],p[B,0])]*r[A][4][2,9]*r[B][1][1,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,0],p[B,0],p[A,1],p[I,0])]*r[A][4][2,9]*r[B][1][1,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,1],p[B,0],p[A,1],p[I,1])]*r[A][4][2,9]*r[B][1][1,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][1][1,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][1][1,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    v = tuple(sorted([(A,3)]))
    hv = 0.0
    
    hv += -1*h[p[A,1],p[B,0]]*r[A][4][3,9]*r[B][1][0,12]
    hv += -1*g[dei(p[A,0],p[B,0],p[A,1],p[A,0])]*r[A][82][3,9]*r[B][1][0,12]
    hv += -1*g[dei(p[A,1],p[B,0],p[A,0],p[A,0])]*r[A][130][3,9]*r[B][1][0,12]
    hv += -1*g[dei(p[A,1],p[B,1],p[B,0],p[B,1])]*r[A][4][3,9]*r[B][117][0,12]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[B,1])]*r[A][4][3,9]*r[B][137][0,12]
    hv += -1*g[dei(p[A,1],p[B,0],p[B,1],p[B,1])]*r[A][4][3,9]*r[B][177][0,12]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[B,0])]*r[A][4][3,9]*r[B][125][0,12]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[B,1])]*r[A][4][3,9]*r[B][137][0,12]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][125][0,12]
    hv += sum(-1/2*g[dei(p[A,1],p[B,0],p[I,0],p[I,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,1],p[B,0],p[I,0],p[I,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[A,1],p[B,0],p[I,1],p[I,1])]*r[A][4][3,9]*r[B][1][0,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,1],p[B,0],p[I,1],p[I,1])]*r[A][4][3,9]*r[B][1][0,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,1],p[I,0],p[I,0],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,1],p[I,1],p[I,1],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,0],p[B,0],p[A,1],p[I,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,1],p[B,0],p[A,1],p[I,1])]*r[A][4][3,9]*r[B][1][0,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B1(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    v = tuple(sorted([(A,3),(B,1)]))
    hv = 0.0
    
    hv += -1*h[p[A,1],p[B,0]]*r[A][4][3,9]*r[B][1][1,12]
    hv += -1*g[dei(p[A,0],p[B,0],p[A,1],p[A,0])]*r[A][82][3,9]*r[B][1][1,12]
    hv += -1*g[dei(p[A,1],p[B,0],p[A,0],p[A,0])]*r[A][130][3,9]*r[B][1][1,12]
    hv += -1*g[dei(p[A,1],p[B,1],p[B,0],p[B,1])]*r[A][4][3,9]*r[B][117][1,12]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,1],p[B,1])]*r[A][4][3,9]*r[B][137][1,12]
    hv += -1*g[dei(p[A,1],p[B,0],p[B,1],p[B,1])]*r[A][4][3,9]*r[B][177][1,12]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,1],p[B,0])]*r[A][4][3,9]*r[B][125][1,12]
    hv += 1/2*g[dei(p[B,1],p[B,0],p[A,1],p[B,1])]*r[A][4][3,9]*r[B][137][1,12]
    hv += 1/2*g[dei(p[B,1],p[B,1],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][125][1,12]
    hv += sum(-1/2*g[dei(p[A,1],p[B,0],p[I,0],p[I,0])]*r[A][4][3,9]*r[B][1][1,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,1],p[B,0],p[I,0],p[I,0])]*r[A][4][3,9]*r[B][1][1,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[A,1],p[B,0],p[I,1],p[I,1])]*r[A][4][3,9]*r[B][1][1,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,1],p[B,0],p[I,1],p[I,1])]*r[A][4][3,9]*r[B][1][1,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,1],p[I,0],p[I,0],p[B,0])]*r[A][4][3,9]*r[B][1][1,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,1],p[I,1],p[I,1],p[B,0])]*r[A][4][3,9]*r[B][1][1,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,0],p[B,0],p[A,1],p[I,0])]*r[A][4][3,9]*r[B][1][1,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,1],p[B,0],p[A,1],p[I,1])]*r[A][4][3,9]*r[B][1][1,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][1][1,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][1][1,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B2(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    v = tuple(sorted([(A,2),(B,2)]))
    hv = 0.0
    
    hv += -1*h[p[A,1],p[B,1]]*r[A][4][2,9]*r[B][5][2,12]
    hv += -1*g[dei(p[A,0],p[B,1],p[A,1],p[A,0])]*r[A][82][2,9]*r[B][5][2,12]
    hv += -1*g[dei(p[A,1],p[B,1],p[A,0],p[A,0])]*r[A][130][2,9]*r[B][5][2,12]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[B,1])]*r[A][4][2,9]*r[B][73][2,12]
    hv += -1*g[dei(p[A,1],p[B,0],p[B,0],p[B,1])]*r[A][4][2,9]*r[B][113][2,12]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[B,0])]*r[A][4][2,9]*r[B][61][2,12]
    hv += -1*g[dei(p[A,1],p[B,1],p[B,1],p[B,1])]*r[A][4][2,9]*r[B][181][2,12]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[B,1])]*r[A][4][2,9]*r[B][73][2,12]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][61][2,12]
    hv += sum(-1/2*g[dei(p[A,1],p[B,1],p[I,0],p[I,0])]*r[A][4][2,9]*r[B][5][2,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,1],p[B,1],p[I,0],p[I,0])]*r[A][4][2,9]*r[B][5][2,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[A,1],p[B,1],p[I,1],p[I,1])]*r[A][4][2,9]*r[B][5][2,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,1],p[B,1],p[I,1],p[I,1])]*r[A][4][2,9]*r[B][5][2,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,1],p[I,0],p[I,0],p[B,1])]*r[A][4][2,9]*r[B][5][2,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,1],p[I,1],p[I,1],p[B,1])]*r[A][4][2,9]*r[B][5][2,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,0],p[B,1],p[A,1],p[I,0])]*r[A][4][2,9]*r[B][5][2,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,1],p[B,1],p[A,1],p[I,1])]*r[A][4][2,9]*r[B][5][2,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,1],p[B,1])]*r[A][4][2,9]*r[B][5][2,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,1],p[B,1])]*r[A][4][2,9]*r[B][5][2,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B3(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    v = tuple(sorted([(A,2),(B,3)]))
    hv = 0.0
    
    hv += -1*h[p[A,1],p[B,1]]*r[A][4][2,9]*r[B][5][3,12]
    hv += -1*g[dei(p[A,0],p[B,1],p[A,1],p[A,0])]*r[A][82][2,9]*r[B][5][3,12]
    hv += -1*g[dei(p[A,1],p[B,1],p[A,0],p[A,0])]*r[A][130][2,9]*r[B][5][3,12]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[B,1])]*r[A][4][2,9]*r[B][73][3,12]
    hv += -1*g[dei(p[A,1],p[B,0],p[B,0],p[B,1])]*r[A][4][2,9]*r[B][113][3,12]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[B,0])]*r[A][4][2,9]*r[B][61][3,12]
    hv += -1*g[dei(p[A,1],p[B,1],p[B,1],p[B,1])]*r[A][4][2,9]*r[B][181][3,12]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[B,1])]*r[A][4][2,9]*r[B][73][3,12]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][61][3,12]
    hv += sum(-1/2*g[dei(p[A,1],p[B,1],p[I,0],p[I,0])]*r[A][4][2,9]*r[B][5][3,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,1],p[B,1],p[I,0],p[I,0])]*r[A][4][2,9]*r[B][5][3,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[A,1],p[B,1],p[I,1],p[I,1])]*r[A][4][2,9]*r[B][5][3,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,1],p[B,1],p[I,1],p[I,1])]*r[A][4][2,9]*r[B][5][3,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,1],p[I,0],p[I,0],p[B,1])]*r[A][4][2,9]*r[B][5][3,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,1],p[I,1],p[I,1],p[B,1])]*r[A][4][2,9]*r[B][5][3,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,0],p[B,1],p[A,1],p[I,0])]*r[A][4][2,9]*r[B][5][3,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,1],p[B,1],p[A,1],p[I,1])]*r[A][4][2,9]*r[B][5][3,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,1],p[B,1])]*r[A][4][2,9]*r[B][5][3,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,1],p[B,1])]*r[A][4][2,9]*r[B][5][3,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B2(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    v = tuple(sorted([(A,3),(B,2)]))
    hv = 0.0
    
    hv += -1*h[p[A,1],p[B,1]]*r[A][4][3,9]*r[B][5][2,12]
    hv += -1*g[dei(p[A,0],p[B,1],p[A,1],p[A,0])]*r[A][82][3,9]*r[B][5][2,12]
    hv += -1*g[dei(p[A,1],p[B,1],p[A,0],p[A,0])]*r[A][130][3,9]*r[B][5][2,12]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[B,1])]*r[A][4][3,9]*r[B][73][2,12]
    hv += -1*g[dei(p[A,1],p[B,0],p[B,0],p[B,1])]*r[A][4][3,9]*r[B][113][2,12]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[B,0])]*r[A][4][3,9]*r[B][61][2,12]
    hv += -1*g[dei(p[A,1],p[B,1],p[B,1],p[B,1])]*r[A][4][3,9]*r[B][181][2,12]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[B,1])]*r[A][4][3,9]*r[B][73][2,12]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][61][2,12]
    hv += sum(-1/2*g[dei(p[A,1],p[B,1],p[I,0],p[I,0])]*r[A][4][3,9]*r[B][5][2,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,1],p[B,1],p[I,0],p[I,0])]*r[A][4][3,9]*r[B][5][2,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[A,1],p[B,1],p[I,1],p[I,1])]*r[A][4][3,9]*r[B][5][2,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,1],p[B,1],p[I,1],p[I,1])]*r[A][4][3,9]*r[B][5][2,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,1],p[I,0],p[I,0],p[B,1])]*r[A][4][3,9]*r[B][5][2,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,1],p[I,1],p[I,1],p[B,1])]*r[A][4][3,9]*r[B][5][2,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,0],p[B,1],p[A,1],p[I,0])]*r[A][4][3,9]*r[B][5][2,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,1],p[B,1],p[A,1],p[I,1])]*r[A][4][3,9]*r[B][5][2,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,1],p[B,1])]*r[A][4][3,9]*r[B][5][2,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,1],p[B,1])]*r[A][4][3,9]*r[B][5][2,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B3(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    v = tuple(sorted([(A,3),(B,3)]))
    hv = 0.0
    
    hv += -1*h[p[A,1],p[B,1]]*r[A][4][3,9]*r[B][5][3,12]
    hv += -1*g[dei(p[A,0],p[B,1],p[A,1],p[A,0])]*r[A][82][3,9]*r[B][5][3,12]
    hv += -1*g[dei(p[A,1],p[B,1],p[A,0],p[A,0])]*r[A][130][3,9]*r[B][5][3,12]
    hv += -1/2*g[dei(p[A,1],p[B,0],p[B,0],p[B,1])]*r[A][4][3,9]*r[B][73][3,12]
    hv += -1*g[dei(p[A,1],p[B,0],p[B,0],p[B,1])]*r[A][4][3,9]*r[B][113][3,12]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[B,0])]*r[A][4][3,9]*r[B][61][3,12]
    hv += -1*g[dei(p[A,1],p[B,1],p[B,1],p[B,1])]*r[A][4][3,9]*r[B][181][3,12]
    hv += 1/2*g[dei(p[B,0],p[B,0],p[A,1],p[B,1])]*r[A][4][3,9]*r[B][73][3,12]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][61][3,12]
    hv += sum(-1/2*g[dei(p[A,1],p[B,1],p[I,0],p[I,0])]*r[A][4][3,9]*r[B][5][3,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,1],p[B,1],p[I,0],p[I,0])]*r[A][4][3,9]*r[B][5][3,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[A,1],p[B,1],p[I,1],p[I,1])]*r[A][4][3,9]*r[B][5][3,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[A,1],p[B,1],p[I,1],p[I,1])]*r[A][4][3,9]*r[B][5][3,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,1],p[I,0],p[I,0],p[B,1])]*r[A][4][3,9]*r[B][5][3,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,1],p[I,1],p[I,1],p[B,1])]*r[A][4][3,9]*r[B][5][3,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,0],p[B,1],p[A,1],p[I,0])]*r[A][4][3,9]*r[B][5][3,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,1],p[B,1],p[A,1],p[I,1])]*r[A][4][3,9]*r[B][5][3,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,1],p[B,1])]*r[A][4][3,9]*r[B][5][3,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,1],p[B,1])]*r[A][4][3,9]*r[B][5][3,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5B4(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    v = tuple(sorted([(A,5),(B,4)]))
    hv = 0.0
    
    hv += -1*h[p[A,1],p[B,1]]*r[A][6][5,9]*r[B][7][4,12]
    hv += 1/2*g[dei(p[A,0],p[A,0],p[A,1],p[B,1])]*r[A][114][5,9]*r[B][7][4,12]
    hv += 1/2*g[dei(p[A,1],p[A,0],p[A,0],p[B,1])]*r[A][162][5,9]*r[B][7][4,12]
    hv += -1/2*g[dei(p[A,0],p[B,1],p[A,1],p[A,0])]*r[A][114][5,9]*r[B][7][4,12]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[A,0],p[A,0])]*r[A][162][5,9]*r[B][7][4,12]
    hv += g[dei(p[B,0],p[B,0],p[A,1],p[B,1])]*r[A][6][5,9]*r[B][81][4,12]
    hv += g[dei(p[B,1],p[B,1],p[A,1],p[B,1])]*r[A][6][5,9]*r[B][149][4,12]
    hv += sum(-1/2*g[dei(p[A,1],p[B,1],p[I,0],p[I,0])]*r[A][6][5,9]*r[B][7][4,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[A,1],p[B,1],p[I,1],p[I,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,1],p[I,0],p[I,0],p[B,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[A,1],p[I,1],p[I,1],p[B,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,0],p[B,1],p[A,1],p[I,0])]*r[A][6][5,9]*r[B][7][4,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,1],p[B,1],p[A,1],p[I,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,0],p[I,0],p[A,1],p[B,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[I,0],p[I,0],p[A,1],p[B,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,1],p[I,1],p[A,1],p[B,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1*g[dei(p[I,1],p[I,1],p[A,1],p[B,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6B15(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    v = tuple(sorted([(A,6),(B,15)]))
    hv = 0.0
    
    hv += h[p[B,0],p[A,0]]*r[A][3][6,9]*r[B][2][15,12]
    hv += 1/2*g[dei(p[B,0],p[A,0],p[B,1],p[B,1])]*r[A][3][6,9]*r[B][118][15,12]
    hv += 1/2*g[dei(p[B,1],p[A,0],p[B,0],p[B,1])]*r[A][3][6,9]*r[B][166][15,12]
    hv += -1*g[dei(p[B,0],p[B,0],p[B,0],p[A,0])]*r[A][3][6,9]*r[B][64][15,12]
    hv += -1/2*g[dei(p[B,0],p[B,1],p[B,1],p[A,0])]*r[A][3][6,9]*r[B][118][15,12]
    hv += -1/2*g[dei(p[B,1],p[B,1],p[B,0],p[A,0])]*r[A][3][6,9]*r[B][166][15,12]
    hv += -1*g[dei(p[B,1],p[B,1],p[B,0],p[A,0])]*r[A][3][6,9]*r[B][132][15,12]
    hv += sum(1/2*g[dei(p[B,0],p[A,0],p[I,0],p[I,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[B,0],p[A,0],p[I,1],p[I,1])]*r[A][3][6,9]*r[B][2][15,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[B,0],p[I,0],p[I,0],p[A,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[B,0],p[I,1],p[I,1],p[A,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,0],p[A,0],p[B,0],p[I,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(-1/2*g[dei(p[I,1],p[A,0],p[B,0],p[I,1])]*r[A][3][6,9]*r[B][2][15,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,0],p[I,0],p[B,0],p[A,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][24][0,0] for I in range(np) if I not in {A,B})
    hv += sum(g[dei(p[I,0],p[I,0],p[B,0],p[A,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][9][0,0] for I in range(np) if I not in {A,B})
    hv += sum(1/2*g[dei(p[I,1],p[I,1],p[B,0],p[A,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][54][0,0] for I in range(np) if I not in {A,B})
    hv += sum(g[dei(p[I,1],p[I,1],p[B,0],p[A,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][39][0,0] for I in range(np) if I not in {A,B})
    
    hd[v] = hd.get(v,0.0)+hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    v = tuple(sorted([(A,11),(B,10)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,0],p[B,0],p[A,1],p[B,1])]*r[A][14][11,9]*r[B][34][10,12]
    hv += 1/2*g[dei(p[A,0],p[B,1],p[A,1],p[B,0])]*r[A][14][11,9]*r[B][16][10,12]
    hv += 1/2*g[dei(p[A,1],p[B,0],p[A,0],p[B,1])]*r[A][32][11,9]*r[B][34][10,12]
    hv += 1/2*g[dei(p[A,1],p[B,1],p[A,0],p[B,0])]*r[A][32][11,9]*r[B][16][10,12]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    v = tuple(sorted([(A,13),(B,8)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[A,0],p[B,0],p[A,1],p[B,1])]*r[A][17][13,9]*r[B][46][8,12]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    v = tuple(sorted([(A,13),(B,7)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[A,0],p[B,1],p[A,1],p[B,1])]*r[A][17][13,9]*r[B][52][7,12]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    v = tuple(sorted([(A,14),(B,8)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[A,1],p[B,0],p[A,1],p[B,1])]*r[A][41][14,9]*r[B][46][8,12]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    v = tuple(sorted([(A,14),(B,7)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += g[dei(p[A,1],p[B,1],p[A,1],p[B,1])]*r[A][41][14,9]*r[B][52][7,12]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    v = tuple(sorted([(A,10),(B,11)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += 1/2*g[dei(p[A,1],p[A,0],p[B,0],p[B,1])]*r[A][48][10,9]*r[B][30][11,12]
    hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[A,0])]*r[A][48][10,9]*r[B][30][11,12]
    hv += -1/2*g[dei(p[B,0],p[A,0],p[A,1],p[B,1])]*r[A][48][10,9]*r[B][30][11,12]
    hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[A,0])]*r[A][48][10,9]*r[B][30][11,12]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    v = tuple(sorted([(A,7),(B,14)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[A,0],p[B,0],p[B,0],p[A,0])]*r[A][12][7,9]*r[B][21][14,12]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    v = tuple(sorted([(A,7),(B,13)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[A,0],p[B,1],p[B,0],p[A,0])]*r[A][12][7,9]*r[B][27][13,12]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    v = tuple(sorted([(A,8),(B,14)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[A,1],p[B,0],p[B,0],p[A,0])]*r[A][36][8,9]*r[B][21][14,12]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    v = tuple(sorted([(A,8),(B,13)]))
    hv = 0.0
    sket = sign([A,B])
    
    hv += -1*g[dei(p[A,1],p[B,1],p[B,0],p[A,0])]*r[A][36][8,9]*r[B][27][13,12]
    
    hd[v] = hd.get(v,0.0)+sket*hv
    
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B12I1J9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,12),(I,1),(J,9)]))
            hv = 0.0
            sket = sign([B,J])
            
            hv += -1/4*g[dei(p[A,0],p[I,0],p[I,0],p[J,0])]*r[A][0][0,9]*r[I][9][1,0]*r[J][1][9,0]
            hv += -1/4*g[dei(p[A,0],p[I,1],p[I,1],p[J,0])]*r[A][0][0,9]*r[I][39][1,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[A,0],p[J,0],p[I,0],p[I,0])]*r[A][0][0,9]*r[I][9][1,0]*r[J][1][9,0]
            hv += 1/2*g[dei(p[A,0],p[J,0],p[I,0],p[I,0])]*r[A][0][0,9]*r[I][24][1,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[A,0],p[J,0],p[I,1],p[I,1])]*r[A][0][0,9]*r[I][39][1,0]*r[J][1][9,0]
            hv += 1/2*g[dei(p[A,0],p[J,0],p[I,1],p[I,1])]*r[A][0][0,9]*r[I][54][1,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[I,0],p[I,0],p[A,0],p[J,0])]*r[A][0][0,9]*r[I][9][1,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[I,1],p[I,1],p[A,0],p[J,0])]*r[A][0][0,9]*r[I][39][1,0]*r[J][1][9,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[A,0],p[I,0])]*r[A][0][0,9]*r[I][9][1,0]*r[J][1][9,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[A,0],p[I,1])]*r[A][0][0,9]*r[I][39][1,0]*r[J][1][9,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B12I1J10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,12),(I,1),(J,10)]))
            hv = 0.0
            sket = sign([B,J])
            
            hv += -1/4*g[dei(p[A,0],p[I,0],p[I,0],p[J,1])]*r[A][0][0,9]*r[I][9][1,0]*r[J][5][10,0]
            hv += -1/4*g[dei(p[A,0],p[I,1],p[I,1],p[J,1])]*r[A][0][0,9]*r[I][39][1,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[A,0],p[J,1],p[I,0],p[I,0])]*r[A][0][0,9]*r[I][9][1,0]*r[J][5][10,0]
            hv += 1/2*g[dei(p[A,0],p[J,1],p[I,0],p[I,0])]*r[A][0][0,9]*r[I][24][1,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[A,0],p[J,1],p[I,1],p[I,1])]*r[A][0][0,9]*r[I][39][1,0]*r[J][5][10,0]
            hv += 1/2*g[dei(p[A,0],p[J,1],p[I,1],p[I,1])]*r[A][0][0,9]*r[I][54][1,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[I,0],p[I,0],p[A,0],p[J,1])]*r[A][0][0,9]*r[I][9][1,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[I,1],p[I,1],p[A,0],p[J,1])]*r[A][0][0,9]*r[I][39][1,0]*r[J][5][10,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[A,0],p[I,0])]*r[A][0][0,9]*r[I][9][1,0]*r[J][5][10,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[A,0],p[I,1])]*r[A][0][0,9]*r[I][39][1,0]*r[J][5][10,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B12I2J9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,12),(I,2),(J,9)]))
            hv = 0.0
            sket = sign([B,J])
            
            hv += -1/4*g[dei(p[A,0],p[I,1],p[I,0],p[J,0])]*r[A][0][0,9]*r[I][15][2,0]*r[J][1][9,0]
            hv += -1/4*g[dei(p[A,0],p[I,0],p[I,1],p[J,0])]*r[A][0][0,9]*r[I][33][2,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[A,0],p[J,0],p[I,0],p[I,1])]*r[A][0][0,9]*r[I][15][2,0]*r[J][1][9,0]
            hv += 1/2*g[dei(p[A,0],p[J,0],p[I,0],p[I,1])]*r[A][0][0,9]*r[I][30][2,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[A,0],p[J,0],p[I,1],p[I,0])]*r[A][0][0,9]*r[I][33][2,0]*r[J][1][9,0]
            hv += 1/2*g[dei(p[A,0],p[J,0],p[I,1],p[I,0])]*r[A][0][0,9]*r[I][48][2,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[I,0],p[I,1],p[A,0],p[J,0])]*r[A][0][0,9]*r[I][15][2,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[A,0],p[J,0])]*r[A][0][0,9]*r[I][33][2,0]*r[J][1][9,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[A,0],p[I,1])]*r[A][0][0,9]*r[I][15][2,0]*r[J][1][9,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[A,0],p[I,0])]*r[A][0][0,9]*r[I][33][2,0]*r[J][1][9,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B12I3J9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,12),(I,3),(J,9)]))
            hv = 0.0
            sket = sign([B,J])
            
            hv += -1/4*g[dei(p[A,0],p[I,1],p[I,0],p[J,0])]*r[A][0][0,9]*r[I][15][3,0]*r[J][1][9,0]
            hv += -1/4*g[dei(p[A,0],p[I,0],p[I,1],p[J,0])]*r[A][0][0,9]*r[I][33][3,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[A,0],p[J,0],p[I,0],p[I,1])]*r[A][0][0,9]*r[I][15][3,0]*r[J][1][9,0]
            hv += 1/2*g[dei(p[A,0],p[J,0],p[I,0],p[I,1])]*r[A][0][0,9]*r[I][30][3,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[A,0],p[J,0],p[I,1],p[I,0])]*r[A][0][0,9]*r[I][33][3,0]*r[J][1][9,0]
            hv += 1/2*g[dei(p[A,0],p[J,0],p[I,1],p[I,0])]*r[A][0][0,9]*r[I][48][3,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[I,0],p[I,1],p[A,0],p[J,0])]*r[A][0][0,9]*r[I][15][3,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[A,0],p[J,0])]*r[A][0][0,9]*r[I][33][3,0]*r[J][1][9,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[A,0],p[I,1])]*r[A][0][0,9]*r[I][15][3,0]*r[J][1][9,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[A,0],p[I,0])]*r[A][0][0,9]*r[I][33][3,0]*r[J][1][9,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B12I5J7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,12),(I,5),(J,7)]))
            hv = 0.0
            sket = sign([B,J])
            
            hv += -1/2*g[dei(p[A,0],p[I,1],p[I,0],p[J,0])]*r[A][0][0,9]*r[I][27][5,0]*r[J][3][7,0]
            hv += -1/2*g[dei(p[A,0],p[I,0],p[I,1],p[J,0])]*r[A][0][0,9]*r[I][45][5,0]*r[J][3][7,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B12I2J10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,12),(I,2),(J,10)]))
            hv = 0.0
            sket = sign([B,J])
            
            hv += -1/4*g[dei(p[A,0],p[I,1],p[I,0],p[J,1])]*r[A][0][0,9]*r[I][15][2,0]*r[J][5][10,0]
            hv += -1/4*g[dei(p[A,0],p[I,0],p[I,1],p[J,1])]*r[A][0][0,9]*r[I][33][2,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[A,0],p[J,1],p[I,0],p[I,1])]*r[A][0][0,9]*r[I][15][2,0]*r[J][5][10,0]
            hv += 1/2*g[dei(p[A,0],p[J,1],p[I,0],p[I,1])]*r[A][0][0,9]*r[I][30][2,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[A,0],p[J,1],p[I,1],p[I,0])]*r[A][0][0,9]*r[I][33][2,0]*r[J][5][10,0]
            hv += 1/2*g[dei(p[A,0],p[J,1],p[I,1],p[I,0])]*r[A][0][0,9]*r[I][48][2,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[I,0],p[I,1],p[A,0],p[J,1])]*r[A][0][0,9]*r[I][15][2,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[A,0],p[J,1])]*r[A][0][0,9]*r[I][33][2,0]*r[J][5][10,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[A,0],p[I,1])]*r[A][0][0,9]*r[I][15][2,0]*r[J][5][10,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[A,0],p[I,0])]*r[A][0][0,9]*r[I][33][2,0]*r[J][5][10,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B12I3J10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,12),(I,3),(J,10)]))
            hv = 0.0
            sket = sign([B,J])
            
            hv += -1/4*g[dei(p[A,0],p[I,1],p[I,0],p[J,1])]*r[A][0][0,9]*r[I][15][3,0]*r[J][5][10,0]
            hv += -1/4*g[dei(p[A,0],p[I,0],p[I,1],p[J,1])]*r[A][0][0,9]*r[I][33][3,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[A,0],p[J,1],p[I,0],p[I,1])]*r[A][0][0,9]*r[I][15][3,0]*r[J][5][10,0]
            hv += 1/2*g[dei(p[A,0],p[J,1],p[I,0],p[I,1])]*r[A][0][0,9]*r[I][30][3,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[A,0],p[J,1],p[I,1],p[I,0])]*r[A][0][0,9]*r[I][33][3,0]*r[J][5][10,0]
            hv += 1/2*g[dei(p[A,0],p[J,1],p[I,1],p[I,0])]*r[A][0][0,9]*r[I][48][3,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[I,0],p[I,1],p[A,0],p[J,1])]*r[A][0][0,9]*r[I][15][3,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[A,0],p[J,1])]*r[A][0][0,9]*r[I][33][3,0]*r[J][5][10,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[A,0],p[I,1])]*r[A][0][0,9]*r[I][15][3,0]*r[J][5][10,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[A,0],p[I,0])]*r[A][0][0,9]*r[I][33][3,0]*r[J][5][10,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B12I5J8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,12),(I,5),(J,8)]))
            hv = 0.0
            sket = sign([B,J])
            
            hv += -1/2*g[dei(p[A,0],p[I,1],p[I,0],p[J,1])]*r[A][0][0,9]*r[I][27][5,0]*r[J][7][8,0]
            hv += -1/2*g[dei(p[A,0],p[I,0],p[I,1],p[J,1])]*r[A][0][0,9]*r[I][45][5,0]*r[J][7][8,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B12I14J6(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,12),(I,14),(J,6)]))
            hv = 0.0
            sket = sign([B,I])
            
            hv += 1/2*g[dei(p[A,0],p[J,0],p[I,0],p[J,0])]*r[A][0][0,9]*r[I][2][14,0]*r[J][22][6,0]
            hv += 1/2*g[dei(p[A,0],p[J,1],p[I,0],p[J,1])]*r[A][0][0,9]*r[I][2][14,0]*r[J][52][6,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B12I13J6(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,12),(I,13),(J,6)]))
            hv = 0.0
            sket = sign([B,I])
            
            hv += 1/2*g[dei(p[A,0],p[J,0],p[I,1],p[J,0])]*r[A][0][0,9]*r[I][6][13,0]*r[J][22][6,0]
            hv += 1/2*g[dei(p[A,0],p[J,1],p[I,1],p[J,1])]*r[A][0][0,9]*r[I][6][13,0]*r[J][52][6,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B12I6J14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,12),(I,6),(J,14)]))
            hv = 0.0
            sket = sign([B,J])
            
            hv += 1/2*g[dei(p[A,0],p[I,0],p[J,0],p[I,0])]*r[A][0][0,9]*r[I][22][6,0]*r[J][2][14,0]
            hv += 1/2*g[dei(p[A,0],p[I,1],p[J,0],p[I,1])]*r[A][0][0,9]*r[I][52][6,0]*r[J][2][14,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B12I6J13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,12),(I,6),(J,13)]))
            hv = 0.0
            sket = sign([B,J])
            
            hv += 1/2*g[dei(p[A,0],p[I,0],p[J,1],p[I,0])]*r[A][0][0,9]*r[I][22][6,0]*r[J][6][13,0]
            hv += 1/2*g[dei(p[A,0],p[I,1],p[J,1],p[I,1])]*r[A][0][0,9]*r[I][52][6,0]*r[J][6][13,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B12I9J1(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,12),(I,9),(J,1)]))
            hv = 0.0
            sket = sign([B,I])
            
            hv += 1/4*g[dei(p[A,0],p[I,0],p[J,0],p[J,0])]*r[A][0][0,9]*r[I][1][9,0]*r[J][9][1,0]
            hv += 1/2*g[dei(p[A,0],p[I,0],p[J,0],p[J,0])]*r[A][0][0,9]*r[I][1][9,0]*r[J][24][1,0]
            hv += 1/4*g[dei(p[A,0],p[I,0],p[J,1],p[J,1])]*r[A][0][0,9]*r[I][1][9,0]*r[J][39][1,0]
            hv += 1/2*g[dei(p[A,0],p[I,0],p[J,1],p[J,1])]*r[A][0][0,9]*r[I][1][9,0]*r[J][54][1,0]
            hv += -1/4*g[dei(p[A,0],p[J,0],p[J,0],p[I,0])]*r[A][0][0,9]*r[I][1][9,0]*r[J][9][1,0]
            hv += -1/4*g[dei(p[A,0],p[J,1],p[J,1],p[I,0])]*r[A][0][0,9]*r[I][1][9,0]*r[J][39][1,0]
            hv += -1/4*g[dei(p[J,0],p[I,0],p[A,0],p[J,0])]*r[A][0][0,9]*r[I][1][9,0]*r[J][9][1,0]
            hv += -1/4*g[dei(p[J,1],p[I,0],p[A,0],p[J,1])]*r[A][0][0,9]*r[I][1][9,0]*r[J][39][1,0]
            hv += 1/4*g[dei(p[J,0],p[J,0],p[A,0],p[I,0])]*r[A][0][0,9]*r[I][1][9,0]*r[J][9][1,0]
            hv += 1/4*g[dei(p[J,1],p[J,1],p[A,0],p[I,0])]*r[A][0][0,9]*r[I][1][9,0]*r[J][39][1,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B12I9J2(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,12),(I,9),(J,2)]))
            hv = 0.0
            sket = sign([B,I])
            
            hv += 1/4*g[dei(p[A,0],p[I,0],p[J,0],p[J,1])]*r[A][0][0,9]*r[I][1][9,0]*r[J][15][2,0]
            hv += 1/2*g[dei(p[A,0],p[I,0],p[J,0],p[J,1])]*r[A][0][0,9]*r[I][1][9,0]*r[J][30][2,0]
            hv += 1/4*g[dei(p[A,0],p[I,0],p[J,1],p[J,0])]*r[A][0][0,9]*r[I][1][9,0]*r[J][33][2,0]
            hv += 1/2*g[dei(p[A,0],p[I,0],p[J,1],p[J,0])]*r[A][0][0,9]*r[I][1][9,0]*r[J][48][2,0]
            hv += -1/4*g[dei(p[A,0],p[J,1],p[J,0],p[I,0])]*r[A][0][0,9]*r[I][1][9,0]*r[J][15][2,0]
            hv += -1/4*g[dei(p[A,0],p[J,0],p[J,1],p[I,0])]*r[A][0][0,9]*r[I][1][9,0]*r[J][33][2,0]
            hv += -1/4*g[dei(p[J,0],p[I,0],p[A,0],p[J,1])]*r[A][0][0,9]*r[I][1][9,0]*r[J][15][2,0]
            hv += -1/4*g[dei(p[J,1],p[I,0],p[A,0],p[J,0])]*r[A][0][0,9]*r[I][1][9,0]*r[J][33][2,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[A,0],p[I,0])]*r[A][0][0,9]*r[I][1][9,0]*r[J][15][2,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[A,0],p[I,0])]*r[A][0][0,9]*r[I][1][9,0]*r[J][33][2,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B12I9J3(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,12),(I,9),(J,3)]))
            hv = 0.0
            sket = sign([B,I])
            
            hv += 1/4*g[dei(p[A,0],p[I,0],p[J,0],p[J,1])]*r[A][0][0,9]*r[I][1][9,0]*r[J][15][3,0]
            hv += 1/2*g[dei(p[A,0],p[I,0],p[J,0],p[J,1])]*r[A][0][0,9]*r[I][1][9,0]*r[J][30][3,0]
            hv += 1/4*g[dei(p[A,0],p[I,0],p[J,1],p[J,0])]*r[A][0][0,9]*r[I][1][9,0]*r[J][33][3,0]
            hv += 1/2*g[dei(p[A,0],p[I,0],p[J,1],p[J,0])]*r[A][0][0,9]*r[I][1][9,0]*r[J][48][3,0]
            hv += -1/4*g[dei(p[A,0],p[J,1],p[J,0],p[I,0])]*r[A][0][0,9]*r[I][1][9,0]*r[J][15][3,0]
            hv += -1/4*g[dei(p[A,0],p[J,0],p[J,1],p[I,0])]*r[A][0][0,9]*r[I][1][9,0]*r[J][33][3,0]
            hv += -1/4*g[dei(p[J,0],p[I,0],p[A,0],p[J,1])]*r[A][0][0,9]*r[I][1][9,0]*r[J][15][3,0]
            hv += -1/4*g[dei(p[J,1],p[I,0],p[A,0],p[J,0])]*r[A][0][0,9]*r[I][1][9,0]*r[J][33][3,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[A,0],p[I,0])]*r[A][0][0,9]*r[I][1][9,0]*r[J][15][3,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[A,0],p[I,0])]*r[A][0][0,9]*r[I][1][9,0]*r[J][33][3,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B12I10J1(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,12),(I,10),(J,1)]))
            hv = 0.0
            sket = sign([B,I])
            
            hv += 1/4*g[dei(p[A,0],p[I,1],p[J,0],p[J,0])]*r[A][0][0,9]*r[I][5][10,0]*r[J][9][1,0]
            hv += 1/2*g[dei(p[A,0],p[I,1],p[J,0],p[J,0])]*r[A][0][0,9]*r[I][5][10,0]*r[J][24][1,0]
            hv += 1/4*g[dei(p[A,0],p[I,1],p[J,1],p[J,1])]*r[A][0][0,9]*r[I][5][10,0]*r[J][39][1,0]
            hv += 1/2*g[dei(p[A,0],p[I,1],p[J,1],p[J,1])]*r[A][0][0,9]*r[I][5][10,0]*r[J][54][1,0]
            hv += -1/4*g[dei(p[A,0],p[J,0],p[J,0],p[I,1])]*r[A][0][0,9]*r[I][5][10,0]*r[J][9][1,0]
            hv += -1/4*g[dei(p[A,0],p[J,1],p[J,1],p[I,1])]*r[A][0][0,9]*r[I][5][10,0]*r[J][39][1,0]
            hv += -1/4*g[dei(p[J,0],p[I,1],p[A,0],p[J,0])]*r[A][0][0,9]*r[I][5][10,0]*r[J][9][1,0]
            hv += -1/4*g[dei(p[J,1],p[I,1],p[A,0],p[J,1])]*r[A][0][0,9]*r[I][5][10,0]*r[J][39][1,0]
            hv += 1/4*g[dei(p[J,0],p[J,0],p[A,0],p[I,1])]*r[A][0][0,9]*r[I][5][10,0]*r[J][9][1,0]
            hv += 1/4*g[dei(p[J,1],p[J,1],p[A,0],p[I,1])]*r[A][0][0,9]*r[I][5][10,0]*r[J][39][1,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B12I10J2(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,12),(I,10),(J,2)]))
            hv = 0.0
            sket = sign([B,I])
            
            hv += 1/4*g[dei(p[A,0],p[I,1],p[J,0],p[J,1])]*r[A][0][0,9]*r[I][5][10,0]*r[J][15][2,0]
            hv += 1/2*g[dei(p[A,0],p[I,1],p[J,0],p[J,1])]*r[A][0][0,9]*r[I][5][10,0]*r[J][30][2,0]
            hv += 1/4*g[dei(p[A,0],p[I,1],p[J,1],p[J,0])]*r[A][0][0,9]*r[I][5][10,0]*r[J][33][2,0]
            hv += 1/2*g[dei(p[A,0],p[I,1],p[J,1],p[J,0])]*r[A][0][0,9]*r[I][5][10,0]*r[J][48][2,0]
            hv += -1/4*g[dei(p[A,0],p[J,1],p[J,0],p[I,1])]*r[A][0][0,9]*r[I][5][10,0]*r[J][15][2,0]
            hv += -1/4*g[dei(p[A,0],p[J,0],p[J,1],p[I,1])]*r[A][0][0,9]*r[I][5][10,0]*r[J][33][2,0]
            hv += -1/4*g[dei(p[J,0],p[I,1],p[A,0],p[J,1])]*r[A][0][0,9]*r[I][5][10,0]*r[J][15][2,0]
            hv += -1/4*g[dei(p[J,1],p[I,1],p[A,0],p[J,0])]*r[A][0][0,9]*r[I][5][10,0]*r[J][33][2,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[A,0],p[I,1])]*r[A][0][0,9]*r[I][5][10,0]*r[J][15][2,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[A,0],p[I,1])]*r[A][0][0,9]*r[I][5][10,0]*r[J][33][2,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B12I10J3(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,12),(I,10),(J,3)]))
            hv = 0.0
            sket = sign([B,I])
            
            hv += 1/4*g[dei(p[A,0],p[I,1],p[J,0],p[J,1])]*r[A][0][0,9]*r[I][5][10,0]*r[J][15][3,0]
            hv += 1/2*g[dei(p[A,0],p[I,1],p[J,0],p[J,1])]*r[A][0][0,9]*r[I][5][10,0]*r[J][30][3,0]
            hv += 1/4*g[dei(p[A,0],p[I,1],p[J,1],p[J,0])]*r[A][0][0,9]*r[I][5][10,0]*r[J][33][3,0]
            hv += 1/2*g[dei(p[A,0],p[I,1],p[J,1],p[J,0])]*r[A][0][0,9]*r[I][5][10,0]*r[J][48][3,0]
            hv += -1/4*g[dei(p[A,0],p[J,1],p[J,0],p[I,1])]*r[A][0][0,9]*r[I][5][10,0]*r[J][15][3,0]
            hv += -1/4*g[dei(p[A,0],p[J,0],p[J,1],p[I,1])]*r[A][0][0,9]*r[I][5][10,0]*r[J][33][3,0]
            hv += -1/4*g[dei(p[J,0],p[I,1],p[A,0],p[J,1])]*r[A][0][0,9]*r[I][5][10,0]*r[J][15][3,0]
            hv += -1/4*g[dei(p[J,1],p[I,1],p[A,0],p[J,0])]*r[A][0][0,9]*r[I][5][10,0]*r[J][33][3,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[A,0],p[I,1])]*r[A][0][0,9]*r[I][5][10,0]*r[J][15][3,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[A,0],p[I,1])]*r[A][0][0,9]*r[I][5][10,0]*r[J][33][3,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B12I7J5(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,12),(I,7),(J,5)]))
            hv = 0.0
            sket = sign([B,I])
            
            hv += -1/2*g[dei(p[A,0],p[J,1],p[J,0],p[I,0])]*r[A][0][0,9]*r[I][3][7,0]*r[J][27][5,0]
            hv += -1/2*g[dei(p[A,0],p[J,0],p[J,1],p[I,0])]*r[A][0][0,9]*r[I][3][7,0]*r[J][45][5,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B12I8J5(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,12),(I,8),(J,5)]))
            hv = 0.0
            sket = sign([B,I])
            
            hv += -1/2*g[dei(p[A,0],p[J,1],p[J,0],p[I,1])]*r[A][0][0,9]*r[I][7][8,0]*r[J][27][5,0]
            hv += -1/2*g[dei(p[A,0],p[J,0],p[J,1],p[I,1])]*r[A][0][0,9]*r[I][7][8,0]*r[J][45][5,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9I15J7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,9),(I,15),(J,7)]))
            hv = 0.0
            sket = sign([A,J])
            
            hv += 1/2*g[dei(p[I,0],p[B,0],p[I,0],p[J,0])]*r[B][1][0,12]*r[I][11][15,0]*r[J][3][7,0]
            hv += 1/2*g[dei(p[I,1],p[B,0],p[I,1],p[J,0])]*r[B][1][0,12]*r[I][41][15,0]*r[J][3][7,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9I15J8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,9),(I,15),(J,8)]))
            hv = 0.0
            sket = sign([A,J])
            
            hv += 1/2*g[dei(p[I,0],p[B,0],p[I,0],p[J,1])]*r[B][1][0,12]*r[I][11][15,0]*r[J][7][8,0]
            hv += 1/2*g[dei(p[I,1],p[B,0],p[I,1],p[J,1])]*r[B][1][0,12]*r[I][41][15,0]*r[J][7][8,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9I1J12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,9),(I,1),(J,12)]))
            hv = 0.0
            sket = sign([A,J])
            
            hv += -1/4*g[dei(p[I,0],p[B,0],p[J,0],p[I,0])]*r[B][1][0,12]*r[I][9][1,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[I,1],p[B,0],p[J,0],p[I,1])]*r[B][1][0,12]*r[I][39][1,0]*r[J][0][12,0]
            hv += 1/4*g[dei(p[I,0],p[I,0],p[J,0],p[B,0])]*r[B][1][0,12]*r[I][9][1,0]*r[J][0][12,0]
            hv += 1/4*g[dei(p[I,1],p[I,1],p[J,0],p[B,0])]*r[B][1][0,12]*r[I][39][1,0]*r[J][0][12,0]
            hv += 1/4*g[dei(p[J,0],p[B,0],p[I,0],p[I,0])]*r[B][1][0,12]*r[I][9][1,0]*r[J][0][12,0]
            hv += 1/2*g[dei(p[J,0],p[B,0],p[I,0],p[I,0])]*r[B][1][0,12]*r[I][24][1,0]*r[J][0][12,0]
            hv += 1/4*g[dei(p[J,0],p[B,0],p[I,1],p[I,1])]*r[B][1][0,12]*r[I][39][1,0]*r[J][0][12,0]
            hv += 1/2*g[dei(p[J,0],p[B,0],p[I,1],p[I,1])]*r[B][1][0,12]*r[I][54][1,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[J,0],p[I,0],p[I,0],p[B,0])]*r[B][1][0,12]*r[I][9][1,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[J,0],p[I,1],p[I,1],p[B,0])]*r[B][1][0,12]*r[I][39][1,0]*r[J][0][12,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9I2J12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,9),(I,2),(J,12)]))
            hv = 0.0
            sket = sign([A,J])
            
            hv += -1/4*g[dei(p[I,0],p[B,0],p[J,0],p[I,1])]*r[B][1][0,12]*r[I][15][2,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[I,1],p[B,0],p[J,0],p[I,0])]*r[B][1][0,12]*r[I][33][2,0]*r[J][0][12,0]
            hv += 1/4*g[dei(p[I,0],p[I,1],p[J,0],p[B,0])]*r[B][1][0,12]*r[I][15][2,0]*r[J][0][12,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[J,0],p[B,0])]*r[B][1][0,12]*r[I][33][2,0]*r[J][0][12,0]
            hv += 1/4*g[dei(p[J,0],p[B,0],p[I,0],p[I,1])]*r[B][1][0,12]*r[I][15][2,0]*r[J][0][12,0]
            hv += 1/2*g[dei(p[J,0],p[B,0],p[I,0],p[I,1])]*r[B][1][0,12]*r[I][30][2,0]*r[J][0][12,0]
            hv += 1/4*g[dei(p[J,0],p[B,0],p[I,1],p[I,0])]*r[B][1][0,12]*r[I][33][2,0]*r[J][0][12,0]
            hv += 1/2*g[dei(p[J,0],p[B,0],p[I,1],p[I,0])]*r[B][1][0,12]*r[I][48][2,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[J,0],p[I,1],p[I,0],p[B,0])]*r[B][1][0,12]*r[I][15][2,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[J,0],p[I,0],p[I,1],p[B,0])]*r[B][1][0,12]*r[I][33][2,0]*r[J][0][12,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9I3J12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,9),(I,3),(J,12)]))
            hv = 0.0
            sket = sign([A,J])
            
            hv += -1/4*g[dei(p[I,0],p[B,0],p[J,0],p[I,1])]*r[B][1][0,12]*r[I][15][3,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[I,1],p[B,0],p[J,0],p[I,0])]*r[B][1][0,12]*r[I][33][3,0]*r[J][0][12,0]
            hv += 1/4*g[dei(p[I,0],p[I,1],p[J,0],p[B,0])]*r[B][1][0,12]*r[I][15][3,0]*r[J][0][12,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[J,0],p[B,0])]*r[B][1][0,12]*r[I][33][3,0]*r[J][0][12,0]
            hv += 1/4*g[dei(p[J,0],p[B,0],p[I,0],p[I,1])]*r[B][1][0,12]*r[I][15][3,0]*r[J][0][12,0]
            hv += 1/2*g[dei(p[J,0],p[B,0],p[I,0],p[I,1])]*r[B][1][0,12]*r[I][30][3,0]*r[J][0][12,0]
            hv += 1/4*g[dei(p[J,0],p[B,0],p[I,1],p[I,0])]*r[B][1][0,12]*r[I][33][3,0]*r[J][0][12,0]
            hv += 1/2*g[dei(p[J,0],p[B,0],p[I,1],p[I,0])]*r[B][1][0,12]*r[I][48][3,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[J,0],p[I,1],p[I,0],p[B,0])]*r[B][1][0,12]*r[I][15][3,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[J,0],p[I,0],p[I,1],p[B,0])]*r[B][1][0,12]*r[I][33][3,0]*r[J][0][12,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9I4J14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,9),(I,4),(J,14)]))
            hv = 0.0
            sket = sign([A,J])
            
            hv += -1/2*g[dei(p[I,0],p[B,0],p[J,0],p[I,1])]*r[B][1][0,12]*r[I][18][4,0]*r[J][2][14,0]
            hv += -1/2*g[dei(p[I,1],p[B,0],p[J,0],p[I,0])]*r[B][1][0,12]*r[I][36][4,0]*r[J][2][14,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9I1J11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,9),(I,1),(J,11)]))
            hv = 0.0
            sket = sign([A,J])
            
            hv += -1/4*g[dei(p[I,0],p[B,0],p[J,1],p[I,0])]*r[B][1][0,12]*r[I][9][1,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[I,1],p[B,0],p[J,1],p[I,1])]*r[B][1][0,12]*r[I][39][1,0]*r[J][4][11,0]
            hv += 1/4*g[dei(p[I,0],p[I,0],p[J,1],p[B,0])]*r[B][1][0,12]*r[I][9][1,0]*r[J][4][11,0]
            hv += 1/4*g[dei(p[I,1],p[I,1],p[J,1],p[B,0])]*r[B][1][0,12]*r[I][39][1,0]*r[J][4][11,0]
            hv += 1/4*g[dei(p[J,1],p[B,0],p[I,0],p[I,0])]*r[B][1][0,12]*r[I][9][1,0]*r[J][4][11,0]
            hv += 1/2*g[dei(p[J,1],p[B,0],p[I,0],p[I,0])]*r[B][1][0,12]*r[I][24][1,0]*r[J][4][11,0]
            hv += 1/4*g[dei(p[J,1],p[B,0],p[I,1],p[I,1])]*r[B][1][0,12]*r[I][39][1,0]*r[J][4][11,0]
            hv += 1/2*g[dei(p[J,1],p[B,0],p[I,1],p[I,1])]*r[B][1][0,12]*r[I][54][1,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[J,1],p[I,0],p[I,0],p[B,0])]*r[B][1][0,12]*r[I][9][1,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[J,1],p[I,1],p[I,1],p[B,0])]*r[B][1][0,12]*r[I][39][1,0]*r[J][4][11,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9I2J11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,9),(I,2),(J,11)]))
            hv = 0.0
            sket = sign([A,J])
            
            hv += -1/4*g[dei(p[I,0],p[B,0],p[J,1],p[I,1])]*r[B][1][0,12]*r[I][15][2,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[I,1],p[B,0],p[J,1],p[I,0])]*r[B][1][0,12]*r[I][33][2,0]*r[J][4][11,0]
            hv += 1/4*g[dei(p[I,0],p[I,1],p[J,1],p[B,0])]*r[B][1][0,12]*r[I][15][2,0]*r[J][4][11,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[J,1],p[B,0])]*r[B][1][0,12]*r[I][33][2,0]*r[J][4][11,0]
            hv += 1/4*g[dei(p[J,1],p[B,0],p[I,0],p[I,1])]*r[B][1][0,12]*r[I][15][2,0]*r[J][4][11,0]
            hv += 1/2*g[dei(p[J,1],p[B,0],p[I,0],p[I,1])]*r[B][1][0,12]*r[I][30][2,0]*r[J][4][11,0]
            hv += 1/4*g[dei(p[J,1],p[B,0],p[I,1],p[I,0])]*r[B][1][0,12]*r[I][33][2,0]*r[J][4][11,0]
            hv += 1/2*g[dei(p[J,1],p[B,0],p[I,1],p[I,0])]*r[B][1][0,12]*r[I][48][2,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[J,1],p[I,1],p[I,0],p[B,0])]*r[B][1][0,12]*r[I][15][2,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[J,1],p[I,0],p[I,1],p[B,0])]*r[B][1][0,12]*r[I][33][2,0]*r[J][4][11,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9I3J11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,9),(I,3),(J,11)]))
            hv = 0.0
            sket = sign([A,J])
            
            hv += -1/4*g[dei(p[I,0],p[B,0],p[J,1],p[I,1])]*r[B][1][0,12]*r[I][15][3,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[I,1],p[B,0],p[J,1],p[I,0])]*r[B][1][0,12]*r[I][33][3,0]*r[J][4][11,0]
            hv += 1/4*g[dei(p[I,0],p[I,1],p[J,1],p[B,0])]*r[B][1][0,12]*r[I][15][3,0]*r[J][4][11,0]
            hv += 1/4*g[dei(p[I,1],p[I,0],p[J,1],p[B,0])]*r[B][1][0,12]*r[I][33][3,0]*r[J][4][11,0]
            hv += 1/4*g[dei(p[J,1],p[B,0],p[I,0],p[I,1])]*r[B][1][0,12]*r[I][15][3,0]*r[J][4][11,0]
            hv += 1/2*g[dei(p[J,1],p[B,0],p[I,0],p[I,1])]*r[B][1][0,12]*r[I][30][3,0]*r[J][4][11,0]
            hv += 1/4*g[dei(p[J,1],p[B,0],p[I,1],p[I,0])]*r[B][1][0,12]*r[I][33][3,0]*r[J][4][11,0]
            hv += 1/2*g[dei(p[J,1],p[B,0],p[I,1],p[I,0])]*r[B][1][0,12]*r[I][48][3,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[J,1],p[I,1],p[I,0],p[B,0])]*r[B][1][0,12]*r[I][15][3,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[J,1],p[I,0],p[I,1],p[B,0])]*r[B][1][0,12]*r[I][33][3,0]*r[J][4][11,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9I4J13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,9),(I,4),(J,13)]))
            hv = 0.0
            sket = sign([A,J])
            
            hv += -1/2*g[dei(p[I,0],p[B,0],p[J,1],p[I,1])]*r[B][1][0,12]*r[I][18][4,0]*r[J][6][13,0]
            hv += -1/2*g[dei(p[I,1],p[B,0],p[J,1],p[I,0])]*r[B][1][0,12]*r[I][36][4,0]*r[J][6][13,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9I12J1(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,9),(I,12),(J,1)]))
            hv = 0.0
            sket = sign([A,I])
            
            hv += 1/4*g[dei(p[I,0],p[B,0],p[J,0],p[J,0])]*r[B][1][0,12]*r[I][0][12,0]*r[J][9][1,0]
            hv += 1/2*g[dei(p[I,0],p[B,0],p[J,0],p[J,0])]*r[B][1][0,12]*r[I][0][12,0]*r[J][24][1,0]
            hv += 1/4*g[dei(p[I,0],p[B,0],p[J,1],p[J,1])]*r[B][1][0,12]*r[I][0][12,0]*r[J][39][1,0]
            hv += 1/2*g[dei(p[I,0],p[B,0],p[J,1],p[J,1])]*r[B][1][0,12]*r[I][0][12,0]*r[J][54][1,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[J,0],p[B,0])]*r[B][1][0,12]*r[I][0][12,0]*r[J][9][1,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[J,1],p[B,0])]*r[B][1][0,12]*r[I][0][12,0]*r[J][39][1,0]
            hv += -1/4*g[dei(p[J,0],p[B,0],p[I,0],p[J,0])]*r[B][1][0,12]*r[I][0][12,0]*r[J][9][1,0]
            hv += -1/4*g[dei(p[J,1],p[B,0],p[I,0],p[J,1])]*r[B][1][0,12]*r[I][0][12,0]*r[J][39][1,0]
            hv += 1/4*g[dei(p[J,0],p[J,0],p[I,0],p[B,0])]*r[B][1][0,12]*r[I][0][12,0]*r[J][9][1,0]
            hv += 1/4*g[dei(p[J,1],p[J,1],p[I,0],p[B,0])]*r[B][1][0,12]*r[I][0][12,0]*r[J][39][1,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9I12J2(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,9),(I,12),(J,2)]))
            hv = 0.0
            sket = sign([A,I])
            
            hv += 1/4*g[dei(p[I,0],p[B,0],p[J,0],p[J,1])]*r[B][1][0,12]*r[I][0][12,0]*r[J][15][2,0]
            hv += 1/2*g[dei(p[I,0],p[B,0],p[J,0],p[J,1])]*r[B][1][0,12]*r[I][0][12,0]*r[J][30][2,0]
            hv += 1/4*g[dei(p[I,0],p[B,0],p[J,1],p[J,0])]*r[B][1][0,12]*r[I][0][12,0]*r[J][33][2,0]
            hv += 1/2*g[dei(p[I,0],p[B,0],p[J,1],p[J,0])]*r[B][1][0,12]*r[I][0][12,0]*r[J][48][2,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[J,0],p[B,0])]*r[B][1][0,12]*r[I][0][12,0]*r[J][15][2,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[J,1],p[B,0])]*r[B][1][0,12]*r[I][0][12,0]*r[J][33][2,0]
            hv += -1/4*g[dei(p[J,0],p[B,0],p[I,0],p[J,1])]*r[B][1][0,12]*r[I][0][12,0]*r[J][15][2,0]
            hv += -1/4*g[dei(p[J,1],p[B,0],p[I,0],p[J,0])]*r[B][1][0,12]*r[I][0][12,0]*r[J][33][2,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[I,0],p[B,0])]*r[B][1][0,12]*r[I][0][12,0]*r[J][15][2,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[I,0],p[B,0])]*r[B][1][0,12]*r[I][0][12,0]*r[J][33][2,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9I12J3(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,9),(I,12),(J,3)]))
            hv = 0.0
            sket = sign([A,I])
            
            hv += 1/4*g[dei(p[I,0],p[B,0],p[J,0],p[J,1])]*r[B][1][0,12]*r[I][0][12,0]*r[J][15][3,0]
            hv += 1/2*g[dei(p[I,0],p[B,0],p[J,0],p[J,1])]*r[B][1][0,12]*r[I][0][12,0]*r[J][30][3,0]
            hv += 1/4*g[dei(p[I,0],p[B,0],p[J,1],p[J,0])]*r[B][1][0,12]*r[I][0][12,0]*r[J][33][3,0]
            hv += 1/2*g[dei(p[I,0],p[B,0],p[J,1],p[J,0])]*r[B][1][0,12]*r[I][0][12,0]*r[J][48][3,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[J,0],p[B,0])]*r[B][1][0,12]*r[I][0][12,0]*r[J][15][3,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[J,1],p[B,0])]*r[B][1][0,12]*r[I][0][12,0]*r[J][33][3,0]
            hv += -1/4*g[dei(p[J,0],p[B,0],p[I,0],p[J,1])]*r[B][1][0,12]*r[I][0][12,0]*r[J][15][3,0]
            hv += -1/4*g[dei(p[J,1],p[B,0],p[I,0],p[J,0])]*r[B][1][0,12]*r[I][0][12,0]*r[J][33][3,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[I,0],p[B,0])]*r[B][1][0,12]*r[I][0][12,0]*r[J][15][3,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[I,0],p[B,0])]*r[B][1][0,12]*r[I][0][12,0]*r[J][33][3,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9I11J1(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,9),(I,11),(J,1)]))
            hv = 0.0
            sket = sign([A,I])
            
            hv += 1/4*g[dei(p[I,1],p[B,0],p[J,0],p[J,0])]*r[B][1][0,12]*r[I][4][11,0]*r[J][9][1,0]
            hv += 1/2*g[dei(p[I,1],p[B,0],p[J,0],p[J,0])]*r[B][1][0,12]*r[I][4][11,0]*r[J][24][1,0]
            hv += 1/4*g[dei(p[I,1],p[B,0],p[J,1],p[J,1])]*r[B][1][0,12]*r[I][4][11,0]*r[J][39][1,0]
            hv += 1/2*g[dei(p[I,1],p[B,0],p[J,1],p[J,1])]*r[B][1][0,12]*r[I][4][11,0]*r[J][54][1,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[J,0],p[B,0])]*r[B][1][0,12]*r[I][4][11,0]*r[J][9][1,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[J,1],p[B,0])]*r[B][1][0,12]*r[I][4][11,0]*r[J][39][1,0]
            hv += -1/4*g[dei(p[J,0],p[B,0],p[I,1],p[J,0])]*r[B][1][0,12]*r[I][4][11,0]*r[J][9][1,0]
            hv += -1/4*g[dei(p[J,1],p[B,0],p[I,1],p[J,1])]*r[B][1][0,12]*r[I][4][11,0]*r[J][39][1,0]
            hv += 1/4*g[dei(p[J,0],p[J,0],p[I,1],p[B,0])]*r[B][1][0,12]*r[I][4][11,0]*r[J][9][1,0]
            hv += 1/4*g[dei(p[J,1],p[J,1],p[I,1],p[B,0])]*r[B][1][0,12]*r[I][4][11,0]*r[J][39][1,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9I11J2(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,9),(I,11),(J,2)]))
            hv = 0.0
            sket = sign([A,I])
            
            hv += 1/4*g[dei(p[I,1],p[B,0],p[J,0],p[J,1])]*r[B][1][0,12]*r[I][4][11,0]*r[J][15][2,0]
            hv += 1/2*g[dei(p[I,1],p[B,0],p[J,0],p[J,1])]*r[B][1][0,12]*r[I][4][11,0]*r[J][30][2,0]
            hv += 1/4*g[dei(p[I,1],p[B,0],p[J,1],p[J,0])]*r[B][1][0,12]*r[I][4][11,0]*r[J][33][2,0]
            hv += 1/2*g[dei(p[I,1],p[B,0],p[J,1],p[J,0])]*r[B][1][0,12]*r[I][4][11,0]*r[J][48][2,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[J,0],p[B,0])]*r[B][1][0,12]*r[I][4][11,0]*r[J][15][2,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[J,1],p[B,0])]*r[B][1][0,12]*r[I][4][11,0]*r[J][33][2,0]
            hv += -1/4*g[dei(p[J,0],p[B,0],p[I,1],p[J,1])]*r[B][1][0,12]*r[I][4][11,0]*r[J][15][2,0]
            hv += -1/4*g[dei(p[J,1],p[B,0],p[I,1],p[J,0])]*r[B][1][0,12]*r[I][4][11,0]*r[J][33][2,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[I,1],p[B,0])]*r[B][1][0,12]*r[I][4][11,0]*r[J][15][2,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[I,1],p[B,0])]*r[B][1][0,12]*r[I][4][11,0]*r[J][33][2,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9I11J3(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,9),(I,11),(J,3)]))
            hv = 0.0
            sket = sign([A,I])
            
            hv += 1/4*g[dei(p[I,1],p[B,0],p[J,0],p[J,1])]*r[B][1][0,12]*r[I][4][11,0]*r[J][15][3,0]
            hv += 1/2*g[dei(p[I,1],p[B,0],p[J,0],p[J,1])]*r[B][1][0,12]*r[I][4][11,0]*r[J][30][3,0]
            hv += 1/4*g[dei(p[I,1],p[B,0],p[J,1],p[J,0])]*r[B][1][0,12]*r[I][4][11,0]*r[J][33][3,0]
            hv += 1/2*g[dei(p[I,1],p[B,0],p[J,1],p[J,0])]*r[B][1][0,12]*r[I][4][11,0]*r[J][48][3,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[J,0],p[B,0])]*r[B][1][0,12]*r[I][4][11,0]*r[J][15][3,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[J,1],p[B,0])]*r[B][1][0,12]*r[I][4][11,0]*r[J][33][3,0]
            hv += -1/4*g[dei(p[J,0],p[B,0],p[I,1],p[J,1])]*r[B][1][0,12]*r[I][4][11,0]*r[J][15][3,0]
            hv += -1/4*g[dei(p[J,1],p[B,0],p[I,1],p[J,0])]*r[B][1][0,12]*r[I][4][11,0]*r[J][33][3,0]
            hv += 1/4*g[dei(p[J,0],p[J,1],p[I,1],p[B,0])]*r[B][1][0,12]*r[I][4][11,0]*r[J][15][3,0]
            hv += 1/4*g[dei(p[J,1],p[J,0],p[I,1],p[B,0])]*r[B][1][0,12]*r[I][4][11,0]*r[J][33][3,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9I14J4(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,9),(I,14),(J,4)]))
            hv = 0.0
            sket = sign([A,I])
            
            hv += -1/2*g[dei(p[J,0],p[B,0],p[I,0],p[J,1])]*r[B][1][0,12]*r[I][2][14,0]*r[J][18][4,0]
            hv += -1/2*g[dei(p[J,1],p[B,0],p[I,0],p[J,0])]*r[B][1][0,12]*r[I][2][14,0]*r[J][36][4,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9I13J4(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,9),(I,13),(J,4)]))
            hv = 0.0
            sket = sign([A,I])
            
            hv += -1/2*g[dei(p[J,0],p[B,0],p[I,1],p[J,1])]*r[B][1][0,12]*r[I][6][13,0]*r[J][18][4,0]
            hv += -1/2*g[dei(p[J,1],p[B,0],p[I,1],p[J,0])]*r[B][1][0,12]*r[I][6][13,0]*r[J][36][4,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9I7J15(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,9),(I,7),(J,15)]))
            hv = 0.0
            sket = sign([A,I])
            
            hv += 1/2*g[dei(p[J,0],p[B,0],p[J,0],p[I,0])]*r[B][1][0,12]*r[I][3][7,0]*r[J][11][15,0]
            hv += 1/2*g[dei(p[J,1],p[B,0],p[J,1],p[I,0])]*r[B][1][0,12]*r[I][3][7,0]*r[J][41][15,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A9I8J15(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,9),(I,8),(J,15)]))
            hv = 0.0
            sket = sign([A,I])
            
            hv += 1/2*g[dei(p[J,0],p[B,0],p[J,0],p[I,1])]*r[B][1][0,12]*r[I][7][8,0]*r[J][11][15,0]
            hv += 1/2*g[dei(p[J,1],p[B,0],p[J,1],p[I,1])]*r[B][1][0,12]*r[I][7][8,0]*r[J][41][15,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11I9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,11),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[B,0],p[A,1],p[I,0])]*r[A][14][11,9]*r[B][1][0,12]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,1],p[B,0],p[A,0],p[I,0])]*r[A][32][11,9]*r[B][1][0,12]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[A,1],p[B,0])]*r[A][14][11,9]*r[B][1][0,12]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[A,0],p[B,0])]*r[A][32][11,9]*r[B][1][0,12]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B1I9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,11),(B,1),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[B,0],p[A,1],p[I,0])]*r[A][14][11,9]*r[B][1][1,12]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,1],p[B,0],p[A,0],p[I,0])]*r[A][32][11,9]*r[B][1][1,12]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[A,1],p[B,0])]*r[A][14][11,9]*r[B][1][1,12]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[A,0],p[B,0])]*r[A][32][11,9]*r[B][1][1,12]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13I7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,13),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,0],p[B,0],p[A,1],p[I,0])]*r[A][17][13,9]*r[B][1][0,12]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B1I7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,13),(B,1),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,0],p[B,0],p[A,1],p[I,0])]*r[A][17][13,9]*r[B][1][1,12]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11I10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,11),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[B,0],p[A,1],p[I,1])]*r[A][14][11,9]*r[B][1][0,12]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,1],p[B,0],p[A,0],p[I,1])]*r[A][32][11,9]*r[B][1][0,12]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[A,1],p[B,0])]*r[A][14][11,9]*r[B][1][0,12]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[A,0],p[B,0])]*r[A][32][11,9]*r[B][1][0,12]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B1I10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,11),(B,1),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[B,0],p[A,1],p[I,1])]*r[A][14][11,9]*r[B][1][1,12]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,1],p[B,0],p[A,0],p[I,1])]*r[A][32][11,9]*r[B][1][1,12]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[A,1],p[B,0])]*r[A][14][11,9]*r[B][1][1,12]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[A,0],p[B,0])]*r[A][32][11,9]*r[B][1][1,12]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13I8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,13),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,0],p[B,0],p[A,1],p[I,1])]*r[A][17][13,9]*r[B][1][0,12]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B1I8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,13),(B,1),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,0],p[B,0],p[A,1],p[I,1])]*r[A][17][13,9]*r[B][1][1,12]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B2I9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,11),(B,2),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[B,1],p[A,1],p[I,0])]*r[A][14][11,9]*r[B][5][2,12]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,1],p[B,1],p[A,0],p[I,0])]*r[A][32][11,9]*r[B][5][2,12]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[A,1],p[B,1])]*r[A][14][11,9]*r[B][5][2,12]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[A,0],p[B,1])]*r[A][32][11,9]*r[B][5][2,12]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B3I9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,11),(B,3),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[B,1],p[A,1],p[I,0])]*r[A][14][11,9]*r[B][5][3,12]*r[I][1][9,0]
        hv += 1/2*g[dei(p[A,1],p[B,1],p[A,0],p[I,0])]*r[A][32][11,9]*r[B][5][3,12]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,0],p[I,0],p[A,1],p[B,1])]*r[A][14][11,9]*r[B][5][3,12]*r[I][1][9,0]
        hv += -1/2*g[dei(p[A,1],p[I,0],p[A,0],p[B,1])]*r[A][32][11,9]*r[B][5][3,12]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B2I7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,13),(B,2),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,0],p[B,1],p[A,1],p[I,0])]*r[A][17][13,9]*r[B][5][2,12]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B3I7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,13),(B,3),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,0],p[B,1],p[A,1],p[I,0])]*r[A][17][13,9]*r[B][5][3,12]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B2I10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,11),(B,2),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[B,1],p[A,1],p[I,1])]*r[A][14][11,9]*r[B][5][2,12]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,1],p[B,1],p[A,0],p[I,1])]*r[A][32][11,9]*r[B][5][2,12]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[A,1],p[B,1])]*r[A][14][11,9]*r[B][5][2,12]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[A,0],p[B,1])]*r[A][32][11,9]*r[B][5][2,12]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A11B3I10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,11),(B,3),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,0],p[B,1],p[A,1],p[I,1])]*r[A][14][11,9]*r[B][5][3,12]*r[I][5][10,0]
        hv += 1/2*g[dei(p[A,1],p[B,1],p[A,0],p[I,1])]*r[A][32][11,9]*r[B][5][3,12]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,0],p[I,1],p[A,1],p[B,1])]*r[A][14][11,9]*r[B][5][3,12]*r[I][5][10,0]
        hv += -1/2*g[dei(p[A,1],p[I,1],p[A,0],p[B,1])]*r[A][32][11,9]*r[B][5][3,12]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B2I8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,13),(B,2),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,0],p[B,1],p[A,1],p[I,1])]*r[A][17][13,9]*r[B][5][2,12]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B3I8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,13),(B,3),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,0],p[B,1],p[A,1],p[I,1])]*r[A][17][13,9]*r[B][5][3,12]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14I7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,14),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,1],p[B,0],p[A,1],p[I,0])]*r[A][41][14,9]*r[B][1][0,12]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B1I7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,14),(B,1),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,1],p[B,0],p[A,1],p[I,0])]*r[A][41][14,9]*r[B][1][1,12]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14I8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,14),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,1],p[B,0],p[A,1],p[I,1])]*r[A][41][14,9]*r[B][1][0,12]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B1I8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,14),(B,1),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,1],p[B,0],p[A,1],p[I,1])]*r[A][41][14,9]*r[B][1][1,12]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B2I7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,14),(B,2),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,1],p[B,1],p[A,1],p[I,0])]*r[A][41][14,9]*r[B][5][2,12]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B3I7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,14),(B,3),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,1],p[B,1],p[A,1],p[I,0])]*r[A][41][14,9]*r[B][5][3,12]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B2I8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,14),(B,2),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,1],p[B,1],p[A,1],p[I,1])]*r[A][41][14,9]*r[B][5][2,12]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B3I8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,14),(B,3),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,1],p[B,1],p[A,1],p[I,1])]*r[A][41][14,9]*r[B][5][3,12]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B4I9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,13),(B,4),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,0],p[I,0],p[A,1],p[B,1])]*r[A][17][13,9]*r[B][7][4,12]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A13B4I10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,13),(B,4),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,0],p[I,1],p[A,1],p[B,1])]*r[A][17][13,9]*r[B][7][4,12]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B4I9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,14),(B,4),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,1],p[I,0],p[A,1],p[B,1])]*r[A][41][14,9]*r[B][7][4,12]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A14B4I10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,14),(B,4),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,1],p[I,1],p[A,1],p[B,1])]*r[A][41][14,9]*r[B][7][4,12]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B15I7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,10),(B,15),(I,7)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[I,0])]*r[A][48][10,9]*r[B][2][15,12]*r[I][3][7,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[B,0],p[A,0])]*r[A][48][10,9]*r[B][2][15,12]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[I,0])]*r[A][48][10,9]*r[B][2][15,12]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[A,1],p[A,0])]*r[A][48][10,9]*r[B][2][15,12]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B15I8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,10),(B,15),(I,8)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1/2*g[dei(p[A,1],p[A,0],p[B,0],p[I,1])]*r[A][48][10,9]*r[B][2][15,12]*r[I][7][8,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[B,0],p[A,0])]*r[A][48][10,9]*r[B][2][15,12]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,0],p[A,0],p[A,1],p[I,1])]*r[A][48][10,9]*r[B][2][15,12]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[A,1],p[A,0])]*r[A][48][10,9]*r[B][2][15,12]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B14I7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(B,14),(I,7)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[A,0],p[B,0],p[B,0],p[I,0])]*r[A][0][0,9]*r[B][21][14,12]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B14I7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,1),(B,14),(I,7)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[A,0],p[B,0],p[B,0],p[I,0])]*r[A][0][1,9]*r[B][21][14,12]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B14I8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(B,14),(I,8)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[A,0],p[B,0],p[B,0],p[I,1])]*r[A][0][0,9]*r[B][21][14,12]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B14I8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,1),(B,14),(I,8)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[A,0],p[B,0],p[B,0],p[I,1])]*r[A][0][1,9]*r[B][21][14,12]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B13I7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(B,13),(I,7)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[A,0],p[B,1],p[B,0],p[I,0])]*r[A][0][0,9]*r[B][27][13,12]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B13I7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,1),(B,13),(I,7)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[A,0],p[B,1],p[B,0],p[I,0])]*r[A][0][1,9]*r[B][27][13,12]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B13I8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(B,13),(I,8)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[A,0],p[B,1],p[B,0],p[I,1])]*r[A][0][0,9]*r[B][27][13,12]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B13I8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,1),(B,13),(I,8)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[A,0],p[B,1],p[B,0],p[I,1])]*r[A][0][1,9]*r[B][27][13,12]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B14I7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,2),(B,14),(I,7)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[A,1],p[B,0],p[B,0],p[I,0])]*r[A][4][2,9]*r[B][21][14,12]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B14I7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,3),(B,14),(I,7)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[A,1],p[B,0],p[B,0],p[I,0])]*r[A][4][3,9]*r[B][21][14,12]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B14I8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,2),(B,14),(I,8)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[A,1],p[B,0],p[B,0],p[I,1])]*r[A][4][2,9]*r[B][21][14,12]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B14I8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,3),(B,14),(I,8)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[A,1],p[B,0],p[B,0],p[I,1])]*r[A][4][3,9]*r[B][21][14,12]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5B11I7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,5),(B,11),(I,7)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[I,0])]*r[A][6][5,9]*r[B][30][11,12]*r[I][3][7,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[B,0],p[B,1])]*r[A][6][5,9]*r[B][30][11,12]*r[I][3][7,0]
        hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[I,0])]*r[A][6][5,9]*r[B][30][11,12]*r[I][3][7,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[A,1],p[B,1])]*r[A][6][5,9]*r[B][30][11,12]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B13I7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,2),(B,13),(I,7)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[A,1],p[B,1],p[B,0],p[I,0])]*r[A][4][2,9]*r[B][27][13,12]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B13I7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,3),(B,13),(I,7)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[A,1],p[B,1],p[B,0],p[I,0])]*r[A][4][3,9]*r[B][27][13,12]*r[I][3][7,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5B11I8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,5),(B,11),(I,8)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1/2*g[dei(p[A,1],p[B,1],p[B,0],p[I,1])]*r[A][6][5,9]*r[B][30][11,12]*r[I][7][8,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[B,0],p[B,1])]*r[A][6][5,9]*r[B][30][11,12]*r[I][7][8,0]
        hv += 1/2*g[dei(p[B,0],p[B,1],p[A,1],p[I,1])]*r[A][6][5,9]*r[B][30][11,12]*r[I][7][8,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[A,1],p[B,1])]*r[A][6][5,9]*r[B][30][11,12]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B13I8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,2),(B,13),(I,8)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[A,1],p[B,1],p[B,0],p[I,1])]*r[A][4][2,9]*r[B][27][13,12]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B13I8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,3),(B,13),(I,8)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[A,1],p[B,1],p[B,0],p[I,1])]*r[A][4][3,9]*r[B][27][13,12]*r[I][7][8,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B15I9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,7),(B,15),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,0],p[I,0],p[B,0],p[A,0])]*r[A][12][7,9]*r[B][2][15,12]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B15I10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,7),(B,15),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,0],p[I,1],p[B,0],p[A,0])]*r[A][12][7,9]*r[B][2][15,12]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B15I9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,8),(B,15),(I,9)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,1],p[I,0],p[B,0],p[A,0])]*r[A][36][8,9]*r[B][2][15,12]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B15I10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,8),(B,15),(I,10)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[A,1],p[I,1],p[B,0],p[A,0])]*r[A][36][8,9]*r[B][2][15,12]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B11I9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(B,11),(I,9)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[A,0],p[I,0],p[B,0],p[B,1])]*r[A][0][0,9]*r[B][30][11,12]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B11I9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,1),(B,11),(I,9)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[A,0],p[I,0],p[B,0],p[B,1])]*r[A][0][1,9]*r[B][30][11,12]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B11I10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(B,11),(I,10)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[A,0],p[I,1],p[B,0],p[B,1])]*r[A][0][0,9]*r[B][30][11,12]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B11I10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,1),(B,11),(I,10)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[A,0],p[I,1],p[B,0],p[B,1])]*r[A][0][1,9]*r[B][30][11,12]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B11I9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,2),(B,11),(I,9)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[A,1],p[I,0],p[B,0],p[B,1])]*r[A][4][2,9]*r[B][30][11,12]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B11I9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,3),(B,11),(I,9)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[A,1],p[I,0],p[B,0],p[B,1])]*r[A][4][3,9]*r[B][30][11,12]*r[I][1][9,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B11I10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,2),(B,11),(I,10)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[A,1],p[I,1],p[B,0],p[B,1])]*r[A][4][2,9]*r[B][30][11,12]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B11I10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,3),(B,11),(I,10)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[A,1],p[I,1],p[B,0],p[B,1])]*r[A][4][3,9]*r[B][30][11,12]*r[I][5][10,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B15I6(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(B,15),(I,6)]))
        hv = 0.0
        
        hv += -1*g[dei(p[A,0],p[I,0],p[B,0],p[I,0])]*r[A][0][0,9]*r[B][2][15,12]*r[I][22][6,0]
        hv += -1*g[dei(p[A,0],p[I,1],p[B,0],p[I,1])]*r[A][0][0,9]*r[B][2][15,12]*r[I][52][6,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B15I6(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,1),(B,15),(I,6)]))
        hv = 0.0
        
        hv += -1*g[dei(p[A,0],p[I,0],p[B,0],p[I,0])]*r[A][0][1,9]*r[B][2][15,12]*r[I][22][6,0]
        hv += -1*g[dei(p[A,0],p[I,1],p[B,0],p[I,1])]*r[A][0][1,9]*r[B][2][15,12]*r[I][52][6,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B15I6(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,2),(B,15),(I,6)]))
        hv = 0.0
        
        hv += -1*g[dei(p[A,1],p[I,0],p[B,0],p[I,0])]*r[A][4][2,9]*r[B][2][15,12]*r[I][22][6,0]
        hv += -1*g[dei(p[A,1],p[I,1],p[B,0],p[I,1])]*r[A][4][2,9]*r[B][2][15,12]*r[I][52][6,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B15I6(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,3),(B,15),(I,6)]))
        hv = 0.0
        
        hv += -1*g[dei(p[A,1],p[I,0],p[B,0],p[I,0])]*r[A][4][3,9]*r[B][2][15,12]*r[I][22][6,0]
        hv += -1*g[dei(p[A,1],p[I,1],p[B,0],p[I,1])]*r[A][4][3,9]*r[B][2][15,12]*r[I][52][6,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B4I14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,10),(B,4),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,0],p[B,1])]*r[A][48][10,9]*r[B][7][4,12]*r[I][2][14,0]
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,0],p[A,0])]*r[A][48][10,9]*r[B][7][4,12]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[A,1],p[B,1])]*r[A][48][10,9]*r[B][7][4,12]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[A,1],p[A,0])]*r[A][48][10,9]*r[B][7][4,12]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B4I13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,10),(B,4),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += 1/2*g[dei(p[A,1],p[A,0],p[I,1],p[B,1])]*r[A][48][10,9]*r[B][7][4,12]*r[I][6][13,0]
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,1],p[A,0])]*r[A][48][10,9]*r[B][7][4,12]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[A,1],p[B,1])]*r[A][48][10,9]*r[B][7][4,12]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[A,1],p[A,0])]*r[A][48][10,9]*r[B][7][4,12]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7I14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,7),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,0],p[B,0],p[I,0],p[A,0])]*r[A][12][7,9]*r[B][1][0,12]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B1I14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,7),(B,1),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,0],p[B,0],p[I,0],p[A,0])]*r[A][12][7,9]*r[B][1][1,12]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B2I14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,7),(B,2),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,0],p[B,1],p[I,0],p[A,0])]*r[A][12][7,9]*r[B][5][2,12]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B3I14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,7),(B,3),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,0],p[B,1],p[I,0],p[A,0])]*r[A][12][7,9]*r[B][5][3,12]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7I13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,7),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,0],p[B,0],p[I,1],p[A,0])]*r[A][12][7,9]*r[B][1][0,12]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B1I13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,7),(B,1),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,0],p[B,0],p[I,1],p[A,0])]*r[A][12][7,9]*r[B][1][1,12]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B2I13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,7),(B,2),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,0],p[B,1],p[I,1],p[A,0])]*r[A][12][7,9]*r[B][5][2,12]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A7B3I13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,7),(B,3),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,0],p[B,1],p[I,1],p[A,0])]*r[A][12][7,9]*r[B][5][3,12]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8I14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,8),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,1],p[B,0],p[I,0],p[A,0])]*r[A][36][8,9]*r[B][1][0,12]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B1I14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,8),(B,1),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,1],p[B,0],p[I,0],p[A,0])]*r[A][36][8,9]*r[B][1][1,12]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B2I14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,8),(B,2),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,1],p[B,1],p[I,0],p[A,0])]*r[A][36][8,9]*r[B][5][2,12]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B3I14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,8),(B,3),(I,14)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,1],p[B,1],p[I,0],p[A,0])]*r[A][36][8,9]*r[B][5][3,12]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8I13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,8),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,1],p[B,0],p[I,1],p[A,0])]*r[A][36][8,9]*r[B][1][0,12]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B1I13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,8),(B,1),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,1],p[B,0],p[I,1],p[A,0])]*r[A][36][8,9]*r[B][1][1,12]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B2I13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,8),(B,2),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,1],p[B,1],p[I,1],p[A,0])]*r[A][36][8,9]*r[B][5][2,12]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A8B3I13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,8),(B,3),(I,13)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += -1*g[dei(p[A,1],p[B,1],p[I,1],p[A,0])]*r[A][36][8,9]*r[B][5][3,12]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B10I12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(B,10),(I,12)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[B,0],p[I,0],p[B,1])]*r[A][0][0,9]*r[B][34][10,12]*r[I][0][12,0]
        hv += 1/2*g[dei(p[A,0],p[B,1],p[I,0],p[B,0])]*r[A][0][0,9]*r[B][16][10,12]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[B,0],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][34][10,12]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[B,1],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][16][10,12]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B10I12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,1),(B,10),(I,12)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[B,0],p[I,0],p[B,1])]*r[A][0][1,9]*r[B][34][10,12]*r[I][0][12,0]
        hv += 1/2*g[dei(p[A,0],p[B,1],p[I,0],p[B,0])]*r[A][0][1,9]*r[B][16][10,12]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[B,0],p[A,0],p[B,1])]*r[A][0][1,9]*r[B][34][10,12]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[B,1],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][16][10,12]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B8I14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(B,8),(I,14)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[A,0],p[B,0],p[I,0],p[B,1])]*r[A][0][0,9]*r[B][46][8,12]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B8I14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,1),(B,8),(I,14)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[A,0],p[B,0],p[I,0],p[B,1])]*r[A][0][1,9]*r[B][46][8,12]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B7I14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(B,7),(I,14)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[A,0],p[B,1],p[I,0],p[B,1])]*r[A][0][0,9]*r[B][52][7,12]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B7I14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,1),(B,7),(I,14)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[A,0],p[B,1],p[I,0],p[B,1])]*r[A][0][1,9]*r[B][52][7,12]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B10I11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(B,10),(I,11)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[B,0],p[I,1],p[B,1])]*r[A][0][0,9]*r[B][34][10,12]*r[I][4][11,0]
        hv += 1/2*g[dei(p[A,0],p[B,1],p[I,1],p[B,0])]*r[A][0][0,9]*r[B][16][10,12]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[B,0],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][34][10,12]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[B,1],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][16][10,12]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B10I11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,1),(B,10),(I,11)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,0],p[B,0],p[I,1],p[B,1])]*r[A][0][1,9]*r[B][34][10,12]*r[I][4][11,0]
        hv += 1/2*g[dei(p[A,0],p[B,1],p[I,1],p[B,0])]*r[A][0][1,9]*r[B][16][10,12]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[B,0],p[A,0],p[B,1])]*r[A][0][1,9]*r[B][34][10,12]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[B,1],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][16][10,12]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B8I13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(B,8),(I,13)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[A,0],p[B,0],p[I,1],p[B,1])]*r[A][0][0,9]*r[B][46][8,12]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B8I13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,1),(B,8),(I,13)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[A,0],p[B,0],p[I,1],p[B,1])]*r[A][0][1,9]*r[B][46][8,12]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B7I13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(B,7),(I,13)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[A,0],p[B,1],p[I,1],p[B,1])]*r[A][0][0,9]*r[B][52][7,12]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B7I13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,1),(B,7),(I,13)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[A,0],p[B,1],p[I,1],p[B,1])]*r[A][0][1,9]*r[B][52][7,12]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B10I12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,2),(B,10),(I,12)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,1],p[B,0],p[I,0],p[B,1])]*r[A][4][2,9]*r[B][34][10,12]*r[I][0][12,0]
        hv += 1/2*g[dei(p[A,1],p[B,1],p[I,0],p[B,0])]*r[A][4][2,9]*r[B][16][10,12]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[B,0],p[A,1],p[B,1])]*r[A][4][2,9]*r[B][34][10,12]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[B,1],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][16][10,12]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B10I12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,3),(B,10),(I,12)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,1],p[B,0],p[I,0],p[B,1])]*r[A][4][3,9]*r[B][34][10,12]*r[I][0][12,0]
        hv += 1/2*g[dei(p[A,1],p[B,1],p[I,0],p[B,0])]*r[A][4][3,9]*r[B][16][10,12]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[B,0],p[A,1],p[B,1])]*r[A][4][3,9]*r[B][34][10,12]*r[I][0][12,0]
        hv += -1/2*g[dei(p[I,0],p[B,1],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][16][10,12]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B8I14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,2),(B,8),(I,14)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[A,1],p[B,0],p[I,0],p[B,1])]*r[A][4][2,9]*r[B][46][8,12]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B8I14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,3),(B,8),(I,14)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[A,1],p[B,0],p[I,0],p[B,1])]*r[A][4][3,9]*r[B][46][8,12]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B7I14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,2),(B,7),(I,14)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[A,1],p[B,1],p[I,0],p[B,1])]*r[A][4][2,9]*r[B][52][7,12]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B7I14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,3),(B,7),(I,14)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[A,1],p[B,1],p[I,0],p[B,1])]*r[A][4][3,9]*r[B][52][7,12]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B10I11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,2),(B,10),(I,11)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,1],p[B,0],p[I,1],p[B,1])]*r[A][4][2,9]*r[B][34][10,12]*r[I][4][11,0]
        hv += 1/2*g[dei(p[A,1],p[B,1],p[I,1],p[B,0])]*r[A][4][2,9]*r[B][16][10,12]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[B,0],p[A,1],p[B,1])]*r[A][4][2,9]*r[B][34][10,12]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[B,1],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][16][10,12]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B10I11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,3),(B,10),(I,11)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[A,1],p[B,0],p[I,1],p[B,1])]*r[A][4][3,9]*r[B][34][10,12]*r[I][4][11,0]
        hv += 1/2*g[dei(p[A,1],p[B,1],p[I,1],p[B,0])]*r[A][4][3,9]*r[B][16][10,12]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[B,0],p[A,1],p[B,1])]*r[A][4][3,9]*r[B][34][10,12]*r[I][4][11,0]
        hv += -1/2*g[dei(p[I,1],p[B,1],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][16][10,12]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B8I13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,2),(B,8),(I,13)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[A,1],p[B,0],p[I,1],p[B,1])]*r[A][4][2,9]*r[B][46][8,12]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B8I13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,3),(B,8),(I,13)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[A,1],p[B,0],p[I,1],p[B,1])]*r[A][4][3,9]*r[B][46][8,12]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B7I13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,2),(B,7),(I,13)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[A,1],p[B,1],p[I,1],p[B,1])]*r[A][4][2,9]*r[B][52][7,12]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B7I13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,3),(B,7),(I,13)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[A,1],p[B,1],p[I,1],p[B,1])]*r[A][4][3,9]*r[B][52][7,12]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _I1(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(I,1)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,0],p[B,0],p[I,0],p[I,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][9][1,0]
        hv += -1*g[dei(p[A,0],p[B,0],p[I,0],p[I,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][24][1,0]
        hv += -1/2*g[dei(p[A,0],p[B,0],p[I,1],p[I,1])]*r[A][0][0,9]*r[B][1][0,12]*r[I][39][1,0]
        hv += -1*g[dei(p[A,0],p[B,0],p[I,1],p[I,1])]*r[A][0][0,9]*r[B][1][0,12]*r[I][54][1,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[I,0],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[I,1],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[A,0],p[I,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[A,0],p[I,1])]*r[A][0][0,9]*r[B][1][0,12]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1I1(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(B,1),(I,1)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,0],p[B,0],p[I,0],p[I,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][9][1,0]
        hv += -1*g[dei(p[A,0],p[B,0],p[I,0],p[I,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][24][1,0]
        hv += -1/2*g[dei(p[A,0],p[B,0],p[I,1],p[I,1])]*r[A][0][0,9]*r[B][1][1,12]*r[I][39][1,0]
        hv += -1*g[dei(p[A,0],p[B,0],p[I,1],p[I,1])]*r[A][0][0,9]*r[B][1][1,12]*r[I][54][1,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[I,0],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[I,1],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[A,0],p[I,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[A,0],p[I,1])]*r[A][0][0,9]*r[B][1][1,12]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I1(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,1),(I,1)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,0],p[B,0],p[I,0],p[I,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][9][1,0]
        hv += -1*g[dei(p[A,0],p[B,0],p[I,0],p[I,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][24][1,0]
        hv += -1/2*g[dei(p[A,0],p[B,0],p[I,1],p[I,1])]*r[A][0][1,9]*r[B][1][0,12]*r[I][39][1,0]
        hv += -1*g[dei(p[A,0],p[B,0],p[I,1],p[I,1])]*r[A][0][1,9]*r[B][1][0,12]*r[I][54][1,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[I,0],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[I,1],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[A,0],p[I,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[A,0],p[I,1])]*r[A][0][1,9]*r[B][1][0,12]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B1I1(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,1),(B,1),(I,1)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,0],p[B,0],p[I,0],p[I,0])]*r[A][0][1,9]*r[B][1][1,12]*r[I][9][1,0]
        hv += -1*g[dei(p[A,0],p[B,0],p[I,0],p[I,0])]*r[A][0][1,9]*r[B][1][1,12]*r[I][24][1,0]
        hv += -1/2*g[dei(p[A,0],p[B,0],p[I,1],p[I,1])]*r[A][0][1,9]*r[B][1][1,12]*r[I][39][1,0]
        hv += -1*g[dei(p[A,0],p[B,0],p[I,1],p[I,1])]*r[A][0][1,9]*r[B][1][1,12]*r[I][54][1,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[I,0],p[B,0])]*r[A][0][1,9]*r[B][1][1,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[I,1],p[B,0])]*r[A][0][1,9]*r[B][1][1,12]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[A,0],p[I,0])]*r[A][0][1,9]*r[B][1][1,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[A,0],p[I,1])]*r[A][0][1,9]*r[B][1][1,12]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][1][1,12]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][1][1,12]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _I2(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(I,2)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,0],p[B,0],p[I,0],p[I,1])]*r[A][0][0,9]*r[B][1][0,12]*r[I][15][2,0]
        hv += -1*g[dei(p[A,0],p[B,0],p[I,0],p[I,1])]*r[A][0][0,9]*r[B][1][0,12]*r[I][30][2,0]
        hv += -1/2*g[dei(p[A,0],p[B,0],p[I,1],p[I,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][33][2,0]
        hv += -1*g[dei(p[A,0],p[B,0],p[I,1],p[I,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][48][2,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[I,0],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[I,1],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[A,0],p[I,1])]*r[A][0][0,9]*r[B][1][0,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[A,0],p[I,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _I3(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(I,3)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,0],p[B,0],p[I,0],p[I,1])]*r[A][0][0,9]*r[B][1][0,12]*r[I][15][3,0]
        hv += -1*g[dei(p[A,0],p[B,0],p[I,0],p[I,1])]*r[A][0][0,9]*r[B][1][0,12]*r[I][30][3,0]
        hv += -1/2*g[dei(p[A,0],p[B,0],p[I,1],p[I,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][33][3,0]
        hv += -1*g[dei(p[A,0],p[B,0],p[I,1],p[I,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][48][3,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[I,0],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[I,1],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[A,0],p[I,1])]*r[A][0][0,9]*r[B][1][0,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[A,0],p[I,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1I2(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(B,1),(I,2)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,0],p[B,0],p[I,0],p[I,1])]*r[A][0][0,9]*r[B][1][1,12]*r[I][15][2,0]
        hv += -1*g[dei(p[A,0],p[B,0],p[I,0],p[I,1])]*r[A][0][0,9]*r[B][1][1,12]*r[I][30][2,0]
        hv += -1/2*g[dei(p[A,0],p[B,0],p[I,1],p[I,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][33][2,0]
        hv += -1*g[dei(p[A,0],p[B,0],p[I,1],p[I,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][48][2,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[I,0],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[I,1],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[A,0],p[I,1])]*r[A][0][0,9]*r[B][1][1,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[A,0],p[I,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1I3(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(B,1),(I,3)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,0],p[B,0],p[I,0],p[I,1])]*r[A][0][0,9]*r[B][1][1,12]*r[I][15][3,0]
        hv += -1*g[dei(p[A,0],p[B,0],p[I,0],p[I,1])]*r[A][0][0,9]*r[B][1][1,12]*r[I][30][3,0]
        hv += -1/2*g[dei(p[A,0],p[B,0],p[I,1],p[I,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][33][3,0]
        hv += -1*g[dei(p[A,0],p[B,0],p[I,1],p[I,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][48][3,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[I,0],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[I,1],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[A,0],p[I,1])]*r[A][0][0,9]*r[B][1][1,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[A,0],p[I,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I2(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,1),(I,2)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,0],p[B,0],p[I,0],p[I,1])]*r[A][0][1,9]*r[B][1][0,12]*r[I][15][2,0]
        hv += -1*g[dei(p[A,0],p[B,0],p[I,0],p[I,1])]*r[A][0][1,9]*r[B][1][0,12]*r[I][30][2,0]
        hv += -1/2*g[dei(p[A,0],p[B,0],p[I,1],p[I,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][33][2,0]
        hv += -1*g[dei(p[A,0],p[B,0],p[I,1],p[I,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][48][2,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[I,0],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[I,1],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[A,0],p[I,1])]*r[A][0][1,9]*r[B][1][0,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[A,0],p[I,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I3(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,1),(I,3)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,0],p[B,0],p[I,0],p[I,1])]*r[A][0][1,9]*r[B][1][0,12]*r[I][15][3,0]
        hv += -1*g[dei(p[A,0],p[B,0],p[I,0],p[I,1])]*r[A][0][1,9]*r[B][1][0,12]*r[I][30][3,0]
        hv += -1/2*g[dei(p[A,0],p[B,0],p[I,1],p[I,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][33][3,0]
        hv += -1*g[dei(p[A,0],p[B,0],p[I,1],p[I,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][48][3,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[I,0],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[I,1],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[A,0],p[I,1])]*r[A][0][1,9]*r[B][1][0,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[A,0],p[I,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B1I2(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,1),(B,1),(I,2)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,0],p[B,0],p[I,0],p[I,1])]*r[A][0][1,9]*r[B][1][1,12]*r[I][15][2,0]
        hv += -1*g[dei(p[A,0],p[B,0],p[I,0],p[I,1])]*r[A][0][1,9]*r[B][1][1,12]*r[I][30][2,0]
        hv += -1/2*g[dei(p[A,0],p[B,0],p[I,1],p[I,0])]*r[A][0][1,9]*r[B][1][1,12]*r[I][33][2,0]
        hv += -1*g[dei(p[A,0],p[B,0],p[I,1],p[I,0])]*r[A][0][1,9]*r[B][1][1,12]*r[I][48][2,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[I,0],p[B,0])]*r[A][0][1,9]*r[B][1][1,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[I,1],p[B,0])]*r[A][0][1,9]*r[B][1][1,12]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[A,0],p[I,1])]*r[A][0][1,9]*r[B][1][1,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[A,0],p[I,0])]*r[A][0][1,9]*r[B][1][1,12]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][1][1,12]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][1][1,12]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B1I3(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,1),(B,1),(I,3)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,0],p[B,0],p[I,0],p[I,1])]*r[A][0][1,9]*r[B][1][1,12]*r[I][15][3,0]
        hv += -1*g[dei(p[A,0],p[B,0],p[I,0],p[I,1])]*r[A][0][1,9]*r[B][1][1,12]*r[I][30][3,0]
        hv += -1/2*g[dei(p[A,0],p[B,0],p[I,1],p[I,0])]*r[A][0][1,9]*r[B][1][1,12]*r[I][33][3,0]
        hv += -1*g[dei(p[A,0],p[B,0],p[I,1],p[I,0])]*r[A][0][1,9]*r[B][1][1,12]*r[I][48][3,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[I,0],p[B,0])]*r[A][0][1,9]*r[B][1][1,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[I,1],p[B,0])]*r[A][0][1,9]*r[B][1][1,12]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[A,0],p[I,1])]*r[A][0][1,9]*r[B][1][1,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[A,0],p[I,0])]*r[A][0][1,9]*r[B][1][1,12]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][1][1,12]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][1][1,12]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2I1(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(B,2),(I,1)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,0],p[B,1],p[I,0],p[I,0])]*r[A][0][0,9]*r[B][5][2,12]*r[I][9][1,0]
        hv += -1*g[dei(p[A,0],p[B,1],p[I,0],p[I,0])]*r[A][0][0,9]*r[B][5][2,12]*r[I][24][1,0]
        hv += -1/2*g[dei(p[A,0],p[B,1],p[I,1],p[I,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][39][1,0]
        hv += -1*g[dei(p[A,0],p[B,1],p[I,1],p[I,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][54][1,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[I,0],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[I,1],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[A,0],p[I,0])]*r[A][0][0,9]*r[B][5][2,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[A,0],p[I,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3I1(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(B,3),(I,1)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,0],p[B,1],p[I,0],p[I,0])]*r[A][0][0,9]*r[B][5][3,12]*r[I][9][1,0]
        hv += -1*g[dei(p[A,0],p[B,1],p[I,0],p[I,0])]*r[A][0][0,9]*r[B][5][3,12]*r[I][24][1,0]
        hv += -1/2*g[dei(p[A,0],p[B,1],p[I,1],p[I,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][39][1,0]
        hv += -1*g[dei(p[A,0],p[B,1],p[I,1],p[I,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][54][1,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[I,0],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[I,1],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[A,0],p[I,0])]*r[A][0][0,9]*r[B][5][3,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[A,0],p[I,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B2I1(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,1),(B,2),(I,1)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,0],p[B,1],p[I,0],p[I,0])]*r[A][0][1,9]*r[B][5][2,12]*r[I][9][1,0]
        hv += -1*g[dei(p[A,0],p[B,1],p[I,0],p[I,0])]*r[A][0][1,9]*r[B][5][2,12]*r[I][24][1,0]
        hv += -1/2*g[dei(p[A,0],p[B,1],p[I,1],p[I,1])]*r[A][0][1,9]*r[B][5][2,12]*r[I][39][1,0]
        hv += -1*g[dei(p[A,0],p[B,1],p[I,1],p[I,1])]*r[A][0][1,9]*r[B][5][2,12]*r[I][54][1,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[I,0],p[B,1])]*r[A][0][1,9]*r[B][5][2,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[I,1],p[B,1])]*r[A][0][1,9]*r[B][5][2,12]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[A,0],p[I,0])]*r[A][0][1,9]*r[B][5][2,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[A,0],p[I,1])]*r[A][0][1,9]*r[B][5][2,12]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[A,0],p[B,1])]*r[A][0][1,9]*r[B][5][2,12]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[A,0],p[B,1])]*r[A][0][1,9]*r[B][5][2,12]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B3I1(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,1),(B,3),(I,1)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,0],p[B,1],p[I,0],p[I,0])]*r[A][0][1,9]*r[B][5][3,12]*r[I][9][1,0]
        hv += -1*g[dei(p[A,0],p[B,1],p[I,0],p[I,0])]*r[A][0][1,9]*r[B][5][3,12]*r[I][24][1,0]
        hv += -1/2*g[dei(p[A,0],p[B,1],p[I,1],p[I,1])]*r[A][0][1,9]*r[B][5][3,12]*r[I][39][1,0]
        hv += -1*g[dei(p[A,0],p[B,1],p[I,1],p[I,1])]*r[A][0][1,9]*r[B][5][3,12]*r[I][54][1,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[I,0],p[B,1])]*r[A][0][1,9]*r[B][5][3,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[I,1],p[B,1])]*r[A][0][1,9]*r[B][5][3,12]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[A,0],p[I,0])]*r[A][0][1,9]*r[B][5][3,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[A,0],p[I,1])]*r[A][0][1,9]*r[B][5][3,12]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[A,0],p[B,1])]*r[A][0][1,9]*r[B][5][3,12]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[A,0],p[B,1])]*r[A][0][1,9]*r[B][5][3,12]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2I2(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(B,2),(I,2)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,0],p[B,1],p[I,0],p[I,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][15][2,0]
        hv += -1*g[dei(p[A,0],p[B,1],p[I,0],p[I,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][30][2,0]
        hv += -1/2*g[dei(p[A,0],p[B,1],p[I,1],p[I,0])]*r[A][0][0,9]*r[B][5][2,12]*r[I][33][2,0]
        hv += -1*g[dei(p[A,0],p[B,1],p[I,1],p[I,0])]*r[A][0][0,9]*r[B][5][2,12]*r[I][48][2,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[I,0],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[I,1],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[A,0],p[I,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[A,0],p[I,0])]*r[A][0][0,9]*r[B][5][2,12]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2I3(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(B,2),(I,3)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,0],p[B,1],p[I,0],p[I,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][15][3,0]
        hv += -1*g[dei(p[A,0],p[B,1],p[I,0],p[I,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][30][3,0]
        hv += -1/2*g[dei(p[A,0],p[B,1],p[I,1],p[I,0])]*r[A][0][0,9]*r[B][5][2,12]*r[I][33][3,0]
        hv += -1*g[dei(p[A,0],p[B,1],p[I,1],p[I,0])]*r[A][0][0,9]*r[B][5][2,12]*r[I][48][3,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[I,0],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[I,1],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[A,0],p[I,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[A,0],p[I,0])]*r[A][0][0,9]*r[B][5][2,12]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3I2(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(B,3),(I,2)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,0],p[B,1],p[I,0],p[I,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][15][2,0]
        hv += -1*g[dei(p[A,0],p[B,1],p[I,0],p[I,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][30][2,0]
        hv += -1/2*g[dei(p[A,0],p[B,1],p[I,1],p[I,0])]*r[A][0][0,9]*r[B][5][3,12]*r[I][33][2,0]
        hv += -1*g[dei(p[A,0],p[B,1],p[I,1],p[I,0])]*r[A][0][0,9]*r[B][5][3,12]*r[I][48][2,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[I,0],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[I,1],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[A,0],p[I,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[A,0],p[I,0])]*r[A][0][0,9]*r[B][5][3,12]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3I3(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(B,3),(I,3)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,0],p[B,1],p[I,0],p[I,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][15][3,0]
        hv += -1*g[dei(p[A,0],p[B,1],p[I,0],p[I,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][30][3,0]
        hv += -1/2*g[dei(p[A,0],p[B,1],p[I,1],p[I,0])]*r[A][0][0,9]*r[B][5][3,12]*r[I][33][3,0]
        hv += -1*g[dei(p[A,0],p[B,1],p[I,1],p[I,0])]*r[A][0][0,9]*r[B][5][3,12]*r[I][48][3,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[I,0],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[I,1],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[A,0],p[I,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[A,0],p[I,0])]*r[A][0][0,9]*r[B][5][3,12]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B2I2(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,1),(B,2),(I,2)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,0],p[B,1],p[I,0],p[I,1])]*r[A][0][1,9]*r[B][5][2,12]*r[I][15][2,0]
        hv += -1*g[dei(p[A,0],p[B,1],p[I,0],p[I,1])]*r[A][0][1,9]*r[B][5][2,12]*r[I][30][2,0]
        hv += -1/2*g[dei(p[A,0],p[B,1],p[I,1],p[I,0])]*r[A][0][1,9]*r[B][5][2,12]*r[I][33][2,0]
        hv += -1*g[dei(p[A,0],p[B,1],p[I,1],p[I,0])]*r[A][0][1,9]*r[B][5][2,12]*r[I][48][2,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[I,0],p[B,1])]*r[A][0][1,9]*r[B][5][2,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[I,1],p[B,1])]*r[A][0][1,9]*r[B][5][2,12]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[A,0],p[I,1])]*r[A][0][1,9]*r[B][5][2,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[A,0],p[I,0])]*r[A][0][1,9]*r[B][5][2,12]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,0],p[B,1])]*r[A][0][1,9]*r[B][5][2,12]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,0],p[B,1])]*r[A][0][1,9]*r[B][5][2,12]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B2I3(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,1),(B,2),(I,3)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,0],p[B,1],p[I,0],p[I,1])]*r[A][0][1,9]*r[B][5][2,12]*r[I][15][3,0]
        hv += -1*g[dei(p[A,0],p[B,1],p[I,0],p[I,1])]*r[A][0][1,9]*r[B][5][2,12]*r[I][30][3,0]
        hv += -1/2*g[dei(p[A,0],p[B,1],p[I,1],p[I,0])]*r[A][0][1,9]*r[B][5][2,12]*r[I][33][3,0]
        hv += -1*g[dei(p[A,0],p[B,1],p[I,1],p[I,0])]*r[A][0][1,9]*r[B][5][2,12]*r[I][48][3,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[I,0],p[B,1])]*r[A][0][1,9]*r[B][5][2,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[I,1],p[B,1])]*r[A][0][1,9]*r[B][5][2,12]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[A,0],p[I,1])]*r[A][0][1,9]*r[B][5][2,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[A,0],p[I,0])]*r[A][0][1,9]*r[B][5][2,12]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,0],p[B,1])]*r[A][0][1,9]*r[B][5][2,12]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,0],p[B,1])]*r[A][0][1,9]*r[B][5][2,12]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B3I2(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,1),(B,3),(I,2)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,0],p[B,1],p[I,0],p[I,1])]*r[A][0][1,9]*r[B][5][3,12]*r[I][15][2,0]
        hv += -1*g[dei(p[A,0],p[B,1],p[I,0],p[I,1])]*r[A][0][1,9]*r[B][5][3,12]*r[I][30][2,0]
        hv += -1/2*g[dei(p[A,0],p[B,1],p[I,1],p[I,0])]*r[A][0][1,9]*r[B][5][3,12]*r[I][33][2,0]
        hv += -1*g[dei(p[A,0],p[B,1],p[I,1],p[I,0])]*r[A][0][1,9]*r[B][5][3,12]*r[I][48][2,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[I,0],p[B,1])]*r[A][0][1,9]*r[B][5][3,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[I,1],p[B,1])]*r[A][0][1,9]*r[B][5][3,12]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[A,0],p[I,1])]*r[A][0][1,9]*r[B][5][3,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[A,0],p[I,0])]*r[A][0][1,9]*r[B][5][3,12]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,0],p[B,1])]*r[A][0][1,9]*r[B][5][3,12]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,0],p[B,1])]*r[A][0][1,9]*r[B][5][3,12]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B3I3(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,1),(B,3),(I,3)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,0],p[B,1],p[I,0],p[I,1])]*r[A][0][1,9]*r[B][5][3,12]*r[I][15][3,0]
        hv += -1*g[dei(p[A,0],p[B,1],p[I,0],p[I,1])]*r[A][0][1,9]*r[B][5][3,12]*r[I][30][3,0]
        hv += -1/2*g[dei(p[A,0],p[B,1],p[I,1],p[I,0])]*r[A][0][1,9]*r[B][5][3,12]*r[I][33][3,0]
        hv += -1*g[dei(p[A,0],p[B,1],p[I,1],p[I,0])]*r[A][0][1,9]*r[B][5][3,12]*r[I][48][3,0]
        hv += 1/2*g[dei(p[A,0],p[I,1],p[I,0],p[B,1])]*r[A][0][1,9]*r[B][5][3,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[A,0],p[I,0],p[I,1],p[B,1])]*r[A][0][1,9]*r[B][5][3,12]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[A,0],p[I,1])]*r[A][0][1,9]*r[B][5][3,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[A,0],p[I,0])]*r[A][0][1,9]*r[B][5][3,12]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,0],p[B,1])]*r[A][0][1,9]*r[B][5][3,12]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,0],p[B,1])]*r[A][0][1,9]*r[B][5][3,12]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2I1(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,2),(I,1)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,1],p[B,0],p[I,0],p[I,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][9][1,0]
        hv += -1*g[dei(p[A,1],p[B,0],p[I,0],p[I,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][24][1,0]
        hv += -1/2*g[dei(p[A,1],p[B,0],p[I,1],p[I,1])]*r[A][4][2,9]*r[B][1][0,12]*r[I][39][1,0]
        hv += -1*g[dei(p[A,1],p[B,0],p[I,1],p[I,1])]*r[A][4][2,9]*r[B][1][0,12]*r[I][54][1,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,0],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,1],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[A,1],p[I,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[A,1],p[I,1])]*r[A][4][2,9]*r[B][1][0,12]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B1I1(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,2),(B,1),(I,1)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,1],p[B,0],p[I,0],p[I,0])]*r[A][4][2,9]*r[B][1][1,12]*r[I][9][1,0]
        hv += -1*g[dei(p[A,1],p[B,0],p[I,0],p[I,0])]*r[A][4][2,9]*r[B][1][1,12]*r[I][24][1,0]
        hv += -1/2*g[dei(p[A,1],p[B,0],p[I,1],p[I,1])]*r[A][4][2,9]*r[B][1][1,12]*r[I][39][1,0]
        hv += -1*g[dei(p[A,1],p[B,0],p[I,1],p[I,1])]*r[A][4][2,9]*r[B][1][1,12]*r[I][54][1,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,0],p[B,0])]*r[A][4][2,9]*r[B][1][1,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,1],p[B,0])]*r[A][4][2,9]*r[B][1][1,12]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[A,1],p[I,0])]*r[A][4][2,9]*r[B][1][1,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[A,1],p[I,1])]*r[A][4][2,9]*r[B][1][1,12]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][1][1,12]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][1][1,12]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I1(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,3),(I,1)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,1],p[B,0],p[I,0],p[I,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][9][1,0]
        hv += -1*g[dei(p[A,1],p[B,0],p[I,0],p[I,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][24][1,0]
        hv += -1/2*g[dei(p[A,1],p[B,0],p[I,1],p[I,1])]*r[A][4][3,9]*r[B][1][0,12]*r[I][39][1,0]
        hv += -1*g[dei(p[A,1],p[B,0],p[I,1],p[I,1])]*r[A][4][3,9]*r[B][1][0,12]*r[I][54][1,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,0],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,1],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[A,1],p[I,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[A,1],p[I,1])]*r[A][4][3,9]*r[B][1][0,12]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B1I1(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,3),(B,1),(I,1)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,1],p[B,0],p[I,0],p[I,0])]*r[A][4][3,9]*r[B][1][1,12]*r[I][9][1,0]
        hv += -1*g[dei(p[A,1],p[B,0],p[I,0],p[I,0])]*r[A][4][3,9]*r[B][1][1,12]*r[I][24][1,0]
        hv += -1/2*g[dei(p[A,1],p[B,0],p[I,1],p[I,1])]*r[A][4][3,9]*r[B][1][1,12]*r[I][39][1,0]
        hv += -1*g[dei(p[A,1],p[B,0],p[I,1],p[I,1])]*r[A][4][3,9]*r[B][1][1,12]*r[I][54][1,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,0],p[B,0])]*r[A][4][3,9]*r[B][1][1,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,1],p[B,0])]*r[A][4][3,9]*r[B][1][1,12]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[A,1],p[I,0])]*r[A][4][3,9]*r[B][1][1,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[A,1],p[I,1])]*r[A][4][3,9]*r[B][1][1,12]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][1][1,12]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][1][1,12]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2I2(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,2),(I,2)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,1],p[B,0],p[I,0],p[I,1])]*r[A][4][2,9]*r[B][1][0,12]*r[I][15][2,0]
        hv += -1*g[dei(p[A,1],p[B,0],p[I,0],p[I,1])]*r[A][4][2,9]*r[B][1][0,12]*r[I][30][2,0]
        hv += -1/2*g[dei(p[A,1],p[B,0],p[I,1],p[I,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][33][2,0]
        hv += -1*g[dei(p[A,1],p[B,0],p[I,1],p[I,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][48][2,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,0],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,1],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[A,1],p[I,1])]*r[A][4][2,9]*r[B][1][0,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[A,1],p[I,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2I3(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,2),(I,3)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,1],p[B,0],p[I,0],p[I,1])]*r[A][4][2,9]*r[B][1][0,12]*r[I][15][3,0]
        hv += -1*g[dei(p[A,1],p[B,0],p[I,0],p[I,1])]*r[A][4][2,9]*r[B][1][0,12]*r[I][30][3,0]
        hv += -1/2*g[dei(p[A,1],p[B,0],p[I,1],p[I,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][33][3,0]
        hv += -1*g[dei(p[A,1],p[B,0],p[I,1],p[I,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][48][3,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,0],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,1],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[A,1],p[I,1])]*r[A][4][2,9]*r[B][1][0,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[A,1],p[I,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B1I2(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,2),(B,1),(I,2)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,1],p[B,0],p[I,0],p[I,1])]*r[A][4][2,9]*r[B][1][1,12]*r[I][15][2,0]
        hv += -1*g[dei(p[A,1],p[B,0],p[I,0],p[I,1])]*r[A][4][2,9]*r[B][1][1,12]*r[I][30][2,0]
        hv += -1/2*g[dei(p[A,1],p[B,0],p[I,1],p[I,0])]*r[A][4][2,9]*r[B][1][1,12]*r[I][33][2,0]
        hv += -1*g[dei(p[A,1],p[B,0],p[I,1],p[I,0])]*r[A][4][2,9]*r[B][1][1,12]*r[I][48][2,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,0],p[B,0])]*r[A][4][2,9]*r[B][1][1,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,1],p[B,0])]*r[A][4][2,9]*r[B][1][1,12]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[A,1],p[I,1])]*r[A][4][2,9]*r[B][1][1,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[A,1],p[I,0])]*r[A][4][2,9]*r[B][1][1,12]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][1][1,12]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][1][1,12]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B1I3(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,2),(B,1),(I,3)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,1],p[B,0],p[I,0],p[I,1])]*r[A][4][2,9]*r[B][1][1,12]*r[I][15][3,0]
        hv += -1*g[dei(p[A,1],p[B,0],p[I,0],p[I,1])]*r[A][4][2,9]*r[B][1][1,12]*r[I][30][3,0]
        hv += -1/2*g[dei(p[A,1],p[B,0],p[I,1],p[I,0])]*r[A][4][2,9]*r[B][1][1,12]*r[I][33][3,0]
        hv += -1*g[dei(p[A,1],p[B,0],p[I,1],p[I,0])]*r[A][4][2,9]*r[B][1][1,12]*r[I][48][3,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,0],p[B,0])]*r[A][4][2,9]*r[B][1][1,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,1],p[B,0])]*r[A][4][2,9]*r[B][1][1,12]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[A,1],p[I,1])]*r[A][4][2,9]*r[B][1][1,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[A,1],p[I,0])]*r[A][4][2,9]*r[B][1][1,12]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][1][1,12]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][1][1,12]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I2(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,3),(I,2)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,1],p[B,0],p[I,0],p[I,1])]*r[A][4][3,9]*r[B][1][0,12]*r[I][15][2,0]
        hv += -1*g[dei(p[A,1],p[B,0],p[I,0],p[I,1])]*r[A][4][3,9]*r[B][1][0,12]*r[I][30][2,0]
        hv += -1/2*g[dei(p[A,1],p[B,0],p[I,1],p[I,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][33][2,0]
        hv += -1*g[dei(p[A,1],p[B,0],p[I,1],p[I,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][48][2,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,0],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,1],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[A,1],p[I,1])]*r[A][4][3,9]*r[B][1][0,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[A,1],p[I,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I3(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,3),(I,3)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,1],p[B,0],p[I,0],p[I,1])]*r[A][4][3,9]*r[B][1][0,12]*r[I][15][3,0]
        hv += -1*g[dei(p[A,1],p[B,0],p[I,0],p[I,1])]*r[A][4][3,9]*r[B][1][0,12]*r[I][30][3,0]
        hv += -1/2*g[dei(p[A,1],p[B,0],p[I,1],p[I,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][33][3,0]
        hv += -1*g[dei(p[A,1],p[B,0],p[I,1],p[I,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][48][3,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,0],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,1],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[A,1],p[I,1])]*r[A][4][3,9]*r[B][1][0,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[A,1],p[I,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B1I2(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,3),(B,1),(I,2)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,1],p[B,0],p[I,0],p[I,1])]*r[A][4][3,9]*r[B][1][1,12]*r[I][15][2,0]
        hv += -1*g[dei(p[A,1],p[B,0],p[I,0],p[I,1])]*r[A][4][3,9]*r[B][1][1,12]*r[I][30][2,0]
        hv += -1/2*g[dei(p[A,1],p[B,0],p[I,1],p[I,0])]*r[A][4][3,9]*r[B][1][1,12]*r[I][33][2,0]
        hv += -1*g[dei(p[A,1],p[B,0],p[I,1],p[I,0])]*r[A][4][3,9]*r[B][1][1,12]*r[I][48][2,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,0],p[B,0])]*r[A][4][3,9]*r[B][1][1,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,1],p[B,0])]*r[A][4][3,9]*r[B][1][1,12]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[A,1],p[I,1])]*r[A][4][3,9]*r[B][1][1,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[A,1],p[I,0])]*r[A][4][3,9]*r[B][1][1,12]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][1][1,12]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][1][1,12]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B1I3(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,3),(B,1),(I,3)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,1],p[B,0],p[I,0],p[I,1])]*r[A][4][3,9]*r[B][1][1,12]*r[I][15][3,0]
        hv += -1*g[dei(p[A,1],p[B,0],p[I,0],p[I,1])]*r[A][4][3,9]*r[B][1][1,12]*r[I][30][3,0]
        hv += -1/2*g[dei(p[A,1],p[B,0],p[I,1],p[I,0])]*r[A][4][3,9]*r[B][1][1,12]*r[I][33][3,0]
        hv += -1*g[dei(p[A,1],p[B,0],p[I,1],p[I,0])]*r[A][4][3,9]*r[B][1][1,12]*r[I][48][3,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,0],p[B,0])]*r[A][4][3,9]*r[B][1][1,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,1],p[B,0])]*r[A][4][3,9]*r[B][1][1,12]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,0],p[B,0],p[A,1],p[I,1])]*r[A][4][3,9]*r[B][1][1,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[B,0],p[A,1],p[I,0])]*r[A][4][3,9]*r[B][1][1,12]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][1][1,12]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][1][1,12]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B2I1(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,2),(B,2),(I,1)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,0],p[I,0])]*r[A][4][2,9]*r[B][5][2,12]*r[I][9][1,0]
        hv += -1*g[dei(p[A,1],p[B,1],p[I,0],p[I,0])]*r[A][4][2,9]*r[B][5][2,12]*r[I][24][1,0]
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,1],p[I,1])]*r[A][4][2,9]*r[B][5][2,12]*r[I][39][1,0]
        hv += -1*g[dei(p[A,1],p[B,1],p[I,1],p[I,1])]*r[A][4][2,9]*r[B][5][2,12]*r[I][54][1,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,0],p[B,1])]*r[A][4][2,9]*r[B][5][2,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,1],p[B,1])]*r[A][4][2,9]*r[B][5][2,12]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[A,1],p[I,0])]*r[A][4][2,9]*r[B][5][2,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[A,1],p[I,1])]*r[A][4][2,9]*r[B][5][2,12]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[A,1],p[B,1])]*r[A][4][2,9]*r[B][5][2,12]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[A,1],p[B,1])]*r[A][4][2,9]*r[B][5][2,12]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B3I1(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,2),(B,3),(I,1)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,0],p[I,0])]*r[A][4][2,9]*r[B][5][3,12]*r[I][9][1,0]
        hv += -1*g[dei(p[A,1],p[B,1],p[I,0],p[I,0])]*r[A][4][2,9]*r[B][5][3,12]*r[I][24][1,0]
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,1],p[I,1])]*r[A][4][2,9]*r[B][5][3,12]*r[I][39][1,0]
        hv += -1*g[dei(p[A,1],p[B,1],p[I,1],p[I,1])]*r[A][4][2,9]*r[B][5][3,12]*r[I][54][1,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,0],p[B,1])]*r[A][4][2,9]*r[B][5][3,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,1],p[B,1])]*r[A][4][2,9]*r[B][5][3,12]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[A,1],p[I,0])]*r[A][4][2,9]*r[B][5][3,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[A,1],p[I,1])]*r[A][4][2,9]*r[B][5][3,12]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[A,1],p[B,1])]*r[A][4][2,9]*r[B][5][3,12]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[A,1],p[B,1])]*r[A][4][2,9]*r[B][5][3,12]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B2I1(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,3),(B,2),(I,1)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,0],p[I,0])]*r[A][4][3,9]*r[B][5][2,12]*r[I][9][1,0]
        hv += -1*g[dei(p[A,1],p[B,1],p[I,0],p[I,0])]*r[A][4][3,9]*r[B][5][2,12]*r[I][24][1,0]
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,1],p[I,1])]*r[A][4][3,9]*r[B][5][2,12]*r[I][39][1,0]
        hv += -1*g[dei(p[A,1],p[B,1],p[I,1],p[I,1])]*r[A][4][3,9]*r[B][5][2,12]*r[I][54][1,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,0],p[B,1])]*r[A][4][3,9]*r[B][5][2,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,1],p[B,1])]*r[A][4][3,9]*r[B][5][2,12]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[A,1],p[I,0])]*r[A][4][3,9]*r[B][5][2,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[A,1],p[I,1])]*r[A][4][3,9]*r[B][5][2,12]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[A,1],p[B,1])]*r[A][4][3,9]*r[B][5][2,12]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[A,1],p[B,1])]*r[A][4][3,9]*r[B][5][2,12]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B3I1(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,3),(B,3),(I,1)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,0],p[I,0])]*r[A][4][3,9]*r[B][5][3,12]*r[I][9][1,0]
        hv += -1*g[dei(p[A,1],p[B,1],p[I,0],p[I,0])]*r[A][4][3,9]*r[B][5][3,12]*r[I][24][1,0]
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,1],p[I,1])]*r[A][4][3,9]*r[B][5][3,12]*r[I][39][1,0]
        hv += -1*g[dei(p[A,1],p[B,1],p[I,1],p[I,1])]*r[A][4][3,9]*r[B][5][3,12]*r[I][54][1,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,0],p[B,1])]*r[A][4][3,9]*r[B][5][3,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,1],p[B,1])]*r[A][4][3,9]*r[B][5][3,12]*r[I][39][1,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[A,1],p[I,0])]*r[A][4][3,9]*r[B][5][3,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[A,1],p[I,1])]*r[A][4][3,9]*r[B][5][3,12]*r[I][39][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[A,1],p[B,1])]*r[A][4][3,9]*r[B][5][3,12]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[A,1],p[B,1])]*r[A][4][3,9]*r[B][5][3,12]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5B4I1(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,5),(B,4),(I,1)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,0],p[I,0])]*r[A][6][5,9]*r[B][7][4,12]*r[I][24][1,0]
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,1],p[I,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][54][1,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,0],p[B,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][24][1,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,1],p[B,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][54][1,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[A,1],p[I,0])]*r[A][6][5,9]*r[B][7][4,12]*r[I][24][1,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[A,1],p[I,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][54][1,0]
        hv += -1/2*g[dei(p[I,0],p[I,0],p[A,1],p[B,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][24][1,0]
        hv += -1*g[dei(p[I,0],p[I,0],p[A,1],p[B,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][9][1,0]
        hv += -1/2*g[dei(p[I,1],p[I,1],p[A,1],p[B,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][54][1,0]
        hv += -1*g[dei(p[I,1],p[I,1],p[A,1],p[B,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B2I2(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,2),(B,2),(I,2)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,0],p[I,1])]*r[A][4][2,9]*r[B][5][2,12]*r[I][15][2,0]
        hv += -1*g[dei(p[A,1],p[B,1],p[I,0],p[I,1])]*r[A][4][2,9]*r[B][5][2,12]*r[I][30][2,0]
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,1],p[I,0])]*r[A][4][2,9]*r[B][5][2,12]*r[I][33][2,0]
        hv += -1*g[dei(p[A,1],p[B,1],p[I,1],p[I,0])]*r[A][4][2,9]*r[B][5][2,12]*r[I][48][2,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,0],p[B,1])]*r[A][4][2,9]*r[B][5][2,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,1],p[B,1])]*r[A][4][2,9]*r[B][5][2,12]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[A,1],p[I,1])]*r[A][4][2,9]*r[B][5][2,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[A,1],p[I,0])]*r[A][4][2,9]*r[B][5][2,12]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,1],p[B,1])]*r[A][4][2,9]*r[B][5][2,12]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,1],p[B,1])]*r[A][4][2,9]*r[B][5][2,12]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B2I3(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,2),(B,2),(I,3)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,0],p[I,1])]*r[A][4][2,9]*r[B][5][2,12]*r[I][15][3,0]
        hv += -1*g[dei(p[A,1],p[B,1],p[I,0],p[I,1])]*r[A][4][2,9]*r[B][5][2,12]*r[I][30][3,0]
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,1],p[I,0])]*r[A][4][2,9]*r[B][5][2,12]*r[I][33][3,0]
        hv += -1*g[dei(p[A,1],p[B,1],p[I,1],p[I,0])]*r[A][4][2,9]*r[B][5][2,12]*r[I][48][3,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,0],p[B,1])]*r[A][4][2,9]*r[B][5][2,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,1],p[B,1])]*r[A][4][2,9]*r[B][5][2,12]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[A,1],p[I,1])]*r[A][4][2,9]*r[B][5][2,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[A,1],p[I,0])]*r[A][4][2,9]*r[B][5][2,12]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,1],p[B,1])]*r[A][4][2,9]*r[B][5][2,12]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,1],p[B,1])]*r[A][4][2,9]*r[B][5][2,12]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B3I2(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,2),(B,3),(I,2)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,0],p[I,1])]*r[A][4][2,9]*r[B][5][3,12]*r[I][15][2,0]
        hv += -1*g[dei(p[A,1],p[B,1],p[I,0],p[I,1])]*r[A][4][2,9]*r[B][5][3,12]*r[I][30][2,0]
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,1],p[I,0])]*r[A][4][2,9]*r[B][5][3,12]*r[I][33][2,0]
        hv += -1*g[dei(p[A,1],p[B,1],p[I,1],p[I,0])]*r[A][4][2,9]*r[B][5][3,12]*r[I][48][2,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,0],p[B,1])]*r[A][4][2,9]*r[B][5][3,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,1],p[B,1])]*r[A][4][2,9]*r[B][5][3,12]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[A,1],p[I,1])]*r[A][4][2,9]*r[B][5][3,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[A,1],p[I,0])]*r[A][4][2,9]*r[B][5][3,12]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,1],p[B,1])]*r[A][4][2,9]*r[B][5][3,12]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,1],p[B,1])]*r[A][4][2,9]*r[B][5][3,12]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B3I3(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,2),(B,3),(I,3)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,0],p[I,1])]*r[A][4][2,9]*r[B][5][3,12]*r[I][15][3,0]
        hv += -1*g[dei(p[A,1],p[B,1],p[I,0],p[I,1])]*r[A][4][2,9]*r[B][5][3,12]*r[I][30][3,0]
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,1],p[I,0])]*r[A][4][2,9]*r[B][5][3,12]*r[I][33][3,0]
        hv += -1*g[dei(p[A,1],p[B,1],p[I,1],p[I,0])]*r[A][4][2,9]*r[B][5][3,12]*r[I][48][3,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,0],p[B,1])]*r[A][4][2,9]*r[B][5][3,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,1],p[B,1])]*r[A][4][2,9]*r[B][5][3,12]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[A,1],p[I,1])]*r[A][4][2,9]*r[B][5][3,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[A,1],p[I,0])]*r[A][4][2,9]*r[B][5][3,12]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,1],p[B,1])]*r[A][4][2,9]*r[B][5][3,12]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,1],p[B,1])]*r[A][4][2,9]*r[B][5][3,12]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B2I2(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,3),(B,2),(I,2)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,0],p[I,1])]*r[A][4][3,9]*r[B][5][2,12]*r[I][15][2,0]
        hv += -1*g[dei(p[A,1],p[B,1],p[I,0],p[I,1])]*r[A][4][3,9]*r[B][5][2,12]*r[I][30][2,0]
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,1],p[I,0])]*r[A][4][3,9]*r[B][5][2,12]*r[I][33][2,0]
        hv += -1*g[dei(p[A,1],p[B,1],p[I,1],p[I,0])]*r[A][4][3,9]*r[B][5][2,12]*r[I][48][2,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,0],p[B,1])]*r[A][4][3,9]*r[B][5][2,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,1],p[B,1])]*r[A][4][3,9]*r[B][5][2,12]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[A,1],p[I,1])]*r[A][4][3,9]*r[B][5][2,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[A,1],p[I,0])]*r[A][4][3,9]*r[B][5][2,12]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,1],p[B,1])]*r[A][4][3,9]*r[B][5][2,12]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,1],p[B,1])]*r[A][4][3,9]*r[B][5][2,12]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B2I3(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,3),(B,2),(I,3)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,0],p[I,1])]*r[A][4][3,9]*r[B][5][2,12]*r[I][15][3,0]
        hv += -1*g[dei(p[A,1],p[B,1],p[I,0],p[I,1])]*r[A][4][3,9]*r[B][5][2,12]*r[I][30][3,0]
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,1],p[I,0])]*r[A][4][3,9]*r[B][5][2,12]*r[I][33][3,0]
        hv += -1*g[dei(p[A,1],p[B,1],p[I,1],p[I,0])]*r[A][4][3,9]*r[B][5][2,12]*r[I][48][3,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,0],p[B,1])]*r[A][4][3,9]*r[B][5][2,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,1],p[B,1])]*r[A][4][3,9]*r[B][5][2,12]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[A,1],p[I,1])]*r[A][4][3,9]*r[B][5][2,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[A,1],p[I,0])]*r[A][4][3,9]*r[B][5][2,12]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,1],p[B,1])]*r[A][4][3,9]*r[B][5][2,12]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,1],p[B,1])]*r[A][4][3,9]*r[B][5][2,12]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B3I2(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,3),(B,3),(I,2)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,0],p[I,1])]*r[A][4][3,9]*r[B][5][3,12]*r[I][15][2,0]
        hv += -1*g[dei(p[A,1],p[B,1],p[I,0],p[I,1])]*r[A][4][3,9]*r[B][5][3,12]*r[I][30][2,0]
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,1],p[I,0])]*r[A][4][3,9]*r[B][5][3,12]*r[I][33][2,0]
        hv += -1*g[dei(p[A,1],p[B,1],p[I,1],p[I,0])]*r[A][4][3,9]*r[B][5][3,12]*r[I][48][2,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,0],p[B,1])]*r[A][4][3,9]*r[B][5][3,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,1],p[B,1])]*r[A][4][3,9]*r[B][5][3,12]*r[I][33][2,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[A,1],p[I,1])]*r[A][4][3,9]*r[B][5][3,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[A,1],p[I,0])]*r[A][4][3,9]*r[B][5][3,12]*r[I][33][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,1],p[B,1])]*r[A][4][3,9]*r[B][5][3,12]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,1],p[B,1])]*r[A][4][3,9]*r[B][5][3,12]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B3I3(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,3),(B,3),(I,3)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,0],p[I,1])]*r[A][4][3,9]*r[B][5][3,12]*r[I][15][3,0]
        hv += -1*g[dei(p[A,1],p[B,1],p[I,0],p[I,1])]*r[A][4][3,9]*r[B][5][3,12]*r[I][30][3,0]
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,1],p[I,0])]*r[A][4][3,9]*r[B][5][3,12]*r[I][33][3,0]
        hv += -1*g[dei(p[A,1],p[B,1],p[I,1],p[I,0])]*r[A][4][3,9]*r[B][5][3,12]*r[I][48][3,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,0],p[B,1])]*r[A][4][3,9]*r[B][5][3,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,1],p[B,1])]*r[A][4][3,9]*r[B][5][3,12]*r[I][33][3,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[A,1],p[I,1])]*r[A][4][3,9]*r[B][5][3,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[A,1],p[I,0])]*r[A][4][3,9]*r[B][5][3,12]*r[I][33][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,1],p[B,1])]*r[A][4][3,9]*r[B][5][3,12]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,1],p[B,1])]*r[A][4][3,9]*r[B][5][3,12]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5B4I2(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,5),(B,4),(I,2)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,0],p[I,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][30][2,0]
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,1],p[I,0])]*r[A][6][5,9]*r[B][7][4,12]*r[I][48][2,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,0],p[B,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][30][2,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,1],p[B,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][48][2,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[A,1],p[I,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][30][2,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[A,1],p[I,0])]*r[A][6][5,9]*r[B][7][4,12]*r[I][48][2,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,1],p[B,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][30][2,0]
        hv += -1*g[dei(p[I,0],p[I,1],p[A,1],p[B,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][15][2,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,1],p[B,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][48][2,0]
        hv += -1*g[dei(p[I,1],p[I,0],p[A,1],p[B,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5B4I3(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,5),(B,4),(I,3)]))
        hv = 0.0
        
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,0],p[I,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][30][3,0]
        hv += -1/2*g[dei(p[A,1],p[B,1],p[I,1],p[I,0])]*r[A][6][5,9]*r[B][7][4,12]*r[I][48][3,0]
        hv += 1/2*g[dei(p[A,1],p[I,1],p[I,0],p[B,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][30][3,0]
        hv += 1/2*g[dei(p[A,1],p[I,0],p[I,1],p[B,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][48][3,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[A,1],p[I,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][30][3,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[A,1],p[I,0])]*r[A][6][5,9]*r[B][7][4,12]*r[I][48][3,0]
        hv += -1/2*g[dei(p[I,0],p[I,1],p[A,1],p[B,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][30][3,0]
        hv += -1*g[dei(p[I,0],p[I,1],p[A,1],p[B,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][15][3,0]
        hv += -1/2*g[dei(p[I,1],p[I,0],p[A,1],p[B,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][48][3,0]
        hv += -1*g[dei(p[I,1],p[I,0],p[A,1],p[B,1])]*r[A][6][5,9]*r[B][7][4,12]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B4I5(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(B,4),(I,5)]))
        hv = 0.0
        
        hv += g[dei(p[A,0],p[I,1],p[I,0],p[B,1])]*r[A][0][0,9]*r[B][7][4,12]*r[I][27][5,0]
        hv += g[dei(p[A,0],p[I,0],p[I,1],p[B,1])]*r[A][0][0,9]*r[B][7][4,12]*r[I][45][5,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1B4I5(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,1),(B,4),(I,5)]))
        hv = 0.0
        
        hv += g[dei(p[A,0],p[I,1],p[I,0],p[B,1])]*r[A][0][1,9]*r[B][7][4,12]*r[I][27][5,0]
        hv += g[dei(p[A,0],p[I,0],p[I,1],p[B,1])]*r[A][0][1,9]*r[B][7][4,12]*r[I][45][5,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2B4I5(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,2),(B,4),(I,5)]))
        hv = 0.0
        
        hv += g[dei(p[A,1],p[I,1],p[I,0],p[B,1])]*r[A][4][2,9]*r[B][7][4,12]*r[I][27][5,0]
        hv += g[dei(p[A,1],p[I,0],p[I,1],p[B,1])]*r[A][4][2,9]*r[B][7][4,12]*r[I][45][5,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3B4I5(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,3),(B,4),(I,5)]))
        hv = 0.0
        
        hv += g[dei(p[A,1],p[I,1],p[I,0],p[B,1])]*r[A][4][3,9]*r[B][7][4,12]*r[I][27][5,0]
        hv += g[dei(p[A,1],p[I,0],p[I,1],p[B,1])]*r[A][4][3,9]*r[B][7][4,12]*r[I][45][5,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6B11I14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,6),(B,11),(I,14)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[B,0],p[A,0],p[I,0],p[B,1])]*r[A][3][6,9]*r[B][30][11,12]*r[I][2][14,0]
        hv += -1/2*g[dei(p[B,0],p[B,1],p[I,0],p[A,0])]*r[A][3][6,9]*r[B][30][11,12]*r[I][2][14,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[B,0],p[B,1])]*r[A][3][6,9]*r[B][30][11,12]*r[I][2][14,0]
        hv += 1/2*g[dei(p[I,0],p[B,1],p[B,0],p[A,0])]*r[A][3][6,9]*r[B][30][11,12]*r[I][2][14,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6B11I13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,6),(B,11),(I,13)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += 1/2*g[dei(p[B,0],p[A,0],p[I,1],p[B,1])]*r[A][3][6,9]*r[B][30][11,12]*r[I][6][13,0]
        hv += -1/2*g[dei(p[B,0],p[B,1],p[I,1],p[A,0])]*r[A][3][6,9]*r[B][30][11,12]*r[I][6][13,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[B,0],p[B,1])]*r[A][3][6,9]*r[B][30][11,12]*r[I][6][13,0]
        hv += 1/2*g[dei(p[I,1],p[B,1],p[B,0],p[A,0])]*r[A][3][6,9]*r[B][30][11,12]*r[I][6][13,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6B15I1(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,6),(B,15),(I,1)]))
        hv = 0.0
        
        hv += 1/2*g[dei(p[B,0],p[A,0],p[I,0],p[I,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][24][1,0]
        hv += 1/2*g[dei(p[B,0],p[A,0],p[I,1],p[I,1])]*r[A][3][6,9]*r[B][2][15,12]*r[I][54][1,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[I,0],p[A,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][24][1,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[I,1],p[A,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][54][1,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[B,0],p[I,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][24][1,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[B,0],p[I,1])]*r[A][3][6,9]*r[B][2][15,12]*r[I][54][1,0]
        hv += 1/2*g[dei(p[I,0],p[I,0],p[B,0],p[A,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][24][1,0]
        hv += g[dei(p[I,0],p[I,0],p[B,0],p[A,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][9][1,0]
        hv += 1/2*g[dei(p[I,1],p[I,1],p[B,0],p[A,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][54][1,0]
        hv += g[dei(p[I,1],p[I,1],p[B,0],p[A,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][39][1,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6B15I2(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,6),(B,15),(I,2)]))
        hv = 0.0
        
        hv += 1/2*g[dei(p[B,0],p[A,0],p[I,0],p[I,1])]*r[A][3][6,9]*r[B][2][15,12]*r[I][30][2,0]
        hv += 1/2*g[dei(p[B,0],p[A,0],p[I,1],p[I,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][48][2,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[I,0],p[A,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][30][2,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[I,1],p[A,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][48][2,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[B,0],p[I,1])]*r[A][3][6,9]*r[B][2][15,12]*r[I][30][2,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[B,0],p[I,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][48][2,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[B,0],p[A,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][30][2,0]
        hv += g[dei(p[I,0],p[I,1],p[B,0],p[A,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][15][2,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[B,0],p[A,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][48][2,0]
        hv += g[dei(p[I,1],p[I,0],p[B,0],p[A,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][33][2,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6B15I3(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,6),(B,15),(I,3)]))
        hv = 0.0
        
        hv += 1/2*g[dei(p[B,0],p[A,0],p[I,0],p[I,1])]*r[A][3][6,9]*r[B][2][15,12]*r[I][30][3,0]
        hv += 1/2*g[dei(p[B,0],p[A,0],p[I,1],p[I,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][48][3,0]
        hv += -1/2*g[dei(p[B,0],p[I,1],p[I,0],p[A,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][30][3,0]
        hv += -1/2*g[dei(p[B,0],p[I,0],p[I,1],p[A,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][48][3,0]
        hv += -1/2*g[dei(p[I,0],p[A,0],p[B,0],p[I,1])]*r[A][3][6,9]*r[B][2][15,12]*r[I][30][3,0]
        hv += -1/2*g[dei(p[I,1],p[A,0],p[B,0],p[I,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][48][3,0]
        hv += 1/2*g[dei(p[I,0],p[I,1],p[B,0],p[A,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][30][3,0]
        hv += g[dei(p[I,0],p[I,1],p[B,0],p[A,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][15][3,0]
        hv += 1/2*g[dei(p[I,1],p[I,0],p[B,0],p[A,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][48][3,0]
        hv += g[dei(p[I,1],p[I,0],p[B,0],p[A,0])]*r[A][3][6,9]*r[B][2][15,12]*r[I][33][3,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10I12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,10),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,0],p[B,0],p[A,1],p[A,0])]*r[A][48][10,9]*r[B][1][0,12]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B1I12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,10),(B,1),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,0],p[B,0],p[A,1],p[A,0])]*r[A][48][10,9]*r[B][1][1,12]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B2I12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,10),(B,2),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,0],p[B,1],p[A,1],p[A,0])]*r[A][48][10,9]*r[B][5][2,12]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B3I12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,10),(B,3),(I,12)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,0],p[B,1],p[A,1],p[A,0])]*r[A][48][10,9]*r[B][5][3,12]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10I11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,10),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,1],p[B,0],p[A,1],p[A,0])]*r[A][48][10,9]*r[B][1][0,12]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B1I11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,10),(B,1),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,1],p[B,0],p[A,1],p[A,0])]*r[A][48][10,9]*r[B][1][1,12]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B2I11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,10),(B,2),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,1],p[B,1],p[A,1],p[A,0])]*r[A][48][10,9]*r[B][5][2,12]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A10B3I11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,10),(B,3),(I,11)]))
        hv = 0.0
        sket = sign([A,I])
        
        hv += g[dei(p[I,1],p[B,1],p[A,1],p[A,0])]*r[A][48][10,9]*r[B][5][3,12]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5B8I12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,5),(B,8),(I,12)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[I,0],p[B,0],p[A,1],p[B,1])]*r[A][6][5,9]*r[B][46][8,12]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5B7I12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,5),(B,7),(I,12)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[I,0],p[B,1],p[A,1],p[B,1])]*r[A][6][5,9]*r[B][52][7,12]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5B8I11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,5),(B,8),(I,11)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[I,1],p[B,0],p[A,1],p[B,1])]*r[A][6][5,9]*r[B][46][8,12]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5B7I11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,5),(B,7),(I,11)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += -1*g[dei(p[I,1],p[B,1],p[A,1],p[B,1])]*r[A][6][5,9]*r[B][52][7,12]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5I4(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,5),(I,4)]))
        hv = 0.0
        
        hv += g[dei(p[I,0],p[B,0],p[A,1],p[I,1])]*r[A][6][5,9]*r[B][1][0,12]*r[I][18][4,0]
        hv += g[dei(p[I,1],p[B,0],p[A,1],p[I,0])]*r[A][6][5,9]*r[B][1][0,12]*r[I][36][4,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5B1I4(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,5),(B,1),(I,4)]))
        hv = 0.0
        
        hv += g[dei(p[I,0],p[B,0],p[A,1],p[I,1])]*r[A][6][5,9]*r[B][1][1,12]*r[I][18][4,0]
        hv += g[dei(p[I,1],p[B,0],p[A,1],p[I,0])]*r[A][6][5,9]*r[B][1][1,12]*r[I][36][4,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5B2I4(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,5),(B,2),(I,4)]))
        hv = 0.0
        
        hv += g[dei(p[I,0],p[B,1],p[A,1],p[I,1])]*r[A][6][5,9]*r[B][5][2,12]*r[I][18][4,0]
        hv += g[dei(p[I,1],p[B,1],p[A,1],p[I,0])]*r[A][6][5,9]*r[B][5][2,12]*r[I][36][4,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5B3I4(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,5),(B,3),(I,4)]))
        hv = 0.0
        
        hv += g[dei(p[I,0],p[B,1],p[A,1],p[I,1])]*r[A][6][5,9]*r[B][5][3,12]*r[I][18][4,0]
        hv += g[dei(p[I,1],p[B,1],p[A,1],p[I,0])]*r[A][6][5,9]*r[B][5][3,12]*r[I][36][4,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6B14I12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,6),(B,14),(I,12)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[I,0],p[B,0],p[B,0],p[A,0])]*r[A][3][6,9]*r[B][21][14,12]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6B13I12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,6),(B,13),(I,12)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[I,0],p[B,1],p[B,0],p[A,0])]*r[A][3][6,9]*r[B][27][13,12]*r[I][0][12,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6B14I11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,6),(B,14),(I,11)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[I,1],p[B,0],p[B,0],p[A,0])]*r[A][3][6,9]*r[B][21][14,12]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6B13I11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,6),(B,13),(I,11)]))
        hv = 0.0
        sket = sign([B,I])
        
        hv += g[dei(p[I,1],p[B,1],p[B,0],p[A,0])]*r[A][3][6,9]*r[B][27][13,12]*r[I][4][11,0]
        
        hd[v] = hd.get(v,0.0)+sket*hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6I15(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,6),(I,15)]))
        hv = 0.0
        
        hv += -1*g[dei(p[I,0],p[B,0],p[I,0],p[A,0])]*r[A][3][6,9]*r[B][1][0,12]*r[I][11][15,0]
        hv += -1*g[dei(p[I,1],p[B,0],p[I,1],p[A,0])]*r[A][3][6,9]*r[B][1][0,12]*r[I][41][15,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6B1I15(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,6),(B,1),(I,15)]))
        hv = 0.0
        
        hv += -1*g[dei(p[I,0],p[B,0],p[I,0],p[A,0])]*r[A][3][6,9]*r[B][1][1,12]*r[I][11][15,0]
        hv += -1*g[dei(p[I,1],p[B,0],p[I,1],p[A,0])]*r[A][3][6,9]*r[B][1][1,12]*r[I][41][15,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6B2I15(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,6),(B,2),(I,15)]))
        hv = 0.0
        
        hv += -1*g[dei(p[I,0],p[B,1],p[I,0],p[A,0])]*r[A][3][6,9]*r[B][5][2,12]*r[I][11][15,0]
        hv += -1*g[dei(p[I,1],p[B,1],p[I,1],p[A,0])]*r[A][3][6,9]*r[B][5][2,12]*r[I][41][15,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6B3I15(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        v = tuple(sorted([(A,6),(B,3),(I,15)]))
        hv = 0.0
        
        hv += -1*g[dei(p[I,0],p[B,1],p[I,0],p[A,0])]*r[A][3][6,9]*r[B][5][3,12]*r[I][11][15,0]
        hv += -1*g[dei(p[I,1],p[B,1],p[I,1],p[A,0])]*r[A][3][6,9]*r[B][5][3,12]*r[I][41][15,0]
        
        hd[v] = hd.get(v,0.0)+hv
        
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B15I9J7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,15),(I,9),(J,7)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,0],p[I,0],p[B,0],p[J,0])]*r[A][0][0,9]*r[B][2][15,12]*r[I][1][9,0]*r[J][3][7,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B15I9J8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,15),(I,9),(J,8)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,0],p[I,0],p[B,0],p[J,1])]*r[A][0][0,9]*r[B][2][15,12]*r[I][1][9,0]*r[J][7][8,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B15I10J7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,15),(I,10),(J,7)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,0],p[I,1],p[B,0],p[J,0])]*r[A][0][0,9]*r[B][2][15,12]*r[I][5][10,0]*r[J][3][7,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B15I10J8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,15),(I,10),(J,8)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,0],p[I,1],p[B,0],p[J,1])]*r[A][0][0,9]*r[B][2][15,12]*r[I][5][10,0]*r[J][7][8,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B15I7J9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,15),(I,7),(J,9)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,0],p[J,0],p[B,0],p[I,0])]*r[A][0][0,9]*r[B][2][15,12]*r[I][3][7,0]*r[J][1][9,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B15I8J9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,15),(I,8),(J,9)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,0],p[J,0],p[B,0],p[I,1])]*r[A][0][0,9]*r[B][2][15,12]*r[I][7][8,0]*r[J][1][9,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B15I7J10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,15),(I,7),(J,10)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,0],p[J,1],p[B,0],p[I,0])]*r[A][0][0,9]*r[B][2][15,12]*r[I][3][7,0]*r[J][5][10,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B15I8J10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,15),(I,8),(J,10)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,0],p[J,1],p[B,0],p[I,1])]*r[A][0][0,9]*r[B][2][15,12]*r[I][7][8,0]*r[J][5][10,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _I12J9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(I,12),(J,9)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[A,0],p[B,0],p[I,0],p[J,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[A,0],p[J,0],p[I,0],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[I,0],p[B,0],p[A,0],p[J,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][1][9,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][1][9,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1I12J9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,1),(I,12),(J,9)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[A,0],p[B,0],p[I,0],p[J,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][0][12,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[A,0],p[J,0],p[I,0],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][0][12,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[I,0],p[B,0],p[A,0],p[J,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][0][12,0]*r[J][1][9,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][0][12,0]*r[J][1][9,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I12J9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,1),(I,12),(J,9)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[A,0],p[B,0],p[I,0],p[J,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[A,0],p[J,0],p[I,0],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[I,0],p[B,0],p[A,0],p[J,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][1][9,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][1][9,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _I14J7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(I,14),(J,7)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,0],p[B,0],p[I,0],p[J,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][2][14,0]*r[J][3][7,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1I14J7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,1),(I,14),(J,7)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,0],p[B,0],p[I,0],p[J,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][2][14,0]*r[J][3][7,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I14J7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,1),(I,14),(J,7)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,0],p[B,0],p[I,0],p[J,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][2][14,0]*r[J][3][7,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _I12J10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(I,12),(J,10)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[A,0],p[B,0],p[I,0],p[J,1])]*r[A][0][0,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[A,0],p[J,1],p[I,0],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[I,0],p[B,0],p[A,0],p[J,1])]*r[A][0][0,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][5][10,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][5][10,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1I12J10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,1),(I,12),(J,10)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[A,0],p[B,0],p[I,0],p[J,1])]*r[A][0][0,9]*r[B][1][1,12]*r[I][0][12,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[A,0],p[J,1],p[I,0],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][0][12,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[I,0],p[B,0],p[A,0],p[J,1])]*r[A][0][0,9]*r[B][1][1,12]*r[I][0][12,0]*r[J][5][10,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][0][12,0]*r[J][5][10,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I12J10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,1),(I,12),(J,10)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[A,0],p[B,0],p[I,0],p[J,1])]*r[A][0][1,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[A,0],p[J,1],p[I,0],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[I,0],p[B,0],p[A,0],p[J,1])]*r[A][0][1,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][5][10,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][5][10,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _I14J8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(I,14),(J,8)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,0],p[B,0],p[I,0],p[J,1])]*r[A][0][0,9]*r[B][1][0,12]*r[I][2][14,0]*r[J][7][8,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1I14J8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,1),(I,14),(J,8)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,0],p[B,0],p[I,0],p[J,1])]*r[A][0][0,9]*r[B][1][1,12]*r[I][2][14,0]*r[J][7][8,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I14J8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,1),(I,14),(J,8)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,0],p[B,0],p[I,0],p[J,1])]*r[A][0][1,9]*r[B][1][0,12]*r[I][2][14,0]*r[J][7][8,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2I12J9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,2),(I,12),(J,9)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[A,0],p[B,1],p[I,0],p[J,0])]*r[A][0][0,9]*r[B][5][2,12]*r[I][0][12,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[A,0],p[J,0],p[I,0],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][0][12,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[I,0],p[B,1],p[A,0],p[J,0])]*r[A][0][0,9]*r[B][5][2,12]*r[I][0][12,0]*r[J][1][9,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][0][12,0]*r[J][1][9,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3I12J9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,3),(I,12),(J,9)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[A,0],p[B,1],p[I,0],p[J,0])]*r[A][0][0,9]*r[B][5][3,12]*r[I][0][12,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[A,0],p[J,0],p[I,0],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][0][12,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[I,0],p[B,1],p[A,0],p[J,0])]*r[A][0][0,9]*r[B][5][3,12]*r[I][0][12,0]*r[J][1][9,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][0][12,0]*r[J][1][9,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2I14J7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,2),(I,14),(J,7)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,0],p[B,1],p[I,0],p[J,0])]*r[A][0][0,9]*r[B][5][2,12]*r[I][2][14,0]*r[J][3][7,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3I14J7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,3),(I,14),(J,7)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,0],p[B,1],p[I,0],p[J,0])]*r[A][0][0,9]*r[B][5][3,12]*r[I][2][14,0]*r[J][3][7,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2I12J10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,2),(I,12),(J,10)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[A,0],p[B,1],p[I,0],p[J,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][0][12,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[A,0],p[J,1],p[I,0],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][0][12,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[I,0],p[B,1],p[A,0],p[J,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][0][12,0]*r[J][5][10,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][0][12,0]*r[J][5][10,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3I12J10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,3),(I,12),(J,10)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[A,0],p[B,1],p[I,0],p[J,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][0][12,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[A,0],p[J,1],p[I,0],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][0][12,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[I,0],p[B,1],p[A,0],p[J,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][0][12,0]*r[J][5][10,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][0][12,0]*r[J][5][10,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2I14J8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,2),(I,14),(J,8)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,0],p[B,1],p[I,0],p[J,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][2][14,0]*r[J][7][8,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3I14J8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,3),(I,14),(J,8)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,0],p[B,1],p[I,0],p[J,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][2][14,0]*r[J][7][8,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _I11J9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(I,11),(J,9)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[A,0],p[B,0],p[I,1],p[J,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[A,0],p[J,0],p[I,1],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[I,1],p[B,0],p[A,0],p[J,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][1][9,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][1][9,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1I11J9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,1),(I,11),(J,9)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[A,0],p[B,0],p[I,1],p[J,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][4][11,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[A,0],p[J,0],p[I,1],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][4][11,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[I,1],p[B,0],p[A,0],p[J,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][4][11,0]*r[J][1][9,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][4][11,0]*r[J][1][9,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I11J9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,1),(I,11),(J,9)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[A,0],p[B,0],p[I,1],p[J,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[A,0],p[J,0],p[I,1],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[I,1],p[B,0],p[A,0],p[J,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][1][9,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][1][9,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _I13J7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(I,13),(J,7)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,0],p[B,0],p[I,1],p[J,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][6][13,0]*r[J][3][7,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1I13J7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,1),(I,13),(J,7)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,0],p[B,0],p[I,1],p[J,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][6][13,0]*r[J][3][7,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I13J7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,1),(I,13),(J,7)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,0],p[B,0],p[I,1],p[J,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][6][13,0]*r[J][3][7,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _I11J10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(I,11),(J,10)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[A,0],p[B,0],p[I,1],p[J,1])]*r[A][0][0,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[A,0],p[J,1],p[I,1],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[I,1],p[B,0],p[A,0],p[J,1])]*r[A][0][0,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][5][10,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][5][10,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1I11J10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,1),(I,11),(J,10)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[A,0],p[B,0],p[I,1],p[J,1])]*r[A][0][0,9]*r[B][1][1,12]*r[I][4][11,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[A,0],p[J,1],p[I,1],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][4][11,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[I,1],p[B,0],p[A,0],p[J,1])]*r[A][0][0,9]*r[B][1][1,12]*r[I][4][11,0]*r[J][5][10,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][4][11,0]*r[J][5][10,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I11J10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,1),(I,11),(J,10)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[A,0],p[B,0],p[I,1],p[J,1])]*r[A][0][1,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[A,0],p[J,1],p[I,1],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[I,1],p[B,0],p[A,0],p[J,1])]*r[A][0][1,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][5][10,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][5][10,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _I13J8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(I,13),(J,8)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,0],p[B,0],p[I,1],p[J,1])]*r[A][0][0,9]*r[B][1][0,12]*r[I][6][13,0]*r[J][7][8,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1I13J8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,1),(I,13),(J,8)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,0],p[B,0],p[I,1],p[J,1])]*r[A][0][0,9]*r[B][1][1,12]*r[I][6][13,0]*r[J][7][8,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I13J8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,1),(I,13),(J,8)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,0],p[B,0],p[I,1],p[J,1])]*r[A][0][1,9]*r[B][1][0,12]*r[I][6][13,0]*r[J][7][8,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2I11J9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,2),(I,11),(J,9)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[A,0],p[B,1],p[I,1],p[J,0])]*r[A][0][0,9]*r[B][5][2,12]*r[I][4][11,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[A,0],p[J,0],p[I,1],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][4][11,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[I,1],p[B,1],p[A,0],p[J,0])]*r[A][0][0,9]*r[B][5][2,12]*r[I][4][11,0]*r[J][1][9,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][4][11,0]*r[J][1][9,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3I11J9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,3),(I,11),(J,9)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[A,0],p[B,1],p[I,1],p[J,0])]*r[A][0][0,9]*r[B][5][3,12]*r[I][4][11,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[A,0],p[J,0],p[I,1],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][4][11,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[I,1],p[B,1],p[A,0],p[J,0])]*r[A][0][0,9]*r[B][5][3,12]*r[I][4][11,0]*r[J][1][9,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][4][11,0]*r[J][1][9,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2I13J7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,2),(I,13),(J,7)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,0],p[B,1],p[I,1],p[J,0])]*r[A][0][0,9]*r[B][5][2,12]*r[I][6][13,0]*r[J][3][7,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3I13J7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,3),(I,13),(J,7)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,0],p[B,1],p[I,1],p[J,0])]*r[A][0][0,9]*r[B][5][3,12]*r[I][6][13,0]*r[J][3][7,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2I11J10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,2),(I,11),(J,10)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[A,0],p[B,1],p[I,1],p[J,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][4][11,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[A,0],p[J,1],p[I,1],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][4][11,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[I,1],p[B,1],p[A,0],p[J,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][4][11,0]*r[J][5][10,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][4][11,0]*r[J][5][10,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3I11J10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,3),(I,11),(J,10)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[A,0],p[B,1],p[I,1],p[J,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][4][11,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[A,0],p[J,1],p[I,1],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][4][11,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[I,1],p[B,1],p[A,0],p[J,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][4][11,0]*r[J][5][10,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][4][11,0]*r[J][5][10,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2I13J8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,2),(I,13),(J,8)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,0],p[B,1],p[I,1],p[J,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][6][13,0]*r[J][7][8,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3I13J8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,3),(I,13),(J,8)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,0],p[B,1],p[I,1],p[J,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][6][13,0]*r[J][7][8,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2I12J9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,2),(I,12),(J,9)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[A,1],p[B,0],p[I,0],p[J,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[A,1],p[J,0],p[I,0],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[I,0],p[B,0],p[A,1],p[J,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][1][9,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][1][9,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I12J9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,3),(I,12),(J,9)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[A,1],p[B,0],p[I,0],p[J,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[A,1],p[J,0],p[I,0],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[I,0],p[B,0],p[A,1],p[J,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][1][9,0]
            hv += -1/4*g[dei(p[I,0],p[J,0],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][1][9,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2I14J7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,2),(I,14),(J,7)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,1],p[B,0],p[I,0],p[J,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][2][14,0]*r[J][3][7,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I14J7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,3),(I,14),(J,7)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,1],p[B,0],p[I,0],p[J,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][2][14,0]*r[J][3][7,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2I12J10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,2),(I,12),(J,10)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[A,1],p[B,0],p[I,0],p[J,1])]*r[A][4][2,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[A,1],p[J,1],p[I,0],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[I,0],p[B,0],p[A,1],p[J,1])]*r[A][4][2,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][5][10,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][5][10,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I12J10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,3),(I,12),(J,10)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[A,1],p[B,0],p[I,0],p[J,1])]*r[A][4][3,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[A,1],p[J,1],p[I,0],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[I,0],p[B,0],p[A,1],p[J,1])]*r[A][4][3,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][5][10,0]
            hv += -1/4*g[dei(p[I,0],p[J,1],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][5][10,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2I14J8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,2),(I,14),(J,8)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,1],p[B,0],p[I,0],p[J,1])]*r[A][4][2,9]*r[B][1][0,12]*r[I][2][14,0]*r[J][7][8,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I14J8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,3),(I,14),(J,8)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,1],p[B,0],p[I,0],p[J,1])]*r[A][4][3,9]*r[B][1][0,12]*r[I][2][14,0]*r[J][7][8,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2I11J9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,2),(I,11),(J,9)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[A,1],p[B,0],p[I,1],p[J,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[A,1],p[J,0],p[I,1],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[I,1],p[B,0],p[A,1],p[J,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][1][9,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][1][9,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I11J9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,3),(I,11),(J,9)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[A,1],p[B,0],p[I,1],p[J,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[A,1],p[J,0],p[I,1],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][1][9,0]
            hv += 1/4*g[dei(p[I,1],p[B,0],p[A,1],p[J,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][1][9,0]
            hv += -1/4*g[dei(p[I,1],p[J,0],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][1][9,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2I13J7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,2),(I,13),(J,7)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,1],p[B,0],p[I,1],p[J,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][6][13,0]*r[J][3][7,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I13J7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,3),(I,13),(J,7)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,1],p[B,0],p[I,1],p[J,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][6][13,0]*r[J][3][7,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2I11J10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,2),(I,11),(J,10)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[A,1],p[B,0],p[I,1],p[J,1])]*r[A][4][2,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[A,1],p[J,1],p[I,1],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[I,1],p[B,0],p[A,1],p[J,1])]*r[A][4][2,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][5][10,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][5][10,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I11J10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,3),(I,11),(J,10)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/4*g[dei(p[A,1],p[B,0],p[I,1],p[J,1])]*r[A][4][3,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[A,1],p[J,1],p[I,1],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][5][10,0]
            hv += 1/4*g[dei(p[I,1],p[B,0],p[A,1],p[J,1])]*r[A][4][3,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][5][10,0]
            hv += -1/4*g[dei(p[I,1],p[J,1],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][5][10,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2I13J8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,2),(I,13),(J,8)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,1],p[B,0],p[I,1],p[J,1])]*r[A][4][2,9]*r[B][1][0,12]*r[I][6][13,0]*r[J][7][8,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I13J8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,3),(I,13),(J,8)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,1],p[B,0],p[I,1],p[J,1])]*r[A][4][3,9]*r[B][1][0,12]*r[I][6][13,0]*r[J][7][8,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B4I14J9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,4),(I,14),(J,9)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,0],p[J,0],p[I,0],p[B,1])]*r[A][0][0,9]*r[B][7][4,12]*r[I][2][14,0]*r[J][1][9,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B4I14J10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,4),(I,14),(J,10)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,0],p[J,1],p[I,0],p[B,1])]*r[A][0][0,9]*r[B][7][4,12]*r[I][2][14,0]*r[J][5][10,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B4I13J9(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,4),(I,13),(J,9)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,0],p[J,0],p[I,1],p[B,1])]*r[A][0][0,9]*r[B][7][4,12]*r[I][6][13,0]*r[J][1][9,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B4I13J10(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,4),(I,13),(J,10)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,0],p[J,1],p[I,1],p[B,1])]*r[A][0][0,9]*r[B][7][4,12]*r[I][6][13,0]*r[J][5][10,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _I9J12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(I,9),(J,12)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[A,0],p[B,0],p[J,0],p[I,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[A,0],p[I,0],p[J,0],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[J,0],p[B,0],p[A,0],p[I,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][0][12,0]
            hv += 1/4*g[dei(p[J,0],p[I,0],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][0][12,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1I9J12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,1),(I,9),(J,12)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[A,0],p[B,0],p[J,0],p[I,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][1][9,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[A,0],p[I,0],p[J,0],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][1][9,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[J,0],p[B,0],p[A,0],p[I,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][1][9,0]*r[J][0][12,0]
            hv += 1/4*g[dei(p[J,0],p[I,0],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][1][9,0]*r[J][0][12,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I9J12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,1),(I,9),(J,12)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[A,0],p[B,0],p[J,0],p[I,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[A,0],p[I,0],p[J,0],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[J,0],p[B,0],p[A,0],p[I,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][0][12,0]
            hv += 1/4*g[dei(p[J,0],p[I,0],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][0][12,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _I7J14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(I,7),(J,14)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,0],p[B,0],p[J,0],p[I,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][3][7,0]*r[J][2][14,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1I7J14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,1),(I,7),(J,14)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,0],p[B,0],p[J,0],p[I,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][3][7,0]*r[J][2][14,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I7J14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,1),(I,7),(J,14)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,0],p[B,0],p[J,0],p[I,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][3][7,0]*r[J][2][14,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _I10J12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(I,10),(J,12)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[A,0],p[B,0],p[J,0],p[I,1])]*r[A][0][0,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[A,0],p[I,1],p[J,0],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[J,0],p[B,0],p[A,0],p[I,1])]*r[A][0][0,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][0][12,0]
            hv += 1/4*g[dei(p[J,0],p[I,1],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][0][12,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1I10J12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,1),(I,10),(J,12)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[A,0],p[B,0],p[J,0],p[I,1])]*r[A][0][0,9]*r[B][1][1,12]*r[I][5][10,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[A,0],p[I,1],p[J,0],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][5][10,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[J,0],p[B,0],p[A,0],p[I,1])]*r[A][0][0,9]*r[B][1][1,12]*r[I][5][10,0]*r[J][0][12,0]
            hv += 1/4*g[dei(p[J,0],p[I,1],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][5][10,0]*r[J][0][12,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I10J12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,1),(I,10),(J,12)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[A,0],p[B,0],p[J,0],p[I,1])]*r[A][0][1,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[A,0],p[I,1],p[J,0],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[J,0],p[B,0],p[A,0],p[I,1])]*r[A][0][1,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][0][12,0]
            hv += 1/4*g[dei(p[J,0],p[I,1],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][0][12,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _I8J14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(I,8),(J,14)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,0],p[B,0],p[J,0],p[I,1])]*r[A][0][0,9]*r[B][1][0,12]*r[I][7][8,0]*r[J][2][14,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1I8J14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,1),(I,8),(J,14)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,0],p[B,0],p[J,0],p[I,1])]*r[A][0][0,9]*r[B][1][1,12]*r[I][7][8,0]*r[J][2][14,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I8J14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,1),(I,8),(J,14)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,0],p[B,0],p[J,0],p[I,1])]*r[A][0][1,9]*r[B][1][0,12]*r[I][7][8,0]*r[J][2][14,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2I9J12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,2),(I,9),(J,12)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[A,0],p[B,1],p[J,0],p[I,0])]*r[A][0][0,9]*r[B][5][2,12]*r[I][1][9,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[A,0],p[I,0],p[J,0],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][1][9,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[J,0],p[B,1],p[A,0],p[I,0])]*r[A][0][0,9]*r[B][5][2,12]*r[I][1][9,0]*r[J][0][12,0]
            hv += 1/4*g[dei(p[J,0],p[I,0],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][1][9,0]*r[J][0][12,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3I9J12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,3),(I,9),(J,12)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[A,0],p[B,1],p[J,0],p[I,0])]*r[A][0][0,9]*r[B][5][3,12]*r[I][1][9,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[A,0],p[I,0],p[J,0],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][1][9,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[J,0],p[B,1],p[A,0],p[I,0])]*r[A][0][0,9]*r[B][5][3,12]*r[I][1][9,0]*r[J][0][12,0]
            hv += 1/4*g[dei(p[J,0],p[I,0],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][1][9,0]*r[J][0][12,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2I7J14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,2),(I,7),(J,14)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,0],p[B,1],p[J,0],p[I,0])]*r[A][0][0,9]*r[B][5][2,12]*r[I][3][7,0]*r[J][2][14,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3I7J14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,3),(I,7),(J,14)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,0],p[B,1],p[J,0],p[I,0])]*r[A][0][0,9]*r[B][5][3,12]*r[I][3][7,0]*r[J][2][14,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2I10J12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,2),(I,10),(J,12)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[A,0],p[B,1],p[J,0],p[I,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][5][10,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[A,0],p[I,1],p[J,0],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][5][10,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[J,0],p[B,1],p[A,0],p[I,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][5][10,0]*r[J][0][12,0]
            hv += 1/4*g[dei(p[J,0],p[I,1],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][5][10,0]*r[J][0][12,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3I10J12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,3),(I,10),(J,12)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[A,0],p[B,1],p[J,0],p[I,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][5][10,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[A,0],p[I,1],p[J,0],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][5][10,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[J,0],p[B,1],p[A,0],p[I,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][5][10,0]*r[J][0][12,0]
            hv += 1/4*g[dei(p[J,0],p[I,1],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][5][10,0]*r[J][0][12,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2I8J14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,2),(I,8),(J,14)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,0],p[B,1],p[J,0],p[I,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][7][8,0]*r[J][2][14,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3I8J14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,3),(I,8),(J,14)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,0],p[B,1],p[J,0],p[I,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][7][8,0]*r[J][2][14,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _I9J11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(I,9),(J,11)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[A,0],p[B,0],p[J,1],p[I,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[A,0],p[I,0],p[J,1],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[J,1],p[B,0],p[A,0],p[I,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][4][11,0]
            hv += 1/4*g[dei(p[J,1],p[I,0],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][4][11,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1I9J11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,1),(I,9),(J,11)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[A,0],p[B,0],p[J,1],p[I,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][1][9,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[A,0],p[I,0],p[J,1],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][1][9,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[J,1],p[B,0],p[A,0],p[I,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][1][9,0]*r[J][4][11,0]
            hv += 1/4*g[dei(p[J,1],p[I,0],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][1][9,0]*r[J][4][11,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I9J11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,1),(I,9),(J,11)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[A,0],p[B,0],p[J,1],p[I,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[A,0],p[I,0],p[J,1],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[J,1],p[B,0],p[A,0],p[I,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][4][11,0]
            hv += 1/4*g[dei(p[J,1],p[I,0],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][4][11,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _I7J13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(I,7),(J,13)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,0],p[B,0],p[J,1],p[I,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][3][7,0]*r[J][6][13,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1I7J13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,1),(I,7),(J,13)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,0],p[B,0],p[J,1],p[I,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][3][7,0]*r[J][6][13,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I7J13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,1),(I,7),(J,13)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,0],p[B,0],p[J,1],p[I,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][3][7,0]*r[J][6][13,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _I10J11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(I,10),(J,11)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[A,0],p[B,0],p[J,1],p[I,1])]*r[A][0][0,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[A,0],p[I,1],p[J,1],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[J,1],p[B,0],p[A,0],p[I,1])]*r[A][0][0,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][4][11,0]
            hv += 1/4*g[dei(p[J,1],p[I,1],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][4][11,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1I10J11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,1),(I,10),(J,11)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[A,0],p[B,0],p[J,1],p[I,1])]*r[A][0][0,9]*r[B][1][1,12]*r[I][5][10,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[A,0],p[I,1],p[J,1],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][5][10,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[J,1],p[B,0],p[A,0],p[I,1])]*r[A][0][0,9]*r[B][1][1,12]*r[I][5][10,0]*r[J][4][11,0]
            hv += 1/4*g[dei(p[J,1],p[I,1],p[A,0],p[B,0])]*r[A][0][0,9]*r[B][1][1,12]*r[I][5][10,0]*r[J][4][11,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I10J11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,1),(I,10),(J,11)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[A,0],p[B,0],p[J,1],p[I,1])]*r[A][0][1,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[A,0],p[I,1],p[J,1],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[J,1],p[B,0],p[A,0],p[I,1])]*r[A][0][1,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][4][11,0]
            hv += 1/4*g[dei(p[J,1],p[I,1],p[A,0],p[B,0])]*r[A][0][1,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][4][11,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _I8J13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(I,8),(J,13)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,0],p[B,0],p[J,1],p[I,1])]*r[A][0][0,9]*r[B][1][0,12]*r[I][7][8,0]*r[J][6][13,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B1I8J13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,1),(I,8),(J,13)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,0],p[B,0],p[J,1],p[I,1])]*r[A][0][0,9]*r[B][1][1,12]*r[I][7][8,0]*r[J][6][13,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A1I8J13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,1),(I,8),(J,13)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,0],p[B,0],p[J,1],p[I,1])]*r[A][0][1,9]*r[B][1][0,12]*r[I][7][8,0]*r[J][6][13,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2I9J11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,2),(I,9),(J,11)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[A,0],p[B,1],p[J,1],p[I,0])]*r[A][0][0,9]*r[B][5][2,12]*r[I][1][9,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[A,0],p[I,0],p[J,1],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][1][9,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[J,1],p[B,1],p[A,0],p[I,0])]*r[A][0][0,9]*r[B][5][2,12]*r[I][1][9,0]*r[J][4][11,0]
            hv += 1/4*g[dei(p[J,1],p[I,0],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][1][9,0]*r[J][4][11,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3I9J11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,3),(I,9),(J,11)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[A,0],p[B,1],p[J,1],p[I,0])]*r[A][0][0,9]*r[B][5][3,12]*r[I][1][9,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[A,0],p[I,0],p[J,1],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][1][9,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[J,1],p[B,1],p[A,0],p[I,0])]*r[A][0][0,9]*r[B][5][3,12]*r[I][1][9,0]*r[J][4][11,0]
            hv += 1/4*g[dei(p[J,1],p[I,0],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][1][9,0]*r[J][4][11,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2I7J13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,2),(I,7),(J,13)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,0],p[B,1],p[J,1],p[I,0])]*r[A][0][0,9]*r[B][5][2,12]*r[I][3][7,0]*r[J][6][13,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3I7J13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,3),(I,7),(J,13)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,0],p[B,1],p[J,1],p[I,0])]*r[A][0][0,9]*r[B][5][3,12]*r[I][3][7,0]*r[J][6][13,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2I10J11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,2),(I,10),(J,11)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[A,0],p[B,1],p[J,1],p[I,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][5][10,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[A,0],p[I,1],p[J,1],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][5][10,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[J,1],p[B,1],p[A,0],p[I,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][5][10,0]*r[J][4][11,0]
            hv += 1/4*g[dei(p[J,1],p[I,1],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][5][10,0]*r[J][4][11,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3I10J11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,3),(I,10),(J,11)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[A,0],p[B,1],p[J,1],p[I,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][5][10,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[A,0],p[I,1],p[J,1],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][5][10,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[J,1],p[B,1],p[A,0],p[I,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][5][10,0]*r[J][4][11,0]
            hv += 1/4*g[dei(p[J,1],p[I,1],p[A,0],p[B,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][5][10,0]*r[J][4][11,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B2I8J13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,2),(I,8),(J,13)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,0],p[B,1],p[J,1],p[I,1])]*r[A][0][0,9]*r[B][5][2,12]*r[I][7][8,0]*r[J][6][13,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B3I8J13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,3),(I,8),(J,13)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,0],p[B,1],p[J,1],p[I,1])]*r[A][0][0,9]*r[B][5][3,12]*r[I][7][8,0]*r[J][6][13,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2I9J12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,2),(I,9),(J,12)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[A,1],p[B,0],p[J,0],p[I,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[A,1],p[I,0],p[J,0],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[J,0],p[B,0],p[A,1],p[I,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][0][12,0]
            hv += 1/4*g[dei(p[J,0],p[I,0],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][0][12,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I9J12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,3),(I,9),(J,12)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[A,1],p[B,0],p[J,0],p[I,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[A,1],p[I,0],p[J,0],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[J,0],p[B,0],p[A,1],p[I,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][0][12,0]
            hv += 1/4*g[dei(p[J,0],p[I,0],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][0][12,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2I7J14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,2),(I,7),(J,14)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,1],p[B,0],p[J,0],p[I,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][3][7,0]*r[J][2][14,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I7J14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,3),(I,7),(J,14)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,1],p[B,0],p[J,0],p[I,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][3][7,0]*r[J][2][14,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2I10J12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,2),(I,10),(J,12)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[A,1],p[B,0],p[J,0],p[I,1])]*r[A][4][2,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[A,1],p[I,1],p[J,0],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[J,0],p[B,0],p[A,1],p[I,1])]*r[A][4][2,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][0][12,0]
            hv += 1/4*g[dei(p[J,0],p[I,1],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][0][12,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I10J12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,3),(I,10),(J,12)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[A,1],p[B,0],p[J,0],p[I,1])]*r[A][4][3,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[A,1],p[I,1],p[J,0],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][0][12,0]
            hv += -1/4*g[dei(p[J,0],p[B,0],p[A,1],p[I,1])]*r[A][4][3,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][0][12,0]
            hv += 1/4*g[dei(p[J,0],p[I,1],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][0][12,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2I8J14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,2),(I,8),(J,14)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,1],p[B,0],p[J,0],p[I,1])]*r[A][4][2,9]*r[B][1][0,12]*r[I][7][8,0]*r[J][2][14,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I8J14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,3),(I,8),(J,14)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,1],p[B,0],p[J,0],p[I,1])]*r[A][4][3,9]*r[B][1][0,12]*r[I][7][8,0]*r[J][2][14,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2I9J11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,2),(I,9),(J,11)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[A,1],p[B,0],p[J,1],p[I,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[A,1],p[I,0],p[J,1],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[J,1],p[B,0],p[A,1],p[I,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][4][11,0]
            hv += 1/4*g[dei(p[J,1],p[I,0],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][4][11,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I9J11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,3),(I,9),(J,11)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[A,1],p[B,0],p[J,1],p[I,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[A,1],p[I,0],p[J,1],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[J,1],p[B,0],p[A,1],p[I,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][4][11,0]
            hv += 1/4*g[dei(p[J,1],p[I,0],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][1][9,0]*r[J][4][11,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2I7J13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,2),(I,7),(J,13)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,1],p[B,0],p[J,1],p[I,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][3][7,0]*r[J][6][13,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I7J13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,3),(I,7),(J,13)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,1],p[B,0],p[J,1],p[I,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][3][7,0]*r[J][6][13,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2I10J11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,2),(I,10),(J,11)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[A,1],p[B,0],p[J,1],p[I,1])]*r[A][4][2,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[A,1],p[I,1],p[J,1],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[J,1],p[B,0],p[A,1],p[I,1])]*r[A][4][2,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][4][11,0]
            hv += 1/4*g[dei(p[J,1],p[I,1],p[A,1],p[B,0])]*r[A][4][2,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][4][11,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I10J11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,3),(I,10),(J,11)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/4*g[dei(p[A,1],p[B,0],p[J,1],p[I,1])]*r[A][4][3,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[A,1],p[I,1],p[J,1],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][4][11,0]
            hv += -1/4*g[dei(p[J,1],p[B,0],p[A,1],p[I,1])]*r[A][4][3,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][4][11,0]
            hv += 1/4*g[dei(p[J,1],p[I,1],p[A,1],p[B,0])]*r[A][4][3,9]*r[B][1][0,12]*r[I][5][10,0]*r[J][4][11,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A2I8J13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,2),(I,8),(J,13)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,1],p[B,0],p[J,1],p[I,1])]*r[A][4][2,9]*r[B][1][0,12]*r[I][7][8,0]*r[J][6][13,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A3I8J13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,3),(I,8),(J,13)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[A,1],p[B,0],p[J,1],p[I,1])]*r[A][4][3,9]*r[B][1][0,12]*r[I][7][8,0]*r[J][6][13,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B4I9J14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,4),(I,9),(J,14)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,0],p[I,0],p[J,0],p[B,1])]*r[A][0][0,9]*r[B][7][4,12]*r[I][1][9,0]*r[J][2][14,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B4I10J14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,4),(I,10),(J,14)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,0],p[I,1],p[J,0],p[B,1])]*r[A][0][0,9]*r[B][7][4,12]*r[I][5][10,0]*r[J][2][14,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B4I9J13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,4),(I,9),(J,13)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,0],p[I,0],p[J,1],p[B,1])]*r[A][0][0,9]*r[B][7][4,12]*r[I][1][9,0]*r[J][6][13,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _B4I10J13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(B,4),(I,10),(J,13)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[A,0],p[I,1],p[J,1],p[B,1])]*r[A][0][0,9]*r[B][7][4,12]*r[I][5][10,0]*r[J][6][13,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5I12J7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,5),(I,12),(J,7)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[I,0],p[B,0],p[A,1],p[J,0])]*r[A][6][5,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][3][7,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5I12J8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,5),(I,12),(J,8)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[I,0],p[B,0],p[A,1],p[J,1])]*r[A][6][5,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][7][8,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5I11J7(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,5),(I,11),(J,7)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[I,1],p[B,0],p[A,1],p[J,0])]*r[A][6][5,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][3][7,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5I11J8(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,5),(I,11),(J,8)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[I,1],p[B,0],p[A,1],p[J,1])]*r[A][6][5,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][7][8,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6I12J14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,6),(I,12),(J,14)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[I,0],p[B,0],p[J,0],p[A,0])]*r[A][3][6,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][2][14,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6I12J13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,6),(I,12),(J,13)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[I,0],p[B,0],p[J,1],p[A,0])]*r[A][3][6,9]*r[B][1][0,12]*r[I][0][12,0]*r[J][6][13,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6I11J14(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,6),(I,11),(J,14)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[I,1],p[B,0],p[J,0],p[A,0])]*r[A][3][6,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][2][14,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6I11J13(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,6),(I,11),(J,13)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[I,1],p[B,0],p[J,1],p[A,0])]*r[A][3][6,9]*r[B][1][0,12]*r[I][4][11,0]*r[J][6][13,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5I7J12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,5),(I,7),(J,12)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[J,0],p[B,0],p[A,1],p[I,0])]*r[A][6][5,9]*r[B][1][0,12]*r[I][3][7,0]*r[J][0][12,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5I8J12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,5),(I,8),(J,12)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[J,0],p[B,0],p[A,1],p[I,1])]*r[A][6][5,9]*r[B][1][0,12]*r[I][7][8,0]*r[J][0][12,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5I7J11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,5),(I,7),(J,11)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[J,1],p[B,0],p[A,1],p[I,0])]*r[A][6][5,9]*r[B][1][0,12]*r[I][3][7,0]*r[J][4][11,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A5I8J11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,5),(I,8),(J,11)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += -1/2*g[dei(p[J,1],p[B,0],p[A,1],p[I,1])]*r[A][6][5,9]*r[B][1][0,12]*r[I][7][8,0]*r[J][4][11,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6I14J12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,6),(I,14),(J,12)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[J,0],p[B,0],p[I,0],p[A,0])]*r[A][3][6,9]*r[B][1][0,12]*r[I][2][14,0]*r[J][0][12,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6I13J12(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,6),(I,13),(J,12)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[J,0],p[B,0],p[I,1],p[A,0])]*r[A][3][6,9]*r[B][1][0,12]*r[I][6][13,0]*r[J][0][12,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6I14J11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,6),(I,14),(J,11)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[J,1],p[B,0],p[I,0],p[A,0])]*r[A][3][6,9]*r[B][1][0,12]*r[I][2][14,0]*r[J][4][11,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def _A6I13J11(A, B, r, h, g, p, nc):
    np = len(p)
    hd = {}
    sbra = sign([A,B])
    
    for I in range(nc, np):
        if I in {A,B}: continue
        for J in range(nc, np):
            if J in {A,B,I}: continue
            v = tuple(sorted([(A,6),(I,13),(J,11)]))
            hv = 0.0
            sket = sign([I,J])
            
            hv += 1/2*g[dei(p[J,1],p[B,0],p[I,1],p[A,0])]*r[A][3][6,9]*r[B][1][0,12]*r[I][6][13,0]*r[J][4][11,0]
            
            hd[v] = hd.get(v,0.0)+sket*hv
            
    if sbra is -1:
        for v,h in hd.items(): hd[v] = -h
    
    return hd
    
def hm_A9B12(r, h, g, p, nc=0):
    np=len(p)
    hdd = {}
    
    for A in range(nc, np):
        for B in range(nc, np):
            if B in {A}: continue
            u = tuple(sorted([(A,9),(B,12)]))
            
            hd = {}
            for v,hv in _A9B12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9B12I1(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9B12I2(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9B12I3(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A10B12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9B11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B12I9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1B12I9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B12I10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1B12I10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2B12I9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3B12I9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A5B12I7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2B12I10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3B12I10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A5B12I8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A6B12I14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A6B12I13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A13B12I6(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A14B12I6(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A10B12I1(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A10B12I2(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A10B12I3(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A7B12I5(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A8B12I5(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9B15I7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9B15I8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9I12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9B1I12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9B2I12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9B3I12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9B4I14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9I11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9B1I11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9B2I11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9B3I11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9B4I13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9B11I1(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9B11I2(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9B11I3(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9B14I4(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9B13I4(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9B8I15(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9B7I15(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B1(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1B1(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B2(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B3(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1B2(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1B3(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2B1(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3B1(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2B2(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2B3(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3B2(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3B3(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A5B4(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A6B15(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A11B10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A13B8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A13B7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A14B8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A14B7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A10B11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A7B14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A7B13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A8B14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A8B13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B12I1J9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B12I1J10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B12I2J9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B12I3J9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B12I5J7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B12I2J10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B12I3J10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B12I5J8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B12I14J6(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B12I13J6(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B12I6J14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B12I6J13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B12I9J1(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B12I9J2(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B12I9J3(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B12I10J1(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B12I10J2(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B12I10J3(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B12I7J5(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B12I8J5(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9I15J7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9I15J8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9I1J12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9I2J12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9I3J12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9I4J14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9I1J11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9I2J11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9I3J11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9I4J13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9I12J1(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9I12J2(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9I12J3(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9I11J1(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9I11J2(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9I11J3(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9I14J4(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9I13J4(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9I7J15(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A9I8J15(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A11I9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A11B1I9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A13I7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A13B1I7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A11I10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A11B1I10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A13I8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A13B1I8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A11B2I9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A11B3I9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A13B2I7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A13B3I7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A11B2I10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A11B3I10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A13B2I8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A13B3I8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A14I7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A14B1I7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A14I8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A14B1I8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A14B2I7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A14B3I7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A14B2I8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A14B3I8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A13B4I9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A13B4I10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A14B4I9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A14B4I10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A10B15I7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A10B15I8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B14I7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1B14I7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B14I8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1B14I8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B13I7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1B13I7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B13I8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1B13I8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2B14I7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3B14I7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2B14I8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3B14I8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A5B11I7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2B13I7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3B13I7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A5B11I8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2B13I8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3B13I8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A7B15I9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A7B15I10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A8B15I9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A8B15I10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B11I9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1B11I9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B11I10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1B11I10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2B11I9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3B11I9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2B11I10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3B11I10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B15I6(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1B15I6(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2B15I6(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3B15I6(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A10B4I14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A10B4I13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A7I14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A7B1I14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A7B2I14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A7B3I14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A7I13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A7B1I13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A7B2I13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A7B3I13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A8I14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A8B1I14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A8B2I14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A8B3I14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A8I13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A8B1I13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A8B2I13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A8B3I13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B10I12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1B10I12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B8I14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1B8I14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B7I14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1B7I14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B10I11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1B10I11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B8I13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1B8I13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B7I13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1B7I13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2B10I12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3B10I12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2B8I14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3B8I14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2B7I14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3B7I14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2B10I11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3B10I11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2B8I13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3B8I13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2B7I13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3B7I13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _I1(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B1I1(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1I1(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1B1I1(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _I2(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _I3(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B1I2(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B1I3(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1I2(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1I3(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1B1I2(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1B1I3(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B2I1(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B3I1(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1B2I1(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1B3I1(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B2I2(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B2I3(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B3I2(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B3I3(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1B2I2(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1B2I3(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1B3I2(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1B3I3(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2I1(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2B1I1(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3I1(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3B1I1(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2I2(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2I3(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2B1I2(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2B1I3(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3I2(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3I3(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3B1I2(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3B1I3(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2B2I1(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2B3I1(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3B2I1(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3B3I1(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A5B4I1(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2B2I2(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2B2I3(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2B3I2(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2B3I3(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3B2I2(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3B2I3(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3B3I2(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3B3I3(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A5B4I2(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A5B4I3(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B4I5(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1B4I5(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2B4I5(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3B4I5(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A6B11I14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A6B11I13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A6B15I1(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A6B15I2(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A6B15I3(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A10I12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A10B1I12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A10B2I12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A10B3I12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A10I11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A10B1I11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A10B2I11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A10B3I11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A5B8I12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A5B7I12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A5B8I11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A5B7I11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A5I4(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A5B1I4(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A5B2I4(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A5B3I4(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A6B14I12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A6B13I12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A6B14I11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A6B13I11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A6I15(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A6B1I15(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A6B2I15(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A6B3I15(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B15I9J7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B15I9J8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B15I10J7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B15I10J8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B15I7J9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B15I8J9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B15I7J10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B15I8J10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _I12J9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B1I12J9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1I12J9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _I14J7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B1I14J7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1I14J7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _I12J10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B1I12J10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1I12J10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _I14J8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B1I14J8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1I14J8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B2I12J9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B3I12J9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B2I14J7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B3I14J7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B2I12J10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B3I12J10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B2I14J8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B3I14J8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _I11J9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B1I11J9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1I11J9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _I13J7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B1I13J7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1I13J7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _I11J10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B1I11J10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1I11J10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _I13J8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B1I13J8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1I13J8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B2I11J9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B3I11J9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B2I13J7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B3I13J7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B2I11J10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B3I11J10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B2I13J8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B3I13J8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2I12J9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3I12J9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2I14J7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3I14J7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2I12J10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3I12J10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2I14J8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3I14J8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2I11J9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3I11J9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2I13J7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3I13J7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2I11J10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3I11J10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2I13J8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3I13J8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B4I14J9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B4I14J10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B4I13J9(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B4I13J10(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _I9J12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B1I9J12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1I9J12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _I7J14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B1I7J14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1I7J14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _I10J12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B1I10J12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1I10J12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _I8J14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B1I8J14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1I8J14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B2I9J12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B3I9J12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B2I7J14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B3I7J14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B2I10J12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B3I10J12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B2I8J14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B3I8J14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _I9J11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B1I9J11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1I9J11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _I7J13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B1I7J13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1I7J13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _I10J11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B1I10J11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1I10J11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _I8J13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B1I8J13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A1I8J13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B2I9J11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B3I9J11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B2I7J13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B3I7J13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B2I10J11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B3I10J11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B2I8J13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B3I8J13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2I9J12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3I9J12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2I7J14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3I7J14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2I10J12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3I10J12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2I8J14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3I8J14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2I9J11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3I9J11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2I7J13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3I7J13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2I10J11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3I10J11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A2I8J13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A3I8J13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B4I9J14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B4I10J14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B4I9J13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _B4I10J13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A5I12J7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A5I12J8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A5I11J7(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A5I11J8(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A6I12J14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A6I12J13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A6I11J14(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A6I11J13(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A5I7J12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A5I8J12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A5I7J11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A5I8J11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A6I14J12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A6I13J12(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A6I14J11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            for v,hv in _A6I13J11(A, B, r, h, g, p, nc).items(): hd[v] = hd.get(v,0.0)+hv
            
            hdd[u] = hd
            
    return hdd
    

