#!/usr/bin/env python 
# -*- coding: utf-8 -*- 
#
#      Copyright:   Qingchun Wang @ NJU
#      File Name:   ta.py
#            Des:   ta
#           Mail:   qingchun720@foxmail.com
#   Created Time:   Fri 22:38:57 Sep/27 2019
#


__version__ = '1.0'
__author__ = 'Qingchun Wang'


# from multiprocessing import Pool, Manager
from copy import deepcopy
from datetime import datetime
from bccc.pub import sign
from itertools import permutations


def ta(t0, h, p, nt=4, nc=0):
    # bra wavefunction list
    # ground state
    from bccc.ta.ta_ import ta_
    
    # 1-block excited types
    from bccc.ta.ta_A1 import ta_A1
    from bccc.ta.ta_A2 import ta_A2
    from bccc.ta.ta_A3 import ta_A3
    brafl = (
             ta_A1, ta_A2, ta_A3,              
             )
    
    # 2-block excited types
    if nt>1: 
        from bccc.ta.ta_A1B1 import ta_A1B1
        from bccc.ta.ta_A1B2 import ta_A1B2
        from bccc.ta.ta_A1B3 import ta_A1B3
        from bccc.ta.ta_A2B1 import ta_A2B1
        from bccc.ta.ta_A2B2 import ta_A2B2
        from bccc.ta.ta_A2B3 import ta_A2B3
        from bccc.ta.ta_A3B1 import ta_A3B1
        from bccc.ta.ta_A3B2 import ta_A3B2
        from bccc.ta.ta_A3B3 import ta_A3B3
        from bccc.ta.ta_A4B5 import ta_A4B5
        from bccc.ta.ta_A5B4 import ta_A5B4
        from bccc.ta.ta_A6B15 import ta_A6B15
        from bccc.ta.ta_A7B13 import ta_A7B13
        from bccc.ta.ta_A7B14 import ta_A7B14
        from bccc.ta.ta_A8B13 import ta_A8B13
        from bccc.ta.ta_A8B14 import ta_A8B14
        from bccc.ta.ta_A9B11 import ta_A9B11
        from bccc.ta.ta_A9B12 import ta_A9B12
        from bccc.ta.ta_A10B11 import ta_A10B11
        from bccc.ta.ta_A10B12 import ta_A10B12
        from bccc.ta.ta_A11B9 import ta_A11B9
        from bccc.ta.ta_A11B10 import ta_A11B10
        from bccc.ta.ta_A12B9 import ta_A12B9
        from bccc.ta.ta_A12B10 import ta_A12B10
        from bccc.ta.ta_A13B7 import ta_A13B7
        from bccc.ta.ta_A13B8 import ta_A13B8
        from bccc.ta.ta_A14B7 import ta_A14B7
        from bccc.ta.ta_A14B8 import ta_A14B8
        from bccc.ta.ta_A15B6 import ta_A15B6
        brafl += (
                 ta_A1B1, ta_A1B2, ta_A1B3, ta_A2B1, ta_A2B2, 
                 ta_A2B3, ta_A3B1, ta_A3B2, ta_A3B3, ta_A4B5, 
                 ta_A5B4, ta_A6B15, ta_A7B13, ta_A7B14, ta_A8B13, 
                 ta_A8B14, ta_A9B11, ta_A9B12, ta_A10B11, ta_A10B12, 
                 ta_A11B9, ta_A11B10, ta_A12B9, ta_A12B10, ta_A13B7, 
                 ta_A13B8, ta_A14B7, ta_A14B8, ta_A15B6,                  
                 )
        
    # 3-block excited types
    if nt>2: 
        from bccc.ta.ta_A1B1C1 import ta_A1B1C1
        from bccc.ta.ta_A1B1C2 import ta_A1B1C2
        from bccc.ta.ta_A1B1C3 import ta_A1B1C3
        from bccc.ta.ta_A1B2C1 import ta_A1B2C1
        from bccc.ta.ta_A1B2C2 import ta_A1B2C2
        from bccc.ta.ta_A1B2C3 import ta_A1B2C3
        from bccc.ta.ta_A1B3C1 import ta_A1B3C1
        from bccc.ta.ta_A1B3C2 import ta_A1B3C2
        from bccc.ta.ta_A1B3C3 import ta_A1B3C3
        from bccc.ta.ta_A1B4C5 import ta_A1B4C5
        from bccc.ta.ta_A1B5C4 import ta_A1B5C4
        from bccc.ta.ta_A1B6C15 import ta_A1B6C15
        from bccc.ta.ta_A1B7C13 import ta_A1B7C13
        from bccc.ta.ta_A1B7C14 import ta_A1B7C14
        from bccc.ta.ta_A1B8C13 import ta_A1B8C13
        from bccc.ta.ta_A1B8C14 import ta_A1B8C14
        from bccc.ta.ta_A1B9C11 import ta_A1B9C11
        from bccc.ta.ta_A1B9C12 import ta_A1B9C12
        from bccc.ta.ta_A1B10C11 import ta_A1B10C11
        from bccc.ta.ta_A1B10C12 import ta_A1B10C12
        from bccc.ta.ta_A1B11C9 import ta_A1B11C9
        from bccc.ta.ta_A1B11C10 import ta_A1B11C10
        from bccc.ta.ta_A1B12C9 import ta_A1B12C9
        from bccc.ta.ta_A1B12C10 import ta_A1B12C10
        from bccc.ta.ta_A1B13C7 import ta_A1B13C7
        from bccc.ta.ta_A1B13C8 import ta_A1B13C8
        from bccc.ta.ta_A1B14C7 import ta_A1B14C7
        from bccc.ta.ta_A1B14C8 import ta_A1B14C8
        from bccc.ta.ta_A1B15C6 import ta_A1B15C6
        from bccc.ta.ta_A2B1C1 import ta_A2B1C1
        from bccc.ta.ta_A2B1C2 import ta_A2B1C2
        from bccc.ta.ta_A2B1C3 import ta_A2B1C3
        from bccc.ta.ta_A2B2C1 import ta_A2B2C1
        from bccc.ta.ta_A2B2C2 import ta_A2B2C2
        from bccc.ta.ta_A2B2C3 import ta_A2B2C3
        from bccc.ta.ta_A2B3C1 import ta_A2B3C1
        from bccc.ta.ta_A2B3C2 import ta_A2B3C2
        from bccc.ta.ta_A2B3C3 import ta_A2B3C3
        from bccc.ta.ta_A2B4C5 import ta_A2B4C5
        from bccc.ta.ta_A2B5C4 import ta_A2B5C4
        from bccc.ta.ta_A2B6C15 import ta_A2B6C15
        from bccc.ta.ta_A2B7C13 import ta_A2B7C13
        from bccc.ta.ta_A2B7C14 import ta_A2B7C14
        from bccc.ta.ta_A2B8C13 import ta_A2B8C13
        from bccc.ta.ta_A2B8C14 import ta_A2B8C14
        from bccc.ta.ta_A2B9C11 import ta_A2B9C11
        from bccc.ta.ta_A2B9C12 import ta_A2B9C12
        from bccc.ta.ta_A2B10C11 import ta_A2B10C11
        from bccc.ta.ta_A2B10C12 import ta_A2B10C12
        from bccc.ta.ta_A2B11C9 import ta_A2B11C9
        from bccc.ta.ta_A2B11C10 import ta_A2B11C10
        from bccc.ta.ta_A2B12C9 import ta_A2B12C9
        from bccc.ta.ta_A2B12C10 import ta_A2B12C10
        from bccc.ta.ta_A2B13C7 import ta_A2B13C7
        from bccc.ta.ta_A2B13C8 import ta_A2B13C8
        from bccc.ta.ta_A2B14C7 import ta_A2B14C7
        from bccc.ta.ta_A2B14C8 import ta_A2B14C8
        from bccc.ta.ta_A2B15C6 import ta_A2B15C6
        from bccc.ta.ta_A3B1C1 import ta_A3B1C1
        from bccc.ta.ta_A3B1C2 import ta_A3B1C2
        from bccc.ta.ta_A3B1C3 import ta_A3B1C3
        from bccc.ta.ta_A3B2C1 import ta_A3B2C1
        from bccc.ta.ta_A3B2C2 import ta_A3B2C2
        from bccc.ta.ta_A3B2C3 import ta_A3B2C3
        from bccc.ta.ta_A3B3C1 import ta_A3B3C1
        from bccc.ta.ta_A3B3C2 import ta_A3B3C2
        from bccc.ta.ta_A3B3C3 import ta_A3B3C3
        from bccc.ta.ta_A3B4C5 import ta_A3B4C5
        from bccc.ta.ta_A3B5C4 import ta_A3B5C4
        from bccc.ta.ta_A3B6C15 import ta_A3B6C15
        from bccc.ta.ta_A3B7C13 import ta_A3B7C13
        from bccc.ta.ta_A3B7C14 import ta_A3B7C14
        from bccc.ta.ta_A3B8C13 import ta_A3B8C13
        from bccc.ta.ta_A3B8C14 import ta_A3B8C14
        from bccc.ta.ta_A3B9C11 import ta_A3B9C11
        from bccc.ta.ta_A3B9C12 import ta_A3B9C12
        from bccc.ta.ta_A3B10C11 import ta_A3B10C11
        from bccc.ta.ta_A3B10C12 import ta_A3B10C12
        from bccc.ta.ta_A3B11C9 import ta_A3B11C9
        from bccc.ta.ta_A3B11C10 import ta_A3B11C10
        from bccc.ta.ta_A3B12C9 import ta_A3B12C9
        from bccc.ta.ta_A3B12C10 import ta_A3B12C10
        from bccc.ta.ta_A3B13C7 import ta_A3B13C7
        from bccc.ta.ta_A3B13C8 import ta_A3B13C8
        from bccc.ta.ta_A3B14C7 import ta_A3B14C7
        from bccc.ta.ta_A3B14C8 import ta_A3B14C8
        from bccc.ta.ta_A3B15C6 import ta_A3B15C6
        from bccc.ta.ta_A4B1C5 import ta_A4B1C5
        from bccc.ta.ta_A4B2C5 import ta_A4B2C5
        from bccc.ta.ta_A4B3C5 import ta_A4B3C5
        from bccc.ta.ta_A4B5C1 import ta_A4B5C1
        from bccc.ta.ta_A4B5C2 import ta_A4B5C2
        from bccc.ta.ta_A4B5C3 import ta_A4B5C3
        from bccc.ta.ta_A4B9C13 import ta_A4B9C13
        from bccc.ta.ta_A4B9C14 import ta_A4B9C14
        from bccc.ta.ta_A4B10C13 import ta_A4B10C13
        from bccc.ta.ta_A4B10C14 import ta_A4B10C14
        from bccc.ta.ta_A4B13C9 import ta_A4B13C9
        from bccc.ta.ta_A4B13C10 import ta_A4B13C10
        from bccc.ta.ta_A4B14C9 import ta_A4B14C9
        from bccc.ta.ta_A4B14C10 import ta_A4B14C10
        from bccc.ta.ta_A5B1C4 import ta_A5B1C4
        from bccc.ta.ta_A5B2C4 import ta_A5B2C4
        from bccc.ta.ta_A5B3C4 import ta_A5B3C4
        from bccc.ta.ta_A5B4C1 import ta_A5B4C1
        from bccc.ta.ta_A5B4C2 import ta_A5B4C2
        from bccc.ta.ta_A5B4C3 import ta_A5B4C3
        from bccc.ta.ta_A5B7C11 import ta_A5B7C11
        from bccc.ta.ta_A5B7C12 import ta_A5B7C12
        from bccc.ta.ta_A5B8C11 import ta_A5B8C11
        from bccc.ta.ta_A5B8C12 import ta_A5B8C12
        from bccc.ta.ta_A5B11C7 import ta_A5B11C7
        from bccc.ta.ta_A5B11C8 import ta_A5B11C8
        from bccc.ta.ta_A5B12C7 import ta_A5B12C7
        from bccc.ta.ta_A5B12C8 import ta_A5B12C8
        from bccc.ta.ta_A6B1C15 import ta_A6B1C15
        from bccc.ta.ta_A6B2C15 import ta_A6B2C15
        from bccc.ta.ta_A6B3C15 import ta_A6B3C15
        from bccc.ta.ta_A6B11C13 import ta_A6B11C13
        from bccc.ta.ta_A6B11C14 import ta_A6B11C14
        from bccc.ta.ta_A6B12C13 import ta_A6B12C13
        from bccc.ta.ta_A6B12C14 import ta_A6B12C14
        from bccc.ta.ta_A6B13C11 import ta_A6B13C11
        from bccc.ta.ta_A6B13C12 import ta_A6B13C12
        from bccc.ta.ta_A6B14C11 import ta_A6B14C11
        from bccc.ta.ta_A6B14C12 import ta_A6B14C12
        from bccc.ta.ta_A6B15C1 import ta_A6B15C1
        from bccc.ta.ta_A6B15C2 import ta_A6B15C2
        from bccc.ta.ta_A6B15C3 import ta_A6B15C3
        from bccc.ta.ta_A7B1C13 import ta_A7B1C13
        from bccc.ta.ta_A7B1C14 import ta_A7B1C14
        from bccc.ta.ta_A7B2C13 import ta_A7B2C13
        from bccc.ta.ta_A7B2C14 import ta_A7B2C14
        from bccc.ta.ta_A7B3C13 import ta_A7B3C13
        from bccc.ta.ta_A7B3C14 import ta_A7B3C14
        from bccc.ta.ta_A7B5C11 import ta_A7B5C11
        from bccc.ta.ta_A7B5C12 import ta_A7B5C12
        from bccc.ta.ta_A7B9C15 import ta_A7B9C15
        from bccc.ta.ta_A7B10C15 import ta_A7B10C15
        from bccc.ta.ta_A7B11C5 import ta_A7B11C5
        from bccc.ta.ta_A7B12C5 import ta_A7B12C5
        from bccc.ta.ta_A7B13C1 import ta_A7B13C1
        from bccc.ta.ta_A7B13C2 import ta_A7B13C2
        from bccc.ta.ta_A7B13C3 import ta_A7B13C3
        from bccc.ta.ta_A7B14C1 import ta_A7B14C1
        from bccc.ta.ta_A7B14C2 import ta_A7B14C2
        from bccc.ta.ta_A7B14C3 import ta_A7B14C3
        from bccc.ta.ta_A7B15C9 import ta_A7B15C9
        from bccc.ta.ta_A7B15C10 import ta_A7B15C10
        from bccc.ta.ta_A8B1C13 import ta_A8B1C13
        from bccc.ta.ta_A8B1C14 import ta_A8B1C14
        from bccc.ta.ta_A8B2C13 import ta_A8B2C13
        from bccc.ta.ta_A8B2C14 import ta_A8B2C14
        from bccc.ta.ta_A8B3C13 import ta_A8B3C13
        from bccc.ta.ta_A8B3C14 import ta_A8B3C14
        from bccc.ta.ta_A8B5C11 import ta_A8B5C11
        from bccc.ta.ta_A8B5C12 import ta_A8B5C12
        from bccc.ta.ta_A8B9C15 import ta_A8B9C15
        from bccc.ta.ta_A8B10C15 import ta_A8B10C15
        from bccc.ta.ta_A8B11C5 import ta_A8B11C5
        from bccc.ta.ta_A8B12C5 import ta_A8B12C5
        from bccc.ta.ta_A8B13C1 import ta_A8B13C1
        from bccc.ta.ta_A8B13C2 import ta_A8B13C2
        from bccc.ta.ta_A8B13C3 import ta_A8B13C3
        from bccc.ta.ta_A8B14C1 import ta_A8B14C1
        from bccc.ta.ta_A8B14C2 import ta_A8B14C2
        from bccc.ta.ta_A8B14C3 import ta_A8B14C3
        from bccc.ta.ta_A8B15C9 import ta_A8B15C9
        from bccc.ta.ta_A8B15C10 import ta_A8B15C10
        from bccc.ta.ta_A9B1C11 import ta_A9B1C11
        from bccc.ta.ta_A9B1C12 import ta_A9B1C12
        from bccc.ta.ta_A9B2C11 import ta_A9B2C11
        from bccc.ta.ta_A9B2C12 import ta_A9B2C12
        from bccc.ta.ta_A9B3C11 import ta_A9B3C11
        from bccc.ta.ta_A9B3C12 import ta_A9B3C12
        from bccc.ta.ta_A9B4C13 import ta_A9B4C13
        from bccc.ta.ta_A9B4C14 import ta_A9B4C14
        from bccc.ta.ta_A9B7C15 import ta_A9B7C15
        from bccc.ta.ta_A9B8C15 import ta_A9B8C15
        from bccc.ta.ta_A9B11C1 import ta_A9B11C1
        from bccc.ta.ta_A9B11C2 import ta_A9B11C2
        from bccc.ta.ta_A9B11C3 import ta_A9B11C3
        from bccc.ta.ta_A9B12C1 import ta_A9B12C1
        from bccc.ta.ta_A9B12C2 import ta_A9B12C2
        from bccc.ta.ta_A9B12C3 import ta_A9B12C3
        from bccc.ta.ta_A9B13C4 import ta_A9B13C4
        from bccc.ta.ta_A9B14C4 import ta_A9B14C4
        from bccc.ta.ta_A9B15C7 import ta_A9B15C7
        from bccc.ta.ta_A9B15C8 import ta_A9B15C8
        from bccc.ta.ta_A10B1C11 import ta_A10B1C11
        from bccc.ta.ta_A10B1C12 import ta_A10B1C12
        from bccc.ta.ta_A10B2C11 import ta_A10B2C11
        from bccc.ta.ta_A10B2C12 import ta_A10B2C12
        from bccc.ta.ta_A10B3C11 import ta_A10B3C11
        from bccc.ta.ta_A10B3C12 import ta_A10B3C12
        from bccc.ta.ta_A10B4C13 import ta_A10B4C13
        from bccc.ta.ta_A10B4C14 import ta_A10B4C14
        from bccc.ta.ta_A10B7C15 import ta_A10B7C15
        from bccc.ta.ta_A10B8C15 import ta_A10B8C15
        from bccc.ta.ta_A10B11C1 import ta_A10B11C1
        from bccc.ta.ta_A10B11C2 import ta_A10B11C2
        from bccc.ta.ta_A10B11C3 import ta_A10B11C3
        from bccc.ta.ta_A10B12C1 import ta_A10B12C1
        from bccc.ta.ta_A10B12C2 import ta_A10B12C2
        from bccc.ta.ta_A10B12C3 import ta_A10B12C3
        from bccc.ta.ta_A10B13C4 import ta_A10B13C4
        from bccc.ta.ta_A10B14C4 import ta_A10B14C4
        from bccc.ta.ta_A10B15C7 import ta_A10B15C7
        from bccc.ta.ta_A10B15C8 import ta_A10B15C8
        from bccc.ta.ta_A11B1C9 import ta_A11B1C9
        from bccc.ta.ta_A11B1C10 import ta_A11B1C10
        from bccc.ta.ta_A11B2C9 import ta_A11B2C9
        from bccc.ta.ta_A11B2C10 import ta_A11B2C10
        from bccc.ta.ta_A11B3C9 import ta_A11B3C9
        from bccc.ta.ta_A11B3C10 import ta_A11B3C10
        from bccc.ta.ta_A11B5C7 import ta_A11B5C7
        from bccc.ta.ta_A11B5C8 import ta_A11B5C8
        from bccc.ta.ta_A11B6C13 import ta_A11B6C13
        from bccc.ta.ta_A11B6C14 import ta_A11B6C14
        from bccc.ta.ta_A11B7C5 import ta_A11B7C5
        from bccc.ta.ta_A11B8C5 import ta_A11B8C5
        from bccc.ta.ta_A11B9C1 import ta_A11B9C1
        from bccc.ta.ta_A11B9C2 import ta_A11B9C2
        from bccc.ta.ta_A11B9C3 import ta_A11B9C3
        from bccc.ta.ta_A11B10C1 import ta_A11B10C1
        from bccc.ta.ta_A11B10C2 import ta_A11B10C2
        from bccc.ta.ta_A11B10C3 import ta_A11B10C3
        from bccc.ta.ta_A11B13C6 import ta_A11B13C6
        from bccc.ta.ta_A11B14C6 import ta_A11B14C6
        from bccc.ta.ta_A12B1C9 import ta_A12B1C9
        from bccc.ta.ta_A12B1C10 import ta_A12B1C10
        from bccc.ta.ta_A12B2C9 import ta_A12B2C9
        from bccc.ta.ta_A12B2C10 import ta_A12B2C10
        from bccc.ta.ta_A12B3C9 import ta_A12B3C9
        from bccc.ta.ta_A12B3C10 import ta_A12B3C10
        from bccc.ta.ta_A12B5C7 import ta_A12B5C7
        from bccc.ta.ta_A12B5C8 import ta_A12B5C8
        from bccc.ta.ta_A12B6C13 import ta_A12B6C13
        from bccc.ta.ta_A12B6C14 import ta_A12B6C14
        from bccc.ta.ta_A12B7C5 import ta_A12B7C5
        from bccc.ta.ta_A12B8C5 import ta_A12B8C5
        from bccc.ta.ta_A12B9C1 import ta_A12B9C1
        from bccc.ta.ta_A12B9C2 import ta_A12B9C2
        from bccc.ta.ta_A12B9C3 import ta_A12B9C3
        from bccc.ta.ta_A12B10C1 import ta_A12B10C1
        from bccc.ta.ta_A12B10C2 import ta_A12B10C2
        from bccc.ta.ta_A12B10C3 import ta_A12B10C3
        from bccc.ta.ta_A12B13C6 import ta_A12B13C6
        from bccc.ta.ta_A12B14C6 import ta_A12B14C6
        from bccc.ta.ta_A13B1C7 import ta_A13B1C7
        from bccc.ta.ta_A13B1C8 import ta_A13B1C8
        from bccc.ta.ta_A13B2C7 import ta_A13B2C7
        from bccc.ta.ta_A13B2C8 import ta_A13B2C8
        from bccc.ta.ta_A13B3C7 import ta_A13B3C7
        from bccc.ta.ta_A13B3C8 import ta_A13B3C8
        from bccc.ta.ta_A13B4C9 import ta_A13B4C9
        from bccc.ta.ta_A13B4C10 import ta_A13B4C10
        from bccc.ta.ta_A13B6C11 import ta_A13B6C11
        from bccc.ta.ta_A13B6C12 import ta_A13B6C12
        from bccc.ta.ta_A13B7C1 import ta_A13B7C1
        from bccc.ta.ta_A13B7C2 import ta_A13B7C2
        from bccc.ta.ta_A13B7C3 import ta_A13B7C3
        from bccc.ta.ta_A13B8C1 import ta_A13B8C1
        from bccc.ta.ta_A13B8C2 import ta_A13B8C2
        from bccc.ta.ta_A13B8C3 import ta_A13B8C3
        from bccc.ta.ta_A13B9C4 import ta_A13B9C4
        from bccc.ta.ta_A13B10C4 import ta_A13B10C4
        from bccc.ta.ta_A13B11C6 import ta_A13B11C6
        from bccc.ta.ta_A13B12C6 import ta_A13B12C6
        from bccc.ta.ta_A14B1C7 import ta_A14B1C7
        from bccc.ta.ta_A14B1C8 import ta_A14B1C8
        from bccc.ta.ta_A14B2C7 import ta_A14B2C7
        from bccc.ta.ta_A14B2C8 import ta_A14B2C8
        from bccc.ta.ta_A14B3C7 import ta_A14B3C7
        from bccc.ta.ta_A14B3C8 import ta_A14B3C8
        from bccc.ta.ta_A14B4C9 import ta_A14B4C9
        from bccc.ta.ta_A14B4C10 import ta_A14B4C10
        from bccc.ta.ta_A14B6C11 import ta_A14B6C11
        from bccc.ta.ta_A14B6C12 import ta_A14B6C12
        from bccc.ta.ta_A14B7C1 import ta_A14B7C1
        from bccc.ta.ta_A14B7C2 import ta_A14B7C2
        from bccc.ta.ta_A14B7C3 import ta_A14B7C3
        from bccc.ta.ta_A14B8C1 import ta_A14B8C1
        from bccc.ta.ta_A14B8C2 import ta_A14B8C2
        from bccc.ta.ta_A14B8C3 import ta_A14B8C3
        from bccc.ta.ta_A14B9C4 import ta_A14B9C4
        from bccc.ta.ta_A14B10C4 import ta_A14B10C4
        from bccc.ta.ta_A14B11C6 import ta_A14B11C6
        from bccc.ta.ta_A14B12C6 import ta_A14B12C6
        from bccc.ta.ta_A15B1C6 import ta_A15B1C6
        from bccc.ta.ta_A15B2C6 import ta_A15B2C6
        from bccc.ta.ta_A15B3C6 import ta_A15B3C6
        from bccc.ta.ta_A15B6C1 import ta_A15B6C1
        from bccc.ta.ta_A15B6C2 import ta_A15B6C2
        from bccc.ta.ta_A15B6C3 import ta_A15B6C3
        from bccc.ta.ta_A15B7C9 import ta_A15B7C9
        from bccc.ta.ta_A15B7C10 import ta_A15B7C10
        from bccc.ta.ta_A15B8C9 import ta_A15B8C9
        from bccc.ta.ta_A15B8C10 import ta_A15B8C10
        from bccc.ta.ta_A15B9C7 import ta_A15B9C7
        from bccc.ta.ta_A15B9C8 import ta_A15B9C8
        from bccc.ta.ta_A15B10C7 import ta_A15B10C7
        from bccc.ta.ta_A15B10C8 import ta_A15B10C8
        brafl += (
                 ta_A1B1C1, ta_A1B1C2, ta_A1B1C3, ta_A1B2C1, ta_A1B2C2, 
                 ta_A1B2C3, ta_A1B3C1, ta_A1B3C2, ta_A1B3C3, ta_A1B4C5, 
                 ta_A1B5C4, ta_A1B6C15, ta_A1B7C13, ta_A1B7C14, ta_A1B8C13, 
                 ta_A1B8C14, ta_A1B9C11, ta_A1B9C12, ta_A1B10C11, ta_A1B10C12, 
                 ta_A1B11C9, ta_A1B11C10, ta_A1B12C9, ta_A1B12C10, ta_A1B13C7, 
                 ta_A1B13C8, ta_A1B14C7, ta_A1B14C8, ta_A1B15C6, ta_A2B1C1, 
                 ta_A2B1C2, ta_A2B1C3, ta_A2B2C1, ta_A2B2C2, ta_A2B2C3, 
                 ta_A2B3C1, ta_A2B3C2, ta_A2B3C3, ta_A2B4C5, ta_A2B5C4, 
                 ta_A2B6C15, ta_A2B7C13, ta_A2B7C14, ta_A2B8C13, ta_A2B8C14, 
                 ta_A2B9C11, ta_A2B9C12, ta_A2B10C11, ta_A2B10C12, ta_A2B11C9, 
                 ta_A2B11C10, ta_A2B12C9, ta_A2B12C10, ta_A2B13C7, ta_A2B13C8, 
                 ta_A2B14C7, ta_A2B14C8, ta_A2B15C6, ta_A3B1C1, ta_A3B1C2, 
                 ta_A3B1C3, ta_A3B2C1, ta_A3B2C2, ta_A3B2C3, ta_A3B3C1, 
                 ta_A3B3C2, ta_A3B3C3, ta_A3B4C5, ta_A3B5C4, ta_A3B6C15, 
                 ta_A3B7C13, ta_A3B7C14, ta_A3B8C13, ta_A3B8C14, ta_A3B9C11, 
                 ta_A3B9C12, ta_A3B10C11, ta_A3B10C12, ta_A3B11C9, ta_A3B11C10, 
                 ta_A3B12C9, ta_A3B12C10, ta_A3B13C7, ta_A3B13C8, ta_A3B14C7, 
                 ta_A3B14C8, ta_A3B15C6, ta_A4B1C5, ta_A4B2C5, ta_A4B3C5, 
                 ta_A4B5C1, ta_A4B5C2, ta_A4B5C3, ta_A4B9C13, ta_A4B9C14, 
                 ta_A4B10C13, ta_A4B10C14, ta_A4B13C9, ta_A4B13C10, ta_A4B14C9, 
                 ta_A4B14C10, ta_A5B1C4, ta_A5B2C4, ta_A5B3C4, ta_A5B4C1, 
                 ta_A5B4C2, ta_A5B4C3, ta_A5B7C11, ta_A5B7C12, ta_A5B8C11, 
                 ta_A5B8C12, ta_A5B11C7, ta_A5B11C8, ta_A5B12C7, ta_A5B12C8, 
                 ta_A6B1C15, ta_A6B2C15, ta_A6B3C15, ta_A6B11C13, ta_A6B11C14, 
                 ta_A6B12C13, ta_A6B12C14, ta_A6B13C11, ta_A6B13C12, ta_A6B14C11, 
                 ta_A6B14C12, ta_A6B15C1, ta_A6B15C2, ta_A6B15C3, ta_A7B1C13, 
                 ta_A7B1C14, ta_A7B2C13, ta_A7B2C14, ta_A7B3C13, ta_A7B3C14, 
                 ta_A7B5C11, ta_A7B5C12, ta_A7B9C15, ta_A7B10C15, ta_A7B11C5, 
                 ta_A7B12C5, ta_A7B13C1, ta_A7B13C2, ta_A7B13C3, ta_A7B14C1, 
                 ta_A7B14C2, ta_A7B14C3, ta_A7B15C9, ta_A7B15C10, ta_A8B1C13, 
                 ta_A8B1C14, ta_A8B2C13, ta_A8B2C14, ta_A8B3C13, ta_A8B3C14, 
                 ta_A8B5C11, ta_A8B5C12, ta_A8B9C15, ta_A8B10C15, ta_A8B11C5, 
                 ta_A8B12C5, ta_A8B13C1, ta_A8B13C2, ta_A8B13C3, ta_A8B14C1, 
                 ta_A8B14C2, ta_A8B14C3, ta_A8B15C9, ta_A8B15C10, ta_A9B1C11, 
                 ta_A9B1C12, ta_A9B2C11, ta_A9B2C12, ta_A9B3C11, ta_A9B3C12, 
                 ta_A9B4C13, ta_A9B4C14, ta_A9B7C15, ta_A9B8C15, ta_A9B11C1, 
                 ta_A9B11C2, ta_A9B11C3, ta_A9B12C1, ta_A9B12C2, ta_A9B12C3, 
                 ta_A9B13C4, ta_A9B14C4, ta_A9B15C7, ta_A9B15C8, ta_A10B1C11, 
                 ta_A10B1C12, ta_A10B2C11, ta_A10B2C12, ta_A10B3C11, ta_A10B3C12, 
                 ta_A10B4C13, ta_A10B4C14, ta_A10B7C15, ta_A10B8C15, ta_A10B11C1, 
                 ta_A10B11C2, ta_A10B11C3, ta_A10B12C1, ta_A10B12C2, ta_A10B12C3, 
                 ta_A10B13C4, ta_A10B14C4, ta_A10B15C7, ta_A10B15C8, ta_A11B1C9, 
                 ta_A11B1C10, ta_A11B2C9, ta_A11B2C10, ta_A11B3C9, ta_A11B3C10, 
                 ta_A11B5C7, ta_A11B5C8, ta_A11B6C13, ta_A11B6C14, ta_A11B7C5, 
                 ta_A11B8C5, ta_A11B9C1, ta_A11B9C2, ta_A11B9C3, ta_A11B10C1, 
                 ta_A11B10C2, ta_A11B10C3, ta_A11B13C6, ta_A11B14C6, ta_A12B1C9, 
                 ta_A12B1C10, ta_A12B2C9, ta_A12B2C10, ta_A12B3C9, ta_A12B3C10, 
                 ta_A12B5C7, ta_A12B5C8, ta_A12B6C13, ta_A12B6C14, ta_A12B7C5, 
                 ta_A12B8C5, ta_A12B9C1, ta_A12B9C2, ta_A12B9C3, ta_A12B10C1, 
                 ta_A12B10C2, ta_A12B10C3, ta_A12B13C6, ta_A12B14C6, ta_A13B1C7, 
                 ta_A13B1C8, ta_A13B2C7, ta_A13B2C8, ta_A13B3C7, ta_A13B3C8, 
                 ta_A13B4C9, ta_A13B4C10, ta_A13B6C11, ta_A13B6C12, ta_A13B7C1, 
                 ta_A13B7C2, ta_A13B7C3, ta_A13B8C1, ta_A13B8C2, ta_A13B8C3, 
                 ta_A13B9C4, ta_A13B10C4, ta_A13B11C6, ta_A13B12C6, ta_A14B1C7, 
                 ta_A14B1C8, ta_A14B2C7, ta_A14B2C8, ta_A14B3C7, ta_A14B3C8, 
                 ta_A14B4C9, ta_A14B4C10, ta_A14B6C11, ta_A14B6C12, ta_A14B7C1, 
                 ta_A14B7C2, ta_A14B7C3, ta_A14B8C1, ta_A14B8C2, ta_A14B8C3, 
                 ta_A14B9C4, ta_A14B10C4, ta_A14B11C6, ta_A14B12C6, ta_A15B1C6, 
                 ta_A15B2C6, ta_A15B3C6, ta_A15B6C1, ta_A15B6C2, ta_A15B6C3, 
                 ta_A15B7C9, ta_A15B7C10, ta_A15B8C9, ta_A15B8C10, ta_A15B9C7, 
                 ta_A15B9C8, ta_A15B10C7, ta_A15B10C8,                  
                 )
        
    # 4-block excited types
    if nt>3: 
        from bccc.ta.ta_A1B1C1D1 import ta_A1B1C1D1
        from bccc.ta.ta_A1B1C1D2 import ta_A1B1C1D2
        from bccc.ta.ta_A1B1C1D3 import ta_A1B1C1D3
        from bccc.ta.ta_A1B1C2D1 import ta_A1B1C2D1
        from bccc.ta.ta_A1B1C2D2 import ta_A1B1C2D2
        from bccc.ta.ta_A1B1C2D3 import ta_A1B1C2D3
        from bccc.ta.ta_A1B1C3D1 import ta_A1B1C3D1
        from bccc.ta.ta_A1B1C3D2 import ta_A1B1C3D2
        from bccc.ta.ta_A1B1C3D3 import ta_A1B1C3D3
        from bccc.ta.ta_A1B1C4D5 import ta_A1B1C4D5
        from bccc.ta.ta_A1B1C5D4 import ta_A1B1C5D4
        from bccc.ta.ta_A1B1C6D15 import ta_A1B1C6D15
        from bccc.ta.ta_A1B1C7D13 import ta_A1B1C7D13
        from bccc.ta.ta_A1B1C7D14 import ta_A1B1C7D14
        from bccc.ta.ta_A1B1C8D13 import ta_A1B1C8D13
        from bccc.ta.ta_A1B1C8D14 import ta_A1B1C8D14
        from bccc.ta.ta_A1B1C9D11 import ta_A1B1C9D11
        from bccc.ta.ta_A1B1C9D12 import ta_A1B1C9D12
        from bccc.ta.ta_A1B1C10D11 import ta_A1B1C10D11
        from bccc.ta.ta_A1B1C10D12 import ta_A1B1C10D12
        from bccc.ta.ta_A1B1C11D9 import ta_A1B1C11D9
        from bccc.ta.ta_A1B1C11D10 import ta_A1B1C11D10
        from bccc.ta.ta_A1B1C12D9 import ta_A1B1C12D9
        from bccc.ta.ta_A1B1C12D10 import ta_A1B1C12D10
        from bccc.ta.ta_A1B1C13D7 import ta_A1B1C13D7
        from bccc.ta.ta_A1B1C13D8 import ta_A1B1C13D8
        from bccc.ta.ta_A1B1C14D7 import ta_A1B1C14D7
        from bccc.ta.ta_A1B1C14D8 import ta_A1B1C14D8
        from bccc.ta.ta_A1B1C15D6 import ta_A1B1C15D6
        from bccc.ta.ta_A1B2C1D1 import ta_A1B2C1D1
        from bccc.ta.ta_A1B2C1D2 import ta_A1B2C1D2
        from bccc.ta.ta_A1B2C1D3 import ta_A1B2C1D3
        from bccc.ta.ta_A1B2C2D1 import ta_A1B2C2D1
        from bccc.ta.ta_A1B2C2D2 import ta_A1B2C2D2
        from bccc.ta.ta_A1B2C2D3 import ta_A1B2C2D3
        from bccc.ta.ta_A1B2C3D1 import ta_A1B2C3D1
        from bccc.ta.ta_A1B2C3D2 import ta_A1B2C3D2
        from bccc.ta.ta_A1B2C3D3 import ta_A1B2C3D3
        from bccc.ta.ta_A1B2C4D5 import ta_A1B2C4D5
        from bccc.ta.ta_A1B2C5D4 import ta_A1B2C5D4
        from bccc.ta.ta_A1B2C6D15 import ta_A1B2C6D15
        from bccc.ta.ta_A1B2C7D13 import ta_A1B2C7D13
        from bccc.ta.ta_A1B2C7D14 import ta_A1B2C7D14
        from bccc.ta.ta_A1B2C8D13 import ta_A1B2C8D13
        from bccc.ta.ta_A1B2C8D14 import ta_A1B2C8D14
        from bccc.ta.ta_A1B2C9D11 import ta_A1B2C9D11
        from bccc.ta.ta_A1B2C9D12 import ta_A1B2C9D12
        from bccc.ta.ta_A1B2C10D11 import ta_A1B2C10D11
        from bccc.ta.ta_A1B2C10D12 import ta_A1B2C10D12
        from bccc.ta.ta_A1B2C11D9 import ta_A1B2C11D9
        from bccc.ta.ta_A1B2C11D10 import ta_A1B2C11D10
        from bccc.ta.ta_A1B2C12D9 import ta_A1B2C12D9
        from bccc.ta.ta_A1B2C12D10 import ta_A1B2C12D10
        from bccc.ta.ta_A1B2C13D7 import ta_A1B2C13D7
        from bccc.ta.ta_A1B2C13D8 import ta_A1B2C13D8
        from bccc.ta.ta_A1B2C14D7 import ta_A1B2C14D7
        from bccc.ta.ta_A1B2C14D8 import ta_A1B2C14D8
        from bccc.ta.ta_A1B2C15D6 import ta_A1B2C15D6
        from bccc.ta.ta_A1B3C1D1 import ta_A1B3C1D1
        from bccc.ta.ta_A1B3C1D2 import ta_A1B3C1D2
        from bccc.ta.ta_A1B3C1D3 import ta_A1B3C1D3
        from bccc.ta.ta_A1B3C2D1 import ta_A1B3C2D1
        from bccc.ta.ta_A1B3C2D2 import ta_A1B3C2D2
        from bccc.ta.ta_A1B3C2D3 import ta_A1B3C2D3
        from bccc.ta.ta_A1B3C3D1 import ta_A1B3C3D1
        from bccc.ta.ta_A1B3C3D2 import ta_A1B3C3D2
        from bccc.ta.ta_A1B3C3D3 import ta_A1B3C3D3
        from bccc.ta.ta_A1B3C4D5 import ta_A1B3C4D5
        from bccc.ta.ta_A1B3C5D4 import ta_A1B3C5D4
        from bccc.ta.ta_A1B3C6D15 import ta_A1B3C6D15
        from bccc.ta.ta_A1B3C7D13 import ta_A1B3C7D13
        from bccc.ta.ta_A1B3C7D14 import ta_A1B3C7D14
        from bccc.ta.ta_A1B3C8D13 import ta_A1B3C8D13
        from bccc.ta.ta_A1B3C8D14 import ta_A1B3C8D14
        from bccc.ta.ta_A1B3C9D11 import ta_A1B3C9D11
        from bccc.ta.ta_A1B3C9D12 import ta_A1B3C9D12
        from bccc.ta.ta_A1B3C10D11 import ta_A1B3C10D11
        from bccc.ta.ta_A1B3C10D12 import ta_A1B3C10D12
        from bccc.ta.ta_A1B3C11D9 import ta_A1B3C11D9
        from bccc.ta.ta_A1B3C11D10 import ta_A1B3C11D10
        from bccc.ta.ta_A1B3C12D9 import ta_A1B3C12D9
        from bccc.ta.ta_A1B3C12D10 import ta_A1B3C12D10
        from bccc.ta.ta_A1B3C13D7 import ta_A1B3C13D7
        from bccc.ta.ta_A1B3C13D8 import ta_A1B3C13D8
        from bccc.ta.ta_A1B3C14D7 import ta_A1B3C14D7
        from bccc.ta.ta_A1B3C14D8 import ta_A1B3C14D8
        from bccc.ta.ta_A1B3C15D6 import ta_A1B3C15D6
        from bccc.ta.ta_A1B4C1D5 import ta_A1B4C1D5
        from bccc.ta.ta_A1B4C2D5 import ta_A1B4C2D5
        from bccc.ta.ta_A1B4C3D5 import ta_A1B4C3D5
        from bccc.ta.ta_A1B4C5D1 import ta_A1B4C5D1
        from bccc.ta.ta_A1B4C5D2 import ta_A1B4C5D2
        from bccc.ta.ta_A1B4C5D3 import ta_A1B4C5D3
        from bccc.ta.ta_A1B4C9D13 import ta_A1B4C9D13
        from bccc.ta.ta_A1B4C9D14 import ta_A1B4C9D14
        from bccc.ta.ta_A1B4C10D13 import ta_A1B4C10D13
        from bccc.ta.ta_A1B4C10D14 import ta_A1B4C10D14
        from bccc.ta.ta_A1B4C13D9 import ta_A1B4C13D9
        from bccc.ta.ta_A1B4C13D10 import ta_A1B4C13D10
        from bccc.ta.ta_A1B4C14D9 import ta_A1B4C14D9
        from bccc.ta.ta_A1B4C14D10 import ta_A1B4C14D10
        from bccc.ta.ta_A1B5C1D4 import ta_A1B5C1D4
        from bccc.ta.ta_A1B5C2D4 import ta_A1B5C2D4
        from bccc.ta.ta_A1B5C3D4 import ta_A1B5C3D4
        from bccc.ta.ta_A1B5C4D1 import ta_A1B5C4D1
        from bccc.ta.ta_A1B5C4D2 import ta_A1B5C4D2
        from bccc.ta.ta_A1B5C4D3 import ta_A1B5C4D3
        from bccc.ta.ta_A1B5C7D11 import ta_A1B5C7D11
        from bccc.ta.ta_A1B5C7D12 import ta_A1B5C7D12
        from bccc.ta.ta_A1B5C8D11 import ta_A1B5C8D11
        from bccc.ta.ta_A1B5C8D12 import ta_A1B5C8D12
        from bccc.ta.ta_A1B5C11D7 import ta_A1B5C11D7
        from bccc.ta.ta_A1B5C11D8 import ta_A1B5C11D8
        from bccc.ta.ta_A1B5C12D7 import ta_A1B5C12D7
        from bccc.ta.ta_A1B5C12D8 import ta_A1B5C12D8
        from bccc.ta.ta_A1B6C1D15 import ta_A1B6C1D15
        from bccc.ta.ta_A1B6C2D15 import ta_A1B6C2D15
        from bccc.ta.ta_A1B6C3D15 import ta_A1B6C3D15
        from bccc.ta.ta_A1B6C11D13 import ta_A1B6C11D13
        from bccc.ta.ta_A1B6C11D14 import ta_A1B6C11D14
        from bccc.ta.ta_A1B6C12D13 import ta_A1B6C12D13
        from bccc.ta.ta_A1B6C12D14 import ta_A1B6C12D14
        from bccc.ta.ta_A1B6C13D11 import ta_A1B6C13D11
        from bccc.ta.ta_A1B6C13D12 import ta_A1B6C13D12
        from bccc.ta.ta_A1B6C14D11 import ta_A1B6C14D11
        from bccc.ta.ta_A1B6C14D12 import ta_A1B6C14D12
        from bccc.ta.ta_A1B6C15D1 import ta_A1B6C15D1
        from bccc.ta.ta_A1B6C15D2 import ta_A1B6C15D2
        from bccc.ta.ta_A1B6C15D3 import ta_A1B6C15D3
        from bccc.ta.ta_A1B7C1D13 import ta_A1B7C1D13
        from bccc.ta.ta_A1B7C1D14 import ta_A1B7C1D14
        from bccc.ta.ta_A1B7C2D13 import ta_A1B7C2D13
        from bccc.ta.ta_A1B7C2D14 import ta_A1B7C2D14
        from bccc.ta.ta_A1B7C3D13 import ta_A1B7C3D13
        from bccc.ta.ta_A1B7C3D14 import ta_A1B7C3D14
        from bccc.ta.ta_A1B7C5D11 import ta_A1B7C5D11
        from bccc.ta.ta_A1B7C5D12 import ta_A1B7C5D12
        from bccc.ta.ta_A1B7C9D15 import ta_A1B7C9D15
        from bccc.ta.ta_A1B7C10D15 import ta_A1B7C10D15
        from bccc.ta.ta_A1B7C11D5 import ta_A1B7C11D5
        from bccc.ta.ta_A1B7C12D5 import ta_A1B7C12D5
        from bccc.ta.ta_A1B7C13D1 import ta_A1B7C13D1
        from bccc.ta.ta_A1B7C13D2 import ta_A1B7C13D2
        from bccc.ta.ta_A1B7C13D3 import ta_A1B7C13D3
        from bccc.ta.ta_A1B7C14D1 import ta_A1B7C14D1
        from bccc.ta.ta_A1B7C14D2 import ta_A1B7C14D2
        from bccc.ta.ta_A1B7C14D3 import ta_A1B7C14D3
        from bccc.ta.ta_A1B7C15D9 import ta_A1B7C15D9
        from bccc.ta.ta_A1B7C15D10 import ta_A1B7C15D10
        from bccc.ta.ta_A1B8C1D13 import ta_A1B8C1D13
        from bccc.ta.ta_A1B8C1D14 import ta_A1B8C1D14
        from bccc.ta.ta_A1B8C2D13 import ta_A1B8C2D13
        from bccc.ta.ta_A1B8C2D14 import ta_A1B8C2D14
        from bccc.ta.ta_A1B8C3D13 import ta_A1B8C3D13
        from bccc.ta.ta_A1B8C3D14 import ta_A1B8C3D14
        from bccc.ta.ta_A1B8C5D11 import ta_A1B8C5D11
        from bccc.ta.ta_A1B8C5D12 import ta_A1B8C5D12
        from bccc.ta.ta_A1B8C9D15 import ta_A1B8C9D15
        from bccc.ta.ta_A1B8C10D15 import ta_A1B8C10D15
        from bccc.ta.ta_A1B8C11D5 import ta_A1B8C11D5
        from bccc.ta.ta_A1B8C12D5 import ta_A1B8C12D5
        from bccc.ta.ta_A1B8C13D1 import ta_A1B8C13D1
        from bccc.ta.ta_A1B8C13D2 import ta_A1B8C13D2
        from bccc.ta.ta_A1B8C13D3 import ta_A1B8C13D3
        from bccc.ta.ta_A1B8C14D1 import ta_A1B8C14D1
        from bccc.ta.ta_A1B8C14D2 import ta_A1B8C14D2
        from bccc.ta.ta_A1B8C14D3 import ta_A1B8C14D3
        from bccc.ta.ta_A1B8C15D9 import ta_A1B8C15D9
        from bccc.ta.ta_A1B8C15D10 import ta_A1B8C15D10
        from bccc.ta.ta_A1B9C1D11 import ta_A1B9C1D11
        from bccc.ta.ta_A1B9C1D12 import ta_A1B9C1D12
        from bccc.ta.ta_A1B9C2D11 import ta_A1B9C2D11
        from bccc.ta.ta_A1B9C2D12 import ta_A1B9C2D12
        from bccc.ta.ta_A1B9C3D11 import ta_A1B9C3D11
        from bccc.ta.ta_A1B9C3D12 import ta_A1B9C3D12
        from bccc.ta.ta_A1B9C4D13 import ta_A1B9C4D13
        from bccc.ta.ta_A1B9C4D14 import ta_A1B9C4D14
        from bccc.ta.ta_A1B9C7D15 import ta_A1B9C7D15
        from bccc.ta.ta_A1B9C8D15 import ta_A1B9C8D15
        from bccc.ta.ta_A1B9C11D1 import ta_A1B9C11D1
        from bccc.ta.ta_A1B9C11D2 import ta_A1B9C11D2
        from bccc.ta.ta_A1B9C11D3 import ta_A1B9C11D3
        from bccc.ta.ta_A1B9C12D1 import ta_A1B9C12D1
        from bccc.ta.ta_A1B9C12D2 import ta_A1B9C12D2
        from bccc.ta.ta_A1B9C12D3 import ta_A1B9C12D3
        from bccc.ta.ta_A1B9C13D4 import ta_A1B9C13D4
        from bccc.ta.ta_A1B9C14D4 import ta_A1B9C14D4
        from bccc.ta.ta_A1B9C15D7 import ta_A1B9C15D7
        from bccc.ta.ta_A1B9C15D8 import ta_A1B9C15D8
        from bccc.ta.ta_A1B10C1D11 import ta_A1B10C1D11
        from bccc.ta.ta_A1B10C1D12 import ta_A1B10C1D12
        from bccc.ta.ta_A1B10C2D11 import ta_A1B10C2D11
        from bccc.ta.ta_A1B10C2D12 import ta_A1B10C2D12
        from bccc.ta.ta_A1B10C3D11 import ta_A1B10C3D11
        from bccc.ta.ta_A1B10C3D12 import ta_A1B10C3D12
        from bccc.ta.ta_A1B10C4D13 import ta_A1B10C4D13
        from bccc.ta.ta_A1B10C4D14 import ta_A1B10C4D14
        from bccc.ta.ta_A1B10C7D15 import ta_A1B10C7D15
        from bccc.ta.ta_A1B10C8D15 import ta_A1B10C8D15
        from bccc.ta.ta_A1B10C11D1 import ta_A1B10C11D1
        from bccc.ta.ta_A1B10C11D2 import ta_A1B10C11D2
        from bccc.ta.ta_A1B10C11D3 import ta_A1B10C11D3
        from bccc.ta.ta_A1B10C12D1 import ta_A1B10C12D1
        from bccc.ta.ta_A1B10C12D2 import ta_A1B10C12D2
        from bccc.ta.ta_A1B10C12D3 import ta_A1B10C12D3
        from bccc.ta.ta_A1B10C13D4 import ta_A1B10C13D4
        from bccc.ta.ta_A1B10C14D4 import ta_A1B10C14D4
        from bccc.ta.ta_A1B10C15D7 import ta_A1B10C15D7
        from bccc.ta.ta_A1B10C15D8 import ta_A1B10C15D8
        from bccc.ta.ta_A1B11C1D9 import ta_A1B11C1D9
        from bccc.ta.ta_A1B11C1D10 import ta_A1B11C1D10
        from bccc.ta.ta_A1B11C2D9 import ta_A1B11C2D9
        from bccc.ta.ta_A1B11C2D10 import ta_A1B11C2D10
        from bccc.ta.ta_A1B11C3D9 import ta_A1B11C3D9
        from bccc.ta.ta_A1B11C3D10 import ta_A1B11C3D10
        from bccc.ta.ta_A1B11C5D7 import ta_A1B11C5D7
        from bccc.ta.ta_A1B11C5D8 import ta_A1B11C5D8
        from bccc.ta.ta_A1B11C6D13 import ta_A1B11C6D13
        from bccc.ta.ta_A1B11C6D14 import ta_A1B11C6D14
        from bccc.ta.ta_A1B11C7D5 import ta_A1B11C7D5
        from bccc.ta.ta_A1B11C8D5 import ta_A1B11C8D5
        from bccc.ta.ta_A1B11C9D1 import ta_A1B11C9D1
        from bccc.ta.ta_A1B11C9D2 import ta_A1B11C9D2
        from bccc.ta.ta_A1B11C9D3 import ta_A1B11C9D3
        from bccc.ta.ta_A1B11C10D1 import ta_A1B11C10D1
        from bccc.ta.ta_A1B11C10D2 import ta_A1B11C10D2
        from bccc.ta.ta_A1B11C10D3 import ta_A1B11C10D3
        from bccc.ta.ta_A1B11C13D6 import ta_A1B11C13D6
        from bccc.ta.ta_A1B11C14D6 import ta_A1B11C14D6
        from bccc.ta.ta_A1B12C1D9 import ta_A1B12C1D9
        from bccc.ta.ta_A1B12C1D10 import ta_A1B12C1D10
        from bccc.ta.ta_A1B12C2D9 import ta_A1B12C2D9
        from bccc.ta.ta_A1B12C2D10 import ta_A1B12C2D10
        from bccc.ta.ta_A1B12C3D9 import ta_A1B12C3D9
        from bccc.ta.ta_A1B12C3D10 import ta_A1B12C3D10
        from bccc.ta.ta_A1B12C5D7 import ta_A1B12C5D7
        from bccc.ta.ta_A1B12C5D8 import ta_A1B12C5D8
        from bccc.ta.ta_A1B12C6D13 import ta_A1B12C6D13
        from bccc.ta.ta_A1B12C6D14 import ta_A1B12C6D14
        from bccc.ta.ta_A1B12C7D5 import ta_A1B12C7D5
        from bccc.ta.ta_A1B12C8D5 import ta_A1B12C8D5
        from bccc.ta.ta_A1B12C9D1 import ta_A1B12C9D1
        from bccc.ta.ta_A1B12C9D2 import ta_A1B12C9D2
        from bccc.ta.ta_A1B12C9D3 import ta_A1B12C9D3
        from bccc.ta.ta_A1B12C10D1 import ta_A1B12C10D1
        from bccc.ta.ta_A1B12C10D2 import ta_A1B12C10D2
        from bccc.ta.ta_A1B12C10D3 import ta_A1B12C10D3
        from bccc.ta.ta_A1B12C13D6 import ta_A1B12C13D6
        from bccc.ta.ta_A1B12C14D6 import ta_A1B12C14D6
        from bccc.ta.ta_A1B13C1D7 import ta_A1B13C1D7
        from bccc.ta.ta_A1B13C1D8 import ta_A1B13C1D8
        from bccc.ta.ta_A1B13C2D7 import ta_A1B13C2D7
        from bccc.ta.ta_A1B13C2D8 import ta_A1B13C2D8
        from bccc.ta.ta_A1B13C3D7 import ta_A1B13C3D7
        from bccc.ta.ta_A1B13C3D8 import ta_A1B13C3D8
        from bccc.ta.ta_A1B13C4D9 import ta_A1B13C4D9
        from bccc.ta.ta_A1B13C4D10 import ta_A1B13C4D10
        from bccc.ta.ta_A1B13C6D11 import ta_A1B13C6D11
        from bccc.ta.ta_A1B13C6D12 import ta_A1B13C6D12
        from bccc.ta.ta_A1B13C7D1 import ta_A1B13C7D1
        from bccc.ta.ta_A1B13C7D2 import ta_A1B13C7D2
        from bccc.ta.ta_A1B13C7D3 import ta_A1B13C7D3
        from bccc.ta.ta_A1B13C8D1 import ta_A1B13C8D1
        from bccc.ta.ta_A1B13C8D2 import ta_A1B13C8D2
        from bccc.ta.ta_A1B13C8D3 import ta_A1B13C8D3
        from bccc.ta.ta_A1B13C9D4 import ta_A1B13C9D4
        from bccc.ta.ta_A1B13C10D4 import ta_A1B13C10D4
        from bccc.ta.ta_A1B13C11D6 import ta_A1B13C11D6
        from bccc.ta.ta_A1B13C12D6 import ta_A1B13C12D6
        from bccc.ta.ta_A1B14C1D7 import ta_A1B14C1D7
        from bccc.ta.ta_A1B14C1D8 import ta_A1B14C1D8
        from bccc.ta.ta_A1B14C2D7 import ta_A1B14C2D7
        from bccc.ta.ta_A1B14C2D8 import ta_A1B14C2D8
        from bccc.ta.ta_A1B14C3D7 import ta_A1B14C3D7
        from bccc.ta.ta_A1B14C3D8 import ta_A1B14C3D8
        from bccc.ta.ta_A1B14C4D9 import ta_A1B14C4D9
        from bccc.ta.ta_A1B14C4D10 import ta_A1B14C4D10
        from bccc.ta.ta_A1B14C6D11 import ta_A1B14C6D11
        from bccc.ta.ta_A1B14C6D12 import ta_A1B14C6D12
        from bccc.ta.ta_A1B14C7D1 import ta_A1B14C7D1
        from bccc.ta.ta_A1B14C7D2 import ta_A1B14C7D2
        from bccc.ta.ta_A1B14C7D3 import ta_A1B14C7D3
        from bccc.ta.ta_A1B14C8D1 import ta_A1B14C8D1
        from bccc.ta.ta_A1B14C8D2 import ta_A1B14C8D2
        from bccc.ta.ta_A1B14C8D3 import ta_A1B14C8D3
        from bccc.ta.ta_A1B14C9D4 import ta_A1B14C9D4
        from bccc.ta.ta_A1B14C10D4 import ta_A1B14C10D4
        from bccc.ta.ta_A1B14C11D6 import ta_A1B14C11D6
        from bccc.ta.ta_A1B14C12D6 import ta_A1B14C12D6
        from bccc.ta.ta_A1B15C1D6 import ta_A1B15C1D6
        from bccc.ta.ta_A1B15C2D6 import ta_A1B15C2D6
        from bccc.ta.ta_A1B15C3D6 import ta_A1B15C3D6
        from bccc.ta.ta_A1B15C6D1 import ta_A1B15C6D1
        from bccc.ta.ta_A1B15C6D2 import ta_A1B15C6D2
        from bccc.ta.ta_A1B15C6D3 import ta_A1B15C6D3
        from bccc.ta.ta_A1B15C7D9 import ta_A1B15C7D9
        from bccc.ta.ta_A1B15C7D10 import ta_A1B15C7D10
        from bccc.ta.ta_A1B15C8D9 import ta_A1B15C8D9
        from bccc.ta.ta_A1B15C8D10 import ta_A1B15C8D10
        from bccc.ta.ta_A1B15C9D7 import ta_A1B15C9D7
        from bccc.ta.ta_A1B15C9D8 import ta_A1B15C9D8
        from bccc.ta.ta_A1B15C10D7 import ta_A1B15C10D7
        from bccc.ta.ta_A1B15C10D8 import ta_A1B15C10D8
        from bccc.ta.ta_A2B1C1D1 import ta_A2B1C1D1
        from bccc.ta.ta_A2B1C1D2 import ta_A2B1C1D2
        from bccc.ta.ta_A2B1C1D3 import ta_A2B1C1D3
        from bccc.ta.ta_A2B1C2D1 import ta_A2B1C2D1
        from bccc.ta.ta_A2B1C2D2 import ta_A2B1C2D2
        from bccc.ta.ta_A2B1C2D3 import ta_A2B1C2D3
        from bccc.ta.ta_A2B1C3D1 import ta_A2B1C3D1
        from bccc.ta.ta_A2B1C3D2 import ta_A2B1C3D2
        from bccc.ta.ta_A2B1C3D3 import ta_A2B1C3D3
        from bccc.ta.ta_A2B1C4D5 import ta_A2B1C4D5
        from bccc.ta.ta_A2B1C5D4 import ta_A2B1C5D4
        from bccc.ta.ta_A2B1C6D15 import ta_A2B1C6D15
        from bccc.ta.ta_A2B1C7D13 import ta_A2B1C7D13
        from bccc.ta.ta_A2B1C7D14 import ta_A2B1C7D14
        from bccc.ta.ta_A2B1C8D13 import ta_A2B1C8D13
        from bccc.ta.ta_A2B1C8D14 import ta_A2B1C8D14
        from bccc.ta.ta_A2B1C9D11 import ta_A2B1C9D11
        from bccc.ta.ta_A2B1C9D12 import ta_A2B1C9D12
        from bccc.ta.ta_A2B1C10D11 import ta_A2B1C10D11
        from bccc.ta.ta_A2B1C10D12 import ta_A2B1C10D12
        from bccc.ta.ta_A2B1C11D9 import ta_A2B1C11D9
        from bccc.ta.ta_A2B1C11D10 import ta_A2B1C11D10
        from bccc.ta.ta_A2B1C12D9 import ta_A2B1C12D9
        from bccc.ta.ta_A2B1C12D10 import ta_A2B1C12D10
        from bccc.ta.ta_A2B1C13D7 import ta_A2B1C13D7
        from bccc.ta.ta_A2B1C13D8 import ta_A2B1C13D8
        from bccc.ta.ta_A2B1C14D7 import ta_A2B1C14D7
        from bccc.ta.ta_A2B1C14D8 import ta_A2B1C14D8
        from bccc.ta.ta_A2B1C15D6 import ta_A2B1C15D6
        from bccc.ta.ta_A2B2C1D1 import ta_A2B2C1D1
        from bccc.ta.ta_A2B2C1D2 import ta_A2B2C1D2
        from bccc.ta.ta_A2B2C1D3 import ta_A2B2C1D3
        from bccc.ta.ta_A2B2C2D1 import ta_A2B2C2D1
        from bccc.ta.ta_A2B2C2D2 import ta_A2B2C2D2
        from bccc.ta.ta_A2B2C2D3 import ta_A2B2C2D3
        from bccc.ta.ta_A2B2C3D1 import ta_A2B2C3D1
        from bccc.ta.ta_A2B2C3D2 import ta_A2B2C3D2
        from bccc.ta.ta_A2B2C3D3 import ta_A2B2C3D3
        from bccc.ta.ta_A2B2C4D5 import ta_A2B2C4D5
        from bccc.ta.ta_A2B2C5D4 import ta_A2B2C5D4
        from bccc.ta.ta_A2B2C6D15 import ta_A2B2C6D15
        from bccc.ta.ta_A2B2C7D13 import ta_A2B2C7D13
        from bccc.ta.ta_A2B2C7D14 import ta_A2B2C7D14
        from bccc.ta.ta_A2B2C8D13 import ta_A2B2C8D13
        from bccc.ta.ta_A2B2C8D14 import ta_A2B2C8D14
        from bccc.ta.ta_A2B2C9D11 import ta_A2B2C9D11
        from bccc.ta.ta_A2B2C9D12 import ta_A2B2C9D12
        from bccc.ta.ta_A2B2C10D11 import ta_A2B2C10D11
        from bccc.ta.ta_A2B2C10D12 import ta_A2B2C10D12
        from bccc.ta.ta_A2B2C11D9 import ta_A2B2C11D9
        from bccc.ta.ta_A2B2C11D10 import ta_A2B2C11D10
        from bccc.ta.ta_A2B2C12D9 import ta_A2B2C12D9
        from bccc.ta.ta_A2B2C12D10 import ta_A2B2C12D10
        from bccc.ta.ta_A2B2C13D7 import ta_A2B2C13D7
        from bccc.ta.ta_A2B2C13D8 import ta_A2B2C13D8
        from bccc.ta.ta_A2B2C14D7 import ta_A2B2C14D7
        from bccc.ta.ta_A2B2C14D8 import ta_A2B2C14D8
        from bccc.ta.ta_A2B2C15D6 import ta_A2B2C15D6
        from bccc.ta.ta_A2B3C1D1 import ta_A2B3C1D1
        from bccc.ta.ta_A2B3C1D2 import ta_A2B3C1D2
        from bccc.ta.ta_A2B3C1D3 import ta_A2B3C1D3
        from bccc.ta.ta_A2B3C2D1 import ta_A2B3C2D1
        from bccc.ta.ta_A2B3C2D2 import ta_A2B3C2D2
        from bccc.ta.ta_A2B3C2D3 import ta_A2B3C2D3
        from bccc.ta.ta_A2B3C3D1 import ta_A2B3C3D1
        from bccc.ta.ta_A2B3C3D2 import ta_A2B3C3D2
        from bccc.ta.ta_A2B3C3D3 import ta_A2B3C3D3
        from bccc.ta.ta_A2B3C4D5 import ta_A2B3C4D5
        from bccc.ta.ta_A2B3C5D4 import ta_A2B3C5D4
        from bccc.ta.ta_A2B3C6D15 import ta_A2B3C6D15
        from bccc.ta.ta_A2B3C7D13 import ta_A2B3C7D13
        from bccc.ta.ta_A2B3C7D14 import ta_A2B3C7D14
        from bccc.ta.ta_A2B3C8D13 import ta_A2B3C8D13
        from bccc.ta.ta_A2B3C8D14 import ta_A2B3C8D14
        from bccc.ta.ta_A2B3C9D11 import ta_A2B3C9D11
        from bccc.ta.ta_A2B3C9D12 import ta_A2B3C9D12
        from bccc.ta.ta_A2B3C10D11 import ta_A2B3C10D11
        from bccc.ta.ta_A2B3C10D12 import ta_A2B3C10D12
        from bccc.ta.ta_A2B3C11D9 import ta_A2B3C11D9
        from bccc.ta.ta_A2B3C11D10 import ta_A2B3C11D10
        from bccc.ta.ta_A2B3C12D9 import ta_A2B3C12D9
        from bccc.ta.ta_A2B3C12D10 import ta_A2B3C12D10
        from bccc.ta.ta_A2B3C13D7 import ta_A2B3C13D7
        from bccc.ta.ta_A2B3C13D8 import ta_A2B3C13D8
        from bccc.ta.ta_A2B3C14D7 import ta_A2B3C14D7
        from bccc.ta.ta_A2B3C14D8 import ta_A2B3C14D8
        from bccc.ta.ta_A2B3C15D6 import ta_A2B3C15D6
        from bccc.ta.ta_A2B4C1D5 import ta_A2B4C1D5
        from bccc.ta.ta_A2B4C2D5 import ta_A2B4C2D5
        from bccc.ta.ta_A2B4C3D5 import ta_A2B4C3D5
        from bccc.ta.ta_A2B4C5D1 import ta_A2B4C5D1
        from bccc.ta.ta_A2B4C5D2 import ta_A2B4C5D2
        from bccc.ta.ta_A2B4C5D3 import ta_A2B4C5D3
        from bccc.ta.ta_A2B4C9D13 import ta_A2B4C9D13
        from bccc.ta.ta_A2B4C9D14 import ta_A2B4C9D14
        from bccc.ta.ta_A2B4C10D13 import ta_A2B4C10D13
        from bccc.ta.ta_A2B4C10D14 import ta_A2B4C10D14
        from bccc.ta.ta_A2B4C13D9 import ta_A2B4C13D9
        from bccc.ta.ta_A2B4C13D10 import ta_A2B4C13D10
        from bccc.ta.ta_A2B4C14D9 import ta_A2B4C14D9
        from bccc.ta.ta_A2B4C14D10 import ta_A2B4C14D10
        from bccc.ta.ta_A2B5C1D4 import ta_A2B5C1D4
        from bccc.ta.ta_A2B5C2D4 import ta_A2B5C2D4
        from bccc.ta.ta_A2B5C3D4 import ta_A2B5C3D4
        from bccc.ta.ta_A2B5C4D1 import ta_A2B5C4D1
        from bccc.ta.ta_A2B5C4D2 import ta_A2B5C4D2
        from bccc.ta.ta_A2B5C4D3 import ta_A2B5C4D3
        from bccc.ta.ta_A2B5C7D11 import ta_A2B5C7D11
        from bccc.ta.ta_A2B5C7D12 import ta_A2B5C7D12
        from bccc.ta.ta_A2B5C8D11 import ta_A2B5C8D11
        from bccc.ta.ta_A2B5C8D12 import ta_A2B5C8D12
        from bccc.ta.ta_A2B5C11D7 import ta_A2B5C11D7
        from bccc.ta.ta_A2B5C11D8 import ta_A2B5C11D8
        from bccc.ta.ta_A2B5C12D7 import ta_A2B5C12D7
        from bccc.ta.ta_A2B5C12D8 import ta_A2B5C12D8
        from bccc.ta.ta_A2B6C1D15 import ta_A2B6C1D15
        from bccc.ta.ta_A2B6C2D15 import ta_A2B6C2D15
        from bccc.ta.ta_A2B6C3D15 import ta_A2B6C3D15
        from bccc.ta.ta_A2B6C11D13 import ta_A2B6C11D13
        from bccc.ta.ta_A2B6C11D14 import ta_A2B6C11D14
        from bccc.ta.ta_A2B6C12D13 import ta_A2B6C12D13
        from bccc.ta.ta_A2B6C12D14 import ta_A2B6C12D14
        from bccc.ta.ta_A2B6C13D11 import ta_A2B6C13D11
        from bccc.ta.ta_A2B6C13D12 import ta_A2B6C13D12
        from bccc.ta.ta_A2B6C14D11 import ta_A2B6C14D11
        from bccc.ta.ta_A2B6C14D12 import ta_A2B6C14D12
        from bccc.ta.ta_A2B6C15D1 import ta_A2B6C15D1
        from bccc.ta.ta_A2B6C15D2 import ta_A2B6C15D2
        from bccc.ta.ta_A2B6C15D3 import ta_A2B6C15D3
        from bccc.ta.ta_A2B7C1D13 import ta_A2B7C1D13
        from bccc.ta.ta_A2B7C1D14 import ta_A2B7C1D14
        from bccc.ta.ta_A2B7C2D13 import ta_A2B7C2D13
        from bccc.ta.ta_A2B7C2D14 import ta_A2B7C2D14
        from bccc.ta.ta_A2B7C3D13 import ta_A2B7C3D13
        from bccc.ta.ta_A2B7C3D14 import ta_A2B7C3D14
        from bccc.ta.ta_A2B7C5D11 import ta_A2B7C5D11
        from bccc.ta.ta_A2B7C5D12 import ta_A2B7C5D12
        from bccc.ta.ta_A2B7C9D15 import ta_A2B7C9D15
        from bccc.ta.ta_A2B7C10D15 import ta_A2B7C10D15
        from bccc.ta.ta_A2B7C11D5 import ta_A2B7C11D5
        from bccc.ta.ta_A2B7C12D5 import ta_A2B7C12D5
        from bccc.ta.ta_A2B7C13D1 import ta_A2B7C13D1
        from bccc.ta.ta_A2B7C13D2 import ta_A2B7C13D2
        from bccc.ta.ta_A2B7C13D3 import ta_A2B7C13D3
        from bccc.ta.ta_A2B7C14D1 import ta_A2B7C14D1
        from bccc.ta.ta_A2B7C14D2 import ta_A2B7C14D2
        from bccc.ta.ta_A2B7C14D3 import ta_A2B7C14D3
        from bccc.ta.ta_A2B7C15D9 import ta_A2B7C15D9
        from bccc.ta.ta_A2B7C15D10 import ta_A2B7C15D10
        from bccc.ta.ta_A2B8C1D13 import ta_A2B8C1D13
        from bccc.ta.ta_A2B8C1D14 import ta_A2B8C1D14
        from bccc.ta.ta_A2B8C2D13 import ta_A2B8C2D13
        from bccc.ta.ta_A2B8C2D14 import ta_A2B8C2D14
        from bccc.ta.ta_A2B8C3D13 import ta_A2B8C3D13
        from bccc.ta.ta_A2B8C3D14 import ta_A2B8C3D14
        from bccc.ta.ta_A2B8C5D11 import ta_A2B8C5D11
        from bccc.ta.ta_A2B8C5D12 import ta_A2B8C5D12
        from bccc.ta.ta_A2B8C9D15 import ta_A2B8C9D15
        from bccc.ta.ta_A2B8C10D15 import ta_A2B8C10D15
        from bccc.ta.ta_A2B8C11D5 import ta_A2B8C11D5
        from bccc.ta.ta_A2B8C12D5 import ta_A2B8C12D5
        from bccc.ta.ta_A2B8C13D1 import ta_A2B8C13D1
        from bccc.ta.ta_A2B8C13D2 import ta_A2B8C13D2
        from bccc.ta.ta_A2B8C13D3 import ta_A2B8C13D3
        from bccc.ta.ta_A2B8C14D1 import ta_A2B8C14D1
        from bccc.ta.ta_A2B8C14D2 import ta_A2B8C14D2
        from bccc.ta.ta_A2B8C14D3 import ta_A2B8C14D3
        from bccc.ta.ta_A2B8C15D9 import ta_A2B8C15D9
        from bccc.ta.ta_A2B8C15D10 import ta_A2B8C15D10
        from bccc.ta.ta_A2B9C1D11 import ta_A2B9C1D11
        from bccc.ta.ta_A2B9C1D12 import ta_A2B9C1D12
        from bccc.ta.ta_A2B9C2D11 import ta_A2B9C2D11
        from bccc.ta.ta_A2B9C2D12 import ta_A2B9C2D12
        from bccc.ta.ta_A2B9C3D11 import ta_A2B9C3D11
        from bccc.ta.ta_A2B9C3D12 import ta_A2B9C3D12
        from bccc.ta.ta_A2B9C4D13 import ta_A2B9C4D13
        from bccc.ta.ta_A2B9C4D14 import ta_A2B9C4D14
        from bccc.ta.ta_A2B9C7D15 import ta_A2B9C7D15
        from bccc.ta.ta_A2B9C8D15 import ta_A2B9C8D15
        from bccc.ta.ta_A2B9C11D1 import ta_A2B9C11D1
        from bccc.ta.ta_A2B9C11D2 import ta_A2B9C11D2
        from bccc.ta.ta_A2B9C11D3 import ta_A2B9C11D3
        from bccc.ta.ta_A2B9C12D1 import ta_A2B9C12D1
        from bccc.ta.ta_A2B9C12D2 import ta_A2B9C12D2
        from bccc.ta.ta_A2B9C12D3 import ta_A2B9C12D3
        from bccc.ta.ta_A2B9C13D4 import ta_A2B9C13D4
        from bccc.ta.ta_A2B9C14D4 import ta_A2B9C14D4
        from bccc.ta.ta_A2B9C15D7 import ta_A2B9C15D7
        from bccc.ta.ta_A2B9C15D8 import ta_A2B9C15D8
        from bccc.ta.ta_A2B10C1D11 import ta_A2B10C1D11
        from bccc.ta.ta_A2B10C1D12 import ta_A2B10C1D12
        from bccc.ta.ta_A2B10C2D11 import ta_A2B10C2D11
        from bccc.ta.ta_A2B10C2D12 import ta_A2B10C2D12
        from bccc.ta.ta_A2B10C3D11 import ta_A2B10C3D11
        from bccc.ta.ta_A2B10C3D12 import ta_A2B10C3D12
        from bccc.ta.ta_A2B10C4D13 import ta_A2B10C4D13
        from bccc.ta.ta_A2B10C4D14 import ta_A2B10C4D14
        from bccc.ta.ta_A2B10C7D15 import ta_A2B10C7D15
        from bccc.ta.ta_A2B10C8D15 import ta_A2B10C8D15
        from bccc.ta.ta_A2B10C11D1 import ta_A2B10C11D1
        from bccc.ta.ta_A2B10C11D2 import ta_A2B10C11D2
        from bccc.ta.ta_A2B10C11D3 import ta_A2B10C11D3
        from bccc.ta.ta_A2B10C12D1 import ta_A2B10C12D1
        from bccc.ta.ta_A2B10C12D2 import ta_A2B10C12D2
        from bccc.ta.ta_A2B10C12D3 import ta_A2B10C12D3
        from bccc.ta.ta_A2B10C13D4 import ta_A2B10C13D4
        from bccc.ta.ta_A2B10C14D4 import ta_A2B10C14D4
        from bccc.ta.ta_A2B10C15D7 import ta_A2B10C15D7
        from bccc.ta.ta_A2B10C15D8 import ta_A2B10C15D8
        from bccc.ta.ta_A2B11C1D9 import ta_A2B11C1D9
        from bccc.ta.ta_A2B11C1D10 import ta_A2B11C1D10
        from bccc.ta.ta_A2B11C2D9 import ta_A2B11C2D9
        from bccc.ta.ta_A2B11C2D10 import ta_A2B11C2D10
        from bccc.ta.ta_A2B11C3D9 import ta_A2B11C3D9
        from bccc.ta.ta_A2B11C3D10 import ta_A2B11C3D10
        from bccc.ta.ta_A2B11C5D7 import ta_A2B11C5D7
        from bccc.ta.ta_A2B11C5D8 import ta_A2B11C5D8
        from bccc.ta.ta_A2B11C6D13 import ta_A2B11C6D13
        from bccc.ta.ta_A2B11C6D14 import ta_A2B11C6D14
        from bccc.ta.ta_A2B11C7D5 import ta_A2B11C7D5
        from bccc.ta.ta_A2B11C8D5 import ta_A2B11C8D5
        from bccc.ta.ta_A2B11C9D1 import ta_A2B11C9D1
        from bccc.ta.ta_A2B11C9D2 import ta_A2B11C9D2
        from bccc.ta.ta_A2B11C9D3 import ta_A2B11C9D3
        from bccc.ta.ta_A2B11C10D1 import ta_A2B11C10D1
        from bccc.ta.ta_A2B11C10D2 import ta_A2B11C10D2
        from bccc.ta.ta_A2B11C10D3 import ta_A2B11C10D3
        from bccc.ta.ta_A2B11C13D6 import ta_A2B11C13D6
        from bccc.ta.ta_A2B11C14D6 import ta_A2B11C14D6
        from bccc.ta.ta_A2B12C1D9 import ta_A2B12C1D9
        from bccc.ta.ta_A2B12C1D10 import ta_A2B12C1D10
        from bccc.ta.ta_A2B12C2D9 import ta_A2B12C2D9
        from bccc.ta.ta_A2B12C2D10 import ta_A2B12C2D10
        from bccc.ta.ta_A2B12C3D9 import ta_A2B12C3D9
        from bccc.ta.ta_A2B12C3D10 import ta_A2B12C3D10
        from bccc.ta.ta_A2B12C5D7 import ta_A2B12C5D7
        from bccc.ta.ta_A2B12C5D8 import ta_A2B12C5D8
        from bccc.ta.ta_A2B12C6D13 import ta_A2B12C6D13
        from bccc.ta.ta_A2B12C6D14 import ta_A2B12C6D14
        from bccc.ta.ta_A2B12C7D5 import ta_A2B12C7D5
        from bccc.ta.ta_A2B12C8D5 import ta_A2B12C8D5
        from bccc.ta.ta_A2B12C9D1 import ta_A2B12C9D1
        from bccc.ta.ta_A2B12C9D2 import ta_A2B12C9D2
        from bccc.ta.ta_A2B12C9D3 import ta_A2B12C9D3
        from bccc.ta.ta_A2B12C10D1 import ta_A2B12C10D1
        from bccc.ta.ta_A2B12C10D2 import ta_A2B12C10D2
        from bccc.ta.ta_A2B12C10D3 import ta_A2B12C10D3
        from bccc.ta.ta_A2B12C13D6 import ta_A2B12C13D6
        from bccc.ta.ta_A2B12C14D6 import ta_A2B12C14D6
        from bccc.ta.ta_A2B13C1D7 import ta_A2B13C1D7
        from bccc.ta.ta_A2B13C1D8 import ta_A2B13C1D8
        from bccc.ta.ta_A2B13C2D7 import ta_A2B13C2D7
        from bccc.ta.ta_A2B13C2D8 import ta_A2B13C2D8
        from bccc.ta.ta_A2B13C3D7 import ta_A2B13C3D7
        from bccc.ta.ta_A2B13C3D8 import ta_A2B13C3D8
        from bccc.ta.ta_A2B13C4D9 import ta_A2B13C4D9
        from bccc.ta.ta_A2B13C4D10 import ta_A2B13C4D10
        from bccc.ta.ta_A2B13C6D11 import ta_A2B13C6D11
        from bccc.ta.ta_A2B13C6D12 import ta_A2B13C6D12
        from bccc.ta.ta_A2B13C7D1 import ta_A2B13C7D1
        from bccc.ta.ta_A2B13C7D2 import ta_A2B13C7D2
        from bccc.ta.ta_A2B13C7D3 import ta_A2B13C7D3
        from bccc.ta.ta_A2B13C8D1 import ta_A2B13C8D1
        from bccc.ta.ta_A2B13C8D2 import ta_A2B13C8D2
        from bccc.ta.ta_A2B13C8D3 import ta_A2B13C8D3
        from bccc.ta.ta_A2B13C9D4 import ta_A2B13C9D4
        from bccc.ta.ta_A2B13C10D4 import ta_A2B13C10D4
        from bccc.ta.ta_A2B13C11D6 import ta_A2B13C11D6
        from bccc.ta.ta_A2B13C12D6 import ta_A2B13C12D6
        from bccc.ta.ta_A2B14C1D7 import ta_A2B14C1D7
        from bccc.ta.ta_A2B14C1D8 import ta_A2B14C1D8
        from bccc.ta.ta_A2B14C2D7 import ta_A2B14C2D7
        from bccc.ta.ta_A2B14C2D8 import ta_A2B14C2D8
        from bccc.ta.ta_A2B14C3D7 import ta_A2B14C3D7
        from bccc.ta.ta_A2B14C3D8 import ta_A2B14C3D8
        from bccc.ta.ta_A2B14C4D9 import ta_A2B14C4D9
        from bccc.ta.ta_A2B14C4D10 import ta_A2B14C4D10
        from bccc.ta.ta_A2B14C6D11 import ta_A2B14C6D11
        from bccc.ta.ta_A2B14C6D12 import ta_A2B14C6D12
        from bccc.ta.ta_A2B14C7D1 import ta_A2B14C7D1
        from bccc.ta.ta_A2B14C7D2 import ta_A2B14C7D2
        from bccc.ta.ta_A2B14C7D3 import ta_A2B14C7D3
        from bccc.ta.ta_A2B14C8D1 import ta_A2B14C8D1
        from bccc.ta.ta_A2B14C8D2 import ta_A2B14C8D2
        from bccc.ta.ta_A2B14C8D3 import ta_A2B14C8D3
        from bccc.ta.ta_A2B14C9D4 import ta_A2B14C9D4
        from bccc.ta.ta_A2B14C10D4 import ta_A2B14C10D4
        from bccc.ta.ta_A2B14C11D6 import ta_A2B14C11D6
        from bccc.ta.ta_A2B14C12D6 import ta_A2B14C12D6
        from bccc.ta.ta_A2B15C1D6 import ta_A2B15C1D6
        from bccc.ta.ta_A2B15C2D6 import ta_A2B15C2D6
        from bccc.ta.ta_A2B15C3D6 import ta_A2B15C3D6
        from bccc.ta.ta_A2B15C6D1 import ta_A2B15C6D1
        from bccc.ta.ta_A2B15C6D2 import ta_A2B15C6D2
        from bccc.ta.ta_A2B15C6D3 import ta_A2B15C6D3
        from bccc.ta.ta_A2B15C7D9 import ta_A2B15C7D9
        from bccc.ta.ta_A2B15C7D10 import ta_A2B15C7D10
        from bccc.ta.ta_A2B15C8D9 import ta_A2B15C8D9
        from bccc.ta.ta_A2B15C8D10 import ta_A2B15C8D10
        from bccc.ta.ta_A2B15C9D7 import ta_A2B15C9D7
        from bccc.ta.ta_A2B15C9D8 import ta_A2B15C9D8
        from bccc.ta.ta_A2B15C10D7 import ta_A2B15C10D7
        from bccc.ta.ta_A2B15C10D8 import ta_A2B15C10D8
        from bccc.ta.ta_A3B1C1D1 import ta_A3B1C1D1
        from bccc.ta.ta_A3B1C1D2 import ta_A3B1C1D2
        from bccc.ta.ta_A3B1C1D3 import ta_A3B1C1D3
        from bccc.ta.ta_A3B1C2D1 import ta_A3B1C2D1
        from bccc.ta.ta_A3B1C2D2 import ta_A3B1C2D2
        from bccc.ta.ta_A3B1C2D3 import ta_A3B1C2D3
        from bccc.ta.ta_A3B1C3D1 import ta_A3B1C3D1
        from bccc.ta.ta_A3B1C3D2 import ta_A3B1C3D2
        from bccc.ta.ta_A3B1C3D3 import ta_A3B1C3D3
        from bccc.ta.ta_A3B1C4D5 import ta_A3B1C4D5
        from bccc.ta.ta_A3B1C5D4 import ta_A3B1C5D4
        from bccc.ta.ta_A3B1C6D15 import ta_A3B1C6D15
        from bccc.ta.ta_A3B1C7D13 import ta_A3B1C7D13
        from bccc.ta.ta_A3B1C7D14 import ta_A3B1C7D14
        from bccc.ta.ta_A3B1C8D13 import ta_A3B1C8D13
        from bccc.ta.ta_A3B1C8D14 import ta_A3B1C8D14
        from bccc.ta.ta_A3B1C9D11 import ta_A3B1C9D11
        from bccc.ta.ta_A3B1C9D12 import ta_A3B1C9D12
        from bccc.ta.ta_A3B1C10D11 import ta_A3B1C10D11
        from bccc.ta.ta_A3B1C10D12 import ta_A3B1C10D12
        from bccc.ta.ta_A3B1C11D9 import ta_A3B1C11D9
        from bccc.ta.ta_A3B1C11D10 import ta_A3B1C11D10
        from bccc.ta.ta_A3B1C12D9 import ta_A3B1C12D9
        from bccc.ta.ta_A3B1C12D10 import ta_A3B1C12D10
        from bccc.ta.ta_A3B1C13D7 import ta_A3B1C13D7
        from bccc.ta.ta_A3B1C13D8 import ta_A3B1C13D8
        from bccc.ta.ta_A3B1C14D7 import ta_A3B1C14D7
        from bccc.ta.ta_A3B1C14D8 import ta_A3B1C14D8
        from bccc.ta.ta_A3B1C15D6 import ta_A3B1C15D6
        from bccc.ta.ta_A3B2C1D1 import ta_A3B2C1D1
        from bccc.ta.ta_A3B2C1D2 import ta_A3B2C1D2
        from bccc.ta.ta_A3B2C1D3 import ta_A3B2C1D3
        from bccc.ta.ta_A3B2C2D1 import ta_A3B2C2D1
        from bccc.ta.ta_A3B2C2D2 import ta_A3B2C2D2
        from bccc.ta.ta_A3B2C2D3 import ta_A3B2C2D3
        from bccc.ta.ta_A3B2C3D1 import ta_A3B2C3D1
        from bccc.ta.ta_A3B2C3D2 import ta_A3B2C3D2
        from bccc.ta.ta_A3B2C3D3 import ta_A3B2C3D3
        from bccc.ta.ta_A3B2C4D5 import ta_A3B2C4D5
        from bccc.ta.ta_A3B2C5D4 import ta_A3B2C5D4
        from bccc.ta.ta_A3B2C6D15 import ta_A3B2C6D15
        from bccc.ta.ta_A3B2C7D13 import ta_A3B2C7D13
        from bccc.ta.ta_A3B2C7D14 import ta_A3B2C7D14
        from bccc.ta.ta_A3B2C8D13 import ta_A3B2C8D13
        from bccc.ta.ta_A3B2C8D14 import ta_A3B2C8D14
        from bccc.ta.ta_A3B2C9D11 import ta_A3B2C9D11
        from bccc.ta.ta_A3B2C9D12 import ta_A3B2C9D12
        from bccc.ta.ta_A3B2C10D11 import ta_A3B2C10D11
        from bccc.ta.ta_A3B2C10D12 import ta_A3B2C10D12
        from bccc.ta.ta_A3B2C11D9 import ta_A3B2C11D9
        from bccc.ta.ta_A3B2C11D10 import ta_A3B2C11D10
        from bccc.ta.ta_A3B2C12D9 import ta_A3B2C12D9
        from bccc.ta.ta_A3B2C12D10 import ta_A3B2C12D10
        from bccc.ta.ta_A3B2C13D7 import ta_A3B2C13D7
        from bccc.ta.ta_A3B2C13D8 import ta_A3B2C13D8
        from bccc.ta.ta_A3B2C14D7 import ta_A3B2C14D7
        from bccc.ta.ta_A3B2C14D8 import ta_A3B2C14D8
        from bccc.ta.ta_A3B2C15D6 import ta_A3B2C15D6
        from bccc.ta.ta_A3B3C1D1 import ta_A3B3C1D1
        from bccc.ta.ta_A3B3C1D2 import ta_A3B3C1D2
        from bccc.ta.ta_A3B3C1D3 import ta_A3B3C1D3
        from bccc.ta.ta_A3B3C2D1 import ta_A3B3C2D1
        from bccc.ta.ta_A3B3C2D2 import ta_A3B3C2D2
        from bccc.ta.ta_A3B3C2D3 import ta_A3B3C2D3
        from bccc.ta.ta_A3B3C3D1 import ta_A3B3C3D1
        from bccc.ta.ta_A3B3C3D2 import ta_A3B3C3D2
        from bccc.ta.ta_A3B3C3D3 import ta_A3B3C3D3
        from bccc.ta.ta_A3B3C4D5 import ta_A3B3C4D5
        from bccc.ta.ta_A3B3C5D4 import ta_A3B3C5D4
        from bccc.ta.ta_A3B3C6D15 import ta_A3B3C6D15
        from bccc.ta.ta_A3B3C7D13 import ta_A3B3C7D13
        from bccc.ta.ta_A3B3C7D14 import ta_A3B3C7D14
        from bccc.ta.ta_A3B3C8D13 import ta_A3B3C8D13
        from bccc.ta.ta_A3B3C8D14 import ta_A3B3C8D14
        from bccc.ta.ta_A3B3C9D11 import ta_A3B3C9D11
        from bccc.ta.ta_A3B3C9D12 import ta_A3B3C9D12
        from bccc.ta.ta_A3B3C10D11 import ta_A3B3C10D11
        from bccc.ta.ta_A3B3C10D12 import ta_A3B3C10D12
        from bccc.ta.ta_A3B3C11D9 import ta_A3B3C11D9
        from bccc.ta.ta_A3B3C11D10 import ta_A3B3C11D10
        from bccc.ta.ta_A3B3C12D9 import ta_A3B3C12D9
        from bccc.ta.ta_A3B3C12D10 import ta_A3B3C12D10
        from bccc.ta.ta_A3B3C13D7 import ta_A3B3C13D7
        from bccc.ta.ta_A3B3C13D8 import ta_A3B3C13D8
        from bccc.ta.ta_A3B3C14D7 import ta_A3B3C14D7
        from bccc.ta.ta_A3B3C14D8 import ta_A3B3C14D8
        from bccc.ta.ta_A3B3C15D6 import ta_A3B3C15D6
        from bccc.ta.ta_A3B4C1D5 import ta_A3B4C1D5
        from bccc.ta.ta_A3B4C2D5 import ta_A3B4C2D5
        from bccc.ta.ta_A3B4C3D5 import ta_A3B4C3D5
        from bccc.ta.ta_A3B4C5D1 import ta_A3B4C5D1
        from bccc.ta.ta_A3B4C5D2 import ta_A3B4C5D2
        from bccc.ta.ta_A3B4C5D3 import ta_A3B4C5D3
        from bccc.ta.ta_A3B4C9D13 import ta_A3B4C9D13
        from bccc.ta.ta_A3B4C9D14 import ta_A3B4C9D14
        from bccc.ta.ta_A3B4C10D13 import ta_A3B4C10D13
        from bccc.ta.ta_A3B4C10D14 import ta_A3B4C10D14
        from bccc.ta.ta_A3B4C13D9 import ta_A3B4C13D9
        from bccc.ta.ta_A3B4C13D10 import ta_A3B4C13D10
        from bccc.ta.ta_A3B4C14D9 import ta_A3B4C14D9
        from bccc.ta.ta_A3B4C14D10 import ta_A3B4C14D10
        from bccc.ta.ta_A3B5C1D4 import ta_A3B5C1D4
        from bccc.ta.ta_A3B5C2D4 import ta_A3B5C2D4
        from bccc.ta.ta_A3B5C3D4 import ta_A3B5C3D4
        from bccc.ta.ta_A3B5C4D1 import ta_A3B5C4D1
        from bccc.ta.ta_A3B5C4D2 import ta_A3B5C4D2
        from bccc.ta.ta_A3B5C4D3 import ta_A3B5C4D3
        from bccc.ta.ta_A3B5C7D11 import ta_A3B5C7D11
        from bccc.ta.ta_A3B5C7D12 import ta_A3B5C7D12
        from bccc.ta.ta_A3B5C8D11 import ta_A3B5C8D11
        from bccc.ta.ta_A3B5C8D12 import ta_A3B5C8D12
        from bccc.ta.ta_A3B5C11D7 import ta_A3B5C11D7
        from bccc.ta.ta_A3B5C11D8 import ta_A3B5C11D8
        from bccc.ta.ta_A3B5C12D7 import ta_A3B5C12D7
        from bccc.ta.ta_A3B5C12D8 import ta_A3B5C12D8
        from bccc.ta.ta_A3B6C1D15 import ta_A3B6C1D15
        from bccc.ta.ta_A3B6C2D15 import ta_A3B6C2D15
        from bccc.ta.ta_A3B6C3D15 import ta_A3B6C3D15
        from bccc.ta.ta_A3B6C11D13 import ta_A3B6C11D13
        from bccc.ta.ta_A3B6C11D14 import ta_A3B6C11D14
        from bccc.ta.ta_A3B6C12D13 import ta_A3B6C12D13
        from bccc.ta.ta_A3B6C12D14 import ta_A3B6C12D14
        from bccc.ta.ta_A3B6C13D11 import ta_A3B6C13D11
        from bccc.ta.ta_A3B6C13D12 import ta_A3B6C13D12
        from bccc.ta.ta_A3B6C14D11 import ta_A3B6C14D11
        from bccc.ta.ta_A3B6C14D12 import ta_A3B6C14D12
        from bccc.ta.ta_A3B6C15D1 import ta_A3B6C15D1
        from bccc.ta.ta_A3B6C15D2 import ta_A3B6C15D2
        from bccc.ta.ta_A3B6C15D3 import ta_A3B6C15D3
        from bccc.ta.ta_A3B7C1D13 import ta_A3B7C1D13
        from bccc.ta.ta_A3B7C1D14 import ta_A3B7C1D14
        from bccc.ta.ta_A3B7C2D13 import ta_A3B7C2D13
        from bccc.ta.ta_A3B7C2D14 import ta_A3B7C2D14
        from bccc.ta.ta_A3B7C3D13 import ta_A3B7C3D13
        from bccc.ta.ta_A3B7C3D14 import ta_A3B7C3D14
        from bccc.ta.ta_A3B7C5D11 import ta_A3B7C5D11
        from bccc.ta.ta_A3B7C5D12 import ta_A3B7C5D12
        from bccc.ta.ta_A3B7C9D15 import ta_A3B7C9D15
        from bccc.ta.ta_A3B7C10D15 import ta_A3B7C10D15
        from bccc.ta.ta_A3B7C11D5 import ta_A3B7C11D5
        from bccc.ta.ta_A3B7C12D5 import ta_A3B7C12D5
        from bccc.ta.ta_A3B7C13D1 import ta_A3B7C13D1
        from bccc.ta.ta_A3B7C13D2 import ta_A3B7C13D2
        from bccc.ta.ta_A3B7C13D3 import ta_A3B7C13D3
        from bccc.ta.ta_A3B7C14D1 import ta_A3B7C14D1
        from bccc.ta.ta_A3B7C14D2 import ta_A3B7C14D2
        from bccc.ta.ta_A3B7C14D3 import ta_A3B7C14D3
        from bccc.ta.ta_A3B7C15D9 import ta_A3B7C15D9
        from bccc.ta.ta_A3B7C15D10 import ta_A3B7C15D10
        from bccc.ta.ta_A3B8C1D13 import ta_A3B8C1D13
        from bccc.ta.ta_A3B8C1D14 import ta_A3B8C1D14
        from bccc.ta.ta_A3B8C2D13 import ta_A3B8C2D13
        from bccc.ta.ta_A3B8C2D14 import ta_A3B8C2D14
        from bccc.ta.ta_A3B8C3D13 import ta_A3B8C3D13
        from bccc.ta.ta_A3B8C3D14 import ta_A3B8C3D14
        from bccc.ta.ta_A3B8C5D11 import ta_A3B8C5D11
        from bccc.ta.ta_A3B8C5D12 import ta_A3B8C5D12
        from bccc.ta.ta_A3B8C9D15 import ta_A3B8C9D15
        from bccc.ta.ta_A3B8C10D15 import ta_A3B8C10D15
        from bccc.ta.ta_A3B8C11D5 import ta_A3B8C11D5
        from bccc.ta.ta_A3B8C12D5 import ta_A3B8C12D5
        from bccc.ta.ta_A3B8C13D1 import ta_A3B8C13D1
        from bccc.ta.ta_A3B8C13D2 import ta_A3B8C13D2
        from bccc.ta.ta_A3B8C13D3 import ta_A3B8C13D3
        from bccc.ta.ta_A3B8C14D1 import ta_A3B8C14D1
        from bccc.ta.ta_A3B8C14D2 import ta_A3B8C14D2
        from bccc.ta.ta_A3B8C14D3 import ta_A3B8C14D3
        from bccc.ta.ta_A3B8C15D9 import ta_A3B8C15D9
        from bccc.ta.ta_A3B8C15D10 import ta_A3B8C15D10
        from bccc.ta.ta_A3B9C1D11 import ta_A3B9C1D11
        from bccc.ta.ta_A3B9C1D12 import ta_A3B9C1D12
        from bccc.ta.ta_A3B9C2D11 import ta_A3B9C2D11
        from bccc.ta.ta_A3B9C2D12 import ta_A3B9C2D12
        from bccc.ta.ta_A3B9C3D11 import ta_A3B9C3D11
        from bccc.ta.ta_A3B9C3D12 import ta_A3B9C3D12
        from bccc.ta.ta_A3B9C4D13 import ta_A3B9C4D13
        from bccc.ta.ta_A3B9C4D14 import ta_A3B9C4D14
        from bccc.ta.ta_A3B9C7D15 import ta_A3B9C7D15
        from bccc.ta.ta_A3B9C8D15 import ta_A3B9C8D15
        from bccc.ta.ta_A3B9C11D1 import ta_A3B9C11D1
        from bccc.ta.ta_A3B9C11D2 import ta_A3B9C11D2
        from bccc.ta.ta_A3B9C11D3 import ta_A3B9C11D3
        from bccc.ta.ta_A3B9C12D1 import ta_A3B9C12D1
        from bccc.ta.ta_A3B9C12D2 import ta_A3B9C12D2
        from bccc.ta.ta_A3B9C12D3 import ta_A3B9C12D3
        from bccc.ta.ta_A3B9C13D4 import ta_A3B9C13D4
        from bccc.ta.ta_A3B9C14D4 import ta_A3B9C14D4
        from bccc.ta.ta_A3B9C15D7 import ta_A3B9C15D7
        from bccc.ta.ta_A3B9C15D8 import ta_A3B9C15D8
        from bccc.ta.ta_A3B10C1D11 import ta_A3B10C1D11
        from bccc.ta.ta_A3B10C1D12 import ta_A3B10C1D12
        from bccc.ta.ta_A3B10C2D11 import ta_A3B10C2D11
        from bccc.ta.ta_A3B10C2D12 import ta_A3B10C2D12
        from bccc.ta.ta_A3B10C3D11 import ta_A3B10C3D11
        from bccc.ta.ta_A3B10C3D12 import ta_A3B10C3D12
        from bccc.ta.ta_A3B10C4D13 import ta_A3B10C4D13
        from bccc.ta.ta_A3B10C4D14 import ta_A3B10C4D14
        from bccc.ta.ta_A3B10C7D15 import ta_A3B10C7D15
        from bccc.ta.ta_A3B10C8D15 import ta_A3B10C8D15
        from bccc.ta.ta_A3B10C11D1 import ta_A3B10C11D1
        from bccc.ta.ta_A3B10C11D2 import ta_A3B10C11D2
        from bccc.ta.ta_A3B10C11D3 import ta_A3B10C11D3
        from bccc.ta.ta_A3B10C12D1 import ta_A3B10C12D1
        from bccc.ta.ta_A3B10C12D2 import ta_A3B10C12D2
        from bccc.ta.ta_A3B10C12D3 import ta_A3B10C12D3
        from bccc.ta.ta_A3B10C13D4 import ta_A3B10C13D4
        from bccc.ta.ta_A3B10C14D4 import ta_A3B10C14D4
        from bccc.ta.ta_A3B10C15D7 import ta_A3B10C15D7
        from bccc.ta.ta_A3B10C15D8 import ta_A3B10C15D8
        from bccc.ta.ta_A3B11C1D9 import ta_A3B11C1D9
        from bccc.ta.ta_A3B11C1D10 import ta_A3B11C1D10
        from bccc.ta.ta_A3B11C2D9 import ta_A3B11C2D9
        from bccc.ta.ta_A3B11C2D10 import ta_A3B11C2D10
        from bccc.ta.ta_A3B11C3D9 import ta_A3B11C3D9
        from bccc.ta.ta_A3B11C3D10 import ta_A3B11C3D10
        from bccc.ta.ta_A3B11C5D7 import ta_A3B11C5D7
        from bccc.ta.ta_A3B11C5D8 import ta_A3B11C5D8
        from bccc.ta.ta_A3B11C6D13 import ta_A3B11C6D13
        from bccc.ta.ta_A3B11C6D14 import ta_A3B11C6D14
        from bccc.ta.ta_A3B11C7D5 import ta_A3B11C7D5
        from bccc.ta.ta_A3B11C8D5 import ta_A3B11C8D5
        from bccc.ta.ta_A3B11C9D1 import ta_A3B11C9D1
        from bccc.ta.ta_A3B11C9D2 import ta_A3B11C9D2
        from bccc.ta.ta_A3B11C9D3 import ta_A3B11C9D3
        from bccc.ta.ta_A3B11C10D1 import ta_A3B11C10D1
        from bccc.ta.ta_A3B11C10D2 import ta_A3B11C10D2
        from bccc.ta.ta_A3B11C10D3 import ta_A3B11C10D3
        from bccc.ta.ta_A3B11C13D6 import ta_A3B11C13D6
        from bccc.ta.ta_A3B11C14D6 import ta_A3B11C14D6
        from bccc.ta.ta_A3B12C1D9 import ta_A3B12C1D9
        from bccc.ta.ta_A3B12C1D10 import ta_A3B12C1D10
        from bccc.ta.ta_A3B12C2D9 import ta_A3B12C2D9
        from bccc.ta.ta_A3B12C2D10 import ta_A3B12C2D10
        from bccc.ta.ta_A3B12C3D9 import ta_A3B12C3D9
        from bccc.ta.ta_A3B12C3D10 import ta_A3B12C3D10
        from bccc.ta.ta_A3B12C5D7 import ta_A3B12C5D7
        from bccc.ta.ta_A3B12C5D8 import ta_A3B12C5D8
        from bccc.ta.ta_A3B12C6D13 import ta_A3B12C6D13
        from bccc.ta.ta_A3B12C6D14 import ta_A3B12C6D14
        from bccc.ta.ta_A3B12C7D5 import ta_A3B12C7D5
        from bccc.ta.ta_A3B12C8D5 import ta_A3B12C8D5
        from bccc.ta.ta_A3B12C9D1 import ta_A3B12C9D1
        from bccc.ta.ta_A3B12C9D2 import ta_A3B12C9D2
        from bccc.ta.ta_A3B12C9D3 import ta_A3B12C9D3
        from bccc.ta.ta_A3B12C10D1 import ta_A3B12C10D1
        from bccc.ta.ta_A3B12C10D2 import ta_A3B12C10D2
        from bccc.ta.ta_A3B12C10D3 import ta_A3B12C10D3
        from bccc.ta.ta_A3B12C13D6 import ta_A3B12C13D6
        from bccc.ta.ta_A3B12C14D6 import ta_A3B12C14D6
        from bccc.ta.ta_A3B13C1D7 import ta_A3B13C1D7
        from bccc.ta.ta_A3B13C1D8 import ta_A3B13C1D8
        from bccc.ta.ta_A3B13C2D7 import ta_A3B13C2D7
        from bccc.ta.ta_A3B13C2D8 import ta_A3B13C2D8
        from bccc.ta.ta_A3B13C3D7 import ta_A3B13C3D7
        from bccc.ta.ta_A3B13C3D8 import ta_A3B13C3D8
        from bccc.ta.ta_A3B13C4D9 import ta_A3B13C4D9
        from bccc.ta.ta_A3B13C4D10 import ta_A3B13C4D10
        from bccc.ta.ta_A3B13C6D11 import ta_A3B13C6D11
        from bccc.ta.ta_A3B13C6D12 import ta_A3B13C6D12
        from bccc.ta.ta_A3B13C7D1 import ta_A3B13C7D1
        from bccc.ta.ta_A3B13C7D2 import ta_A3B13C7D2
        from bccc.ta.ta_A3B13C7D3 import ta_A3B13C7D3
        from bccc.ta.ta_A3B13C8D1 import ta_A3B13C8D1
        from bccc.ta.ta_A3B13C8D2 import ta_A3B13C8D2
        from bccc.ta.ta_A3B13C8D3 import ta_A3B13C8D3
        from bccc.ta.ta_A3B13C9D4 import ta_A3B13C9D4
        from bccc.ta.ta_A3B13C10D4 import ta_A3B13C10D4
        from bccc.ta.ta_A3B13C11D6 import ta_A3B13C11D6
        from bccc.ta.ta_A3B13C12D6 import ta_A3B13C12D6
        from bccc.ta.ta_A3B14C1D7 import ta_A3B14C1D7
        from bccc.ta.ta_A3B14C1D8 import ta_A3B14C1D8
        from bccc.ta.ta_A3B14C2D7 import ta_A3B14C2D7
        from bccc.ta.ta_A3B14C2D8 import ta_A3B14C2D8
        from bccc.ta.ta_A3B14C3D7 import ta_A3B14C3D7
        from bccc.ta.ta_A3B14C3D8 import ta_A3B14C3D8
        from bccc.ta.ta_A3B14C4D9 import ta_A3B14C4D9
        from bccc.ta.ta_A3B14C4D10 import ta_A3B14C4D10
        from bccc.ta.ta_A3B14C6D11 import ta_A3B14C6D11
        from bccc.ta.ta_A3B14C6D12 import ta_A3B14C6D12
        from bccc.ta.ta_A3B14C7D1 import ta_A3B14C7D1
        from bccc.ta.ta_A3B14C7D2 import ta_A3B14C7D2
        from bccc.ta.ta_A3B14C7D3 import ta_A3B14C7D3
        from bccc.ta.ta_A3B14C8D1 import ta_A3B14C8D1
        from bccc.ta.ta_A3B14C8D2 import ta_A3B14C8D2
        from bccc.ta.ta_A3B14C8D3 import ta_A3B14C8D3
        from bccc.ta.ta_A3B14C9D4 import ta_A3B14C9D4
        from bccc.ta.ta_A3B14C10D4 import ta_A3B14C10D4
        from bccc.ta.ta_A3B14C11D6 import ta_A3B14C11D6
        from bccc.ta.ta_A3B14C12D6 import ta_A3B14C12D6
        from bccc.ta.ta_A3B15C1D6 import ta_A3B15C1D6
        from bccc.ta.ta_A3B15C2D6 import ta_A3B15C2D6
        from bccc.ta.ta_A3B15C3D6 import ta_A3B15C3D6
        from bccc.ta.ta_A3B15C6D1 import ta_A3B15C6D1
        from bccc.ta.ta_A3B15C6D2 import ta_A3B15C6D2
        from bccc.ta.ta_A3B15C6D3 import ta_A3B15C6D3
        from bccc.ta.ta_A3B15C7D9 import ta_A3B15C7D9
        from bccc.ta.ta_A3B15C7D10 import ta_A3B15C7D10
        from bccc.ta.ta_A3B15C8D9 import ta_A3B15C8D9
        from bccc.ta.ta_A3B15C8D10 import ta_A3B15C8D10
        from bccc.ta.ta_A3B15C9D7 import ta_A3B15C9D7
        from bccc.ta.ta_A3B15C9D8 import ta_A3B15C9D8
        from bccc.ta.ta_A3B15C10D7 import ta_A3B15C10D7
        from bccc.ta.ta_A3B15C10D8 import ta_A3B15C10D8
        from bccc.ta.ta_A4B1C1D5 import ta_A4B1C1D5
        from bccc.ta.ta_A4B1C2D5 import ta_A4B1C2D5
        from bccc.ta.ta_A4B1C3D5 import ta_A4B1C3D5
        from bccc.ta.ta_A4B1C5D1 import ta_A4B1C5D1
        from bccc.ta.ta_A4B1C5D2 import ta_A4B1C5D2
        from bccc.ta.ta_A4B1C5D3 import ta_A4B1C5D3
        from bccc.ta.ta_A4B1C9D13 import ta_A4B1C9D13
        from bccc.ta.ta_A4B1C9D14 import ta_A4B1C9D14
        from bccc.ta.ta_A4B1C10D13 import ta_A4B1C10D13
        from bccc.ta.ta_A4B1C10D14 import ta_A4B1C10D14
        from bccc.ta.ta_A4B1C13D9 import ta_A4B1C13D9
        from bccc.ta.ta_A4B1C13D10 import ta_A4B1C13D10
        from bccc.ta.ta_A4B1C14D9 import ta_A4B1C14D9
        from bccc.ta.ta_A4B1C14D10 import ta_A4B1C14D10
        from bccc.ta.ta_A4B2C1D5 import ta_A4B2C1D5
        from bccc.ta.ta_A4B2C2D5 import ta_A4B2C2D5
        from bccc.ta.ta_A4B2C3D5 import ta_A4B2C3D5
        from bccc.ta.ta_A4B2C5D1 import ta_A4B2C5D1
        from bccc.ta.ta_A4B2C5D2 import ta_A4B2C5D2
        from bccc.ta.ta_A4B2C5D3 import ta_A4B2C5D3
        from bccc.ta.ta_A4B2C9D13 import ta_A4B2C9D13
        from bccc.ta.ta_A4B2C9D14 import ta_A4B2C9D14
        from bccc.ta.ta_A4B2C10D13 import ta_A4B2C10D13
        from bccc.ta.ta_A4B2C10D14 import ta_A4B2C10D14
        from bccc.ta.ta_A4B2C13D9 import ta_A4B2C13D9
        from bccc.ta.ta_A4B2C13D10 import ta_A4B2C13D10
        from bccc.ta.ta_A4B2C14D9 import ta_A4B2C14D9
        from bccc.ta.ta_A4B2C14D10 import ta_A4B2C14D10
        from bccc.ta.ta_A4B3C1D5 import ta_A4B3C1D5
        from bccc.ta.ta_A4B3C2D5 import ta_A4B3C2D5
        from bccc.ta.ta_A4B3C3D5 import ta_A4B3C3D5
        from bccc.ta.ta_A4B3C5D1 import ta_A4B3C5D1
        from bccc.ta.ta_A4B3C5D2 import ta_A4B3C5D2
        from bccc.ta.ta_A4B3C5D3 import ta_A4B3C5D3
        from bccc.ta.ta_A4B3C9D13 import ta_A4B3C9D13
        from bccc.ta.ta_A4B3C9D14 import ta_A4B3C9D14
        from bccc.ta.ta_A4B3C10D13 import ta_A4B3C10D13
        from bccc.ta.ta_A4B3C10D14 import ta_A4B3C10D14
        from bccc.ta.ta_A4B3C13D9 import ta_A4B3C13D9
        from bccc.ta.ta_A4B3C13D10 import ta_A4B3C13D10
        from bccc.ta.ta_A4B3C14D9 import ta_A4B3C14D9
        from bccc.ta.ta_A4B3C14D10 import ta_A4B3C14D10
        from bccc.ta.ta_A4B4C5D5 import ta_A4B4C5D5
        from bccc.ta.ta_A4B5C1D1 import ta_A4B5C1D1
        from bccc.ta.ta_A4B5C1D2 import ta_A4B5C1D2
        from bccc.ta.ta_A4B5C1D3 import ta_A4B5C1D3
        from bccc.ta.ta_A4B5C2D1 import ta_A4B5C2D1
        from bccc.ta.ta_A4B5C2D2 import ta_A4B5C2D2
        from bccc.ta.ta_A4B5C2D3 import ta_A4B5C2D3
        from bccc.ta.ta_A4B5C3D1 import ta_A4B5C3D1
        from bccc.ta.ta_A4B5C3D2 import ta_A4B5C3D2
        from bccc.ta.ta_A4B5C3D3 import ta_A4B5C3D3
        from bccc.ta.ta_A4B5C4D5 import ta_A4B5C4D5
        from bccc.ta.ta_A4B5C5D4 import ta_A4B5C5D4
        from bccc.ta.ta_A4B5C6D15 import ta_A4B5C6D15
        from bccc.ta.ta_A4B5C7D13 import ta_A4B5C7D13
        from bccc.ta.ta_A4B5C7D14 import ta_A4B5C7D14
        from bccc.ta.ta_A4B5C8D13 import ta_A4B5C8D13
        from bccc.ta.ta_A4B5C8D14 import ta_A4B5C8D14
        from bccc.ta.ta_A4B5C9D11 import ta_A4B5C9D11
        from bccc.ta.ta_A4B5C9D12 import ta_A4B5C9D12
        from bccc.ta.ta_A4B5C10D11 import ta_A4B5C10D11
        from bccc.ta.ta_A4B5C10D12 import ta_A4B5C10D12
        from bccc.ta.ta_A4B5C11D9 import ta_A4B5C11D9
        from bccc.ta.ta_A4B5C11D10 import ta_A4B5C11D10
        from bccc.ta.ta_A4B5C12D9 import ta_A4B5C12D9
        from bccc.ta.ta_A4B5C12D10 import ta_A4B5C12D10
        from bccc.ta.ta_A4B5C13D7 import ta_A4B5C13D7
        from bccc.ta.ta_A4B5C13D8 import ta_A4B5C13D8
        from bccc.ta.ta_A4B5C14D7 import ta_A4B5C14D7
        from bccc.ta.ta_A4B5C14D8 import ta_A4B5C14D8
        from bccc.ta.ta_A4B5C15D6 import ta_A4B5C15D6
        from bccc.ta.ta_A4B6C5D15 import ta_A4B6C5D15
        from bccc.ta.ta_A4B6C13D13 import ta_A4B6C13D13
        from bccc.ta.ta_A4B6C13D14 import ta_A4B6C13D14
        from bccc.ta.ta_A4B6C14D13 import ta_A4B6C14D13
        from bccc.ta.ta_A4B6C14D14 import ta_A4B6C14D14
        from bccc.ta.ta_A4B6C15D5 import ta_A4B6C15D5
        from bccc.ta.ta_A4B7C5D13 import ta_A4B7C5D13
        from bccc.ta.ta_A4B7C5D14 import ta_A4B7C5D14
        from bccc.ta.ta_A4B7C13D5 import ta_A4B7C13D5
        from bccc.ta.ta_A4B7C14D5 import ta_A4B7C14D5
        from bccc.ta.ta_A4B8C5D13 import ta_A4B8C5D13
        from bccc.ta.ta_A4B8C5D14 import ta_A4B8C5D14
        from bccc.ta.ta_A4B8C13D5 import ta_A4B8C13D5
        from bccc.ta.ta_A4B8C14D5 import ta_A4B8C14D5
        from bccc.ta.ta_A4B9C1D13 import ta_A4B9C1D13
        from bccc.ta.ta_A4B9C1D14 import ta_A4B9C1D14
        from bccc.ta.ta_A4B9C2D13 import ta_A4B9C2D13
        from bccc.ta.ta_A4B9C2D14 import ta_A4B9C2D14
        from bccc.ta.ta_A4B9C3D13 import ta_A4B9C3D13
        from bccc.ta.ta_A4B9C3D14 import ta_A4B9C3D14
        from bccc.ta.ta_A4B9C5D11 import ta_A4B9C5D11
        from bccc.ta.ta_A4B9C5D12 import ta_A4B9C5D12
        from bccc.ta.ta_A4B9C9D15 import ta_A4B9C9D15
        from bccc.ta.ta_A4B9C10D15 import ta_A4B9C10D15
        from bccc.ta.ta_A4B9C11D5 import ta_A4B9C11D5
        from bccc.ta.ta_A4B9C12D5 import ta_A4B9C12D5
        from bccc.ta.ta_A4B9C13D1 import ta_A4B9C13D1
        from bccc.ta.ta_A4B9C13D2 import ta_A4B9C13D2
        from bccc.ta.ta_A4B9C13D3 import ta_A4B9C13D3
        from bccc.ta.ta_A4B9C14D1 import ta_A4B9C14D1
        from bccc.ta.ta_A4B9C14D2 import ta_A4B9C14D2
        from bccc.ta.ta_A4B9C14D3 import ta_A4B9C14D3
        from bccc.ta.ta_A4B9C15D9 import ta_A4B9C15D9
        from bccc.ta.ta_A4B9C15D10 import ta_A4B9C15D10
        from bccc.ta.ta_A4B10C1D13 import ta_A4B10C1D13
        from bccc.ta.ta_A4B10C1D14 import ta_A4B10C1D14
        from bccc.ta.ta_A4B10C2D13 import ta_A4B10C2D13
        from bccc.ta.ta_A4B10C2D14 import ta_A4B10C2D14
        from bccc.ta.ta_A4B10C3D13 import ta_A4B10C3D13
        from bccc.ta.ta_A4B10C3D14 import ta_A4B10C3D14
        from bccc.ta.ta_A4B10C5D11 import ta_A4B10C5D11
        from bccc.ta.ta_A4B10C5D12 import ta_A4B10C5D12
        from bccc.ta.ta_A4B10C9D15 import ta_A4B10C9D15
        from bccc.ta.ta_A4B10C10D15 import ta_A4B10C10D15
        from bccc.ta.ta_A4B10C11D5 import ta_A4B10C11D5
        from bccc.ta.ta_A4B10C12D5 import ta_A4B10C12D5
        from bccc.ta.ta_A4B10C13D1 import ta_A4B10C13D1
        from bccc.ta.ta_A4B10C13D2 import ta_A4B10C13D2
        from bccc.ta.ta_A4B10C13D3 import ta_A4B10C13D3
        from bccc.ta.ta_A4B10C14D1 import ta_A4B10C14D1
        from bccc.ta.ta_A4B10C14D2 import ta_A4B10C14D2
        from bccc.ta.ta_A4B10C14D3 import ta_A4B10C14D3
        from bccc.ta.ta_A4B10C15D9 import ta_A4B10C15D9
        from bccc.ta.ta_A4B10C15D10 import ta_A4B10C15D10
        from bccc.ta.ta_A4B11C5D9 import ta_A4B11C5D9
        from bccc.ta.ta_A4B11C5D10 import ta_A4B11C5D10
        from bccc.ta.ta_A4B11C9D5 import ta_A4B11C9D5
        from bccc.ta.ta_A4B11C10D5 import ta_A4B11C10D5
        from bccc.ta.ta_A4B12C5D9 import ta_A4B12C5D9
        from bccc.ta.ta_A4B12C5D10 import ta_A4B12C5D10
        from bccc.ta.ta_A4B12C9D5 import ta_A4B12C9D5
        from bccc.ta.ta_A4B12C10D5 import ta_A4B12C10D5
        from bccc.ta.ta_A4B13C1D9 import ta_A4B13C1D9
        from bccc.ta.ta_A4B13C1D10 import ta_A4B13C1D10
        from bccc.ta.ta_A4B13C2D9 import ta_A4B13C2D9
        from bccc.ta.ta_A4B13C2D10 import ta_A4B13C2D10
        from bccc.ta.ta_A4B13C3D9 import ta_A4B13C3D9
        from bccc.ta.ta_A4B13C3D10 import ta_A4B13C3D10
        from bccc.ta.ta_A4B13C5D7 import ta_A4B13C5D7
        from bccc.ta.ta_A4B13C5D8 import ta_A4B13C5D8
        from bccc.ta.ta_A4B13C6D13 import ta_A4B13C6D13
        from bccc.ta.ta_A4B13C6D14 import ta_A4B13C6D14
        from bccc.ta.ta_A4B13C7D5 import ta_A4B13C7D5
        from bccc.ta.ta_A4B13C8D5 import ta_A4B13C8D5
        from bccc.ta.ta_A4B13C9D1 import ta_A4B13C9D1
        from bccc.ta.ta_A4B13C9D2 import ta_A4B13C9D2
        from bccc.ta.ta_A4B13C9D3 import ta_A4B13C9D3
        from bccc.ta.ta_A4B13C10D1 import ta_A4B13C10D1
        from bccc.ta.ta_A4B13C10D2 import ta_A4B13C10D2
        from bccc.ta.ta_A4B13C10D3 import ta_A4B13C10D3
        from bccc.ta.ta_A4B13C13D6 import ta_A4B13C13D6
        from bccc.ta.ta_A4B13C14D6 import ta_A4B13C14D6
        from bccc.ta.ta_A4B14C1D9 import ta_A4B14C1D9
        from bccc.ta.ta_A4B14C1D10 import ta_A4B14C1D10
        from bccc.ta.ta_A4B14C2D9 import ta_A4B14C2D9
        from bccc.ta.ta_A4B14C2D10 import ta_A4B14C2D10
        from bccc.ta.ta_A4B14C3D9 import ta_A4B14C3D9
        from bccc.ta.ta_A4B14C3D10 import ta_A4B14C3D10
        from bccc.ta.ta_A4B14C5D7 import ta_A4B14C5D7
        from bccc.ta.ta_A4B14C5D8 import ta_A4B14C5D8
        from bccc.ta.ta_A4B14C6D13 import ta_A4B14C6D13
        from bccc.ta.ta_A4B14C6D14 import ta_A4B14C6D14
        from bccc.ta.ta_A4B14C7D5 import ta_A4B14C7D5
        from bccc.ta.ta_A4B14C8D5 import ta_A4B14C8D5
        from bccc.ta.ta_A4B14C9D1 import ta_A4B14C9D1
        from bccc.ta.ta_A4B14C9D2 import ta_A4B14C9D2
        from bccc.ta.ta_A4B14C9D3 import ta_A4B14C9D3
        from bccc.ta.ta_A4B14C10D1 import ta_A4B14C10D1
        from bccc.ta.ta_A4B14C10D2 import ta_A4B14C10D2
        from bccc.ta.ta_A4B14C10D3 import ta_A4B14C10D3
        from bccc.ta.ta_A4B14C13D6 import ta_A4B14C13D6
        from bccc.ta.ta_A4B14C14D6 import ta_A4B14C14D6
        from bccc.ta.ta_A4B15C5D6 import ta_A4B15C5D6
        from bccc.ta.ta_A4B15C6D5 import ta_A4B15C6D5
        from bccc.ta.ta_A4B15C9D9 import ta_A4B15C9D9
        from bccc.ta.ta_A4B15C9D10 import ta_A4B15C9D10
        from bccc.ta.ta_A4B15C10D9 import ta_A4B15C10D9
        from bccc.ta.ta_A4B15C10D10 import ta_A4B15C10D10
        from bccc.ta.ta_A5B1C1D4 import ta_A5B1C1D4
        from bccc.ta.ta_A5B1C2D4 import ta_A5B1C2D4
        from bccc.ta.ta_A5B1C3D4 import ta_A5B1C3D4
        from bccc.ta.ta_A5B1C4D1 import ta_A5B1C4D1
        from bccc.ta.ta_A5B1C4D2 import ta_A5B1C4D2
        from bccc.ta.ta_A5B1C4D3 import ta_A5B1C4D3
        from bccc.ta.ta_A5B1C7D11 import ta_A5B1C7D11
        from bccc.ta.ta_A5B1C7D12 import ta_A5B1C7D12
        from bccc.ta.ta_A5B1C8D11 import ta_A5B1C8D11
        from bccc.ta.ta_A5B1C8D12 import ta_A5B1C8D12
        from bccc.ta.ta_A5B1C11D7 import ta_A5B1C11D7
        from bccc.ta.ta_A5B1C11D8 import ta_A5B1C11D8
        from bccc.ta.ta_A5B1C12D7 import ta_A5B1C12D7
        from bccc.ta.ta_A5B1C12D8 import ta_A5B1C12D8
        from bccc.ta.ta_A5B2C1D4 import ta_A5B2C1D4
        from bccc.ta.ta_A5B2C2D4 import ta_A5B2C2D4
        from bccc.ta.ta_A5B2C3D4 import ta_A5B2C3D4
        from bccc.ta.ta_A5B2C4D1 import ta_A5B2C4D1
        from bccc.ta.ta_A5B2C4D2 import ta_A5B2C4D2
        from bccc.ta.ta_A5B2C4D3 import ta_A5B2C4D3
        from bccc.ta.ta_A5B2C7D11 import ta_A5B2C7D11
        from bccc.ta.ta_A5B2C7D12 import ta_A5B2C7D12
        from bccc.ta.ta_A5B2C8D11 import ta_A5B2C8D11
        from bccc.ta.ta_A5B2C8D12 import ta_A5B2C8D12
        from bccc.ta.ta_A5B2C11D7 import ta_A5B2C11D7
        from bccc.ta.ta_A5B2C11D8 import ta_A5B2C11D8
        from bccc.ta.ta_A5B2C12D7 import ta_A5B2C12D7
        from bccc.ta.ta_A5B2C12D8 import ta_A5B2C12D8
        from bccc.ta.ta_A5B3C1D4 import ta_A5B3C1D4
        from bccc.ta.ta_A5B3C2D4 import ta_A5B3C2D4
        from bccc.ta.ta_A5B3C3D4 import ta_A5B3C3D4
        from bccc.ta.ta_A5B3C4D1 import ta_A5B3C4D1
        from bccc.ta.ta_A5B3C4D2 import ta_A5B3C4D2
        from bccc.ta.ta_A5B3C4D3 import ta_A5B3C4D3
        from bccc.ta.ta_A5B3C7D11 import ta_A5B3C7D11
        from bccc.ta.ta_A5B3C7D12 import ta_A5B3C7D12
        from bccc.ta.ta_A5B3C8D11 import ta_A5B3C8D11
        from bccc.ta.ta_A5B3C8D12 import ta_A5B3C8D12
        from bccc.ta.ta_A5B3C11D7 import ta_A5B3C11D7
        from bccc.ta.ta_A5B3C11D8 import ta_A5B3C11D8
        from bccc.ta.ta_A5B3C12D7 import ta_A5B3C12D7
        from bccc.ta.ta_A5B3C12D8 import ta_A5B3C12D8
        from bccc.ta.ta_A5B4C1D1 import ta_A5B4C1D1
        from bccc.ta.ta_A5B4C1D2 import ta_A5B4C1D2
        from bccc.ta.ta_A5B4C1D3 import ta_A5B4C1D3
        from bccc.ta.ta_A5B4C2D1 import ta_A5B4C2D1
        from bccc.ta.ta_A5B4C2D2 import ta_A5B4C2D2
        from bccc.ta.ta_A5B4C2D3 import ta_A5B4C2D3
        from bccc.ta.ta_A5B4C3D1 import ta_A5B4C3D1
        from bccc.ta.ta_A5B4C3D2 import ta_A5B4C3D2
        from bccc.ta.ta_A5B4C3D3 import ta_A5B4C3D3
        from bccc.ta.ta_A5B4C4D5 import ta_A5B4C4D5
        from bccc.ta.ta_A5B4C5D4 import ta_A5B4C5D4
        from bccc.ta.ta_A5B4C6D15 import ta_A5B4C6D15
        from bccc.ta.ta_A5B4C7D13 import ta_A5B4C7D13
        from bccc.ta.ta_A5B4C7D14 import ta_A5B4C7D14
        from bccc.ta.ta_A5B4C8D13 import ta_A5B4C8D13
        from bccc.ta.ta_A5B4C8D14 import ta_A5B4C8D14
        from bccc.ta.ta_A5B4C9D11 import ta_A5B4C9D11
        from bccc.ta.ta_A5B4C9D12 import ta_A5B4C9D12
        from bccc.ta.ta_A5B4C10D11 import ta_A5B4C10D11
        from bccc.ta.ta_A5B4C10D12 import ta_A5B4C10D12
        from bccc.ta.ta_A5B4C11D9 import ta_A5B4C11D9
        from bccc.ta.ta_A5B4C11D10 import ta_A5B4C11D10
        from bccc.ta.ta_A5B4C12D9 import ta_A5B4C12D9
        from bccc.ta.ta_A5B4C12D10 import ta_A5B4C12D10
        from bccc.ta.ta_A5B4C13D7 import ta_A5B4C13D7
        from bccc.ta.ta_A5B4C13D8 import ta_A5B4C13D8
        from bccc.ta.ta_A5B4C14D7 import ta_A5B4C14D7
        from bccc.ta.ta_A5B4C14D8 import ta_A5B4C14D8
        from bccc.ta.ta_A5B4C15D6 import ta_A5B4C15D6
        from bccc.ta.ta_A5B5C4D4 import ta_A5B5C4D4
        from bccc.ta.ta_A5B6C4D15 import ta_A5B6C4D15
        from bccc.ta.ta_A5B6C11D11 import ta_A5B6C11D11
        from bccc.ta.ta_A5B6C11D12 import ta_A5B6C11D12
        from bccc.ta.ta_A5B6C12D11 import ta_A5B6C12D11
        from bccc.ta.ta_A5B6C12D12 import ta_A5B6C12D12
        from bccc.ta.ta_A5B6C15D4 import ta_A5B6C15D4
        from bccc.ta.ta_A5B7C1D11 import ta_A5B7C1D11
        from bccc.ta.ta_A5B7C1D12 import ta_A5B7C1D12
        from bccc.ta.ta_A5B7C2D11 import ta_A5B7C2D11
        from bccc.ta.ta_A5B7C2D12 import ta_A5B7C2D12
        from bccc.ta.ta_A5B7C3D11 import ta_A5B7C3D11
        from bccc.ta.ta_A5B7C3D12 import ta_A5B7C3D12
        from bccc.ta.ta_A5B7C4D13 import ta_A5B7C4D13
        from bccc.ta.ta_A5B7C4D14 import ta_A5B7C4D14
        from bccc.ta.ta_A5B7C7D15 import ta_A5B7C7D15
        from bccc.ta.ta_A5B7C8D15 import ta_A5B7C8D15
        from bccc.ta.ta_A5B7C11D1 import ta_A5B7C11D1
        from bccc.ta.ta_A5B7C11D2 import ta_A5B7C11D2
        from bccc.ta.ta_A5B7C11D3 import ta_A5B7C11D3
        from bccc.ta.ta_A5B7C12D1 import ta_A5B7C12D1
        from bccc.ta.ta_A5B7C12D2 import ta_A5B7C12D2
        from bccc.ta.ta_A5B7C12D3 import ta_A5B7C12D3
        from bccc.ta.ta_A5B7C13D4 import ta_A5B7C13D4
        from bccc.ta.ta_A5B7C14D4 import ta_A5B7C14D4
        from bccc.ta.ta_A5B7C15D7 import ta_A5B7C15D7
        from bccc.ta.ta_A5B7C15D8 import ta_A5B7C15D8
        from bccc.ta.ta_A5B8C1D11 import ta_A5B8C1D11
        from bccc.ta.ta_A5B8C1D12 import ta_A5B8C1D12
        from bccc.ta.ta_A5B8C2D11 import ta_A5B8C2D11
        from bccc.ta.ta_A5B8C2D12 import ta_A5B8C2D12
        from bccc.ta.ta_A5B8C3D11 import ta_A5B8C3D11
        from bccc.ta.ta_A5B8C3D12 import ta_A5B8C3D12
        from bccc.ta.ta_A5B8C4D13 import ta_A5B8C4D13
        from bccc.ta.ta_A5B8C4D14 import ta_A5B8C4D14
        from bccc.ta.ta_A5B8C7D15 import ta_A5B8C7D15
        from bccc.ta.ta_A5B8C8D15 import ta_A5B8C8D15
        from bccc.ta.ta_A5B8C11D1 import ta_A5B8C11D1
        from bccc.ta.ta_A5B8C11D2 import ta_A5B8C11D2
        from bccc.ta.ta_A5B8C11D3 import ta_A5B8C11D3
        from bccc.ta.ta_A5B8C12D1 import ta_A5B8C12D1
        from bccc.ta.ta_A5B8C12D2 import ta_A5B8C12D2
        from bccc.ta.ta_A5B8C12D3 import ta_A5B8C12D3
        from bccc.ta.ta_A5B8C13D4 import ta_A5B8C13D4
        from bccc.ta.ta_A5B8C14D4 import ta_A5B8C14D4
        from bccc.ta.ta_A5B8C15D7 import ta_A5B8C15D7
        from bccc.ta.ta_A5B8C15D8 import ta_A5B8C15D8
        from bccc.ta.ta_A5B9C4D11 import ta_A5B9C4D11
        from bccc.ta.ta_A5B9C4D12 import ta_A5B9C4D12
        from bccc.ta.ta_A5B9C11D4 import ta_A5B9C11D4
        from bccc.ta.ta_A5B9C12D4 import ta_A5B9C12D4
        from bccc.ta.ta_A5B10C4D11 import ta_A5B10C4D11
        from bccc.ta.ta_A5B10C4D12 import ta_A5B10C4D12
        from bccc.ta.ta_A5B10C11D4 import ta_A5B10C11D4
        from bccc.ta.ta_A5B10C12D4 import ta_A5B10C12D4
        from bccc.ta.ta_A5B11C1D7 import ta_A5B11C1D7
        from bccc.ta.ta_A5B11C1D8 import ta_A5B11C1D8
        from bccc.ta.ta_A5B11C2D7 import ta_A5B11C2D7
        from bccc.ta.ta_A5B11C2D8 import ta_A5B11C2D8
        from bccc.ta.ta_A5B11C3D7 import ta_A5B11C3D7
        from bccc.ta.ta_A5B11C3D8 import ta_A5B11C3D8
        from bccc.ta.ta_A5B11C4D9 import ta_A5B11C4D9
        from bccc.ta.ta_A5B11C4D10 import ta_A5B11C4D10
        from bccc.ta.ta_A5B11C6D11 import ta_A5B11C6D11
        from bccc.ta.ta_A5B11C6D12 import ta_A5B11C6D12
        from bccc.ta.ta_A5B11C7D1 import ta_A5B11C7D1
        from bccc.ta.ta_A5B11C7D2 import ta_A5B11C7D2
        from bccc.ta.ta_A5B11C7D3 import ta_A5B11C7D3
        from bccc.ta.ta_A5B11C8D1 import ta_A5B11C8D1
        from bccc.ta.ta_A5B11C8D2 import ta_A5B11C8D2
        from bccc.ta.ta_A5B11C8D3 import ta_A5B11C8D3
        from bccc.ta.ta_A5B11C9D4 import ta_A5B11C9D4
        from bccc.ta.ta_A5B11C10D4 import ta_A5B11C10D4
        from bccc.ta.ta_A5B11C11D6 import ta_A5B11C11D6
        from bccc.ta.ta_A5B11C12D6 import ta_A5B11C12D6
        from bccc.ta.ta_A5B12C1D7 import ta_A5B12C1D7
        from bccc.ta.ta_A5B12C1D8 import ta_A5B12C1D8
        from bccc.ta.ta_A5B12C2D7 import ta_A5B12C2D7
        from bccc.ta.ta_A5B12C2D8 import ta_A5B12C2D8
        from bccc.ta.ta_A5B12C3D7 import ta_A5B12C3D7
        from bccc.ta.ta_A5B12C3D8 import ta_A5B12C3D8
        from bccc.ta.ta_A5B12C4D9 import ta_A5B12C4D9
        from bccc.ta.ta_A5B12C4D10 import ta_A5B12C4D10
        from bccc.ta.ta_A5B12C6D11 import ta_A5B12C6D11
        from bccc.ta.ta_A5B12C6D12 import ta_A5B12C6D12
        from bccc.ta.ta_A5B12C7D1 import ta_A5B12C7D1
        from bccc.ta.ta_A5B12C7D2 import ta_A5B12C7D2
        from bccc.ta.ta_A5B12C7D3 import ta_A5B12C7D3
        from bccc.ta.ta_A5B12C8D1 import ta_A5B12C8D1
        from bccc.ta.ta_A5B12C8D2 import ta_A5B12C8D2
        from bccc.ta.ta_A5B12C8D3 import ta_A5B12C8D3
        from bccc.ta.ta_A5B12C9D4 import ta_A5B12C9D4
        from bccc.ta.ta_A5B12C10D4 import ta_A5B12C10D4
        from bccc.ta.ta_A5B12C11D6 import ta_A5B12C11D6
        from bccc.ta.ta_A5B12C12D6 import ta_A5B12C12D6
        from bccc.ta.ta_A5B13C4D7 import ta_A5B13C4D7
        from bccc.ta.ta_A5B13C4D8 import ta_A5B13C4D8
        from bccc.ta.ta_A5B13C7D4 import ta_A5B13C7D4
        from bccc.ta.ta_A5B13C8D4 import ta_A5B13C8D4
        from bccc.ta.ta_A5B14C4D7 import ta_A5B14C4D7
        from bccc.ta.ta_A5B14C4D8 import ta_A5B14C4D8
        from bccc.ta.ta_A5B14C7D4 import ta_A5B14C7D4
        from bccc.ta.ta_A5B14C8D4 import ta_A5B14C8D4
        from bccc.ta.ta_A5B15C4D6 import ta_A5B15C4D6
        from bccc.ta.ta_A5B15C6D4 import ta_A5B15C6D4
        from bccc.ta.ta_A5B15C7D7 import ta_A5B15C7D7
        from bccc.ta.ta_A5B15C7D8 import ta_A5B15C7D8
        from bccc.ta.ta_A5B15C8D7 import ta_A5B15C8D7
        from bccc.ta.ta_A5B15C8D8 import ta_A5B15C8D8
        from bccc.ta.ta_A6B1C1D15 import ta_A6B1C1D15
        from bccc.ta.ta_A6B1C2D15 import ta_A6B1C2D15
        from bccc.ta.ta_A6B1C3D15 import ta_A6B1C3D15
        from bccc.ta.ta_A6B1C11D13 import ta_A6B1C11D13
        from bccc.ta.ta_A6B1C11D14 import ta_A6B1C11D14
        from bccc.ta.ta_A6B1C12D13 import ta_A6B1C12D13
        from bccc.ta.ta_A6B1C12D14 import ta_A6B1C12D14
        from bccc.ta.ta_A6B1C13D11 import ta_A6B1C13D11
        from bccc.ta.ta_A6B1C13D12 import ta_A6B1C13D12
        from bccc.ta.ta_A6B1C14D11 import ta_A6B1C14D11
        from bccc.ta.ta_A6B1C14D12 import ta_A6B1C14D12
        from bccc.ta.ta_A6B1C15D1 import ta_A6B1C15D1
        from bccc.ta.ta_A6B1C15D2 import ta_A6B1C15D2
        from bccc.ta.ta_A6B1C15D3 import ta_A6B1C15D3
        from bccc.ta.ta_A6B2C1D15 import ta_A6B2C1D15
        from bccc.ta.ta_A6B2C2D15 import ta_A6B2C2D15
        from bccc.ta.ta_A6B2C3D15 import ta_A6B2C3D15
        from bccc.ta.ta_A6B2C11D13 import ta_A6B2C11D13
        from bccc.ta.ta_A6B2C11D14 import ta_A6B2C11D14
        from bccc.ta.ta_A6B2C12D13 import ta_A6B2C12D13
        from bccc.ta.ta_A6B2C12D14 import ta_A6B2C12D14
        from bccc.ta.ta_A6B2C13D11 import ta_A6B2C13D11
        from bccc.ta.ta_A6B2C13D12 import ta_A6B2C13D12
        from bccc.ta.ta_A6B2C14D11 import ta_A6B2C14D11
        from bccc.ta.ta_A6B2C14D12 import ta_A6B2C14D12
        from bccc.ta.ta_A6B2C15D1 import ta_A6B2C15D1
        from bccc.ta.ta_A6B2C15D2 import ta_A6B2C15D2
        from bccc.ta.ta_A6B2C15D3 import ta_A6B2C15D3
        from bccc.ta.ta_A6B3C1D15 import ta_A6B3C1D15
        from bccc.ta.ta_A6B3C2D15 import ta_A6B3C2D15
        from bccc.ta.ta_A6B3C3D15 import ta_A6B3C3D15
        from bccc.ta.ta_A6B3C11D13 import ta_A6B3C11D13
        from bccc.ta.ta_A6B3C11D14 import ta_A6B3C11D14
        from bccc.ta.ta_A6B3C12D13 import ta_A6B3C12D13
        from bccc.ta.ta_A6B3C12D14 import ta_A6B3C12D14
        from bccc.ta.ta_A6B3C13D11 import ta_A6B3C13D11
        from bccc.ta.ta_A6B3C13D12 import ta_A6B3C13D12
        from bccc.ta.ta_A6B3C14D11 import ta_A6B3C14D11
        from bccc.ta.ta_A6B3C14D12 import ta_A6B3C14D12
        from bccc.ta.ta_A6B3C15D1 import ta_A6B3C15D1
        from bccc.ta.ta_A6B3C15D2 import ta_A6B3C15D2
        from bccc.ta.ta_A6B3C15D3 import ta_A6B3C15D3
        from bccc.ta.ta_A6B4C5D15 import ta_A6B4C5D15
        from bccc.ta.ta_A6B4C13D13 import ta_A6B4C13D13
        from bccc.ta.ta_A6B4C13D14 import ta_A6B4C13D14
        from bccc.ta.ta_A6B4C14D13 import ta_A6B4C14D13
        from bccc.ta.ta_A6B4C14D14 import ta_A6B4C14D14
        from bccc.ta.ta_A6B4C15D5 import ta_A6B4C15D5
        from bccc.ta.ta_A6B5C4D15 import ta_A6B5C4D15
        from bccc.ta.ta_A6B5C11D11 import ta_A6B5C11D11
        from bccc.ta.ta_A6B5C11D12 import ta_A6B5C11D12
        from bccc.ta.ta_A6B5C12D11 import ta_A6B5C12D11
        from bccc.ta.ta_A6B5C12D12 import ta_A6B5C12D12
        from bccc.ta.ta_A6B5C15D4 import ta_A6B5C15D4
        from bccc.ta.ta_A6B6C15D15 import ta_A6B6C15D15
        from bccc.ta.ta_A6B7C13D15 import ta_A6B7C13D15
        from bccc.ta.ta_A6B7C14D15 import ta_A6B7C14D15
        from bccc.ta.ta_A6B7C15D13 import ta_A6B7C15D13
        from bccc.ta.ta_A6B7C15D14 import ta_A6B7C15D14
        from bccc.ta.ta_A6B8C13D15 import ta_A6B8C13D15
        from bccc.ta.ta_A6B8C14D15 import ta_A6B8C14D15
        from bccc.ta.ta_A6B8C15D13 import ta_A6B8C15D13
        from bccc.ta.ta_A6B8C15D14 import ta_A6B8C15D14
        from bccc.ta.ta_A6B9C11D15 import ta_A6B9C11D15
        from bccc.ta.ta_A6B9C12D15 import ta_A6B9C12D15
        from bccc.ta.ta_A6B9C15D11 import ta_A6B9C15D11
        from bccc.ta.ta_A6B9C15D12 import ta_A6B9C15D12
        from bccc.ta.ta_A6B10C11D15 import ta_A6B10C11D15
        from bccc.ta.ta_A6B10C12D15 import ta_A6B10C12D15
        from bccc.ta.ta_A6B10C15D11 import ta_A6B10C15D11
        from bccc.ta.ta_A6B10C15D12 import ta_A6B10C15D12
        from bccc.ta.ta_A6B11C1D13 import ta_A6B11C1D13
        from bccc.ta.ta_A6B11C1D14 import ta_A6B11C1D14
        from bccc.ta.ta_A6B11C2D13 import ta_A6B11C2D13
        from bccc.ta.ta_A6B11C2D14 import ta_A6B11C2D14
        from bccc.ta.ta_A6B11C3D13 import ta_A6B11C3D13
        from bccc.ta.ta_A6B11C3D14 import ta_A6B11C3D14
        from bccc.ta.ta_A6B11C5D11 import ta_A6B11C5D11
        from bccc.ta.ta_A6B11C5D12 import ta_A6B11C5D12
        from bccc.ta.ta_A6B11C9D15 import ta_A6B11C9D15
        from bccc.ta.ta_A6B11C10D15 import ta_A6B11C10D15
        from bccc.ta.ta_A6B11C11D5 import ta_A6B11C11D5
        from bccc.ta.ta_A6B11C12D5 import ta_A6B11C12D5
        from bccc.ta.ta_A6B11C13D1 import ta_A6B11C13D1
        from bccc.ta.ta_A6B11C13D2 import ta_A6B11C13D2
        from bccc.ta.ta_A6B11C13D3 import ta_A6B11C13D3
        from bccc.ta.ta_A6B11C14D1 import ta_A6B11C14D1
        from bccc.ta.ta_A6B11C14D2 import ta_A6B11C14D2
        from bccc.ta.ta_A6B11C14D3 import ta_A6B11C14D3
        from bccc.ta.ta_A6B11C15D9 import ta_A6B11C15D9
        from bccc.ta.ta_A6B11C15D10 import ta_A6B11C15D10
        from bccc.ta.ta_A6B12C1D13 import ta_A6B12C1D13
        from bccc.ta.ta_A6B12C1D14 import ta_A6B12C1D14
        from bccc.ta.ta_A6B12C2D13 import ta_A6B12C2D13
        from bccc.ta.ta_A6B12C2D14 import ta_A6B12C2D14
        from bccc.ta.ta_A6B12C3D13 import ta_A6B12C3D13
        from bccc.ta.ta_A6B12C3D14 import ta_A6B12C3D14
        from bccc.ta.ta_A6B12C5D11 import ta_A6B12C5D11
        from bccc.ta.ta_A6B12C5D12 import ta_A6B12C5D12
        from bccc.ta.ta_A6B12C9D15 import ta_A6B12C9D15
        from bccc.ta.ta_A6B12C10D15 import ta_A6B12C10D15
        from bccc.ta.ta_A6B12C11D5 import ta_A6B12C11D5
        from bccc.ta.ta_A6B12C12D5 import ta_A6B12C12D5
        from bccc.ta.ta_A6B12C13D1 import ta_A6B12C13D1
        from bccc.ta.ta_A6B12C13D2 import ta_A6B12C13D2
        from bccc.ta.ta_A6B12C13D3 import ta_A6B12C13D3
        from bccc.ta.ta_A6B12C14D1 import ta_A6B12C14D1
        from bccc.ta.ta_A6B12C14D2 import ta_A6B12C14D2
        from bccc.ta.ta_A6B12C14D3 import ta_A6B12C14D3
        from bccc.ta.ta_A6B12C15D9 import ta_A6B12C15D9
        from bccc.ta.ta_A6B12C15D10 import ta_A6B12C15D10
        from bccc.ta.ta_A6B13C1D11 import ta_A6B13C1D11
        from bccc.ta.ta_A6B13C1D12 import ta_A6B13C1D12
        from bccc.ta.ta_A6B13C2D11 import ta_A6B13C2D11
        from bccc.ta.ta_A6B13C2D12 import ta_A6B13C2D12
        from bccc.ta.ta_A6B13C3D11 import ta_A6B13C3D11
        from bccc.ta.ta_A6B13C3D12 import ta_A6B13C3D12
        from bccc.ta.ta_A6B13C4D13 import ta_A6B13C4D13
        from bccc.ta.ta_A6B13C4D14 import ta_A6B13C4D14
        from bccc.ta.ta_A6B13C7D15 import ta_A6B13C7D15
        from bccc.ta.ta_A6B13C8D15 import ta_A6B13C8D15
        from bccc.ta.ta_A6B13C11D1 import ta_A6B13C11D1
        from bccc.ta.ta_A6B13C11D2 import ta_A6B13C11D2
        from bccc.ta.ta_A6B13C11D3 import ta_A6B13C11D3
        from bccc.ta.ta_A6B13C12D1 import ta_A6B13C12D1
        from bccc.ta.ta_A6B13C12D2 import ta_A6B13C12D2
        from bccc.ta.ta_A6B13C12D3 import ta_A6B13C12D3
        from bccc.ta.ta_A6B13C13D4 import ta_A6B13C13D4
        from bccc.ta.ta_A6B13C14D4 import ta_A6B13C14D4
        from bccc.ta.ta_A6B13C15D7 import ta_A6B13C15D7
        from bccc.ta.ta_A6B13C15D8 import ta_A6B13C15D8
        from bccc.ta.ta_A6B14C1D11 import ta_A6B14C1D11
        from bccc.ta.ta_A6B14C1D12 import ta_A6B14C1D12
        from bccc.ta.ta_A6B14C2D11 import ta_A6B14C2D11
        from bccc.ta.ta_A6B14C2D12 import ta_A6B14C2D12
        from bccc.ta.ta_A6B14C3D11 import ta_A6B14C3D11
        from bccc.ta.ta_A6B14C3D12 import ta_A6B14C3D12
        from bccc.ta.ta_A6B14C4D13 import ta_A6B14C4D13
        from bccc.ta.ta_A6B14C4D14 import ta_A6B14C4D14
        from bccc.ta.ta_A6B14C7D15 import ta_A6B14C7D15
        from bccc.ta.ta_A6B14C8D15 import ta_A6B14C8D15
        from bccc.ta.ta_A6B14C11D1 import ta_A6B14C11D1
        from bccc.ta.ta_A6B14C11D2 import ta_A6B14C11D2
        from bccc.ta.ta_A6B14C11D3 import ta_A6B14C11D3
        from bccc.ta.ta_A6B14C12D1 import ta_A6B14C12D1
        from bccc.ta.ta_A6B14C12D2 import ta_A6B14C12D2
        from bccc.ta.ta_A6B14C12D3 import ta_A6B14C12D3
        from bccc.ta.ta_A6B14C13D4 import ta_A6B14C13D4
        from bccc.ta.ta_A6B14C14D4 import ta_A6B14C14D4
        from bccc.ta.ta_A6B14C15D7 import ta_A6B14C15D7
        from bccc.ta.ta_A6B14C15D8 import ta_A6B14C15D8
        from bccc.ta.ta_A6B15C1D1 import ta_A6B15C1D1
        from bccc.ta.ta_A6B15C1D2 import ta_A6B15C1D2
        from bccc.ta.ta_A6B15C1D3 import ta_A6B15C1D3
        from bccc.ta.ta_A6B15C2D1 import ta_A6B15C2D1
        from bccc.ta.ta_A6B15C2D2 import ta_A6B15C2D2
        from bccc.ta.ta_A6B15C2D3 import ta_A6B15C2D3
        from bccc.ta.ta_A6B15C3D1 import ta_A6B15C3D1
        from bccc.ta.ta_A6B15C3D2 import ta_A6B15C3D2
        from bccc.ta.ta_A6B15C3D3 import ta_A6B15C3D3
        from bccc.ta.ta_A6B15C4D5 import ta_A6B15C4D5
        from bccc.ta.ta_A6B15C5D4 import ta_A6B15C5D4
        from bccc.ta.ta_A6B15C6D15 import ta_A6B15C6D15
        from bccc.ta.ta_A6B15C7D13 import ta_A6B15C7D13
        from bccc.ta.ta_A6B15C7D14 import ta_A6B15C7D14
        from bccc.ta.ta_A6B15C8D13 import ta_A6B15C8D13
        from bccc.ta.ta_A6B15C8D14 import ta_A6B15C8D14
        from bccc.ta.ta_A6B15C9D11 import ta_A6B15C9D11
        from bccc.ta.ta_A6B15C9D12 import ta_A6B15C9D12
        from bccc.ta.ta_A6B15C10D11 import ta_A6B15C10D11
        from bccc.ta.ta_A6B15C10D12 import ta_A6B15C10D12
        from bccc.ta.ta_A6B15C11D9 import ta_A6B15C11D9
        from bccc.ta.ta_A6B15C11D10 import ta_A6B15C11D10
        from bccc.ta.ta_A6B15C12D9 import ta_A6B15C12D9
        from bccc.ta.ta_A6B15C12D10 import ta_A6B15C12D10
        from bccc.ta.ta_A6B15C13D7 import ta_A6B15C13D7
        from bccc.ta.ta_A6B15C13D8 import ta_A6B15C13D8
        from bccc.ta.ta_A6B15C14D7 import ta_A6B15C14D7
        from bccc.ta.ta_A6B15C14D8 import ta_A6B15C14D8
        from bccc.ta.ta_A6B15C15D6 import ta_A6B15C15D6
        from bccc.ta.ta_A7B1C1D13 import ta_A7B1C1D13
        from bccc.ta.ta_A7B1C1D14 import ta_A7B1C1D14
        from bccc.ta.ta_A7B1C2D13 import ta_A7B1C2D13
        from bccc.ta.ta_A7B1C2D14 import ta_A7B1C2D14
        from bccc.ta.ta_A7B1C3D13 import ta_A7B1C3D13
        from bccc.ta.ta_A7B1C3D14 import ta_A7B1C3D14
        from bccc.ta.ta_A7B1C5D11 import ta_A7B1C5D11
        from bccc.ta.ta_A7B1C5D12 import ta_A7B1C5D12
        from bccc.ta.ta_A7B1C9D15 import ta_A7B1C9D15
        from bccc.ta.ta_A7B1C10D15 import ta_A7B1C10D15
        from bccc.ta.ta_A7B1C11D5 import ta_A7B1C11D5
        from bccc.ta.ta_A7B1C12D5 import ta_A7B1C12D5
        from bccc.ta.ta_A7B1C13D1 import ta_A7B1C13D1
        from bccc.ta.ta_A7B1C13D2 import ta_A7B1C13D2
        from bccc.ta.ta_A7B1C13D3 import ta_A7B1C13D3
        from bccc.ta.ta_A7B1C14D1 import ta_A7B1C14D1
        from bccc.ta.ta_A7B1C14D2 import ta_A7B1C14D2
        from bccc.ta.ta_A7B1C14D3 import ta_A7B1C14D3
        from bccc.ta.ta_A7B1C15D9 import ta_A7B1C15D9
        from bccc.ta.ta_A7B1C15D10 import ta_A7B1C15D10
        from bccc.ta.ta_A7B2C1D13 import ta_A7B2C1D13
        from bccc.ta.ta_A7B2C1D14 import ta_A7B2C1D14
        from bccc.ta.ta_A7B2C2D13 import ta_A7B2C2D13
        from bccc.ta.ta_A7B2C2D14 import ta_A7B2C2D14
        from bccc.ta.ta_A7B2C3D13 import ta_A7B2C3D13
        from bccc.ta.ta_A7B2C3D14 import ta_A7B2C3D14
        from bccc.ta.ta_A7B2C5D11 import ta_A7B2C5D11
        from bccc.ta.ta_A7B2C5D12 import ta_A7B2C5D12
        from bccc.ta.ta_A7B2C9D15 import ta_A7B2C9D15
        from bccc.ta.ta_A7B2C10D15 import ta_A7B2C10D15
        from bccc.ta.ta_A7B2C11D5 import ta_A7B2C11D5
        from bccc.ta.ta_A7B2C12D5 import ta_A7B2C12D5
        from bccc.ta.ta_A7B2C13D1 import ta_A7B2C13D1
        from bccc.ta.ta_A7B2C13D2 import ta_A7B2C13D2
        from bccc.ta.ta_A7B2C13D3 import ta_A7B2C13D3
        from bccc.ta.ta_A7B2C14D1 import ta_A7B2C14D1
        from bccc.ta.ta_A7B2C14D2 import ta_A7B2C14D2
        from bccc.ta.ta_A7B2C14D3 import ta_A7B2C14D3
        from bccc.ta.ta_A7B2C15D9 import ta_A7B2C15D9
        from bccc.ta.ta_A7B2C15D10 import ta_A7B2C15D10
        from bccc.ta.ta_A7B3C1D13 import ta_A7B3C1D13
        from bccc.ta.ta_A7B3C1D14 import ta_A7B3C1D14
        from bccc.ta.ta_A7B3C2D13 import ta_A7B3C2D13
        from bccc.ta.ta_A7B3C2D14 import ta_A7B3C2D14
        from bccc.ta.ta_A7B3C3D13 import ta_A7B3C3D13
        from bccc.ta.ta_A7B3C3D14 import ta_A7B3C3D14
        from bccc.ta.ta_A7B3C5D11 import ta_A7B3C5D11
        from bccc.ta.ta_A7B3C5D12 import ta_A7B3C5D12
        from bccc.ta.ta_A7B3C9D15 import ta_A7B3C9D15
        from bccc.ta.ta_A7B3C10D15 import ta_A7B3C10D15
        from bccc.ta.ta_A7B3C11D5 import ta_A7B3C11D5
        from bccc.ta.ta_A7B3C12D5 import ta_A7B3C12D5
        from bccc.ta.ta_A7B3C13D1 import ta_A7B3C13D1
        from bccc.ta.ta_A7B3C13D2 import ta_A7B3C13D2
        from bccc.ta.ta_A7B3C13D3 import ta_A7B3C13D3
        from bccc.ta.ta_A7B3C14D1 import ta_A7B3C14D1
        from bccc.ta.ta_A7B3C14D2 import ta_A7B3C14D2
        from bccc.ta.ta_A7B3C14D3 import ta_A7B3C14D3
        from bccc.ta.ta_A7B3C15D9 import ta_A7B3C15D9
        from bccc.ta.ta_A7B3C15D10 import ta_A7B3C15D10
        from bccc.ta.ta_A7B4C5D13 import ta_A7B4C5D13
        from bccc.ta.ta_A7B4C5D14 import ta_A7B4C5D14
        from bccc.ta.ta_A7B4C13D5 import ta_A7B4C13D5
        from bccc.ta.ta_A7B4C14D5 import ta_A7B4C14D5
        from bccc.ta.ta_A7B5C1D11 import ta_A7B5C1D11
        from bccc.ta.ta_A7B5C1D12 import ta_A7B5C1D12
        from bccc.ta.ta_A7B5C2D11 import ta_A7B5C2D11
        from bccc.ta.ta_A7B5C2D12 import ta_A7B5C2D12
        from bccc.ta.ta_A7B5C3D11 import ta_A7B5C3D11
        from bccc.ta.ta_A7B5C3D12 import ta_A7B5C3D12
        from bccc.ta.ta_A7B5C4D13 import ta_A7B5C4D13
        from bccc.ta.ta_A7B5C4D14 import ta_A7B5C4D14
        from bccc.ta.ta_A7B5C7D15 import ta_A7B5C7D15
        from bccc.ta.ta_A7B5C8D15 import ta_A7B5C8D15
        from bccc.ta.ta_A7B5C11D1 import ta_A7B5C11D1
        from bccc.ta.ta_A7B5C11D2 import ta_A7B5C11D2
        from bccc.ta.ta_A7B5C11D3 import ta_A7B5C11D3
        from bccc.ta.ta_A7B5C12D1 import ta_A7B5C12D1
        from bccc.ta.ta_A7B5C12D2 import ta_A7B5C12D2
        from bccc.ta.ta_A7B5C12D3 import ta_A7B5C12D3
        from bccc.ta.ta_A7B5C13D4 import ta_A7B5C13D4
        from bccc.ta.ta_A7B5C14D4 import ta_A7B5C14D4
        from bccc.ta.ta_A7B5C15D7 import ta_A7B5C15D7
        from bccc.ta.ta_A7B5C15D8 import ta_A7B5C15D8
        from bccc.ta.ta_A7B6C13D15 import ta_A7B6C13D15
        from bccc.ta.ta_A7B6C14D15 import ta_A7B6C14D15
        from bccc.ta.ta_A7B6C15D13 import ta_A7B6C15D13
        from bccc.ta.ta_A7B6C15D14 import ta_A7B6C15D14
        from bccc.ta.ta_A7B7C5D15 import ta_A7B7C5D15
        from bccc.ta.ta_A7B7C13D13 import ta_A7B7C13D13
        from bccc.ta.ta_A7B7C13D14 import ta_A7B7C13D14
        from bccc.ta.ta_A7B7C14D13 import ta_A7B7C14D13
        from bccc.ta.ta_A7B7C14D14 import ta_A7B7C14D14
        from bccc.ta.ta_A7B7C15D5 import ta_A7B7C15D5
        from bccc.ta.ta_A7B8C5D15 import ta_A7B8C5D15
        from bccc.ta.ta_A7B8C13D13 import ta_A7B8C13D13
        from bccc.ta.ta_A7B8C13D14 import ta_A7B8C13D14
        from bccc.ta.ta_A7B8C14D13 import ta_A7B8C14D13
        from bccc.ta.ta_A7B8C14D14 import ta_A7B8C14D14
        from bccc.ta.ta_A7B8C15D5 import ta_A7B8C15D5
        from bccc.ta.ta_A7B9C1D15 import ta_A7B9C1D15
        from bccc.ta.ta_A7B9C2D15 import ta_A7B9C2D15
        from bccc.ta.ta_A7B9C3D15 import ta_A7B9C3D15
        from bccc.ta.ta_A7B9C11D13 import ta_A7B9C11D13
        from bccc.ta.ta_A7B9C11D14 import ta_A7B9C11D14
        from bccc.ta.ta_A7B9C12D13 import ta_A7B9C12D13
        from bccc.ta.ta_A7B9C12D14 import ta_A7B9C12D14
        from bccc.ta.ta_A7B9C13D11 import ta_A7B9C13D11
        from bccc.ta.ta_A7B9C13D12 import ta_A7B9C13D12
        from bccc.ta.ta_A7B9C14D11 import ta_A7B9C14D11
        from bccc.ta.ta_A7B9C14D12 import ta_A7B9C14D12
        from bccc.ta.ta_A7B9C15D1 import ta_A7B9C15D1
        from bccc.ta.ta_A7B9C15D2 import ta_A7B9C15D2
        from bccc.ta.ta_A7B9C15D3 import ta_A7B9C15D3
        from bccc.ta.ta_A7B10C1D15 import ta_A7B10C1D15
        from bccc.ta.ta_A7B10C2D15 import ta_A7B10C2D15
        from bccc.ta.ta_A7B10C3D15 import ta_A7B10C3D15
        from bccc.ta.ta_A7B10C11D13 import ta_A7B10C11D13
        from bccc.ta.ta_A7B10C11D14 import ta_A7B10C11D14
        from bccc.ta.ta_A7B10C12D13 import ta_A7B10C12D13
        from bccc.ta.ta_A7B10C12D14 import ta_A7B10C12D14
        from bccc.ta.ta_A7B10C13D11 import ta_A7B10C13D11
        from bccc.ta.ta_A7B10C13D12 import ta_A7B10C13D12
        from bccc.ta.ta_A7B10C14D11 import ta_A7B10C14D11
        from bccc.ta.ta_A7B10C14D12 import ta_A7B10C14D12
        from bccc.ta.ta_A7B10C15D1 import ta_A7B10C15D1
        from bccc.ta.ta_A7B10C15D2 import ta_A7B10C15D2
        from bccc.ta.ta_A7B10C15D3 import ta_A7B10C15D3
        from bccc.ta.ta_A7B11C1D5 import ta_A7B11C1D5
        from bccc.ta.ta_A7B11C2D5 import ta_A7B11C2D5
        from bccc.ta.ta_A7B11C3D5 import ta_A7B11C3D5
        from bccc.ta.ta_A7B11C5D1 import ta_A7B11C5D1
        from bccc.ta.ta_A7B11C5D2 import ta_A7B11C5D2
        from bccc.ta.ta_A7B11C5D3 import ta_A7B11C5D3
        from bccc.ta.ta_A7B11C9D13 import ta_A7B11C9D13
        from bccc.ta.ta_A7B11C9D14 import ta_A7B11C9D14
        from bccc.ta.ta_A7B11C10D13 import ta_A7B11C10D13
        from bccc.ta.ta_A7B11C10D14 import ta_A7B11C10D14
        from bccc.ta.ta_A7B11C13D9 import ta_A7B11C13D9
        from bccc.ta.ta_A7B11C13D10 import ta_A7B11C13D10
        from bccc.ta.ta_A7B11C14D9 import ta_A7B11C14D9
        from bccc.ta.ta_A7B11C14D10 import ta_A7B11C14D10
        from bccc.ta.ta_A7B12C1D5 import ta_A7B12C1D5
        from bccc.ta.ta_A7B12C2D5 import ta_A7B12C2D5
        from bccc.ta.ta_A7B12C3D5 import ta_A7B12C3D5
        from bccc.ta.ta_A7B12C5D1 import ta_A7B12C5D1
        from bccc.ta.ta_A7B12C5D2 import ta_A7B12C5D2
        from bccc.ta.ta_A7B12C5D3 import ta_A7B12C5D3
        from bccc.ta.ta_A7B12C9D13 import ta_A7B12C9D13
        from bccc.ta.ta_A7B12C9D14 import ta_A7B12C9D14
        from bccc.ta.ta_A7B12C10D13 import ta_A7B12C10D13
        from bccc.ta.ta_A7B12C10D14 import ta_A7B12C10D14
        from bccc.ta.ta_A7B12C13D9 import ta_A7B12C13D9
        from bccc.ta.ta_A7B12C13D10 import ta_A7B12C13D10
        from bccc.ta.ta_A7B12C14D9 import ta_A7B12C14D9
        from bccc.ta.ta_A7B12C14D10 import ta_A7B12C14D10
        from bccc.ta.ta_A7B13C1D1 import ta_A7B13C1D1
        from bccc.ta.ta_A7B13C1D2 import ta_A7B13C1D2
        from bccc.ta.ta_A7B13C1D3 import ta_A7B13C1D3
        from bccc.ta.ta_A7B13C2D1 import ta_A7B13C2D1
        from bccc.ta.ta_A7B13C2D2 import ta_A7B13C2D2
        from bccc.ta.ta_A7B13C2D3 import ta_A7B13C2D3
        from bccc.ta.ta_A7B13C3D1 import ta_A7B13C3D1
        from bccc.ta.ta_A7B13C3D2 import ta_A7B13C3D2
        from bccc.ta.ta_A7B13C3D3 import ta_A7B13C3D3
        from bccc.ta.ta_A7B13C4D5 import ta_A7B13C4D5
        from bccc.ta.ta_A7B13C5D4 import ta_A7B13C5D4
        from bccc.ta.ta_A7B13C6D15 import ta_A7B13C6D15
        from bccc.ta.ta_A7B13C7D13 import ta_A7B13C7D13
        from bccc.ta.ta_A7B13C7D14 import ta_A7B13C7D14
        from bccc.ta.ta_A7B13C8D13 import ta_A7B13C8D13
        from bccc.ta.ta_A7B13C8D14 import ta_A7B13C8D14
        from bccc.ta.ta_A7B13C9D11 import ta_A7B13C9D11
        from bccc.ta.ta_A7B13C9D12 import ta_A7B13C9D12
        from bccc.ta.ta_A7B13C10D11 import ta_A7B13C10D11
        from bccc.ta.ta_A7B13C10D12 import ta_A7B13C10D12
        from bccc.ta.ta_A7B13C11D9 import ta_A7B13C11D9
        from bccc.ta.ta_A7B13C11D10 import ta_A7B13C11D10
        from bccc.ta.ta_A7B13C12D9 import ta_A7B13C12D9
        from bccc.ta.ta_A7B13C12D10 import ta_A7B13C12D10
        from bccc.ta.ta_A7B13C13D7 import ta_A7B13C13D7
        from bccc.ta.ta_A7B13C13D8 import ta_A7B13C13D8
        from bccc.ta.ta_A7B13C14D7 import ta_A7B13C14D7
        from bccc.ta.ta_A7B13C14D8 import ta_A7B13C14D8
        from bccc.ta.ta_A7B13C15D6 import ta_A7B13C15D6
        from bccc.ta.ta_A7B14C1D1 import ta_A7B14C1D1
        from bccc.ta.ta_A7B14C1D2 import ta_A7B14C1D2
        from bccc.ta.ta_A7B14C1D3 import ta_A7B14C1D3
        from bccc.ta.ta_A7B14C2D1 import ta_A7B14C2D1
        from bccc.ta.ta_A7B14C2D2 import ta_A7B14C2D2
        from bccc.ta.ta_A7B14C2D3 import ta_A7B14C2D3
        from bccc.ta.ta_A7B14C3D1 import ta_A7B14C3D1
        from bccc.ta.ta_A7B14C3D2 import ta_A7B14C3D2
        from bccc.ta.ta_A7B14C3D3 import ta_A7B14C3D3
        from bccc.ta.ta_A7B14C4D5 import ta_A7B14C4D5
        from bccc.ta.ta_A7B14C5D4 import ta_A7B14C5D4
        from bccc.ta.ta_A7B14C6D15 import ta_A7B14C6D15
        from bccc.ta.ta_A7B14C7D13 import ta_A7B14C7D13
        from bccc.ta.ta_A7B14C7D14 import ta_A7B14C7D14
        from bccc.ta.ta_A7B14C8D13 import ta_A7B14C8D13
        from bccc.ta.ta_A7B14C8D14 import ta_A7B14C8D14
        from bccc.ta.ta_A7B14C9D11 import ta_A7B14C9D11
        from bccc.ta.ta_A7B14C9D12 import ta_A7B14C9D12
        from bccc.ta.ta_A7B14C10D11 import ta_A7B14C10D11
        from bccc.ta.ta_A7B14C10D12 import ta_A7B14C10D12
        from bccc.ta.ta_A7B14C11D9 import ta_A7B14C11D9
        from bccc.ta.ta_A7B14C11D10 import ta_A7B14C11D10
        from bccc.ta.ta_A7B14C12D9 import ta_A7B14C12D9
        from bccc.ta.ta_A7B14C12D10 import ta_A7B14C12D10
        from bccc.ta.ta_A7B14C13D7 import ta_A7B14C13D7
        from bccc.ta.ta_A7B14C13D8 import ta_A7B14C13D8
        from bccc.ta.ta_A7B14C14D7 import ta_A7B14C14D7
        from bccc.ta.ta_A7B14C14D8 import ta_A7B14C14D8
        from bccc.ta.ta_A7B14C15D6 import ta_A7B14C15D6
        from bccc.ta.ta_A7B15C1D9 import ta_A7B15C1D9
        from bccc.ta.ta_A7B15C1D10 import ta_A7B15C1D10
        from bccc.ta.ta_A7B15C2D9 import ta_A7B15C2D9
        from bccc.ta.ta_A7B15C2D10 import ta_A7B15C2D10
        from bccc.ta.ta_A7B15C3D9 import ta_A7B15C3D9
        from bccc.ta.ta_A7B15C3D10 import ta_A7B15C3D10
        from bccc.ta.ta_A7B15C5D7 import ta_A7B15C5D7
        from bccc.ta.ta_A7B15C5D8 import ta_A7B15C5D8
        from bccc.ta.ta_A7B15C6D13 import ta_A7B15C6D13
        from bccc.ta.ta_A7B15C6D14 import ta_A7B15C6D14
        from bccc.ta.ta_A7B15C7D5 import ta_A7B15C7D5
        from bccc.ta.ta_A7B15C8D5 import ta_A7B15C8D5
        from bccc.ta.ta_A7B15C9D1 import ta_A7B15C9D1
        from bccc.ta.ta_A7B15C9D2 import ta_A7B15C9D2
        from bccc.ta.ta_A7B15C9D3 import ta_A7B15C9D3
        from bccc.ta.ta_A7B15C10D1 import ta_A7B15C10D1
        from bccc.ta.ta_A7B15C10D2 import ta_A7B15C10D2
        from bccc.ta.ta_A7B15C10D3 import ta_A7B15C10D3
        from bccc.ta.ta_A7B15C13D6 import ta_A7B15C13D6
        from bccc.ta.ta_A7B15C14D6 import ta_A7B15C14D6
        from bccc.ta.ta_A8B1C1D13 import ta_A8B1C1D13
        from bccc.ta.ta_A8B1C1D14 import ta_A8B1C1D14
        from bccc.ta.ta_A8B1C2D13 import ta_A8B1C2D13
        from bccc.ta.ta_A8B1C2D14 import ta_A8B1C2D14
        from bccc.ta.ta_A8B1C3D13 import ta_A8B1C3D13
        from bccc.ta.ta_A8B1C3D14 import ta_A8B1C3D14
        from bccc.ta.ta_A8B1C5D11 import ta_A8B1C5D11
        from bccc.ta.ta_A8B1C5D12 import ta_A8B1C5D12
        from bccc.ta.ta_A8B1C9D15 import ta_A8B1C9D15
        from bccc.ta.ta_A8B1C10D15 import ta_A8B1C10D15
        from bccc.ta.ta_A8B1C11D5 import ta_A8B1C11D5
        from bccc.ta.ta_A8B1C12D5 import ta_A8B1C12D5
        from bccc.ta.ta_A8B1C13D1 import ta_A8B1C13D1
        from bccc.ta.ta_A8B1C13D2 import ta_A8B1C13D2
        from bccc.ta.ta_A8B1C13D3 import ta_A8B1C13D3
        from bccc.ta.ta_A8B1C14D1 import ta_A8B1C14D1
        from bccc.ta.ta_A8B1C14D2 import ta_A8B1C14D2
        from bccc.ta.ta_A8B1C14D3 import ta_A8B1C14D3
        from bccc.ta.ta_A8B1C15D9 import ta_A8B1C15D9
        from bccc.ta.ta_A8B1C15D10 import ta_A8B1C15D10
        from bccc.ta.ta_A8B2C1D13 import ta_A8B2C1D13
        from bccc.ta.ta_A8B2C1D14 import ta_A8B2C1D14
        from bccc.ta.ta_A8B2C2D13 import ta_A8B2C2D13
        from bccc.ta.ta_A8B2C2D14 import ta_A8B2C2D14
        from bccc.ta.ta_A8B2C3D13 import ta_A8B2C3D13
        from bccc.ta.ta_A8B2C3D14 import ta_A8B2C3D14
        from bccc.ta.ta_A8B2C5D11 import ta_A8B2C5D11
        from bccc.ta.ta_A8B2C5D12 import ta_A8B2C5D12
        from bccc.ta.ta_A8B2C9D15 import ta_A8B2C9D15
        from bccc.ta.ta_A8B2C10D15 import ta_A8B2C10D15
        from bccc.ta.ta_A8B2C11D5 import ta_A8B2C11D5
        from bccc.ta.ta_A8B2C12D5 import ta_A8B2C12D5
        from bccc.ta.ta_A8B2C13D1 import ta_A8B2C13D1
        from bccc.ta.ta_A8B2C13D2 import ta_A8B2C13D2
        from bccc.ta.ta_A8B2C13D3 import ta_A8B2C13D3
        from bccc.ta.ta_A8B2C14D1 import ta_A8B2C14D1
        from bccc.ta.ta_A8B2C14D2 import ta_A8B2C14D2
        from bccc.ta.ta_A8B2C14D3 import ta_A8B2C14D3
        from bccc.ta.ta_A8B2C15D9 import ta_A8B2C15D9
        from bccc.ta.ta_A8B2C15D10 import ta_A8B2C15D10
        from bccc.ta.ta_A8B3C1D13 import ta_A8B3C1D13
        from bccc.ta.ta_A8B3C1D14 import ta_A8B3C1D14
        from bccc.ta.ta_A8B3C2D13 import ta_A8B3C2D13
        from bccc.ta.ta_A8B3C2D14 import ta_A8B3C2D14
        from bccc.ta.ta_A8B3C3D13 import ta_A8B3C3D13
        from bccc.ta.ta_A8B3C3D14 import ta_A8B3C3D14
        from bccc.ta.ta_A8B3C5D11 import ta_A8B3C5D11
        from bccc.ta.ta_A8B3C5D12 import ta_A8B3C5D12
        from bccc.ta.ta_A8B3C9D15 import ta_A8B3C9D15
        from bccc.ta.ta_A8B3C10D15 import ta_A8B3C10D15
        from bccc.ta.ta_A8B3C11D5 import ta_A8B3C11D5
        from bccc.ta.ta_A8B3C12D5 import ta_A8B3C12D5
        from bccc.ta.ta_A8B3C13D1 import ta_A8B3C13D1
        from bccc.ta.ta_A8B3C13D2 import ta_A8B3C13D2
        from bccc.ta.ta_A8B3C13D3 import ta_A8B3C13D3
        from bccc.ta.ta_A8B3C14D1 import ta_A8B3C14D1
        from bccc.ta.ta_A8B3C14D2 import ta_A8B3C14D2
        from bccc.ta.ta_A8B3C14D3 import ta_A8B3C14D3
        from bccc.ta.ta_A8B3C15D9 import ta_A8B3C15D9
        from bccc.ta.ta_A8B3C15D10 import ta_A8B3C15D10
        from bccc.ta.ta_A8B4C5D13 import ta_A8B4C5D13
        from bccc.ta.ta_A8B4C5D14 import ta_A8B4C5D14
        from bccc.ta.ta_A8B4C13D5 import ta_A8B4C13D5
        from bccc.ta.ta_A8B4C14D5 import ta_A8B4C14D5
        from bccc.ta.ta_A8B5C1D11 import ta_A8B5C1D11
        from bccc.ta.ta_A8B5C1D12 import ta_A8B5C1D12
        from bccc.ta.ta_A8B5C2D11 import ta_A8B5C2D11
        from bccc.ta.ta_A8B5C2D12 import ta_A8B5C2D12
        from bccc.ta.ta_A8B5C3D11 import ta_A8B5C3D11
        from bccc.ta.ta_A8B5C3D12 import ta_A8B5C3D12
        from bccc.ta.ta_A8B5C4D13 import ta_A8B5C4D13
        from bccc.ta.ta_A8B5C4D14 import ta_A8B5C4D14
        from bccc.ta.ta_A8B5C7D15 import ta_A8B5C7D15
        from bccc.ta.ta_A8B5C8D15 import ta_A8B5C8D15
        from bccc.ta.ta_A8B5C11D1 import ta_A8B5C11D1
        from bccc.ta.ta_A8B5C11D2 import ta_A8B5C11D2
        from bccc.ta.ta_A8B5C11D3 import ta_A8B5C11D3
        from bccc.ta.ta_A8B5C12D1 import ta_A8B5C12D1
        from bccc.ta.ta_A8B5C12D2 import ta_A8B5C12D2
        from bccc.ta.ta_A8B5C12D3 import ta_A8B5C12D3
        from bccc.ta.ta_A8B5C13D4 import ta_A8B5C13D4
        from bccc.ta.ta_A8B5C14D4 import ta_A8B5C14D4
        from bccc.ta.ta_A8B5C15D7 import ta_A8B5C15D7
        from bccc.ta.ta_A8B5C15D8 import ta_A8B5C15D8
        from bccc.ta.ta_A8B6C13D15 import ta_A8B6C13D15
        from bccc.ta.ta_A8B6C14D15 import ta_A8B6C14D15
        from bccc.ta.ta_A8B6C15D13 import ta_A8B6C15D13
        from bccc.ta.ta_A8B6C15D14 import ta_A8B6C15D14
        from bccc.ta.ta_A8B7C5D15 import ta_A8B7C5D15
        from bccc.ta.ta_A8B7C13D13 import ta_A8B7C13D13
        from bccc.ta.ta_A8B7C13D14 import ta_A8B7C13D14
        from bccc.ta.ta_A8B7C14D13 import ta_A8B7C14D13
        from bccc.ta.ta_A8B7C14D14 import ta_A8B7C14D14
        from bccc.ta.ta_A8B7C15D5 import ta_A8B7C15D5
        from bccc.ta.ta_A8B8C5D15 import ta_A8B8C5D15
        from bccc.ta.ta_A8B8C13D13 import ta_A8B8C13D13
        from bccc.ta.ta_A8B8C13D14 import ta_A8B8C13D14
        from bccc.ta.ta_A8B8C14D13 import ta_A8B8C14D13
        from bccc.ta.ta_A8B8C14D14 import ta_A8B8C14D14
        from bccc.ta.ta_A8B8C15D5 import ta_A8B8C15D5
        from bccc.ta.ta_A8B9C1D15 import ta_A8B9C1D15
        from bccc.ta.ta_A8B9C2D15 import ta_A8B9C2D15
        from bccc.ta.ta_A8B9C3D15 import ta_A8B9C3D15
        from bccc.ta.ta_A8B9C11D13 import ta_A8B9C11D13
        from bccc.ta.ta_A8B9C11D14 import ta_A8B9C11D14
        from bccc.ta.ta_A8B9C12D13 import ta_A8B9C12D13
        from bccc.ta.ta_A8B9C12D14 import ta_A8B9C12D14
        from bccc.ta.ta_A8B9C13D11 import ta_A8B9C13D11
        from bccc.ta.ta_A8B9C13D12 import ta_A8B9C13D12
        from bccc.ta.ta_A8B9C14D11 import ta_A8B9C14D11
        from bccc.ta.ta_A8B9C14D12 import ta_A8B9C14D12
        from bccc.ta.ta_A8B9C15D1 import ta_A8B9C15D1
        from bccc.ta.ta_A8B9C15D2 import ta_A8B9C15D2
        from bccc.ta.ta_A8B9C15D3 import ta_A8B9C15D3
        from bccc.ta.ta_A8B10C1D15 import ta_A8B10C1D15
        from bccc.ta.ta_A8B10C2D15 import ta_A8B10C2D15
        from bccc.ta.ta_A8B10C3D15 import ta_A8B10C3D15
        from bccc.ta.ta_A8B10C11D13 import ta_A8B10C11D13
        from bccc.ta.ta_A8B10C11D14 import ta_A8B10C11D14
        from bccc.ta.ta_A8B10C12D13 import ta_A8B10C12D13
        from bccc.ta.ta_A8B10C12D14 import ta_A8B10C12D14
        from bccc.ta.ta_A8B10C13D11 import ta_A8B10C13D11
        from bccc.ta.ta_A8B10C13D12 import ta_A8B10C13D12
        from bccc.ta.ta_A8B10C14D11 import ta_A8B10C14D11
        from bccc.ta.ta_A8B10C14D12 import ta_A8B10C14D12
        from bccc.ta.ta_A8B10C15D1 import ta_A8B10C15D1
        from bccc.ta.ta_A8B10C15D2 import ta_A8B10C15D2
        from bccc.ta.ta_A8B10C15D3 import ta_A8B10C15D3
        from bccc.ta.ta_A8B11C1D5 import ta_A8B11C1D5
        from bccc.ta.ta_A8B11C2D5 import ta_A8B11C2D5
        from bccc.ta.ta_A8B11C3D5 import ta_A8B11C3D5
        from bccc.ta.ta_A8B11C5D1 import ta_A8B11C5D1
        from bccc.ta.ta_A8B11C5D2 import ta_A8B11C5D2
        from bccc.ta.ta_A8B11C5D3 import ta_A8B11C5D3
        from bccc.ta.ta_A8B11C9D13 import ta_A8B11C9D13
        from bccc.ta.ta_A8B11C9D14 import ta_A8B11C9D14
        from bccc.ta.ta_A8B11C10D13 import ta_A8B11C10D13
        from bccc.ta.ta_A8B11C10D14 import ta_A8B11C10D14
        from bccc.ta.ta_A8B11C13D9 import ta_A8B11C13D9
        from bccc.ta.ta_A8B11C13D10 import ta_A8B11C13D10
        from bccc.ta.ta_A8B11C14D9 import ta_A8B11C14D9
        from bccc.ta.ta_A8B11C14D10 import ta_A8B11C14D10
        from bccc.ta.ta_A8B12C1D5 import ta_A8B12C1D5
        from bccc.ta.ta_A8B12C2D5 import ta_A8B12C2D5
        from bccc.ta.ta_A8B12C3D5 import ta_A8B12C3D5
        from bccc.ta.ta_A8B12C5D1 import ta_A8B12C5D1
        from bccc.ta.ta_A8B12C5D2 import ta_A8B12C5D2
        from bccc.ta.ta_A8B12C5D3 import ta_A8B12C5D3
        from bccc.ta.ta_A8B12C9D13 import ta_A8B12C9D13
        from bccc.ta.ta_A8B12C9D14 import ta_A8B12C9D14
        from bccc.ta.ta_A8B12C10D13 import ta_A8B12C10D13
        from bccc.ta.ta_A8B12C10D14 import ta_A8B12C10D14
        from bccc.ta.ta_A8B12C13D9 import ta_A8B12C13D9
        from bccc.ta.ta_A8B12C13D10 import ta_A8B12C13D10
        from bccc.ta.ta_A8B12C14D9 import ta_A8B12C14D9
        from bccc.ta.ta_A8B12C14D10 import ta_A8B12C14D10
        from bccc.ta.ta_A8B13C1D1 import ta_A8B13C1D1
        from bccc.ta.ta_A8B13C1D2 import ta_A8B13C1D2
        from bccc.ta.ta_A8B13C1D3 import ta_A8B13C1D3
        from bccc.ta.ta_A8B13C2D1 import ta_A8B13C2D1
        from bccc.ta.ta_A8B13C2D2 import ta_A8B13C2D2
        from bccc.ta.ta_A8B13C2D3 import ta_A8B13C2D3
        from bccc.ta.ta_A8B13C3D1 import ta_A8B13C3D1
        from bccc.ta.ta_A8B13C3D2 import ta_A8B13C3D2
        from bccc.ta.ta_A8B13C3D3 import ta_A8B13C3D3
        from bccc.ta.ta_A8B13C4D5 import ta_A8B13C4D5
        from bccc.ta.ta_A8B13C5D4 import ta_A8B13C5D4
        from bccc.ta.ta_A8B13C6D15 import ta_A8B13C6D15
        from bccc.ta.ta_A8B13C7D13 import ta_A8B13C7D13
        from bccc.ta.ta_A8B13C7D14 import ta_A8B13C7D14
        from bccc.ta.ta_A8B13C8D13 import ta_A8B13C8D13
        from bccc.ta.ta_A8B13C8D14 import ta_A8B13C8D14
        from bccc.ta.ta_A8B13C9D11 import ta_A8B13C9D11
        from bccc.ta.ta_A8B13C9D12 import ta_A8B13C9D12
        from bccc.ta.ta_A8B13C10D11 import ta_A8B13C10D11
        from bccc.ta.ta_A8B13C10D12 import ta_A8B13C10D12
        from bccc.ta.ta_A8B13C11D9 import ta_A8B13C11D9
        from bccc.ta.ta_A8B13C11D10 import ta_A8B13C11D10
        from bccc.ta.ta_A8B13C12D9 import ta_A8B13C12D9
        from bccc.ta.ta_A8B13C12D10 import ta_A8B13C12D10
        from bccc.ta.ta_A8B13C13D7 import ta_A8B13C13D7
        from bccc.ta.ta_A8B13C13D8 import ta_A8B13C13D8
        from bccc.ta.ta_A8B13C14D7 import ta_A8B13C14D7
        from bccc.ta.ta_A8B13C14D8 import ta_A8B13C14D8
        from bccc.ta.ta_A8B13C15D6 import ta_A8B13C15D6
        from bccc.ta.ta_A8B14C1D1 import ta_A8B14C1D1
        from bccc.ta.ta_A8B14C1D2 import ta_A8B14C1D2
        from bccc.ta.ta_A8B14C1D3 import ta_A8B14C1D3
        from bccc.ta.ta_A8B14C2D1 import ta_A8B14C2D1
        from bccc.ta.ta_A8B14C2D2 import ta_A8B14C2D2
        from bccc.ta.ta_A8B14C2D3 import ta_A8B14C2D3
        from bccc.ta.ta_A8B14C3D1 import ta_A8B14C3D1
        from bccc.ta.ta_A8B14C3D2 import ta_A8B14C3D2
        from bccc.ta.ta_A8B14C3D3 import ta_A8B14C3D3
        from bccc.ta.ta_A8B14C4D5 import ta_A8B14C4D5
        from bccc.ta.ta_A8B14C5D4 import ta_A8B14C5D4
        from bccc.ta.ta_A8B14C6D15 import ta_A8B14C6D15
        from bccc.ta.ta_A8B14C7D13 import ta_A8B14C7D13
        from bccc.ta.ta_A8B14C7D14 import ta_A8B14C7D14
        from bccc.ta.ta_A8B14C8D13 import ta_A8B14C8D13
        from bccc.ta.ta_A8B14C8D14 import ta_A8B14C8D14
        from bccc.ta.ta_A8B14C9D11 import ta_A8B14C9D11
        from bccc.ta.ta_A8B14C9D12 import ta_A8B14C9D12
        from bccc.ta.ta_A8B14C10D11 import ta_A8B14C10D11
        from bccc.ta.ta_A8B14C10D12 import ta_A8B14C10D12
        from bccc.ta.ta_A8B14C11D9 import ta_A8B14C11D9
        from bccc.ta.ta_A8B14C11D10 import ta_A8B14C11D10
        from bccc.ta.ta_A8B14C12D9 import ta_A8B14C12D9
        from bccc.ta.ta_A8B14C12D10 import ta_A8B14C12D10
        from bccc.ta.ta_A8B14C13D7 import ta_A8B14C13D7
        from bccc.ta.ta_A8B14C13D8 import ta_A8B14C13D8
        from bccc.ta.ta_A8B14C14D7 import ta_A8B14C14D7
        from bccc.ta.ta_A8B14C14D8 import ta_A8B14C14D8
        from bccc.ta.ta_A8B14C15D6 import ta_A8B14C15D6
        from bccc.ta.ta_A8B15C1D9 import ta_A8B15C1D9
        from bccc.ta.ta_A8B15C1D10 import ta_A8B15C1D10
        from bccc.ta.ta_A8B15C2D9 import ta_A8B15C2D9
        from bccc.ta.ta_A8B15C2D10 import ta_A8B15C2D10
        from bccc.ta.ta_A8B15C3D9 import ta_A8B15C3D9
        from bccc.ta.ta_A8B15C3D10 import ta_A8B15C3D10
        from bccc.ta.ta_A8B15C5D7 import ta_A8B15C5D7
        from bccc.ta.ta_A8B15C5D8 import ta_A8B15C5D8
        from bccc.ta.ta_A8B15C6D13 import ta_A8B15C6D13
        from bccc.ta.ta_A8B15C6D14 import ta_A8B15C6D14
        from bccc.ta.ta_A8B15C7D5 import ta_A8B15C7D5
        from bccc.ta.ta_A8B15C8D5 import ta_A8B15C8D5
        from bccc.ta.ta_A8B15C9D1 import ta_A8B15C9D1
        from bccc.ta.ta_A8B15C9D2 import ta_A8B15C9D2
        from bccc.ta.ta_A8B15C9D3 import ta_A8B15C9D3
        from bccc.ta.ta_A8B15C10D1 import ta_A8B15C10D1
        from bccc.ta.ta_A8B15C10D2 import ta_A8B15C10D2
        from bccc.ta.ta_A8B15C10D3 import ta_A8B15C10D3
        from bccc.ta.ta_A8B15C13D6 import ta_A8B15C13D6
        from bccc.ta.ta_A8B15C14D6 import ta_A8B15C14D6
        from bccc.ta.ta_A9B1C1D11 import ta_A9B1C1D11
        from bccc.ta.ta_A9B1C1D12 import ta_A9B1C1D12
        from bccc.ta.ta_A9B1C2D11 import ta_A9B1C2D11
        from bccc.ta.ta_A9B1C2D12 import ta_A9B1C2D12
        from bccc.ta.ta_A9B1C3D11 import ta_A9B1C3D11
        from bccc.ta.ta_A9B1C3D12 import ta_A9B1C3D12
        from bccc.ta.ta_A9B1C4D13 import ta_A9B1C4D13
        from bccc.ta.ta_A9B1C4D14 import ta_A9B1C4D14
        from bccc.ta.ta_A9B1C7D15 import ta_A9B1C7D15
        from bccc.ta.ta_A9B1C8D15 import ta_A9B1C8D15
        from bccc.ta.ta_A9B1C11D1 import ta_A9B1C11D1
        from bccc.ta.ta_A9B1C11D2 import ta_A9B1C11D2
        from bccc.ta.ta_A9B1C11D3 import ta_A9B1C11D3
        from bccc.ta.ta_A9B1C12D1 import ta_A9B1C12D1
        from bccc.ta.ta_A9B1C12D2 import ta_A9B1C12D2
        from bccc.ta.ta_A9B1C12D3 import ta_A9B1C12D3
        from bccc.ta.ta_A9B1C13D4 import ta_A9B1C13D4
        from bccc.ta.ta_A9B1C14D4 import ta_A9B1C14D4
        from bccc.ta.ta_A9B1C15D7 import ta_A9B1C15D7
        from bccc.ta.ta_A9B1C15D8 import ta_A9B1C15D8
        from bccc.ta.ta_A9B2C1D11 import ta_A9B2C1D11
        from bccc.ta.ta_A9B2C1D12 import ta_A9B2C1D12
        from bccc.ta.ta_A9B2C2D11 import ta_A9B2C2D11
        from bccc.ta.ta_A9B2C2D12 import ta_A9B2C2D12
        from bccc.ta.ta_A9B2C3D11 import ta_A9B2C3D11
        from bccc.ta.ta_A9B2C3D12 import ta_A9B2C3D12
        from bccc.ta.ta_A9B2C4D13 import ta_A9B2C4D13
        from bccc.ta.ta_A9B2C4D14 import ta_A9B2C4D14
        from bccc.ta.ta_A9B2C7D15 import ta_A9B2C7D15
        from bccc.ta.ta_A9B2C8D15 import ta_A9B2C8D15
        from bccc.ta.ta_A9B2C11D1 import ta_A9B2C11D1
        from bccc.ta.ta_A9B2C11D2 import ta_A9B2C11D2
        from bccc.ta.ta_A9B2C11D3 import ta_A9B2C11D3
        from bccc.ta.ta_A9B2C12D1 import ta_A9B2C12D1
        from bccc.ta.ta_A9B2C12D2 import ta_A9B2C12D2
        from bccc.ta.ta_A9B2C12D3 import ta_A9B2C12D3
        from bccc.ta.ta_A9B2C13D4 import ta_A9B2C13D4
        from bccc.ta.ta_A9B2C14D4 import ta_A9B2C14D4
        from bccc.ta.ta_A9B2C15D7 import ta_A9B2C15D7
        from bccc.ta.ta_A9B2C15D8 import ta_A9B2C15D8
        from bccc.ta.ta_A9B3C1D11 import ta_A9B3C1D11
        from bccc.ta.ta_A9B3C1D12 import ta_A9B3C1D12
        from bccc.ta.ta_A9B3C2D11 import ta_A9B3C2D11
        from bccc.ta.ta_A9B3C2D12 import ta_A9B3C2D12
        from bccc.ta.ta_A9B3C3D11 import ta_A9B3C3D11
        from bccc.ta.ta_A9B3C3D12 import ta_A9B3C3D12
        from bccc.ta.ta_A9B3C4D13 import ta_A9B3C4D13
        from bccc.ta.ta_A9B3C4D14 import ta_A9B3C4D14
        from bccc.ta.ta_A9B3C7D15 import ta_A9B3C7D15
        from bccc.ta.ta_A9B3C8D15 import ta_A9B3C8D15
        from bccc.ta.ta_A9B3C11D1 import ta_A9B3C11D1
        from bccc.ta.ta_A9B3C11D2 import ta_A9B3C11D2
        from bccc.ta.ta_A9B3C11D3 import ta_A9B3C11D3
        from bccc.ta.ta_A9B3C12D1 import ta_A9B3C12D1
        from bccc.ta.ta_A9B3C12D2 import ta_A9B3C12D2
        from bccc.ta.ta_A9B3C12D3 import ta_A9B3C12D3
        from bccc.ta.ta_A9B3C13D4 import ta_A9B3C13D4
        from bccc.ta.ta_A9B3C14D4 import ta_A9B3C14D4
        from bccc.ta.ta_A9B3C15D7 import ta_A9B3C15D7
        from bccc.ta.ta_A9B3C15D8 import ta_A9B3C15D8
        from bccc.ta.ta_A9B4C1D13 import ta_A9B4C1D13
        from bccc.ta.ta_A9B4C1D14 import ta_A9B4C1D14
        from bccc.ta.ta_A9B4C2D13 import ta_A9B4C2D13
        from bccc.ta.ta_A9B4C2D14 import ta_A9B4C2D14
        from bccc.ta.ta_A9B4C3D13 import ta_A9B4C3D13
        from bccc.ta.ta_A9B4C3D14 import ta_A9B4C3D14
        from bccc.ta.ta_A9B4C5D11 import ta_A9B4C5D11
        from bccc.ta.ta_A9B4C5D12 import ta_A9B4C5D12
        from bccc.ta.ta_A9B4C9D15 import ta_A9B4C9D15
        from bccc.ta.ta_A9B4C10D15 import ta_A9B4C10D15
        from bccc.ta.ta_A9B4C11D5 import ta_A9B4C11D5
        from bccc.ta.ta_A9B4C12D5 import ta_A9B4C12D5
        from bccc.ta.ta_A9B4C13D1 import ta_A9B4C13D1
        from bccc.ta.ta_A9B4C13D2 import ta_A9B4C13D2
        from bccc.ta.ta_A9B4C13D3 import ta_A9B4C13D3
        from bccc.ta.ta_A9B4C14D1 import ta_A9B4C14D1
        from bccc.ta.ta_A9B4C14D2 import ta_A9B4C14D2
        from bccc.ta.ta_A9B4C14D3 import ta_A9B4C14D3
        from bccc.ta.ta_A9B4C15D9 import ta_A9B4C15D9
        from bccc.ta.ta_A9B4C15D10 import ta_A9B4C15D10
        from bccc.ta.ta_A9B5C4D11 import ta_A9B5C4D11
        from bccc.ta.ta_A9B5C4D12 import ta_A9B5C4D12
        from bccc.ta.ta_A9B5C11D4 import ta_A9B5C11D4
        from bccc.ta.ta_A9B5C12D4 import ta_A9B5C12D4
        from bccc.ta.ta_A9B6C11D15 import ta_A9B6C11D15
        from bccc.ta.ta_A9B6C12D15 import ta_A9B6C12D15
        from bccc.ta.ta_A9B6C15D11 import ta_A9B6C15D11
        from bccc.ta.ta_A9B6C15D12 import ta_A9B6C15D12
        from bccc.ta.ta_A9B7C1D15 import ta_A9B7C1D15
        from bccc.ta.ta_A9B7C2D15 import ta_A9B7C2D15
        from bccc.ta.ta_A9B7C3D15 import ta_A9B7C3D15
        from bccc.ta.ta_A9B7C11D13 import ta_A9B7C11D13
        from bccc.ta.ta_A9B7C11D14 import ta_A9B7C11D14
        from bccc.ta.ta_A9B7C12D13 import ta_A9B7C12D13
        from bccc.ta.ta_A9B7C12D14 import ta_A9B7C12D14
        from bccc.ta.ta_A9B7C13D11 import ta_A9B7C13D11
        from bccc.ta.ta_A9B7C13D12 import ta_A9B7C13D12
        from bccc.ta.ta_A9B7C14D11 import ta_A9B7C14D11
        from bccc.ta.ta_A9B7C14D12 import ta_A9B7C14D12
        from bccc.ta.ta_A9B7C15D1 import ta_A9B7C15D1
        from bccc.ta.ta_A9B7C15D2 import ta_A9B7C15D2
        from bccc.ta.ta_A9B7C15D3 import ta_A9B7C15D3
        from bccc.ta.ta_A9B8C1D15 import ta_A9B8C1D15
        from bccc.ta.ta_A9B8C2D15 import ta_A9B8C2D15
        from bccc.ta.ta_A9B8C3D15 import ta_A9B8C3D15
        from bccc.ta.ta_A9B8C11D13 import ta_A9B8C11D13
        from bccc.ta.ta_A9B8C11D14 import ta_A9B8C11D14
        from bccc.ta.ta_A9B8C12D13 import ta_A9B8C12D13
        from bccc.ta.ta_A9B8C12D14 import ta_A9B8C12D14
        from bccc.ta.ta_A9B8C13D11 import ta_A9B8C13D11
        from bccc.ta.ta_A9B8C13D12 import ta_A9B8C13D12
        from bccc.ta.ta_A9B8C14D11 import ta_A9B8C14D11
        from bccc.ta.ta_A9B8C14D12 import ta_A9B8C14D12
        from bccc.ta.ta_A9B8C15D1 import ta_A9B8C15D1
        from bccc.ta.ta_A9B8C15D2 import ta_A9B8C15D2
        from bccc.ta.ta_A9B8C15D3 import ta_A9B8C15D3
        from bccc.ta.ta_A9B9C4D15 import ta_A9B9C4D15
        from bccc.ta.ta_A9B9C11D11 import ta_A9B9C11D11
        from bccc.ta.ta_A9B9C11D12 import ta_A9B9C11D12
        from bccc.ta.ta_A9B9C12D11 import ta_A9B9C12D11
        from bccc.ta.ta_A9B9C12D12 import ta_A9B9C12D12
        from bccc.ta.ta_A9B9C15D4 import ta_A9B9C15D4
        from bccc.ta.ta_A9B10C4D15 import ta_A9B10C4D15
        from bccc.ta.ta_A9B10C11D11 import ta_A9B10C11D11
        from bccc.ta.ta_A9B10C11D12 import ta_A9B10C11D12
        from bccc.ta.ta_A9B10C12D11 import ta_A9B10C12D11
        from bccc.ta.ta_A9B10C12D12 import ta_A9B10C12D12
        from bccc.ta.ta_A9B10C15D4 import ta_A9B10C15D4
        from bccc.ta.ta_A9B11C1D1 import ta_A9B11C1D1
        from bccc.ta.ta_A9B11C1D2 import ta_A9B11C1D2
        from bccc.ta.ta_A9B11C1D3 import ta_A9B11C1D3
        from bccc.ta.ta_A9B11C2D1 import ta_A9B11C2D1
        from bccc.ta.ta_A9B11C2D2 import ta_A9B11C2D2
        from bccc.ta.ta_A9B11C2D3 import ta_A9B11C2D3
        from bccc.ta.ta_A9B11C3D1 import ta_A9B11C3D1
        from bccc.ta.ta_A9B11C3D2 import ta_A9B11C3D2
        from bccc.ta.ta_A9B11C3D3 import ta_A9B11C3D3
        from bccc.ta.ta_A9B11C4D5 import ta_A9B11C4D5
        from bccc.ta.ta_A9B11C5D4 import ta_A9B11C5D4
        from bccc.ta.ta_A9B11C6D15 import ta_A9B11C6D15
        from bccc.ta.ta_A9B11C7D13 import ta_A9B11C7D13
        from bccc.ta.ta_A9B11C7D14 import ta_A9B11C7D14
        from bccc.ta.ta_A9B11C8D13 import ta_A9B11C8D13
        from bccc.ta.ta_A9B11C8D14 import ta_A9B11C8D14
        from bccc.ta.ta_A9B11C9D11 import ta_A9B11C9D11
        from bccc.ta.ta_A9B11C9D12 import ta_A9B11C9D12
        from bccc.ta.ta_A9B11C10D11 import ta_A9B11C10D11
        from bccc.ta.ta_A9B11C10D12 import ta_A9B11C10D12
        from bccc.ta.ta_A9B11C11D9 import ta_A9B11C11D9
        from bccc.ta.ta_A9B11C11D10 import ta_A9B11C11D10
        from bccc.ta.ta_A9B11C12D9 import ta_A9B11C12D9
        from bccc.ta.ta_A9B11C12D10 import ta_A9B11C12D10
        from bccc.ta.ta_A9B11C13D7 import ta_A9B11C13D7
        from bccc.ta.ta_A9B11C13D8 import ta_A9B11C13D8
        from bccc.ta.ta_A9B11C14D7 import ta_A9B11C14D7
        from bccc.ta.ta_A9B11C14D8 import ta_A9B11C14D8
        from bccc.ta.ta_A9B11C15D6 import ta_A9B11C15D6
        from bccc.ta.ta_A9B12C1D1 import ta_A9B12C1D1
        from bccc.ta.ta_A9B12C1D2 import ta_A9B12C1D2
        from bccc.ta.ta_A9B12C1D3 import ta_A9B12C1D3
        from bccc.ta.ta_A9B12C2D1 import ta_A9B12C2D1
        from bccc.ta.ta_A9B12C2D2 import ta_A9B12C2D2
        from bccc.ta.ta_A9B12C2D3 import ta_A9B12C2D3
        from bccc.ta.ta_A9B12C3D1 import ta_A9B12C3D1
        from bccc.ta.ta_A9B12C3D2 import ta_A9B12C3D2
        from bccc.ta.ta_A9B12C3D3 import ta_A9B12C3D3
        from bccc.ta.ta_A9B12C4D5 import ta_A9B12C4D5
        from bccc.ta.ta_A9B12C5D4 import ta_A9B12C5D4
        from bccc.ta.ta_A9B12C6D15 import ta_A9B12C6D15
        from bccc.ta.ta_A9B12C7D13 import ta_A9B12C7D13
        from bccc.ta.ta_A9B12C7D14 import ta_A9B12C7D14
        from bccc.ta.ta_A9B12C8D13 import ta_A9B12C8D13
        from bccc.ta.ta_A9B12C8D14 import ta_A9B12C8D14
        from bccc.ta.ta_A9B12C9D11 import ta_A9B12C9D11
        from bccc.ta.ta_A9B12C9D12 import ta_A9B12C9D12
        from bccc.ta.ta_A9B12C10D11 import ta_A9B12C10D11
        from bccc.ta.ta_A9B12C10D12 import ta_A9B12C10D12
        from bccc.ta.ta_A9B12C11D9 import ta_A9B12C11D9
        from bccc.ta.ta_A9B12C11D10 import ta_A9B12C11D10
        from bccc.ta.ta_A9B12C12D9 import ta_A9B12C12D9
        from bccc.ta.ta_A9B12C12D10 import ta_A9B12C12D10
        from bccc.ta.ta_A9B12C13D7 import ta_A9B12C13D7
        from bccc.ta.ta_A9B12C13D8 import ta_A9B12C13D8
        from bccc.ta.ta_A9B12C14D7 import ta_A9B12C14D7
        from bccc.ta.ta_A9B12C14D8 import ta_A9B12C14D8
        from bccc.ta.ta_A9B12C15D6 import ta_A9B12C15D6
        from bccc.ta.ta_A9B13C1D4 import ta_A9B13C1D4
        from bccc.ta.ta_A9B13C2D4 import ta_A9B13C2D4
        from bccc.ta.ta_A9B13C3D4 import ta_A9B13C3D4
        from bccc.ta.ta_A9B13C4D1 import ta_A9B13C4D1
        from bccc.ta.ta_A9B13C4D2 import ta_A9B13C4D2
        from bccc.ta.ta_A9B13C4D3 import ta_A9B13C4D3
        from bccc.ta.ta_A9B13C7D11 import ta_A9B13C7D11
        from bccc.ta.ta_A9B13C7D12 import ta_A9B13C7D12
        from bccc.ta.ta_A9B13C8D11 import ta_A9B13C8D11
        from bccc.ta.ta_A9B13C8D12 import ta_A9B13C8D12
        from bccc.ta.ta_A9B13C11D7 import ta_A9B13C11D7
        from bccc.ta.ta_A9B13C11D8 import ta_A9B13C11D8
        from bccc.ta.ta_A9B13C12D7 import ta_A9B13C12D7
        from bccc.ta.ta_A9B13C12D8 import ta_A9B13C12D8
        from bccc.ta.ta_A9B14C1D4 import ta_A9B14C1D4
        from bccc.ta.ta_A9B14C2D4 import ta_A9B14C2D4
        from bccc.ta.ta_A9B14C3D4 import ta_A9B14C3D4
        from bccc.ta.ta_A9B14C4D1 import ta_A9B14C4D1
        from bccc.ta.ta_A9B14C4D2 import ta_A9B14C4D2
        from bccc.ta.ta_A9B14C4D3 import ta_A9B14C4D3
        from bccc.ta.ta_A9B14C7D11 import ta_A9B14C7D11
        from bccc.ta.ta_A9B14C7D12 import ta_A9B14C7D12
        from bccc.ta.ta_A9B14C8D11 import ta_A9B14C8D11
        from bccc.ta.ta_A9B14C8D12 import ta_A9B14C8D12
        from bccc.ta.ta_A9B14C11D7 import ta_A9B14C11D7
        from bccc.ta.ta_A9B14C11D8 import ta_A9B14C11D8
        from bccc.ta.ta_A9B14C12D7 import ta_A9B14C12D7
        from bccc.ta.ta_A9B14C12D8 import ta_A9B14C12D8
        from bccc.ta.ta_A9B15C1D7 import ta_A9B15C1D7
        from bccc.ta.ta_A9B15C1D8 import ta_A9B15C1D8
        from bccc.ta.ta_A9B15C2D7 import ta_A9B15C2D7
        from bccc.ta.ta_A9B15C2D8 import ta_A9B15C2D8
        from bccc.ta.ta_A9B15C3D7 import ta_A9B15C3D7
        from bccc.ta.ta_A9B15C3D8 import ta_A9B15C3D8
        from bccc.ta.ta_A9B15C4D9 import ta_A9B15C4D9
        from bccc.ta.ta_A9B15C4D10 import ta_A9B15C4D10
        from bccc.ta.ta_A9B15C6D11 import ta_A9B15C6D11
        from bccc.ta.ta_A9B15C6D12 import ta_A9B15C6D12
        from bccc.ta.ta_A9B15C7D1 import ta_A9B15C7D1
        from bccc.ta.ta_A9B15C7D2 import ta_A9B15C7D2
        from bccc.ta.ta_A9B15C7D3 import ta_A9B15C7D3
        from bccc.ta.ta_A9B15C8D1 import ta_A9B15C8D1
        from bccc.ta.ta_A9B15C8D2 import ta_A9B15C8D2
        from bccc.ta.ta_A9B15C8D3 import ta_A9B15C8D3
        from bccc.ta.ta_A9B15C9D4 import ta_A9B15C9D4
        from bccc.ta.ta_A9B15C10D4 import ta_A9B15C10D4
        from bccc.ta.ta_A9B15C11D6 import ta_A9B15C11D6
        from bccc.ta.ta_A9B15C12D6 import ta_A9B15C12D6
        from bccc.ta.ta_A10B1C1D11 import ta_A10B1C1D11
        from bccc.ta.ta_A10B1C1D12 import ta_A10B1C1D12
        from bccc.ta.ta_A10B1C2D11 import ta_A10B1C2D11
        from bccc.ta.ta_A10B1C2D12 import ta_A10B1C2D12
        from bccc.ta.ta_A10B1C3D11 import ta_A10B1C3D11
        from bccc.ta.ta_A10B1C3D12 import ta_A10B1C3D12
        from bccc.ta.ta_A10B1C4D13 import ta_A10B1C4D13
        from bccc.ta.ta_A10B1C4D14 import ta_A10B1C4D14
        from bccc.ta.ta_A10B1C7D15 import ta_A10B1C7D15
        from bccc.ta.ta_A10B1C8D15 import ta_A10B1C8D15
        from bccc.ta.ta_A10B1C11D1 import ta_A10B1C11D1
        from bccc.ta.ta_A10B1C11D2 import ta_A10B1C11D2
        from bccc.ta.ta_A10B1C11D3 import ta_A10B1C11D3
        from bccc.ta.ta_A10B1C12D1 import ta_A10B1C12D1
        from bccc.ta.ta_A10B1C12D2 import ta_A10B1C12D2
        from bccc.ta.ta_A10B1C12D3 import ta_A10B1C12D3
        from bccc.ta.ta_A10B1C13D4 import ta_A10B1C13D4
        from bccc.ta.ta_A10B1C14D4 import ta_A10B1C14D4
        from bccc.ta.ta_A10B1C15D7 import ta_A10B1C15D7
        from bccc.ta.ta_A10B1C15D8 import ta_A10B1C15D8
        from bccc.ta.ta_A10B2C1D11 import ta_A10B2C1D11
        from bccc.ta.ta_A10B2C1D12 import ta_A10B2C1D12
        from bccc.ta.ta_A10B2C2D11 import ta_A10B2C2D11
        from bccc.ta.ta_A10B2C2D12 import ta_A10B2C2D12
        from bccc.ta.ta_A10B2C3D11 import ta_A10B2C3D11
        from bccc.ta.ta_A10B2C3D12 import ta_A10B2C3D12
        from bccc.ta.ta_A10B2C4D13 import ta_A10B2C4D13
        from bccc.ta.ta_A10B2C4D14 import ta_A10B2C4D14
        from bccc.ta.ta_A10B2C7D15 import ta_A10B2C7D15
        from bccc.ta.ta_A10B2C8D15 import ta_A10B2C8D15
        from bccc.ta.ta_A10B2C11D1 import ta_A10B2C11D1
        from bccc.ta.ta_A10B2C11D2 import ta_A10B2C11D2
        from bccc.ta.ta_A10B2C11D3 import ta_A10B2C11D3
        from bccc.ta.ta_A10B2C12D1 import ta_A10B2C12D1
        from bccc.ta.ta_A10B2C12D2 import ta_A10B2C12D2
        from bccc.ta.ta_A10B2C12D3 import ta_A10B2C12D3
        from bccc.ta.ta_A10B2C13D4 import ta_A10B2C13D4
        from bccc.ta.ta_A10B2C14D4 import ta_A10B2C14D4
        from bccc.ta.ta_A10B2C15D7 import ta_A10B2C15D7
        from bccc.ta.ta_A10B2C15D8 import ta_A10B2C15D8
        from bccc.ta.ta_A10B3C1D11 import ta_A10B3C1D11
        from bccc.ta.ta_A10B3C1D12 import ta_A10B3C1D12
        from bccc.ta.ta_A10B3C2D11 import ta_A10B3C2D11
        from bccc.ta.ta_A10B3C2D12 import ta_A10B3C2D12
        from bccc.ta.ta_A10B3C3D11 import ta_A10B3C3D11
        from bccc.ta.ta_A10B3C3D12 import ta_A10B3C3D12
        from bccc.ta.ta_A10B3C4D13 import ta_A10B3C4D13
        from bccc.ta.ta_A10B3C4D14 import ta_A10B3C4D14
        from bccc.ta.ta_A10B3C7D15 import ta_A10B3C7D15
        from bccc.ta.ta_A10B3C8D15 import ta_A10B3C8D15
        from bccc.ta.ta_A10B3C11D1 import ta_A10B3C11D1
        from bccc.ta.ta_A10B3C11D2 import ta_A10B3C11D2
        from bccc.ta.ta_A10B3C11D3 import ta_A10B3C11D3
        from bccc.ta.ta_A10B3C12D1 import ta_A10B3C12D1
        from bccc.ta.ta_A10B3C12D2 import ta_A10B3C12D2
        from bccc.ta.ta_A10B3C12D3 import ta_A10B3C12D3
        from bccc.ta.ta_A10B3C13D4 import ta_A10B3C13D4
        from bccc.ta.ta_A10B3C14D4 import ta_A10B3C14D4
        from bccc.ta.ta_A10B3C15D7 import ta_A10B3C15D7
        from bccc.ta.ta_A10B3C15D8 import ta_A10B3C15D8
        from bccc.ta.ta_A10B4C1D13 import ta_A10B4C1D13
        from bccc.ta.ta_A10B4C1D14 import ta_A10B4C1D14
        from bccc.ta.ta_A10B4C2D13 import ta_A10B4C2D13
        from bccc.ta.ta_A10B4C2D14 import ta_A10B4C2D14
        from bccc.ta.ta_A10B4C3D13 import ta_A10B4C3D13
        from bccc.ta.ta_A10B4C3D14 import ta_A10B4C3D14
        from bccc.ta.ta_A10B4C5D11 import ta_A10B4C5D11
        from bccc.ta.ta_A10B4C5D12 import ta_A10B4C5D12
        from bccc.ta.ta_A10B4C9D15 import ta_A10B4C9D15
        from bccc.ta.ta_A10B4C10D15 import ta_A10B4C10D15
        from bccc.ta.ta_A10B4C11D5 import ta_A10B4C11D5
        from bccc.ta.ta_A10B4C12D5 import ta_A10B4C12D5
        from bccc.ta.ta_A10B4C13D1 import ta_A10B4C13D1
        from bccc.ta.ta_A10B4C13D2 import ta_A10B4C13D2
        from bccc.ta.ta_A10B4C13D3 import ta_A10B4C13D3
        from bccc.ta.ta_A10B4C14D1 import ta_A10B4C14D1
        from bccc.ta.ta_A10B4C14D2 import ta_A10B4C14D2
        from bccc.ta.ta_A10B4C14D3 import ta_A10B4C14D3
        from bccc.ta.ta_A10B4C15D9 import ta_A10B4C15D9
        from bccc.ta.ta_A10B4C15D10 import ta_A10B4C15D10
        from bccc.ta.ta_A10B5C4D11 import ta_A10B5C4D11
        from bccc.ta.ta_A10B5C4D12 import ta_A10B5C4D12
        from bccc.ta.ta_A10B5C11D4 import ta_A10B5C11D4
        from bccc.ta.ta_A10B5C12D4 import ta_A10B5C12D4
        from bccc.ta.ta_A10B6C11D15 import ta_A10B6C11D15
        from bccc.ta.ta_A10B6C12D15 import ta_A10B6C12D15
        from bccc.ta.ta_A10B6C15D11 import ta_A10B6C15D11
        from bccc.ta.ta_A10B6C15D12 import ta_A10B6C15D12
        from bccc.ta.ta_A10B7C1D15 import ta_A10B7C1D15
        from bccc.ta.ta_A10B7C2D15 import ta_A10B7C2D15
        from bccc.ta.ta_A10B7C3D15 import ta_A10B7C3D15
        from bccc.ta.ta_A10B7C11D13 import ta_A10B7C11D13
        from bccc.ta.ta_A10B7C11D14 import ta_A10B7C11D14
        from bccc.ta.ta_A10B7C12D13 import ta_A10B7C12D13
        from bccc.ta.ta_A10B7C12D14 import ta_A10B7C12D14
        from bccc.ta.ta_A10B7C13D11 import ta_A10B7C13D11
        from bccc.ta.ta_A10B7C13D12 import ta_A10B7C13D12
        from bccc.ta.ta_A10B7C14D11 import ta_A10B7C14D11
        from bccc.ta.ta_A10B7C14D12 import ta_A10B7C14D12
        from bccc.ta.ta_A10B7C15D1 import ta_A10B7C15D1
        from bccc.ta.ta_A10B7C15D2 import ta_A10B7C15D2
        from bccc.ta.ta_A10B7C15D3 import ta_A10B7C15D3
        from bccc.ta.ta_A10B8C1D15 import ta_A10B8C1D15
        from bccc.ta.ta_A10B8C2D15 import ta_A10B8C2D15
        from bccc.ta.ta_A10B8C3D15 import ta_A10B8C3D15
        from bccc.ta.ta_A10B8C11D13 import ta_A10B8C11D13
        from bccc.ta.ta_A10B8C11D14 import ta_A10B8C11D14
        from bccc.ta.ta_A10B8C12D13 import ta_A10B8C12D13
        from bccc.ta.ta_A10B8C12D14 import ta_A10B8C12D14
        from bccc.ta.ta_A10B8C13D11 import ta_A10B8C13D11
        from bccc.ta.ta_A10B8C13D12 import ta_A10B8C13D12
        from bccc.ta.ta_A10B8C14D11 import ta_A10B8C14D11
        from bccc.ta.ta_A10B8C14D12 import ta_A10B8C14D12
        from bccc.ta.ta_A10B8C15D1 import ta_A10B8C15D1
        from bccc.ta.ta_A10B8C15D2 import ta_A10B8C15D2
        from bccc.ta.ta_A10B8C15D3 import ta_A10B8C15D3
        from bccc.ta.ta_A10B9C4D15 import ta_A10B9C4D15
        from bccc.ta.ta_A10B9C11D11 import ta_A10B9C11D11
        from bccc.ta.ta_A10B9C11D12 import ta_A10B9C11D12
        from bccc.ta.ta_A10B9C12D11 import ta_A10B9C12D11
        from bccc.ta.ta_A10B9C12D12 import ta_A10B9C12D12
        from bccc.ta.ta_A10B9C15D4 import ta_A10B9C15D4
        from bccc.ta.ta_A10B10C4D15 import ta_A10B10C4D15
        from bccc.ta.ta_A10B10C11D11 import ta_A10B10C11D11
        from bccc.ta.ta_A10B10C11D12 import ta_A10B10C11D12
        from bccc.ta.ta_A10B10C12D11 import ta_A10B10C12D11
        from bccc.ta.ta_A10B10C12D12 import ta_A10B10C12D12
        from bccc.ta.ta_A10B10C15D4 import ta_A10B10C15D4
        from bccc.ta.ta_A10B11C1D1 import ta_A10B11C1D1
        from bccc.ta.ta_A10B11C1D2 import ta_A10B11C1D2
        from bccc.ta.ta_A10B11C1D3 import ta_A10B11C1D3
        from bccc.ta.ta_A10B11C2D1 import ta_A10B11C2D1
        from bccc.ta.ta_A10B11C2D2 import ta_A10B11C2D2
        from bccc.ta.ta_A10B11C2D3 import ta_A10B11C2D3
        from bccc.ta.ta_A10B11C3D1 import ta_A10B11C3D1
        from bccc.ta.ta_A10B11C3D2 import ta_A10B11C3D2
        from bccc.ta.ta_A10B11C3D3 import ta_A10B11C3D3
        from bccc.ta.ta_A10B11C4D5 import ta_A10B11C4D5
        from bccc.ta.ta_A10B11C5D4 import ta_A10B11C5D4
        from bccc.ta.ta_A10B11C6D15 import ta_A10B11C6D15
        from bccc.ta.ta_A10B11C7D13 import ta_A10B11C7D13
        from bccc.ta.ta_A10B11C7D14 import ta_A10B11C7D14
        from bccc.ta.ta_A10B11C8D13 import ta_A10B11C8D13
        from bccc.ta.ta_A10B11C8D14 import ta_A10B11C8D14
        from bccc.ta.ta_A10B11C9D11 import ta_A10B11C9D11
        from bccc.ta.ta_A10B11C9D12 import ta_A10B11C9D12
        from bccc.ta.ta_A10B11C10D11 import ta_A10B11C10D11
        from bccc.ta.ta_A10B11C10D12 import ta_A10B11C10D12
        from bccc.ta.ta_A10B11C11D9 import ta_A10B11C11D9
        from bccc.ta.ta_A10B11C11D10 import ta_A10B11C11D10
        from bccc.ta.ta_A10B11C12D9 import ta_A10B11C12D9
        from bccc.ta.ta_A10B11C12D10 import ta_A10B11C12D10
        from bccc.ta.ta_A10B11C13D7 import ta_A10B11C13D7
        from bccc.ta.ta_A10B11C13D8 import ta_A10B11C13D8
        from bccc.ta.ta_A10B11C14D7 import ta_A10B11C14D7
        from bccc.ta.ta_A10B11C14D8 import ta_A10B11C14D8
        from bccc.ta.ta_A10B11C15D6 import ta_A10B11C15D6
        from bccc.ta.ta_A10B12C1D1 import ta_A10B12C1D1
        from bccc.ta.ta_A10B12C1D2 import ta_A10B12C1D2
        from bccc.ta.ta_A10B12C1D3 import ta_A10B12C1D3
        from bccc.ta.ta_A10B12C2D1 import ta_A10B12C2D1
        from bccc.ta.ta_A10B12C2D2 import ta_A10B12C2D2
        from bccc.ta.ta_A10B12C2D3 import ta_A10B12C2D3
        from bccc.ta.ta_A10B12C3D1 import ta_A10B12C3D1
        from bccc.ta.ta_A10B12C3D2 import ta_A10B12C3D2
        from bccc.ta.ta_A10B12C3D3 import ta_A10B12C3D3
        from bccc.ta.ta_A10B12C4D5 import ta_A10B12C4D5
        from bccc.ta.ta_A10B12C5D4 import ta_A10B12C5D4
        from bccc.ta.ta_A10B12C6D15 import ta_A10B12C6D15
        from bccc.ta.ta_A10B12C7D13 import ta_A10B12C7D13
        from bccc.ta.ta_A10B12C7D14 import ta_A10B12C7D14
        from bccc.ta.ta_A10B12C8D13 import ta_A10B12C8D13
        from bccc.ta.ta_A10B12C8D14 import ta_A10B12C8D14
        from bccc.ta.ta_A10B12C9D11 import ta_A10B12C9D11
        from bccc.ta.ta_A10B12C9D12 import ta_A10B12C9D12
        from bccc.ta.ta_A10B12C10D11 import ta_A10B12C10D11
        from bccc.ta.ta_A10B12C10D12 import ta_A10B12C10D12
        from bccc.ta.ta_A10B12C11D9 import ta_A10B12C11D9
        from bccc.ta.ta_A10B12C11D10 import ta_A10B12C11D10
        from bccc.ta.ta_A10B12C12D9 import ta_A10B12C12D9
        from bccc.ta.ta_A10B12C12D10 import ta_A10B12C12D10
        from bccc.ta.ta_A10B12C13D7 import ta_A10B12C13D7
        from bccc.ta.ta_A10B12C13D8 import ta_A10B12C13D8
        from bccc.ta.ta_A10B12C14D7 import ta_A10B12C14D7
        from bccc.ta.ta_A10B12C14D8 import ta_A10B12C14D8
        from bccc.ta.ta_A10B12C15D6 import ta_A10B12C15D6
        from bccc.ta.ta_A10B13C1D4 import ta_A10B13C1D4
        from bccc.ta.ta_A10B13C2D4 import ta_A10B13C2D4
        from bccc.ta.ta_A10B13C3D4 import ta_A10B13C3D4
        from bccc.ta.ta_A10B13C4D1 import ta_A10B13C4D1
        from bccc.ta.ta_A10B13C4D2 import ta_A10B13C4D2
        from bccc.ta.ta_A10B13C4D3 import ta_A10B13C4D3
        from bccc.ta.ta_A10B13C7D11 import ta_A10B13C7D11
        from bccc.ta.ta_A10B13C7D12 import ta_A10B13C7D12
        from bccc.ta.ta_A10B13C8D11 import ta_A10B13C8D11
        from bccc.ta.ta_A10B13C8D12 import ta_A10B13C8D12
        from bccc.ta.ta_A10B13C11D7 import ta_A10B13C11D7
        from bccc.ta.ta_A10B13C11D8 import ta_A10B13C11D8
        from bccc.ta.ta_A10B13C12D7 import ta_A10B13C12D7
        from bccc.ta.ta_A10B13C12D8 import ta_A10B13C12D8
        from bccc.ta.ta_A10B14C1D4 import ta_A10B14C1D4
        from bccc.ta.ta_A10B14C2D4 import ta_A10B14C2D4
        from bccc.ta.ta_A10B14C3D4 import ta_A10B14C3D4
        from bccc.ta.ta_A10B14C4D1 import ta_A10B14C4D1
        from bccc.ta.ta_A10B14C4D2 import ta_A10B14C4D2
        from bccc.ta.ta_A10B14C4D3 import ta_A10B14C4D3
        from bccc.ta.ta_A10B14C7D11 import ta_A10B14C7D11
        from bccc.ta.ta_A10B14C7D12 import ta_A10B14C7D12
        from bccc.ta.ta_A10B14C8D11 import ta_A10B14C8D11
        from bccc.ta.ta_A10B14C8D12 import ta_A10B14C8D12
        from bccc.ta.ta_A10B14C11D7 import ta_A10B14C11D7
        from bccc.ta.ta_A10B14C11D8 import ta_A10B14C11D8
        from bccc.ta.ta_A10B14C12D7 import ta_A10B14C12D7
        from bccc.ta.ta_A10B14C12D8 import ta_A10B14C12D8
        from bccc.ta.ta_A10B15C1D7 import ta_A10B15C1D7
        from bccc.ta.ta_A10B15C1D8 import ta_A10B15C1D8
        from bccc.ta.ta_A10B15C2D7 import ta_A10B15C2D7
        from bccc.ta.ta_A10B15C2D8 import ta_A10B15C2D8
        from bccc.ta.ta_A10B15C3D7 import ta_A10B15C3D7
        from bccc.ta.ta_A10B15C3D8 import ta_A10B15C3D8
        from bccc.ta.ta_A10B15C4D9 import ta_A10B15C4D9
        from bccc.ta.ta_A10B15C4D10 import ta_A10B15C4D10
        from bccc.ta.ta_A10B15C6D11 import ta_A10B15C6D11
        from bccc.ta.ta_A10B15C6D12 import ta_A10B15C6D12
        from bccc.ta.ta_A10B15C7D1 import ta_A10B15C7D1
        from bccc.ta.ta_A10B15C7D2 import ta_A10B15C7D2
        from bccc.ta.ta_A10B15C7D3 import ta_A10B15C7D3
        from bccc.ta.ta_A10B15C8D1 import ta_A10B15C8D1
        from bccc.ta.ta_A10B15C8D2 import ta_A10B15C8D2
        from bccc.ta.ta_A10B15C8D3 import ta_A10B15C8D3
        from bccc.ta.ta_A10B15C9D4 import ta_A10B15C9D4
        from bccc.ta.ta_A10B15C10D4 import ta_A10B15C10D4
        from bccc.ta.ta_A10B15C11D6 import ta_A10B15C11D6
        from bccc.ta.ta_A10B15C12D6 import ta_A10B15C12D6
        from bccc.ta.ta_A11B1C1D9 import ta_A11B1C1D9
        from bccc.ta.ta_A11B1C1D10 import ta_A11B1C1D10
        from bccc.ta.ta_A11B1C2D9 import ta_A11B1C2D9
        from bccc.ta.ta_A11B1C2D10 import ta_A11B1C2D10
        from bccc.ta.ta_A11B1C3D9 import ta_A11B1C3D9
        from bccc.ta.ta_A11B1C3D10 import ta_A11B1C3D10
        from bccc.ta.ta_A11B1C5D7 import ta_A11B1C5D7
        from bccc.ta.ta_A11B1C5D8 import ta_A11B1C5D8
        from bccc.ta.ta_A11B1C6D13 import ta_A11B1C6D13
        from bccc.ta.ta_A11B1C6D14 import ta_A11B1C6D14
        from bccc.ta.ta_A11B1C7D5 import ta_A11B1C7D5
        from bccc.ta.ta_A11B1C8D5 import ta_A11B1C8D5
        from bccc.ta.ta_A11B1C9D1 import ta_A11B1C9D1
        from bccc.ta.ta_A11B1C9D2 import ta_A11B1C9D2
        from bccc.ta.ta_A11B1C9D3 import ta_A11B1C9D3
        from bccc.ta.ta_A11B1C10D1 import ta_A11B1C10D1
        from bccc.ta.ta_A11B1C10D2 import ta_A11B1C10D2
        from bccc.ta.ta_A11B1C10D3 import ta_A11B1C10D3
        from bccc.ta.ta_A11B1C13D6 import ta_A11B1C13D6
        from bccc.ta.ta_A11B1C14D6 import ta_A11B1C14D6
        from bccc.ta.ta_A11B2C1D9 import ta_A11B2C1D9
        from bccc.ta.ta_A11B2C1D10 import ta_A11B2C1D10
        from bccc.ta.ta_A11B2C2D9 import ta_A11B2C2D9
        from bccc.ta.ta_A11B2C2D10 import ta_A11B2C2D10
        from bccc.ta.ta_A11B2C3D9 import ta_A11B2C3D9
        from bccc.ta.ta_A11B2C3D10 import ta_A11B2C3D10
        from bccc.ta.ta_A11B2C5D7 import ta_A11B2C5D7
        from bccc.ta.ta_A11B2C5D8 import ta_A11B2C5D8
        from bccc.ta.ta_A11B2C6D13 import ta_A11B2C6D13
        from bccc.ta.ta_A11B2C6D14 import ta_A11B2C6D14
        from bccc.ta.ta_A11B2C7D5 import ta_A11B2C7D5
        from bccc.ta.ta_A11B2C8D5 import ta_A11B2C8D5
        from bccc.ta.ta_A11B2C9D1 import ta_A11B2C9D1
        from bccc.ta.ta_A11B2C9D2 import ta_A11B2C9D2
        from bccc.ta.ta_A11B2C9D3 import ta_A11B2C9D3
        from bccc.ta.ta_A11B2C10D1 import ta_A11B2C10D1
        from bccc.ta.ta_A11B2C10D2 import ta_A11B2C10D2
        from bccc.ta.ta_A11B2C10D3 import ta_A11B2C10D3
        from bccc.ta.ta_A11B2C13D6 import ta_A11B2C13D6
        from bccc.ta.ta_A11B2C14D6 import ta_A11B2C14D6
        from bccc.ta.ta_A11B3C1D9 import ta_A11B3C1D9
        from bccc.ta.ta_A11B3C1D10 import ta_A11B3C1D10
        from bccc.ta.ta_A11B3C2D9 import ta_A11B3C2D9
        from bccc.ta.ta_A11B3C2D10 import ta_A11B3C2D10
        from bccc.ta.ta_A11B3C3D9 import ta_A11B3C3D9
        from bccc.ta.ta_A11B3C3D10 import ta_A11B3C3D10
        from bccc.ta.ta_A11B3C5D7 import ta_A11B3C5D7
        from bccc.ta.ta_A11B3C5D8 import ta_A11B3C5D8
        from bccc.ta.ta_A11B3C6D13 import ta_A11B3C6D13
        from bccc.ta.ta_A11B3C6D14 import ta_A11B3C6D14
        from bccc.ta.ta_A11B3C7D5 import ta_A11B3C7D5
        from bccc.ta.ta_A11B3C8D5 import ta_A11B3C8D5
        from bccc.ta.ta_A11B3C9D1 import ta_A11B3C9D1
        from bccc.ta.ta_A11B3C9D2 import ta_A11B3C9D2
        from bccc.ta.ta_A11B3C9D3 import ta_A11B3C9D3
        from bccc.ta.ta_A11B3C10D1 import ta_A11B3C10D1
        from bccc.ta.ta_A11B3C10D2 import ta_A11B3C10D2
        from bccc.ta.ta_A11B3C10D3 import ta_A11B3C10D3
        from bccc.ta.ta_A11B3C13D6 import ta_A11B3C13D6
        from bccc.ta.ta_A11B3C14D6 import ta_A11B3C14D6
        from bccc.ta.ta_A11B4C5D9 import ta_A11B4C5D9
        from bccc.ta.ta_A11B4C5D10 import ta_A11B4C5D10
        from bccc.ta.ta_A11B4C9D5 import ta_A11B4C9D5
        from bccc.ta.ta_A11B4C10D5 import ta_A11B4C10D5
        from bccc.ta.ta_A11B5C1D7 import ta_A11B5C1D7
        from bccc.ta.ta_A11B5C1D8 import ta_A11B5C1D8
        from bccc.ta.ta_A11B5C2D7 import ta_A11B5C2D7
        from bccc.ta.ta_A11B5C2D8 import ta_A11B5C2D8
        from bccc.ta.ta_A11B5C3D7 import ta_A11B5C3D7
        from bccc.ta.ta_A11B5C3D8 import ta_A11B5C3D8
        from bccc.ta.ta_A11B5C4D9 import ta_A11B5C4D9
        from bccc.ta.ta_A11B5C4D10 import ta_A11B5C4D10
        from bccc.ta.ta_A11B5C6D11 import ta_A11B5C6D11
        from bccc.ta.ta_A11B5C6D12 import ta_A11B5C6D12
        from bccc.ta.ta_A11B5C7D1 import ta_A11B5C7D1
        from bccc.ta.ta_A11B5C7D2 import ta_A11B5C7D2
        from bccc.ta.ta_A11B5C7D3 import ta_A11B5C7D3
        from bccc.ta.ta_A11B5C8D1 import ta_A11B5C8D1
        from bccc.ta.ta_A11B5C8D2 import ta_A11B5C8D2
        from bccc.ta.ta_A11B5C8D3 import ta_A11B5C8D3
        from bccc.ta.ta_A11B5C9D4 import ta_A11B5C9D4
        from bccc.ta.ta_A11B5C10D4 import ta_A11B5C10D4
        from bccc.ta.ta_A11B5C11D6 import ta_A11B5C11D6
        from bccc.ta.ta_A11B5C12D6 import ta_A11B5C12D6
        from bccc.ta.ta_A11B6C1D13 import ta_A11B6C1D13
        from bccc.ta.ta_A11B6C1D14 import ta_A11B6C1D14
        from bccc.ta.ta_A11B6C2D13 import ta_A11B6C2D13
        from bccc.ta.ta_A11B6C2D14 import ta_A11B6C2D14
        from bccc.ta.ta_A11B6C3D13 import ta_A11B6C3D13
        from bccc.ta.ta_A11B6C3D14 import ta_A11B6C3D14
        from bccc.ta.ta_A11B6C5D11 import ta_A11B6C5D11
        from bccc.ta.ta_A11B6C5D12 import ta_A11B6C5D12
        from bccc.ta.ta_A11B6C9D15 import ta_A11B6C9D15
        from bccc.ta.ta_A11B6C10D15 import ta_A11B6C10D15
        from bccc.ta.ta_A11B6C11D5 import ta_A11B6C11D5
        from bccc.ta.ta_A11B6C12D5 import ta_A11B6C12D5
        from bccc.ta.ta_A11B6C13D1 import ta_A11B6C13D1
        from bccc.ta.ta_A11B6C13D2 import ta_A11B6C13D2
        from bccc.ta.ta_A11B6C13D3 import ta_A11B6C13D3
        from bccc.ta.ta_A11B6C14D1 import ta_A11B6C14D1
        from bccc.ta.ta_A11B6C14D2 import ta_A11B6C14D2
        from bccc.ta.ta_A11B6C14D3 import ta_A11B6C14D3
        from bccc.ta.ta_A11B6C15D9 import ta_A11B6C15D9
        from bccc.ta.ta_A11B6C15D10 import ta_A11B6C15D10
        from bccc.ta.ta_A11B7C1D5 import ta_A11B7C1D5
        from bccc.ta.ta_A11B7C2D5 import ta_A11B7C2D5
        from bccc.ta.ta_A11B7C3D5 import ta_A11B7C3D5
        from bccc.ta.ta_A11B7C5D1 import ta_A11B7C5D1
        from bccc.ta.ta_A11B7C5D2 import ta_A11B7C5D2
        from bccc.ta.ta_A11B7C5D3 import ta_A11B7C5D3
        from bccc.ta.ta_A11B7C9D13 import ta_A11B7C9D13
        from bccc.ta.ta_A11B7C9D14 import ta_A11B7C9D14
        from bccc.ta.ta_A11B7C10D13 import ta_A11B7C10D13
        from bccc.ta.ta_A11B7C10D14 import ta_A11B7C10D14
        from bccc.ta.ta_A11B7C13D9 import ta_A11B7C13D9
        from bccc.ta.ta_A11B7C13D10 import ta_A11B7C13D10
        from bccc.ta.ta_A11B7C14D9 import ta_A11B7C14D9
        from bccc.ta.ta_A11B7C14D10 import ta_A11B7C14D10
        from bccc.ta.ta_A11B8C1D5 import ta_A11B8C1D5
        from bccc.ta.ta_A11B8C2D5 import ta_A11B8C2D5
        from bccc.ta.ta_A11B8C3D5 import ta_A11B8C3D5
        from bccc.ta.ta_A11B8C5D1 import ta_A11B8C5D1
        from bccc.ta.ta_A11B8C5D2 import ta_A11B8C5D2
        from bccc.ta.ta_A11B8C5D3 import ta_A11B8C5D3
        from bccc.ta.ta_A11B8C9D13 import ta_A11B8C9D13
        from bccc.ta.ta_A11B8C9D14 import ta_A11B8C9D14
        from bccc.ta.ta_A11B8C10D13 import ta_A11B8C10D13
        from bccc.ta.ta_A11B8C10D14 import ta_A11B8C10D14
        from bccc.ta.ta_A11B8C13D9 import ta_A11B8C13D9
        from bccc.ta.ta_A11B8C13D10 import ta_A11B8C13D10
        from bccc.ta.ta_A11B8C14D9 import ta_A11B8C14D9
        from bccc.ta.ta_A11B8C14D10 import ta_A11B8C14D10
        from bccc.ta.ta_A11B9C1D1 import ta_A11B9C1D1
        from bccc.ta.ta_A11B9C1D2 import ta_A11B9C1D2
        from bccc.ta.ta_A11B9C1D3 import ta_A11B9C1D3
        from bccc.ta.ta_A11B9C2D1 import ta_A11B9C2D1
        from bccc.ta.ta_A11B9C2D2 import ta_A11B9C2D2
        from bccc.ta.ta_A11B9C2D3 import ta_A11B9C2D3
        from bccc.ta.ta_A11B9C3D1 import ta_A11B9C3D1
        from bccc.ta.ta_A11B9C3D2 import ta_A11B9C3D2
        from bccc.ta.ta_A11B9C3D3 import ta_A11B9C3D3
        from bccc.ta.ta_A11B9C4D5 import ta_A11B9C4D5
        from bccc.ta.ta_A11B9C5D4 import ta_A11B9C5D4
        from bccc.ta.ta_A11B9C6D15 import ta_A11B9C6D15
        from bccc.ta.ta_A11B9C7D13 import ta_A11B9C7D13
        from bccc.ta.ta_A11B9C7D14 import ta_A11B9C7D14
        from bccc.ta.ta_A11B9C8D13 import ta_A11B9C8D13
        from bccc.ta.ta_A11B9C8D14 import ta_A11B9C8D14
        from bccc.ta.ta_A11B9C9D11 import ta_A11B9C9D11
        from bccc.ta.ta_A11B9C9D12 import ta_A11B9C9D12
        from bccc.ta.ta_A11B9C10D11 import ta_A11B9C10D11
        from bccc.ta.ta_A11B9C10D12 import ta_A11B9C10D12
        from bccc.ta.ta_A11B9C11D9 import ta_A11B9C11D9
        from bccc.ta.ta_A11B9C11D10 import ta_A11B9C11D10
        from bccc.ta.ta_A11B9C12D9 import ta_A11B9C12D9
        from bccc.ta.ta_A11B9C12D10 import ta_A11B9C12D10
        from bccc.ta.ta_A11B9C13D7 import ta_A11B9C13D7
        from bccc.ta.ta_A11B9C13D8 import ta_A11B9C13D8
        from bccc.ta.ta_A11B9C14D7 import ta_A11B9C14D7
        from bccc.ta.ta_A11B9C14D8 import ta_A11B9C14D8
        from bccc.ta.ta_A11B9C15D6 import ta_A11B9C15D6
        from bccc.ta.ta_A11B10C1D1 import ta_A11B10C1D1
        from bccc.ta.ta_A11B10C1D2 import ta_A11B10C1D2
        from bccc.ta.ta_A11B10C1D3 import ta_A11B10C1D3
        from bccc.ta.ta_A11B10C2D1 import ta_A11B10C2D1
        from bccc.ta.ta_A11B10C2D2 import ta_A11B10C2D2
        from bccc.ta.ta_A11B10C2D3 import ta_A11B10C2D3
        from bccc.ta.ta_A11B10C3D1 import ta_A11B10C3D1
        from bccc.ta.ta_A11B10C3D2 import ta_A11B10C3D2
        from bccc.ta.ta_A11B10C3D3 import ta_A11B10C3D3
        from bccc.ta.ta_A11B10C4D5 import ta_A11B10C4D5
        from bccc.ta.ta_A11B10C5D4 import ta_A11B10C5D4
        from bccc.ta.ta_A11B10C6D15 import ta_A11B10C6D15
        from bccc.ta.ta_A11B10C7D13 import ta_A11B10C7D13
        from bccc.ta.ta_A11B10C7D14 import ta_A11B10C7D14
        from bccc.ta.ta_A11B10C8D13 import ta_A11B10C8D13
        from bccc.ta.ta_A11B10C8D14 import ta_A11B10C8D14
        from bccc.ta.ta_A11B10C9D11 import ta_A11B10C9D11
        from bccc.ta.ta_A11B10C9D12 import ta_A11B10C9D12
        from bccc.ta.ta_A11B10C10D11 import ta_A11B10C10D11
        from bccc.ta.ta_A11B10C10D12 import ta_A11B10C10D12
        from bccc.ta.ta_A11B10C11D9 import ta_A11B10C11D9
        from bccc.ta.ta_A11B10C11D10 import ta_A11B10C11D10
        from bccc.ta.ta_A11B10C12D9 import ta_A11B10C12D9
        from bccc.ta.ta_A11B10C12D10 import ta_A11B10C12D10
        from bccc.ta.ta_A11B10C13D7 import ta_A11B10C13D7
        from bccc.ta.ta_A11B10C13D8 import ta_A11B10C13D8
        from bccc.ta.ta_A11B10C14D7 import ta_A11B10C14D7
        from bccc.ta.ta_A11B10C14D8 import ta_A11B10C14D8
        from bccc.ta.ta_A11B10C15D6 import ta_A11B10C15D6
        from bccc.ta.ta_A11B11C5D6 import ta_A11B11C5D6
        from bccc.ta.ta_A11B11C6D5 import ta_A11B11C6D5
        from bccc.ta.ta_A11B11C9D9 import ta_A11B11C9D9
        from bccc.ta.ta_A11B11C9D10 import ta_A11B11C9D10
        from bccc.ta.ta_A11B11C10D9 import ta_A11B11C10D9
        from bccc.ta.ta_A11B11C10D10 import ta_A11B11C10D10
        from bccc.ta.ta_A11B12C5D6 import ta_A11B12C5D6
        from bccc.ta.ta_A11B12C6D5 import ta_A11B12C6D5
        from bccc.ta.ta_A11B12C9D9 import ta_A11B12C9D9
        from bccc.ta.ta_A11B12C9D10 import ta_A11B12C9D10
        from bccc.ta.ta_A11B12C10D9 import ta_A11B12C10D9
        from bccc.ta.ta_A11B12C10D10 import ta_A11B12C10D10
        from bccc.ta.ta_A11B13C1D6 import ta_A11B13C1D6
        from bccc.ta.ta_A11B13C2D6 import ta_A11B13C2D6
        from bccc.ta.ta_A11B13C3D6 import ta_A11B13C3D6
        from bccc.ta.ta_A11B13C6D1 import ta_A11B13C6D1
        from bccc.ta.ta_A11B13C6D2 import ta_A11B13C6D2
        from bccc.ta.ta_A11B13C6D3 import ta_A11B13C6D3
        from bccc.ta.ta_A11B13C7D9 import ta_A11B13C7D9
        from bccc.ta.ta_A11B13C7D10 import ta_A11B13C7D10
        from bccc.ta.ta_A11B13C8D9 import ta_A11B13C8D9
        from bccc.ta.ta_A11B13C8D10 import ta_A11B13C8D10
        from bccc.ta.ta_A11B13C9D7 import ta_A11B13C9D7
        from bccc.ta.ta_A11B13C9D8 import ta_A11B13C9D8
        from bccc.ta.ta_A11B13C10D7 import ta_A11B13C10D7
        from bccc.ta.ta_A11B13C10D8 import ta_A11B13C10D8
        from bccc.ta.ta_A11B14C1D6 import ta_A11B14C1D6
        from bccc.ta.ta_A11B14C2D6 import ta_A11B14C2D6
        from bccc.ta.ta_A11B14C3D6 import ta_A11B14C3D6
        from bccc.ta.ta_A11B14C6D1 import ta_A11B14C6D1
        from bccc.ta.ta_A11B14C6D2 import ta_A11B14C6D2
        from bccc.ta.ta_A11B14C6D3 import ta_A11B14C6D3
        from bccc.ta.ta_A11B14C7D9 import ta_A11B14C7D9
        from bccc.ta.ta_A11B14C7D10 import ta_A11B14C7D10
        from bccc.ta.ta_A11B14C8D9 import ta_A11B14C8D9
        from bccc.ta.ta_A11B14C8D10 import ta_A11B14C8D10
        from bccc.ta.ta_A11B14C9D7 import ta_A11B14C9D7
        from bccc.ta.ta_A11B14C9D8 import ta_A11B14C9D8
        from bccc.ta.ta_A11B14C10D7 import ta_A11B14C10D7
        from bccc.ta.ta_A11B14C10D8 import ta_A11B14C10D8
        from bccc.ta.ta_A11B15C6D9 import ta_A11B15C6D9
        from bccc.ta.ta_A11B15C6D10 import ta_A11B15C6D10
        from bccc.ta.ta_A11B15C9D6 import ta_A11B15C9D6
        from bccc.ta.ta_A11B15C10D6 import ta_A11B15C10D6
        from bccc.ta.ta_A12B1C1D9 import ta_A12B1C1D9
        from bccc.ta.ta_A12B1C1D10 import ta_A12B1C1D10
        from bccc.ta.ta_A12B1C2D9 import ta_A12B1C2D9
        from bccc.ta.ta_A12B1C2D10 import ta_A12B1C2D10
        from bccc.ta.ta_A12B1C3D9 import ta_A12B1C3D9
        from bccc.ta.ta_A12B1C3D10 import ta_A12B1C3D10
        from bccc.ta.ta_A12B1C5D7 import ta_A12B1C5D7
        from bccc.ta.ta_A12B1C5D8 import ta_A12B1C5D8
        from bccc.ta.ta_A12B1C6D13 import ta_A12B1C6D13
        from bccc.ta.ta_A12B1C6D14 import ta_A12B1C6D14
        from bccc.ta.ta_A12B1C7D5 import ta_A12B1C7D5
        from bccc.ta.ta_A12B1C8D5 import ta_A12B1C8D5
        from bccc.ta.ta_A12B1C9D1 import ta_A12B1C9D1
        from bccc.ta.ta_A12B1C9D2 import ta_A12B1C9D2
        from bccc.ta.ta_A12B1C9D3 import ta_A12B1C9D3
        from bccc.ta.ta_A12B1C10D1 import ta_A12B1C10D1
        from bccc.ta.ta_A12B1C10D2 import ta_A12B1C10D2
        from bccc.ta.ta_A12B1C10D3 import ta_A12B1C10D3
        from bccc.ta.ta_A12B1C13D6 import ta_A12B1C13D6
        from bccc.ta.ta_A12B1C14D6 import ta_A12B1C14D6
        from bccc.ta.ta_A12B2C1D9 import ta_A12B2C1D9
        from bccc.ta.ta_A12B2C1D10 import ta_A12B2C1D10
        from bccc.ta.ta_A12B2C2D9 import ta_A12B2C2D9
        from bccc.ta.ta_A12B2C2D10 import ta_A12B2C2D10
        from bccc.ta.ta_A12B2C3D9 import ta_A12B2C3D9
        from bccc.ta.ta_A12B2C3D10 import ta_A12B2C3D10
        from bccc.ta.ta_A12B2C5D7 import ta_A12B2C5D7
        from bccc.ta.ta_A12B2C5D8 import ta_A12B2C5D8
        from bccc.ta.ta_A12B2C6D13 import ta_A12B2C6D13
        from bccc.ta.ta_A12B2C6D14 import ta_A12B2C6D14
        from bccc.ta.ta_A12B2C7D5 import ta_A12B2C7D5
        from bccc.ta.ta_A12B2C8D5 import ta_A12B2C8D5
        from bccc.ta.ta_A12B2C9D1 import ta_A12B2C9D1
        from bccc.ta.ta_A12B2C9D2 import ta_A12B2C9D2
        from bccc.ta.ta_A12B2C9D3 import ta_A12B2C9D3
        from bccc.ta.ta_A12B2C10D1 import ta_A12B2C10D1
        from bccc.ta.ta_A12B2C10D2 import ta_A12B2C10D2
        from bccc.ta.ta_A12B2C10D3 import ta_A12B2C10D3
        from bccc.ta.ta_A12B2C13D6 import ta_A12B2C13D6
        from bccc.ta.ta_A12B2C14D6 import ta_A12B2C14D6
        from bccc.ta.ta_A12B3C1D9 import ta_A12B3C1D9
        from bccc.ta.ta_A12B3C1D10 import ta_A12B3C1D10
        from bccc.ta.ta_A12B3C2D9 import ta_A12B3C2D9
        from bccc.ta.ta_A12B3C2D10 import ta_A12B3C2D10
        from bccc.ta.ta_A12B3C3D9 import ta_A12B3C3D9
        from bccc.ta.ta_A12B3C3D10 import ta_A12B3C3D10
        from bccc.ta.ta_A12B3C5D7 import ta_A12B3C5D7
        from bccc.ta.ta_A12B3C5D8 import ta_A12B3C5D8
        from bccc.ta.ta_A12B3C6D13 import ta_A12B3C6D13
        from bccc.ta.ta_A12B3C6D14 import ta_A12B3C6D14
        from bccc.ta.ta_A12B3C7D5 import ta_A12B3C7D5
        from bccc.ta.ta_A12B3C8D5 import ta_A12B3C8D5
        from bccc.ta.ta_A12B3C9D1 import ta_A12B3C9D1
        from bccc.ta.ta_A12B3C9D2 import ta_A12B3C9D2
        from bccc.ta.ta_A12B3C9D3 import ta_A12B3C9D3
        from bccc.ta.ta_A12B3C10D1 import ta_A12B3C10D1
        from bccc.ta.ta_A12B3C10D2 import ta_A12B3C10D2
        from bccc.ta.ta_A12B3C10D3 import ta_A12B3C10D3
        from bccc.ta.ta_A12B3C13D6 import ta_A12B3C13D6
        from bccc.ta.ta_A12B3C14D6 import ta_A12B3C14D6
        from bccc.ta.ta_A12B4C5D9 import ta_A12B4C5D9
        from bccc.ta.ta_A12B4C5D10 import ta_A12B4C5D10
        from bccc.ta.ta_A12B4C9D5 import ta_A12B4C9D5
        from bccc.ta.ta_A12B4C10D5 import ta_A12B4C10D5
        from bccc.ta.ta_A12B5C1D7 import ta_A12B5C1D7
        from bccc.ta.ta_A12B5C1D8 import ta_A12B5C1D8
        from bccc.ta.ta_A12B5C2D7 import ta_A12B5C2D7
        from bccc.ta.ta_A12B5C2D8 import ta_A12B5C2D8
        from bccc.ta.ta_A12B5C3D7 import ta_A12B5C3D7
        from bccc.ta.ta_A12B5C3D8 import ta_A12B5C3D8
        from bccc.ta.ta_A12B5C4D9 import ta_A12B5C4D9
        from bccc.ta.ta_A12B5C4D10 import ta_A12B5C4D10
        from bccc.ta.ta_A12B5C6D11 import ta_A12B5C6D11
        from bccc.ta.ta_A12B5C6D12 import ta_A12B5C6D12
        from bccc.ta.ta_A12B5C7D1 import ta_A12B5C7D1
        from bccc.ta.ta_A12B5C7D2 import ta_A12B5C7D2
        from bccc.ta.ta_A12B5C7D3 import ta_A12B5C7D3
        from bccc.ta.ta_A12B5C8D1 import ta_A12B5C8D1
        from bccc.ta.ta_A12B5C8D2 import ta_A12B5C8D2
        from bccc.ta.ta_A12B5C8D3 import ta_A12B5C8D3
        from bccc.ta.ta_A12B5C9D4 import ta_A12B5C9D4
        from bccc.ta.ta_A12B5C10D4 import ta_A12B5C10D4
        from bccc.ta.ta_A12B5C11D6 import ta_A12B5C11D6
        from bccc.ta.ta_A12B5C12D6 import ta_A12B5C12D6
        from bccc.ta.ta_A12B6C1D13 import ta_A12B6C1D13
        from bccc.ta.ta_A12B6C1D14 import ta_A12B6C1D14
        from bccc.ta.ta_A12B6C2D13 import ta_A12B6C2D13
        from bccc.ta.ta_A12B6C2D14 import ta_A12B6C2D14
        from bccc.ta.ta_A12B6C3D13 import ta_A12B6C3D13
        from bccc.ta.ta_A12B6C3D14 import ta_A12B6C3D14
        from bccc.ta.ta_A12B6C5D11 import ta_A12B6C5D11
        from bccc.ta.ta_A12B6C5D12 import ta_A12B6C5D12
        from bccc.ta.ta_A12B6C9D15 import ta_A12B6C9D15
        from bccc.ta.ta_A12B6C10D15 import ta_A12B6C10D15
        from bccc.ta.ta_A12B6C11D5 import ta_A12B6C11D5
        from bccc.ta.ta_A12B6C12D5 import ta_A12B6C12D5
        from bccc.ta.ta_A12B6C13D1 import ta_A12B6C13D1
        from bccc.ta.ta_A12B6C13D2 import ta_A12B6C13D2
        from bccc.ta.ta_A12B6C13D3 import ta_A12B6C13D3
        from bccc.ta.ta_A12B6C14D1 import ta_A12B6C14D1
        from bccc.ta.ta_A12B6C14D2 import ta_A12B6C14D2
        from bccc.ta.ta_A12B6C14D3 import ta_A12B6C14D3
        from bccc.ta.ta_A12B6C15D9 import ta_A12B6C15D9
        from bccc.ta.ta_A12B6C15D10 import ta_A12B6C15D10
        from bccc.ta.ta_A12B7C1D5 import ta_A12B7C1D5
        from bccc.ta.ta_A12B7C2D5 import ta_A12B7C2D5
        from bccc.ta.ta_A12B7C3D5 import ta_A12B7C3D5
        from bccc.ta.ta_A12B7C5D1 import ta_A12B7C5D1
        from bccc.ta.ta_A12B7C5D2 import ta_A12B7C5D2
        from bccc.ta.ta_A12B7C5D3 import ta_A12B7C5D3
        from bccc.ta.ta_A12B7C9D13 import ta_A12B7C9D13
        from bccc.ta.ta_A12B7C9D14 import ta_A12B7C9D14
        from bccc.ta.ta_A12B7C10D13 import ta_A12B7C10D13
        from bccc.ta.ta_A12B7C10D14 import ta_A12B7C10D14
        from bccc.ta.ta_A12B7C13D9 import ta_A12B7C13D9
        from bccc.ta.ta_A12B7C13D10 import ta_A12B7C13D10
        from bccc.ta.ta_A12B7C14D9 import ta_A12B7C14D9
        from bccc.ta.ta_A12B7C14D10 import ta_A12B7C14D10
        from bccc.ta.ta_A12B8C1D5 import ta_A12B8C1D5
        from bccc.ta.ta_A12B8C2D5 import ta_A12B8C2D5
        from bccc.ta.ta_A12B8C3D5 import ta_A12B8C3D5
        from bccc.ta.ta_A12B8C5D1 import ta_A12B8C5D1
        from bccc.ta.ta_A12B8C5D2 import ta_A12B8C5D2
        from bccc.ta.ta_A12B8C5D3 import ta_A12B8C5D3
        from bccc.ta.ta_A12B8C9D13 import ta_A12B8C9D13
        from bccc.ta.ta_A12B8C9D14 import ta_A12B8C9D14
        from bccc.ta.ta_A12B8C10D13 import ta_A12B8C10D13
        from bccc.ta.ta_A12B8C10D14 import ta_A12B8C10D14
        from bccc.ta.ta_A12B8C13D9 import ta_A12B8C13D9
        from bccc.ta.ta_A12B8C13D10 import ta_A12B8C13D10
        from bccc.ta.ta_A12B8C14D9 import ta_A12B8C14D9
        from bccc.ta.ta_A12B8C14D10 import ta_A12B8C14D10
        from bccc.ta.ta_A12B9C1D1 import ta_A12B9C1D1
        from bccc.ta.ta_A12B9C1D2 import ta_A12B9C1D2
        from bccc.ta.ta_A12B9C1D3 import ta_A12B9C1D3
        from bccc.ta.ta_A12B9C2D1 import ta_A12B9C2D1
        from bccc.ta.ta_A12B9C2D2 import ta_A12B9C2D2
        from bccc.ta.ta_A12B9C2D3 import ta_A12B9C2D3
        from bccc.ta.ta_A12B9C3D1 import ta_A12B9C3D1
        from bccc.ta.ta_A12B9C3D2 import ta_A12B9C3D2
        from bccc.ta.ta_A12B9C3D3 import ta_A12B9C3D3
        from bccc.ta.ta_A12B9C4D5 import ta_A12B9C4D5
        from bccc.ta.ta_A12B9C5D4 import ta_A12B9C5D4
        from bccc.ta.ta_A12B9C6D15 import ta_A12B9C6D15
        from bccc.ta.ta_A12B9C7D13 import ta_A12B9C7D13
        from bccc.ta.ta_A12B9C7D14 import ta_A12B9C7D14
        from bccc.ta.ta_A12B9C8D13 import ta_A12B9C8D13
        from bccc.ta.ta_A12B9C8D14 import ta_A12B9C8D14
        from bccc.ta.ta_A12B9C9D11 import ta_A12B9C9D11
        from bccc.ta.ta_A12B9C9D12 import ta_A12B9C9D12
        from bccc.ta.ta_A12B9C10D11 import ta_A12B9C10D11
        from bccc.ta.ta_A12B9C10D12 import ta_A12B9C10D12
        from bccc.ta.ta_A12B9C11D9 import ta_A12B9C11D9
        from bccc.ta.ta_A12B9C11D10 import ta_A12B9C11D10
        from bccc.ta.ta_A12B9C12D9 import ta_A12B9C12D9
        from bccc.ta.ta_A12B9C12D10 import ta_A12B9C12D10
        from bccc.ta.ta_A12B9C13D7 import ta_A12B9C13D7
        from bccc.ta.ta_A12B9C13D8 import ta_A12B9C13D8
        from bccc.ta.ta_A12B9C14D7 import ta_A12B9C14D7
        from bccc.ta.ta_A12B9C14D8 import ta_A12B9C14D8
        from bccc.ta.ta_A12B9C15D6 import ta_A12B9C15D6
        from bccc.ta.ta_A12B10C1D1 import ta_A12B10C1D1
        from bccc.ta.ta_A12B10C1D2 import ta_A12B10C1D2
        from bccc.ta.ta_A12B10C1D3 import ta_A12B10C1D3
        from bccc.ta.ta_A12B10C2D1 import ta_A12B10C2D1
        from bccc.ta.ta_A12B10C2D2 import ta_A12B10C2D2
        from bccc.ta.ta_A12B10C2D3 import ta_A12B10C2D3
        from bccc.ta.ta_A12B10C3D1 import ta_A12B10C3D1
        from bccc.ta.ta_A12B10C3D2 import ta_A12B10C3D2
        from bccc.ta.ta_A12B10C3D3 import ta_A12B10C3D3
        from bccc.ta.ta_A12B10C4D5 import ta_A12B10C4D5
        from bccc.ta.ta_A12B10C5D4 import ta_A12B10C5D4
        from bccc.ta.ta_A12B10C6D15 import ta_A12B10C6D15
        from bccc.ta.ta_A12B10C7D13 import ta_A12B10C7D13
        from bccc.ta.ta_A12B10C7D14 import ta_A12B10C7D14
        from bccc.ta.ta_A12B10C8D13 import ta_A12B10C8D13
        from bccc.ta.ta_A12B10C8D14 import ta_A12B10C8D14
        from bccc.ta.ta_A12B10C9D11 import ta_A12B10C9D11
        from bccc.ta.ta_A12B10C9D12 import ta_A12B10C9D12
        from bccc.ta.ta_A12B10C10D11 import ta_A12B10C10D11
        from bccc.ta.ta_A12B10C10D12 import ta_A12B10C10D12
        from bccc.ta.ta_A12B10C11D9 import ta_A12B10C11D9
        from bccc.ta.ta_A12B10C11D10 import ta_A12B10C11D10
        from bccc.ta.ta_A12B10C12D9 import ta_A12B10C12D9
        from bccc.ta.ta_A12B10C12D10 import ta_A12B10C12D10
        from bccc.ta.ta_A12B10C13D7 import ta_A12B10C13D7
        from bccc.ta.ta_A12B10C13D8 import ta_A12B10C13D8
        from bccc.ta.ta_A12B10C14D7 import ta_A12B10C14D7
        from bccc.ta.ta_A12B10C14D8 import ta_A12B10C14D8
        from bccc.ta.ta_A12B10C15D6 import ta_A12B10C15D6
        from bccc.ta.ta_A12B11C5D6 import ta_A12B11C5D6
        from bccc.ta.ta_A12B11C6D5 import ta_A12B11C6D5
        from bccc.ta.ta_A12B11C9D9 import ta_A12B11C9D9
        from bccc.ta.ta_A12B11C9D10 import ta_A12B11C9D10
        from bccc.ta.ta_A12B11C10D9 import ta_A12B11C10D9
        from bccc.ta.ta_A12B11C10D10 import ta_A12B11C10D10
        from bccc.ta.ta_A12B12C5D6 import ta_A12B12C5D6
        from bccc.ta.ta_A12B12C6D5 import ta_A12B12C6D5
        from bccc.ta.ta_A12B12C9D9 import ta_A12B12C9D9
        from bccc.ta.ta_A12B12C9D10 import ta_A12B12C9D10
        from bccc.ta.ta_A12B12C10D9 import ta_A12B12C10D9
        from bccc.ta.ta_A12B12C10D10 import ta_A12B12C10D10
        from bccc.ta.ta_A12B13C1D6 import ta_A12B13C1D6
        from bccc.ta.ta_A12B13C2D6 import ta_A12B13C2D6
        from bccc.ta.ta_A12B13C3D6 import ta_A12B13C3D6
        from bccc.ta.ta_A12B13C6D1 import ta_A12B13C6D1
        from bccc.ta.ta_A12B13C6D2 import ta_A12B13C6D2
        from bccc.ta.ta_A12B13C6D3 import ta_A12B13C6D3
        from bccc.ta.ta_A12B13C7D9 import ta_A12B13C7D9
        from bccc.ta.ta_A12B13C7D10 import ta_A12B13C7D10
        from bccc.ta.ta_A12B13C8D9 import ta_A12B13C8D9
        from bccc.ta.ta_A12B13C8D10 import ta_A12B13C8D10
        from bccc.ta.ta_A12B13C9D7 import ta_A12B13C9D7
        from bccc.ta.ta_A12B13C9D8 import ta_A12B13C9D8
        from bccc.ta.ta_A12B13C10D7 import ta_A12B13C10D7
        from bccc.ta.ta_A12B13C10D8 import ta_A12B13C10D8
        from bccc.ta.ta_A12B14C1D6 import ta_A12B14C1D6
        from bccc.ta.ta_A12B14C2D6 import ta_A12B14C2D6
        from bccc.ta.ta_A12B14C3D6 import ta_A12B14C3D6
        from bccc.ta.ta_A12B14C6D1 import ta_A12B14C6D1
        from bccc.ta.ta_A12B14C6D2 import ta_A12B14C6D2
        from bccc.ta.ta_A12B14C6D3 import ta_A12B14C6D3
        from bccc.ta.ta_A12B14C7D9 import ta_A12B14C7D9
        from bccc.ta.ta_A12B14C7D10 import ta_A12B14C7D10
        from bccc.ta.ta_A12B14C8D9 import ta_A12B14C8D9
        from bccc.ta.ta_A12B14C8D10 import ta_A12B14C8D10
        from bccc.ta.ta_A12B14C9D7 import ta_A12B14C9D7
        from bccc.ta.ta_A12B14C9D8 import ta_A12B14C9D8
        from bccc.ta.ta_A12B14C10D7 import ta_A12B14C10D7
        from bccc.ta.ta_A12B14C10D8 import ta_A12B14C10D8
        from bccc.ta.ta_A12B15C6D9 import ta_A12B15C6D9
        from bccc.ta.ta_A12B15C6D10 import ta_A12B15C6D10
        from bccc.ta.ta_A12B15C9D6 import ta_A12B15C9D6
        from bccc.ta.ta_A12B15C10D6 import ta_A12B15C10D6
        from bccc.ta.ta_A13B1C1D7 import ta_A13B1C1D7
        from bccc.ta.ta_A13B1C1D8 import ta_A13B1C1D8
        from bccc.ta.ta_A13B1C2D7 import ta_A13B1C2D7
        from bccc.ta.ta_A13B1C2D8 import ta_A13B1C2D8
        from bccc.ta.ta_A13B1C3D7 import ta_A13B1C3D7
        from bccc.ta.ta_A13B1C3D8 import ta_A13B1C3D8
        from bccc.ta.ta_A13B1C4D9 import ta_A13B1C4D9
        from bccc.ta.ta_A13B1C4D10 import ta_A13B1C4D10
        from bccc.ta.ta_A13B1C6D11 import ta_A13B1C6D11
        from bccc.ta.ta_A13B1C6D12 import ta_A13B1C6D12
        from bccc.ta.ta_A13B1C7D1 import ta_A13B1C7D1
        from bccc.ta.ta_A13B1C7D2 import ta_A13B1C7D2
        from bccc.ta.ta_A13B1C7D3 import ta_A13B1C7D3
        from bccc.ta.ta_A13B1C8D1 import ta_A13B1C8D1
        from bccc.ta.ta_A13B1C8D2 import ta_A13B1C8D2
        from bccc.ta.ta_A13B1C8D3 import ta_A13B1C8D3
        from bccc.ta.ta_A13B1C9D4 import ta_A13B1C9D4
        from bccc.ta.ta_A13B1C10D4 import ta_A13B1C10D4
        from bccc.ta.ta_A13B1C11D6 import ta_A13B1C11D6
        from bccc.ta.ta_A13B1C12D6 import ta_A13B1C12D6
        from bccc.ta.ta_A13B2C1D7 import ta_A13B2C1D7
        from bccc.ta.ta_A13B2C1D8 import ta_A13B2C1D8
        from bccc.ta.ta_A13B2C2D7 import ta_A13B2C2D7
        from bccc.ta.ta_A13B2C2D8 import ta_A13B2C2D8
        from bccc.ta.ta_A13B2C3D7 import ta_A13B2C3D7
        from bccc.ta.ta_A13B2C3D8 import ta_A13B2C3D8
        from bccc.ta.ta_A13B2C4D9 import ta_A13B2C4D9
        from bccc.ta.ta_A13B2C4D10 import ta_A13B2C4D10
        from bccc.ta.ta_A13B2C6D11 import ta_A13B2C6D11
        from bccc.ta.ta_A13B2C6D12 import ta_A13B2C6D12
        from bccc.ta.ta_A13B2C7D1 import ta_A13B2C7D1
        from bccc.ta.ta_A13B2C7D2 import ta_A13B2C7D2
        from bccc.ta.ta_A13B2C7D3 import ta_A13B2C7D3
        from bccc.ta.ta_A13B2C8D1 import ta_A13B2C8D1
        from bccc.ta.ta_A13B2C8D2 import ta_A13B2C8D2
        from bccc.ta.ta_A13B2C8D3 import ta_A13B2C8D3
        from bccc.ta.ta_A13B2C9D4 import ta_A13B2C9D4
        from bccc.ta.ta_A13B2C10D4 import ta_A13B2C10D4
        from bccc.ta.ta_A13B2C11D6 import ta_A13B2C11D6
        from bccc.ta.ta_A13B2C12D6 import ta_A13B2C12D6
        from bccc.ta.ta_A13B3C1D7 import ta_A13B3C1D7
        from bccc.ta.ta_A13B3C1D8 import ta_A13B3C1D8
        from bccc.ta.ta_A13B3C2D7 import ta_A13B3C2D7
        from bccc.ta.ta_A13B3C2D8 import ta_A13B3C2D8
        from bccc.ta.ta_A13B3C3D7 import ta_A13B3C3D7
        from bccc.ta.ta_A13B3C3D8 import ta_A13B3C3D8
        from bccc.ta.ta_A13B3C4D9 import ta_A13B3C4D9
        from bccc.ta.ta_A13B3C4D10 import ta_A13B3C4D10
        from bccc.ta.ta_A13B3C6D11 import ta_A13B3C6D11
        from bccc.ta.ta_A13B3C6D12 import ta_A13B3C6D12
        from bccc.ta.ta_A13B3C7D1 import ta_A13B3C7D1
        from bccc.ta.ta_A13B3C7D2 import ta_A13B3C7D2
        from bccc.ta.ta_A13B3C7D3 import ta_A13B3C7D3
        from bccc.ta.ta_A13B3C8D1 import ta_A13B3C8D1
        from bccc.ta.ta_A13B3C8D2 import ta_A13B3C8D2
        from bccc.ta.ta_A13B3C8D3 import ta_A13B3C8D3
        from bccc.ta.ta_A13B3C9D4 import ta_A13B3C9D4
        from bccc.ta.ta_A13B3C10D4 import ta_A13B3C10D4
        from bccc.ta.ta_A13B3C11D6 import ta_A13B3C11D6
        from bccc.ta.ta_A13B3C12D6 import ta_A13B3C12D6
        from bccc.ta.ta_A13B4C1D9 import ta_A13B4C1D9
        from bccc.ta.ta_A13B4C1D10 import ta_A13B4C1D10
        from bccc.ta.ta_A13B4C2D9 import ta_A13B4C2D9
        from bccc.ta.ta_A13B4C2D10 import ta_A13B4C2D10
        from bccc.ta.ta_A13B4C3D9 import ta_A13B4C3D9
        from bccc.ta.ta_A13B4C3D10 import ta_A13B4C3D10
        from bccc.ta.ta_A13B4C5D7 import ta_A13B4C5D7
        from bccc.ta.ta_A13B4C5D8 import ta_A13B4C5D8
        from bccc.ta.ta_A13B4C6D13 import ta_A13B4C6D13
        from bccc.ta.ta_A13B4C6D14 import ta_A13B4C6D14
        from bccc.ta.ta_A13B4C7D5 import ta_A13B4C7D5
        from bccc.ta.ta_A13B4C8D5 import ta_A13B4C8D5
        from bccc.ta.ta_A13B4C9D1 import ta_A13B4C9D1
        from bccc.ta.ta_A13B4C9D2 import ta_A13B4C9D2
        from bccc.ta.ta_A13B4C9D3 import ta_A13B4C9D3
        from bccc.ta.ta_A13B4C10D1 import ta_A13B4C10D1
        from bccc.ta.ta_A13B4C10D2 import ta_A13B4C10D2
        from bccc.ta.ta_A13B4C10D3 import ta_A13B4C10D3
        from bccc.ta.ta_A13B4C13D6 import ta_A13B4C13D6
        from bccc.ta.ta_A13B4C14D6 import ta_A13B4C14D6
        from bccc.ta.ta_A13B5C4D7 import ta_A13B5C4D7
        from bccc.ta.ta_A13B5C4D8 import ta_A13B5C4D8
        from bccc.ta.ta_A13B5C7D4 import ta_A13B5C7D4
        from bccc.ta.ta_A13B5C8D4 import ta_A13B5C8D4
        from bccc.ta.ta_A13B6C1D11 import ta_A13B6C1D11
        from bccc.ta.ta_A13B6C1D12 import ta_A13B6C1D12
        from bccc.ta.ta_A13B6C2D11 import ta_A13B6C2D11
        from bccc.ta.ta_A13B6C2D12 import ta_A13B6C2D12
        from bccc.ta.ta_A13B6C3D11 import ta_A13B6C3D11
        from bccc.ta.ta_A13B6C3D12 import ta_A13B6C3D12
        from bccc.ta.ta_A13B6C4D13 import ta_A13B6C4D13
        from bccc.ta.ta_A13B6C4D14 import ta_A13B6C4D14
        from bccc.ta.ta_A13B6C7D15 import ta_A13B6C7D15
        from bccc.ta.ta_A13B6C8D15 import ta_A13B6C8D15
        from bccc.ta.ta_A13B6C11D1 import ta_A13B6C11D1
        from bccc.ta.ta_A13B6C11D2 import ta_A13B6C11D2
        from bccc.ta.ta_A13B6C11D3 import ta_A13B6C11D3
        from bccc.ta.ta_A13B6C12D1 import ta_A13B6C12D1
        from bccc.ta.ta_A13B6C12D2 import ta_A13B6C12D2
        from bccc.ta.ta_A13B6C12D3 import ta_A13B6C12D3
        from bccc.ta.ta_A13B6C13D4 import ta_A13B6C13D4
        from bccc.ta.ta_A13B6C14D4 import ta_A13B6C14D4
        from bccc.ta.ta_A13B6C15D7 import ta_A13B6C15D7
        from bccc.ta.ta_A13B6C15D8 import ta_A13B6C15D8
        from bccc.ta.ta_A13B7C1D1 import ta_A13B7C1D1
        from bccc.ta.ta_A13B7C1D2 import ta_A13B7C1D2
        from bccc.ta.ta_A13B7C1D3 import ta_A13B7C1D3
        from bccc.ta.ta_A13B7C2D1 import ta_A13B7C2D1
        from bccc.ta.ta_A13B7C2D2 import ta_A13B7C2D2
        from bccc.ta.ta_A13B7C2D3 import ta_A13B7C2D3
        from bccc.ta.ta_A13B7C3D1 import ta_A13B7C3D1
        from bccc.ta.ta_A13B7C3D2 import ta_A13B7C3D2
        from bccc.ta.ta_A13B7C3D3 import ta_A13B7C3D3
        from bccc.ta.ta_A13B7C4D5 import ta_A13B7C4D5
        from bccc.ta.ta_A13B7C5D4 import ta_A13B7C5D4
        from bccc.ta.ta_A13B7C6D15 import ta_A13B7C6D15
        from bccc.ta.ta_A13B7C7D13 import ta_A13B7C7D13
        from bccc.ta.ta_A13B7C7D14 import ta_A13B7C7D14
        from bccc.ta.ta_A13B7C8D13 import ta_A13B7C8D13
        from bccc.ta.ta_A13B7C8D14 import ta_A13B7C8D14
        from bccc.ta.ta_A13B7C9D11 import ta_A13B7C9D11
        from bccc.ta.ta_A13B7C9D12 import ta_A13B7C9D12
        from bccc.ta.ta_A13B7C10D11 import ta_A13B7C10D11
        from bccc.ta.ta_A13B7C10D12 import ta_A13B7C10D12
        from bccc.ta.ta_A13B7C11D9 import ta_A13B7C11D9
        from bccc.ta.ta_A13B7C11D10 import ta_A13B7C11D10
        from bccc.ta.ta_A13B7C12D9 import ta_A13B7C12D9
        from bccc.ta.ta_A13B7C12D10 import ta_A13B7C12D10
        from bccc.ta.ta_A13B7C13D7 import ta_A13B7C13D7
        from bccc.ta.ta_A13B7C13D8 import ta_A13B7C13D8
        from bccc.ta.ta_A13B7C14D7 import ta_A13B7C14D7
        from bccc.ta.ta_A13B7C14D8 import ta_A13B7C14D8
        from bccc.ta.ta_A13B7C15D6 import ta_A13B7C15D6
        from bccc.ta.ta_A13B8C1D1 import ta_A13B8C1D1
        from bccc.ta.ta_A13B8C1D2 import ta_A13B8C1D2
        from bccc.ta.ta_A13B8C1D3 import ta_A13B8C1D3
        from bccc.ta.ta_A13B8C2D1 import ta_A13B8C2D1
        from bccc.ta.ta_A13B8C2D2 import ta_A13B8C2D2
        from bccc.ta.ta_A13B8C2D3 import ta_A13B8C2D3
        from bccc.ta.ta_A13B8C3D1 import ta_A13B8C3D1
        from bccc.ta.ta_A13B8C3D2 import ta_A13B8C3D2
        from bccc.ta.ta_A13B8C3D3 import ta_A13B8C3D3
        from bccc.ta.ta_A13B8C4D5 import ta_A13B8C4D5
        from bccc.ta.ta_A13B8C5D4 import ta_A13B8C5D4
        from bccc.ta.ta_A13B8C6D15 import ta_A13B8C6D15
        from bccc.ta.ta_A13B8C7D13 import ta_A13B8C7D13
        from bccc.ta.ta_A13B8C7D14 import ta_A13B8C7D14
        from bccc.ta.ta_A13B8C8D13 import ta_A13B8C8D13
        from bccc.ta.ta_A13B8C8D14 import ta_A13B8C8D14
        from bccc.ta.ta_A13B8C9D11 import ta_A13B8C9D11
        from bccc.ta.ta_A13B8C9D12 import ta_A13B8C9D12
        from bccc.ta.ta_A13B8C10D11 import ta_A13B8C10D11
        from bccc.ta.ta_A13B8C10D12 import ta_A13B8C10D12
        from bccc.ta.ta_A13B8C11D9 import ta_A13B8C11D9
        from bccc.ta.ta_A13B8C11D10 import ta_A13B8C11D10
        from bccc.ta.ta_A13B8C12D9 import ta_A13B8C12D9
        from bccc.ta.ta_A13B8C12D10 import ta_A13B8C12D10
        from bccc.ta.ta_A13B8C13D7 import ta_A13B8C13D7
        from bccc.ta.ta_A13B8C13D8 import ta_A13B8C13D8
        from bccc.ta.ta_A13B8C14D7 import ta_A13B8C14D7
        from bccc.ta.ta_A13B8C14D8 import ta_A13B8C14D8
        from bccc.ta.ta_A13B8C15D6 import ta_A13B8C15D6
        from bccc.ta.ta_A13B9C1D4 import ta_A13B9C1D4
        from bccc.ta.ta_A13B9C2D4 import ta_A13B9C2D4
        from bccc.ta.ta_A13B9C3D4 import ta_A13B9C3D4
        from bccc.ta.ta_A13B9C4D1 import ta_A13B9C4D1
        from bccc.ta.ta_A13B9C4D2 import ta_A13B9C4D2
        from bccc.ta.ta_A13B9C4D3 import ta_A13B9C4D3
        from bccc.ta.ta_A13B9C7D11 import ta_A13B9C7D11
        from bccc.ta.ta_A13B9C7D12 import ta_A13B9C7D12
        from bccc.ta.ta_A13B9C8D11 import ta_A13B9C8D11
        from bccc.ta.ta_A13B9C8D12 import ta_A13B9C8D12
        from bccc.ta.ta_A13B9C11D7 import ta_A13B9C11D7
        from bccc.ta.ta_A13B9C11D8 import ta_A13B9C11D8
        from bccc.ta.ta_A13B9C12D7 import ta_A13B9C12D7
        from bccc.ta.ta_A13B9C12D8 import ta_A13B9C12D8
        from bccc.ta.ta_A13B10C1D4 import ta_A13B10C1D4
        from bccc.ta.ta_A13B10C2D4 import ta_A13B10C2D4
        from bccc.ta.ta_A13B10C3D4 import ta_A13B10C3D4
        from bccc.ta.ta_A13B10C4D1 import ta_A13B10C4D1
        from bccc.ta.ta_A13B10C4D2 import ta_A13B10C4D2
        from bccc.ta.ta_A13B10C4D3 import ta_A13B10C4D3
        from bccc.ta.ta_A13B10C7D11 import ta_A13B10C7D11
        from bccc.ta.ta_A13B10C7D12 import ta_A13B10C7D12
        from bccc.ta.ta_A13B10C8D11 import ta_A13B10C8D11
        from bccc.ta.ta_A13B10C8D12 import ta_A13B10C8D12
        from bccc.ta.ta_A13B10C11D7 import ta_A13B10C11D7
        from bccc.ta.ta_A13B10C11D8 import ta_A13B10C11D8
        from bccc.ta.ta_A13B10C12D7 import ta_A13B10C12D7
        from bccc.ta.ta_A13B10C12D8 import ta_A13B10C12D8
        from bccc.ta.ta_A13B11C1D6 import ta_A13B11C1D6
        from bccc.ta.ta_A13B11C2D6 import ta_A13B11C2D6
        from bccc.ta.ta_A13B11C3D6 import ta_A13B11C3D6
        from bccc.ta.ta_A13B11C6D1 import ta_A13B11C6D1
        from bccc.ta.ta_A13B11C6D2 import ta_A13B11C6D2
        from bccc.ta.ta_A13B11C6D3 import ta_A13B11C6D3
        from bccc.ta.ta_A13B11C7D9 import ta_A13B11C7D9
        from bccc.ta.ta_A13B11C7D10 import ta_A13B11C7D10
        from bccc.ta.ta_A13B11C8D9 import ta_A13B11C8D9
        from bccc.ta.ta_A13B11C8D10 import ta_A13B11C8D10
        from bccc.ta.ta_A13B11C9D7 import ta_A13B11C9D7
        from bccc.ta.ta_A13B11C9D8 import ta_A13B11C9D8
        from bccc.ta.ta_A13B11C10D7 import ta_A13B11C10D7
        from bccc.ta.ta_A13B11C10D8 import ta_A13B11C10D8
        from bccc.ta.ta_A13B12C1D6 import ta_A13B12C1D6
        from bccc.ta.ta_A13B12C2D6 import ta_A13B12C2D6
        from bccc.ta.ta_A13B12C3D6 import ta_A13B12C3D6
        from bccc.ta.ta_A13B12C6D1 import ta_A13B12C6D1
        from bccc.ta.ta_A13B12C6D2 import ta_A13B12C6D2
        from bccc.ta.ta_A13B12C6D3 import ta_A13B12C6D3
        from bccc.ta.ta_A13B12C7D9 import ta_A13B12C7D9
        from bccc.ta.ta_A13B12C7D10 import ta_A13B12C7D10
        from bccc.ta.ta_A13B12C8D9 import ta_A13B12C8D9
        from bccc.ta.ta_A13B12C8D10 import ta_A13B12C8D10
        from bccc.ta.ta_A13B12C9D7 import ta_A13B12C9D7
        from bccc.ta.ta_A13B12C9D8 import ta_A13B12C9D8
        from bccc.ta.ta_A13B12C10D7 import ta_A13B12C10D7
        from bccc.ta.ta_A13B12C10D8 import ta_A13B12C10D8
        from bccc.ta.ta_A13B13C4D6 import ta_A13B13C4D6
        from bccc.ta.ta_A13B13C6D4 import ta_A13B13C6D4
        from bccc.ta.ta_A13B13C7D7 import ta_A13B13C7D7
        from bccc.ta.ta_A13B13C7D8 import ta_A13B13C7D8
        from bccc.ta.ta_A13B13C8D7 import ta_A13B13C8D7
        from bccc.ta.ta_A13B13C8D8 import ta_A13B13C8D8
        from bccc.ta.ta_A13B14C4D6 import ta_A13B14C4D6
        from bccc.ta.ta_A13B14C6D4 import ta_A13B14C6D4
        from bccc.ta.ta_A13B14C7D7 import ta_A13B14C7D7
        from bccc.ta.ta_A13B14C7D8 import ta_A13B14C7D8
        from bccc.ta.ta_A13B14C8D7 import ta_A13B14C8D7
        from bccc.ta.ta_A13B14C8D8 import ta_A13B14C8D8
        from bccc.ta.ta_A13B15C6D7 import ta_A13B15C6D7
        from bccc.ta.ta_A13B15C6D8 import ta_A13B15C6D8
        from bccc.ta.ta_A13B15C7D6 import ta_A13B15C7D6
        from bccc.ta.ta_A13B15C8D6 import ta_A13B15C8D6
        from bccc.ta.ta_A14B1C1D7 import ta_A14B1C1D7
        from bccc.ta.ta_A14B1C1D8 import ta_A14B1C1D8
        from bccc.ta.ta_A14B1C2D7 import ta_A14B1C2D7
        from bccc.ta.ta_A14B1C2D8 import ta_A14B1C2D8
        from bccc.ta.ta_A14B1C3D7 import ta_A14B1C3D7
        from bccc.ta.ta_A14B1C3D8 import ta_A14B1C3D8
        from bccc.ta.ta_A14B1C4D9 import ta_A14B1C4D9
        from bccc.ta.ta_A14B1C4D10 import ta_A14B1C4D10
        from bccc.ta.ta_A14B1C6D11 import ta_A14B1C6D11
        from bccc.ta.ta_A14B1C6D12 import ta_A14B1C6D12
        from bccc.ta.ta_A14B1C7D1 import ta_A14B1C7D1
        from bccc.ta.ta_A14B1C7D2 import ta_A14B1C7D2
        from bccc.ta.ta_A14B1C7D3 import ta_A14B1C7D3
        from bccc.ta.ta_A14B1C8D1 import ta_A14B1C8D1
        from bccc.ta.ta_A14B1C8D2 import ta_A14B1C8D2
        from bccc.ta.ta_A14B1C8D3 import ta_A14B1C8D3
        from bccc.ta.ta_A14B1C9D4 import ta_A14B1C9D4
        from bccc.ta.ta_A14B1C10D4 import ta_A14B1C10D4
        from bccc.ta.ta_A14B1C11D6 import ta_A14B1C11D6
        from bccc.ta.ta_A14B1C12D6 import ta_A14B1C12D6
        from bccc.ta.ta_A14B2C1D7 import ta_A14B2C1D7
        from bccc.ta.ta_A14B2C1D8 import ta_A14B2C1D8
        from bccc.ta.ta_A14B2C2D7 import ta_A14B2C2D7
        from bccc.ta.ta_A14B2C2D8 import ta_A14B2C2D8
        from bccc.ta.ta_A14B2C3D7 import ta_A14B2C3D7
        from bccc.ta.ta_A14B2C3D8 import ta_A14B2C3D8
        from bccc.ta.ta_A14B2C4D9 import ta_A14B2C4D9
        from bccc.ta.ta_A14B2C4D10 import ta_A14B2C4D10
        from bccc.ta.ta_A14B2C6D11 import ta_A14B2C6D11
        from bccc.ta.ta_A14B2C6D12 import ta_A14B2C6D12
        from bccc.ta.ta_A14B2C7D1 import ta_A14B2C7D1
        from bccc.ta.ta_A14B2C7D2 import ta_A14B2C7D2
        from bccc.ta.ta_A14B2C7D3 import ta_A14B2C7D3
        from bccc.ta.ta_A14B2C8D1 import ta_A14B2C8D1
        from bccc.ta.ta_A14B2C8D2 import ta_A14B2C8D2
        from bccc.ta.ta_A14B2C8D3 import ta_A14B2C8D3
        from bccc.ta.ta_A14B2C9D4 import ta_A14B2C9D4
        from bccc.ta.ta_A14B2C10D4 import ta_A14B2C10D4
        from bccc.ta.ta_A14B2C11D6 import ta_A14B2C11D6
        from bccc.ta.ta_A14B2C12D6 import ta_A14B2C12D6
        from bccc.ta.ta_A14B3C1D7 import ta_A14B3C1D7
        from bccc.ta.ta_A14B3C1D8 import ta_A14B3C1D8
        from bccc.ta.ta_A14B3C2D7 import ta_A14B3C2D7
        from bccc.ta.ta_A14B3C2D8 import ta_A14B3C2D8
        from bccc.ta.ta_A14B3C3D7 import ta_A14B3C3D7
        from bccc.ta.ta_A14B3C3D8 import ta_A14B3C3D8
        from bccc.ta.ta_A14B3C4D9 import ta_A14B3C4D9
        from bccc.ta.ta_A14B3C4D10 import ta_A14B3C4D10
        from bccc.ta.ta_A14B3C6D11 import ta_A14B3C6D11
        from bccc.ta.ta_A14B3C6D12 import ta_A14B3C6D12
        from bccc.ta.ta_A14B3C7D1 import ta_A14B3C7D1
        from bccc.ta.ta_A14B3C7D2 import ta_A14B3C7D2
        from bccc.ta.ta_A14B3C7D3 import ta_A14B3C7D3
        from bccc.ta.ta_A14B3C8D1 import ta_A14B3C8D1
        from bccc.ta.ta_A14B3C8D2 import ta_A14B3C8D2
        from bccc.ta.ta_A14B3C8D3 import ta_A14B3C8D3
        from bccc.ta.ta_A14B3C9D4 import ta_A14B3C9D4
        from bccc.ta.ta_A14B3C10D4 import ta_A14B3C10D4
        from bccc.ta.ta_A14B3C11D6 import ta_A14B3C11D6
        from bccc.ta.ta_A14B3C12D6 import ta_A14B3C12D6
        from bccc.ta.ta_A14B4C1D9 import ta_A14B4C1D9
        from bccc.ta.ta_A14B4C1D10 import ta_A14B4C1D10
        from bccc.ta.ta_A14B4C2D9 import ta_A14B4C2D9
        from bccc.ta.ta_A14B4C2D10 import ta_A14B4C2D10
        from bccc.ta.ta_A14B4C3D9 import ta_A14B4C3D9
        from bccc.ta.ta_A14B4C3D10 import ta_A14B4C3D10
        from bccc.ta.ta_A14B4C5D7 import ta_A14B4C5D7
        from bccc.ta.ta_A14B4C5D8 import ta_A14B4C5D8
        from bccc.ta.ta_A14B4C6D13 import ta_A14B4C6D13
        from bccc.ta.ta_A14B4C6D14 import ta_A14B4C6D14
        from bccc.ta.ta_A14B4C7D5 import ta_A14B4C7D5
        from bccc.ta.ta_A14B4C8D5 import ta_A14B4C8D5
        from bccc.ta.ta_A14B4C9D1 import ta_A14B4C9D1
        from bccc.ta.ta_A14B4C9D2 import ta_A14B4C9D2
        from bccc.ta.ta_A14B4C9D3 import ta_A14B4C9D3
        from bccc.ta.ta_A14B4C10D1 import ta_A14B4C10D1
        from bccc.ta.ta_A14B4C10D2 import ta_A14B4C10D2
        from bccc.ta.ta_A14B4C10D3 import ta_A14B4C10D3
        from bccc.ta.ta_A14B4C13D6 import ta_A14B4C13D6
        from bccc.ta.ta_A14B4C14D6 import ta_A14B4C14D6
        from bccc.ta.ta_A14B5C4D7 import ta_A14B5C4D7
        from bccc.ta.ta_A14B5C4D8 import ta_A14B5C4D8
        from bccc.ta.ta_A14B5C7D4 import ta_A14B5C7D4
        from bccc.ta.ta_A14B5C8D4 import ta_A14B5C8D4
        from bccc.ta.ta_A14B6C1D11 import ta_A14B6C1D11
        from bccc.ta.ta_A14B6C1D12 import ta_A14B6C1D12
        from bccc.ta.ta_A14B6C2D11 import ta_A14B6C2D11
        from bccc.ta.ta_A14B6C2D12 import ta_A14B6C2D12
        from bccc.ta.ta_A14B6C3D11 import ta_A14B6C3D11
        from bccc.ta.ta_A14B6C3D12 import ta_A14B6C3D12
        from bccc.ta.ta_A14B6C4D13 import ta_A14B6C4D13
        from bccc.ta.ta_A14B6C4D14 import ta_A14B6C4D14
        from bccc.ta.ta_A14B6C7D15 import ta_A14B6C7D15
        from bccc.ta.ta_A14B6C8D15 import ta_A14B6C8D15
        from bccc.ta.ta_A14B6C11D1 import ta_A14B6C11D1
        from bccc.ta.ta_A14B6C11D2 import ta_A14B6C11D2
        from bccc.ta.ta_A14B6C11D3 import ta_A14B6C11D3
        from bccc.ta.ta_A14B6C12D1 import ta_A14B6C12D1
        from bccc.ta.ta_A14B6C12D2 import ta_A14B6C12D2
        from bccc.ta.ta_A14B6C12D3 import ta_A14B6C12D3
        from bccc.ta.ta_A14B6C13D4 import ta_A14B6C13D4
        from bccc.ta.ta_A14B6C14D4 import ta_A14B6C14D4
        from bccc.ta.ta_A14B6C15D7 import ta_A14B6C15D7
        from bccc.ta.ta_A14B6C15D8 import ta_A14B6C15D8
        from bccc.ta.ta_A14B7C1D1 import ta_A14B7C1D1
        from bccc.ta.ta_A14B7C1D2 import ta_A14B7C1D2
        from bccc.ta.ta_A14B7C1D3 import ta_A14B7C1D3
        from bccc.ta.ta_A14B7C2D1 import ta_A14B7C2D1
        from bccc.ta.ta_A14B7C2D2 import ta_A14B7C2D2
        from bccc.ta.ta_A14B7C2D3 import ta_A14B7C2D3
        from bccc.ta.ta_A14B7C3D1 import ta_A14B7C3D1
        from bccc.ta.ta_A14B7C3D2 import ta_A14B7C3D2
        from bccc.ta.ta_A14B7C3D3 import ta_A14B7C3D3
        from bccc.ta.ta_A14B7C4D5 import ta_A14B7C4D5
        from bccc.ta.ta_A14B7C5D4 import ta_A14B7C5D4
        from bccc.ta.ta_A14B7C6D15 import ta_A14B7C6D15
        from bccc.ta.ta_A14B7C7D13 import ta_A14B7C7D13
        from bccc.ta.ta_A14B7C7D14 import ta_A14B7C7D14
        from bccc.ta.ta_A14B7C8D13 import ta_A14B7C8D13
        from bccc.ta.ta_A14B7C8D14 import ta_A14B7C8D14
        from bccc.ta.ta_A14B7C9D11 import ta_A14B7C9D11
        from bccc.ta.ta_A14B7C9D12 import ta_A14B7C9D12
        from bccc.ta.ta_A14B7C10D11 import ta_A14B7C10D11
        from bccc.ta.ta_A14B7C10D12 import ta_A14B7C10D12
        from bccc.ta.ta_A14B7C11D9 import ta_A14B7C11D9
        from bccc.ta.ta_A14B7C11D10 import ta_A14B7C11D10
        from bccc.ta.ta_A14B7C12D9 import ta_A14B7C12D9
        from bccc.ta.ta_A14B7C12D10 import ta_A14B7C12D10
        from bccc.ta.ta_A14B7C13D7 import ta_A14B7C13D7
        from bccc.ta.ta_A14B7C13D8 import ta_A14B7C13D8
        from bccc.ta.ta_A14B7C14D7 import ta_A14B7C14D7
        from bccc.ta.ta_A14B7C14D8 import ta_A14B7C14D8
        from bccc.ta.ta_A14B7C15D6 import ta_A14B7C15D6
        from bccc.ta.ta_A14B8C1D1 import ta_A14B8C1D1
        from bccc.ta.ta_A14B8C1D2 import ta_A14B8C1D2
        from bccc.ta.ta_A14B8C1D3 import ta_A14B8C1D3
        from bccc.ta.ta_A14B8C2D1 import ta_A14B8C2D1
        from bccc.ta.ta_A14B8C2D2 import ta_A14B8C2D2
        from bccc.ta.ta_A14B8C2D3 import ta_A14B8C2D3
        from bccc.ta.ta_A14B8C3D1 import ta_A14B8C3D1
        from bccc.ta.ta_A14B8C3D2 import ta_A14B8C3D2
        from bccc.ta.ta_A14B8C3D3 import ta_A14B8C3D3
        from bccc.ta.ta_A14B8C4D5 import ta_A14B8C4D5
        from bccc.ta.ta_A14B8C5D4 import ta_A14B8C5D4
        from bccc.ta.ta_A14B8C6D15 import ta_A14B8C6D15
        from bccc.ta.ta_A14B8C7D13 import ta_A14B8C7D13
        from bccc.ta.ta_A14B8C7D14 import ta_A14B8C7D14
        from bccc.ta.ta_A14B8C8D13 import ta_A14B8C8D13
        from bccc.ta.ta_A14B8C8D14 import ta_A14B8C8D14
        from bccc.ta.ta_A14B8C9D11 import ta_A14B8C9D11
        from bccc.ta.ta_A14B8C9D12 import ta_A14B8C9D12
        from bccc.ta.ta_A14B8C10D11 import ta_A14B8C10D11
        from bccc.ta.ta_A14B8C10D12 import ta_A14B8C10D12
        from bccc.ta.ta_A14B8C11D9 import ta_A14B8C11D9
        from bccc.ta.ta_A14B8C11D10 import ta_A14B8C11D10
        from bccc.ta.ta_A14B8C12D9 import ta_A14B8C12D9
        from bccc.ta.ta_A14B8C12D10 import ta_A14B8C12D10
        from bccc.ta.ta_A14B8C13D7 import ta_A14B8C13D7
        from bccc.ta.ta_A14B8C13D8 import ta_A14B8C13D8
        from bccc.ta.ta_A14B8C14D7 import ta_A14B8C14D7
        from bccc.ta.ta_A14B8C14D8 import ta_A14B8C14D8
        from bccc.ta.ta_A14B8C15D6 import ta_A14B8C15D6
        from bccc.ta.ta_A14B9C1D4 import ta_A14B9C1D4
        from bccc.ta.ta_A14B9C2D4 import ta_A14B9C2D4
        from bccc.ta.ta_A14B9C3D4 import ta_A14B9C3D4
        from bccc.ta.ta_A14B9C4D1 import ta_A14B9C4D1
        from bccc.ta.ta_A14B9C4D2 import ta_A14B9C4D2
        from bccc.ta.ta_A14B9C4D3 import ta_A14B9C4D3
        from bccc.ta.ta_A14B9C7D11 import ta_A14B9C7D11
        from bccc.ta.ta_A14B9C7D12 import ta_A14B9C7D12
        from bccc.ta.ta_A14B9C8D11 import ta_A14B9C8D11
        from bccc.ta.ta_A14B9C8D12 import ta_A14B9C8D12
        from bccc.ta.ta_A14B9C11D7 import ta_A14B9C11D7
        from bccc.ta.ta_A14B9C11D8 import ta_A14B9C11D8
        from bccc.ta.ta_A14B9C12D7 import ta_A14B9C12D7
        from bccc.ta.ta_A14B9C12D8 import ta_A14B9C12D8
        from bccc.ta.ta_A14B10C1D4 import ta_A14B10C1D4
        from bccc.ta.ta_A14B10C2D4 import ta_A14B10C2D4
        from bccc.ta.ta_A14B10C3D4 import ta_A14B10C3D4
        from bccc.ta.ta_A14B10C4D1 import ta_A14B10C4D1
        from bccc.ta.ta_A14B10C4D2 import ta_A14B10C4D2
        from bccc.ta.ta_A14B10C4D3 import ta_A14B10C4D3
        from bccc.ta.ta_A14B10C7D11 import ta_A14B10C7D11
        from bccc.ta.ta_A14B10C7D12 import ta_A14B10C7D12
        from bccc.ta.ta_A14B10C8D11 import ta_A14B10C8D11
        from bccc.ta.ta_A14B10C8D12 import ta_A14B10C8D12
        from bccc.ta.ta_A14B10C11D7 import ta_A14B10C11D7
        from bccc.ta.ta_A14B10C11D8 import ta_A14B10C11D8
        from bccc.ta.ta_A14B10C12D7 import ta_A14B10C12D7
        from bccc.ta.ta_A14B10C12D8 import ta_A14B10C12D8
        from bccc.ta.ta_A14B11C1D6 import ta_A14B11C1D6
        from bccc.ta.ta_A14B11C2D6 import ta_A14B11C2D6
        from bccc.ta.ta_A14B11C3D6 import ta_A14B11C3D6
        from bccc.ta.ta_A14B11C6D1 import ta_A14B11C6D1
        from bccc.ta.ta_A14B11C6D2 import ta_A14B11C6D2
        from bccc.ta.ta_A14B11C6D3 import ta_A14B11C6D3
        from bccc.ta.ta_A14B11C7D9 import ta_A14B11C7D9
        from bccc.ta.ta_A14B11C7D10 import ta_A14B11C7D10
        from bccc.ta.ta_A14B11C8D9 import ta_A14B11C8D9
        from bccc.ta.ta_A14B11C8D10 import ta_A14B11C8D10
        from bccc.ta.ta_A14B11C9D7 import ta_A14B11C9D7
        from bccc.ta.ta_A14B11C9D8 import ta_A14B11C9D8
        from bccc.ta.ta_A14B11C10D7 import ta_A14B11C10D7
        from bccc.ta.ta_A14B11C10D8 import ta_A14B11C10D8
        from bccc.ta.ta_A14B12C1D6 import ta_A14B12C1D6
        from bccc.ta.ta_A14B12C2D6 import ta_A14B12C2D6
        from bccc.ta.ta_A14B12C3D6 import ta_A14B12C3D6
        from bccc.ta.ta_A14B12C6D1 import ta_A14B12C6D1
        from bccc.ta.ta_A14B12C6D2 import ta_A14B12C6D2
        from bccc.ta.ta_A14B12C6D3 import ta_A14B12C6D3
        from bccc.ta.ta_A14B12C7D9 import ta_A14B12C7D9
        from bccc.ta.ta_A14B12C7D10 import ta_A14B12C7D10
        from bccc.ta.ta_A14B12C8D9 import ta_A14B12C8D9
        from bccc.ta.ta_A14B12C8D10 import ta_A14B12C8D10
        from bccc.ta.ta_A14B12C9D7 import ta_A14B12C9D7
        from bccc.ta.ta_A14B12C9D8 import ta_A14B12C9D8
        from bccc.ta.ta_A14B12C10D7 import ta_A14B12C10D7
        from bccc.ta.ta_A14B12C10D8 import ta_A14B12C10D8
        from bccc.ta.ta_A14B13C4D6 import ta_A14B13C4D6
        from bccc.ta.ta_A14B13C6D4 import ta_A14B13C6D4
        from bccc.ta.ta_A14B13C7D7 import ta_A14B13C7D7
        from bccc.ta.ta_A14B13C7D8 import ta_A14B13C7D8
        from bccc.ta.ta_A14B13C8D7 import ta_A14B13C8D7
        from bccc.ta.ta_A14B13C8D8 import ta_A14B13C8D8
        from bccc.ta.ta_A14B14C4D6 import ta_A14B14C4D6
        from bccc.ta.ta_A14B14C6D4 import ta_A14B14C6D4
        from bccc.ta.ta_A14B14C7D7 import ta_A14B14C7D7
        from bccc.ta.ta_A14B14C7D8 import ta_A14B14C7D8
        from bccc.ta.ta_A14B14C8D7 import ta_A14B14C8D7
        from bccc.ta.ta_A14B14C8D8 import ta_A14B14C8D8
        from bccc.ta.ta_A14B15C6D7 import ta_A14B15C6D7
        from bccc.ta.ta_A14B15C6D8 import ta_A14B15C6D8
        from bccc.ta.ta_A14B15C7D6 import ta_A14B15C7D6
        from bccc.ta.ta_A14B15C8D6 import ta_A14B15C8D6
        from bccc.ta.ta_A15B1C1D6 import ta_A15B1C1D6
        from bccc.ta.ta_A15B1C2D6 import ta_A15B1C2D6
        from bccc.ta.ta_A15B1C3D6 import ta_A15B1C3D6
        from bccc.ta.ta_A15B1C6D1 import ta_A15B1C6D1
        from bccc.ta.ta_A15B1C6D2 import ta_A15B1C6D2
        from bccc.ta.ta_A15B1C6D3 import ta_A15B1C6D3
        from bccc.ta.ta_A15B1C7D9 import ta_A15B1C7D9
        from bccc.ta.ta_A15B1C7D10 import ta_A15B1C7D10
        from bccc.ta.ta_A15B1C8D9 import ta_A15B1C8D9
        from bccc.ta.ta_A15B1C8D10 import ta_A15B1C8D10
        from bccc.ta.ta_A15B1C9D7 import ta_A15B1C9D7
        from bccc.ta.ta_A15B1C9D8 import ta_A15B1C9D8
        from bccc.ta.ta_A15B1C10D7 import ta_A15B1C10D7
        from bccc.ta.ta_A15B1C10D8 import ta_A15B1C10D8
        from bccc.ta.ta_A15B2C1D6 import ta_A15B2C1D6
        from bccc.ta.ta_A15B2C2D6 import ta_A15B2C2D6
        from bccc.ta.ta_A15B2C3D6 import ta_A15B2C3D6
        from bccc.ta.ta_A15B2C6D1 import ta_A15B2C6D1
        from bccc.ta.ta_A15B2C6D2 import ta_A15B2C6D2
        from bccc.ta.ta_A15B2C6D3 import ta_A15B2C6D3
        from bccc.ta.ta_A15B2C7D9 import ta_A15B2C7D9
        from bccc.ta.ta_A15B2C7D10 import ta_A15B2C7D10
        from bccc.ta.ta_A15B2C8D9 import ta_A15B2C8D9
        from bccc.ta.ta_A15B2C8D10 import ta_A15B2C8D10
        from bccc.ta.ta_A15B2C9D7 import ta_A15B2C9D7
        from bccc.ta.ta_A15B2C9D8 import ta_A15B2C9D8
        from bccc.ta.ta_A15B2C10D7 import ta_A15B2C10D7
        from bccc.ta.ta_A15B2C10D8 import ta_A15B2C10D8
        from bccc.ta.ta_A15B3C1D6 import ta_A15B3C1D6
        from bccc.ta.ta_A15B3C2D6 import ta_A15B3C2D6
        from bccc.ta.ta_A15B3C3D6 import ta_A15B3C3D6
        from bccc.ta.ta_A15B3C6D1 import ta_A15B3C6D1
        from bccc.ta.ta_A15B3C6D2 import ta_A15B3C6D2
        from bccc.ta.ta_A15B3C6D3 import ta_A15B3C6D3
        from bccc.ta.ta_A15B3C7D9 import ta_A15B3C7D9
        from bccc.ta.ta_A15B3C7D10 import ta_A15B3C7D10
        from bccc.ta.ta_A15B3C8D9 import ta_A15B3C8D9
        from bccc.ta.ta_A15B3C8D10 import ta_A15B3C8D10
        from bccc.ta.ta_A15B3C9D7 import ta_A15B3C9D7
        from bccc.ta.ta_A15B3C9D8 import ta_A15B3C9D8
        from bccc.ta.ta_A15B3C10D7 import ta_A15B3C10D7
        from bccc.ta.ta_A15B3C10D8 import ta_A15B3C10D8
        from bccc.ta.ta_A15B4C5D6 import ta_A15B4C5D6
        from bccc.ta.ta_A15B4C6D5 import ta_A15B4C6D5
        from bccc.ta.ta_A15B4C9D9 import ta_A15B4C9D9
        from bccc.ta.ta_A15B4C9D10 import ta_A15B4C9D10
        from bccc.ta.ta_A15B4C10D9 import ta_A15B4C10D9
        from bccc.ta.ta_A15B4C10D10 import ta_A15B4C10D10
        from bccc.ta.ta_A15B5C4D6 import ta_A15B5C4D6
        from bccc.ta.ta_A15B5C6D4 import ta_A15B5C6D4
        from bccc.ta.ta_A15B5C7D7 import ta_A15B5C7D7
        from bccc.ta.ta_A15B5C7D8 import ta_A15B5C7D8
        from bccc.ta.ta_A15B5C8D7 import ta_A15B5C8D7
        from bccc.ta.ta_A15B5C8D8 import ta_A15B5C8D8
        from bccc.ta.ta_A15B6C1D1 import ta_A15B6C1D1
        from bccc.ta.ta_A15B6C1D2 import ta_A15B6C1D2
        from bccc.ta.ta_A15B6C1D3 import ta_A15B6C1D3
        from bccc.ta.ta_A15B6C2D1 import ta_A15B6C2D1
        from bccc.ta.ta_A15B6C2D2 import ta_A15B6C2D2
        from bccc.ta.ta_A15B6C2D3 import ta_A15B6C2D3
        from bccc.ta.ta_A15B6C3D1 import ta_A15B6C3D1
        from bccc.ta.ta_A15B6C3D2 import ta_A15B6C3D2
        from bccc.ta.ta_A15B6C3D3 import ta_A15B6C3D3
        from bccc.ta.ta_A15B6C4D5 import ta_A15B6C4D5
        from bccc.ta.ta_A15B6C5D4 import ta_A15B6C5D4
        from bccc.ta.ta_A15B6C6D15 import ta_A15B6C6D15
        from bccc.ta.ta_A15B6C7D13 import ta_A15B6C7D13
        from bccc.ta.ta_A15B6C7D14 import ta_A15B6C7D14
        from bccc.ta.ta_A15B6C8D13 import ta_A15B6C8D13
        from bccc.ta.ta_A15B6C8D14 import ta_A15B6C8D14
        from bccc.ta.ta_A15B6C9D11 import ta_A15B6C9D11
        from bccc.ta.ta_A15B6C9D12 import ta_A15B6C9D12
        from bccc.ta.ta_A15B6C10D11 import ta_A15B6C10D11
        from bccc.ta.ta_A15B6C10D12 import ta_A15B6C10D12
        from bccc.ta.ta_A15B6C11D9 import ta_A15B6C11D9
        from bccc.ta.ta_A15B6C11D10 import ta_A15B6C11D10
        from bccc.ta.ta_A15B6C12D9 import ta_A15B6C12D9
        from bccc.ta.ta_A15B6C12D10 import ta_A15B6C12D10
        from bccc.ta.ta_A15B6C13D7 import ta_A15B6C13D7
        from bccc.ta.ta_A15B6C13D8 import ta_A15B6C13D8
        from bccc.ta.ta_A15B6C14D7 import ta_A15B6C14D7
        from bccc.ta.ta_A15B6C14D8 import ta_A15B6C14D8
        from bccc.ta.ta_A15B6C15D6 import ta_A15B6C15D6
        from bccc.ta.ta_A15B7C1D9 import ta_A15B7C1D9
        from bccc.ta.ta_A15B7C1D10 import ta_A15B7C1D10
        from bccc.ta.ta_A15B7C2D9 import ta_A15B7C2D9
        from bccc.ta.ta_A15B7C2D10 import ta_A15B7C2D10
        from bccc.ta.ta_A15B7C3D9 import ta_A15B7C3D9
        from bccc.ta.ta_A15B7C3D10 import ta_A15B7C3D10
        from bccc.ta.ta_A15B7C5D7 import ta_A15B7C5D7
        from bccc.ta.ta_A15B7C5D8 import ta_A15B7C5D8
        from bccc.ta.ta_A15B7C6D13 import ta_A15B7C6D13
        from bccc.ta.ta_A15B7C6D14 import ta_A15B7C6D14
        from bccc.ta.ta_A15B7C7D5 import ta_A15B7C7D5
        from bccc.ta.ta_A15B7C8D5 import ta_A15B7C8D5
        from bccc.ta.ta_A15B7C9D1 import ta_A15B7C9D1
        from bccc.ta.ta_A15B7C9D2 import ta_A15B7C9D2
        from bccc.ta.ta_A15B7C9D3 import ta_A15B7C9D3
        from bccc.ta.ta_A15B7C10D1 import ta_A15B7C10D1
        from bccc.ta.ta_A15B7C10D2 import ta_A15B7C10D2
        from bccc.ta.ta_A15B7C10D3 import ta_A15B7C10D3
        from bccc.ta.ta_A15B7C13D6 import ta_A15B7C13D6
        from bccc.ta.ta_A15B7C14D6 import ta_A15B7C14D6
        from bccc.ta.ta_A15B8C1D9 import ta_A15B8C1D9
        from bccc.ta.ta_A15B8C1D10 import ta_A15B8C1D10
        from bccc.ta.ta_A15B8C2D9 import ta_A15B8C2D9
        from bccc.ta.ta_A15B8C2D10 import ta_A15B8C2D10
        from bccc.ta.ta_A15B8C3D9 import ta_A15B8C3D9
        from bccc.ta.ta_A15B8C3D10 import ta_A15B8C3D10
        from bccc.ta.ta_A15B8C5D7 import ta_A15B8C5D7
        from bccc.ta.ta_A15B8C5D8 import ta_A15B8C5D8
        from bccc.ta.ta_A15B8C6D13 import ta_A15B8C6D13
        from bccc.ta.ta_A15B8C6D14 import ta_A15B8C6D14
        from bccc.ta.ta_A15B8C7D5 import ta_A15B8C7D5
        from bccc.ta.ta_A15B8C8D5 import ta_A15B8C8D5
        from bccc.ta.ta_A15B8C9D1 import ta_A15B8C9D1
        from bccc.ta.ta_A15B8C9D2 import ta_A15B8C9D2
        from bccc.ta.ta_A15B8C9D3 import ta_A15B8C9D3
        from bccc.ta.ta_A15B8C10D1 import ta_A15B8C10D1
        from bccc.ta.ta_A15B8C10D2 import ta_A15B8C10D2
        from bccc.ta.ta_A15B8C10D3 import ta_A15B8C10D3
        from bccc.ta.ta_A15B8C13D6 import ta_A15B8C13D6
        from bccc.ta.ta_A15B8C14D6 import ta_A15B8C14D6
        from bccc.ta.ta_A15B9C1D7 import ta_A15B9C1D7
        from bccc.ta.ta_A15B9C1D8 import ta_A15B9C1D8
        from bccc.ta.ta_A15B9C2D7 import ta_A15B9C2D7
        from bccc.ta.ta_A15B9C2D8 import ta_A15B9C2D8
        from bccc.ta.ta_A15B9C3D7 import ta_A15B9C3D7
        from bccc.ta.ta_A15B9C3D8 import ta_A15B9C3D8
        from bccc.ta.ta_A15B9C4D9 import ta_A15B9C4D9
        from bccc.ta.ta_A15B9C4D10 import ta_A15B9C4D10
        from bccc.ta.ta_A15B9C6D11 import ta_A15B9C6D11
        from bccc.ta.ta_A15B9C6D12 import ta_A15B9C6D12
        from bccc.ta.ta_A15B9C7D1 import ta_A15B9C7D1
        from bccc.ta.ta_A15B9C7D2 import ta_A15B9C7D2
        from bccc.ta.ta_A15B9C7D3 import ta_A15B9C7D3
        from bccc.ta.ta_A15B9C8D1 import ta_A15B9C8D1
        from bccc.ta.ta_A15B9C8D2 import ta_A15B9C8D2
        from bccc.ta.ta_A15B9C8D3 import ta_A15B9C8D3
        from bccc.ta.ta_A15B9C9D4 import ta_A15B9C9D4
        from bccc.ta.ta_A15B9C10D4 import ta_A15B9C10D4
        from bccc.ta.ta_A15B9C11D6 import ta_A15B9C11D6
        from bccc.ta.ta_A15B9C12D6 import ta_A15B9C12D6
        from bccc.ta.ta_A15B10C1D7 import ta_A15B10C1D7
        from bccc.ta.ta_A15B10C1D8 import ta_A15B10C1D8
        from bccc.ta.ta_A15B10C2D7 import ta_A15B10C2D7
        from bccc.ta.ta_A15B10C2D8 import ta_A15B10C2D8
        from bccc.ta.ta_A15B10C3D7 import ta_A15B10C3D7
        from bccc.ta.ta_A15B10C3D8 import ta_A15B10C3D8
        from bccc.ta.ta_A15B10C4D9 import ta_A15B10C4D9
        from bccc.ta.ta_A15B10C4D10 import ta_A15B10C4D10
        from bccc.ta.ta_A15B10C6D11 import ta_A15B10C6D11
        from bccc.ta.ta_A15B10C6D12 import ta_A15B10C6D12
        from bccc.ta.ta_A15B10C7D1 import ta_A15B10C7D1
        from bccc.ta.ta_A15B10C7D2 import ta_A15B10C7D2
        from bccc.ta.ta_A15B10C7D3 import ta_A15B10C7D3
        from bccc.ta.ta_A15B10C8D1 import ta_A15B10C8D1
        from bccc.ta.ta_A15B10C8D2 import ta_A15B10C8D2
        from bccc.ta.ta_A15B10C8D3 import ta_A15B10C8D3
        from bccc.ta.ta_A15B10C9D4 import ta_A15B10C9D4
        from bccc.ta.ta_A15B10C10D4 import ta_A15B10C10D4
        from bccc.ta.ta_A15B10C11D6 import ta_A15B10C11D6
        from bccc.ta.ta_A15B10C12D6 import ta_A15B10C12D6
        from bccc.ta.ta_A15B11C6D9 import ta_A15B11C6D9
        from bccc.ta.ta_A15B11C6D10 import ta_A15B11C6D10
        from bccc.ta.ta_A15B11C9D6 import ta_A15B11C9D6
        from bccc.ta.ta_A15B11C10D6 import ta_A15B11C10D6
        from bccc.ta.ta_A15B12C6D9 import ta_A15B12C6D9
        from bccc.ta.ta_A15B12C6D10 import ta_A15B12C6D10
        from bccc.ta.ta_A15B12C9D6 import ta_A15B12C9D6
        from bccc.ta.ta_A15B12C10D6 import ta_A15B12C10D6
        from bccc.ta.ta_A15B13C6D7 import ta_A15B13C6D7
        from bccc.ta.ta_A15B13C6D8 import ta_A15B13C6D8
        from bccc.ta.ta_A15B13C7D6 import ta_A15B13C7D6
        from bccc.ta.ta_A15B13C8D6 import ta_A15B13C8D6
        from bccc.ta.ta_A15B14C6D7 import ta_A15B14C6D7
        from bccc.ta.ta_A15B14C6D8 import ta_A15B14C6D8
        from bccc.ta.ta_A15B14C7D6 import ta_A15B14C7D6
        from bccc.ta.ta_A15B14C8D6 import ta_A15B14C8D6
        from bccc.ta.ta_A15B15C6D6 import ta_A15B15C6D6
        brafl += (
                 ta_A1B1C1D1, ta_A1B1C1D2, ta_A1B1C1D3, ta_A1B1C2D1, ta_A1B1C2D2, 
                 ta_A1B1C2D3, ta_A1B1C3D1, ta_A1B1C3D2, ta_A1B1C3D3, ta_A1B1C4D5, 
                 ta_A1B1C5D4, ta_A1B1C6D15, ta_A1B1C7D13, ta_A1B1C7D14, ta_A1B1C8D13, 
                 ta_A1B1C8D14, ta_A1B1C9D11, ta_A1B1C9D12, ta_A1B1C10D11, ta_A1B1C10D12, 
                 ta_A1B1C11D9, ta_A1B1C11D10, ta_A1B1C12D9, ta_A1B1C12D10, ta_A1B1C13D7, 
                 ta_A1B1C13D8, ta_A1B1C14D7, ta_A1B1C14D8, ta_A1B1C15D6, ta_A1B2C1D1, 
                 ta_A1B2C1D2, ta_A1B2C1D3, ta_A1B2C2D1, ta_A1B2C2D2, ta_A1B2C2D3, 
                 ta_A1B2C3D1, ta_A1B2C3D2, ta_A1B2C3D3, ta_A1B2C4D5, ta_A1B2C5D4, 
                 ta_A1B2C6D15, ta_A1B2C7D13, ta_A1B2C7D14, ta_A1B2C8D13, ta_A1B2C8D14, 
                 ta_A1B2C9D11, ta_A1B2C9D12, ta_A1B2C10D11, ta_A1B2C10D12, ta_A1B2C11D9, 
                 ta_A1B2C11D10, ta_A1B2C12D9, ta_A1B2C12D10, ta_A1B2C13D7, ta_A1B2C13D8, 
                 ta_A1B2C14D7, ta_A1B2C14D8, ta_A1B2C15D6, ta_A1B3C1D1, ta_A1B3C1D2, 
                 ta_A1B3C1D3, ta_A1B3C2D1, ta_A1B3C2D2, ta_A1B3C2D3, ta_A1B3C3D1, 
                 ta_A1B3C3D2, ta_A1B3C3D3, ta_A1B3C4D5, ta_A1B3C5D4, ta_A1B3C6D15, 
                 ta_A1B3C7D13, ta_A1B3C7D14, ta_A1B3C8D13, ta_A1B3C8D14, ta_A1B3C9D11, 
                 ta_A1B3C9D12, ta_A1B3C10D11, ta_A1B3C10D12, ta_A1B3C11D9, ta_A1B3C11D10, 
                 ta_A1B3C12D9, ta_A1B3C12D10, ta_A1B3C13D7, ta_A1B3C13D8, ta_A1B3C14D7, 
                 ta_A1B3C14D8, ta_A1B3C15D6, ta_A1B4C1D5, ta_A1B4C2D5, ta_A1B4C3D5, 
                 ta_A1B4C5D1, ta_A1B4C5D2, ta_A1B4C5D3, ta_A1B4C9D13, ta_A1B4C9D14, 
                 ta_A1B4C10D13, ta_A1B4C10D14, ta_A1B4C13D9, ta_A1B4C13D10, ta_A1B4C14D9, 
                 ta_A1B4C14D10, ta_A1B5C1D4, ta_A1B5C2D4, ta_A1B5C3D4, ta_A1B5C4D1, 
                 ta_A1B5C4D2, ta_A1B5C4D3, ta_A1B5C7D11, ta_A1B5C7D12, ta_A1B5C8D11, 
                 ta_A1B5C8D12, ta_A1B5C11D7, ta_A1B5C11D8, ta_A1B5C12D7, ta_A1B5C12D8, 
                 ta_A1B6C1D15, ta_A1B6C2D15, ta_A1B6C3D15, ta_A1B6C11D13, ta_A1B6C11D14, 
                 ta_A1B6C12D13, ta_A1B6C12D14, ta_A1B6C13D11, ta_A1B6C13D12, ta_A1B6C14D11, 
                 ta_A1B6C14D12, ta_A1B6C15D1, ta_A1B6C15D2, ta_A1B6C15D3, ta_A1B7C1D13, 
                 ta_A1B7C1D14, ta_A1B7C2D13, ta_A1B7C2D14, ta_A1B7C3D13, ta_A1B7C3D14, 
                 ta_A1B7C5D11, ta_A1B7C5D12, ta_A1B7C9D15, ta_A1B7C10D15, ta_A1B7C11D5, 
                 ta_A1B7C12D5, ta_A1B7C13D1, ta_A1B7C13D2, ta_A1B7C13D3, ta_A1B7C14D1, 
                 ta_A1B7C14D2, ta_A1B7C14D3, ta_A1B7C15D9, ta_A1B7C15D10, ta_A1B8C1D13, 
                 ta_A1B8C1D14, ta_A1B8C2D13, ta_A1B8C2D14, ta_A1B8C3D13, ta_A1B8C3D14, 
                 ta_A1B8C5D11, ta_A1B8C5D12, ta_A1B8C9D15, ta_A1B8C10D15, ta_A1B8C11D5, 
                 ta_A1B8C12D5, ta_A1B8C13D1, ta_A1B8C13D2, ta_A1B8C13D3, ta_A1B8C14D1, 
                 ta_A1B8C14D2, ta_A1B8C14D3, ta_A1B8C15D9, ta_A1B8C15D10, ta_A1B9C1D11, 
                 ta_A1B9C1D12, ta_A1B9C2D11, ta_A1B9C2D12, ta_A1B9C3D11, ta_A1B9C3D12, 
                 ta_A1B9C4D13, ta_A1B9C4D14, ta_A1B9C7D15, ta_A1B9C8D15, ta_A1B9C11D1, 
                 ta_A1B9C11D2, ta_A1B9C11D3, ta_A1B9C12D1, ta_A1B9C12D2, ta_A1B9C12D3, 
                 ta_A1B9C13D4, ta_A1B9C14D4, ta_A1B9C15D7, ta_A1B9C15D8, ta_A1B10C1D11, 
                 ta_A1B10C1D12, ta_A1B10C2D11, ta_A1B10C2D12, ta_A1B10C3D11, ta_A1B10C3D12, 
                 ta_A1B10C4D13, ta_A1B10C4D14, ta_A1B10C7D15, ta_A1B10C8D15, ta_A1B10C11D1, 
                 ta_A1B10C11D2, ta_A1B10C11D3, ta_A1B10C12D1, ta_A1B10C12D2, ta_A1B10C12D3, 
                 ta_A1B10C13D4, ta_A1B10C14D4, ta_A1B10C15D7, ta_A1B10C15D8, ta_A1B11C1D9, 
                 ta_A1B11C1D10, ta_A1B11C2D9, ta_A1B11C2D10, ta_A1B11C3D9, ta_A1B11C3D10, 
                 ta_A1B11C5D7, ta_A1B11C5D8, ta_A1B11C6D13, ta_A1B11C6D14, ta_A1B11C7D5, 
                 ta_A1B11C8D5, ta_A1B11C9D1, ta_A1B11C9D2, ta_A1B11C9D3, ta_A1B11C10D1, 
                 ta_A1B11C10D2, ta_A1B11C10D3, ta_A1B11C13D6, ta_A1B11C14D6, ta_A1B12C1D9, 
                 ta_A1B12C1D10, ta_A1B12C2D9, ta_A1B12C2D10, ta_A1B12C3D9, ta_A1B12C3D10, 
                 ta_A1B12C5D7, ta_A1B12C5D8, ta_A1B12C6D13, ta_A1B12C6D14, ta_A1B12C7D5, 
                 ta_A1B12C8D5, ta_A1B12C9D1, ta_A1B12C9D2, ta_A1B12C9D3, ta_A1B12C10D1, 
                 ta_A1B12C10D2, ta_A1B12C10D3, ta_A1B12C13D6, ta_A1B12C14D6, ta_A1B13C1D7, 
                 ta_A1B13C1D8, ta_A1B13C2D7, ta_A1B13C2D8, ta_A1B13C3D7, ta_A1B13C3D8, 
                 ta_A1B13C4D9, ta_A1B13C4D10, ta_A1B13C6D11, ta_A1B13C6D12, ta_A1B13C7D1, 
                 ta_A1B13C7D2, ta_A1B13C7D3, ta_A1B13C8D1, ta_A1B13C8D2, ta_A1B13C8D3, 
                 ta_A1B13C9D4, ta_A1B13C10D4, ta_A1B13C11D6, ta_A1B13C12D6, ta_A1B14C1D7, 
                 ta_A1B14C1D8, ta_A1B14C2D7, ta_A1B14C2D8, ta_A1B14C3D7, ta_A1B14C3D8, 
                 ta_A1B14C4D9, ta_A1B14C4D10, ta_A1B14C6D11, ta_A1B14C6D12, ta_A1B14C7D1, 
                 ta_A1B14C7D2, ta_A1B14C7D3, ta_A1B14C8D1, ta_A1B14C8D2, ta_A1B14C8D3, 
                 ta_A1B14C9D4, ta_A1B14C10D4, ta_A1B14C11D6, ta_A1B14C12D6, ta_A1B15C1D6, 
                 ta_A1B15C2D6, ta_A1B15C3D6, ta_A1B15C6D1, ta_A1B15C6D2, ta_A1B15C6D3, 
                 ta_A1B15C7D9, ta_A1B15C7D10, ta_A1B15C8D9, ta_A1B15C8D10, ta_A1B15C9D7, 
                 ta_A1B15C9D8, ta_A1B15C10D7, ta_A1B15C10D8, ta_A2B1C1D1, ta_A2B1C1D2, 
                 ta_A2B1C1D3, ta_A2B1C2D1, ta_A2B1C2D2, ta_A2B1C2D3, ta_A2B1C3D1, 
                 ta_A2B1C3D2, ta_A2B1C3D3, ta_A2B1C4D5, ta_A2B1C5D4, ta_A2B1C6D15, 
                 ta_A2B1C7D13, ta_A2B1C7D14, ta_A2B1C8D13, ta_A2B1C8D14, ta_A2B1C9D11, 
                 ta_A2B1C9D12, ta_A2B1C10D11, ta_A2B1C10D12, ta_A2B1C11D9, ta_A2B1C11D10, 
                 ta_A2B1C12D9, ta_A2B1C12D10, ta_A2B1C13D7, ta_A2B1C13D8, ta_A2B1C14D7, 
                 ta_A2B1C14D8, ta_A2B1C15D6, ta_A2B2C1D1, ta_A2B2C1D2, ta_A2B2C1D3, 
                 ta_A2B2C2D1, ta_A2B2C2D2, ta_A2B2C2D3, ta_A2B2C3D1, ta_A2B2C3D2, 
                 ta_A2B2C3D3, ta_A2B2C4D5, ta_A2B2C5D4, ta_A2B2C6D15, ta_A2B2C7D13, 
                 ta_A2B2C7D14, ta_A2B2C8D13, ta_A2B2C8D14, ta_A2B2C9D11, ta_A2B2C9D12, 
                 ta_A2B2C10D11, ta_A2B2C10D12, ta_A2B2C11D9, ta_A2B2C11D10, ta_A2B2C12D9, 
                 ta_A2B2C12D10, ta_A2B2C13D7, ta_A2B2C13D8, ta_A2B2C14D7, ta_A2B2C14D8, 
                 ta_A2B2C15D6, ta_A2B3C1D1, ta_A2B3C1D2, ta_A2B3C1D3, ta_A2B3C2D1, 
                 ta_A2B3C2D2, ta_A2B3C2D3, ta_A2B3C3D1, ta_A2B3C3D2, ta_A2B3C3D3, 
                 ta_A2B3C4D5, ta_A2B3C5D4, ta_A2B3C6D15, ta_A2B3C7D13, ta_A2B3C7D14, 
                 ta_A2B3C8D13, ta_A2B3C8D14, ta_A2B3C9D11, ta_A2B3C9D12, ta_A2B3C10D11, 
                 ta_A2B3C10D12, ta_A2B3C11D9, ta_A2B3C11D10, ta_A2B3C12D9, ta_A2B3C12D10, 
                 ta_A2B3C13D7, ta_A2B3C13D8, ta_A2B3C14D7, ta_A2B3C14D8, ta_A2B3C15D6, 
                 ta_A2B4C1D5, ta_A2B4C2D5, ta_A2B4C3D5, ta_A2B4C5D1, ta_A2B4C5D2, 
                 ta_A2B4C5D3, ta_A2B4C9D13, ta_A2B4C9D14, ta_A2B4C10D13, ta_A2B4C10D14, 
                 ta_A2B4C13D9, ta_A2B4C13D10, ta_A2B4C14D9, ta_A2B4C14D10, ta_A2B5C1D4, 
                 ta_A2B5C2D4, ta_A2B5C3D4, ta_A2B5C4D1, ta_A2B5C4D2, ta_A2B5C4D3, 
                 ta_A2B5C7D11, ta_A2B5C7D12, ta_A2B5C8D11, ta_A2B5C8D12, ta_A2B5C11D7, 
                 ta_A2B5C11D8, ta_A2B5C12D7, ta_A2B5C12D8, ta_A2B6C1D15, ta_A2B6C2D15, 
                 ta_A2B6C3D15, ta_A2B6C11D13, ta_A2B6C11D14, ta_A2B6C12D13, ta_A2B6C12D14, 
                 ta_A2B6C13D11, ta_A2B6C13D12, ta_A2B6C14D11, ta_A2B6C14D12, ta_A2B6C15D1, 
                 ta_A2B6C15D2, ta_A2B6C15D3, ta_A2B7C1D13, ta_A2B7C1D14, ta_A2B7C2D13, 
                 ta_A2B7C2D14, ta_A2B7C3D13, ta_A2B7C3D14, ta_A2B7C5D11, ta_A2B7C5D12, 
                 ta_A2B7C9D15, ta_A2B7C10D15, ta_A2B7C11D5, ta_A2B7C12D5, ta_A2B7C13D1, 
                 ta_A2B7C13D2, ta_A2B7C13D3, ta_A2B7C14D1, ta_A2B7C14D2, ta_A2B7C14D3, 
                 ta_A2B7C15D9, ta_A2B7C15D10, ta_A2B8C1D13, ta_A2B8C1D14, ta_A2B8C2D13, 
                 ta_A2B8C2D14, ta_A2B8C3D13, ta_A2B8C3D14, ta_A2B8C5D11, ta_A2B8C5D12, 
                 ta_A2B8C9D15, ta_A2B8C10D15, ta_A2B8C11D5, ta_A2B8C12D5, ta_A2B8C13D1, 
                 ta_A2B8C13D2, ta_A2B8C13D3, ta_A2B8C14D1, ta_A2B8C14D2, ta_A2B8C14D3, 
                 ta_A2B8C15D9, ta_A2B8C15D10, ta_A2B9C1D11, ta_A2B9C1D12, ta_A2B9C2D11, 
                 ta_A2B9C2D12, ta_A2B9C3D11, ta_A2B9C3D12, ta_A2B9C4D13, ta_A2B9C4D14, 
                 ta_A2B9C7D15, ta_A2B9C8D15, ta_A2B9C11D1, ta_A2B9C11D2, ta_A2B9C11D3, 
                 ta_A2B9C12D1, ta_A2B9C12D2, ta_A2B9C12D3, ta_A2B9C13D4, ta_A2B9C14D4, 
                 ta_A2B9C15D7, ta_A2B9C15D8, ta_A2B10C1D11, ta_A2B10C1D12, ta_A2B10C2D11, 
                 ta_A2B10C2D12, ta_A2B10C3D11, ta_A2B10C3D12, ta_A2B10C4D13, ta_A2B10C4D14, 
                 ta_A2B10C7D15, ta_A2B10C8D15, ta_A2B10C11D1, ta_A2B10C11D2, ta_A2B10C11D3, 
                 ta_A2B10C12D1, ta_A2B10C12D2, ta_A2B10C12D3, ta_A2B10C13D4, ta_A2B10C14D4, 
                 ta_A2B10C15D7, ta_A2B10C15D8, ta_A2B11C1D9, ta_A2B11C1D10, ta_A2B11C2D9, 
                 ta_A2B11C2D10, ta_A2B11C3D9, ta_A2B11C3D10, ta_A2B11C5D7, ta_A2B11C5D8, 
                 ta_A2B11C6D13, ta_A2B11C6D14, ta_A2B11C7D5, ta_A2B11C8D5, ta_A2B11C9D1, 
                 ta_A2B11C9D2, ta_A2B11C9D3, ta_A2B11C10D1, ta_A2B11C10D2, ta_A2B11C10D3, 
                 ta_A2B11C13D6, ta_A2B11C14D6, ta_A2B12C1D9, ta_A2B12C1D10, ta_A2B12C2D9, 
                 ta_A2B12C2D10, ta_A2B12C3D9, ta_A2B12C3D10, ta_A2B12C5D7, ta_A2B12C5D8, 
                 ta_A2B12C6D13, ta_A2B12C6D14, ta_A2B12C7D5, ta_A2B12C8D5, ta_A2B12C9D1, 
                 ta_A2B12C9D2, ta_A2B12C9D3, ta_A2B12C10D1, ta_A2B12C10D2, ta_A2B12C10D3, 
                 ta_A2B12C13D6, ta_A2B12C14D6, ta_A2B13C1D7, ta_A2B13C1D8, ta_A2B13C2D7, 
                 ta_A2B13C2D8, ta_A2B13C3D7, ta_A2B13C3D8, ta_A2B13C4D9, ta_A2B13C4D10, 
                 ta_A2B13C6D11, ta_A2B13C6D12, ta_A2B13C7D1, ta_A2B13C7D2, ta_A2B13C7D3, 
                 ta_A2B13C8D1, ta_A2B13C8D2, ta_A2B13C8D3, ta_A2B13C9D4, ta_A2B13C10D4, 
                 ta_A2B13C11D6, ta_A2B13C12D6, ta_A2B14C1D7, ta_A2B14C1D8, ta_A2B14C2D7, 
                 ta_A2B14C2D8, ta_A2B14C3D7, ta_A2B14C3D8, ta_A2B14C4D9, ta_A2B14C4D10, 
                 ta_A2B14C6D11, ta_A2B14C6D12, ta_A2B14C7D1, ta_A2B14C7D2, ta_A2B14C7D3, 
                 ta_A2B14C8D1, ta_A2B14C8D2, ta_A2B14C8D3, ta_A2B14C9D4, ta_A2B14C10D4, 
                 ta_A2B14C11D6, ta_A2B14C12D6, ta_A2B15C1D6, ta_A2B15C2D6, ta_A2B15C3D6, 
                 ta_A2B15C6D1, ta_A2B15C6D2, ta_A2B15C6D3, ta_A2B15C7D9, ta_A2B15C7D10, 
                 ta_A2B15C8D9, ta_A2B15C8D10, ta_A2B15C9D7, ta_A2B15C9D8, ta_A2B15C10D7, 
                 ta_A2B15C10D8, ta_A3B1C1D1, ta_A3B1C1D2, ta_A3B1C1D3, ta_A3B1C2D1, 
                 ta_A3B1C2D2, ta_A3B1C2D3, ta_A3B1C3D1, ta_A3B1C3D2, ta_A3B1C3D3, 
                 ta_A3B1C4D5, ta_A3B1C5D4, ta_A3B1C6D15, ta_A3B1C7D13, ta_A3B1C7D14, 
                 ta_A3B1C8D13, ta_A3B1C8D14, ta_A3B1C9D11, ta_A3B1C9D12, ta_A3B1C10D11, 
                 ta_A3B1C10D12, ta_A3B1C11D9, ta_A3B1C11D10, ta_A3B1C12D9, ta_A3B1C12D10, 
                 ta_A3B1C13D7, ta_A3B1C13D8, ta_A3B1C14D7, ta_A3B1C14D8, ta_A3B1C15D6, 
                 ta_A3B2C1D1, ta_A3B2C1D2, ta_A3B2C1D3, ta_A3B2C2D1, ta_A3B2C2D2, 
                 ta_A3B2C2D3, ta_A3B2C3D1, ta_A3B2C3D2, ta_A3B2C3D3, ta_A3B2C4D5, 
                 ta_A3B2C5D4, ta_A3B2C6D15, ta_A3B2C7D13, ta_A3B2C7D14, ta_A3B2C8D13, 
                 ta_A3B2C8D14, ta_A3B2C9D11, ta_A3B2C9D12, ta_A3B2C10D11, ta_A3B2C10D12, 
                 ta_A3B2C11D9, ta_A3B2C11D10, ta_A3B2C12D9, ta_A3B2C12D10, ta_A3B2C13D7, 
                 ta_A3B2C13D8, ta_A3B2C14D7, ta_A3B2C14D8, ta_A3B2C15D6, ta_A3B3C1D1, 
                 ta_A3B3C1D2, ta_A3B3C1D3, ta_A3B3C2D1, ta_A3B3C2D2, ta_A3B3C2D3, 
                 ta_A3B3C3D1, ta_A3B3C3D2, ta_A3B3C3D3, ta_A3B3C4D5, ta_A3B3C5D4, 
                 ta_A3B3C6D15, ta_A3B3C7D13, ta_A3B3C7D14, ta_A3B3C8D13, ta_A3B3C8D14, 
                 ta_A3B3C9D11, ta_A3B3C9D12, ta_A3B3C10D11, ta_A3B3C10D12, ta_A3B3C11D9, 
                 ta_A3B3C11D10, ta_A3B3C12D9, ta_A3B3C12D10, ta_A3B3C13D7, ta_A3B3C13D8, 
                 ta_A3B3C14D7, ta_A3B3C14D8, ta_A3B3C15D6, ta_A3B4C1D5, ta_A3B4C2D5, 
                 ta_A3B4C3D5, ta_A3B4C5D1, ta_A3B4C5D2, ta_A3B4C5D3, ta_A3B4C9D13, 
                 ta_A3B4C9D14, ta_A3B4C10D13, ta_A3B4C10D14, ta_A3B4C13D9, ta_A3B4C13D10, 
                 ta_A3B4C14D9, ta_A3B4C14D10, ta_A3B5C1D4, ta_A3B5C2D4, ta_A3B5C3D4, 
                 ta_A3B5C4D1, ta_A3B5C4D2, ta_A3B5C4D3, ta_A3B5C7D11, ta_A3B5C7D12, 
                 ta_A3B5C8D11, ta_A3B5C8D12, ta_A3B5C11D7, ta_A3B5C11D8, ta_A3B5C12D7, 
                 ta_A3B5C12D8, ta_A3B6C1D15, ta_A3B6C2D15, ta_A3B6C3D15, ta_A3B6C11D13, 
                 ta_A3B6C11D14, ta_A3B6C12D13, ta_A3B6C12D14, ta_A3B6C13D11, ta_A3B6C13D12, 
                 ta_A3B6C14D11, ta_A3B6C14D12, ta_A3B6C15D1, ta_A3B6C15D2, ta_A3B6C15D3, 
                 ta_A3B7C1D13, ta_A3B7C1D14, ta_A3B7C2D13, ta_A3B7C2D14, ta_A3B7C3D13, 
                 ta_A3B7C3D14, ta_A3B7C5D11, ta_A3B7C5D12, ta_A3B7C9D15, ta_A3B7C10D15, 
                 ta_A3B7C11D5, ta_A3B7C12D5, ta_A3B7C13D1, ta_A3B7C13D2, ta_A3B7C13D3, 
                 ta_A3B7C14D1, ta_A3B7C14D2, ta_A3B7C14D3, ta_A3B7C15D9, ta_A3B7C15D10, 
                 ta_A3B8C1D13, ta_A3B8C1D14, ta_A3B8C2D13, ta_A3B8C2D14, ta_A3B8C3D13, 
                 ta_A3B8C3D14, ta_A3B8C5D11, ta_A3B8C5D12, ta_A3B8C9D15, ta_A3B8C10D15, 
                 ta_A3B8C11D5, ta_A3B8C12D5, ta_A3B8C13D1, ta_A3B8C13D2, ta_A3B8C13D3, 
                 ta_A3B8C14D1, ta_A3B8C14D2, ta_A3B8C14D3, ta_A3B8C15D9, ta_A3B8C15D10, 
                 ta_A3B9C1D11, ta_A3B9C1D12, ta_A3B9C2D11, ta_A3B9C2D12, ta_A3B9C3D11, 
                 ta_A3B9C3D12, ta_A3B9C4D13, ta_A3B9C4D14, ta_A3B9C7D15, ta_A3B9C8D15, 
                 ta_A3B9C11D1, ta_A3B9C11D2, ta_A3B9C11D3, ta_A3B9C12D1, ta_A3B9C12D2, 
                 ta_A3B9C12D3, ta_A3B9C13D4, ta_A3B9C14D4, ta_A3B9C15D7, ta_A3B9C15D8, 
                 ta_A3B10C1D11, ta_A3B10C1D12, ta_A3B10C2D11, ta_A3B10C2D12, ta_A3B10C3D11, 
                 ta_A3B10C3D12, ta_A3B10C4D13, ta_A3B10C4D14, ta_A3B10C7D15, ta_A3B10C8D15, 
                 ta_A3B10C11D1, ta_A3B10C11D2, ta_A3B10C11D3, ta_A3B10C12D1, ta_A3B10C12D2, 
                 ta_A3B10C12D3, ta_A3B10C13D4, ta_A3B10C14D4, ta_A3B10C15D7, ta_A3B10C15D8, 
                 ta_A3B11C1D9, ta_A3B11C1D10, ta_A3B11C2D9, ta_A3B11C2D10, ta_A3B11C3D9, 
                 ta_A3B11C3D10, ta_A3B11C5D7, ta_A3B11C5D8, ta_A3B11C6D13, ta_A3B11C6D14, 
                 ta_A3B11C7D5, ta_A3B11C8D5, ta_A3B11C9D1, ta_A3B11C9D2, ta_A3B11C9D3, 
                 ta_A3B11C10D1, ta_A3B11C10D2, ta_A3B11C10D3, ta_A3B11C13D6, ta_A3B11C14D6, 
                 ta_A3B12C1D9, ta_A3B12C1D10, ta_A3B12C2D9, ta_A3B12C2D10, ta_A3B12C3D9, 
                 ta_A3B12C3D10, ta_A3B12C5D7, ta_A3B12C5D8, ta_A3B12C6D13, ta_A3B12C6D14, 
                 ta_A3B12C7D5, ta_A3B12C8D5, ta_A3B12C9D1, ta_A3B12C9D2, ta_A3B12C9D3, 
                 ta_A3B12C10D1, ta_A3B12C10D2, ta_A3B12C10D3, ta_A3B12C13D6, ta_A3B12C14D6, 
                 ta_A3B13C1D7, ta_A3B13C1D8, ta_A3B13C2D7, ta_A3B13C2D8, ta_A3B13C3D7, 
                 ta_A3B13C3D8, ta_A3B13C4D9, ta_A3B13C4D10, ta_A3B13C6D11, ta_A3B13C6D12, 
                 ta_A3B13C7D1, ta_A3B13C7D2, ta_A3B13C7D3, ta_A3B13C8D1, ta_A3B13C8D2, 
                 ta_A3B13C8D3, ta_A3B13C9D4, ta_A3B13C10D4, ta_A3B13C11D6, ta_A3B13C12D6, 
                 ta_A3B14C1D7, ta_A3B14C1D8, ta_A3B14C2D7, ta_A3B14C2D8, ta_A3B14C3D7, 
                 ta_A3B14C3D8, ta_A3B14C4D9, ta_A3B14C4D10, ta_A3B14C6D11, ta_A3B14C6D12, 
                 ta_A3B14C7D1, ta_A3B14C7D2, ta_A3B14C7D3, ta_A3B14C8D1, ta_A3B14C8D2, 
                 ta_A3B14C8D3, ta_A3B14C9D4, ta_A3B14C10D4, ta_A3B14C11D6, ta_A3B14C12D6, 
                 ta_A3B15C1D6, ta_A3B15C2D6, ta_A3B15C3D6, ta_A3B15C6D1, ta_A3B15C6D2, 
                 ta_A3B15C6D3, ta_A3B15C7D9, ta_A3B15C7D10, ta_A3B15C8D9, ta_A3B15C8D10, 
                 ta_A3B15C9D7, ta_A3B15C9D8, ta_A3B15C10D7, ta_A3B15C10D8, ta_A4B1C1D5, 
                 ta_A4B1C2D5, ta_A4B1C3D5, ta_A4B1C5D1, ta_A4B1C5D2, ta_A4B1C5D3, 
                 ta_A4B1C9D13, ta_A4B1C9D14, ta_A4B1C10D13, ta_A4B1C10D14, ta_A4B1C13D9, 
                 ta_A4B1C13D10, ta_A4B1C14D9, ta_A4B1C14D10, ta_A4B2C1D5, ta_A4B2C2D5, 
                 ta_A4B2C3D5, ta_A4B2C5D1, ta_A4B2C5D2, ta_A4B2C5D3, ta_A4B2C9D13, 
                 ta_A4B2C9D14, ta_A4B2C10D13, ta_A4B2C10D14, ta_A4B2C13D9, ta_A4B2C13D10, 
                 ta_A4B2C14D9, ta_A4B2C14D10, ta_A4B3C1D5, ta_A4B3C2D5, ta_A4B3C3D5, 
                 ta_A4B3C5D1, ta_A4B3C5D2, ta_A4B3C5D3, ta_A4B3C9D13, ta_A4B3C9D14, 
                 ta_A4B3C10D13, ta_A4B3C10D14, ta_A4B3C13D9, ta_A4B3C13D10, ta_A4B3C14D9, 
                 ta_A4B3C14D10, ta_A4B4C5D5, ta_A4B5C1D1, ta_A4B5C1D2, ta_A4B5C1D3, 
                 ta_A4B5C2D1, ta_A4B5C2D2, ta_A4B5C2D3, ta_A4B5C3D1, ta_A4B5C3D2, 
                 ta_A4B5C3D3, ta_A4B5C4D5, ta_A4B5C5D4, ta_A4B5C6D15, ta_A4B5C7D13, 
                 ta_A4B5C7D14, ta_A4B5C8D13, ta_A4B5C8D14, ta_A4B5C9D11, ta_A4B5C9D12, 
                 ta_A4B5C10D11, ta_A4B5C10D12, ta_A4B5C11D9, ta_A4B5C11D10, ta_A4B5C12D9, 
                 ta_A4B5C12D10, ta_A4B5C13D7, ta_A4B5C13D8, ta_A4B5C14D7, ta_A4B5C14D8, 
                 ta_A4B5C15D6, ta_A4B6C5D15, ta_A4B6C13D13, ta_A4B6C13D14, ta_A4B6C14D13, 
                 ta_A4B6C14D14, ta_A4B6C15D5, ta_A4B7C5D13, ta_A4B7C5D14, ta_A4B7C13D5, 
                 ta_A4B7C14D5, ta_A4B8C5D13, ta_A4B8C5D14, ta_A4B8C13D5, ta_A4B8C14D5, 
                 ta_A4B9C1D13, ta_A4B9C1D14, ta_A4B9C2D13, ta_A4B9C2D14, ta_A4B9C3D13, 
                 ta_A4B9C3D14, ta_A4B9C5D11, ta_A4B9C5D12, ta_A4B9C9D15, ta_A4B9C10D15, 
                 ta_A4B9C11D5, ta_A4B9C12D5, ta_A4B9C13D1, ta_A4B9C13D2, ta_A4B9C13D3, 
                 ta_A4B9C14D1, ta_A4B9C14D2, ta_A4B9C14D3, ta_A4B9C15D9, ta_A4B9C15D10, 
                 ta_A4B10C1D13, ta_A4B10C1D14, ta_A4B10C2D13, ta_A4B10C2D14, ta_A4B10C3D13, 
                 ta_A4B10C3D14, ta_A4B10C5D11, ta_A4B10C5D12, ta_A4B10C9D15, ta_A4B10C10D15, 
                 ta_A4B10C11D5, ta_A4B10C12D5, ta_A4B10C13D1, ta_A4B10C13D2, ta_A4B10C13D3, 
                 ta_A4B10C14D1, ta_A4B10C14D2, ta_A4B10C14D3, ta_A4B10C15D9, ta_A4B10C15D10, 
                 ta_A4B11C5D9, ta_A4B11C5D10, ta_A4B11C9D5, ta_A4B11C10D5, ta_A4B12C5D9, 
                 ta_A4B12C5D10, ta_A4B12C9D5, ta_A4B12C10D5, ta_A4B13C1D9, ta_A4B13C1D10, 
                 ta_A4B13C2D9, ta_A4B13C2D10, ta_A4B13C3D9, ta_A4B13C3D10, ta_A4B13C5D7, 
                 ta_A4B13C5D8, ta_A4B13C6D13, ta_A4B13C6D14, ta_A4B13C7D5, ta_A4B13C8D5, 
                 ta_A4B13C9D1, ta_A4B13C9D2, ta_A4B13C9D3, ta_A4B13C10D1, ta_A4B13C10D2, 
                 ta_A4B13C10D3, ta_A4B13C13D6, ta_A4B13C14D6, ta_A4B14C1D9, ta_A4B14C1D10, 
                 ta_A4B14C2D9, ta_A4B14C2D10, ta_A4B14C3D9, ta_A4B14C3D10, ta_A4B14C5D7, 
                 ta_A4B14C5D8, ta_A4B14C6D13, ta_A4B14C6D14, ta_A4B14C7D5, ta_A4B14C8D5, 
                 ta_A4B14C9D1, ta_A4B14C9D2, ta_A4B14C9D3, ta_A4B14C10D1, ta_A4B14C10D2, 
                 ta_A4B14C10D3, ta_A4B14C13D6, ta_A4B14C14D6, ta_A4B15C5D6, ta_A4B15C6D5, 
                 ta_A4B15C9D9, ta_A4B15C9D10, ta_A4B15C10D9, ta_A4B15C10D10, ta_A5B1C1D4, 
                 ta_A5B1C2D4, ta_A5B1C3D4, ta_A5B1C4D1, ta_A5B1C4D2, ta_A5B1C4D3, 
                 ta_A5B1C7D11, ta_A5B1C7D12, ta_A5B1C8D11, ta_A5B1C8D12, ta_A5B1C11D7, 
                 ta_A5B1C11D8, ta_A5B1C12D7, ta_A5B1C12D8, ta_A5B2C1D4, ta_A5B2C2D4, 
                 ta_A5B2C3D4, ta_A5B2C4D1, ta_A5B2C4D2, ta_A5B2C4D3, ta_A5B2C7D11, 
                 ta_A5B2C7D12, ta_A5B2C8D11, ta_A5B2C8D12, ta_A5B2C11D7, ta_A5B2C11D8, 
                 ta_A5B2C12D7, ta_A5B2C12D8, ta_A5B3C1D4, ta_A5B3C2D4, ta_A5B3C3D4, 
                 ta_A5B3C4D1, ta_A5B3C4D2, ta_A5B3C4D3, ta_A5B3C7D11, ta_A5B3C7D12, 
                 ta_A5B3C8D11, ta_A5B3C8D12, ta_A5B3C11D7, ta_A5B3C11D8, ta_A5B3C12D7, 
                 ta_A5B3C12D8, ta_A5B4C1D1, ta_A5B4C1D2, ta_A5B4C1D3, ta_A5B4C2D1, 
                 ta_A5B4C2D2, ta_A5B4C2D3, ta_A5B4C3D1, ta_A5B4C3D2, ta_A5B4C3D3, 
                 ta_A5B4C4D5, ta_A5B4C5D4, ta_A5B4C6D15, ta_A5B4C7D13, ta_A5B4C7D14, 
                 ta_A5B4C8D13, ta_A5B4C8D14, ta_A5B4C9D11, ta_A5B4C9D12, ta_A5B4C10D11, 
                 ta_A5B4C10D12, ta_A5B4C11D9, ta_A5B4C11D10, ta_A5B4C12D9, ta_A5B4C12D10, 
                 ta_A5B4C13D7, ta_A5B4C13D8, ta_A5B4C14D7, ta_A5B4C14D8, ta_A5B4C15D6, 
                 ta_A5B5C4D4, ta_A5B6C4D15, ta_A5B6C11D11, ta_A5B6C11D12, ta_A5B6C12D11, 
                 ta_A5B6C12D12, ta_A5B6C15D4, ta_A5B7C1D11, ta_A5B7C1D12, ta_A5B7C2D11, 
                 ta_A5B7C2D12, ta_A5B7C3D11, ta_A5B7C3D12, ta_A5B7C4D13, ta_A5B7C4D14, 
                 ta_A5B7C7D15, ta_A5B7C8D15, ta_A5B7C11D1, ta_A5B7C11D2, ta_A5B7C11D3, 
                 ta_A5B7C12D1, ta_A5B7C12D2, ta_A5B7C12D3, ta_A5B7C13D4, ta_A5B7C14D4, 
                 ta_A5B7C15D7, ta_A5B7C15D8, ta_A5B8C1D11, ta_A5B8C1D12, ta_A5B8C2D11, 
                 ta_A5B8C2D12, ta_A5B8C3D11, ta_A5B8C3D12, ta_A5B8C4D13, ta_A5B8C4D14, 
                 ta_A5B8C7D15, ta_A5B8C8D15, ta_A5B8C11D1, ta_A5B8C11D2, ta_A5B8C11D3, 
                 ta_A5B8C12D1, ta_A5B8C12D2, ta_A5B8C12D3, ta_A5B8C13D4, ta_A5B8C14D4, 
                 ta_A5B8C15D7, ta_A5B8C15D8, ta_A5B9C4D11, ta_A5B9C4D12, ta_A5B9C11D4, 
                 ta_A5B9C12D4, ta_A5B10C4D11, ta_A5B10C4D12, ta_A5B10C11D4, ta_A5B10C12D4, 
                 ta_A5B11C1D7, ta_A5B11C1D8, ta_A5B11C2D7, ta_A5B11C2D8, ta_A5B11C3D7, 
                 ta_A5B11C3D8, ta_A5B11C4D9, ta_A5B11C4D10, ta_A5B11C6D11, ta_A5B11C6D12, 
                 ta_A5B11C7D1, ta_A5B11C7D2, ta_A5B11C7D3, ta_A5B11C8D1, ta_A5B11C8D2, 
                 ta_A5B11C8D3, ta_A5B11C9D4, ta_A5B11C10D4, ta_A5B11C11D6, ta_A5B11C12D6, 
                 ta_A5B12C1D7, ta_A5B12C1D8, ta_A5B12C2D7, ta_A5B12C2D8, ta_A5B12C3D7, 
                 ta_A5B12C3D8, ta_A5B12C4D9, ta_A5B12C4D10, ta_A5B12C6D11, ta_A5B12C6D12, 
                 ta_A5B12C7D1, ta_A5B12C7D2, ta_A5B12C7D3, ta_A5B12C8D1, ta_A5B12C8D2, 
                 ta_A5B12C8D3, ta_A5B12C9D4, ta_A5B12C10D4, ta_A5B12C11D6, ta_A5B12C12D6, 
                 ta_A5B13C4D7, ta_A5B13C4D8, ta_A5B13C7D4, ta_A5B13C8D4, ta_A5B14C4D7, 
                 ta_A5B14C4D8, ta_A5B14C7D4, ta_A5B14C8D4, ta_A5B15C4D6, ta_A5B15C6D4, 
                 ta_A5B15C7D7, ta_A5B15C7D8, ta_A5B15C8D7, ta_A5B15C8D8, ta_A6B1C1D15, 
                 ta_A6B1C2D15, ta_A6B1C3D15, ta_A6B1C11D13, ta_A6B1C11D14, ta_A6B1C12D13, 
                 ta_A6B1C12D14, ta_A6B1C13D11, ta_A6B1C13D12, ta_A6B1C14D11, ta_A6B1C14D12, 
                 ta_A6B1C15D1, ta_A6B1C15D2, ta_A6B1C15D3, ta_A6B2C1D15, ta_A6B2C2D15, 
                 ta_A6B2C3D15, ta_A6B2C11D13, ta_A6B2C11D14, ta_A6B2C12D13, ta_A6B2C12D14, 
                 ta_A6B2C13D11, ta_A6B2C13D12, ta_A6B2C14D11, ta_A6B2C14D12, ta_A6B2C15D1, 
                 ta_A6B2C15D2, ta_A6B2C15D3, ta_A6B3C1D15, ta_A6B3C2D15, ta_A6B3C3D15, 
                 ta_A6B3C11D13, ta_A6B3C11D14, ta_A6B3C12D13, ta_A6B3C12D14, ta_A6B3C13D11, 
                 ta_A6B3C13D12, ta_A6B3C14D11, ta_A6B3C14D12, ta_A6B3C15D1, ta_A6B3C15D2, 
                 ta_A6B3C15D3, ta_A6B4C5D15, ta_A6B4C13D13, ta_A6B4C13D14, ta_A6B4C14D13, 
                 ta_A6B4C14D14, ta_A6B4C15D5, ta_A6B5C4D15, ta_A6B5C11D11, ta_A6B5C11D12, 
                 ta_A6B5C12D11, ta_A6B5C12D12, ta_A6B5C15D4, ta_A6B6C15D15, ta_A6B7C13D15, 
                 ta_A6B7C14D15, ta_A6B7C15D13, ta_A6B7C15D14, ta_A6B8C13D15, ta_A6B8C14D15, 
                 ta_A6B8C15D13, ta_A6B8C15D14, ta_A6B9C11D15, ta_A6B9C12D15, ta_A6B9C15D11, 
                 ta_A6B9C15D12, ta_A6B10C11D15, ta_A6B10C12D15, ta_A6B10C15D11, ta_A6B10C15D12, 
                 ta_A6B11C1D13, ta_A6B11C1D14, ta_A6B11C2D13, ta_A6B11C2D14, ta_A6B11C3D13, 
                 ta_A6B11C3D14, ta_A6B11C5D11, ta_A6B11C5D12, ta_A6B11C9D15, ta_A6B11C10D15, 
                 ta_A6B11C11D5, ta_A6B11C12D5, ta_A6B11C13D1, ta_A6B11C13D2, ta_A6B11C13D3, 
                 ta_A6B11C14D1, ta_A6B11C14D2, ta_A6B11C14D3, ta_A6B11C15D9, ta_A6B11C15D10, 
                 ta_A6B12C1D13, ta_A6B12C1D14, ta_A6B12C2D13, ta_A6B12C2D14, ta_A6B12C3D13, 
                 ta_A6B12C3D14, ta_A6B12C5D11, ta_A6B12C5D12, ta_A6B12C9D15, ta_A6B12C10D15, 
                 ta_A6B12C11D5, ta_A6B12C12D5, ta_A6B12C13D1, ta_A6B12C13D2, ta_A6B12C13D3, 
                 ta_A6B12C14D1, ta_A6B12C14D2, ta_A6B12C14D3, ta_A6B12C15D9, ta_A6B12C15D10, 
                 ta_A6B13C1D11, ta_A6B13C1D12, ta_A6B13C2D11, ta_A6B13C2D12, ta_A6B13C3D11, 
                 ta_A6B13C3D12, ta_A6B13C4D13, ta_A6B13C4D14, ta_A6B13C7D15, ta_A6B13C8D15, 
                 ta_A6B13C11D1, ta_A6B13C11D2, ta_A6B13C11D3, ta_A6B13C12D1, ta_A6B13C12D2, 
                 ta_A6B13C12D3, ta_A6B13C13D4, ta_A6B13C14D4, ta_A6B13C15D7, ta_A6B13C15D8, 
                 ta_A6B14C1D11, ta_A6B14C1D12, ta_A6B14C2D11, ta_A6B14C2D12, ta_A6B14C3D11, 
                 ta_A6B14C3D12, ta_A6B14C4D13, ta_A6B14C4D14, ta_A6B14C7D15, ta_A6B14C8D15, 
                 ta_A6B14C11D1, ta_A6B14C11D2, ta_A6B14C11D3, ta_A6B14C12D1, ta_A6B14C12D2, 
                 ta_A6B14C12D3, ta_A6B14C13D4, ta_A6B14C14D4, ta_A6B14C15D7, ta_A6B14C15D8, 
                 ta_A6B15C1D1, ta_A6B15C1D2, ta_A6B15C1D3, ta_A6B15C2D1, ta_A6B15C2D2, 
                 ta_A6B15C2D3, ta_A6B15C3D1, ta_A6B15C3D2, ta_A6B15C3D3, ta_A6B15C4D5, 
                 ta_A6B15C5D4, ta_A6B15C6D15, ta_A6B15C7D13, ta_A6B15C7D14, ta_A6B15C8D13, 
                 ta_A6B15C8D14, ta_A6B15C9D11, ta_A6B15C9D12, ta_A6B15C10D11, ta_A6B15C10D12, 
                 ta_A6B15C11D9, ta_A6B15C11D10, ta_A6B15C12D9, ta_A6B15C12D10, ta_A6B15C13D7, 
                 ta_A6B15C13D8, ta_A6B15C14D7, ta_A6B15C14D8, ta_A6B15C15D6, ta_A7B1C1D13, 
                 ta_A7B1C1D14, ta_A7B1C2D13, ta_A7B1C2D14, ta_A7B1C3D13, ta_A7B1C3D14, 
                 ta_A7B1C5D11, ta_A7B1C5D12, ta_A7B1C9D15, ta_A7B1C10D15, ta_A7B1C11D5, 
                 ta_A7B1C12D5, ta_A7B1C13D1, ta_A7B1C13D2, ta_A7B1C13D3, ta_A7B1C14D1, 
                 ta_A7B1C14D2, ta_A7B1C14D3, ta_A7B1C15D9, ta_A7B1C15D10, ta_A7B2C1D13, 
                 ta_A7B2C1D14, ta_A7B2C2D13, ta_A7B2C2D14, ta_A7B2C3D13, ta_A7B2C3D14, 
                 ta_A7B2C5D11, ta_A7B2C5D12, ta_A7B2C9D15, ta_A7B2C10D15, ta_A7B2C11D5, 
                 ta_A7B2C12D5, ta_A7B2C13D1, ta_A7B2C13D2, ta_A7B2C13D3, ta_A7B2C14D1, 
                 ta_A7B2C14D2, ta_A7B2C14D3, ta_A7B2C15D9, ta_A7B2C15D10, ta_A7B3C1D13, 
                 ta_A7B3C1D14, ta_A7B3C2D13, ta_A7B3C2D14, ta_A7B3C3D13, ta_A7B3C3D14, 
                 ta_A7B3C5D11, ta_A7B3C5D12, ta_A7B3C9D15, ta_A7B3C10D15, ta_A7B3C11D5, 
                 ta_A7B3C12D5, ta_A7B3C13D1, ta_A7B3C13D2, ta_A7B3C13D3, ta_A7B3C14D1, 
                 ta_A7B3C14D2, ta_A7B3C14D3, ta_A7B3C15D9, ta_A7B3C15D10, ta_A7B4C5D13, 
                 ta_A7B4C5D14, ta_A7B4C13D5, ta_A7B4C14D5, ta_A7B5C1D11, ta_A7B5C1D12, 
                 ta_A7B5C2D11, ta_A7B5C2D12, ta_A7B5C3D11, ta_A7B5C3D12, ta_A7B5C4D13, 
                 ta_A7B5C4D14, ta_A7B5C7D15, ta_A7B5C8D15, ta_A7B5C11D1, ta_A7B5C11D2, 
                 ta_A7B5C11D3, ta_A7B5C12D1, ta_A7B5C12D2, ta_A7B5C12D3, ta_A7B5C13D4, 
                 ta_A7B5C14D4, ta_A7B5C15D7, ta_A7B5C15D8, ta_A7B6C13D15, ta_A7B6C14D15, 
                 ta_A7B6C15D13, ta_A7B6C15D14, ta_A7B7C5D15, ta_A7B7C13D13, ta_A7B7C13D14, 
                 ta_A7B7C14D13, ta_A7B7C14D14, ta_A7B7C15D5, ta_A7B8C5D15, ta_A7B8C13D13, 
                 ta_A7B8C13D14, ta_A7B8C14D13, ta_A7B8C14D14, ta_A7B8C15D5, ta_A7B9C1D15, 
                 ta_A7B9C2D15, ta_A7B9C3D15, ta_A7B9C11D13, ta_A7B9C11D14, ta_A7B9C12D13, 
                 ta_A7B9C12D14, ta_A7B9C13D11, ta_A7B9C13D12, ta_A7B9C14D11, ta_A7B9C14D12, 
                 ta_A7B9C15D1, ta_A7B9C15D2, ta_A7B9C15D3, ta_A7B10C1D15, ta_A7B10C2D15, 
                 ta_A7B10C3D15, ta_A7B10C11D13, ta_A7B10C11D14, ta_A7B10C12D13, ta_A7B10C12D14, 
                 ta_A7B10C13D11, ta_A7B10C13D12, ta_A7B10C14D11, ta_A7B10C14D12, ta_A7B10C15D1, 
                 ta_A7B10C15D2, ta_A7B10C15D3, ta_A7B11C1D5, ta_A7B11C2D5, ta_A7B11C3D5, 
                 ta_A7B11C5D1, ta_A7B11C5D2, ta_A7B11C5D3, ta_A7B11C9D13, ta_A7B11C9D14, 
                 ta_A7B11C10D13, ta_A7B11C10D14, ta_A7B11C13D9, ta_A7B11C13D10, ta_A7B11C14D9, 
                 ta_A7B11C14D10, ta_A7B12C1D5, ta_A7B12C2D5, ta_A7B12C3D5, ta_A7B12C5D1, 
                 ta_A7B12C5D2, ta_A7B12C5D3, ta_A7B12C9D13, ta_A7B12C9D14, ta_A7B12C10D13, 
                 ta_A7B12C10D14, ta_A7B12C13D9, ta_A7B12C13D10, ta_A7B12C14D9, ta_A7B12C14D10, 
                 ta_A7B13C1D1, ta_A7B13C1D2, ta_A7B13C1D3, ta_A7B13C2D1, ta_A7B13C2D2, 
                 ta_A7B13C2D3, ta_A7B13C3D1, ta_A7B13C3D2, ta_A7B13C3D3, ta_A7B13C4D5, 
                 ta_A7B13C5D4, ta_A7B13C6D15, ta_A7B13C7D13, ta_A7B13C7D14, ta_A7B13C8D13, 
                 ta_A7B13C8D14, ta_A7B13C9D11, ta_A7B13C9D12, ta_A7B13C10D11, ta_A7B13C10D12, 
                 ta_A7B13C11D9, ta_A7B13C11D10, ta_A7B13C12D9, ta_A7B13C12D10, ta_A7B13C13D7, 
                 ta_A7B13C13D8, ta_A7B13C14D7, ta_A7B13C14D8, ta_A7B13C15D6, ta_A7B14C1D1, 
                 ta_A7B14C1D2, ta_A7B14C1D3, ta_A7B14C2D1, ta_A7B14C2D2, ta_A7B14C2D3, 
                 ta_A7B14C3D1, ta_A7B14C3D2, ta_A7B14C3D3, ta_A7B14C4D5, ta_A7B14C5D4, 
                 ta_A7B14C6D15, ta_A7B14C7D13, ta_A7B14C7D14, ta_A7B14C8D13, ta_A7B14C8D14, 
                 ta_A7B14C9D11, ta_A7B14C9D12, ta_A7B14C10D11, ta_A7B14C10D12, ta_A7B14C11D9, 
                 ta_A7B14C11D10, ta_A7B14C12D9, ta_A7B14C12D10, ta_A7B14C13D7, ta_A7B14C13D8, 
                 ta_A7B14C14D7, ta_A7B14C14D8, ta_A7B14C15D6, ta_A7B15C1D9, ta_A7B15C1D10, 
                 ta_A7B15C2D9, ta_A7B15C2D10, ta_A7B15C3D9, ta_A7B15C3D10, ta_A7B15C5D7, 
                 ta_A7B15C5D8, ta_A7B15C6D13, ta_A7B15C6D14, ta_A7B15C7D5, ta_A7B15C8D5, 
                 ta_A7B15C9D1, ta_A7B15C9D2, ta_A7B15C9D3, ta_A7B15C10D1, ta_A7B15C10D2, 
                 ta_A7B15C10D3, ta_A7B15C13D6, ta_A7B15C14D6, ta_A8B1C1D13, ta_A8B1C1D14, 
                 ta_A8B1C2D13, ta_A8B1C2D14, ta_A8B1C3D13, ta_A8B1C3D14, ta_A8B1C5D11, 
                 ta_A8B1C5D12, ta_A8B1C9D15, ta_A8B1C10D15, ta_A8B1C11D5, ta_A8B1C12D5, 
                 ta_A8B1C13D1, ta_A8B1C13D2, ta_A8B1C13D3, ta_A8B1C14D1, ta_A8B1C14D2, 
                 ta_A8B1C14D3, ta_A8B1C15D9, ta_A8B1C15D10, ta_A8B2C1D13, ta_A8B2C1D14, 
                 ta_A8B2C2D13, ta_A8B2C2D14, ta_A8B2C3D13, ta_A8B2C3D14, ta_A8B2C5D11, 
                 ta_A8B2C5D12, ta_A8B2C9D15, ta_A8B2C10D15, ta_A8B2C11D5, ta_A8B2C12D5, 
                 ta_A8B2C13D1, ta_A8B2C13D2, ta_A8B2C13D3, ta_A8B2C14D1, ta_A8B2C14D2, 
                 ta_A8B2C14D3, ta_A8B2C15D9, ta_A8B2C15D10, ta_A8B3C1D13, ta_A8B3C1D14, 
                 ta_A8B3C2D13, ta_A8B3C2D14, ta_A8B3C3D13, ta_A8B3C3D14, ta_A8B3C5D11, 
                 ta_A8B3C5D12, ta_A8B3C9D15, ta_A8B3C10D15, ta_A8B3C11D5, ta_A8B3C12D5, 
                 ta_A8B3C13D1, ta_A8B3C13D2, ta_A8B3C13D3, ta_A8B3C14D1, ta_A8B3C14D2, 
                 ta_A8B3C14D3, ta_A8B3C15D9, ta_A8B3C15D10, ta_A8B4C5D13, ta_A8B4C5D14, 
                 ta_A8B4C13D5, ta_A8B4C14D5, ta_A8B5C1D11, ta_A8B5C1D12, ta_A8B5C2D11, 
                 ta_A8B5C2D12, ta_A8B5C3D11, ta_A8B5C3D12, ta_A8B5C4D13, ta_A8B5C4D14, 
                 ta_A8B5C7D15, ta_A8B5C8D15, ta_A8B5C11D1, ta_A8B5C11D2, ta_A8B5C11D3, 
                 ta_A8B5C12D1, ta_A8B5C12D2, ta_A8B5C12D3, ta_A8B5C13D4, ta_A8B5C14D4, 
                 ta_A8B5C15D7, ta_A8B5C15D8, ta_A8B6C13D15, ta_A8B6C14D15, ta_A8B6C15D13, 
                 ta_A8B6C15D14, ta_A8B7C5D15, ta_A8B7C13D13, ta_A8B7C13D14, ta_A8B7C14D13, 
                 ta_A8B7C14D14, ta_A8B7C15D5, ta_A8B8C5D15, ta_A8B8C13D13, ta_A8B8C13D14, 
                 ta_A8B8C14D13, ta_A8B8C14D14, ta_A8B8C15D5, ta_A8B9C1D15, ta_A8B9C2D15, 
                 ta_A8B9C3D15, ta_A8B9C11D13, ta_A8B9C11D14, ta_A8B9C12D13, ta_A8B9C12D14, 
                 ta_A8B9C13D11, ta_A8B9C13D12, ta_A8B9C14D11, ta_A8B9C14D12, ta_A8B9C15D1, 
                 ta_A8B9C15D2, ta_A8B9C15D3, ta_A8B10C1D15, ta_A8B10C2D15, ta_A8B10C3D15, 
                 ta_A8B10C11D13, ta_A8B10C11D14, ta_A8B10C12D13, ta_A8B10C12D14, ta_A8B10C13D11, 
                 ta_A8B10C13D12, ta_A8B10C14D11, ta_A8B10C14D12, ta_A8B10C15D1, ta_A8B10C15D2, 
                 ta_A8B10C15D3, ta_A8B11C1D5, ta_A8B11C2D5, ta_A8B11C3D5, ta_A8B11C5D1, 
                 ta_A8B11C5D2, ta_A8B11C5D3, ta_A8B11C9D13, ta_A8B11C9D14, ta_A8B11C10D13, 
                 ta_A8B11C10D14, ta_A8B11C13D9, ta_A8B11C13D10, ta_A8B11C14D9, ta_A8B11C14D10, 
                 ta_A8B12C1D5, ta_A8B12C2D5, ta_A8B12C3D5, ta_A8B12C5D1, ta_A8B12C5D2, 
                 ta_A8B12C5D3, ta_A8B12C9D13, ta_A8B12C9D14, ta_A8B12C10D13, ta_A8B12C10D14, 
                 ta_A8B12C13D9, ta_A8B12C13D10, ta_A8B12C14D9, ta_A8B12C14D10, ta_A8B13C1D1, 
                 ta_A8B13C1D2, ta_A8B13C1D3, ta_A8B13C2D1, ta_A8B13C2D2, ta_A8B13C2D3, 
                 ta_A8B13C3D1, ta_A8B13C3D2, ta_A8B13C3D3, ta_A8B13C4D5, ta_A8B13C5D4, 
                 ta_A8B13C6D15, ta_A8B13C7D13, ta_A8B13C7D14, ta_A8B13C8D13, ta_A8B13C8D14, 
                 ta_A8B13C9D11, ta_A8B13C9D12, ta_A8B13C10D11, ta_A8B13C10D12, ta_A8B13C11D9, 
                 ta_A8B13C11D10, ta_A8B13C12D9, ta_A8B13C12D10, ta_A8B13C13D7, ta_A8B13C13D8, 
                 ta_A8B13C14D7, ta_A8B13C14D8, ta_A8B13C15D6, ta_A8B14C1D1, ta_A8B14C1D2, 
                 ta_A8B14C1D3, ta_A8B14C2D1, ta_A8B14C2D2, ta_A8B14C2D3, ta_A8B14C3D1, 
                 ta_A8B14C3D2, ta_A8B14C3D3, ta_A8B14C4D5, ta_A8B14C5D4, ta_A8B14C6D15, 
                 ta_A8B14C7D13, ta_A8B14C7D14, ta_A8B14C8D13, ta_A8B14C8D14, ta_A8B14C9D11, 
                 ta_A8B14C9D12, ta_A8B14C10D11, ta_A8B14C10D12, ta_A8B14C11D9, ta_A8B14C11D10, 
                 ta_A8B14C12D9, ta_A8B14C12D10, ta_A8B14C13D7, ta_A8B14C13D8, ta_A8B14C14D7, 
                 ta_A8B14C14D8, ta_A8B14C15D6, ta_A8B15C1D9, ta_A8B15C1D10, ta_A8B15C2D9, 
                 ta_A8B15C2D10, ta_A8B15C3D9, ta_A8B15C3D10, ta_A8B15C5D7, ta_A8B15C5D8, 
                 ta_A8B15C6D13, ta_A8B15C6D14, ta_A8B15C7D5, ta_A8B15C8D5, ta_A8B15C9D1, 
                 ta_A8B15C9D2, ta_A8B15C9D3, ta_A8B15C10D1, ta_A8B15C10D2, ta_A8B15C10D3, 
                 ta_A8B15C13D6, ta_A8B15C14D6, ta_A9B1C1D11, ta_A9B1C1D12, ta_A9B1C2D11, 
                 ta_A9B1C2D12, ta_A9B1C3D11, ta_A9B1C3D12, ta_A9B1C4D13, ta_A9B1C4D14, 
                 ta_A9B1C7D15, ta_A9B1C8D15, ta_A9B1C11D1, ta_A9B1C11D2, ta_A9B1C11D3, 
                 ta_A9B1C12D1, ta_A9B1C12D2, ta_A9B1C12D3, ta_A9B1C13D4, ta_A9B1C14D4, 
                 ta_A9B1C15D7, ta_A9B1C15D8, ta_A9B2C1D11, ta_A9B2C1D12, ta_A9B2C2D11, 
                 ta_A9B2C2D12, ta_A9B2C3D11, ta_A9B2C3D12, ta_A9B2C4D13, ta_A9B2C4D14, 
                 ta_A9B2C7D15, ta_A9B2C8D15, ta_A9B2C11D1, ta_A9B2C11D2, ta_A9B2C11D3, 
                 ta_A9B2C12D1, ta_A9B2C12D2, ta_A9B2C12D3, ta_A9B2C13D4, ta_A9B2C14D4, 
                 ta_A9B2C15D7, ta_A9B2C15D8, ta_A9B3C1D11, ta_A9B3C1D12, ta_A9B3C2D11, 
                 ta_A9B3C2D12, ta_A9B3C3D11, ta_A9B3C3D12, ta_A9B3C4D13, ta_A9B3C4D14, 
                 ta_A9B3C7D15, ta_A9B3C8D15, ta_A9B3C11D1, ta_A9B3C11D2, ta_A9B3C11D3, 
                 ta_A9B3C12D1, ta_A9B3C12D2, ta_A9B3C12D3, ta_A9B3C13D4, ta_A9B3C14D4, 
                 ta_A9B3C15D7, ta_A9B3C15D8, ta_A9B4C1D13, ta_A9B4C1D14, ta_A9B4C2D13, 
                 ta_A9B4C2D14, ta_A9B4C3D13, ta_A9B4C3D14, ta_A9B4C5D11, ta_A9B4C5D12, 
                 ta_A9B4C9D15, ta_A9B4C10D15, ta_A9B4C11D5, ta_A9B4C12D5, ta_A9B4C13D1, 
                 ta_A9B4C13D2, ta_A9B4C13D3, ta_A9B4C14D1, ta_A9B4C14D2, ta_A9B4C14D3, 
                 ta_A9B4C15D9, ta_A9B4C15D10, ta_A9B5C4D11, ta_A9B5C4D12, ta_A9B5C11D4, 
                 ta_A9B5C12D4, ta_A9B6C11D15, ta_A9B6C12D15, ta_A9B6C15D11, ta_A9B6C15D12, 
                 ta_A9B7C1D15, ta_A9B7C2D15, ta_A9B7C3D15, ta_A9B7C11D13, ta_A9B7C11D14, 
                 ta_A9B7C12D13, ta_A9B7C12D14, ta_A9B7C13D11, ta_A9B7C13D12, ta_A9B7C14D11, 
                 ta_A9B7C14D12, ta_A9B7C15D1, ta_A9B7C15D2, ta_A9B7C15D3, ta_A9B8C1D15, 
                 ta_A9B8C2D15, ta_A9B8C3D15, ta_A9B8C11D13, ta_A9B8C11D14, ta_A9B8C12D13, 
                 ta_A9B8C12D14, ta_A9B8C13D11, ta_A9B8C13D12, ta_A9B8C14D11, ta_A9B8C14D12, 
                 ta_A9B8C15D1, ta_A9B8C15D2, ta_A9B8C15D3, ta_A9B9C4D15, ta_A9B9C11D11, 
                 ta_A9B9C11D12, ta_A9B9C12D11, ta_A9B9C12D12, ta_A9B9C15D4, ta_A9B10C4D15, 
                 ta_A9B10C11D11, ta_A9B10C11D12, ta_A9B10C12D11, ta_A9B10C12D12, ta_A9B10C15D4, 
                 ta_A9B11C1D1, ta_A9B11C1D2, ta_A9B11C1D3, ta_A9B11C2D1, ta_A9B11C2D2, 
                 ta_A9B11C2D3, ta_A9B11C3D1, ta_A9B11C3D2, ta_A9B11C3D3, ta_A9B11C4D5, 
                 ta_A9B11C5D4, ta_A9B11C6D15, ta_A9B11C7D13, ta_A9B11C7D14, ta_A9B11C8D13, 
                 ta_A9B11C8D14, ta_A9B11C9D11, ta_A9B11C9D12, ta_A9B11C10D11, ta_A9B11C10D12, 
                 ta_A9B11C11D9, ta_A9B11C11D10, ta_A9B11C12D9, ta_A9B11C12D10, ta_A9B11C13D7, 
                 ta_A9B11C13D8, ta_A9B11C14D7, ta_A9B11C14D8, ta_A9B11C15D6, ta_A9B12C1D1, 
                 ta_A9B12C1D2, ta_A9B12C1D3, ta_A9B12C2D1, ta_A9B12C2D2, ta_A9B12C2D3, 
                 ta_A9B12C3D1, ta_A9B12C3D2, ta_A9B12C3D3, ta_A9B12C4D5, ta_A9B12C5D4, 
                 ta_A9B12C6D15, ta_A9B12C7D13, ta_A9B12C7D14, ta_A9B12C8D13, ta_A9B12C8D14, 
                 ta_A9B12C9D11, ta_A9B12C9D12, ta_A9B12C10D11, ta_A9B12C10D12, ta_A9B12C11D9, 
                 ta_A9B12C11D10, ta_A9B12C12D9, ta_A9B12C12D10, ta_A9B12C13D7, ta_A9B12C13D8, 
                 ta_A9B12C14D7, ta_A9B12C14D8, ta_A9B12C15D6, ta_A9B13C1D4, ta_A9B13C2D4, 
                 ta_A9B13C3D4, ta_A9B13C4D1, ta_A9B13C4D2, ta_A9B13C4D3, ta_A9B13C7D11, 
                 ta_A9B13C7D12, ta_A9B13C8D11, ta_A9B13C8D12, ta_A9B13C11D7, ta_A9B13C11D8, 
                 ta_A9B13C12D7, ta_A9B13C12D8, ta_A9B14C1D4, ta_A9B14C2D4, ta_A9B14C3D4, 
                 ta_A9B14C4D1, ta_A9B14C4D2, ta_A9B14C4D3, ta_A9B14C7D11, ta_A9B14C7D12, 
                 ta_A9B14C8D11, ta_A9B14C8D12, ta_A9B14C11D7, ta_A9B14C11D8, ta_A9B14C12D7, 
                 ta_A9B14C12D8, ta_A9B15C1D7, ta_A9B15C1D8, ta_A9B15C2D7, ta_A9B15C2D8, 
                 ta_A9B15C3D7, ta_A9B15C3D8, ta_A9B15C4D9, ta_A9B15C4D10, ta_A9B15C6D11, 
                 ta_A9B15C6D12, ta_A9B15C7D1, ta_A9B15C7D2, ta_A9B15C7D3, ta_A9B15C8D1, 
                 ta_A9B15C8D2, ta_A9B15C8D3, ta_A9B15C9D4, ta_A9B15C10D4, ta_A9B15C11D6, 
                 ta_A9B15C12D6, ta_A10B1C1D11, ta_A10B1C1D12, ta_A10B1C2D11, ta_A10B1C2D12, 
                 ta_A10B1C3D11, ta_A10B1C3D12, ta_A10B1C4D13, ta_A10B1C4D14, ta_A10B1C7D15, 
                 ta_A10B1C8D15, ta_A10B1C11D1, ta_A10B1C11D2, ta_A10B1C11D3, ta_A10B1C12D1, 
                 ta_A10B1C12D2, ta_A10B1C12D3, ta_A10B1C13D4, ta_A10B1C14D4, ta_A10B1C15D7, 
                 ta_A10B1C15D8, ta_A10B2C1D11, ta_A10B2C1D12, ta_A10B2C2D11, ta_A10B2C2D12, 
                 ta_A10B2C3D11, ta_A10B2C3D12, ta_A10B2C4D13, ta_A10B2C4D14, ta_A10B2C7D15, 
                 ta_A10B2C8D15, ta_A10B2C11D1, ta_A10B2C11D2, ta_A10B2C11D3, ta_A10B2C12D1, 
                 ta_A10B2C12D2, ta_A10B2C12D3, ta_A10B2C13D4, ta_A10B2C14D4, ta_A10B2C15D7, 
                 ta_A10B2C15D8, ta_A10B3C1D11, ta_A10B3C1D12, ta_A10B3C2D11, ta_A10B3C2D12, 
                 ta_A10B3C3D11, ta_A10B3C3D12, ta_A10B3C4D13, ta_A10B3C4D14, ta_A10B3C7D15, 
                 ta_A10B3C8D15, ta_A10B3C11D1, ta_A10B3C11D2, ta_A10B3C11D3, ta_A10B3C12D1, 
                 ta_A10B3C12D2, ta_A10B3C12D3, ta_A10B3C13D4, ta_A10B3C14D4, ta_A10B3C15D7, 
                 ta_A10B3C15D8, ta_A10B4C1D13, ta_A10B4C1D14, ta_A10B4C2D13, ta_A10B4C2D14, 
                 ta_A10B4C3D13, ta_A10B4C3D14, ta_A10B4C5D11, ta_A10B4C5D12, ta_A10B4C9D15, 
                 ta_A10B4C10D15, ta_A10B4C11D5, ta_A10B4C12D5, ta_A10B4C13D1, ta_A10B4C13D2, 
                 ta_A10B4C13D3, ta_A10B4C14D1, ta_A10B4C14D2, ta_A10B4C14D3, ta_A10B4C15D9, 
                 ta_A10B4C15D10, ta_A10B5C4D11, ta_A10B5C4D12, ta_A10B5C11D4, ta_A10B5C12D4, 
                 ta_A10B6C11D15, ta_A10B6C12D15, ta_A10B6C15D11, ta_A10B6C15D12, ta_A10B7C1D15, 
                 ta_A10B7C2D15, ta_A10B7C3D15, ta_A10B7C11D13, ta_A10B7C11D14, ta_A10B7C12D13, 
                 ta_A10B7C12D14, ta_A10B7C13D11, ta_A10B7C13D12, ta_A10B7C14D11, ta_A10B7C14D12, 
                 ta_A10B7C15D1, ta_A10B7C15D2, ta_A10B7C15D3, ta_A10B8C1D15, ta_A10B8C2D15, 
                 ta_A10B8C3D15, ta_A10B8C11D13, ta_A10B8C11D14, ta_A10B8C12D13, ta_A10B8C12D14, 
                 ta_A10B8C13D11, ta_A10B8C13D12, ta_A10B8C14D11, ta_A10B8C14D12, ta_A10B8C15D1, 
                 ta_A10B8C15D2, ta_A10B8C15D3, ta_A10B9C4D15, ta_A10B9C11D11, ta_A10B9C11D12, 
                 ta_A10B9C12D11, ta_A10B9C12D12, ta_A10B9C15D4, ta_A10B10C4D15, ta_A10B10C11D11, 
                 ta_A10B10C11D12, ta_A10B10C12D11, ta_A10B10C12D12, ta_A10B10C15D4, ta_A10B11C1D1, 
                 ta_A10B11C1D2, ta_A10B11C1D3, ta_A10B11C2D1, ta_A10B11C2D2, ta_A10B11C2D3, 
                 ta_A10B11C3D1, ta_A10B11C3D2, ta_A10B11C3D3, ta_A10B11C4D5, ta_A10B11C5D4, 
                 ta_A10B11C6D15, ta_A10B11C7D13, ta_A10B11C7D14, ta_A10B11C8D13, ta_A10B11C8D14, 
                 ta_A10B11C9D11, ta_A10B11C9D12, ta_A10B11C10D11, ta_A10B11C10D12, ta_A10B11C11D9, 
                 ta_A10B11C11D10, ta_A10B11C12D9, ta_A10B11C12D10, ta_A10B11C13D7, ta_A10B11C13D8, 
                 ta_A10B11C14D7, ta_A10B11C14D8, ta_A10B11C15D6, ta_A10B12C1D1, ta_A10B12C1D2, 
                 ta_A10B12C1D3, ta_A10B12C2D1, ta_A10B12C2D2, ta_A10B12C2D3, ta_A10B12C3D1, 
                 ta_A10B12C3D2, ta_A10B12C3D3, ta_A10B12C4D5, ta_A10B12C5D4, ta_A10B12C6D15, 
                 ta_A10B12C7D13, ta_A10B12C7D14, ta_A10B12C8D13, ta_A10B12C8D14, ta_A10B12C9D11, 
                 ta_A10B12C9D12, ta_A10B12C10D11, ta_A10B12C10D12, ta_A10B12C11D9, ta_A10B12C11D10, 
                 ta_A10B12C12D9, ta_A10B12C12D10, ta_A10B12C13D7, ta_A10B12C13D8, ta_A10B12C14D7, 
                 ta_A10B12C14D8, ta_A10B12C15D6, ta_A10B13C1D4, ta_A10B13C2D4, ta_A10B13C3D4, 
                 ta_A10B13C4D1, ta_A10B13C4D2, ta_A10B13C4D3, ta_A10B13C7D11, ta_A10B13C7D12, 
                 ta_A10B13C8D11, ta_A10B13C8D12, ta_A10B13C11D7, ta_A10B13C11D8, ta_A10B13C12D7, 
                 ta_A10B13C12D8, ta_A10B14C1D4, ta_A10B14C2D4, ta_A10B14C3D4, ta_A10B14C4D1, 
                 ta_A10B14C4D2, ta_A10B14C4D3, ta_A10B14C7D11, ta_A10B14C7D12, ta_A10B14C8D11, 
                 ta_A10B14C8D12, ta_A10B14C11D7, ta_A10B14C11D8, ta_A10B14C12D7, ta_A10B14C12D8, 
                 ta_A10B15C1D7, ta_A10B15C1D8, ta_A10B15C2D7, ta_A10B15C2D8, ta_A10B15C3D7, 
                 ta_A10B15C3D8, ta_A10B15C4D9, ta_A10B15C4D10, ta_A10B15C6D11, ta_A10B15C6D12, 
                 ta_A10B15C7D1, ta_A10B15C7D2, ta_A10B15C7D3, ta_A10B15C8D1, ta_A10B15C8D2, 
                 ta_A10B15C8D3, ta_A10B15C9D4, ta_A10B15C10D4, ta_A10B15C11D6, ta_A10B15C12D6, 
                 ta_A11B1C1D9, ta_A11B1C1D10, ta_A11B1C2D9, ta_A11B1C2D10, ta_A11B1C3D9, 
                 ta_A11B1C3D10, ta_A11B1C5D7, ta_A11B1C5D8, ta_A11B1C6D13, ta_A11B1C6D14, 
                 ta_A11B1C7D5, ta_A11B1C8D5, ta_A11B1C9D1, ta_A11B1C9D2, ta_A11B1C9D3, 
                 ta_A11B1C10D1, ta_A11B1C10D2, ta_A11B1C10D3, ta_A11B1C13D6, ta_A11B1C14D6, 
                 ta_A11B2C1D9, ta_A11B2C1D10, ta_A11B2C2D9, ta_A11B2C2D10, ta_A11B2C3D9, 
                 ta_A11B2C3D10, ta_A11B2C5D7, ta_A11B2C5D8, ta_A11B2C6D13, ta_A11B2C6D14, 
                 ta_A11B2C7D5, ta_A11B2C8D5, ta_A11B2C9D1, ta_A11B2C9D2, ta_A11B2C9D3, 
                 ta_A11B2C10D1, ta_A11B2C10D2, ta_A11B2C10D3, ta_A11B2C13D6, ta_A11B2C14D6, 
                 ta_A11B3C1D9, ta_A11B3C1D10, ta_A11B3C2D9, ta_A11B3C2D10, ta_A11B3C3D9, 
                 ta_A11B3C3D10, ta_A11B3C5D7, ta_A11B3C5D8, ta_A11B3C6D13, ta_A11B3C6D14, 
                 ta_A11B3C7D5, ta_A11B3C8D5, ta_A11B3C9D1, ta_A11B3C9D2, ta_A11B3C9D3, 
                 ta_A11B3C10D1, ta_A11B3C10D2, ta_A11B3C10D3, ta_A11B3C13D6, ta_A11B3C14D6, 
                 ta_A11B4C5D9, ta_A11B4C5D10, ta_A11B4C9D5, ta_A11B4C10D5, ta_A11B5C1D7, 
                 ta_A11B5C1D8, ta_A11B5C2D7, ta_A11B5C2D8, ta_A11B5C3D7, ta_A11B5C3D8, 
                 ta_A11B5C4D9, ta_A11B5C4D10, ta_A11B5C6D11, ta_A11B5C6D12, ta_A11B5C7D1, 
                 ta_A11B5C7D2, ta_A11B5C7D3, ta_A11B5C8D1, ta_A11B5C8D2, ta_A11B5C8D3, 
                 ta_A11B5C9D4, ta_A11B5C10D4, ta_A11B5C11D6, ta_A11B5C12D6, ta_A11B6C1D13, 
                 ta_A11B6C1D14, ta_A11B6C2D13, ta_A11B6C2D14, ta_A11B6C3D13, ta_A11B6C3D14, 
                 ta_A11B6C5D11, ta_A11B6C5D12, ta_A11B6C9D15, ta_A11B6C10D15, ta_A11B6C11D5, 
                 ta_A11B6C12D5, ta_A11B6C13D1, ta_A11B6C13D2, ta_A11B6C13D3, ta_A11B6C14D1, 
                 ta_A11B6C14D2, ta_A11B6C14D3, ta_A11B6C15D9, ta_A11B6C15D10, ta_A11B7C1D5, 
                 ta_A11B7C2D5, ta_A11B7C3D5, ta_A11B7C5D1, ta_A11B7C5D2, ta_A11B7C5D3, 
                 ta_A11B7C9D13, ta_A11B7C9D14, ta_A11B7C10D13, ta_A11B7C10D14, ta_A11B7C13D9, 
                 ta_A11B7C13D10, ta_A11B7C14D9, ta_A11B7C14D10, ta_A11B8C1D5, ta_A11B8C2D5, 
                 ta_A11B8C3D5, ta_A11B8C5D1, ta_A11B8C5D2, ta_A11B8C5D3, ta_A11B8C9D13, 
                 ta_A11B8C9D14, ta_A11B8C10D13, ta_A11B8C10D14, ta_A11B8C13D9, ta_A11B8C13D10, 
                 ta_A11B8C14D9, ta_A11B8C14D10, ta_A11B9C1D1, ta_A11B9C1D2, ta_A11B9C1D3, 
                 ta_A11B9C2D1, ta_A11B9C2D2, ta_A11B9C2D3, ta_A11B9C3D1, ta_A11B9C3D2, 
                 ta_A11B9C3D3, ta_A11B9C4D5, ta_A11B9C5D4, ta_A11B9C6D15, ta_A11B9C7D13, 
                 ta_A11B9C7D14, ta_A11B9C8D13, ta_A11B9C8D14, ta_A11B9C9D11, ta_A11B9C9D12, 
                 ta_A11B9C10D11, ta_A11B9C10D12, ta_A11B9C11D9, ta_A11B9C11D10, ta_A11B9C12D9, 
                 ta_A11B9C12D10, ta_A11B9C13D7, ta_A11B9C13D8, ta_A11B9C14D7, ta_A11B9C14D8, 
                 ta_A11B9C15D6, ta_A11B10C1D1, ta_A11B10C1D2, ta_A11B10C1D3, ta_A11B10C2D1, 
                 ta_A11B10C2D2, ta_A11B10C2D3, ta_A11B10C3D1, ta_A11B10C3D2, ta_A11B10C3D3, 
                 ta_A11B10C4D5, ta_A11B10C5D4, ta_A11B10C6D15, ta_A11B10C7D13, ta_A11B10C7D14, 
                 ta_A11B10C8D13, ta_A11B10C8D14, ta_A11B10C9D11, ta_A11B10C9D12, ta_A11B10C10D11, 
                 ta_A11B10C10D12, ta_A11B10C11D9, ta_A11B10C11D10, ta_A11B10C12D9, ta_A11B10C12D10, 
                 ta_A11B10C13D7, ta_A11B10C13D8, ta_A11B10C14D7, ta_A11B10C14D8, ta_A11B10C15D6, 
                 ta_A11B11C5D6, ta_A11B11C6D5, ta_A11B11C9D9, ta_A11B11C9D10, ta_A11B11C10D9, 
                 ta_A11B11C10D10, ta_A11B12C5D6, ta_A11B12C6D5, ta_A11B12C9D9, ta_A11B12C9D10, 
                 ta_A11B12C10D9, ta_A11B12C10D10, ta_A11B13C1D6, ta_A11B13C2D6, ta_A11B13C3D6, 
                 ta_A11B13C6D1, ta_A11B13C6D2, ta_A11B13C6D3, ta_A11B13C7D9, ta_A11B13C7D10, 
                 ta_A11B13C8D9, ta_A11B13C8D10, ta_A11B13C9D7, ta_A11B13C9D8, ta_A11B13C10D7, 
                 ta_A11B13C10D8, ta_A11B14C1D6, ta_A11B14C2D6, ta_A11B14C3D6, ta_A11B14C6D1, 
                 ta_A11B14C6D2, ta_A11B14C6D3, ta_A11B14C7D9, ta_A11B14C7D10, ta_A11B14C8D9, 
                 ta_A11B14C8D10, ta_A11B14C9D7, ta_A11B14C9D8, ta_A11B14C10D7, ta_A11B14C10D8, 
                 ta_A11B15C6D9, ta_A11B15C6D10, ta_A11B15C9D6, ta_A11B15C10D6, ta_A12B1C1D9, 
                 ta_A12B1C1D10, ta_A12B1C2D9, ta_A12B1C2D10, ta_A12B1C3D9, ta_A12B1C3D10, 
                 ta_A12B1C5D7, ta_A12B1C5D8, ta_A12B1C6D13, ta_A12B1C6D14, ta_A12B1C7D5, 
                 ta_A12B1C8D5, ta_A12B1C9D1, ta_A12B1C9D2, ta_A12B1C9D3, ta_A12B1C10D1, 
                 ta_A12B1C10D2, ta_A12B1C10D3, ta_A12B1C13D6, ta_A12B1C14D6, ta_A12B2C1D9, 
                 ta_A12B2C1D10, ta_A12B2C2D9, ta_A12B2C2D10, ta_A12B2C3D9, ta_A12B2C3D10, 
                 ta_A12B2C5D7, ta_A12B2C5D8, ta_A12B2C6D13, ta_A12B2C6D14, ta_A12B2C7D5, 
                 ta_A12B2C8D5, ta_A12B2C9D1, ta_A12B2C9D2, ta_A12B2C9D3, ta_A12B2C10D1, 
                 ta_A12B2C10D2, ta_A12B2C10D3, ta_A12B2C13D6, ta_A12B2C14D6, ta_A12B3C1D9, 
                 ta_A12B3C1D10, ta_A12B3C2D9, ta_A12B3C2D10, ta_A12B3C3D9, ta_A12B3C3D10, 
                 ta_A12B3C5D7, ta_A12B3C5D8, ta_A12B3C6D13, ta_A12B3C6D14, ta_A12B3C7D5, 
                 ta_A12B3C8D5, ta_A12B3C9D1, ta_A12B3C9D2, ta_A12B3C9D3, ta_A12B3C10D1, 
                 ta_A12B3C10D2, ta_A12B3C10D3, ta_A12B3C13D6, ta_A12B3C14D6, ta_A12B4C5D9, 
                 ta_A12B4C5D10, ta_A12B4C9D5, ta_A12B4C10D5, ta_A12B5C1D7, ta_A12B5C1D8, 
                 ta_A12B5C2D7, ta_A12B5C2D8, ta_A12B5C3D7, ta_A12B5C3D8, ta_A12B5C4D9, 
                 ta_A12B5C4D10, ta_A12B5C6D11, ta_A12B5C6D12, ta_A12B5C7D1, ta_A12B5C7D2, 
                 ta_A12B5C7D3, ta_A12B5C8D1, ta_A12B5C8D2, ta_A12B5C8D3, ta_A12B5C9D4, 
                 ta_A12B5C10D4, ta_A12B5C11D6, ta_A12B5C12D6, ta_A12B6C1D13, ta_A12B6C1D14, 
                 ta_A12B6C2D13, ta_A12B6C2D14, ta_A12B6C3D13, ta_A12B6C3D14, ta_A12B6C5D11, 
                 ta_A12B6C5D12, ta_A12B6C9D15, ta_A12B6C10D15, ta_A12B6C11D5, ta_A12B6C12D5, 
                 ta_A12B6C13D1, ta_A12B6C13D2, ta_A12B6C13D3, ta_A12B6C14D1, ta_A12B6C14D2, 
                 ta_A12B6C14D3, ta_A12B6C15D9, ta_A12B6C15D10, ta_A12B7C1D5, ta_A12B7C2D5, 
                 ta_A12B7C3D5, ta_A12B7C5D1, ta_A12B7C5D2, ta_A12B7C5D3, ta_A12B7C9D13, 
                 ta_A12B7C9D14, ta_A12B7C10D13, ta_A12B7C10D14, ta_A12B7C13D9, ta_A12B7C13D10, 
                 ta_A12B7C14D9, ta_A12B7C14D10, ta_A12B8C1D5, ta_A12B8C2D5, ta_A12B8C3D5, 
                 ta_A12B8C5D1, ta_A12B8C5D2, ta_A12B8C5D3, ta_A12B8C9D13, ta_A12B8C9D14, 
                 ta_A12B8C10D13, ta_A12B8C10D14, ta_A12B8C13D9, ta_A12B8C13D10, ta_A12B8C14D9, 
                 ta_A12B8C14D10, ta_A12B9C1D1, ta_A12B9C1D2, ta_A12B9C1D3, ta_A12B9C2D1, 
                 ta_A12B9C2D2, ta_A12B9C2D3, ta_A12B9C3D1, ta_A12B9C3D2, ta_A12B9C3D3, 
                 ta_A12B9C4D5, ta_A12B9C5D4, ta_A12B9C6D15, ta_A12B9C7D13, ta_A12B9C7D14, 
                 ta_A12B9C8D13, ta_A12B9C8D14, ta_A12B9C9D11, ta_A12B9C9D12, ta_A12B9C10D11, 
                 ta_A12B9C10D12, ta_A12B9C11D9, ta_A12B9C11D10, ta_A12B9C12D9, ta_A12B9C12D10, 
                 ta_A12B9C13D7, ta_A12B9C13D8, ta_A12B9C14D7, ta_A12B9C14D8, ta_A12B9C15D6, 
                 ta_A12B10C1D1, ta_A12B10C1D2, ta_A12B10C1D3, ta_A12B10C2D1, ta_A12B10C2D2, 
                 ta_A12B10C2D3, ta_A12B10C3D1, ta_A12B10C3D2, ta_A12B10C3D3, ta_A12B10C4D5, 
                 ta_A12B10C5D4, ta_A12B10C6D15, ta_A12B10C7D13, ta_A12B10C7D14, ta_A12B10C8D13, 
                 ta_A12B10C8D14, ta_A12B10C9D11, ta_A12B10C9D12, ta_A12B10C10D11, ta_A12B10C10D12, 
                 ta_A12B10C11D9, ta_A12B10C11D10, ta_A12B10C12D9, ta_A12B10C12D10, ta_A12B10C13D7, 
                 ta_A12B10C13D8, ta_A12B10C14D7, ta_A12B10C14D8, ta_A12B10C15D6, ta_A12B11C5D6, 
                 ta_A12B11C6D5, ta_A12B11C9D9, ta_A12B11C9D10, ta_A12B11C10D9, ta_A12B11C10D10, 
                 ta_A12B12C5D6, ta_A12B12C6D5, ta_A12B12C9D9, ta_A12B12C9D10, ta_A12B12C10D9, 
                 ta_A12B12C10D10, ta_A12B13C1D6, ta_A12B13C2D6, ta_A12B13C3D6, ta_A12B13C6D1, 
                 ta_A12B13C6D2, ta_A12B13C6D3, ta_A12B13C7D9, ta_A12B13C7D10, ta_A12B13C8D9, 
                 ta_A12B13C8D10, ta_A12B13C9D7, ta_A12B13C9D8, ta_A12B13C10D7, ta_A12B13C10D8, 
                 ta_A12B14C1D6, ta_A12B14C2D6, ta_A12B14C3D6, ta_A12B14C6D1, ta_A12B14C6D2, 
                 ta_A12B14C6D3, ta_A12B14C7D9, ta_A12B14C7D10, ta_A12B14C8D9, ta_A12B14C8D10, 
                 ta_A12B14C9D7, ta_A12B14C9D8, ta_A12B14C10D7, ta_A12B14C10D8, ta_A12B15C6D9, 
                 ta_A12B15C6D10, ta_A12B15C9D6, ta_A12B15C10D6, ta_A13B1C1D7, ta_A13B1C1D8, 
                 ta_A13B1C2D7, ta_A13B1C2D8, ta_A13B1C3D7, ta_A13B1C3D8, ta_A13B1C4D9, 
                 ta_A13B1C4D10, ta_A13B1C6D11, ta_A13B1C6D12, ta_A13B1C7D1, ta_A13B1C7D2, 
                 ta_A13B1C7D3, ta_A13B1C8D1, ta_A13B1C8D2, ta_A13B1C8D3, ta_A13B1C9D4, 
                 ta_A13B1C10D4, ta_A13B1C11D6, ta_A13B1C12D6, ta_A13B2C1D7, ta_A13B2C1D8, 
                 ta_A13B2C2D7, ta_A13B2C2D8, ta_A13B2C3D7, ta_A13B2C3D8, ta_A13B2C4D9, 
                 ta_A13B2C4D10, ta_A13B2C6D11, ta_A13B2C6D12, ta_A13B2C7D1, ta_A13B2C7D2, 
                 ta_A13B2C7D3, ta_A13B2C8D1, ta_A13B2C8D2, ta_A13B2C8D3, ta_A13B2C9D4, 
                 ta_A13B2C10D4, ta_A13B2C11D6, ta_A13B2C12D6, ta_A13B3C1D7, ta_A13B3C1D8, 
                 ta_A13B3C2D7, ta_A13B3C2D8, ta_A13B3C3D7, ta_A13B3C3D8, ta_A13B3C4D9, 
                 ta_A13B3C4D10, ta_A13B3C6D11, ta_A13B3C6D12, ta_A13B3C7D1, ta_A13B3C7D2, 
                 ta_A13B3C7D3, ta_A13B3C8D1, ta_A13B3C8D2, ta_A13B3C8D3, ta_A13B3C9D4, 
                 ta_A13B3C10D4, ta_A13B3C11D6, ta_A13B3C12D6, ta_A13B4C1D9, ta_A13B4C1D10, 
                 ta_A13B4C2D9, ta_A13B4C2D10, ta_A13B4C3D9, ta_A13B4C3D10, ta_A13B4C5D7, 
                 ta_A13B4C5D8, ta_A13B4C6D13, ta_A13B4C6D14, ta_A13B4C7D5, ta_A13B4C8D5, 
                 ta_A13B4C9D1, ta_A13B4C9D2, ta_A13B4C9D3, ta_A13B4C10D1, ta_A13B4C10D2, 
                 ta_A13B4C10D3, ta_A13B4C13D6, ta_A13B4C14D6, ta_A13B5C4D7, ta_A13B5C4D8, 
                 ta_A13B5C7D4, ta_A13B5C8D4, ta_A13B6C1D11, ta_A13B6C1D12, ta_A13B6C2D11, 
                 ta_A13B6C2D12, ta_A13B6C3D11, ta_A13B6C3D12, ta_A13B6C4D13, ta_A13B6C4D14, 
                 ta_A13B6C7D15, ta_A13B6C8D15, ta_A13B6C11D1, ta_A13B6C11D2, ta_A13B6C11D3, 
                 ta_A13B6C12D1, ta_A13B6C12D2, ta_A13B6C12D3, ta_A13B6C13D4, ta_A13B6C14D4, 
                 ta_A13B6C15D7, ta_A13B6C15D8, ta_A13B7C1D1, ta_A13B7C1D2, ta_A13B7C1D3, 
                 ta_A13B7C2D1, ta_A13B7C2D2, ta_A13B7C2D3, ta_A13B7C3D1, ta_A13B7C3D2, 
                 ta_A13B7C3D3, ta_A13B7C4D5, ta_A13B7C5D4, ta_A13B7C6D15, ta_A13B7C7D13, 
                 ta_A13B7C7D14, ta_A13B7C8D13, ta_A13B7C8D14, ta_A13B7C9D11, ta_A13B7C9D12, 
                 ta_A13B7C10D11, ta_A13B7C10D12, ta_A13B7C11D9, ta_A13B7C11D10, ta_A13B7C12D9, 
                 ta_A13B7C12D10, ta_A13B7C13D7, ta_A13B7C13D8, ta_A13B7C14D7, ta_A13B7C14D8, 
                 ta_A13B7C15D6, ta_A13B8C1D1, ta_A13B8C1D2, ta_A13B8C1D3, ta_A13B8C2D1, 
                 ta_A13B8C2D2, ta_A13B8C2D3, ta_A13B8C3D1, ta_A13B8C3D2, ta_A13B8C3D3, 
                 ta_A13B8C4D5, ta_A13B8C5D4, ta_A13B8C6D15, ta_A13B8C7D13, ta_A13B8C7D14, 
                 ta_A13B8C8D13, ta_A13B8C8D14, ta_A13B8C9D11, ta_A13B8C9D12, ta_A13B8C10D11, 
                 ta_A13B8C10D12, ta_A13B8C11D9, ta_A13B8C11D10, ta_A13B8C12D9, ta_A13B8C12D10, 
                 ta_A13B8C13D7, ta_A13B8C13D8, ta_A13B8C14D7, ta_A13B8C14D8, ta_A13B8C15D6, 
                 ta_A13B9C1D4, ta_A13B9C2D4, ta_A13B9C3D4, ta_A13B9C4D1, ta_A13B9C4D2, 
                 ta_A13B9C4D3, ta_A13B9C7D11, ta_A13B9C7D12, ta_A13B9C8D11, ta_A13B9C8D12, 
                 ta_A13B9C11D7, ta_A13B9C11D8, ta_A13B9C12D7, ta_A13B9C12D8, ta_A13B10C1D4, 
                 ta_A13B10C2D4, ta_A13B10C3D4, ta_A13B10C4D1, ta_A13B10C4D2, ta_A13B10C4D3, 
                 ta_A13B10C7D11, ta_A13B10C7D12, ta_A13B10C8D11, ta_A13B10C8D12, ta_A13B10C11D7, 
                 ta_A13B10C11D8, ta_A13B10C12D7, ta_A13B10C12D8, ta_A13B11C1D6, ta_A13B11C2D6, 
                 ta_A13B11C3D6, ta_A13B11C6D1, ta_A13B11C6D2, ta_A13B11C6D3, ta_A13B11C7D9, 
                 ta_A13B11C7D10, ta_A13B11C8D9, ta_A13B11C8D10, ta_A13B11C9D7, ta_A13B11C9D8, 
                 ta_A13B11C10D7, ta_A13B11C10D8, ta_A13B12C1D6, ta_A13B12C2D6, ta_A13B12C3D6, 
                 ta_A13B12C6D1, ta_A13B12C6D2, ta_A13B12C6D3, ta_A13B12C7D9, ta_A13B12C7D10, 
                 ta_A13B12C8D9, ta_A13B12C8D10, ta_A13B12C9D7, ta_A13B12C9D8, ta_A13B12C10D7, 
                 ta_A13B12C10D8, ta_A13B13C4D6, ta_A13B13C6D4, ta_A13B13C7D7, ta_A13B13C7D8, 
                 ta_A13B13C8D7, ta_A13B13C8D8, ta_A13B14C4D6, ta_A13B14C6D4, ta_A13B14C7D7, 
                 ta_A13B14C7D8, ta_A13B14C8D7, ta_A13B14C8D8, ta_A13B15C6D7, ta_A13B15C6D8, 
                 ta_A13B15C7D6, ta_A13B15C8D6, ta_A14B1C1D7, ta_A14B1C1D8, ta_A14B1C2D7, 
                 ta_A14B1C2D8, ta_A14B1C3D7, ta_A14B1C3D8, ta_A14B1C4D9, ta_A14B1C4D10, 
                 ta_A14B1C6D11, ta_A14B1C6D12, ta_A14B1C7D1, ta_A14B1C7D2, ta_A14B1C7D3, 
                 ta_A14B1C8D1, ta_A14B1C8D2, ta_A14B1C8D3, ta_A14B1C9D4, ta_A14B1C10D4, 
                 ta_A14B1C11D6, ta_A14B1C12D6, ta_A14B2C1D7, ta_A14B2C1D8, ta_A14B2C2D7, 
                 ta_A14B2C2D8, ta_A14B2C3D7, ta_A14B2C3D8, ta_A14B2C4D9, ta_A14B2C4D10, 
                 ta_A14B2C6D11, ta_A14B2C6D12, ta_A14B2C7D1, ta_A14B2C7D2, ta_A14B2C7D3, 
                 ta_A14B2C8D1, ta_A14B2C8D2, ta_A14B2C8D3, ta_A14B2C9D4, ta_A14B2C10D4, 
                 ta_A14B2C11D6, ta_A14B2C12D6, ta_A14B3C1D7, ta_A14B3C1D8, ta_A14B3C2D7, 
                 ta_A14B3C2D8, ta_A14B3C3D7, ta_A14B3C3D8, ta_A14B3C4D9, ta_A14B3C4D10, 
                 ta_A14B3C6D11, ta_A14B3C6D12, ta_A14B3C7D1, ta_A14B3C7D2, ta_A14B3C7D3, 
                 ta_A14B3C8D1, ta_A14B3C8D2, ta_A14B3C8D3, ta_A14B3C9D4, ta_A14B3C10D4, 
                 ta_A14B3C11D6, ta_A14B3C12D6, ta_A14B4C1D9, ta_A14B4C1D10, ta_A14B4C2D9, 
                 ta_A14B4C2D10, ta_A14B4C3D9, ta_A14B4C3D10, ta_A14B4C5D7, ta_A14B4C5D8, 
                 ta_A14B4C6D13, ta_A14B4C6D14, ta_A14B4C7D5, ta_A14B4C8D5, ta_A14B4C9D1, 
                 ta_A14B4C9D2, ta_A14B4C9D3, ta_A14B4C10D1, ta_A14B4C10D2, ta_A14B4C10D3, 
                 ta_A14B4C13D6, ta_A14B4C14D6, ta_A14B5C4D7, ta_A14B5C4D8, ta_A14B5C7D4, 
                 ta_A14B5C8D4, ta_A14B6C1D11, ta_A14B6C1D12, ta_A14B6C2D11, ta_A14B6C2D12, 
                 ta_A14B6C3D11, ta_A14B6C3D12, ta_A14B6C4D13, ta_A14B6C4D14, ta_A14B6C7D15, 
                 ta_A14B6C8D15, ta_A14B6C11D1, ta_A14B6C11D2, ta_A14B6C11D3, ta_A14B6C12D1, 
                 ta_A14B6C12D2, ta_A14B6C12D3, ta_A14B6C13D4, ta_A14B6C14D4, ta_A14B6C15D7, 
                 ta_A14B6C15D8, ta_A14B7C1D1, ta_A14B7C1D2, ta_A14B7C1D3, ta_A14B7C2D1, 
                 ta_A14B7C2D2, ta_A14B7C2D3, ta_A14B7C3D1, ta_A14B7C3D2, ta_A14B7C3D3, 
                 ta_A14B7C4D5, ta_A14B7C5D4, ta_A14B7C6D15, ta_A14B7C7D13, ta_A14B7C7D14, 
                 ta_A14B7C8D13, ta_A14B7C8D14, ta_A14B7C9D11, ta_A14B7C9D12, ta_A14B7C10D11, 
                 ta_A14B7C10D12, ta_A14B7C11D9, ta_A14B7C11D10, ta_A14B7C12D9, ta_A14B7C12D10, 
                 ta_A14B7C13D7, ta_A14B7C13D8, ta_A14B7C14D7, ta_A14B7C14D8, ta_A14B7C15D6, 
                 ta_A14B8C1D1, ta_A14B8C1D2, ta_A14B8C1D3, ta_A14B8C2D1, ta_A14B8C2D2, 
                 ta_A14B8C2D3, ta_A14B8C3D1, ta_A14B8C3D2, ta_A14B8C3D3, ta_A14B8C4D5, 
                 ta_A14B8C5D4, ta_A14B8C6D15, ta_A14B8C7D13, ta_A14B8C7D14, ta_A14B8C8D13, 
                 ta_A14B8C8D14, ta_A14B8C9D11, ta_A14B8C9D12, ta_A14B8C10D11, ta_A14B8C10D12, 
                 ta_A14B8C11D9, ta_A14B8C11D10, ta_A14B8C12D9, ta_A14B8C12D10, ta_A14B8C13D7, 
                 ta_A14B8C13D8, ta_A14B8C14D7, ta_A14B8C14D8, ta_A14B8C15D6, ta_A14B9C1D4, 
                 ta_A14B9C2D4, ta_A14B9C3D4, ta_A14B9C4D1, ta_A14B9C4D2, ta_A14B9C4D3, 
                 ta_A14B9C7D11, ta_A14B9C7D12, ta_A14B9C8D11, ta_A14B9C8D12, ta_A14B9C11D7, 
                 ta_A14B9C11D8, ta_A14B9C12D7, ta_A14B9C12D8, ta_A14B10C1D4, ta_A14B10C2D4, 
                 ta_A14B10C3D4, ta_A14B10C4D1, ta_A14B10C4D2, ta_A14B10C4D3, ta_A14B10C7D11, 
                 ta_A14B10C7D12, ta_A14B10C8D11, ta_A14B10C8D12, ta_A14B10C11D7, ta_A14B10C11D8, 
                 ta_A14B10C12D7, ta_A14B10C12D8, ta_A14B11C1D6, ta_A14B11C2D6, ta_A14B11C3D6, 
                 ta_A14B11C6D1, ta_A14B11C6D2, ta_A14B11C6D3, ta_A14B11C7D9, ta_A14B11C7D10, 
                 ta_A14B11C8D9, ta_A14B11C8D10, ta_A14B11C9D7, ta_A14B11C9D8, ta_A14B11C10D7, 
                 ta_A14B11C10D8, ta_A14B12C1D6, ta_A14B12C2D6, ta_A14B12C3D6, ta_A14B12C6D1, 
                 ta_A14B12C6D2, ta_A14B12C6D3, ta_A14B12C7D9, ta_A14B12C7D10, ta_A14B12C8D9, 
                 ta_A14B12C8D10, ta_A14B12C9D7, ta_A14B12C9D8, ta_A14B12C10D7, ta_A14B12C10D8, 
                 ta_A14B13C4D6, ta_A14B13C6D4, ta_A14B13C7D7, ta_A14B13C7D8, ta_A14B13C8D7, 
                 ta_A14B13C8D8, ta_A14B14C4D6, ta_A14B14C6D4, ta_A14B14C7D7, ta_A14B14C7D8, 
                 ta_A14B14C8D7, ta_A14B14C8D8, ta_A14B15C6D7, ta_A14B15C6D8, ta_A14B15C7D6, 
                 ta_A14B15C8D6, ta_A15B1C1D6, ta_A15B1C2D6, ta_A15B1C3D6, ta_A15B1C6D1, 
                 ta_A15B1C6D2, ta_A15B1C6D3, ta_A15B1C7D9, ta_A15B1C7D10, ta_A15B1C8D9, 
                 ta_A15B1C8D10, ta_A15B1C9D7, ta_A15B1C9D8, ta_A15B1C10D7, ta_A15B1C10D8, 
                 ta_A15B2C1D6, ta_A15B2C2D6, ta_A15B2C3D6, ta_A15B2C6D1, ta_A15B2C6D2, 
                 ta_A15B2C6D3, ta_A15B2C7D9, ta_A15B2C7D10, ta_A15B2C8D9, ta_A15B2C8D10, 
                 ta_A15B2C9D7, ta_A15B2C9D8, ta_A15B2C10D7, ta_A15B2C10D8, ta_A15B3C1D6, 
                 ta_A15B3C2D6, ta_A15B3C3D6, ta_A15B3C6D1, ta_A15B3C6D2, ta_A15B3C6D3, 
                 ta_A15B3C7D9, ta_A15B3C7D10, ta_A15B3C8D9, ta_A15B3C8D10, ta_A15B3C9D7, 
                 ta_A15B3C9D8, ta_A15B3C10D7, ta_A15B3C10D8, ta_A15B4C5D6, ta_A15B4C6D5, 
                 ta_A15B4C9D9, ta_A15B4C9D10, ta_A15B4C10D9, ta_A15B4C10D10, ta_A15B5C4D6, 
                 ta_A15B5C6D4, ta_A15B5C7D7, ta_A15B5C7D8, ta_A15B5C8D7, ta_A15B5C8D8, 
                 ta_A15B6C1D1, ta_A15B6C1D2, ta_A15B6C1D3, ta_A15B6C2D1, ta_A15B6C2D2, 
                 ta_A15B6C2D3, ta_A15B6C3D1, ta_A15B6C3D2, ta_A15B6C3D3, ta_A15B6C4D5, 
                 ta_A15B6C5D4, ta_A15B6C6D15, ta_A15B6C7D13, ta_A15B6C7D14, ta_A15B6C8D13, 
                 ta_A15B6C8D14, ta_A15B6C9D11, ta_A15B6C9D12, ta_A15B6C10D11, ta_A15B6C10D12, 
                 ta_A15B6C11D9, ta_A15B6C11D10, ta_A15B6C12D9, ta_A15B6C12D10, ta_A15B6C13D7, 
                 ta_A15B6C13D8, ta_A15B6C14D7, ta_A15B6C14D8, ta_A15B6C15D6, ta_A15B7C1D9, 
                 ta_A15B7C1D10, ta_A15B7C2D9, ta_A15B7C2D10, ta_A15B7C3D9, ta_A15B7C3D10, 
                 ta_A15B7C5D7, ta_A15B7C5D8, ta_A15B7C6D13, ta_A15B7C6D14, ta_A15B7C7D5, 
                 ta_A15B7C8D5, ta_A15B7C9D1, ta_A15B7C9D2, ta_A15B7C9D3, ta_A15B7C10D1, 
                 ta_A15B7C10D2, ta_A15B7C10D3, ta_A15B7C13D6, ta_A15B7C14D6, ta_A15B8C1D9, 
                 ta_A15B8C1D10, ta_A15B8C2D9, ta_A15B8C2D10, ta_A15B8C3D9, ta_A15B8C3D10, 
                 ta_A15B8C5D7, ta_A15B8C5D8, ta_A15B8C6D13, ta_A15B8C6D14, ta_A15B8C7D5, 
                 ta_A15B8C8D5, ta_A15B8C9D1, ta_A15B8C9D2, ta_A15B8C9D3, ta_A15B8C10D1, 
                 ta_A15B8C10D2, ta_A15B8C10D3, ta_A15B8C13D6, ta_A15B8C14D6, ta_A15B9C1D7, 
                 ta_A15B9C1D8, ta_A15B9C2D7, ta_A15B9C2D8, ta_A15B9C3D7, ta_A15B9C3D8, 
                 ta_A15B9C4D9, ta_A15B9C4D10, ta_A15B9C6D11, ta_A15B9C6D12, ta_A15B9C7D1, 
                 ta_A15B9C7D2, ta_A15B9C7D3, ta_A15B9C8D1, ta_A15B9C8D2, ta_A15B9C8D3, 
                 ta_A15B9C9D4, ta_A15B9C10D4, ta_A15B9C11D6, ta_A15B9C12D6, ta_A15B10C1D7, 
                 ta_A15B10C1D8, ta_A15B10C2D7, ta_A15B10C2D8, ta_A15B10C3D7, ta_A15B10C3D8, 
                 ta_A15B10C4D9, ta_A15B10C4D10, ta_A15B10C6D11, ta_A15B10C6D12, ta_A15B10C7D1, 
                 ta_A15B10C7D2, ta_A15B10C7D3, ta_A15B10C8D1, ta_A15B10C8D2, ta_A15B10C8D3, 
                 ta_A15B10C9D4, ta_A15B10C10D4, ta_A15B10C11D6, ta_A15B10C12D6, ta_A15B11C6D9, 
                 ta_A15B11C6D10, ta_A15B11C9D6, ta_A15B11C10D6, ta_A15B12C6D9, ta_A15B12C6D10, 
                 ta_A15B12C9D6, ta_A15B12C10D6, ta_A15B13C6D7, ta_A15B13C6D8, ta_A15B13C7D6, 
                 ta_A15B13C8D6, ta_A15B14C6D7, ta_A15B14C6D8, ta_A15B14C7D6, ta_A15B14C8D6, 
                 ta_A15B15C6D6,                  
                 )
        
    Eref = h[()][()]
    
    t0 = {v: sign([b for b,s in v if 6<s<15])*tu for u,tu in deepcopy(t0).items() for v in permutations(u)}
    Ecorr=ta_(t0, h, p, nc); E0 = Eref+Ecorr
    print(F'Ecorr,E0 = {Ecorr},{E0}')
    
    print('    it            dE               dt               time/s')
    for it in range(200):
        t = {}
        
        t1 = datetime.now()
        for braf in brafl: t.update(braf(t0, h, p, E0, nc))
        t2 = datetime.now()
        
        dt = sum(abs(t[u]-t0[u]) for u in t)
        
        t0 = {v: sign([b for b,s in v if 6<s<15])*tu for u,tu in t.items() for v in permutations(u)}
        Ecorr=ta_(t0, h, p, nc); E = Eref+Ecorr
        
        dE = E-E0
        
        print(F'    {it+1:3d}      {dE:13.10f}    {dt:13.10f}     {t2-t1}', flush=True)
        if abs(dt)<1.0e-7: 
            print(F'Successfully converged: Ecorr = {Ecorr}')
            break
        else: 
            E0 = E
        
    else: 
        print('Error: Convergence failed ')
    
    return Ecorr,t
    

