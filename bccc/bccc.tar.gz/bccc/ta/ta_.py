#!/usr/bin/env python 
# -*- coding: utf-8 -*- 
# 
# Author: Qingchun Wang @ NJU 
# E-mail: qingchun720@foxmail.com 
# 


from bccc.pub import sign,dei


def h0_(r, h, g, p, nc=0):
    np = len(p)
    hd = {}
    
    u = tuple(sorted(()))
    hu = 0.0
    
    hu += sum(h[p[I,0],p[I,0]]*r[I][9][0,0] for I in range(np) if I not in [])
    hu += sum(h[p[I,0],p[I,0]]*r[I][24][0,0] for I in range(np) if I not in [])
    hu += sum(h[p[I,1],p[I,1]]*r[I][39][0,0] for I in range(np) if I not in [])
    hu += sum(h[p[I,1],p[I,1]]*r[I][54][0,0] for I in range(np) if I not in [])
    hu += sum(g[dei(p[I,0],p[I,0],p[I,0],p[I,0])]*r[I][194][0,0] for I in range(np) if I not in [])
    hu += sum(g[dei(p[I,0],p[I,1],p[I,0],p[I,1])]*r[I][199][0,0] for I in range(np) if I not in [])
    hu += sum(g[dei(p[I,1],p[I,0],p[I,1],p[I,0])]*r[I][274][0,0] for I in range(np) if I not in [])
    hu += sum(g[dei(p[I,1],p[I,1],p[I,1],p[I,1])]*r[I][279][0,0] for I in range(np) if I not in [])
    hu += sum(1/4*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][9][0,0]*r[J][9][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(1/4*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][24][0,0]*r[J][24][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][9][0,0]*r[J][24][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(1/4*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][9][0,0]*r[J][39][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(1/4*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][24][0,0]*r[J][54][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(1/2*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][9][0,0]*r[J][54][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(1/4*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][39][0,0]*r[J][9][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(1/4*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][54][0,0]*r[J][24][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][39][0,0]*r[J][24][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(1/4*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][39][0,0]*r[J][39][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(1/4*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][54][0,0]*r[J][54][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(1/2*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][39][0,0]*r[J][54][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,0])]*r[I][9][0,0]*r[J][9][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(-1/4*g[dei(p[I,0],p[J,0],p[J,0],p[I,0])]*r[I][24][0,0]*r[J][24][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,0])]*r[I][9][0,0]*r[J][39][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(-1/4*g[dei(p[I,0],p[J,1],p[J,1],p[I,0])]*r[I][24][0,0]*r[J][54][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,1])]*r[I][39][0,0]*r[J][9][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(-1/4*g[dei(p[I,1],p[J,0],p[J,0],p[I,1])]*r[I][54][0,0]*r[J][24][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,1])]*r[I][39][0,0]*r[J][39][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(-1/4*g[dei(p[I,1],p[J,1],p[J,1],p[I,1])]*r[I][54][0,0]*r[J][54][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,0],p[J,0])]*r[I][9][0,0]*r[J][9][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(-1/4*g[dei(p[J,0],p[I,0],p[I,0],p[J,0])]*r[I][24][0,0]*r[J][24][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,1],p[J,0])]*r[I][39][0,0]*r[J][9][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(-1/4*g[dei(p[J,0],p[I,1],p[I,1],p[J,0])]*r[I][54][0,0]*r[J][24][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,0],p[J,1])]*r[I][9][0,0]*r[J][39][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(-1/4*g[dei(p[J,1],p[I,0],p[I,0],p[J,1])]*r[I][24][0,0]*r[J][54][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,1],p[J,1])]*r[I][39][0,0]*r[J][39][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(-1/4*g[dei(p[J,1],p[I,1],p[I,1],p[J,1])]*r[I][54][0,0]*r[J][54][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[I][9][0,0]*r[J][9][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(1/4*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[I][24][0,0]*r[J][24][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(1/2*g[dei(p[J,0],p[J,0],p[I,0],p[I,0])]*r[I][24][0,0]*r[J][9][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[I][39][0,0]*r[J][9][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(1/4*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[I][54][0,0]*r[J][24][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(1/2*g[dei(p[J,0],p[J,0],p[I,1],p[I,1])]*r[I][54][0,0]*r[J][9][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[I][9][0,0]*r[J][39][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(1/4*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[I][24][0,0]*r[J][54][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(1/2*g[dei(p[J,1],p[J,1],p[I,0],p[I,0])]*r[I][24][0,0]*r[J][39][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[I][39][0,0]*r[J][39][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(1/4*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[I][54][0,0]*r[J][54][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    hu += sum(1/2*g[dei(p[J,1],p[J,1],p[I,1],p[I,1])]*r[I][54][0,0]*r[J][39][0,0] for I in range(np) if I not in [] for J in range(np) if J not in [I])
    
    hd[u] = hu
    
    return hd
    
def ta_(t, r, h, g, p, nc=0):
    td = {}
    np = len(p)
    
    u = tuple(sorted(()))
    tu = 0.0
    tul = []
    
    for I in range(nc,np):
        if I in {}: continue
        for J in range(nc,np):
            if J in {I}: continue
            # ({I}_{12}, {J}_{9})
            tu += 1/2*h[p[I,0],p[J,0]]*r[I][0][12,0]*r[J][1][9,0]*t[((I,12),(J,9),)]
            tu += -1/4*g[dei(p[I,0],p[I,1],p[I,1],p[J,0])]*r[I][76][12,0]*r[J][1][9,0]*t[((I,12),(J,9),)]
            tu += -1/4*g[dei(p[I,0],p[J,0],p[I,1],p[I,1])]*r[I][124][12,0]*r[J][1][9,0]*t[((I,12),(J,9),)]
            tu += 1/4*g[dei(p[I,0],p[J,0],p[I,1],p[I,1])]*r[I][76][12,0]*r[J][1][9,0]*t[((I,12),(J,9),)]
            tu += 1/2*g[dei(p[I,0],p[J,0],p[I,1],p[I,1])]*r[I][86][12,0]*r[J][1][9,0]*t[((I,12),(J,9),)]
            tu += 1/4*g[dei(p[I,0],p[I,1],p[I,1],p[J,0])]*r[I][124][12,0]*r[J][1][9,0]*t[((I,12),(J,9),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[I,1],p[J,0])]*r[I][146][12,0]*r[J][1][9,0]*t[((I,12),(J,9),)]
            tu += 1/2*g[dei(p[I,0],p[J,0],p[J,0],p[J,0])]*r[I][0][12,0]*r[J][97][9,0]*t[((I,12),(J,9),)]
            tu += 1/2*g[dei(p[I,0],p[J,1],p[J,0],p[J,1])]*r[I][0][12,0]*r[J][117][9,0]*t[((I,12),(J,9),)]
            tu += sum(1/2*g[dei(p[I,0],p[J,0],p[K,0],p[K,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][9][0,0]*t[((I,12),(J,9),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,0],p[J,0],p[K,1],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][39][0,0]*t[((I,12),(J,9),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,0],p[K,0],p[J,0],p[K,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][9][0,0]*t[((I,12),(J,9),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,0],p[K,1],p[J,0],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][39][0,0]*t[((I,12),(J,9),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,0],p[J,0],p[K,0],p[K,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][24][0,0]*t[((I,12),(J,9),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,0],p[J,0],p[K,1],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][54][0,0]*t[((I,12),(J,9),)] for K in range(np) if K not in {I,J})
            # ({I}_{14}, {J}_{7})
            tu += 1/2*h[p[I,0],p[J,0]]*r[I][2][14,0]*r[J][3][7,0]*t[((I,14),(J,7),)]
            tu += -1/4*g[dei(p[I,0],p[I,1],p[I,1],p[J,0])]*r[I][118][14,0]*r[J][3][7,0]*t[((I,14),(J,7),)]
            tu += -1/4*g[dei(p[I,0],p[J,0],p[I,1],p[I,1])]*r[I][166][14,0]*r[J][3][7,0]*t[((I,14),(J,7),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,1],p[I,1])]*r[I][132][14,0]*r[J][3][7,0]*t[((I,14),(J,7),)]
            tu += -1/2*g[dei(p[I,0],p[I,1],p[I,1],p[J,0])]*r[I][144][14,0]*r[J][3][7,0]*t[((I,14),(J,7),)]
            tu += 1/4*g[dei(p[I,0],p[J,0],p[I,1],p[I,1])]*r[I][118][14,0]*r[J][3][7,0]*t[((I,14),(J,7),)]
            tu += 1/4*g[dei(p[I,0],p[I,1],p[I,1],p[J,0])]*r[I][166][14,0]*r[J][3][7,0]*t[((I,14),(J,7),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[J,0],p[J,0])]*r[I][2][14,0]*r[J][65][7,0]*t[((I,14),(J,7),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[J,0],p[J,1])]*r[I][2][14,0]*r[J][85][7,0]*t[((I,14),(J,7),)]
            tu += sum(1/2*g[dei(p[I,0],p[J,0],p[K,0],p[K,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][24][0,0]*t[((I,14),(J,7),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,0],p[J,0],p[K,0],p[K,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][9][0,0]*t[((I,14),(J,7),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,0],p[J,0],p[K,1],p[K,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][54][0,0]*t[((I,14),(J,7),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,0],p[J,0],p[K,1],p[K,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][39][0,0]*t[((I,14),(J,7),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,0],p[K,0],p[J,0],p[K,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][24][0,0]*t[((I,14),(J,7),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,0],p[K,1],p[J,0],p[K,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][54][0,0]*t[((I,14),(J,7),)] for K in range(np) if K not in {I,J})
            # ({I}_{12}, {J}_{10})
            tu += 1/2*h[p[I,0],p[J,1]]*r[I][0][12,0]*r[J][5][10,0]*t[((I,12),(J,10),)]
            tu += -1/4*g[dei(p[I,0],p[I,1],p[I,1],p[J,1])]*r[I][76][12,0]*r[J][5][10,0]*t[((I,12),(J,10),)]
            tu += -1/4*g[dei(p[I,0],p[J,1],p[I,1],p[I,1])]*r[I][124][12,0]*r[J][5][10,0]*t[((I,12),(J,10),)]
            tu += 1/4*g[dei(p[I,0],p[J,1],p[I,1],p[I,1])]*r[I][76][12,0]*r[J][5][10,0]*t[((I,12),(J,10),)]
            tu += 1/2*g[dei(p[I,0],p[J,1],p[I,1],p[I,1])]*r[I][86][12,0]*r[J][5][10,0]*t[((I,12),(J,10),)]
            tu += 1/4*g[dei(p[I,0],p[I,1],p[I,1],p[J,1])]*r[I][124][12,0]*r[J][5][10,0]*t[((I,12),(J,10),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[I,1],p[J,1])]*r[I][146][12,0]*r[J][5][10,0]*t[((I,12),(J,10),)]
            tu += 1/2*g[dei(p[I,0],p[J,0],p[J,0],p[J,1])]*r[I][0][12,0]*r[J][161][10,0]*t[((I,12),(J,10),)]
            tu += 1/2*g[dei(p[I,0],p[J,1],p[J,1],p[J,1])]*r[I][0][12,0]*r[J][181][10,0]*t[((I,12),(J,10),)]
            tu += sum(1/2*g[dei(p[I,0],p[J,1],p[K,0],p[K,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][9][0,0]*t[((I,12),(J,10),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,0],p[J,1],p[K,1],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][39][0,0]*t[((I,12),(J,10),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,0],p[K,0],p[J,1],p[K,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][9][0,0]*t[((I,12),(J,10),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,0],p[K,1],p[J,1],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][39][0,0]*t[((I,12),(J,10),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,0],p[J,1],p[K,0],p[K,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][24][0,0]*t[((I,12),(J,10),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,0],p[J,1],p[K,1],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][54][0,0]*t[((I,12),(J,10),)] for K in range(np) if K not in {I,J})
            # ({I}_{14}, {J}_{8})
            tu += 1/2*h[p[I,0],p[J,1]]*r[I][2][14,0]*r[J][7][8,0]*t[((I,14),(J,8),)]
            tu += -1/4*g[dei(p[I,0],p[I,1],p[I,1],p[J,1])]*r[I][118][14,0]*r[J][7][8,0]*t[((I,14),(J,8),)]
            tu += -1/4*g[dei(p[I,0],p[J,1],p[I,1],p[I,1])]*r[I][166][14,0]*r[J][7][8,0]*t[((I,14),(J,8),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[I,1],p[I,1])]*r[I][132][14,0]*r[J][7][8,0]*t[((I,14),(J,8),)]
            tu += -1/2*g[dei(p[I,0],p[I,1],p[I,1],p[J,1])]*r[I][144][14,0]*r[J][7][8,0]*t[((I,14),(J,8),)]
            tu += 1/4*g[dei(p[I,0],p[J,1],p[I,1],p[I,1])]*r[I][118][14,0]*r[J][7][8,0]*t[((I,14),(J,8),)]
            tu += 1/4*g[dei(p[I,0],p[I,1],p[I,1],p[J,1])]*r[I][166][14,0]*r[J][7][8,0]*t[((I,14),(J,8),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[J,0],p[J,1])]*r[I][2][14,0]*r[J][129][8,0]*t[((I,14),(J,8),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[J,1],p[J,1])]*r[I][2][14,0]*r[J][149][8,0]*t[((I,14),(J,8),)]
            tu += sum(1/2*g[dei(p[I,0],p[J,1],p[K,0],p[K,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][24][0,0]*t[((I,14),(J,8),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,0],p[J,1],p[K,0],p[K,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][9][0,0]*t[((I,14),(J,8),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,0],p[J,1],p[K,1],p[K,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][54][0,0]*t[((I,14),(J,8),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,0],p[J,1],p[K,1],p[K,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][39][0,0]*t[((I,14),(J,8),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,0],p[K,0],p[J,1],p[K,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][24][0,0]*t[((I,14),(J,8),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,0],p[K,1],p[J,1],p[K,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][54][0,0]*t[((I,14),(J,8),)] for K in range(np) if K not in {I,J})
            # ({I}_{11}, {J}_{9})
            tu += 1/2*h[p[I,1],p[J,0]]*r[I][4][11,0]*r[J][1][9,0]*t[((I,11),(J,9),)]
            tu += -1/4*g[dei(p[I,0],p[I,0],p[I,1],p[J,0])]*r[I][72][11,0]*r[J][1][9,0]*t[((I,11),(J,9),)]
            tu += -1/4*g[dei(p[I,0],p[I,1],p[I,0],p[J,0])]*r[I][120][11,0]*r[J][1][9,0]*t[((I,11),(J,9),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[I,0],p[J,0])]*r[I][70][11,0]*r[J][1][9,0]*t[((I,11),(J,9),)]
            tu += 1/4*g[dei(p[I,0],p[I,1],p[I,0],p[J,0])]*r[I][72][11,0]*r[J][1][9,0]*t[((I,11),(J,9),)]
            tu += 1/4*g[dei(p[I,0],p[I,0],p[I,1],p[J,0])]*r[I][120][11,0]*r[J][1][9,0]*t[((I,11),(J,9),)]
            tu += 1/2*g[dei(p[I,0],p[I,0],p[I,1],p[J,0])]*r[I][130][11,0]*r[J][1][9,0]*t[((I,11),(J,9),)]
            tu += 1/2*g[dei(p[I,1],p[J,0],p[J,0],p[J,0])]*r[I][4][11,0]*r[J][97][9,0]*t[((I,11),(J,9),)]
            tu += 1/2*g[dei(p[I,1],p[J,1],p[J,0],p[J,1])]*r[I][4][11,0]*r[J][117][9,0]*t[((I,11),(J,9),)]
            tu += sum(1/2*g[dei(p[I,1],p[J,0],p[K,0],p[K,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][9][0,0]*t[((I,11),(J,9),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,1],p[J,0],p[K,1],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][39][0,0]*t[((I,11),(J,9),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,1],p[K,0],p[J,0],p[K,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][9][0,0]*t[((I,11),(J,9),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,1],p[K,1],p[J,0],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][39][0,0]*t[((I,11),(J,9),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,1],p[J,0],p[K,0],p[K,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][24][0,0]*t[((I,11),(J,9),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,1],p[J,0],p[K,1],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][54][0,0]*t[((I,11),(J,9),)] for K in range(np) if K not in {I,J})
            # ({I}_{13}, {J}_{7})
            tu += 1/2*h[p[I,1],p[J,0]]*r[I][6][13,0]*r[J][3][7,0]*t[((I,13),(J,7),)]
            tu += -1/2*g[dei(p[I,0],p[I,1],p[I,0],p[J,0])]*r[I][68][13,0]*r[J][3][7,0]*t[((I,13),(J,7),)]
            tu += -1/4*g[dei(p[I,0],p[I,0],p[I,1],p[J,0])]*r[I][114][13,0]*r[J][3][7,0]*t[((I,13),(J,7),)]
            tu += -1/2*g[dei(p[I,0],p[I,0],p[I,1],p[J,0])]*r[I][80][13,0]*r[J][3][7,0]*t[((I,13),(J,7),)]
            tu += -1/4*g[dei(p[I,0],p[I,1],p[I,0],p[J,0])]*r[I][162][13,0]*r[J][3][7,0]*t[((I,13),(J,7),)]
            tu += 1/4*g[dei(p[I,0],p[I,1],p[I,0],p[J,0])]*r[I][114][13,0]*r[J][3][7,0]*t[((I,13),(J,7),)]
            tu += 1/4*g[dei(p[I,0],p[I,0],p[I,1],p[J,0])]*r[I][162][13,0]*r[J][3][7,0]*t[((I,13),(J,7),)]
            tu += -1/2*g[dei(p[I,1],p[J,0],p[J,0],p[J,0])]*r[I][6][13,0]*r[J][65][7,0]*t[((I,13),(J,7),)]
            tu += -1/2*g[dei(p[I,1],p[J,1],p[J,0],p[J,1])]*r[I][6][13,0]*r[J][85][7,0]*t[((I,13),(J,7),)]
            tu += sum(1/2*g[dei(p[I,1],p[J,0],p[K,0],p[K,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][24][0,0]*t[((I,13),(J,7),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,1],p[J,0],p[K,0],p[K,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][9][0,0]*t[((I,13),(J,7),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,1],p[J,0],p[K,1],p[K,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][54][0,0]*t[((I,13),(J,7),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,1],p[J,0],p[K,1],p[K,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][39][0,0]*t[((I,13),(J,7),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,1],p[K,0],p[J,0],p[K,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][24][0,0]*t[((I,13),(J,7),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,1],p[K,1],p[J,0],p[K,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][54][0,0]*t[((I,13),(J,7),)] for K in range(np) if K not in {I,J})
            # ({I}_{11}, {J}_{10})
            tu += 1/2*h[p[I,1],p[J,1]]*r[I][4][11,0]*r[J][5][10,0]*t[((I,11),(J,10),)]
            tu += -1/4*g[dei(p[I,0],p[I,0],p[I,1],p[J,1])]*r[I][72][11,0]*r[J][5][10,0]*t[((I,11),(J,10),)]
            tu += -1/4*g[dei(p[I,0],p[I,1],p[I,0],p[J,1])]*r[I][120][11,0]*r[J][5][10,0]*t[((I,11),(J,10),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[I,0],p[J,1])]*r[I][70][11,0]*r[J][5][10,0]*t[((I,11),(J,10),)]
            tu += 1/4*g[dei(p[I,0],p[I,1],p[I,0],p[J,1])]*r[I][72][11,0]*r[J][5][10,0]*t[((I,11),(J,10),)]
            tu += 1/4*g[dei(p[I,0],p[I,0],p[I,1],p[J,1])]*r[I][120][11,0]*r[J][5][10,0]*t[((I,11),(J,10),)]
            tu += 1/2*g[dei(p[I,0],p[I,0],p[I,1],p[J,1])]*r[I][130][11,0]*r[J][5][10,0]*t[((I,11),(J,10),)]
            tu += 1/2*g[dei(p[I,1],p[J,0],p[J,0],p[J,1])]*r[I][4][11,0]*r[J][161][10,0]*t[((I,11),(J,10),)]
            tu += 1/2*g[dei(p[I,1],p[J,1],p[J,1],p[J,1])]*r[I][4][11,0]*r[J][181][10,0]*t[((I,11),(J,10),)]
            tu += sum(1/2*g[dei(p[I,1],p[J,1],p[K,0],p[K,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][9][0,0]*t[((I,11),(J,10),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,1],p[J,1],p[K,1],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][39][0,0]*t[((I,11),(J,10),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,1],p[K,0],p[J,1],p[K,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][9][0,0]*t[((I,11),(J,10),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,1],p[K,1],p[J,1],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][39][0,0]*t[((I,11),(J,10),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,1],p[J,1],p[K,0],p[K,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][24][0,0]*t[((I,11),(J,10),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,1],p[J,1],p[K,1],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][54][0,0]*t[((I,11),(J,10),)] for K in range(np) if K not in {I,J})
            # ({I}_{13}, {J}_{8})
            tu += 1/2*h[p[I,1],p[J,1]]*r[I][6][13,0]*r[J][7][8,0]*t[((I,13),(J,8),)]
            tu += -1/2*g[dei(p[I,0],p[I,1],p[I,0],p[J,1])]*r[I][68][13,0]*r[J][7][8,0]*t[((I,13),(J,8),)]
            tu += -1/4*g[dei(p[I,0],p[I,0],p[I,1],p[J,1])]*r[I][114][13,0]*r[J][7][8,0]*t[((I,13),(J,8),)]
            tu += -1/2*g[dei(p[I,0],p[I,0],p[I,1],p[J,1])]*r[I][80][13,0]*r[J][7][8,0]*t[((I,13),(J,8),)]
            tu += -1/4*g[dei(p[I,0],p[I,1],p[I,0],p[J,1])]*r[I][162][13,0]*r[J][7][8,0]*t[((I,13),(J,8),)]
            tu += 1/4*g[dei(p[I,0],p[I,1],p[I,0],p[J,1])]*r[I][114][13,0]*r[J][7][8,0]*t[((I,13),(J,8),)]
            tu += 1/4*g[dei(p[I,0],p[I,0],p[I,1],p[J,1])]*r[I][162][13,0]*r[J][7][8,0]*t[((I,13),(J,8),)]
            tu += -1/2*g[dei(p[I,1],p[J,0],p[J,0],p[J,1])]*r[I][6][13,0]*r[J][129][8,0]*t[((I,13),(J,8),)]
            tu += -1/2*g[dei(p[I,1],p[J,1],p[J,1],p[J,1])]*r[I][6][13,0]*r[J][149][8,0]*t[((I,13),(J,8),)]
            tu += sum(1/2*g[dei(p[I,1],p[J,1],p[K,0],p[K,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][24][0,0]*t[((I,13),(J,8),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,1],p[J,1],p[K,0],p[K,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][9][0,0]*t[((I,13),(J,8),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,1],p[J,1],p[K,1],p[K,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][54][0,0]*t[((I,13),(J,8),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,1],p[J,1],p[K,1],p[K,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][39][0,0]*t[((I,13),(J,8),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,1],p[K,0],p[J,1],p[K,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][24][0,0]*t[((I,13),(J,8),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,1],p[K,1],p[J,1],p[K,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][54][0,0]*t[((I,13),(J,8),)] for K in range(np) if K not in {I,J})
            # ({I}_{9}, {J}_{12})
            tu += -1/2*h[p[I,0],p[J,0]]*r[I][1][9,0]*r[J][0][12,0]*t[((I,9),(J,12),)]
            tu += -1/2*g[dei(p[I,0],p[I,0],p[I,0],p[J,0])]*r[I][97][9,0]*r[J][0][12,0]*t[((I,9),(J,12),)]
            tu += -1/2*g[dei(p[I,0],p[I,1],p[I,1],p[J,0])]*r[I][117][9,0]*r[J][0][12,0]*t[((I,9),(J,12),)]
            tu += -1/4*g[dei(p[I,0],p[J,0],p[J,1],p[J,1])]*r[I][1][9,0]*r[J][76][12,0]*t[((I,9),(J,12),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[J,1],p[J,1])]*r[I][1][9,0]*r[J][86][12,0]*t[((I,9),(J,12),)]
            tu += -1/4*g[dei(p[I,0],p[J,1],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][124][12,0]*t[((I,9),(J,12),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][146][12,0]*t[((I,9),(J,12),)]
            tu += 1/4*g[dei(p[I,0],p[J,1],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][76][12,0]*t[((I,9),(J,12),)]
            tu += 1/4*g[dei(p[I,0],p[J,0],p[J,1],p[J,1])]*r[I][1][9,0]*r[J][124][12,0]*t[((I,9),(J,12),)]
            tu += sum(-1/2*g[dei(p[I,0],p[J,0],p[K,0],p[K,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][9][0,0]*t[((I,9),(J,12),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,0],p[J,0],p[K,1],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][39][0,0]*t[((I,9),(J,12),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,0],p[K,0],p[J,0],p[K,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][9][0,0]*t[((I,9),(J,12),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,0],p[K,1],p[J,0],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][39][0,0]*t[((I,9),(J,12),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,0],p[J,0],p[K,0],p[K,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][24][0,0]*t[((I,9),(J,12),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,0],p[J,0],p[K,1],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][54][0,0]*t[((I,9),(J,12),)] for K in range(np) if K not in {I,J})
            # ({I}_{7}, {J}_{14})
            tu += -1/2*h[p[I,0],p[J,0]]*r[I][3][7,0]*r[J][2][14,0]*t[((I,7),(J,14),)]
            tu += 1/2*g[dei(p[I,0],p[I,0],p[I,0],p[J,0])]*r[I][65][7,0]*r[J][2][14,0]*t[((I,7),(J,14),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[I,1],p[J,0])]*r[I][85][7,0]*r[J][2][14,0]*t[((I,7),(J,14),)]
            tu += -1/4*g[dei(p[I,0],p[J,0],p[J,1],p[J,1])]*r[I][3][7,0]*r[J][118][14,0]*t[((I,7),(J,14),)]
            tu += -1/4*g[dei(p[I,0],p[J,1],p[J,0],p[J,1])]*r[I][3][7,0]*r[J][166][14,0]*t[((I,7),(J,14),)]
            tu += 1/4*g[dei(p[I,0],p[J,1],p[J,0],p[J,1])]*r[I][3][7,0]*r[J][118][14,0]*t[((I,7),(J,14),)]
            tu += 1/4*g[dei(p[I,0],p[J,0],p[J,1],p[J,1])]*r[I][3][7,0]*r[J][166][14,0]*t[((I,7),(J,14),)]
            tu += 1/2*g[dei(p[I,0],p[J,0],p[J,1],p[J,1])]*r[I][3][7,0]*r[J][132][14,0]*t[((I,7),(J,14),)]
            tu += 1/2*g[dei(p[I,0],p[J,1],p[J,0],p[J,1])]*r[I][3][7,0]*r[J][144][14,0]*t[((I,7),(J,14),)]
            tu += sum(-1/2*g[dei(p[I,0],p[J,0],p[K,0],p[K,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][24][0,0]*t[((I,7),(J,14),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,0],p[J,0],p[K,0],p[K,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][9][0,0]*t[((I,7),(J,14),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,0],p[J,0],p[K,1],p[K,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][54][0,0]*t[((I,7),(J,14),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,0],p[J,0],p[K,1],p[K,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][39][0,0]*t[((I,7),(J,14),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,0],p[K,0],p[J,0],p[K,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][24][0,0]*t[((I,7),(J,14),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,0],p[K,1],p[J,0],p[K,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][54][0,0]*t[((I,7),(J,14),)] for K in range(np) if K not in {I,J})
            # ({I}_{10}, {J}_{12})
            tu += -1/2*h[p[I,1],p[J,0]]*r[I][5][10,0]*r[J][0][12,0]*t[((I,10),(J,12),)]
            tu += -1/2*g[dei(p[I,0],p[I,1],p[I,0],p[J,0])]*r[I][161][10,0]*r[J][0][12,0]*t[((I,10),(J,12),)]
            tu += -1/2*g[dei(p[I,1],p[I,1],p[I,1],p[J,0])]*r[I][181][10,0]*r[J][0][12,0]*t[((I,10),(J,12),)]
            tu += -1/4*g[dei(p[I,1],p[J,0],p[J,1],p[J,1])]*r[I][5][10,0]*r[J][76][12,0]*t[((I,10),(J,12),)]
            tu += -1/2*g[dei(p[I,1],p[J,0],p[J,1],p[J,1])]*r[I][5][10,0]*r[J][86][12,0]*t[((I,10),(J,12),)]
            tu += -1/4*g[dei(p[I,1],p[J,1],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][124][12,0]*t[((I,10),(J,12),)]
            tu += -1/2*g[dei(p[I,1],p[J,1],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][146][12,0]*t[((I,10),(J,12),)]
            tu += 1/4*g[dei(p[I,1],p[J,1],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][76][12,0]*t[((I,10),(J,12),)]
            tu += 1/4*g[dei(p[I,1],p[J,0],p[J,1],p[J,1])]*r[I][5][10,0]*r[J][124][12,0]*t[((I,10),(J,12),)]
            tu += sum(-1/2*g[dei(p[I,1],p[J,0],p[K,0],p[K,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][9][0,0]*t[((I,10),(J,12),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,1],p[J,0],p[K,1],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][39][0,0]*t[((I,10),(J,12),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,1],p[K,0],p[J,0],p[K,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][9][0,0]*t[((I,10),(J,12),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,1],p[K,1],p[J,0],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][39][0,0]*t[((I,10),(J,12),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,1],p[J,0],p[K,0],p[K,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][24][0,0]*t[((I,10),(J,12),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,1],p[J,0],p[K,1],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][54][0,0]*t[((I,10),(J,12),)] for K in range(np) if K not in {I,J})
            # ({I}_{8}, {J}_{14})
            tu += -1/2*h[p[I,1],p[J,0]]*r[I][7][8,0]*r[J][2][14,0]*t[((I,8),(J,14),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[I,0],p[J,0])]*r[I][129][8,0]*r[J][2][14,0]*t[((I,8),(J,14),)]
            tu += 1/2*g[dei(p[I,1],p[I,1],p[I,1],p[J,0])]*r[I][149][8,0]*r[J][2][14,0]*t[((I,8),(J,14),)]
            tu += -1/4*g[dei(p[I,1],p[J,0],p[J,1],p[J,1])]*r[I][7][8,0]*r[J][118][14,0]*t[((I,8),(J,14),)]
            tu += -1/4*g[dei(p[I,1],p[J,1],p[J,0],p[J,1])]*r[I][7][8,0]*r[J][166][14,0]*t[((I,8),(J,14),)]
            tu += 1/4*g[dei(p[I,1],p[J,1],p[J,0],p[J,1])]*r[I][7][8,0]*r[J][118][14,0]*t[((I,8),(J,14),)]
            tu += 1/4*g[dei(p[I,1],p[J,0],p[J,1],p[J,1])]*r[I][7][8,0]*r[J][166][14,0]*t[((I,8),(J,14),)]
            tu += 1/2*g[dei(p[I,1],p[J,0],p[J,1],p[J,1])]*r[I][7][8,0]*r[J][132][14,0]*t[((I,8),(J,14),)]
            tu += 1/2*g[dei(p[I,1],p[J,1],p[J,0],p[J,1])]*r[I][7][8,0]*r[J][144][14,0]*t[((I,8),(J,14),)]
            tu += sum(-1/2*g[dei(p[I,1],p[J,0],p[K,0],p[K,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][24][0,0]*t[((I,8),(J,14),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,1],p[J,0],p[K,0],p[K,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][9][0,0]*t[((I,8),(J,14),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,1],p[J,0],p[K,1],p[K,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][54][0,0]*t[((I,8),(J,14),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,1],p[J,0],p[K,1],p[K,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][39][0,0]*t[((I,8),(J,14),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,1],p[K,0],p[J,0],p[K,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][24][0,0]*t[((I,8),(J,14),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,1],p[K,1],p[J,0],p[K,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][54][0,0]*t[((I,8),(J,14),)] for K in range(np) if K not in {I,J})
            # ({I}_{9}, {J}_{11})
            tu += -1/2*h[p[I,0],p[J,1]]*r[I][1][9,0]*r[J][4][11,0]*t[((I,9),(J,11),)]
            tu += -1/2*g[dei(p[I,0],p[I,0],p[I,0],p[J,1])]*r[I][97][9,0]*r[J][4][11,0]*t[((I,9),(J,11),)]
            tu += -1/2*g[dei(p[I,0],p[I,1],p[I,1],p[J,1])]*r[I][117][9,0]*r[J][4][11,0]*t[((I,9),(J,11),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][70][11,0]*t[((I,9),(J,11),)]
            tu += -1/4*g[dei(p[I,0],p[J,0],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][72][11,0]*t[((I,9),(J,11),)]
            tu += -1/4*g[dei(p[I,0],p[J,1],p[J,0],p[J,0])]*r[I][1][9,0]*r[J][120][11,0]*t[((I,9),(J,11),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[J,0],p[J,0])]*r[I][1][9,0]*r[J][130][11,0]*t[((I,9),(J,11),)]
            tu += 1/4*g[dei(p[I,0],p[J,1],p[J,0],p[J,0])]*r[I][1][9,0]*r[J][72][11,0]*t[((I,9),(J,11),)]
            tu += 1/4*g[dei(p[I,0],p[J,0],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][120][11,0]*t[((I,9),(J,11),)]
            tu += sum(-1/2*g[dei(p[I,0],p[J,1],p[K,0],p[K,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][9][0,0]*t[((I,9),(J,11),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,0],p[J,1],p[K,1],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][39][0,0]*t[((I,9),(J,11),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,0],p[K,0],p[J,1],p[K,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][9][0,0]*t[((I,9),(J,11),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,0],p[K,1],p[J,1],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][39][0,0]*t[((I,9),(J,11),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,0],p[J,1],p[K,0],p[K,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][24][0,0]*t[((I,9),(J,11),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,0],p[J,1],p[K,1],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][54][0,0]*t[((I,9),(J,11),)] for K in range(np) if K not in {I,J})
            # ({I}_{7}, {J}_{13})
            tu += -1/2*h[p[I,0],p[J,1]]*r[I][3][7,0]*r[J][6][13,0]*t[((I,7),(J,13),)]
            tu += 1/2*g[dei(p[I,0],p[I,0],p[I,0],p[J,1])]*r[I][65][7,0]*r[J][6][13,0]*t[((I,7),(J,13),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[I,1],p[J,1])]*r[I][85][7,0]*r[J][6][13,0]*t[((I,7),(J,13),)]
            tu += -1/4*g[dei(p[I,0],p[J,0],p[J,0],p[J,1])]*r[I][3][7,0]*r[J][114][13,0]*t[((I,7),(J,13),)]
            tu += -1/4*g[dei(p[I,0],p[J,1],p[J,0],p[J,0])]*r[I][3][7,0]*r[J][162][13,0]*t[((I,7),(J,13),)]
            tu += 1/2*g[dei(p[I,0],p[J,0],p[J,0],p[J,1])]*r[I][3][7,0]*r[J][68][13,0]*t[((I,7),(J,13),)]
            tu += 1/4*g[dei(p[I,0],p[J,1],p[J,0],p[J,0])]*r[I][3][7,0]*r[J][114][13,0]*t[((I,7),(J,13),)]
            tu += 1/2*g[dei(p[I,0],p[J,1],p[J,0],p[J,0])]*r[I][3][7,0]*r[J][80][13,0]*t[((I,7),(J,13),)]
            tu += 1/4*g[dei(p[I,0],p[J,0],p[J,0],p[J,1])]*r[I][3][7,0]*r[J][162][13,0]*t[((I,7),(J,13),)]
            tu += sum(-1/2*g[dei(p[I,0],p[J,1],p[K,0],p[K,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][24][0,0]*t[((I,7),(J,13),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,0],p[J,1],p[K,0],p[K,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][9][0,0]*t[((I,7),(J,13),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,0],p[J,1],p[K,1],p[K,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][54][0,0]*t[((I,7),(J,13),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,0],p[J,1],p[K,1],p[K,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][39][0,0]*t[((I,7),(J,13),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,0],p[K,0],p[J,1],p[K,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][24][0,0]*t[((I,7),(J,13),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,0],p[K,1],p[J,1],p[K,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][54][0,0]*t[((I,7),(J,13),)] for K in range(np) if K not in {I,J})
            # ({I}_{10}, {J}_{11})
            tu += -1/2*h[p[I,1],p[J,1]]*r[I][5][10,0]*r[J][4][11,0]*t[((I,10),(J,11),)]
            tu += -1/2*g[dei(p[I,0],p[I,1],p[I,0],p[J,1])]*r[I][161][10,0]*r[J][4][11,0]*t[((I,10),(J,11),)]
            tu += -1/2*g[dei(p[I,1],p[I,1],p[I,1],p[J,1])]*r[I][181][10,0]*r[J][4][11,0]*t[((I,10),(J,11),)]
            tu += -1/2*g[dei(p[I,1],p[J,0],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][70][11,0]*t[((I,10),(J,11),)]
            tu += -1/4*g[dei(p[I,1],p[J,0],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][72][11,0]*t[((I,10),(J,11),)]
            tu += -1/4*g[dei(p[I,1],p[J,1],p[J,0],p[J,0])]*r[I][5][10,0]*r[J][120][11,0]*t[((I,10),(J,11),)]
            tu += -1/2*g[dei(p[I,1],p[J,1],p[J,0],p[J,0])]*r[I][5][10,0]*r[J][130][11,0]*t[((I,10),(J,11),)]
            tu += 1/4*g[dei(p[I,1],p[J,1],p[J,0],p[J,0])]*r[I][5][10,0]*r[J][72][11,0]*t[((I,10),(J,11),)]
            tu += 1/4*g[dei(p[I,1],p[J,0],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][120][11,0]*t[((I,10),(J,11),)]
            tu += sum(-1/2*g[dei(p[I,1],p[J,1],p[K,0],p[K,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][9][0,0]*t[((I,10),(J,11),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,1],p[J,1],p[K,1],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][39][0,0]*t[((I,10),(J,11),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,1],p[K,0],p[J,1],p[K,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][9][0,0]*t[((I,10),(J,11),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,1],p[K,1],p[J,1],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][39][0,0]*t[((I,10),(J,11),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,1],p[J,1],p[K,0],p[K,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][24][0,0]*t[((I,10),(J,11),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,1],p[J,1],p[K,1],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][54][0,0]*t[((I,10),(J,11),)] for K in range(np) if K not in {I,J})
            # ({I}_{8}, {J}_{13})
            tu += -1/2*h[p[I,1],p[J,1]]*r[I][7][8,0]*r[J][6][13,0]*t[((I,8),(J,13),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[I,0],p[J,1])]*r[I][129][8,0]*r[J][6][13,0]*t[((I,8),(J,13),)]
            tu += 1/2*g[dei(p[I,1],p[I,1],p[I,1],p[J,1])]*r[I][149][8,0]*r[J][6][13,0]*t[((I,8),(J,13),)]
            tu += -1/4*g[dei(p[I,1],p[J,0],p[J,0],p[J,1])]*r[I][7][8,0]*r[J][114][13,0]*t[((I,8),(J,13),)]
            tu += -1/4*g[dei(p[I,1],p[J,1],p[J,0],p[J,0])]*r[I][7][8,0]*r[J][162][13,0]*t[((I,8),(J,13),)]
            tu += 1/2*g[dei(p[I,1],p[J,0],p[J,0],p[J,1])]*r[I][7][8,0]*r[J][68][13,0]*t[((I,8),(J,13),)]
            tu += 1/4*g[dei(p[I,1],p[J,1],p[J,0],p[J,0])]*r[I][7][8,0]*r[J][114][13,0]*t[((I,8),(J,13),)]
            tu += 1/2*g[dei(p[I,1],p[J,1],p[J,0],p[J,0])]*r[I][7][8,0]*r[J][80][13,0]*t[((I,8),(J,13),)]
            tu += 1/4*g[dei(p[I,1],p[J,0],p[J,0],p[J,1])]*r[I][7][8,0]*r[J][162][13,0]*t[((I,8),(J,13),)]
            tu += sum(-1/2*g[dei(p[I,1],p[J,1],p[K,0],p[K,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][24][0,0]*t[((I,8),(J,13),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,1],p[J,1],p[K,0],p[K,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][9][0,0]*t[((I,8),(J,13),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,1],p[J,1],p[K,1],p[K,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][54][0,0]*t[((I,8),(J,13),)] for K in range(np) if K not in {I,J})
            tu += sum(-1/2*g[dei(p[I,1],p[J,1],p[K,1],p[K,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][39][0,0]*t[((I,8),(J,13),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,1],p[K,0],p[J,1],p[K,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][24][0,0]*t[((I,8),(J,13),)] for K in range(np) if K not in {I,J})
            tu += sum(1/2*g[dei(p[I,1],p[K,1],p[J,1],p[K,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][54][0,0]*t[((I,8),(J,13),)] for K in range(np) if K not in {I,J})
            # ({I}_{15}, {J}_{6})
            tu += 1/2*g[dei(p[I,0],p[J,0],p[I,0],p[J,0])]*r[I][11][15,0]*r[J][22][6,0]*t[((I,15),(J,6),)]
            tu += 1/2*g[dei(p[I,0],p[J,1],p[I,0],p[J,1])]*r[I][11][15,0]*r[J][52][6,0]*t[((I,15),(J,6),)]
            tu += 1/2*g[dei(p[I,1],p[J,0],p[I,1],p[J,0])]*r[I][41][15,0]*r[J][22][6,0]*t[((I,15),(J,6),)]
            tu += 1/2*g[dei(p[I,1],p[J,1],p[I,1],p[J,1])]*r[I][41][15,0]*r[J][52][6,0]*t[((I,15),(J,6),)]
            # ({I}_{1}, {J}_{1})
            tu += 1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][9][1,0]*r[J][9][1,0]*t[((I,1),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][24][1,0]*r[J][24][1,0]*t[((I,1),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][9][1,0]*r[J][24][1,0]*t[((I,1),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][9][1,0]*r[J][39][1,0]*t[((I,1),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][24][1,0]*r[J][54][1,0]*t[((I,1),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][9][1,0]*r[J][54][1,0]*t[((I,1),(J,1),)]
            tu += 1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][39][1,0]*r[J][9][1,0]*t[((I,1),(J,1),)]
            tu += 1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][54][1,0]*r[J][24][1,0]*t[((I,1),(J,1),)]
            tu += 1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][39][1,0]*r[J][24][1,0]*t[((I,1),(J,1),)]
            tu += 1/2*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][39][1,0]*r[J][39][1,0]*t[((I,1),(J,1),)]
            tu += 1/2*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][54][1,0]*r[J][54][1,0]*t[((I,1),(J,1),)]
            tu += 1/2*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][39][1,0]*r[J][54][1,0]*t[((I,1),(J,1),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,0],p[J,0])]*r[I][9][1,0]*r[J][9][1,0]*t[((I,1),(J,1),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,0],p[J,0])]*r[I][24][1,0]*r[J][24][1,0]*t[((I,1),(J,1),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[I,0],p[J,1])]*r[I][9][1,0]*r[J][39][1,0]*t[((I,1),(J,1),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[I,0],p[J,1])]*r[I][24][1,0]*r[J][54][1,0]*t[((I,1),(J,1),)]
            tu += -1/2*g[dei(p[I,1],p[J,0],p[I,1],p[J,0])]*r[I][39][1,0]*r[J][9][1,0]*t[((I,1),(J,1),)]
            tu += -1/2*g[dei(p[I,1],p[J,0],p[I,1],p[J,0])]*r[I][54][1,0]*r[J][24][1,0]*t[((I,1),(J,1),)]
            tu += -1/2*g[dei(p[I,1],p[J,1],p[I,1],p[J,1])]*r[I][39][1,0]*r[J][39][1,0]*t[((I,1),(J,1),)]
            tu += -1/2*g[dei(p[I,1],p[J,1],p[I,1],p[J,1])]*r[I][54][1,0]*r[J][54][1,0]*t[((I,1),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,0])]*r[I][24][1,0]*r[J][9][1,0]*t[((I,1),(J,1),)]
            tu += 1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,0])]*r[I][54][1,0]*r[J][9][1,0]*t[((I,1),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,0],p[J,1],p[J,1])]*r[I][24][1,0]*r[J][39][1,0]*t[((I,1),(J,1),)]
            tu += 1/2*g[dei(p[I,1],p[I,1],p[J,1],p[J,1])]*r[I][54][1,0]*r[J][39][1,0]*t[((I,1),(J,1),)]
            # ({I}_{1}, {J}_{2})
            tu += 1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,1])]*r[I][9][1,0]*r[J][15][2,0]*t[((I,1),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,1])]*r[I][24][1,0]*r[J][30][2,0]*t[((I,1),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,1])]*r[I][9][1,0]*r[J][30][2,0]*t[((I,1),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,1])]*r[I][9][1,0]*r[J][33][2,0]*t[((I,1),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,1])]*r[I][24][1,0]*r[J][48][2,0]*t[((I,1),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,1])]*r[I][9][1,0]*r[J][48][2,0]*t[((I,1),(J,2),)]
            tu += 1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,1])]*r[I][39][1,0]*r[J][15][2,0]*t[((I,1),(J,2),)]
            tu += 1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,1])]*r[I][54][1,0]*r[J][30][2,0]*t[((I,1),(J,2),)]
            tu += 1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,1])]*r[I][39][1,0]*r[J][30][2,0]*t[((I,1),(J,2),)]
            tu += 1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,1])]*r[I][39][1,0]*r[J][33][2,0]*t[((I,1),(J,2),)]
            tu += 1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,1])]*r[I][54][1,0]*r[J][48][2,0]*t[((I,1),(J,2),)]
            tu += 1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,1])]*r[I][39][1,0]*r[J][48][2,0]*t[((I,1),(J,2),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,0],p[J,1])]*r[I][9][1,0]*r[J][15][2,0]*t[((I,1),(J,2),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,0],p[J,1])]*r[I][24][1,0]*r[J][30][2,0]*t[((I,1),(J,2),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,0],p[J,1])]*r[I][9][1,0]*r[J][33][2,0]*t[((I,1),(J,2),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,0],p[J,1])]*r[I][24][1,0]*r[J][48][2,0]*t[((I,1),(J,2),)]
            tu += -1/2*g[dei(p[I,1],p[J,0],p[I,1],p[J,1])]*r[I][39][1,0]*r[J][15][2,0]*t[((I,1),(J,2),)]
            tu += -1/2*g[dei(p[I,1],p[J,0],p[I,1],p[J,1])]*r[I][54][1,0]*r[J][30][2,0]*t[((I,1),(J,2),)]
            tu += -1/2*g[dei(p[I,1],p[J,0],p[I,1],p[J,1])]*r[I][39][1,0]*r[J][33][2,0]*t[((I,1),(J,2),)]
            tu += -1/2*g[dei(p[I,1],p[J,0],p[I,1],p[J,1])]*r[I][54][1,0]*r[J][48][2,0]*t[((I,1),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,1])]*r[I][24][1,0]*r[J][15][2,0]*t[((I,1),(J,2),)]
            tu += 1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,1])]*r[I][54][1,0]*r[J][15][2,0]*t[((I,1),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,1])]*r[I][24][1,0]*r[J][33][2,0]*t[((I,1),(J,2),)]
            tu += 1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,1])]*r[I][54][1,0]*r[J][33][2,0]*t[((I,1),(J,2),)]
            # ({I}_{1}, {J}_{3})
            tu += 1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,1])]*r[I][9][1,0]*r[J][15][3,0]*t[((I,1),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,1])]*r[I][24][1,0]*r[J][30][3,0]*t[((I,1),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,1])]*r[I][9][1,0]*r[J][30][3,0]*t[((I,1),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,1])]*r[I][9][1,0]*r[J][33][3,0]*t[((I,1),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,1])]*r[I][24][1,0]*r[J][48][3,0]*t[((I,1),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,1])]*r[I][9][1,0]*r[J][48][3,0]*t[((I,1),(J,3),)]
            tu += 1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,1])]*r[I][39][1,0]*r[J][15][3,0]*t[((I,1),(J,3),)]
            tu += 1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,1])]*r[I][54][1,0]*r[J][30][3,0]*t[((I,1),(J,3),)]
            tu += 1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,1])]*r[I][39][1,0]*r[J][30][3,0]*t[((I,1),(J,3),)]
            tu += 1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,1])]*r[I][39][1,0]*r[J][33][3,0]*t[((I,1),(J,3),)]
            tu += 1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,1])]*r[I][54][1,0]*r[J][48][3,0]*t[((I,1),(J,3),)]
            tu += 1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,1])]*r[I][39][1,0]*r[J][48][3,0]*t[((I,1),(J,3),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,0],p[J,1])]*r[I][9][1,0]*r[J][15][3,0]*t[((I,1),(J,3),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,0],p[J,1])]*r[I][24][1,0]*r[J][30][3,0]*t[((I,1),(J,3),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,0],p[J,1])]*r[I][9][1,0]*r[J][33][3,0]*t[((I,1),(J,3),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,0],p[J,1])]*r[I][24][1,0]*r[J][48][3,0]*t[((I,1),(J,3),)]
            tu += -1/2*g[dei(p[I,1],p[J,0],p[I,1],p[J,1])]*r[I][39][1,0]*r[J][15][3,0]*t[((I,1),(J,3),)]
            tu += -1/2*g[dei(p[I,1],p[J,0],p[I,1],p[J,1])]*r[I][54][1,0]*r[J][30][3,0]*t[((I,1),(J,3),)]
            tu += -1/2*g[dei(p[I,1],p[J,0],p[I,1],p[J,1])]*r[I][39][1,0]*r[J][33][3,0]*t[((I,1),(J,3),)]
            tu += -1/2*g[dei(p[I,1],p[J,0],p[I,1],p[J,1])]*r[I][54][1,0]*r[J][48][3,0]*t[((I,1),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,1])]*r[I][24][1,0]*r[J][15][3,0]*t[((I,1),(J,3),)]
            tu += 1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,1])]*r[I][54][1,0]*r[J][15][3,0]*t[((I,1),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,0],p[J,0],p[J,1])]*r[I][24][1,0]*r[J][33][3,0]*t[((I,1),(J,3),)]
            tu += 1/2*g[dei(p[I,1],p[I,1],p[J,0],p[J,1])]*r[I][54][1,0]*r[J][33][3,0]*t[((I,1),(J,3),)]
            # ({I}_{2}, {J}_{1})
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][15][2,0]*r[J][9][1,0]*t[((I,2),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][30][2,0]*r[J][24][1,0]*t[((I,2),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][15][2,0]*r[J][24][1,0]*t[((I,2),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][15][2,0]*r[J][39][1,0]*t[((I,2),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][30][2,0]*r[J][54][1,0]*t[((I,2),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][15][2,0]*r[J][54][1,0]*t[((I,2),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][33][2,0]*r[J][9][1,0]*t[((I,2),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][48][2,0]*r[J][24][1,0]*t[((I,2),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][33][2,0]*r[J][24][1,0]*t[((I,2),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][33][2,0]*r[J][39][1,0]*t[((I,2),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][48][2,0]*r[J][54][1,0]*t[((I,2),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][33][2,0]*r[J][54][1,0]*t[((I,2),(J,1),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,1],p[J,0])]*r[I][15][2,0]*r[J][9][1,0]*t[((I,2),(J,1),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,1],p[J,0])]*r[I][30][2,0]*r[J][24][1,0]*t[((I,2),(J,1),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[I,1],p[J,1])]*r[I][15][2,0]*r[J][39][1,0]*t[((I,2),(J,1),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[I,1],p[J,1])]*r[I][30][2,0]*r[J][54][1,0]*t[((I,2),(J,1),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,1],p[J,0])]*r[I][33][2,0]*r[J][9][1,0]*t[((I,2),(J,1),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,1],p[J,0])]*r[I][48][2,0]*r[J][24][1,0]*t[((I,2),(J,1),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[I,1],p[J,1])]*r[I][33][2,0]*r[J][39][1,0]*t[((I,2),(J,1),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[I,1],p[J,1])]*r[I][48][2,0]*r[J][54][1,0]*t[((I,2),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][30][2,0]*r[J][9][1,0]*t[((I,2),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][48][2,0]*r[J][9][1,0]*t[((I,2),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][30][2,0]*r[J][39][1,0]*t[((I,2),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][48][2,0]*r[J][39][1,0]*t[((I,2),(J,1),)]
            # ({I}_{3}, {J}_{1})
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][15][3,0]*r[J][9][1,0]*t[((I,3),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][30][3,0]*r[J][24][1,0]*t[((I,3),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][15][3,0]*r[J][24][1,0]*t[((I,3),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][15][3,0]*r[J][39][1,0]*t[((I,3),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][30][3,0]*r[J][54][1,0]*t[((I,3),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][15][3,0]*r[J][54][1,0]*t[((I,3),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][33][3,0]*r[J][9][1,0]*t[((I,3),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][48][3,0]*r[J][24][1,0]*t[((I,3),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][33][3,0]*r[J][24][1,0]*t[((I,3),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][33][3,0]*r[J][39][1,0]*t[((I,3),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][48][3,0]*r[J][54][1,0]*t[((I,3),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][33][3,0]*r[J][54][1,0]*t[((I,3),(J,1),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,1],p[J,0])]*r[I][15][3,0]*r[J][9][1,0]*t[((I,3),(J,1),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,1],p[J,0])]*r[I][30][3,0]*r[J][24][1,0]*t[((I,3),(J,1),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[I,1],p[J,1])]*r[I][15][3,0]*r[J][39][1,0]*t[((I,3),(J,1),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[I,1],p[J,1])]*r[I][30][3,0]*r[J][54][1,0]*t[((I,3),(J,1),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,1],p[J,0])]*r[I][33][3,0]*r[J][9][1,0]*t[((I,3),(J,1),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,1],p[J,0])]*r[I][48][3,0]*r[J][24][1,0]*t[((I,3),(J,1),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[I,1],p[J,1])]*r[I][33][3,0]*r[J][39][1,0]*t[((I,3),(J,1),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[I,1],p[J,1])]*r[I][48][3,0]*r[J][54][1,0]*t[((I,3),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][30][3,0]*r[J][9][1,0]*t[((I,3),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,0])]*r[I][48][3,0]*r[J][9][1,0]*t[((I,3),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][30][3,0]*r[J][39][1,0]*t[((I,3),(J,1),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,1],p[J,1])]*r[I][48][3,0]*r[J][39][1,0]*t[((I,3),(J,1),)]
            # ({I}_{2}, {J}_{2})
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][15][2,0]*r[J][15][2,0]*t[((I,2),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][30][2,0]*r[J][30][2,0]*t[((I,2),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][15][2,0]*r[J][30][2,0]*t[((I,2),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][15][2,0]*r[J][33][2,0]*t[((I,2),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][30][2,0]*r[J][48][2,0]*t[((I,2),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][15][2,0]*r[J][48][2,0]*t[((I,2),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][33][2,0]*r[J][15][2,0]*t[((I,2),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][48][2,0]*r[J][30][2,0]*t[((I,2),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][33][2,0]*r[J][30][2,0]*t[((I,2),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][33][2,0]*r[J][33][2,0]*t[((I,2),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][48][2,0]*r[J][48][2,0]*t[((I,2),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][33][2,0]*r[J][48][2,0]*t[((I,2),(J,2),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[I,1],p[J,0])]*r[I][15][2,0]*r[J][15][2,0]*t[((I,2),(J,2),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[I,1],p[J,0])]*r[I][30][2,0]*r[J][30][2,0]*t[((I,2),(J,2),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,1],p[J,1])]*r[I][15][2,0]*r[J][33][2,0]*t[((I,2),(J,2),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,1],p[J,1])]*r[I][30][2,0]*r[J][48][2,0]*t[((I,2),(J,2),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,1],p[J,1])]*r[I][33][2,0]*r[J][15][2,0]*t[((I,2),(J,2),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,1],p[J,1])]*r[I][48][2,0]*r[J][30][2,0]*t[((I,2),(J,2),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[I,1],p[J,0])]*r[I][33][2,0]*r[J][33][2,0]*t[((I,2),(J,2),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[I,1],p[J,0])]*r[I][48][2,0]*r[J][48][2,0]*t[((I,2),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][30][2,0]*r[J][15][2,0]*t[((I,2),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][48][2,0]*r[J][15][2,0]*t[((I,2),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][30][2,0]*r[J][33][2,0]*t[((I,2),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][48][2,0]*r[J][33][2,0]*t[((I,2),(J,2),)]
            # ({I}_{2}, {J}_{3})
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][15][2,0]*r[J][15][3,0]*t[((I,2),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][30][2,0]*r[J][30][3,0]*t[((I,2),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][15][2,0]*r[J][30][3,0]*t[((I,2),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][15][2,0]*r[J][33][3,0]*t[((I,2),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][30][2,0]*r[J][48][3,0]*t[((I,2),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][15][2,0]*r[J][48][3,0]*t[((I,2),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][33][2,0]*r[J][15][3,0]*t[((I,2),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][48][2,0]*r[J][30][3,0]*t[((I,2),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][33][2,0]*r[J][30][3,0]*t[((I,2),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][33][2,0]*r[J][33][3,0]*t[((I,2),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][48][2,0]*r[J][48][3,0]*t[((I,2),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][33][2,0]*r[J][48][3,0]*t[((I,2),(J,3),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[I,1],p[J,0])]*r[I][15][2,0]*r[J][15][3,0]*t[((I,2),(J,3),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[I,1],p[J,0])]*r[I][30][2,0]*r[J][30][3,0]*t[((I,2),(J,3),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,1],p[J,1])]*r[I][15][2,0]*r[J][33][3,0]*t[((I,2),(J,3),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,1],p[J,1])]*r[I][30][2,0]*r[J][48][3,0]*t[((I,2),(J,3),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,1],p[J,1])]*r[I][33][2,0]*r[J][15][3,0]*t[((I,2),(J,3),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,1],p[J,1])]*r[I][48][2,0]*r[J][30][3,0]*t[((I,2),(J,3),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[I,1],p[J,0])]*r[I][33][2,0]*r[J][33][3,0]*t[((I,2),(J,3),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[I,1],p[J,0])]*r[I][48][2,0]*r[J][48][3,0]*t[((I,2),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][30][2,0]*r[J][15][3,0]*t[((I,2),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][48][2,0]*r[J][15][3,0]*t[((I,2),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][30][2,0]*r[J][33][3,0]*t[((I,2),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][48][2,0]*r[J][33][3,0]*t[((I,2),(J,3),)]
            # ({I}_{3}, {J}_{2})
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][15][3,0]*r[J][15][2,0]*t[((I,3),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][30][3,0]*r[J][30][2,0]*t[((I,3),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][15][3,0]*r[J][30][2,0]*t[((I,3),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][15][3,0]*r[J][33][2,0]*t[((I,3),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][30][3,0]*r[J][48][2,0]*t[((I,3),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][15][3,0]*r[J][48][2,0]*t[((I,3),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][33][3,0]*r[J][15][2,0]*t[((I,3),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][48][3,0]*r[J][30][2,0]*t[((I,3),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][33][3,0]*r[J][30][2,0]*t[((I,3),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][33][3,0]*r[J][33][2,0]*t[((I,3),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][48][3,0]*r[J][48][2,0]*t[((I,3),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][33][3,0]*r[J][48][2,0]*t[((I,3),(J,2),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[I,1],p[J,0])]*r[I][15][3,0]*r[J][15][2,0]*t[((I,3),(J,2),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[I,1],p[J,0])]*r[I][30][3,0]*r[J][30][2,0]*t[((I,3),(J,2),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,1],p[J,1])]*r[I][15][3,0]*r[J][33][2,0]*t[((I,3),(J,2),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,1],p[J,1])]*r[I][30][3,0]*r[J][48][2,0]*t[((I,3),(J,2),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,1],p[J,1])]*r[I][33][3,0]*r[J][15][2,0]*t[((I,3),(J,2),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,1],p[J,1])]*r[I][48][3,0]*r[J][30][2,0]*t[((I,3),(J,2),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[I,1],p[J,0])]*r[I][33][3,0]*r[J][33][2,0]*t[((I,3),(J,2),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[I,1],p[J,0])]*r[I][48][3,0]*r[J][48][2,0]*t[((I,3),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][30][3,0]*r[J][15][2,0]*t[((I,3),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][48][3,0]*r[J][15][2,0]*t[((I,3),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][30][3,0]*r[J][33][2,0]*t[((I,3),(J,2),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][48][3,0]*r[J][33][2,0]*t[((I,3),(J,2),)]
            # ({I}_{3}, {J}_{3})
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][15][3,0]*r[J][15][3,0]*t[((I,3),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][30][3,0]*r[J][30][3,0]*t[((I,3),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][15][3,0]*r[J][30][3,0]*t[((I,3),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][15][3,0]*r[J][33][3,0]*t[((I,3),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][30][3,0]*r[J][48][3,0]*t[((I,3),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][15][3,0]*r[J][48][3,0]*t[((I,3),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][33][3,0]*r[J][15][3,0]*t[((I,3),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][48][3,0]*r[J][30][3,0]*t[((I,3),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][33][3,0]*r[J][30][3,0]*t[((I,3),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][33][3,0]*r[J][33][3,0]*t[((I,3),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][48][3,0]*r[J][48][3,0]*t[((I,3),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][33][3,0]*r[J][48][3,0]*t[((I,3),(J,3),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[I,1],p[J,0])]*r[I][15][3,0]*r[J][15][3,0]*t[((I,3),(J,3),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[I,1],p[J,0])]*r[I][30][3,0]*r[J][30][3,0]*t[((I,3),(J,3),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,1],p[J,1])]*r[I][15][3,0]*r[J][33][3,0]*t[((I,3),(J,3),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,1],p[J,1])]*r[I][30][3,0]*r[J][48][3,0]*t[((I,3),(J,3),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,1],p[J,1])]*r[I][33][3,0]*r[J][15][3,0]*t[((I,3),(J,3),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,1],p[J,1])]*r[I][48][3,0]*r[J][30][3,0]*t[((I,3),(J,3),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[I,1],p[J,0])]*r[I][33][3,0]*r[J][33][3,0]*t[((I,3),(J,3),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[I,1],p[J,0])]*r[I][48][3,0]*r[J][48][3,0]*t[((I,3),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][30][3,0]*r[J][15][3,0]*t[((I,3),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][48][3,0]*r[J][15][3,0]*t[((I,3),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][30][3,0]*r[J][33][3,0]*t[((I,3),(J,3),)]
            tu += 1/2*g[dei(p[I,0],p[I,1],p[J,0],p[J,1])]*r[I][48][3,0]*r[J][33][3,0]*t[((I,3),(J,3),)]
            # ({I}_{4}, {J}_{5})
            tu += -1/2*g[dei(p[I,0],p[J,1],p[I,1],p[J,0])]*r[I][18][4,0]*r[J][27][5,0]*t[((I,4),(J,5),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,1],p[J,1])]*r[I][18][4,0]*r[J][45][5,0]*t[((I,4),(J,5),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,1],p[J,1])]*r[I][36][4,0]*r[J][27][5,0]*t[((I,4),(J,5),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[I,1],p[J,0])]*r[I][36][4,0]*r[J][45][5,0]*t[((I,4),(J,5),)]
            # ({I}_{5}, {J}_{4})
            tu += -1/2*g[dei(p[I,0],p[J,1],p[I,1],p[J,0])]*r[I][27][5,0]*r[J][18][4,0]*t[((I,5),(J,4),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,1],p[J,1])]*r[I][45][5,0]*r[J][18][4,0]*t[((I,5),(J,4),)]
            tu += -1/2*g[dei(p[I,0],p[J,0],p[I,1],p[J,1])]*r[I][27][5,0]*r[J][36][4,0]*t[((I,5),(J,4),)]
            tu += -1/2*g[dei(p[I,0],p[J,1],p[I,1],p[J,0])]*r[I][45][5,0]*r[J][36][4,0]*t[((I,5),(J,4),)]
            # ({I}_{6}, {J}_{15})
            tu += 1/2*g[dei(p[I,0],p[J,0],p[I,0],p[J,0])]*r[I][22][6,0]*r[J][11][15,0]*t[((I,6),(J,15),)]
            tu += 1/2*g[dei(p[I,1],p[J,0],p[I,1],p[J,0])]*r[I][52][6,0]*r[J][11][15,0]*t[((I,6),(J,15),)]
            tu += 1/2*g[dei(p[I,0],p[J,1],p[I,0],p[J,1])]*r[I][22][6,0]*r[J][41][15,0]*t[((I,6),(J,15),)]
            tu += 1/2*g[dei(p[I,1],p[J,1],p[I,1],p[J,1])]*r[I][52][6,0]*r[J][41][15,0]*t[((I,6),(J,15),)]
            
    for I in range(nc,np):
        if I in {}: continue
        for J in range(nc,np):
            if J in {I}: continue
            for K in range(nc,np):
                if K in {I,J}: continue
                # ({I}_{15}, {J}_{9}, {K}_{7})
                tu += -1/6*g[dei(p[I,0],p[J,0],p[I,0],p[K,0])]*r[I][11][15,0]*r[J][1][9,0]*r[K][3][7,0]*t[((I,15),(J,9),(K,7),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[I,1],p[K,0])]*r[I][41][15,0]*r[J][1][9,0]*r[K][3][7,0]*t[((I,15),(J,9),(K,7),)]
                # ({I}_{15}, {J}_{9}, {K}_{8})
                tu += -1/6*g[dei(p[I,0],p[J,0],p[I,0],p[K,1])]*r[I][11][15,0]*r[J][1][9,0]*r[K][7][8,0]*t[((I,15),(J,9),(K,8),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[I,1],p[K,1])]*r[I][41][15,0]*r[J][1][9,0]*r[K][7][8,0]*t[((I,15),(J,9),(K,8),)]
                # ({I}_{15}, {J}_{10}, {K}_{7})
                tu += -1/6*g[dei(p[I,0],p[J,1],p[I,0],p[K,0])]*r[I][11][15,0]*r[J][5][10,0]*r[K][3][7,0]*t[((I,15),(J,10),(K,7),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[I,1],p[K,0])]*r[I][41][15,0]*r[J][5][10,0]*r[K][3][7,0]*t[((I,15),(J,10),(K,7),)]
                # ({I}_{15}, {J}_{10}, {K}_{8})
                tu += -1/6*g[dei(p[I,0],p[J,1],p[I,0],p[K,1])]*r[I][11][15,0]*r[J][5][10,0]*r[K][7][8,0]*t[((I,15),(J,10),(K,8),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[I,1],p[K,1])]*r[I][41][15,0]*r[J][5][10,0]*r[K][7][8,0]*t[((I,15),(J,10),(K,8),)]
                # ({I}_{15}, {J}_{7}, {K}_{9})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[I,0],p[K,0])]*r[I][11][15,0]*r[J][3][7,0]*r[K][1][9,0]*t[((I,15),(J,7),(K,9),)]
                tu += 1/6*g[dei(p[I,1],p[J,0],p[I,1],p[K,0])]*r[I][41][15,0]*r[J][3][7,0]*r[K][1][9,0]*t[((I,15),(J,7),(K,9),)]
                # ({I}_{15}, {J}_{8}, {K}_{9})
                tu += 1/6*g[dei(p[I,0],p[J,1],p[I,0],p[K,0])]*r[I][11][15,0]*r[J][7][8,0]*r[K][1][9,0]*t[((I,15),(J,8),(K,9),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[I,1],p[K,0])]*r[I][41][15,0]*r[J][7][8,0]*r[K][1][9,0]*t[((I,15),(J,8),(K,9),)]
                # ({I}_{15}, {J}_{7}, {K}_{10})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[I,0],p[K,1])]*r[I][11][15,0]*r[J][3][7,0]*r[K][5][10,0]*t[((I,15),(J,7),(K,10),)]
                tu += 1/6*g[dei(p[I,1],p[J,0],p[I,1],p[K,1])]*r[I][41][15,0]*r[J][3][7,0]*r[K][5][10,0]*t[((I,15),(J,7),(K,10),)]
                # ({I}_{15}, {J}_{8}, {K}_{10})
                tu += 1/6*g[dei(p[I,0],p[J,1],p[I,0],p[K,1])]*r[I][11][15,0]*r[J][7][8,0]*r[K][5][10,0]*t[((I,15),(J,8),(K,10),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[I,1],p[K,1])]*r[I][41][15,0]*r[J][7][8,0]*r[K][5][10,0]*t[((I,15),(J,8),(K,10),)]
                # ({I}_{1}, {J}_{12}, {K}_{9})
                tu += 1/6*g[dei(p[I,0],p[I,0],p[J,0],p[K,0])]*r[I][9][1,0]*r[J][0][12,0]*r[K][1][9,0]*t[((I,1),(J,12),(K,9),)]
                tu += 1/6*g[dei(p[I,1],p[I,1],p[J,0],p[K,0])]*r[I][39][1,0]*r[J][0][12,0]*r[K][1][9,0]*t[((I,1),(J,12),(K,9),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[I,0],p[K,0])]*r[I][9][1,0]*r[J][0][12,0]*r[K][1][9,0]*t[((I,1),(J,12),(K,9),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[I,1],p[K,0])]*r[I][39][1,0]*r[J][0][12,0]*r[K][1][9,0]*t[((I,1),(J,12),(K,9),)]
                tu += 1/6*g[dei(p[I,0],p[I,0],p[J,0],p[K,0])]*r[I][24][1,0]*r[J][0][12,0]*r[K][1][9,0]*t[((I,1),(J,12),(K,9),)]
                tu += 1/6*g[dei(p[I,1],p[I,1],p[J,0],p[K,0])]*r[I][54][1,0]*r[J][0][12,0]*r[K][1][9,0]*t[((I,1),(J,12),(K,9),)]
                # ({I}_{1}, {J}_{14}, {K}_{7})
                tu += 1/6*g[dei(p[I,0],p[I,0],p[J,0],p[K,0])]*r[I][24][1,0]*r[J][2][14,0]*r[K][3][7,0]*t[((I,1),(J,14),(K,7),)]
                tu += 1/6*g[dei(p[I,0],p[I,0],p[J,0],p[K,0])]*r[I][9][1,0]*r[J][2][14,0]*r[K][3][7,0]*t[((I,1),(J,14),(K,7),)]
                tu += 1/6*g[dei(p[I,1],p[I,1],p[J,0],p[K,0])]*r[I][54][1,0]*r[J][2][14,0]*r[K][3][7,0]*t[((I,1),(J,14),(K,7),)]
                tu += 1/6*g[dei(p[I,1],p[I,1],p[J,0],p[K,0])]*r[I][39][1,0]*r[J][2][14,0]*r[K][3][7,0]*t[((I,1),(J,14),(K,7),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[I,0],p[K,0])]*r[I][24][1,0]*r[J][2][14,0]*r[K][3][7,0]*t[((I,1),(J,14),(K,7),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[I,1],p[K,0])]*r[I][54][1,0]*r[J][2][14,0]*r[K][3][7,0]*t[((I,1),(J,14),(K,7),)]
                # ({I}_{1}, {J}_{12}, {K}_{10})
                tu += 1/6*g[dei(p[I,0],p[I,0],p[J,0],p[K,1])]*r[I][9][1,0]*r[J][0][12,0]*r[K][5][10,0]*t[((I,1),(J,12),(K,10),)]
                tu += 1/6*g[dei(p[I,1],p[I,1],p[J,0],p[K,1])]*r[I][39][1,0]*r[J][0][12,0]*r[K][5][10,0]*t[((I,1),(J,12),(K,10),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[I,0],p[K,1])]*r[I][9][1,0]*r[J][0][12,0]*r[K][5][10,0]*t[((I,1),(J,12),(K,10),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[I,1],p[K,1])]*r[I][39][1,0]*r[J][0][12,0]*r[K][5][10,0]*t[((I,1),(J,12),(K,10),)]
                tu += 1/6*g[dei(p[I,0],p[I,0],p[J,0],p[K,1])]*r[I][24][1,0]*r[J][0][12,0]*r[K][5][10,0]*t[((I,1),(J,12),(K,10),)]
                tu += 1/6*g[dei(p[I,1],p[I,1],p[J,0],p[K,1])]*r[I][54][1,0]*r[J][0][12,0]*r[K][5][10,0]*t[((I,1),(J,12),(K,10),)]
                # ({I}_{1}, {J}_{14}, {K}_{8})
                tu += 1/6*g[dei(p[I,0],p[I,0],p[J,0],p[K,1])]*r[I][24][1,0]*r[J][2][14,0]*r[K][7][8,0]*t[((I,1),(J,14),(K,8),)]
                tu += 1/6*g[dei(p[I,0],p[I,0],p[J,0],p[K,1])]*r[I][9][1,0]*r[J][2][14,0]*r[K][7][8,0]*t[((I,1),(J,14),(K,8),)]
                tu += 1/6*g[dei(p[I,1],p[I,1],p[J,0],p[K,1])]*r[I][54][1,0]*r[J][2][14,0]*r[K][7][8,0]*t[((I,1),(J,14),(K,8),)]
                tu += 1/6*g[dei(p[I,1],p[I,1],p[J,0],p[K,1])]*r[I][39][1,0]*r[J][2][14,0]*r[K][7][8,0]*t[((I,1),(J,14),(K,8),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[I,0],p[K,1])]*r[I][24][1,0]*r[J][2][14,0]*r[K][7][8,0]*t[((I,1),(J,14),(K,8),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[I,1],p[K,1])]*r[I][54][1,0]*r[J][2][14,0]*r[K][7][8,0]*t[((I,1),(J,14),(K,8),)]
                # ({I}_{2}, {J}_{12}, {K}_{9})
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][15][2,0]*r[J][0][12,0]*r[K][1][9,0]*t[((I,2),(J,12),(K,9),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][33][2,0]*r[J][0][12,0]*r[K][1][9,0]*t[((I,2),(J,12),(K,9),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[I,1],p[J,0])]*r[I][15][2,0]*r[J][0][12,0]*r[K][1][9,0]*t[((I,2),(J,12),(K,9),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[I,1],p[K,0])]*r[I][33][2,0]*r[J][0][12,0]*r[K][1][9,0]*t[((I,2),(J,12),(K,9),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][30][2,0]*r[J][0][12,0]*r[K][1][9,0]*t[((I,2),(J,12),(K,9),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][48][2,0]*r[J][0][12,0]*r[K][1][9,0]*t[((I,2),(J,12),(K,9),)]
                # ({I}_{3}, {J}_{12}, {K}_{9})
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][15][3,0]*r[J][0][12,0]*r[K][1][9,0]*t[((I,3),(J,12),(K,9),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][33][3,0]*r[J][0][12,0]*r[K][1][9,0]*t[((I,3),(J,12),(K,9),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[I,1],p[J,0])]*r[I][15][3,0]*r[J][0][12,0]*r[K][1][9,0]*t[((I,3),(J,12),(K,9),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[I,1],p[K,0])]*r[I][33][3,0]*r[J][0][12,0]*r[K][1][9,0]*t[((I,3),(J,12),(K,9),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][30][3,0]*r[J][0][12,0]*r[K][1][9,0]*t[((I,3),(J,12),(K,9),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][48][3,0]*r[J][0][12,0]*r[K][1][9,0]*t[((I,3),(J,12),(K,9),)]
                # ({I}_{2}, {J}_{14}, {K}_{7})
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][30][2,0]*r[J][2][14,0]*r[K][3][7,0]*t[((I,2),(J,14),(K,7),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][15][2,0]*r[J][2][14,0]*r[K][3][7,0]*t[((I,2),(J,14),(K,7),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][48][2,0]*r[J][2][14,0]*r[K][3][7,0]*t[((I,2),(J,14),(K,7),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][33][2,0]*r[J][2][14,0]*r[K][3][7,0]*t[((I,2),(J,14),(K,7),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[I,1],p[J,0])]*r[I][30][2,0]*r[J][2][14,0]*r[K][3][7,0]*t[((I,2),(J,14),(K,7),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[I,1],p[K,0])]*r[I][48][2,0]*r[J][2][14,0]*r[K][3][7,0]*t[((I,2),(J,14),(K,7),)]
                # ({I}_{3}, {J}_{14}, {K}_{7})
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][30][3,0]*r[J][2][14,0]*r[K][3][7,0]*t[((I,3),(J,14),(K,7),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][15][3,0]*r[J][2][14,0]*r[K][3][7,0]*t[((I,3),(J,14),(K,7),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][48][3,0]*r[J][2][14,0]*r[K][3][7,0]*t[((I,3),(J,14),(K,7),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][33][3,0]*r[J][2][14,0]*r[K][3][7,0]*t[((I,3),(J,14),(K,7),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[I,1],p[J,0])]*r[I][30][3,0]*r[J][2][14,0]*r[K][3][7,0]*t[((I,3),(J,14),(K,7),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[I,1],p[K,0])]*r[I][48][3,0]*r[J][2][14,0]*r[K][3][7,0]*t[((I,3),(J,14),(K,7),)]
                # ({I}_{2}, {J}_{12}, {K}_{10})
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][15][2,0]*r[J][0][12,0]*r[K][5][10,0]*t[((I,2),(J,12),(K,10),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][33][2,0]*r[J][0][12,0]*r[K][5][10,0]*t[((I,2),(J,12),(K,10),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[I,1],p[J,0])]*r[I][15][2,0]*r[J][0][12,0]*r[K][5][10,0]*t[((I,2),(J,12),(K,10),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[I,1],p[K,1])]*r[I][33][2,0]*r[J][0][12,0]*r[K][5][10,0]*t[((I,2),(J,12),(K,10),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][30][2,0]*r[J][0][12,0]*r[K][5][10,0]*t[((I,2),(J,12),(K,10),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][48][2,0]*r[J][0][12,0]*r[K][5][10,0]*t[((I,2),(J,12),(K,10),)]
                # ({I}_{3}, {J}_{12}, {K}_{10})
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][15][3,0]*r[J][0][12,0]*r[K][5][10,0]*t[((I,3),(J,12),(K,10),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][33][3,0]*r[J][0][12,0]*r[K][5][10,0]*t[((I,3),(J,12),(K,10),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[I,1],p[J,0])]*r[I][15][3,0]*r[J][0][12,0]*r[K][5][10,0]*t[((I,3),(J,12),(K,10),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[I,1],p[K,1])]*r[I][33][3,0]*r[J][0][12,0]*r[K][5][10,0]*t[((I,3),(J,12),(K,10),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][30][3,0]*r[J][0][12,0]*r[K][5][10,0]*t[((I,3),(J,12),(K,10),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][48][3,0]*r[J][0][12,0]*r[K][5][10,0]*t[((I,3),(J,12),(K,10),)]
                # ({I}_{2}, {J}_{14}, {K}_{8})
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][30][2,0]*r[J][2][14,0]*r[K][7][8,0]*t[((I,2),(J,14),(K,8),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][15][2,0]*r[J][2][14,0]*r[K][7][8,0]*t[((I,2),(J,14),(K,8),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][48][2,0]*r[J][2][14,0]*r[K][7][8,0]*t[((I,2),(J,14),(K,8),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][33][2,0]*r[J][2][14,0]*r[K][7][8,0]*t[((I,2),(J,14),(K,8),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[I,1],p[J,0])]*r[I][30][2,0]*r[J][2][14,0]*r[K][7][8,0]*t[((I,2),(J,14),(K,8),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[I,1],p[K,1])]*r[I][48][2,0]*r[J][2][14,0]*r[K][7][8,0]*t[((I,2),(J,14),(K,8),)]
                # ({I}_{3}, {J}_{14}, {K}_{8})
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][30][3,0]*r[J][2][14,0]*r[K][7][8,0]*t[((I,3),(J,14),(K,8),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][15][3,0]*r[J][2][14,0]*r[K][7][8,0]*t[((I,3),(J,14),(K,8),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][48][3,0]*r[J][2][14,0]*r[K][7][8,0]*t[((I,3),(J,14),(K,8),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][33][3,0]*r[J][2][14,0]*r[K][7][8,0]*t[((I,3),(J,14),(K,8),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[I,1],p[J,0])]*r[I][30][3,0]*r[J][2][14,0]*r[K][7][8,0]*t[((I,3),(J,14),(K,8),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[I,1],p[K,1])]*r[I][48][3,0]*r[J][2][14,0]*r[K][7][8,0]*t[((I,3),(J,14),(K,8),)]
                # ({I}_{1}, {J}_{11}, {K}_{9})
                tu += 1/6*g[dei(p[I,0],p[I,0],p[J,1],p[K,0])]*r[I][9][1,0]*r[J][4][11,0]*r[K][1][9,0]*t[((I,1),(J,11),(K,9),)]
                tu += 1/6*g[dei(p[I,1],p[I,1],p[J,1],p[K,0])]*r[I][39][1,0]*r[J][4][11,0]*r[K][1][9,0]*t[((I,1),(J,11),(K,9),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[I,0],p[K,0])]*r[I][9][1,0]*r[J][4][11,0]*r[K][1][9,0]*t[((I,1),(J,11),(K,9),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[I,1],p[K,0])]*r[I][39][1,0]*r[J][4][11,0]*r[K][1][9,0]*t[((I,1),(J,11),(K,9),)]
                tu += 1/6*g[dei(p[I,0],p[I,0],p[J,1],p[K,0])]*r[I][24][1,0]*r[J][4][11,0]*r[K][1][9,0]*t[((I,1),(J,11),(K,9),)]
                tu += 1/6*g[dei(p[I,1],p[I,1],p[J,1],p[K,0])]*r[I][54][1,0]*r[J][4][11,0]*r[K][1][9,0]*t[((I,1),(J,11),(K,9),)]
                # ({I}_{1}, {J}_{13}, {K}_{7})
                tu += 1/6*g[dei(p[I,0],p[I,0],p[J,1],p[K,0])]*r[I][24][1,0]*r[J][6][13,0]*r[K][3][7,0]*t[((I,1),(J,13),(K,7),)]
                tu += 1/6*g[dei(p[I,0],p[I,0],p[J,1],p[K,0])]*r[I][9][1,0]*r[J][6][13,0]*r[K][3][7,0]*t[((I,1),(J,13),(K,7),)]
                tu += 1/6*g[dei(p[I,1],p[I,1],p[J,1],p[K,0])]*r[I][54][1,0]*r[J][6][13,0]*r[K][3][7,0]*t[((I,1),(J,13),(K,7),)]
                tu += 1/6*g[dei(p[I,1],p[I,1],p[J,1],p[K,0])]*r[I][39][1,0]*r[J][6][13,0]*r[K][3][7,0]*t[((I,1),(J,13),(K,7),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[I,0],p[K,0])]*r[I][24][1,0]*r[J][6][13,0]*r[K][3][7,0]*t[((I,1),(J,13),(K,7),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[I,1],p[K,0])]*r[I][54][1,0]*r[J][6][13,0]*r[K][3][7,0]*t[((I,1),(J,13),(K,7),)]
                # ({I}_{1}, {J}_{11}, {K}_{10})
                tu += 1/6*g[dei(p[I,0],p[I,0],p[J,1],p[K,1])]*r[I][9][1,0]*r[J][4][11,0]*r[K][5][10,0]*t[((I,1),(J,11),(K,10),)]
                tu += 1/6*g[dei(p[I,1],p[I,1],p[J,1],p[K,1])]*r[I][39][1,0]*r[J][4][11,0]*r[K][5][10,0]*t[((I,1),(J,11),(K,10),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[I,0],p[K,1])]*r[I][9][1,0]*r[J][4][11,0]*r[K][5][10,0]*t[((I,1),(J,11),(K,10),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[I,1],p[K,1])]*r[I][39][1,0]*r[J][4][11,0]*r[K][5][10,0]*t[((I,1),(J,11),(K,10),)]
                tu += 1/6*g[dei(p[I,0],p[I,0],p[J,1],p[K,1])]*r[I][24][1,0]*r[J][4][11,0]*r[K][5][10,0]*t[((I,1),(J,11),(K,10),)]
                tu += 1/6*g[dei(p[I,1],p[I,1],p[J,1],p[K,1])]*r[I][54][1,0]*r[J][4][11,0]*r[K][5][10,0]*t[((I,1),(J,11),(K,10),)]
                # ({I}_{1}, {J}_{13}, {K}_{8})
                tu += 1/6*g[dei(p[I,0],p[I,0],p[J,1],p[K,1])]*r[I][24][1,0]*r[J][6][13,0]*r[K][7][8,0]*t[((I,1),(J,13),(K,8),)]
                tu += 1/6*g[dei(p[I,0],p[I,0],p[J,1],p[K,1])]*r[I][9][1,0]*r[J][6][13,0]*r[K][7][8,0]*t[((I,1),(J,13),(K,8),)]
                tu += 1/6*g[dei(p[I,1],p[I,1],p[J,1],p[K,1])]*r[I][54][1,0]*r[J][6][13,0]*r[K][7][8,0]*t[((I,1),(J,13),(K,8),)]
                tu += 1/6*g[dei(p[I,1],p[I,1],p[J,1],p[K,1])]*r[I][39][1,0]*r[J][6][13,0]*r[K][7][8,0]*t[((I,1),(J,13),(K,8),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[I,0],p[K,1])]*r[I][24][1,0]*r[J][6][13,0]*r[K][7][8,0]*t[((I,1),(J,13),(K,8),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[I,1],p[K,1])]*r[I][54][1,0]*r[J][6][13,0]*r[K][7][8,0]*t[((I,1),(J,13),(K,8),)]
                # ({I}_{2}, {J}_{11}, {K}_{9})
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][15][2,0]*r[J][4][11,0]*r[K][1][9,0]*t[((I,2),(J,11),(K,9),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][33][2,0]*r[J][4][11,0]*r[K][1][9,0]*t[((I,2),(J,11),(K,9),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[I,1],p[J,1])]*r[I][15][2,0]*r[J][4][11,0]*r[K][1][9,0]*t[((I,2),(J,11),(K,9),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[I,1],p[K,0])]*r[I][33][2,0]*r[J][4][11,0]*r[K][1][9,0]*t[((I,2),(J,11),(K,9),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][30][2,0]*r[J][4][11,0]*r[K][1][9,0]*t[((I,2),(J,11),(K,9),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][48][2,0]*r[J][4][11,0]*r[K][1][9,0]*t[((I,2),(J,11),(K,9),)]
                # ({I}_{3}, {J}_{11}, {K}_{9})
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][15][3,0]*r[J][4][11,0]*r[K][1][9,0]*t[((I,3),(J,11),(K,9),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][33][3,0]*r[J][4][11,0]*r[K][1][9,0]*t[((I,3),(J,11),(K,9),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[I,1],p[J,1])]*r[I][15][3,0]*r[J][4][11,0]*r[K][1][9,0]*t[((I,3),(J,11),(K,9),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[I,1],p[K,0])]*r[I][33][3,0]*r[J][4][11,0]*r[K][1][9,0]*t[((I,3),(J,11),(K,9),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][30][3,0]*r[J][4][11,0]*r[K][1][9,0]*t[((I,3),(J,11),(K,9),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][48][3,0]*r[J][4][11,0]*r[K][1][9,0]*t[((I,3),(J,11),(K,9),)]
                # ({I}_{2}, {J}_{13}, {K}_{7})
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][30][2,0]*r[J][6][13,0]*r[K][3][7,0]*t[((I,2),(J,13),(K,7),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][15][2,0]*r[J][6][13,0]*r[K][3][7,0]*t[((I,2),(J,13),(K,7),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][48][2,0]*r[J][6][13,0]*r[K][3][7,0]*t[((I,2),(J,13),(K,7),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][33][2,0]*r[J][6][13,0]*r[K][3][7,0]*t[((I,2),(J,13),(K,7),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[I,1],p[J,1])]*r[I][30][2,0]*r[J][6][13,0]*r[K][3][7,0]*t[((I,2),(J,13),(K,7),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[I,1],p[K,0])]*r[I][48][2,0]*r[J][6][13,0]*r[K][3][7,0]*t[((I,2),(J,13),(K,7),)]
                # ({I}_{3}, {J}_{13}, {K}_{7})
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][30][3,0]*r[J][6][13,0]*r[K][3][7,0]*t[((I,3),(J,13),(K,7),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][15][3,0]*r[J][6][13,0]*r[K][3][7,0]*t[((I,3),(J,13),(K,7),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][48][3,0]*r[J][6][13,0]*r[K][3][7,0]*t[((I,3),(J,13),(K,7),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][33][3,0]*r[J][6][13,0]*r[K][3][7,0]*t[((I,3),(J,13),(K,7),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[I,1],p[J,1])]*r[I][30][3,0]*r[J][6][13,0]*r[K][3][7,0]*t[((I,3),(J,13),(K,7),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[I,1],p[K,0])]*r[I][48][3,0]*r[J][6][13,0]*r[K][3][7,0]*t[((I,3),(J,13),(K,7),)]
                # ({I}_{2}, {J}_{11}, {K}_{10})
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][15][2,0]*r[J][4][11,0]*r[K][5][10,0]*t[((I,2),(J,11),(K,10),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][33][2,0]*r[J][4][11,0]*r[K][5][10,0]*t[((I,2),(J,11),(K,10),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[I,1],p[J,1])]*r[I][15][2,0]*r[J][4][11,0]*r[K][5][10,0]*t[((I,2),(J,11),(K,10),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[I,1],p[K,1])]*r[I][33][2,0]*r[J][4][11,0]*r[K][5][10,0]*t[((I,2),(J,11),(K,10),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][30][2,0]*r[J][4][11,0]*r[K][5][10,0]*t[((I,2),(J,11),(K,10),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][48][2,0]*r[J][4][11,0]*r[K][5][10,0]*t[((I,2),(J,11),(K,10),)]
                # ({I}_{3}, {J}_{11}, {K}_{10})
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][15][3,0]*r[J][4][11,0]*r[K][5][10,0]*t[((I,3),(J,11),(K,10),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][33][3,0]*r[J][4][11,0]*r[K][5][10,0]*t[((I,3),(J,11),(K,10),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[I,1],p[J,1])]*r[I][15][3,0]*r[J][4][11,0]*r[K][5][10,0]*t[((I,3),(J,11),(K,10),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[I,1],p[K,1])]*r[I][33][3,0]*r[J][4][11,0]*r[K][5][10,0]*t[((I,3),(J,11),(K,10),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][30][3,0]*r[J][4][11,0]*r[K][5][10,0]*t[((I,3),(J,11),(K,10),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][48][3,0]*r[J][4][11,0]*r[K][5][10,0]*t[((I,3),(J,11),(K,10),)]
                # ({I}_{2}, {J}_{13}, {K}_{8})
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][30][2,0]*r[J][6][13,0]*r[K][7][8,0]*t[((I,2),(J,13),(K,8),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][15][2,0]*r[J][6][13,0]*r[K][7][8,0]*t[((I,2),(J,13),(K,8),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][48][2,0]*r[J][6][13,0]*r[K][7][8,0]*t[((I,2),(J,13),(K,8),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][33][2,0]*r[J][6][13,0]*r[K][7][8,0]*t[((I,2),(J,13),(K,8),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[I,1],p[J,1])]*r[I][30][2,0]*r[J][6][13,0]*r[K][7][8,0]*t[((I,2),(J,13),(K,8),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[I,1],p[K,1])]*r[I][48][2,0]*r[J][6][13,0]*r[K][7][8,0]*t[((I,2),(J,13),(K,8),)]
                # ({I}_{3}, {J}_{13}, {K}_{8})
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][30][3,0]*r[J][6][13,0]*r[K][7][8,0]*t[((I,3),(J,13),(K,8),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][15][3,0]*r[J][6][13,0]*r[K][7][8,0]*t[((I,3),(J,13),(K,8),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][48][3,0]*r[J][6][13,0]*r[K][7][8,0]*t[((I,3),(J,13),(K,8),)]
                tu += 1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][33][3,0]*r[J][6][13,0]*r[K][7][8,0]*t[((I,3),(J,13),(K,8),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[I,1],p[J,1])]*r[I][30][3,0]*r[J][6][13,0]*r[K][7][8,0]*t[((I,3),(J,13),(K,8),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[I,1],p[K,1])]*r[I][48][3,0]*r[J][6][13,0]*r[K][7][8,0]*t[((I,3),(J,13),(K,8),)]
                # ({I}_{12}, {J}_{1}, {K}_{9})
                tu += -1/6*g[dei(p[I,0],p[J,0],p[J,0],p[K,0])]*r[I][0][12,0]*r[J][9][1,0]*r[K][1][9,0]*t[((I,12),(J,1),(K,9),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[J,1],p[K,0])]*r[I][0][12,0]*r[J][39][1,0]*r[K][1][9,0]*t[((I,12),(J,1),(K,9),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,0])]*r[I][0][12,0]*r[J][9][1,0]*r[K][1][9,0]*t[((I,12),(J,1),(K,9),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,0])]*r[I][0][12,0]*r[J][24][1,0]*r[K][1][9,0]*t[((I,12),(J,1),(K,9),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,1],p[J,1])]*r[I][0][12,0]*r[J][39][1,0]*r[K][1][9,0]*t[((I,12),(J,1),(K,9),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,1],p[J,1])]*r[I][0][12,0]*r[J][54][1,0]*r[K][1][9,0]*t[((I,12),(J,1),(K,9),)]
                # ({I}_{14}, {J}_{1}, {K}_{7})
                tu += -1/6*g[dei(p[I,0],p[J,0],p[J,0],p[K,0])]*r[I][2][14,0]*r[J][24][1,0]*r[K][3][7,0]*t[((I,14),(J,1),(K,7),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[J,1],p[K,0])]*r[I][2][14,0]*r[J][54][1,0]*r[K][3][7,0]*t[((I,14),(J,1),(K,7),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,0])]*r[I][2][14,0]*r[J][24][1,0]*r[K][3][7,0]*t[((I,14),(J,1),(K,7),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,1],p[J,1])]*r[I][2][14,0]*r[J][54][1,0]*r[K][3][7,0]*t[((I,14),(J,1),(K,7),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,0])]*r[I][2][14,0]*r[J][9][1,0]*r[K][3][7,0]*t[((I,14),(J,1),(K,7),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,1],p[J,1])]*r[I][2][14,0]*r[J][39][1,0]*r[K][3][7,0]*t[((I,14),(J,1),(K,7),)]
                # ({I}_{12}, {J}_{1}, {K}_{10})
                tu += -1/6*g[dei(p[I,0],p[J,0],p[J,0],p[K,1])]*r[I][0][12,0]*r[J][9][1,0]*r[K][5][10,0]*t[((I,12),(J,1),(K,10),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[J,1],p[K,1])]*r[I][0][12,0]*r[J][39][1,0]*r[K][5][10,0]*t[((I,12),(J,1),(K,10),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,0])]*r[I][0][12,0]*r[J][9][1,0]*r[K][5][10,0]*t[((I,12),(J,1),(K,10),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,0])]*r[I][0][12,0]*r[J][24][1,0]*r[K][5][10,0]*t[((I,12),(J,1),(K,10),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,1],p[J,1])]*r[I][0][12,0]*r[J][39][1,0]*r[K][5][10,0]*t[((I,12),(J,1),(K,10),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,1],p[J,1])]*r[I][0][12,0]*r[J][54][1,0]*r[K][5][10,0]*t[((I,12),(J,1),(K,10),)]
                # ({I}_{14}, {J}_{1}, {K}_{8})
                tu += -1/6*g[dei(p[I,0],p[J,0],p[J,0],p[K,1])]*r[I][2][14,0]*r[J][24][1,0]*r[K][7][8,0]*t[((I,14),(J,1),(K,8),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[J,1],p[K,1])]*r[I][2][14,0]*r[J][54][1,0]*r[K][7][8,0]*t[((I,14),(J,1),(K,8),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,0])]*r[I][2][14,0]*r[J][24][1,0]*r[K][7][8,0]*t[((I,14),(J,1),(K,8),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,1],p[J,1])]*r[I][2][14,0]*r[J][54][1,0]*r[K][7][8,0]*t[((I,14),(J,1),(K,8),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,0])]*r[I][2][14,0]*r[J][9][1,0]*r[K][7][8,0]*t[((I,14),(J,1),(K,8),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,1],p[J,1])]*r[I][2][14,0]*r[J][39][1,0]*r[K][7][8,0]*t[((I,14),(J,1),(K,8),)]
                # ({I}_{12}, {J}_{2}, {K}_{9})
                tu += -1/6*g[dei(p[I,0],p[J,1],p[J,0],p[K,0])]*r[I][0][12,0]*r[J][15][2,0]*r[K][1][9,0]*t[((I,12),(J,2),(K,9),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[J,1],p[K,0])]*r[I][0][12,0]*r[J][33][2,0]*r[K][1][9,0]*t[((I,12),(J,2),(K,9),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][0][12,0]*r[J][15][2,0]*r[K][1][9,0]*t[((I,12),(J,2),(K,9),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][0][12,0]*r[J][30][2,0]*r[K][1][9,0]*t[((I,12),(J,2),(K,9),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][0][12,0]*r[J][33][2,0]*r[K][1][9,0]*t[((I,12),(J,2),(K,9),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][0][12,0]*r[J][48][2,0]*r[K][1][9,0]*t[((I,12),(J,2),(K,9),)]
                # ({I}_{12}, {J}_{3}, {K}_{9})
                tu += -1/6*g[dei(p[I,0],p[J,1],p[J,0],p[K,0])]*r[I][0][12,0]*r[J][15][3,0]*r[K][1][9,0]*t[((I,12),(J,3),(K,9),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[J,1],p[K,0])]*r[I][0][12,0]*r[J][33][3,0]*r[K][1][9,0]*t[((I,12),(J,3),(K,9),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][0][12,0]*r[J][15][3,0]*r[K][1][9,0]*t[((I,12),(J,3),(K,9),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][0][12,0]*r[J][30][3,0]*r[K][1][9,0]*t[((I,12),(J,3),(K,9),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][0][12,0]*r[J][33][3,0]*r[K][1][9,0]*t[((I,12),(J,3),(K,9),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][0][12,0]*r[J][48][3,0]*r[K][1][9,0]*t[((I,12),(J,3),(K,9),)]
                # ({I}_{14}, {J}_{2}, {K}_{7})
                tu += -1/6*g[dei(p[I,0],p[J,1],p[J,0],p[K,0])]*r[I][2][14,0]*r[J][30][2,0]*r[K][3][7,0]*t[((I,14),(J,2),(K,7),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[J,1],p[K,0])]*r[I][2][14,0]*r[J][48][2,0]*r[K][3][7,0]*t[((I,14),(J,2),(K,7),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][2][14,0]*r[J][30][2,0]*r[K][3][7,0]*t[((I,14),(J,2),(K,7),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][2][14,0]*r[J][48][2,0]*r[K][3][7,0]*t[((I,14),(J,2),(K,7),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][2][14,0]*r[J][15][2,0]*r[K][3][7,0]*t[((I,14),(J,2),(K,7),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][2][14,0]*r[J][33][2,0]*r[K][3][7,0]*t[((I,14),(J,2),(K,7),)]
                # ({I}_{14}, {J}_{3}, {K}_{7})
                tu += -1/6*g[dei(p[I,0],p[J,1],p[J,0],p[K,0])]*r[I][2][14,0]*r[J][30][3,0]*r[K][3][7,0]*t[((I,14),(J,3),(K,7),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[J,1],p[K,0])]*r[I][2][14,0]*r[J][48][3,0]*r[K][3][7,0]*t[((I,14),(J,3),(K,7),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][2][14,0]*r[J][30][3,0]*r[K][3][7,0]*t[((I,14),(J,3),(K,7),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][2][14,0]*r[J][48][3,0]*r[K][3][7,0]*t[((I,14),(J,3),(K,7),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][2][14,0]*r[J][15][3,0]*r[K][3][7,0]*t[((I,14),(J,3),(K,7),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][2][14,0]*r[J][33][3,0]*r[K][3][7,0]*t[((I,14),(J,3),(K,7),)]
                # ({I}_{12}, {J}_{5}, {K}_{7})
                tu += -1/6*g[dei(p[I,0],p[J,1],p[J,0],p[K,0])]*r[I][0][12,0]*r[J][27][5,0]*r[K][3][7,0]*t[((I,12),(J,5),(K,7),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[J,1],p[K,0])]*r[I][0][12,0]*r[J][45][5,0]*r[K][3][7,0]*t[((I,12),(J,5),(K,7),)]
                # ({I}_{12}, {J}_{2}, {K}_{10})
                tu += -1/6*g[dei(p[I,0],p[J,1],p[J,0],p[K,1])]*r[I][0][12,0]*r[J][15][2,0]*r[K][5][10,0]*t[((I,12),(J,2),(K,10),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[J,1],p[K,1])]*r[I][0][12,0]*r[J][33][2,0]*r[K][5][10,0]*t[((I,12),(J,2),(K,10),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][0][12,0]*r[J][15][2,0]*r[K][5][10,0]*t[((I,12),(J,2),(K,10),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][0][12,0]*r[J][30][2,0]*r[K][5][10,0]*t[((I,12),(J,2),(K,10),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][0][12,0]*r[J][33][2,0]*r[K][5][10,0]*t[((I,12),(J,2),(K,10),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][0][12,0]*r[J][48][2,0]*r[K][5][10,0]*t[((I,12),(J,2),(K,10),)]
                # ({I}_{12}, {J}_{3}, {K}_{10})
                tu += -1/6*g[dei(p[I,0],p[J,1],p[J,0],p[K,1])]*r[I][0][12,0]*r[J][15][3,0]*r[K][5][10,0]*t[((I,12),(J,3),(K,10),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[J,1],p[K,1])]*r[I][0][12,0]*r[J][33][3,0]*r[K][5][10,0]*t[((I,12),(J,3),(K,10),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][0][12,0]*r[J][15][3,0]*r[K][5][10,0]*t[((I,12),(J,3),(K,10),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][0][12,0]*r[J][30][3,0]*r[K][5][10,0]*t[((I,12),(J,3),(K,10),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][0][12,0]*r[J][33][3,0]*r[K][5][10,0]*t[((I,12),(J,3),(K,10),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][0][12,0]*r[J][48][3,0]*r[K][5][10,0]*t[((I,12),(J,3),(K,10),)]
                # ({I}_{14}, {J}_{2}, {K}_{8})
                tu += -1/6*g[dei(p[I,0],p[J,1],p[J,0],p[K,1])]*r[I][2][14,0]*r[J][30][2,0]*r[K][7][8,0]*t[((I,14),(J,2),(K,8),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[J,1],p[K,1])]*r[I][2][14,0]*r[J][48][2,0]*r[K][7][8,0]*t[((I,14),(J,2),(K,8),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][2][14,0]*r[J][30][2,0]*r[K][7][8,0]*t[((I,14),(J,2),(K,8),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][2][14,0]*r[J][48][2,0]*r[K][7][8,0]*t[((I,14),(J,2),(K,8),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][2][14,0]*r[J][15][2,0]*r[K][7][8,0]*t[((I,14),(J,2),(K,8),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][2][14,0]*r[J][33][2,0]*r[K][7][8,0]*t[((I,14),(J,2),(K,8),)]
                # ({I}_{14}, {J}_{3}, {K}_{8})
                tu += -1/6*g[dei(p[I,0],p[J,1],p[J,0],p[K,1])]*r[I][2][14,0]*r[J][30][3,0]*r[K][7][8,0]*t[((I,14),(J,3),(K,8),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[J,1],p[K,1])]*r[I][2][14,0]*r[J][48][3,0]*r[K][7][8,0]*t[((I,14),(J,3),(K,8),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][2][14,0]*r[J][30][3,0]*r[K][7][8,0]*t[((I,14),(J,3),(K,8),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][2][14,0]*r[J][48][3,0]*r[K][7][8,0]*t[((I,14),(J,3),(K,8),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][2][14,0]*r[J][15][3,0]*r[K][7][8,0]*t[((I,14),(J,3),(K,8),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][2][14,0]*r[J][33][3,0]*r[K][7][8,0]*t[((I,14),(J,3),(K,8),)]
                # ({I}_{12}, {J}_{5}, {K}_{8})
                tu += -1/6*g[dei(p[I,0],p[J,1],p[J,0],p[K,1])]*r[I][0][12,0]*r[J][27][5,0]*r[K][7][8,0]*t[((I,12),(J,5),(K,8),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[J,1],p[K,1])]*r[I][0][12,0]*r[J][45][5,0]*r[K][7][8,0]*t[((I,12),(J,5),(K,8),)]
                # ({I}_{11}, {J}_{1}, {K}_{9})
                tu += -1/6*g[dei(p[I,1],p[J,0],p[J,0],p[K,0])]*r[I][4][11,0]*r[J][9][1,0]*r[K][1][9,0]*t[((I,11),(J,1),(K,9),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[J,1],p[K,0])]*r[I][4][11,0]*r[J][39][1,0]*r[K][1][9,0]*t[((I,11),(J,1),(K,9),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,0])]*r[I][4][11,0]*r[J][9][1,0]*r[K][1][9,0]*t[((I,11),(J,1),(K,9),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,0])]*r[I][4][11,0]*r[J][24][1,0]*r[K][1][9,0]*t[((I,11),(J,1),(K,9),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,1],p[J,1])]*r[I][4][11,0]*r[J][39][1,0]*r[K][1][9,0]*t[((I,11),(J,1),(K,9),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,1],p[J,1])]*r[I][4][11,0]*r[J][54][1,0]*r[K][1][9,0]*t[((I,11),(J,1),(K,9),)]
                # ({I}_{13}, {J}_{1}, {K}_{7})
                tu += -1/6*g[dei(p[I,1],p[J,0],p[J,0],p[K,0])]*r[I][6][13,0]*r[J][24][1,0]*r[K][3][7,0]*t[((I,13),(J,1),(K,7),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[J,1],p[K,0])]*r[I][6][13,0]*r[J][54][1,0]*r[K][3][7,0]*t[((I,13),(J,1),(K,7),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,0])]*r[I][6][13,0]*r[J][24][1,0]*r[K][3][7,0]*t[((I,13),(J,1),(K,7),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,1],p[J,1])]*r[I][6][13,0]*r[J][54][1,0]*r[K][3][7,0]*t[((I,13),(J,1),(K,7),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,0])]*r[I][6][13,0]*r[J][9][1,0]*r[K][3][7,0]*t[((I,13),(J,1),(K,7),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,1],p[J,1])]*r[I][6][13,0]*r[J][39][1,0]*r[K][3][7,0]*t[((I,13),(J,1),(K,7),)]
                # ({I}_{11}, {J}_{1}, {K}_{10})
                tu += -1/6*g[dei(p[I,1],p[J,0],p[J,0],p[K,1])]*r[I][4][11,0]*r[J][9][1,0]*r[K][5][10,0]*t[((I,11),(J,1),(K,10),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[J,1],p[K,1])]*r[I][4][11,0]*r[J][39][1,0]*r[K][5][10,0]*t[((I,11),(J,1),(K,10),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,0])]*r[I][4][11,0]*r[J][9][1,0]*r[K][5][10,0]*t[((I,11),(J,1),(K,10),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,0])]*r[I][4][11,0]*r[J][24][1,0]*r[K][5][10,0]*t[((I,11),(J,1),(K,10),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,1],p[J,1])]*r[I][4][11,0]*r[J][39][1,0]*r[K][5][10,0]*t[((I,11),(J,1),(K,10),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,1],p[J,1])]*r[I][4][11,0]*r[J][54][1,0]*r[K][5][10,0]*t[((I,11),(J,1),(K,10),)]
                # ({I}_{13}, {J}_{1}, {K}_{8})
                tu += -1/6*g[dei(p[I,1],p[J,0],p[J,0],p[K,1])]*r[I][6][13,0]*r[J][24][1,0]*r[K][7][8,0]*t[((I,13),(J,1),(K,8),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[J,1],p[K,1])]*r[I][6][13,0]*r[J][54][1,0]*r[K][7][8,0]*t[((I,13),(J,1),(K,8),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,0])]*r[I][6][13,0]*r[J][24][1,0]*r[K][7][8,0]*t[((I,13),(J,1),(K,8),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,1],p[J,1])]*r[I][6][13,0]*r[J][54][1,0]*r[K][7][8,0]*t[((I,13),(J,1),(K,8),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,0])]*r[I][6][13,0]*r[J][9][1,0]*r[K][7][8,0]*t[((I,13),(J,1),(K,8),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,1],p[J,1])]*r[I][6][13,0]*r[J][39][1,0]*r[K][7][8,0]*t[((I,13),(J,1),(K,8),)]
                # ({I}_{11}, {J}_{2}, {K}_{9})
                tu += -1/6*g[dei(p[I,1],p[J,1],p[J,0],p[K,0])]*r[I][4][11,0]*r[J][15][2,0]*r[K][1][9,0]*t[((I,11),(J,2),(K,9),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[J,1],p[K,0])]*r[I][4][11,0]*r[J][33][2,0]*r[K][1][9,0]*t[((I,11),(J,2),(K,9),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][4][11,0]*r[J][15][2,0]*r[K][1][9,0]*t[((I,11),(J,2),(K,9),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][4][11,0]*r[J][30][2,0]*r[K][1][9,0]*t[((I,11),(J,2),(K,9),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][4][11,0]*r[J][33][2,0]*r[K][1][9,0]*t[((I,11),(J,2),(K,9),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][4][11,0]*r[J][48][2,0]*r[K][1][9,0]*t[((I,11),(J,2),(K,9),)]
                # ({I}_{11}, {J}_{3}, {K}_{9})
                tu += -1/6*g[dei(p[I,1],p[J,1],p[J,0],p[K,0])]*r[I][4][11,0]*r[J][15][3,0]*r[K][1][9,0]*t[((I,11),(J,3),(K,9),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[J,1],p[K,0])]*r[I][4][11,0]*r[J][33][3,0]*r[K][1][9,0]*t[((I,11),(J,3),(K,9),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][4][11,0]*r[J][15][3,0]*r[K][1][9,0]*t[((I,11),(J,3),(K,9),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][4][11,0]*r[J][30][3,0]*r[K][1][9,0]*t[((I,11),(J,3),(K,9),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][4][11,0]*r[J][33][3,0]*r[K][1][9,0]*t[((I,11),(J,3),(K,9),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][4][11,0]*r[J][48][3,0]*r[K][1][9,0]*t[((I,11),(J,3),(K,9),)]
                # ({I}_{13}, {J}_{2}, {K}_{7})
                tu += -1/6*g[dei(p[I,1],p[J,1],p[J,0],p[K,0])]*r[I][6][13,0]*r[J][30][2,0]*r[K][3][7,0]*t[((I,13),(J,2),(K,7),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[J,1],p[K,0])]*r[I][6][13,0]*r[J][48][2,0]*r[K][3][7,0]*t[((I,13),(J,2),(K,7),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][6][13,0]*r[J][30][2,0]*r[K][3][7,0]*t[((I,13),(J,2),(K,7),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][6][13,0]*r[J][48][2,0]*r[K][3][7,0]*t[((I,13),(J,2),(K,7),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][6][13,0]*r[J][15][2,0]*r[K][3][7,0]*t[((I,13),(J,2),(K,7),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][6][13,0]*r[J][33][2,0]*r[K][3][7,0]*t[((I,13),(J,2),(K,7),)]
                # ({I}_{13}, {J}_{3}, {K}_{7})
                tu += -1/6*g[dei(p[I,1],p[J,1],p[J,0],p[K,0])]*r[I][6][13,0]*r[J][30][3,0]*r[K][3][7,0]*t[((I,13),(J,3),(K,7),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[J,1],p[K,0])]*r[I][6][13,0]*r[J][48][3,0]*r[K][3][7,0]*t[((I,13),(J,3),(K,7),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][6][13,0]*r[J][30][3,0]*r[K][3][7,0]*t[((I,13),(J,3),(K,7),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][6][13,0]*r[J][48][3,0]*r[K][3][7,0]*t[((I,13),(J,3),(K,7),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][6][13,0]*r[J][15][3,0]*r[K][3][7,0]*t[((I,13),(J,3),(K,7),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][6][13,0]*r[J][33][3,0]*r[K][3][7,0]*t[((I,13),(J,3),(K,7),)]
                # ({I}_{11}, {J}_{5}, {K}_{7})
                tu += -1/6*g[dei(p[I,1],p[J,1],p[J,0],p[K,0])]*r[I][4][11,0]*r[J][27][5,0]*r[K][3][7,0]*t[((I,11),(J,5),(K,7),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[J,1],p[K,0])]*r[I][4][11,0]*r[J][45][5,0]*r[K][3][7,0]*t[((I,11),(J,5),(K,7),)]
                # ({I}_{11}, {J}_{2}, {K}_{10})
                tu += -1/6*g[dei(p[I,1],p[J,1],p[J,0],p[K,1])]*r[I][4][11,0]*r[J][15][2,0]*r[K][5][10,0]*t[((I,11),(J,2),(K,10),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[J,1],p[K,1])]*r[I][4][11,0]*r[J][33][2,0]*r[K][5][10,0]*t[((I,11),(J,2),(K,10),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][4][11,0]*r[J][15][2,0]*r[K][5][10,0]*t[((I,11),(J,2),(K,10),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][4][11,0]*r[J][30][2,0]*r[K][5][10,0]*t[((I,11),(J,2),(K,10),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][4][11,0]*r[J][33][2,0]*r[K][5][10,0]*t[((I,11),(J,2),(K,10),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][4][11,0]*r[J][48][2,0]*r[K][5][10,0]*t[((I,11),(J,2),(K,10),)]
                # ({I}_{11}, {J}_{3}, {K}_{10})
                tu += -1/6*g[dei(p[I,1],p[J,1],p[J,0],p[K,1])]*r[I][4][11,0]*r[J][15][3,0]*r[K][5][10,0]*t[((I,11),(J,3),(K,10),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[J,1],p[K,1])]*r[I][4][11,0]*r[J][33][3,0]*r[K][5][10,0]*t[((I,11),(J,3),(K,10),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][4][11,0]*r[J][15][3,0]*r[K][5][10,0]*t[((I,11),(J,3),(K,10),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][4][11,0]*r[J][30][3,0]*r[K][5][10,0]*t[((I,11),(J,3),(K,10),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][4][11,0]*r[J][33][3,0]*r[K][5][10,0]*t[((I,11),(J,3),(K,10),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][4][11,0]*r[J][48][3,0]*r[K][5][10,0]*t[((I,11),(J,3),(K,10),)]
                # ({I}_{13}, {J}_{2}, {K}_{8})
                tu += -1/6*g[dei(p[I,1],p[J,1],p[J,0],p[K,1])]*r[I][6][13,0]*r[J][30][2,0]*r[K][7][8,0]*t[((I,13),(J,2),(K,8),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[J,1],p[K,1])]*r[I][6][13,0]*r[J][48][2,0]*r[K][7][8,0]*t[((I,13),(J,2),(K,8),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][6][13,0]*r[J][30][2,0]*r[K][7][8,0]*t[((I,13),(J,2),(K,8),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][6][13,0]*r[J][48][2,0]*r[K][7][8,0]*t[((I,13),(J,2),(K,8),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][6][13,0]*r[J][15][2,0]*r[K][7][8,0]*t[((I,13),(J,2),(K,8),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][6][13,0]*r[J][33][2,0]*r[K][7][8,0]*t[((I,13),(J,2),(K,8),)]
                # ({I}_{13}, {J}_{3}, {K}_{8})
                tu += -1/6*g[dei(p[I,1],p[J,1],p[J,0],p[K,1])]*r[I][6][13,0]*r[J][30][3,0]*r[K][7][8,0]*t[((I,13),(J,3),(K,8),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[J,1],p[K,1])]*r[I][6][13,0]*r[J][48][3,0]*r[K][7][8,0]*t[((I,13),(J,3),(K,8),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][6][13,0]*r[J][30][3,0]*r[K][7][8,0]*t[((I,13),(J,3),(K,8),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][6][13,0]*r[J][48][3,0]*r[K][7][8,0]*t[((I,13),(J,3),(K,8),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][6][13,0]*r[J][15][3,0]*r[K][7][8,0]*t[((I,13),(J,3),(K,8),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][6][13,0]*r[J][33][3,0]*r[K][7][8,0]*t[((I,13),(J,3),(K,8),)]
                # ({I}_{11}, {J}_{5}, {K}_{8})
                tu += -1/6*g[dei(p[I,1],p[J,1],p[J,0],p[K,1])]*r[I][4][11,0]*r[J][27][5,0]*r[K][7][8,0]*t[((I,11),(J,5),(K,8),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[J,1],p[K,1])]*r[I][4][11,0]*r[J][45][5,0]*r[K][7][8,0]*t[((I,11),(J,5),(K,8),)]
                # ({I}_{4}, {J}_{14}, {K}_{9})
                tu += -1/6*g[dei(p[I,0],p[K,0],p[I,1],p[J,0])]*r[I][18][4,0]*r[J][2][14,0]*r[K][1][9,0]*t[((I,4),(J,14),(K,9),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[I,1],p[K,0])]*r[I][36][4,0]*r[J][2][14,0]*r[K][1][9,0]*t[((I,4),(J,14),(K,9),)]
                # ({I}_{4}, {J}_{14}, {K}_{10})
                tu += -1/6*g[dei(p[I,0],p[K,1],p[I,1],p[J,0])]*r[I][18][4,0]*r[J][2][14,0]*r[K][5][10,0]*t[((I,4),(J,14),(K,10),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[I,1],p[K,1])]*r[I][36][4,0]*r[J][2][14,0]*r[K][5][10,0]*t[((I,4),(J,14),(K,10),)]
                # ({I}_{4}, {J}_{13}, {K}_{9})
                tu += -1/6*g[dei(p[I,0],p[K,0],p[I,1],p[J,1])]*r[I][18][4,0]*r[J][6][13,0]*r[K][1][9,0]*t[((I,4),(J,13),(K,9),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[I,1],p[K,0])]*r[I][36][4,0]*r[J][6][13,0]*r[K][1][9,0]*t[((I,4),(J,13),(K,9),)]
                # ({I}_{4}, {J}_{13}, {K}_{10})
                tu += -1/6*g[dei(p[I,0],p[K,1],p[I,1],p[J,1])]*r[I][18][4,0]*r[J][6][13,0]*r[K][5][10,0]*t[((I,4),(J,13),(K,10),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[I,1],p[K,1])]*r[I][36][4,0]*r[J][6][13,0]*r[K][5][10,0]*t[((I,4),(J,13),(K,10),)]
                # ({I}_{12}, {J}_{14}, {K}_{6})
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[K,0])]*r[I][0][12,0]*r[J][2][14,0]*r[K][22][6,0]*t[((I,12),(J,14),(K,6),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[K,1])]*r[I][0][12,0]*r[J][2][14,0]*r[K][52][6,0]*t[((I,12),(J,14),(K,6),)]
                # ({I}_{12}, {J}_{13}, {K}_{6})
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,1],p[K,0])]*r[I][0][12,0]*r[J][6][13,0]*r[K][22][6,0]*t[((I,12),(J,13),(K,6),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,1],p[K,1])]*r[I][0][12,0]*r[J][6][13,0]*r[K][52][6,0]*t[((I,12),(J,13),(K,6),)]
                # ({I}_{11}, {J}_{14}, {K}_{6})
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[K,0])]*r[I][4][11,0]*r[J][2][14,0]*r[K][22][6,0]*t[((I,11),(J,14),(K,6),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[K,1])]*r[I][4][11,0]*r[J][2][14,0]*r[K][52][6,0]*t[((I,11),(J,14),(K,6),)]
                # ({I}_{11}, {J}_{13}, {K}_{6})
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,1],p[K,0])]*r[I][4][11,0]*r[J][6][13,0]*r[K][22][6,0]*t[((I,11),(J,13),(K,6),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,1],p[K,1])]*r[I][4][11,0]*r[J][6][13,0]*r[K][52][6,0]*t[((I,11),(J,13),(K,6),)]
                # ({I}_{1}, {J}_{9}, {K}_{12})
                tu += -1/6*g[dei(p[I,0],p[I,0],p[J,0],p[K,0])]*r[I][9][1,0]*r[J][1][9,0]*r[K][0][12,0]*t[((I,1),(J,9),(K,12),)]
                tu += -1/6*g[dei(p[I,1],p[I,1],p[J,0],p[K,0])]*r[I][39][1,0]*r[J][1][9,0]*r[K][0][12,0]*t[((I,1),(J,9),(K,12),)]
                tu += 1/6*g[dei(p[I,0],p[J,0],p[I,0],p[K,0])]*r[I][9][1,0]*r[J][1][9,0]*r[K][0][12,0]*t[((I,1),(J,9),(K,12),)]
                tu += 1/6*g[dei(p[I,1],p[J,0],p[I,1],p[K,0])]*r[I][39][1,0]*r[J][1][9,0]*r[K][0][12,0]*t[((I,1),(J,9),(K,12),)]
                tu += -1/6*g[dei(p[I,0],p[I,0],p[J,0],p[K,0])]*r[I][24][1,0]*r[J][1][9,0]*r[K][0][12,0]*t[((I,1),(J,9),(K,12),)]
                tu += -1/6*g[dei(p[I,1],p[I,1],p[J,0],p[K,0])]*r[I][54][1,0]*r[J][1][9,0]*r[K][0][12,0]*t[((I,1),(J,9),(K,12),)]
                # ({I}_{1}, {J}_{7}, {K}_{14})
                tu += -1/6*g[dei(p[I,0],p[I,0],p[J,0],p[K,0])]*r[I][24][1,0]*r[J][3][7,0]*r[K][2][14,0]*t[((I,1),(J,7),(K,14),)]
                tu += -1/6*g[dei(p[I,0],p[I,0],p[J,0],p[K,0])]*r[I][9][1,0]*r[J][3][7,0]*r[K][2][14,0]*t[((I,1),(J,7),(K,14),)]
                tu += -1/6*g[dei(p[I,1],p[I,1],p[J,0],p[K,0])]*r[I][54][1,0]*r[J][3][7,0]*r[K][2][14,0]*t[((I,1),(J,7),(K,14),)]
                tu += -1/6*g[dei(p[I,1],p[I,1],p[J,0],p[K,0])]*r[I][39][1,0]*r[J][3][7,0]*r[K][2][14,0]*t[((I,1),(J,7),(K,14),)]
                tu += 1/6*g[dei(p[I,0],p[J,0],p[I,0],p[K,0])]*r[I][24][1,0]*r[J][3][7,0]*r[K][2][14,0]*t[((I,1),(J,7),(K,14),)]
                tu += 1/6*g[dei(p[I,1],p[J,0],p[I,1],p[K,0])]*r[I][54][1,0]*r[J][3][7,0]*r[K][2][14,0]*t[((I,1),(J,7),(K,14),)]
                # ({I}_{1}, {J}_{10}, {K}_{12})
                tu += -1/6*g[dei(p[I,0],p[I,0],p[J,1],p[K,0])]*r[I][9][1,0]*r[J][5][10,0]*r[K][0][12,0]*t[((I,1),(J,10),(K,12),)]
                tu += -1/6*g[dei(p[I,1],p[I,1],p[J,1],p[K,0])]*r[I][39][1,0]*r[J][5][10,0]*r[K][0][12,0]*t[((I,1),(J,10),(K,12),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[I,0],p[K,0])]*r[I][9][1,0]*r[J][5][10,0]*r[K][0][12,0]*t[((I,1),(J,10),(K,12),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[I,1],p[K,0])]*r[I][39][1,0]*r[J][5][10,0]*r[K][0][12,0]*t[((I,1),(J,10),(K,12),)]
                tu += -1/6*g[dei(p[I,0],p[I,0],p[J,1],p[K,0])]*r[I][24][1,0]*r[J][5][10,0]*r[K][0][12,0]*t[((I,1),(J,10),(K,12),)]
                tu += -1/6*g[dei(p[I,1],p[I,1],p[J,1],p[K,0])]*r[I][54][1,0]*r[J][5][10,0]*r[K][0][12,0]*t[((I,1),(J,10),(K,12),)]
                # ({I}_{1}, {J}_{8}, {K}_{14})
                tu += -1/6*g[dei(p[I,0],p[I,0],p[J,1],p[K,0])]*r[I][24][1,0]*r[J][7][8,0]*r[K][2][14,0]*t[((I,1),(J,8),(K,14),)]
                tu += -1/6*g[dei(p[I,0],p[I,0],p[J,1],p[K,0])]*r[I][9][1,0]*r[J][7][8,0]*r[K][2][14,0]*t[((I,1),(J,8),(K,14),)]
                tu += -1/6*g[dei(p[I,1],p[I,1],p[J,1],p[K,0])]*r[I][54][1,0]*r[J][7][8,0]*r[K][2][14,0]*t[((I,1),(J,8),(K,14),)]
                tu += -1/6*g[dei(p[I,1],p[I,1],p[J,1],p[K,0])]*r[I][39][1,0]*r[J][7][8,0]*r[K][2][14,0]*t[((I,1),(J,8),(K,14),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[I,0],p[K,0])]*r[I][24][1,0]*r[J][7][8,0]*r[K][2][14,0]*t[((I,1),(J,8),(K,14),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[I,1],p[K,0])]*r[I][54][1,0]*r[J][7][8,0]*r[K][2][14,0]*t[((I,1),(J,8),(K,14),)]
                # ({I}_{2}, {J}_{9}, {K}_{12})
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][15][2,0]*r[J][1][9,0]*r[K][0][12,0]*t[((I,2),(J,9),(K,12),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][33][2,0]*r[J][1][9,0]*r[K][0][12,0]*t[((I,2),(J,9),(K,12),)]
                tu += 1/6*g[dei(p[I,0],p[J,0],p[I,1],p[K,0])]*r[I][15][2,0]*r[J][1][9,0]*r[K][0][12,0]*t[((I,2),(J,9),(K,12),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[I,1],p[J,0])]*r[I][33][2,0]*r[J][1][9,0]*r[K][0][12,0]*t[((I,2),(J,9),(K,12),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][30][2,0]*r[J][1][9,0]*r[K][0][12,0]*t[((I,2),(J,9),(K,12),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][48][2,0]*r[J][1][9,0]*r[K][0][12,0]*t[((I,2),(J,9),(K,12),)]
                # ({I}_{3}, {J}_{9}, {K}_{12})
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][15][3,0]*r[J][1][9,0]*r[K][0][12,0]*t[((I,3),(J,9),(K,12),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][33][3,0]*r[J][1][9,0]*r[K][0][12,0]*t[((I,3),(J,9),(K,12),)]
                tu += 1/6*g[dei(p[I,0],p[J,0],p[I,1],p[K,0])]*r[I][15][3,0]*r[J][1][9,0]*r[K][0][12,0]*t[((I,3),(J,9),(K,12),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[I,1],p[J,0])]*r[I][33][3,0]*r[J][1][9,0]*r[K][0][12,0]*t[((I,3),(J,9),(K,12),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][30][3,0]*r[J][1][9,0]*r[K][0][12,0]*t[((I,3),(J,9),(K,12),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][48][3,0]*r[J][1][9,0]*r[K][0][12,0]*t[((I,3),(J,9),(K,12),)]
                # ({I}_{2}, {J}_{7}, {K}_{14})
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][30][2,0]*r[J][3][7,0]*r[K][2][14,0]*t[((I,2),(J,7),(K,14),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][15][2,0]*r[J][3][7,0]*r[K][2][14,0]*t[((I,2),(J,7),(K,14),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][48][2,0]*r[J][3][7,0]*r[K][2][14,0]*t[((I,2),(J,7),(K,14),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][33][2,0]*r[J][3][7,0]*r[K][2][14,0]*t[((I,2),(J,7),(K,14),)]
                tu += 1/6*g[dei(p[I,0],p[J,0],p[I,1],p[K,0])]*r[I][30][2,0]*r[J][3][7,0]*r[K][2][14,0]*t[((I,2),(J,7),(K,14),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[I,1],p[J,0])]*r[I][48][2,0]*r[J][3][7,0]*r[K][2][14,0]*t[((I,2),(J,7),(K,14),)]
                # ({I}_{3}, {J}_{7}, {K}_{14})
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][30][3,0]*r[J][3][7,0]*r[K][2][14,0]*t[((I,3),(J,7),(K,14),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][15][3,0]*r[J][3][7,0]*r[K][2][14,0]*t[((I,3),(J,7),(K,14),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][48][3,0]*r[J][3][7,0]*r[K][2][14,0]*t[((I,3),(J,7),(K,14),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,0])]*r[I][33][3,0]*r[J][3][7,0]*r[K][2][14,0]*t[((I,3),(J,7),(K,14),)]
                tu += 1/6*g[dei(p[I,0],p[J,0],p[I,1],p[K,0])]*r[I][30][3,0]*r[J][3][7,0]*r[K][2][14,0]*t[((I,3),(J,7),(K,14),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[I,1],p[J,0])]*r[I][48][3,0]*r[J][3][7,0]*r[K][2][14,0]*t[((I,3),(J,7),(K,14),)]
                # ({I}_{2}, {J}_{10}, {K}_{12})
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][15][2,0]*r[J][5][10,0]*r[K][0][12,0]*t[((I,2),(J,10),(K,12),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][33][2,0]*r[J][5][10,0]*r[K][0][12,0]*t[((I,2),(J,10),(K,12),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[I,1],p[K,0])]*r[I][15][2,0]*r[J][5][10,0]*r[K][0][12,0]*t[((I,2),(J,10),(K,12),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[I,1],p[J,1])]*r[I][33][2,0]*r[J][5][10,0]*r[K][0][12,0]*t[((I,2),(J,10),(K,12),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][30][2,0]*r[J][5][10,0]*r[K][0][12,0]*t[((I,2),(J,10),(K,12),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][48][2,0]*r[J][5][10,0]*r[K][0][12,0]*t[((I,2),(J,10),(K,12),)]
                # ({I}_{3}, {J}_{10}, {K}_{12})
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][15][3,0]*r[J][5][10,0]*r[K][0][12,0]*t[((I,3),(J,10),(K,12),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][33][3,0]*r[J][5][10,0]*r[K][0][12,0]*t[((I,3),(J,10),(K,12),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[I,1],p[K,0])]*r[I][15][3,0]*r[J][5][10,0]*r[K][0][12,0]*t[((I,3),(J,10),(K,12),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[I,1],p[J,1])]*r[I][33][3,0]*r[J][5][10,0]*r[K][0][12,0]*t[((I,3),(J,10),(K,12),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][30][3,0]*r[J][5][10,0]*r[K][0][12,0]*t[((I,3),(J,10),(K,12),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][48][3,0]*r[J][5][10,0]*r[K][0][12,0]*t[((I,3),(J,10),(K,12),)]
                # ({I}_{2}, {J}_{8}, {K}_{14})
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][30][2,0]*r[J][7][8,0]*r[K][2][14,0]*t[((I,2),(J,8),(K,14),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][15][2,0]*r[J][7][8,0]*r[K][2][14,0]*t[((I,2),(J,8),(K,14),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][48][2,0]*r[J][7][8,0]*r[K][2][14,0]*t[((I,2),(J,8),(K,14),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][33][2,0]*r[J][7][8,0]*r[K][2][14,0]*t[((I,2),(J,8),(K,14),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[I,1],p[K,0])]*r[I][30][2,0]*r[J][7][8,0]*r[K][2][14,0]*t[((I,2),(J,8),(K,14),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[I,1],p[J,1])]*r[I][48][2,0]*r[J][7][8,0]*r[K][2][14,0]*t[((I,2),(J,8),(K,14),)]
                # ({I}_{3}, {J}_{8}, {K}_{14})
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][30][3,0]*r[J][7][8,0]*r[K][2][14,0]*t[((I,3),(J,8),(K,14),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][15][3,0]*r[J][7][8,0]*r[K][2][14,0]*t[((I,3),(J,8),(K,14),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][48][3,0]*r[J][7][8,0]*r[K][2][14,0]*t[((I,3),(J,8),(K,14),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,0])]*r[I][33][3,0]*r[J][7][8,0]*r[K][2][14,0]*t[((I,3),(J,8),(K,14),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[I,1],p[K,0])]*r[I][30][3,0]*r[J][7][8,0]*r[K][2][14,0]*t[((I,3),(J,8),(K,14),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[I,1],p[J,1])]*r[I][48][3,0]*r[J][7][8,0]*r[K][2][14,0]*t[((I,3),(J,8),(K,14),)]
                # ({I}_{1}, {J}_{9}, {K}_{11})
                tu += -1/6*g[dei(p[I,0],p[I,0],p[J,0],p[K,1])]*r[I][9][1,0]*r[J][1][9,0]*r[K][4][11,0]*t[((I,1),(J,9),(K,11),)]
                tu += -1/6*g[dei(p[I,1],p[I,1],p[J,0],p[K,1])]*r[I][39][1,0]*r[J][1][9,0]*r[K][4][11,0]*t[((I,1),(J,9),(K,11),)]
                tu += 1/6*g[dei(p[I,0],p[J,0],p[I,0],p[K,1])]*r[I][9][1,0]*r[J][1][9,0]*r[K][4][11,0]*t[((I,1),(J,9),(K,11),)]
                tu += 1/6*g[dei(p[I,1],p[J,0],p[I,1],p[K,1])]*r[I][39][1,0]*r[J][1][9,0]*r[K][4][11,0]*t[((I,1),(J,9),(K,11),)]
                tu += -1/6*g[dei(p[I,0],p[I,0],p[J,0],p[K,1])]*r[I][24][1,0]*r[J][1][9,0]*r[K][4][11,0]*t[((I,1),(J,9),(K,11),)]
                tu += -1/6*g[dei(p[I,1],p[I,1],p[J,0],p[K,1])]*r[I][54][1,0]*r[J][1][9,0]*r[K][4][11,0]*t[((I,1),(J,9),(K,11),)]
                # ({I}_{1}, {J}_{7}, {K}_{13})
                tu += -1/6*g[dei(p[I,0],p[I,0],p[J,0],p[K,1])]*r[I][24][1,0]*r[J][3][7,0]*r[K][6][13,0]*t[((I,1),(J,7),(K,13),)]
                tu += -1/6*g[dei(p[I,0],p[I,0],p[J,0],p[K,1])]*r[I][9][1,0]*r[J][3][7,0]*r[K][6][13,0]*t[((I,1),(J,7),(K,13),)]
                tu += -1/6*g[dei(p[I,1],p[I,1],p[J,0],p[K,1])]*r[I][54][1,0]*r[J][3][7,0]*r[K][6][13,0]*t[((I,1),(J,7),(K,13),)]
                tu += -1/6*g[dei(p[I,1],p[I,1],p[J,0],p[K,1])]*r[I][39][1,0]*r[J][3][7,0]*r[K][6][13,0]*t[((I,1),(J,7),(K,13),)]
                tu += 1/6*g[dei(p[I,0],p[J,0],p[I,0],p[K,1])]*r[I][24][1,0]*r[J][3][7,0]*r[K][6][13,0]*t[((I,1),(J,7),(K,13),)]
                tu += 1/6*g[dei(p[I,1],p[J,0],p[I,1],p[K,1])]*r[I][54][1,0]*r[J][3][7,0]*r[K][6][13,0]*t[((I,1),(J,7),(K,13),)]
                # ({I}_{1}, {J}_{10}, {K}_{11})
                tu += -1/6*g[dei(p[I,0],p[I,0],p[J,1],p[K,1])]*r[I][9][1,0]*r[J][5][10,0]*r[K][4][11,0]*t[((I,1),(J,10),(K,11),)]
                tu += -1/6*g[dei(p[I,1],p[I,1],p[J,1],p[K,1])]*r[I][39][1,0]*r[J][5][10,0]*r[K][4][11,0]*t[((I,1),(J,10),(K,11),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[I,0],p[K,1])]*r[I][9][1,0]*r[J][5][10,0]*r[K][4][11,0]*t[((I,1),(J,10),(K,11),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[I,1],p[K,1])]*r[I][39][1,0]*r[J][5][10,0]*r[K][4][11,0]*t[((I,1),(J,10),(K,11),)]
                tu += -1/6*g[dei(p[I,0],p[I,0],p[J,1],p[K,1])]*r[I][24][1,0]*r[J][5][10,0]*r[K][4][11,0]*t[((I,1),(J,10),(K,11),)]
                tu += -1/6*g[dei(p[I,1],p[I,1],p[J,1],p[K,1])]*r[I][54][1,0]*r[J][5][10,0]*r[K][4][11,0]*t[((I,1),(J,10),(K,11),)]
                # ({I}_{1}, {J}_{8}, {K}_{13})
                tu += -1/6*g[dei(p[I,0],p[I,0],p[J,1],p[K,1])]*r[I][24][1,0]*r[J][7][8,0]*r[K][6][13,0]*t[((I,1),(J,8),(K,13),)]
                tu += -1/6*g[dei(p[I,0],p[I,0],p[J,1],p[K,1])]*r[I][9][1,0]*r[J][7][8,0]*r[K][6][13,0]*t[((I,1),(J,8),(K,13),)]
                tu += -1/6*g[dei(p[I,1],p[I,1],p[J,1],p[K,1])]*r[I][54][1,0]*r[J][7][8,0]*r[K][6][13,0]*t[((I,1),(J,8),(K,13),)]
                tu += -1/6*g[dei(p[I,1],p[I,1],p[J,1],p[K,1])]*r[I][39][1,0]*r[J][7][8,0]*r[K][6][13,0]*t[((I,1),(J,8),(K,13),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[I,0],p[K,1])]*r[I][24][1,0]*r[J][7][8,0]*r[K][6][13,0]*t[((I,1),(J,8),(K,13),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[I,1],p[K,1])]*r[I][54][1,0]*r[J][7][8,0]*r[K][6][13,0]*t[((I,1),(J,8),(K,13),)]
                # ({I}_{2}, {J}_{9}, {K}_{11})
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][15][2,0]*r[J][1][9,0]*r[K][4][11,0]*t[((I,2),(J,9),(K,11),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][33][2,0]*r[J][1][9,0]*r[K][4][11,0]*t[((I,2),(J,9),(K,11),)]
                tu += 1/6*g[dei(p[I,0],p[J,0],p[I,1],p[K,1])]*r[I][15][2,0]*r[J][1][9,0]*r[K][4][11,0]*t[((I,2),(J,9),(K,11),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[I,1],p[J,0])]*r[I][33][2,0]*r[J][1][9,0]*r[K][4][11,0]*t[((I,2),(J,9),(K,11),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][30][2,0]*r[J][1][9,0]*r[K][4][11,0]*t[((I,2),(J,9),(K,11),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][48][2,0]*r[J][1][9,0]*r[K][4][11,0]*t[((I,2),(J,9),(K,11),)]
                # ({I}_{3}, {J}_{9}, {K}_{11})
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][15][3,0]*r[J][1][9,0]*r[K][4][11,0]*t[((I,3),(J,9),(K,11),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][33][3,0]*r[J][1][9,0]*r[K][4][11,0]*t[((I,3),(J,9),(K,11),)]
                tu += 1/6*g[dei(p[I,0],p[J,0],p[I,1],p[K,1])]*r[I][15][3,0]*r[J][1][9,0]*r[K][4][11,0]*t[((I,3),(J,9),(K,11),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[I,1],p[J,0])]*r[I][33][3,0]*r[J][1][9,0]*r[K][4][11,0]*t[((I,3),(J,9),(K,11),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][30][3,0]*r[J][1][9,0]*r[K][4][11,0]*t[((I,3),(J,9),(K,11),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][48][3,0]*r[J][1][9,0]*r[K][4][11,0]*t[((I,3),(J,9),(K,11),)]
                # ({I}_{2}, {J}_{7}, {K}_{13})
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][30][2,0]*r[J][3][7,0]*r[K][6][13,0]*t[((I,2),(J,7),(K,13),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][15][2,0]*r[J][3][7,0]*r[K][6][13,0]*t[((I,2),(J,7),(K,13),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][48][2,0]*r[J][3][7,0]*r[K][6][13,0]*t[((I,2),(J,7),(K,13),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][33][2,0]*r[J][3][7,0]*r[K][6][13,0]*t[((I,2),(J,7),(K,13),)]
                tu += 1/6*g[dei(p[I,0],p[J,0],p[I,1],p[K,1])]*r[I][30][2,0]*r[J][3][7,0]*r[K][6][13,0]*t[((I,2),(J,7),(K,13),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[I,1],p[J,0])]*r[I][48][2,0]*r[J][3][7,0]*r[K][6][13,0]*t[((I,2),(J,7),(K,13),)]
                # ({I}_{3}, {J}_{7}, {K}_{13})
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][30][3,0]*r[J][3][7,0]*r[K][6][13,0]*t[((I,3),(J,7),(K,13),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][15][3,0]*r[J][3][7,0]*r[K][6][13,0]*t[((I,3),(J,7),(K,13),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][48][3,0]*r[J][3][7,0]*r[K][6][13,0]*t[((I,3),(J,7),(K,13),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,0],p[K,1])]*r[I][33][3,0]*r[J][3][7,0]*r[K][6][13,0]*t[((I,3),(J,7),(K,13),)]
                tu += 1/6*g[dei(p[I,0],p[J,0],p[I,1],p[K,1])]*r[I][30][3,0]*r[J][3][7,0]*r[K][6][13,0]*t[((I,3),(J,7),(K,13),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[I,1],p[J,0])]*r[I][48][3,0]*r[J][3][7,0]*r[K][6][13,0]*t[((I,3),(J,7),(K,13),)]
                # ({I}_{2}, {J}_{10}, {K}_{11})
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][15][2,0]*r[J][5][10,0]*r[K][4][11,0]*t[((I,2),(J,10),(K,11),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][33][2,0]*r[J][5][10,0]*r[K][4][11,0]*t[((I,2),(J,10),(K,11),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[I,1],p[K,1])]*r[I][15][2,0]*r[J][5][10,0]*r[K][4][11,0]*t[((I,2),(J,10),(K,11),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[I,1],p[J,1])]*r[I][33][2,0]*r[J][5][10,0]*r[K][4][11,0]*t[((I,2),(J,10),(K,11),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][30][2,0]*r[J][5][10,0]*r[K][4][11,0]*t[((I,2),(J,10),(K,11),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][48][2,0]*r[J][5][10,0]*r[K][4][11,0]*t[((I,2),(J,10),(K,11),)]
                # ({I}_{3}, {J}_{10}, {K}_{11})
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][15][3,0]*r[J][5][10,0]*r[K][4][11,0]*t[((I,3),(J,10),(K,11),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][33][3,0]*r[J][5][10,0]*r[K][4][11,0]*t[((I,3),(J,10),(K,11),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[I,1],p[K,1])]*r[I][15][3,0]*r[J][5][10,0]*r[K][4][11,0]*t[((I,3),(J,10),(K,11),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[I,1],p[J,1])]*r[I][33][3,0]*r[J][5][10,0]*r[K][4][11,0]*t[((I,3),(J,10),(K,11),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][30][3,0]*r[J][5][10,0]*r[K][4][11,0]*t[((I,3),(J,10),(K,11),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][48][3,0]*r[J][5][10,0]*r[K][4][11,0]*t[((I,3),(J,10),(K,11),)]
                # ({I}_{2}, {J}_{8}, {K}_{13})
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][30][2,0]*r[J][7][8,0]*r[K][6][13,0]*t[((I,2),(J,8),(K,13),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][15][2,0]*r[J][7][8,0]*r[K][6][13,0]*t[((I,2),(J,8),(K,13),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][48][2,0]*r[J][7][8,0]*r[K][6][13,0]*t[((I,2),(J,8),(K,13),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][33][2,0]*r[J][7][8,0]*r[K][6][13,0]*t[((I,2),(J,8),(K,13),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[I,1],p[K,1])]*r[I][30][2,0]*r[J][7][8,0]*r[K][6][13,0]*t[((I,2),(J,8),(K,13),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[I,1],p[J,1])]*r[I][48][2,0]*r[J][7][8,0]*r[K][6][13,0]*t[((I,2),(J,8),(K,13),)]
                # ({I}_{3}, {J}_{8}, {K}_{13})
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][30][3,0]*r[J][7][8,0]*r[K][6][13,0]*t[((I,3),(J,8),(K,13),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][15][3,0]*r[J][7][8,0]*r[K][6][13,0]*t[((I,3),(J,8),(K,13),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][48][3,0]*r[J][7][8,0]*r[K][6][13,0]*t[((I,3),(J,8),(K,13),)]
                tu += -1/6*g[dei(p[I,0],p[I,1],p[J,1],p[K,1])]*r[I][33][3,0]*r[J][7][8,0]*r[K][6][13,0]*t[((I,3),(J,8),(K,13),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[I,1],p[K,1])]*r[I][30][3,0]*r[J][7][8,0]*r[K][6][13,0]*t[((I,3),(J,8),(K,13),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[I,1],p[J,1])]*r[I][48][3,0]*r[J][7][8,0]*r[K][6][13,0]*t[((I,3),(J,8),(K,13),)]
                # ({I}_{4}, {J}_{9}, {K}_{14})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[I,1],p[K,0])]*r[I][18][4,0]*r[J][1][9,0]*r[K][2][14,0]*t[((I,4),(J,9),(K,14),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[I,1],p[J,0])]*r[I][36][4,0]*r[J][1][9,0]*r[K][2][14,0]*t[((I,4),(J,9),(K,14),)]
                # ({I}_{4}, {J}_{10}, {K}_{14})
                tu += 1/6*g[dei(p[I,0],p[J,1],p[I,1],p[K,0])]*r[I][18][4,0]*r[J][5][10,0]*r[K][2][14,0]*t[((I,4),(J,10),(K,14),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[I,1],p[J,1])]*r[I][36][4,0]*r[J][5][10,0]*r[K][2][14,0]*t[((I,4),(J,10),(K,14),)]
                # ({I}_{4}, {J}_{9}, {K}_{13})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[I,1],p[K,1])]*r[I][18][4,0]*r[J][1][9,0]*r[K][6][13,0]*t[((I,4),(J,9),(K,13),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[I,1],p[J,0])]*r[I][36][4,0]*r[J][1][9,0]*r[K][6][13,0]*t[((I,4),(J,9),(K,13),)]
                # ({I}_{4}, {J}_{10}, {K}_{13})
                tu += 1/6*g[dei(p[I,0],p[J,1],p[I,1],p[K,1])]*r[I][18][4,0]*r[J][5][10,0]*r[K][6][13,0]*t[((I,4),(J,10),(K,13),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[I,1],p[J,1])]*r[I][36][4,0]*r[J][5][10,0]*r[K][6][13,0]*t[((I,4),(J,10),(K,13),)]
                # ({I}_{12}, {J}_{6}, {K}_{14})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[J,0],p[K,0])]*r[I][0][12,0]*r[J][22][6,0]*r[K][2][14,0]*t[((I,12),(J,6),(K,14),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[J,1],p[K,0])]*r[I][0][12,0]*r[J][52][6,0]*r[K][2][14,0]*t[((I,12),(J,6),(K,14),)]
                # ({I}_{12}, {J}_{6}, {K}_{13})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[J,0],p[K,1])]*r[I][0][12,0]*r[J][22][6,0]*r[K][6][13,0]*t[((I,12),(J,6),(K,13),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[J,1],p[K,1])]*r[I][0][12,0]*r[J][52][6,0]*r[K][6][13,0]*t[((I,12),(J,6),(K,13),)]
                # ({I}_{11}, {J}_{6}, {K}_{14})
                tu += 1/6*g[dei(p[I,1],p[J,0],p[J,0],p[K,0])]*r[I][4][11,0]*r[J][22][6,0]*r[K][2][14,0]*t[((I,11),(J,6),(K,14),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[J,1],p[K,0])]*r[I][4][11,0]*r[J][52][6,0]*r[K][2][14,0]*t[((I,11),(J,6),(K,14),)]
                # ({I}_{11}, {J}_{6}, {K}_{13})
                tu += 1/6*g[dei(p[I,1],p[J,0],p[J,0],p[K,1])]*r[I][4][11,0]*r[J][22][6,0]*r[K][6][13,0]*t[((I,11),(J,6),(K,13),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[J,1],p[K,1])]*r[I][4][11,0]*r[J][52][6,0]*r[K][6][13,0]*t[((I,11),(J,6),(K,13),)]
                # ({I}_{12}, {J}_{9}, {K}_{1})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][9][1,0]*t[((I,12),(J,9),(K,1),)]
                tu += 1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][24][1,0]*t[((I,12),(J,9),(K,1),)]
                tu += 1/6*g[dei(p[I,0],p[J,0],p[K,1],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][39][1,0]*t[((I,12),(J,9),(K,1),)]
                tu += 1/6*g[dei(p[I,0],p[J,0],p[K,1],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][54][1,0]*t[((I,12),(J,9),(K,1),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,0],p[K,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][9][1,0]*t[((I,12),(J,9),(K,1),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,0],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][39][1,0]*t[((I,12),(J,9),(K,1),)]
                # ({I}_{14}, {J}_{7}, {K}_{1})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][24][1,0]*t[((I,14),(J,7),(K,1),)]
                tu += 1/6*g[dei(p[I,0],p[J,0],p[K,1],p[K,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][54][1,0]*t[((I,14),(J,7),(K,1),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,0],p[K,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][24][1,0]*t[((I,14),(J,7),(K,1),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,0],p[K,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][54][1,0]*t[((I,14),(J,7),(K,1),)]
                tu += 1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][9][1,0]*t[((I,14),(J,7),(K,1),)]
                tu += 1/6*g[dei(p[I,0],p[J,0],p[K,1],p[K,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][39][1,0]*t[((I,14),(J,7),(K,1),)]
                # ({I}_{12}, {J}_{9}, {K}_{2})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][15][2,0]*t[((I,12),(J,9),(K,2),)]
                tu += 1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][30][2,0]*t[((I,12),(J,9),(K,2),)]
                tu += 1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][33][2,0]*t[((I,12),(J,9),(K,2),)]
                tu += 1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][48][2,0]*t[((I,12),(J,9),(K,2),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,0],p[K,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][15][2,0]*t[((I,12),(J,9),(K,2),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,0],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][33][2,0]*t[((I,12),(J,9),(K,2),)]
                # ({I}_{12}, {J}_{9}, {K}_{3})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][15][3,0]*t[((I,12),(J,9),(K,3),)]
                tu += 1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][30][3,0]*t[((I,12),(J,9),(K,3),)]
                tu += 1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][33][3,0]*t[((I,12),(J,9),(K,3),)]
                tu += 1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][48][3,0]*t[((I,12),(J,9),(K,3),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,0],p[K,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][15][3,0]*t[((I,12),(J,9),(K,3),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,0],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][33][3,0]*t[((I,12),(J,9),(K,3),)]
                # ({I}_{14}, {J}_{7}, {K}_{2})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][30][2,0]*t[((I,14),(J,7),(K,2),)]
                tu += 1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][48][2,0]*t[((I,14),(J,7),(K,2),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,0],p[K,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][30][2,0]*t[((I,14),(J,7),(K,2),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,0],p[K,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][48][2,0]*t[((I,14),(J,7),(K,2),)]
                tu += 1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][15][2,0]*t[((I,14),(J,7),(K,2),)]
                tu += 1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][33][2,0]*t[((I,14),(J,7),(K,2),)]
                # ({I}_{14}, {J}_{7}, {K}_{3})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][30][3,0]*t[((I,14),(J,7),(K,3),)]
                tu += 1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][48][3,0]*t[((I,14),(J,7),(K,3),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,0],p[K,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][30][3,0]*t[((I,14),(J,7),(K,3),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,0],p[K,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][48][3,0]*t[((I,14),(J,7),(K,3),)]
                tu += 1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][15][3,0]*t[((I,14),(J,7),(K,3),)]
                tu += 1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][33][3,0]*t[((I,14),(J,7),(K,3),)]
                # ({I}_{12}, {J}_{10}, {K}_{1})
                tu += 1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][9][1,0]*t[((I,12),(J,10),(K,1),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][24][1,0]*t[((I,12),(J,10),(K,1),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[K,1],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][39][1,0]*t[((I,12),(J,10),(K,1),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[K,1],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][54][1,0]*t[((I,12),(J,10),(K,1),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,1],p[K,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][9][1,0]*t[((I,12),(J,10),(K,1),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,1],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][39][1,0]*t[((I,12),(J,10),(K,1),)]
                # ({I}_{14}, {J}_{8}, {K}_{1})
                tu += 1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][24][1,0]*t[((I,14),(J,8),(K,1),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[K,1],p[K,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][54][1,0]*t[((I,14),(J,8),(K,1),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,1],p[K,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][24][1,0]*t[((I,14),(J,8),(K,1),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,1],p[K,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][54][1,0]*t[((I,14),(J,8),(K,1),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][9][1,0]*t[((I,14),(J,8),(K,1),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[K,1],p[K,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][39][1,0]*t[((I,14),(J,8),(K,1),)]
                # ({I}_{12}, {J}_{10}, {K}_{2})
                tu += 1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][15][2,0]*t[((I,12),(J,10),(K,2),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][30][2,0]*t[((I,12),(J,10),(K,2),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][33][2,0]*t[((I,12),(J,10),(K,2),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][48][2,0]*t[((I,12),(J,10),(K,2),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,1],p[K,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][15][2,0]*t[((I,12),(J,10),(K,2),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,1],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][33][2,0]*t[((I,12),(J,10),(K,2),)]
                # ({I}_{12}, {J}_{10}, {K}_{3})
                tu += 1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][15][3,0]*t[((I,12),(J,10),(K,3),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][30][3,0]*t[((I,12),(J,10),(K,3),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][33][3,0]*t[((I,12),(J,10),(K,3),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][48][3,0]*t[((I,12),(J,10),(K,3),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,1],p[K,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][15][3,0]*t[((I,12),(J,10),(K,3),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,1],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][33][3,0]*t[((I,12),(J,10),(K,3),)]
                # ({I}_{14}, {J}_{8}, {K}_{2})
                tu += 1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][30][2,0]*t[((I,14),(J,8),(K,2),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][48][2,0]*t[((I,14),(J,8),(K,2),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,1],p[K,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][30][2,0]*t[((I,14),(J,8),(K,2),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,1],p[K,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][48][2,0]*t[((I,14),(J,8),(K,2),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][15][2,0]*t[((I,14),(J,8),(K,2),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][33][2,0]*t[((I,14),(J,8),(K,2),)]
                # ({I}_{14}, {J}_{8}, {K}_{3})
                tu += 1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][30][3,0]*t[((I,14),(J,8),(K,3),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][48][3,0]*t[((I,14),(J,8),(K,3),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,1],p[K,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][30][3,0]*t[((I,14),(J,8),(K,3),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,1],p[K,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][48][3,0]*t[((I,14),(J,8),(K,3),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][15][3,0]*t[((I,14),(J,8),(K,3),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][33][3,0]*t[((I,14),(J,8),(K,3),)]
                # ({I}_{11}, {J}_{9}, {K}_{1})
                tu += 1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][9][1,0]*t[((I,11),(J,9),(K,1),)]
                tu += 1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][24][1,0]*t[((I,11),(J,9),(K,1),)]
                tu += 1/6*g[dei(p[I,1],p[J,0],p[K,1],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][39][1,0]*t[((I,11),(J,9),(K,1),)]
                tu += 1/6*g[dei(p[I,1],p[J,0],p[K,1],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][54][1,0]*t[((I,11),(J,9),(K,1),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,0],p[K,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][9][1,0]*t[((I,11),(J,9),(K,1),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,0],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][39][1,0]*t[((I,11),(J,9),(K,1),)]
                # ({I}_{13}, {J}_{7}, {K}_{1})
                tu += 1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][24][1,0]*t[((I,13),(J,7),(K,1),)]
                tu += 1/6*g[dei(p[I,1],p[J,0],p[K,1],p[K,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][54][1,0]*t[((I,13),(J,7),(K,1),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,0],p[K,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][24][1,0]*t[((I,13),(J,7),(K,1),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,0],p[K,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][54][1,0]*t[((I,13),(J,7),(K,1),)]
                tu += 1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][9][1,0]*t[((I,13),(J,7),(K,1),)]
                tu += 1/6*g[dei(p[I,1],p[J,0],p[K,1],p[K,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][39][1,0]*t[((I,13),(J,7),(K,1),)]
                # ({I}_{11}, {J}_{9}, {K}_{2})
                tu += 1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][15][2,0]*t[((I,11),(J,9),(K,2),)]
                tu += 1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][30][2,0]*t[((I,11),(J,9),(K,2),)]
                tu += 1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][33][2,0]*t[((I,11),(J,9),(K,2),)]
                tu += 1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][48][2,0]*t[((I,11),(J,9),(K,2),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,0],p[K,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][15][2,0]*t[((I,11),(J,9),(K,2),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,0],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][33][2,0]*t[((I,11),(J,9),(K,2),)]
                # ({I}_{11}, {J}_{9}, {K}_{3})
                tu += 1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][15][3,0]*t[((I,11),(J,9),(K,3),)]
                tu += 1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][30][3,0]*t[((I,11),(J,9),(K,3),)]
                tu += 1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][33][3,0]*t[((I,11),(J,9),(K,3),)]
                tu += 1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][48][3,0]*t[((I,11),(J,9),(K,3),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,0],p[K,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][15][3,0]*t[((I,11),(J,9),(K,3),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,0],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][33][3,0]*t[((I,11),(J,9),(K,3),)]
                # ({I}_{13}, {J}_{7}, {K}_{2})
                tu += 1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][30][2,0]*t[((I,13),(J,7),(K,2),)]
                tu += 1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][48][2,0]*t[((I,13),(J,7),(K,2),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,0],p[K,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][30][2,0]*t[((I,13),(J,7),(K,2),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,0],p[K,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][48][2,0]*t[((I,13),(J,7),(K,2),)]
                tu += 1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][15][2,0]*t[((I,13),(J,7),(K,2),)]
                tu += 1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][33][2,0]*t[((I,13),(J,7),(K,2),)]
                # ({I}_{13}, {J}_{7}, {K}_{3})
                tu += 1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][30][3,0]*t[((I,13),(J,7),(K,3),)]
                tu += 1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][48][3,0]*t[((I,13),(J,7),(K,3),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,0],p[K,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][30][3,0]*t[((I,13),(J,7),(K,3),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,0],p[K,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][48][3,0]*t[((I,13),(J,7),(K,3),)]
                tu += 1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][15][3,0]*t[((I,13),(J,7),(K,3),)]
                tu += 1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][33][3,0]*t[((I,13),(J,7),(K,3),)]
                # ({I}_{11}, {J}_{10}, {K}_{1})
                tu += 1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][9][1,0]*t[((I,11),(J,10),(K,1),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][24][1,0]*t[((I,11),(J,10),(K,1),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[K,1],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][39][1,0]*t[((I,11),(J,10),(K,1),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[K,1],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][54][1,0]*t[((I,11),(J,10),(K,1),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,1],p[K,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][9][1,0]*t[((I,11),(J,10),(K,1),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,1],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][39][1,0]*t[((I,11),(J,10),(K,1),)]
                # ({I}_{13}, {J}_{8}, {K}_{1})
                tu += 1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][24][1,0]*t[((I,13),(J,8),(K,1),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[K,1],p[K,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][54][1,0]*t[((I,13),(J,8),(K,1),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,1],p[K,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][24][1,0]*t[((I,13),(J,8),(K,1),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,1],p[K,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][54][1,0]*t[((I,13),(J,8),(K,1),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][9][1,0]*t[((I,13),(J,8),(K,1),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[K,1],p[K,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][39][1,0]*t[((I,13),(J,8),(K,1),)]
                # ({I}_{11}, {J}_{10}, {K}_{2})
                tu += 1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][15][2,0]*t[((I,11),(J,10),(K,2),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][30][2,0]*t[((I,11),(J,10),(K,2),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][33][2,0]*t[((I,11),(J,10),(K,2),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][48][2,0]*t[((I,11),(J,10),(K,2),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,1],p[K,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][15][2,0]*t[((I,11),(J,10),(K,2),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,1],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][33][2,0]*t[((I,11),(J,10),(K,2),)]
                # ({I}_{11}, {J}_{10}, {K}_{3})
                tu += 1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][15][3,0]*t[((I,11),(J,10),(K,3),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][30][3,0]*t[((I,11),(J,10),(K,3),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][33][3,0]*t[((I,11),(J,10),(K,3),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][48][3,0]*t[((I,11),(J,10),(K,3),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,1],p[K,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][15][3,0]*t[((I,11),(J,10),(K,3),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,1],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][33][3,0]*t[((I,11),(J,10),(K,3),)]
                # ({I}_{13}, {J}_{8}, {K}_{2})
                tu += 1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][30][2,0]*t[((I,13),(J,8),(K,2),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][48][2,0]*t[((I,13),(J,8),(K,2),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,1],p[K,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][30][2,0]*t[((I,13),(J,8),(K,2),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,1],p[K,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][48][2,0]*t[((I,13),(J,8),(K,2),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][15][2,0]*t[((I,13),(J,8),(K,2),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][33][2,0]*t[((I,13),(J,8),(K,2),)]
                # ({I}_{13}, {J}_{8}, {K}_{3})
                tu += 1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][30][3,0]*t[((I,13),(J,8),(K,3),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][48][3,0]*t[((I,13),(J,8),(K,3),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,1],p[K,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][30][3,0]*t[((I,13),(J,8),(K,3),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,1],p[K,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][48][3,0]*t[((I,13),(J,8),(K,3),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][15][3,0]*t[((I,13),(J,8),(K,3),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][33][3,0]*t[((I,13),(J,8),(K,3),)]
                # ({I}_{12}, {J}_{7}, {K}_{5})
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,0],p[K,0])]*r[I][0][12,0]*r[J][3][7,0]*r[K][27][5,0]*t[((I,12),(J,7),(K,5),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,0],p[K,1])]*r[I][0][12,0]*r[J][3][7,0]*r[K][45][5,0]*t[((I,12),(J,7),(K,5),)]
                # ({I}_{12}, {J}_{8}, {K}_{5})
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,1],p[K,0])]*r[I][0][12,0]*r[J][7][8,0]*r[K][27][5,0]*t[((I,12),(J,8),(K,5),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,1],p[K,1])]*r[I][0][12,0]*r[J][7][8,0]*r[K][45][5,0]*t[((I,12),(J,8),(K,5),)]
                # ({I}_{11}, {J}_{7}, {K}_{5})
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,0],p[K,0])]*r[I][4][11,0]*r[J][3][7,0]*r[K][27][5,0]*t[((I,11),(J,7),(K,5),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,0],p[K,1])]*r[I][4][11,0]*r[J][3][7,0]*r[K][45][5,0]*t[((I,11),(J,7),(K,5),)]
                # ({I}_{11}, {J}_{8}, {K}_{5})
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,1],p[K,0])]*r[I][4][11,0]*r[J][7][8,0]*r[K][27][5,0]*t[((I,11),(J,8),(K,5),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,1],p[K,1])]*r[I][4][11,0]*r[J][7][8,0]*r[K][45][5,0]*t[((I,11),(J,8),(K,5),)]
                # ({I}_{5}, {J}_{12}, {K}_{7})
                tu += -1/6*g[dei(p[I,0],p[K,0],p[I,1],p[J,0])]*r[I][27][5,0]*r[J][0][12,0]*r[K][3][7,0]*t[((I,5),(J,12),(K,7),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[I,1],p[K,0])]*r[I][45][5,0]*r[J][0][12,0]*r[K][3][7,0]*t[((I,5),(J,12),(K,7),)]
                # ({I}_{5}, {J}_{12}, {K}_{8})
                tu += -1/6*g[dei(p[I,0],p[K,1],p[I,1],p[J,0])]*r[I][27][5,0]*r[J][0][12,0]*r[K][7][8,0]*t[((I,5),(J,12),(K,8),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[I,1],p[K,1])]*r[I][45][5,0]*r[J][0][12,0]*r[K][7][8,0]*t[((I,5),(J,12),(K,8),)]
                # ({I}_{5}, {J}_{11}, {K}_{7})
                tu += -1/6*g[dei(p[I,0],p[K,0],p[I,1],p[J,1])]*r[I][27][5,0]*r[J][4][11,0]*r[K][3][7,0]*t[((I,5),(J,11),(K,7),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[I,1],p[K,0])]*r[I][45][5,0]*r[J][4][11,0]*r[K][3][7,0]*t[((I,5),(J,11),(K,7),)]
                # ({I}_{5}, {J}_{11}, {K}_{8})
                tu += -1/6*g[dei(p[I,0],p[K,1],p[I,1],p[J,1])]*r[I][27][5,0]*r[J][4][11,0]*r[K][7][8,0]*t[((I,5),(J,11),(K,8),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[I,1],p[K,1])]*r[I][45][5,0]*r[J][4][11,0]*r[K][7][8,0]*t[((I,5),(J,11),(K,8),)]
                # ({I}_{14}, {J}_{4}, {K}_{9})
                tu += -1/6*g[dei(p[I,0],p[J,1],p[J,0],p[K,0])]*r[I][2][14,0]*r[J][18][4,0]*r[K][1][9,0]*t[((I,14),(J,4),(K,9),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[J,1],p[K,0])]*r[I][2][14,0]*r[J][36][4,0]*r[K][1][9,0]*t[((I,14),(J,4),(K,9),)]
                # ({I}_{14}, {J}_{4}, {K}_{10})
                tu += -1/6*g[dei(p[I,0],p[J,1],p[J,0],p[K,1])]*r[I][2][14,0]*r[J][18][4,0]*r[K][5][10,0]*t[((I,14),(J,4),(K,10),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[J,1],p[K,1])]*r[I][2][14,0]*r[J][36][4,0]*r[K][5][10,0]*t[((I,14),(J,4),(K,10),)]
                # ({I}_{13}, {J}_{4}, {K}_{9})
                tu += -1/6*g[dei(p[I,1],p[J,1],p[J,0],p[K,0])]*r[I][6][13,0]*r[J][18][4,0]*r[K][1][9,0]*t[((I,13),(J,4),(K,9),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[J,1],p[K,0])]*r[I][6][13,0]*r[J][36][4,0]*r[K][1][9,0]*t[((I,13),(J,4),(K,9),)]
                # ({I}_{13}, {J}_{4}, {K}_{10})
                tu += -1/6*g[dei(p[I,1],p[J,1],p[J,0],p[K,1])]*r[I][6][13,0]*r[J][18][4,0]*r[K][5][10,0]*t[((I,13),(J,4),(K,10),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[J,1],p[K,1])]*r[I][6][13,0]*r[J][36][4,0]*r[K][5][10,0]*t[((I,13),(J,4),(K,10),)]
                # ({I}_{14}, {J}_{12}, {K}_{6})
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,0],p[K,0])]*r[I][2][14,0]*r[J][0][12,0]*r[K][22][6,0]*t[((I,14),(J,12),(K,6),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,0],p[K,1])]*r[I][2][14,0]*r[J][0][12,0]*r[K][52][6,0]*t[((I,14),(J,12),(K,6),)]
                # ({I}_{13}, {J}_{12}, {K}_{6})
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,0],p[K,0])]*r[I][6][13,0]*r[J][0][12,0]*r[K][22][6,0]*t[((I,13),(J,12),(K,6),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,0],p[K,1])]*r[I][6][13,0]*r[J][0][12,0]*r[K][52][6,0]*t[((I,13),(J,12),(K,6),)]
                # ({I}_{14}, {J}_{11}, {K}_{6})
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,1],p[K,0])]*r[I][2][14,0]*r[J][4][11,0]*r[K][22][6,0]*t[((I,14),(J,11),(K,6),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,1],p[K,1])]*r[I][2][14,0]*r[J][4][11,0]*r[K][52][6,0]*t[((I,14),(J,11),(K,6),)]
                # ({I}_{13}, {J}_{11}, {K}_{6})
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,1],p[K,0])]*r[I][6][13,0]*r[J][4][11,0]*r[K][22][6,0]*t[((I,13),(J,11),(K,6),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,1],p[K,1])]*r[I][6][13,0]*r[J][4][11,0]*r[K][52][6,0]*t[((I,13),(J,11),(K,6),)]
                # ({I}_{9}, {J}_{15}, {K}_{7})
                tu += -1/6*g[dei(p[I,0],p[J,0],p[J,0],p[K,0])]*r[I][1][9,0]*r[J][11][15,0]*r[K][3][7,0]*t[((I,9),(J,15),(K,7),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[J,1],p[K,0])]*r[I][1][9,0]*r[J][41][15,0]*r[K][3][7,0]*t[((I,9),(J,15),(K,7),)]
                # ({I}_{9}, {J}_{15}, {K}_{8})
                tu += -1/6*g[dei(p[I,0],p[J,0],p[J,0],p[K,1])]*r[I][1][9,0]*r[J][11][15,0]*r[K][7][8,0]*t[((I,9),(J,15),(K,8),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[J,1],p[K,1])]*r[I][1][9,0]*r[J][41][15,0]*r[K][7][8,0]*t[((I,9),(J,15),(K,8),)]
                # ({I}_{10}, {J}_{15}, {K}_{7})
                tu += -1/6*g[dei(p[I,1],p[J,0],p[J,0],p[K,0])]*r[I][5][10,0]*r[J][11][15,0]*r[K][3][7,0]*t[((I,10),(J,15),(K,7),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[J,1],p[K,0])]*r[I][5][10,0]*r[J][41][15,0]*r[K][3][7,0]*t[((I,10),(J,15),(K,7),)]
                # ({I}_{10}, {J}_{15}, {K}_{8})
                tu += -1/6*g[dei(p[I,1],p[J,0],p[J,0],p[K,1])]*r[I][5][10,0]*r[J][11][15,0]*r[K][7][8,0]*t[((I,10),(J,15),(K,8),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[J,1],p[K,1])]*r[I][5][10,0]*r[J][41][15,0]*r[K][7][8,0]*t[((I,10),(J,15),(K,8),)]
                # ({I}_{7}, {J}_{15}, {K}_{9})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[J,0],p[K,0])]*r[I][3][7,0]*r[J][11][15,0]*r[K][1][9,0]*t[((I,7),(J,15),(K,9),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[J,1],p[K,0])]*r[I][3][7,0]*r[J][41][15,0]*r[K][1][9,0]*t[((I,7),(J,15),(K,9),)]
                # ({I}_{8}, {J}_{15}, {K}_{9})
                tu += 1/6*g[dei(p[I,1],p[J,0],p[J,0],p[K,0])]*r[I][7][8,0]*r[J][11][15,0]*r[K][1][9,0]*t[((I,8),(J,15),(K,9),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[J,1],p[K,0])]*r[I][7][8,0]*r[J][41][15,0]*r[K][1][9,0]*t[((I,8),(J,15),(K,9),)]
                # ({I}_{7}, {J}_{15}, {K}_{10})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[J,0],p[K,1])]*r[I][3][7,0]*r[J][11][15,0]*r[K][5][10,0]*t[((I,7),(J,15),(K,10),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[J,1],p[K,1])]*r[I][3][7,0]*r[J][41][15,0]*r[K][5][10,0]*t[((I,7),(J,15),(K,10),)]
                # ({I}_{8}, {J}_{15}, {K}_{10})
                tu += 1/6*g[dei(p[I,1],p[J,0],p[J,0],p[K,1])]*r[I][7][8,0]*r[J][11][15,0]*r[K][5][10,0]*t[((I,8),(J,15),(K,10),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[J,1],p[K,1])]*r[I][7][8,0]*r[J][41][15,0]*r[K][5][10,0]*t[((I,8),(J,15),(K,10),)]
                # ({I}_{6}, {J}_{12}, {K}_{14})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[I,0],p[K,0])]*r[I][22][6,0]*r[J][0][12,0]*r[K][2][14,0]*t[((I,6),(J,12),(K,14),)]
                tu += 1/6*g[dei(p[I,1],p[J,0],p[I,1],p[K,0])]*r[I][52][6,0]*r[J][0][12,0]*r[K][2][14,0]*t[((I,6),(J,12),(K,14),)]
                # ({I}_{6}, {J}_{12}, {K}_{13})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[I,0],p[K,1])]*r[I][22][6,0]*r[J][0][12,0]*r[K][6][13,0]*t[((I,6),(J,12),(K,13),)]
                tu += 1/6*g[dei(p[I,1],p[J,0],p[I,1],p[K,1])]*r[I][52][6,0]*r[J][0][12,0]*r[K][6][13,0]*t[((I,6),(J,12),(K,13),)]
                # ({I}_{6}, {J}_{11}, {K}_{14})
                tu += 1/6*g[dei(p[I,0],p[J,1],p[I,0],p[K,0])]*r[I][22][6,0]*r[J][4][11,0]*r[K][2][14,0]*t[((I,6),(J,11),(K,14),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[I,1],p[K,0])]*r[I][52][6,0]*r[J][4][11,0]*r[K][2][14,0]*t[((I,6),(J,11),(K,14),)]
                # ({I}_{6}, {J}_{11}, {K}_{13})
                tu += 1/6*g[dei(p[I,0],p[J,1],p[I,0],p[K,1])]*r[I][22][6,0]*r[J][4][11,0]*r[K][6][13,0]*t[((I,6),(J,11),(K,13),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[I,1],p[K,1])]*r[I][52][6,0]*r[J][4][11,0]*r[K][6][13,0]*t[((I,6),(J,11),(K,13),)]
                # ({I}_{9}, {J}_{1}, {K}_{12})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[J,0],p[K,0])]*r[I][1][9,0]*r[J][9][1,0]*r[K][0][12,0]*t[((I,9),(J,1),(K,12),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[J,1],p[K,0])]*r[I][1][9,0]*r[J][39][1,0]*r[K][0][12,0]*t[((I,9),(J,1),(K,12),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,0])]*r[I][1][9,0]*r[J][9][1,0]*r[K][0][12,0]*t[((I,9),(J,1),(K,12),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,1],p[J,1])]*r[I][1][9,0]*r[J][39][1,0]*r[K][0][12,0]*t[((I,9),(J,1),(K,12),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,0])]*r[I][1][9,0]*r[J][24][1,0]*r[K][0][12,0]*t[((I,9),(J,1),(K,12),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,1],p[J,1])]*r[I][1][9,0]*r[J][54][1,0]*r[K][0][12,0]*t[((I,9),(J,1),(K,12),)]
                # ({I}_{7}, {J}_{1}, {K}_{14})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[J,0],p[K,0])]*r[I][3][7,0]*r[J][24][1,0]*r[K][2][14,0]*t[((I,7),(J,1),(K,14),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[J,1],p[K,0])]*r[I][3][7,0]*r[J][54][1,0]*r[K][2][14,0]*t[((I,7),(J,1),(K,14),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,0])]*r[I][3][7,0]*r[J][24][1,0]*r[K][2][14,0]*t[((I,7),(J,1),(K,14),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,0])]*r[I][3][7,0]*r[J][9][1,0]*r[K][2][14,0]*t[((I,7),(J,1),(K,14),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,1],p[J,1])]*r[I][3][7,0]*r[J][54][1,0]*r[K][2][14,0]*t[((I,7),(J,1),(K,14),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,1],p[J,1])]*r[I][3][7,0]*r[J][39][1,0]*r[K][2][14,0]*t[((I,7),(J,1),(K,14),)]
                # ({I}_{9}, {J}_{2}, {K}_{12})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[J,1],p[K,0])]*r[I][1][9,0]*r[J][15][2,0]*r[K][0][12,0]*t[((I,9),(J,2),(K,12),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[J,0],p[K,0])]*r[I][1][9,0]*r[J][33][2,0]*r[K][0][12,0]*t[((I,9),(J,2),(K,12),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][15][2,0]*r[K][0][12,0]*t[((I,9),(J,2),(K,12),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][33][2,0]*r[K][0][12,0]*t[((I,9),(J,2),(K,12),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][30][2,0]*r[K][0][12,0]*t[((I,9),(J,2),(K,12),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][48][2,0]*r[K][0][12,0]*t[((I,9),(J,2),(K,12),)]
                # ({I}_{9}, {J}_{3}, {K}_{12})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[J,1],p[K,0])]*r[I][1][9,0]*r[J][15][3,0]*r[K][0][12,0]*t[((I,9),(J,3),(K,12),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[J,0],p[K,0])]*r[I][1][9,0]*r[J][33][3,0]*r[K][0][12,0]*t[((I,9),(J,3),(K,12),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][15][3,0]*r[K][0][12,0]*t[((I,9),(J,3),(K,12),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][33][3,0]*r[K][0][12,0]*t[((I,9),(J,3),(K,12),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][30][3,0]*r[K][0][12,0]*t[((I,9),(J,3),(K,12),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][48][3,0]*r[K][0][12,0]*t[((I,9),(J,3),(K,12),)]
                # ({I}_{7}, {J}_{2}, {K}_{14})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[J,1],p[K,0])]*r[I][3][7,0]*r[J][30][2,0]*r[K][2][14,0]*t[((I,7),(J,2),(K,14),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[J,0],p[K,0])]*r[I][3][7,0]*r[J][48][2,0]*r[K][2][14,0]*t[((I,7),(J,2),(K,14),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][3][7,0]*r[J][30][2,0]*r[K][2][14,0]*t[((I,7),(J,2),(K,14),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][3][7,0]*r[J][15][2,0]*r[K][2][14,0]*t[((I,7),(J,2),(K,14),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][3][7,0]*r[J][48][2,0]*r[K][2][14,0]*t[((I,7),(J,2),(K,14),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][3][7,0]*r[J][33][2,0]*r[K][2][14,0]*t[((I,7),(J,2),(K,14),)]
                # ({I}_{7}, {J}_{3}, {K}_{14})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[J,1],p[K,0])]*r[I][3][7,0]*r[J][30][3,0]*r[K][2][14,0]*t[((I,7),(J,3),(K,14),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[J,0],p[K,0])]*r[I][3][7,0]*r[J][48][3,0]*r[K][2][14,0]*t[((I,7),(J,3),(K,14),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][3][7,0]*r[J][30][3,0]*r[K][2][14,0]*t[((I,7),(J,3),(K,14),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][3][7,0]*r[J][15][3,0]*r[K][2][14,0]*t[((I,7),(J,3),(K,14),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][3][7,0]*r[J][48][3,0]*r[K][2][14,0]*t[((I,7),(J,3),(K,14),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,0],p[J,1])]*r[I][3][7,0]*r[J][33][3,0]*r[K][2][14,0]*t[((I,7),(J,3),(K,14),)]
                # ({I}_{9}, {J}_{4}, {K}_{14})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[J,1],p[K,0])]*r[I][1][9,0]*r[J][18][4,0]*r[K][2][14,0]*t[((I,9),(J,4),(K,14),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[J,0],p[K,0])]*r[I][1][9,0]*r[J][36][4,0]*r[K][2][14,0]*t[((I,9),(J,4),(K,14),)]
                # ({I}_{10}, {J}_{1}, {K}_{12})
                tu += 1/6*g[dei(p[I,1],p[J,0],p[J,0],p[K,0])]*r[I][5][10,0]*r[J][9][1,0]*r[K][0][12,0]*t[((I,10),(J,1),(K,12),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[J,1],p[K,0])]*r[I][5][10,0]*r[J][39][1,0]*r[K][0][12,0]*t[((I,10),(J,1),(K,12),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,0])]*r[I][5][10,0]*r[J][9][1,0]*r[K][0][12,0]*t[((I,10),(J,1),(K,12),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,1],p[J,1])]*r[I][5][10,0]*r[J][39][1,0]*r[K][0][12,0]*t[((I,10),(J,1),(K,12),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,0])]*r[I][5][10,0]*r[J][24][1,0]*r[K][0][12,0]*t[((I,10),(J,1),(K,12),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,1],p[J,1])]*r[I][5][10,0]*r[J][54][1,0]*r[K][0][12,0]*t[((I,10),(J,1),(K,12),)]
                # ({I}_{8}, {J}_{1}, {K}_{14})
                tu += 1/6*g[dei(p[I,1],p[J,0],p[J,0],p[K,0])]*r[I][7][8,0]*r[J][24][1,0]*r[K][2][14,0]*t[((I,8),(J,1),(K,14),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[J,1],p[K,0])]*r[I][7][8,0]*r[J][54][1,0]*r[K][2][14,0]*t[((I,8),(J,1),(K,14),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,0])]*r[I][7][8,0]*r[J][24][1,0]*r[K][2][14,0]*t[((I,8),(J,1),(K,14),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,0])]*r[I][7][8,0]*r[J][9][1,0]*r[K][2][14,0]*t[((I,8),(J,1),(K,14),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,1],p[J,1])]*r[I][7][8,0]*r[J][54][1,0]*r[K][2][14,0]*t[((I,8),(J,1),(K,14),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,1],p[J,1])]*r[I][7][8,0]*r[J][39][1,0]*r[K][2][14,0]*t[((I,8),(J,1),(K,14),)]
                # ({I}_{10}, {J}_{2}, {K}_{12})
                tu += 1/6*g[dei(p[I,1],p[J,0],p[J,1],p[K,0])]*r[I][5][10,0]*r[J][15][2,0]*r[K][0][12,0]*t[((I,10),(J,2),(K,12),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[J,0],p[K,0])]*r[I][5][10,0]*r[J][33][2,0]*r[K][0][12,0]*t[((I,10),(J,2),(K,12),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][15][2,0]*r[K][0][12,0]*t[((I,10),(J,2),(K,12),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][33][2,0]*r[K][0][12,0]*t[((I,10),(J,2),(K,12),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][30][2,0]*r[K][0][12,0]*t[((I,10),(J,2),(K,12),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][48][2,0]*r[K][0][12,0]*t[((I,10),(J,2),(K,12),)]
                # ({I}_{10}, {J}_{3}, {K}_{12})
                tu += 1/6*g[dei(p[I,1],p[J,0],p[J,1],p[K,0])]*r[I][5][10,0]*r[J][15][3,0]*r[K][0][12,0]*t[((I,10),(J,3),(K,12),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[J,0],p[K,0])]*r[I][5][10,0]*r[J][33][3,0]*r[K][0][12,0]*t[((I,10),(J,3),(K,12),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][15][3,0]*r[K][0][12,0]*t[((I,10),(J,3),(K,12),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][33][3,0]*r[K][0][12,0]*t[((I,10),(J,3),(K,12),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][30][3,0]*r[K][0][12,0]*t[((I,10),(J,3),(K,12),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][48][3,0]*r[K][0][12,0]*t[((I,10),(J,3),(K,12),)]
                # ({I}_{8}, {J}_{2}, {K}_{14})
                tu += 1/6*g[dei(p[I,1],p[J,0],p[J,1],p[K,0])]*r[I][7][8,0]*r[J][30][2,0]*r[K][2][14,0]*t[((I,8),(J,2),(K,14),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[J,0],p[K,0])]*r[I][7][8,0]*r[J][48][2,0]*r[K][2][14,0]*t[((I,8),(J,2),(K,14),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][7][8,0]*r[J][30][2,0]*r[K][2][14,0]*t[((I,8),(J,2),(K,14),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][7][8,0]*r[J][15][2,0]*r[K][2][14,0]*t[((I,8),(J,2),(K,14),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][7][8,0]*r[J][48][2,0]*r[K][2][14,0]*t[((I,8),(J,2),(K,14),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][7][8,0]*r[J][33][2,0]*r[K][2][14,0]*t[((I,8),(J,2),(K,14),)]
                # ({I}_{8}, {J}_{3}, {K}_{14})
                tu += 1/6*g[dei(p[I,1],p[J,0],p[J,1],p[K,0])]*r[I][7][8,0]*r[J][30][3,0]*r[K][2][14,0]*t[((I,8),(J,3),(K,14),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[J,0],p[K,0])]*r[I][7][8,0]*r[J][48][3,0]*r[K][2][14,0]*t[((I,8),(J,3),(K,14),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][7][8,0]*r[J][30][3,0]*r[K][2][14,0]*t[((I,8),(J,3),(K,14),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][7][8,0]*r[J][15][3,0]*r[K][2][14,0]*t[((I,8),(J,3),(K,14),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][7][8,0]*r[J][48][3,0]*r[K][2][14,0]*t[((I,8),(J,3),(K,14),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,0],p[J,1])]*r[I][7][8,0]*r[J][33][3,0]*r[K][2][14,0]*t[((I,8),(J,3),(K,14),)]
                # ({I}_{10}, {J}_{4}, {K}_{14})
                tu += 1/6*g[dei(p[I,1],p[J,0],p[J,1],p[K,0])]*r[I][5][10,0]*r[J][18][4,0]*r[K][2][14,0]*t[((I,10),(J,4),(K,14),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[J,0],p[K,0])]*r[I][5][10,0]*r[J][36][4,0]*r[K][2][14,0]*t[((I,10),(J,4),(K,14),)]
                # ({I}_{9}, {J}_{1}, {K}_{11})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[J,0],p[K,1])]*r[I][1][9,0]*r[J][9][1,0]*r[K][4][11,0]*t[((I,9),(J,1),(K,11),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[J,1],p[K,1])]*r[I][1][9,0]*r[J][39][1,0]*r[K][4][11,0]*t[((I,9),(J,1),(K,11),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,0])]*r[I][1][9,0]*r[J][9][1,0]*r[K][4][11,0]*t[((I,9),(J,1),(K,11),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,1],p[J,1])]*r[I][1][9,0]*r[J][39][1,0]*r[K][4][11,0]*t[((I,9),(J,1),(K,11),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,0])]*r[I][1][9,0]*r[J][24][1,0]*r[K][4][11,0]*t[((I,9),(J,1),(K,11),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,1],p[J,1])]*r[I][1][9,0]*r[J][54][1,0]*r[K][4][11,0]*t[((I,9),(J,1),(K,11),)]
                # ({I}_{7}, {J}_{1}, {K}_{13})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[J,0],p[K,1])]*r[I][3][7,0]*r[J][24][1,0]*r[K][6][13,0]*t[((I,7),(J,1),(K,13),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[J,1],p[K,1])]*r[I][3][7,0]*r[J][54][1,0]*r[K][6][13,0]*t[((I,7),(J,1),(K,13),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,0])]*r[I][3][7,0]*r[J][24][1,0]*r[K][6][13,0]*t[((I,7),(J,1),(K,13),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,0])]*r[I][3][7,0]*r[J][9][1,0]*r[K][6][13,0]*t[((I,7),(J,1),(K,13),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,1],p[J,1])]*r[I][3][7,0]*r[J][54][1,0]*r[K][6][13,0]*t[((I,7),(J,1),(K,13),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,1],p[J,1])]*r[I][3][7,0]*r[J][39][1,0]*r[K][6][13,0]*t[((I,7),(J,1),(K,13),)]
                # ({I}_{9}, {J}_{2}, {K}_{11})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[J,1],p[K,1])]*r[I][1][9,0]*r[J][15][2,0]*r[K][4][11,0]*t[((I,9),(J,2),(K,11),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[J,0],p[K,1])]*r[I][1][9,0]*r[J][33][2,0]*r[K][4][11,0]*t[((I,9),(J,2),(K,11),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][15][2,0]*r[K][4][11,0]*t[((I,9),(J,2),(K,11),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][33][2,0]*r[K][4][11,0]*t[((I,9),(J,2),(K,11),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][30][2,0]*r[K][4][11,0]*t[((I,9),(J,2),(K,11),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][48][2,0]*r[K][4][11,0]*t[((I,9),(J,2),(K,11),)]
                # ({I}_{9}, {J}_{3}, {K}_{11})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[J,1],p[K,1])]*r[I][1][9,0]*r[J][15][3,0]*r[K][4][11,0]*t[((I,9),(J,3),(K,11),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[J,0],p[K,1])]*r[I][1][9,0]*r[J][33][3,0]*r[K][4][11,0]*t[((I,9),(J,3),(K,11),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][15][3,0]*r[K][4][11,0]*t[((I,9),(J,3),(K,11),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][33][3,0]*r[K][4][11,0]*t[((I,9),(J,3),(K,11),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][30][3,0]*r[K][4][11,0]*t[((I,9),(J,3),(K,11),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][1][9,0]*r[J][48][3,0]*r[K][4][11,0]*t[((I,9),(J,3),(K,11),)]
                # ({I}_{7}, {J}_{2}, {K}_{13})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[J,1],p[K,1])]*r[I][3][7,0]*r[J][30][2,0]*r[K][6][13,0]*t[((I,7),(J,2),(K,13),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[J,0],p[K,1])]*r[I][3][7,0]*r[J][48][2,0]*r[K][6][13,0]*t[((I,7),(J,2),(K,13),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][3][7,0]*r[J][30][2,0]*r[K][6][13,0]*t[((I,7),(J,2),(K,13),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][3][7,0]*r[J][15][2,0]*r[K][6][13,0]*t[((I,7),(J,2),(K,13),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][3][7,0]*r[J][48][2,0]*r[K][6][13,0]*t[((I,7),(J,2),(K,13),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][3][7,0]*r[J][33][2,0]*r[K][6][13,0]*t[((I,7),(J,2),(K,13),)]
                # ({I}_{7}, {J}_{3}, {K}_{13})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[J,1],p[K,1])]*r[I][3][7,0]*r[J][30][3,0]*r[K][6][13,0]*t[((I,7),(J,3),(K,13),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[J,0],p[K,1])]*r[I][3][7,0]*r[J][48][3,0]*r[K][6][13,0]*t[((I,7),(J,3),(K,13),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][3][7,0]*r[J][30][3,0]*r[K][6][13,0]*t[((I,7),(J,3),(K,13),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][3][7,0]*r[J][15][3,0]*r[K][6][13,0]*t[((I,7),(J,3),(K,13),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][3][7,0]*r[J][48][3,0]*r[K][6][13,0]*t[((I,7),(J,3),(K,13),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,0],p[J,1])]*r[I][3][7,0]*r[J][33][3,0]*r[K][6][13,0]*t[((I,7),(J,3),(K,13),)]
                # ({I}_{9}, {J}_{4}, {K}_{13})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[J,1],p[K,1])]*r[I][1][9,0]*r[J][18][4,0]*r[K][6][13,0]*t[((I,9),(J,4),(K,13),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[J,0],p[K,1])]*r[I][1][9,0]*r[J][36][4,0]*r[K][6][13,0]*t[((I,9),(J,4),(K,13),)]
                # ({I}_{10}, {J}_{1}, {K}_{11})
                tu += 1/6*g[dei(p[I,1],p[J,0],p[J,0],p[K,1])]*r[I][5][10,0]*r[J][9][1,0]*r[K][4][11,0]*t[((I,10),(J,1),(K,11),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[J,1],p[K,1])]*r[I][5][10,0]*r[J][39][1,0]*r[K][4][11,0]*t[((I,10),(J,1),(K,11),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,0])]*r[I][5][10,0]*r[J][9][1,0]*r[K][4][11,0]*t[((I,10),(J,1),(K,11),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,1],p[J,1])]*r[I][5][10,0]*r[J][39][1,0]*r[K][4][11,0]*t[((I,10),(J,1),(K,11),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,0])]*r[I][5][10,0]*r[J][24][1,0]*r[K][4][11,0]*t[((I,10),(J,1),(K,11),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,1],p[J,1])]*r[I][5][10,0]*r[J][54][1,0]*r[K][4][11,0]*t[((I,10),(J,1),(K,11),)]
                # ({I}_{8}, {J}_{1}, {K}_{13})
                tu += 1/6*g[dei(p[I,1],p[J,0],p[J,0],p[K,1])]*r[I][7][8,0]*r[J][24][1,0]*r[K][6][13,0]*t[((I,8),(J,1),(K,13),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[J,1],p[K,1])]*r[I][7][8,0]*r[J][54][1,0]*r[K][6][13,0]*t[((I,8),(J,1),(K,13),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,0])]*r[I][7][8,0]*r[J][24][1,0]*r[K][6][13,0]*t[((I,8),(J,1),(K,13),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,0])]*r[I][7][8,0]*r[J][9][1,0]*r[K][6][13,0]*t[((I,8),(J,1),(K,13),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,1],p[J,1])]*r[I][7][8,0]*r[J][54][1,0]*r[K][6][13,0]*t[((I,8),(J,1),(K,13),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,1],p[J,1])]*r[I][7][8,0]*r[J][39][1,0]*r[K][6][13,0]*t[((I,8),(J,1),(K,13),)]
                # ({I}_{10}, {J}_{2}, {K}_{11})
                tu += 1/6*g[dei(p[I,1],p[J,0],p[J,1],p[K,1])]*r[I][5][10,0]*r[J][15][2,0]*r[K][4][11,0]*t[((I,10),(J,2),(K,11),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[J,0],p[K,1])]*r[I][5][10,0]*r[J][33][2,0]*r[K][4][11,0]*t[((I,10),(J,2),(K,11),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][15][2,0]*r[K][4][11,0]*t[((I,10),(J,2),(K,11),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][33][2,0]*r[K][4][11,0]*t[((I,10),(J,2),(K,11),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][30][2,0]*r[K][4][11,0]*t[((I,10),(J,2),(K,11),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][48][2,0]*r[K][4][11,0]*t[((I,10),(J,2),(K,11),)]
                # ({I}_{10}, {J}_{3}, {K}_{11})
                tu += 1/6*g[dei(p[I,1],p[J,0],p[J,1],p[K,1])]*r[I][5][10,0]*r[J][15][3,0]*r[K][4][11,0]*t[((I,10),(J,3),(K,11),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[J,0],p[K,1])]*r[I][5][10,0]*r[J][33][3,0]*r[K][4][11,0]*t[((I,10),(J,3),(K,11),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][15][3,0]*r[K][4][11,0]*t[((I,10),(J,3),(K,11),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][33][3,0]*r[K][4][11,0]*t[((I,10),(J,3),(K,11),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][30][3,0]*r[K][4][11,0]*t[((I,10),(J,3),(K,11),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][5][10,0]*r[J][48][3,0]*r[K][4][11,0]*t[((I,10),(J,3),(K,11),)]
                # ({I}_{8}, {J}_{2}, {K}_{13})
                tu += 1/6*g[dei(p[I,1],p[J,0],p[J,1],p[K,1])]*r[I][7][8,0]*r[J][30][2,0]*r[K][6][13,0]*t[((I,8),(J,2),(K,13),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[J,0],p[K,1])]*r[I][7][8,0]*r[J][48][2,0]*r[K][6][13,0]*t[((I,8),(J,2),(K,13),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][7][8,0]*r[J][30][2,0]*r[K][6][13,0]*t[((I,8),(J,2),(K,13),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][7][8,0]*r[J][15][2,0]*r[K][6][13,0]*t[((I,8),(J,2),(K,13),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][7][8,0]*r[J][48][2,0]*r[K][6][13,0]*t[((I,8),(J,2),(K,13),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][7][8,0]*r[J][33][2,0]*r[K][6][13,0]*t[((I,8),(J,2),(K,13),)]
                # ({I}_{8}, {J}_{3}, {K}_{13})
                tu += 1/6*g[dei(p[I,1],p[J,0],p[J,1],p[K,1])]*r[I][7][8,0]*r[J][30][3,0]*r[K][6][13,0]*t[((I,8),(J,3),(K,13),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[J,0],p[K,1])]*r[I][7][8,0]*r[J][48][3,0]*r[K][6][13,0]*t[((I,8),(J,3),(K,13),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][7][8,0]*r[J][30][3,0]*r[K][6][13,0]*t[((I,8),(J,3),(K,13),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][7][8,0]*r[J][15][3,0]*r[K][6][13,0]*t[((I,8),(J,3),(K,13),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][7][8,0]*r[J][48][3,0]*r[K][6][13,0]*t[((I,8),(J,3),(K,13),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,0],p[J,1])]*r[I][7][8,0]*r[J][33][3,0]*r[K][6][13,0]*t[((I,8),(J,3),(K,13),)]
                # ({I}_{10}, {J}_{4}, {K}_{13})
                tu += 1/6*g[dei(p[I,1],p[J,0],p[J,1],p[K,1])]*r[I][5][10,0]*r[J][18][4,0]*r[K][6][13,0]*t[((I,10),(J,4),(K,13),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[J,0],p[K,1])]*r[I][5][10,0]*r[J][36][4,0]*r[K][6][13,0]*t[((I,10),(J,4),(K,13),)]
                # ({I}_{9}, {J}_{12}, {K}_{1})
                tu += -1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][9][1,0]*t[((I,9),(J,12),(K,1),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][24][1,0]*t[((I,9),(J,12),(K,1),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[K,1],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][39][1,0]*t[((I,9),(J,12),(K,1),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[K,1],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][54][1,0]*t[((I,9),(J,12),(K,1),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[K,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][9][1,0]*t[((I,9),(J,12),(K,1),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][39][1,0]*t[((I,9),(J,12),(K,1),)]
                # ({I}_{7}, {J}_{14}, {K}_{1})
                tu += -1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][24][1,0]*t[((I,7),(J,14),(K,1),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[K,1],p[K,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][54][1,0]*t[((I,7),(J,14),(K,1),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[K,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][24][1,0]*t[((I,7),(J,14),(K,1),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[K,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][54][1,0]*t[((I,7),(J,14),(K,1),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][9][1,0]*t[((I,7),(J,14),(K,1),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[K,1],p[K,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][39][1,0]*t[((I,7),(J,14),(K,1),)]
                # ({I}_{9}, {J}_{12}, {K}_{2})
                tu += -1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][15][2,0]*t[((I,9),(J,12),(K,2),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][30][2,0]*t[((I,9),(J,12),(K,2),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][33][2,0]*t[((I,9),(J,12),(K,2),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][48][2,0]*t[((I,9),(J,12),(K,2),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][15][2,0]*t[((I,9),(J,12),(K,2),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[K,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][33][2,0]*t[((I,9),(J,12),(K,2),)]
                # ({I}_{9}, {J}_{12}, {K}_{3})
                tu += -1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][15][3,0]*t[((I,9),(J,12),(K,3),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][30][3,0]*t[((I,9),(J,12),(K,3),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][33][3,0]*t[((I,9),(J,12),(K,3),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][48][3,0]*t[((I,9),(J,12),(K,3),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][15][3,0]*t[((I,9),(J,12),(K,3),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[K,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][33][3,0]*t[((I,9),(J,12),(K,3),)]
                # ({I}_{7}, {J}_{14}, {K}_{2})
                tu += -1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][30][2,0]*t[((I,7),(J,14),(K,2),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][48][2,0]*t[((I,7),(J,14),(K,2),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[K,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][30][2,0]*t[((I,7),(J,14),(K,2),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[K,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][48][2,0]*t[((I,7),(J,14),(K,2),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][15][2,0]*t[((I,7),(J,14),(K,2),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][33][2,0]*t[((I,7),(J,14),(K,2),)]
                # ({I}_{7}, {J}_{14}, {K}_{3})
                tu += -1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][30][3,0]*t[((I,7),(J,14),(K,3),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][48][3,0]*t[((I,7),(J,14),(K,3),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[K,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][30][3,0]*t[((I,7),(J,14),(K,3),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[K,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][48][3,0]*t[((I,7),(J,14),(K,3),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][15][3,0]*t[((I,7),(J,14),(K,3),)]
                tu += -1/6*g[dei(p[I,0],p[J,0],p[K,0],p[K,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][33][3,0]*t[((I,7),(J,14),(K,3),)]
                # ({I}_{10}, {J}_{12}, {K}_{1})
                tu += -1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][9][1,0]*t[((I,10),(J,12),(K,1),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][24][1,0]*t[((I,10),(J,12),(K,1),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[K,1],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][39][1,0]*t[((I,10),(J,12),(K,1),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[K,1],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][54][1,0]*t[((I,10),(J,12),(K,1),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[K,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][9][1,0]*t[((I,10),(J,12),(K,1),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][39][1,0]*t[((I,10),(J,12),(K,1),)]
                # ({I}_{8}, {J}_{14}, {K}_{1})
                tu += -1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][24][1,0]*t[((I,8),(J,14),(K,1),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[K,1],p[K,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][54][1,0]*t[((I,8),(J,14),(K,1),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[K,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][24][1,0]*t[((I,8),(J,14),(K,1),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[K,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][54][1,0]*t[((I,8),(J,14),(K,1),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][9][1,0]*t[((I,8),(J,14),(K,1),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[K,1],p[K,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][39][1,0]*t[((I,8),(J,14),(K,1),)]
                # ({I}_{10}, {J}_{12}, {K}_{2})
                tu += -1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][15][2,0]*t[((I,10),(J,12),(K,2),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][30][2,0]*t[((I,10),(J,12),(K,2),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][33][2,0]*t[((I,10),(J,12),(K,2),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][48][2,0]*t[((I,10),(J,12),(K,2),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][15][2,0]*t[((I,10),(J,12),(K,2),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[K,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][33][2,0]*t[((I,10),(J,12),(K,2),)]
                # ({I}_{10}, {J}_{12}, {K}_{3})
                tu += -1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][15][3,0]*t[((I,10),(J,12),(K,3),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][30][3,0]*t[((I,10),(J,12),(K,3),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][33][3,0]*t[((I,10),(J,12),(K,3),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][48][3,0]*t[((I,10),(J,12),(K,3),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][15][3,0]*t[((I,10),(J,12),(K,3),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[K,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][33][3,0]*t[((I,10),(J,12),(K,3),)]
                # ({I}_{8}, {J}_{14}, {K}_{2})
                tu += -1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][30][2,0]*t[((I,8),(J,14),(K,2),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][48][2,0]*t[((I,8),(J,14),(K,2),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[K,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][30][2,0]*t[((I,8),(J,14),(K,2),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[K,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][48][2,0]*t[((I,8),(J,14),(K,2),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][15][2,0]*t[((I,8),(J,14),(K,2),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][33][2,0]*t[((I,8),(J,14),(K,2),)]
                # ({I}_{8}, {J}_{14}, {K}_{3})
                tu += -1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][30][3,0]*t[((I,8),(J,14),(K,3),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][48][3,0]*t[((I,8),(J,14),(K,3),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[K,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][30][3,0]*t[((I,8),(J,14),(K,3),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[K,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][48][3,0]*t[((I,8),(J,14),(K,3),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][15][3,0]*t[((I,8),(J,14),(K,3),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[K,0],p[K,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][33][3,0]*t[((I,8),(J,14),(K,3),)]
                # ({I}_{9}, {J}_{11}, {K}_{1})
                tu += -1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][9][1,0]*t[((I,9),(J,11),(K,1),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][24][1,0]*t[((I,9),(J,11),(K,1),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[K,1],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][39][1,0]*t[((I,9),(J,11),(K,1),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[K,1],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][54][1,0]*t[((I,9),(J,11),(K,1),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,1],p[K,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][9][1,0]*t[((I,9),(J,11),(K,1),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,1],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][39][1,0]*t[((I,9),(J,11),(K,1),)]
                # ({I}_{7}, {J}_{13}, {K}_{1})
                tu += -1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][24][1,0]*t[((I,7),(J,13),(K,1),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[K,1],p[K,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][54][1,0]*t[((I,7),(J,13),(K,1),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,1],p[K,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][24][1,0]*t[((I,7),(J,13),(K,1),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,1],p[K,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][54][1,0]*t[((I,7),(J,13),(K,1),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][9][1,0]*t[((I,7),(J,13),(K,1),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[K,1],p[K,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][39][1,0]*t[((I,7),(J,13),(K,1),)]
                # ({I}_{9}, {J}_{11}, {K}_{2})
                tu += -1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][15][2,0]*t[((I,9),(J,11),(K,2),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][30][2,0]*t[((I,9),(J,11),(K,2),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][33][2,0]*t[((I,9),(J,11),(K,2),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][48][2,0]*t[((I,9),(J,11),(K,2),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,1],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][15][2,0]*t[((I,9),(J,11),(K,2),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,1],p[K,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][33][2,0]*t[((I,9),(J,11),(K,2),)]
                # ({I}_{9}, {J}_{11}, {K}_{3})
                tu += -1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][15][3,0]*t[((I,9),(J,11),(K,3),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][30][3,0]*t[((I,9),(J,11),(K,3),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][33][3,0]*t[((I,9),(J,11),(K,3),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][48][3,0]*t[((I,9),(J,11),(K,3),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,1],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][15][3,0]*t[((I,9),(J,11),(K,3),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,1],p[K,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][33][3,0]*t[((I,9),(J,11),(K,3),)]
                # ({I}_{7}, {J}_{13}, {K}_{2})
                tu += -1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][30][2,0]*t[((I,7),(J,13),(K,2),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][48][2,0]*t[((I,7),(J,13),(K,2),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,1],p[K,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][30][2,0]*t[((I,7),(J,13),(K,2),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,1],p[K,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][48][2,0]*t[((I,7),(J,13),(K,2),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][15][2,0]*t[((I,7),(J,13),(K,2),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][33][2,0]*t[((I,7),(J,13),(K,2),)]
                # ({I}_{7}, {J}_{13}, {K}_{3})
                tu += -1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][30][3,0]*t[((I,7),(J,13),(K,3),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][48][3,0]*t[((I,7),(J,13),(K,3),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,1],p[K,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][30][3,0]*t[((I,7),(J,13),(K,3),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,1],p[K,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][48][3,0]*t[((I,7),(J,13),(K,3),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][15][3,0]*t[((I,7),(J,13),(K,3),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[K,0],p[K,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][33][3,0]*t[((I,7),(J,13),(K,3),)]
                # ({I}_{10}, {J}_{11}, {K}_{1})
                tu += -1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][9][1,0]*t[((I,10),(J,11),(K,1),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][24][1,0]*t[((I,10),(J,11),(K,1),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[K,1],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][39][1,0]*t[((I,10),(J,11),(K,1),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[K,1],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][54][1,0]*t[((I,10),(J,11),(K,1),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,1],p[K,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][9][1,0]*t[((I,10),(J,11),(K,1),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,1],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][39][1,0]*t[((I,10),(J,11),(K,1),)]
                # ({I}_{8}, {J}_{13}, {K}_{1})
                tu += -1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][24][1,0]*t[((I,8),(J,13),(K,1),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[K,1],p[K,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][54][1,0]*t[((I,8),(J,13),(K,1),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,1],p[K,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][24][1,0]*t[((I,8),(J,13),(K,1),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,1],p[K,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][54][1,0]*t[((I,8),(J,13),(K,1),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][9][1,0]*t[((I,8),(J,13),(K,1),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[K,1],p[K,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][39][1,0]*t[((I,8),(J,13),(K,1),)]
                # ({I}_{10}, {J}_{11}, {K}_{2})
                tu += -1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][15][2,0]*t[((I,10),(J,11),(K,2),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][30][2,0]*t[((I,10),(J,11),(K,2),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][33][2,0]*t[((I,10),(J,11),(K,2),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][48][2,0]*t[((I,10),(J,11),(K,2),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,1],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][15][2,0]*t[((I,10),(J,11),(K,2),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,1],p[K,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][33][2,0]*t[((I,10),(J,11),(K,2),)]
                # ({I}_{10}, {J}_{11}, {K}_{3})
                tu += -1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][15][3,0]*t[((I,10),(J,11),(K,3),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][30][3,0]*t[((I,10),(J,11),(K,3),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][33][3,0]*t[((I,10),(J,11),(K,3),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][48][3,0]*t[((I,10),(J,11),(K,3),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,1],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][15][3,0]*t[((I,10),(J,11),(K,3),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,1],p[K,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][33][3,0]*t[((I,10),(J,11),(K,3),)]
                # ({I}_{8}, {J}_{13}, {K}_{2})
                tu += -1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][30][2,0]*t[((I,8),(J,13),(K,2),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][48][2,0]*t[((I,8),(J,13),(K,2),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,1],p[K,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][30][2,0]*t[((I,8),(J,13),(K,2),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,1],p[K,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][48][2,0]*t[((I,8),(J,13),(K,2),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][15][2,0]*t[((I,8),(J,13),(K,2),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][33][2,0]*t[((I,8),(J,13),(K,2),)]
                # ({I}_{8}, {J}_{13}, {K}_{3})
                tu += -1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][30][3,0]*t[((I,8),(J,13),(K,3),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][48][3,0]*t[((I,8),(J,13),(K,3),)]
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,1],p[K,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][30][3,0]*t[((I,8),(J,13),(K,3),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,1],p[K,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][48][3,0]*t[((I,8),(J,13),(K,3),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][15][3,0]*t[((I,8),(J,13),(K,3),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[K,0],p[K,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][33][3,0]*t[((I,8),(J,13),(K,3),)]
                # ({I}_{7}, {J}_{12}, {K}_{5})
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[K,1])]*r[I][3][7,0]*r[J][0][12,0]*r[K][27][5,0]*t[((I,7),(J,12),(K,5),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[K,0])]*r[I][3][7,0]*r[J][0][12,0]*r[K][45][5,0]*t[((I,7),(J,12),(K,5),)]
                # ({I}_{8}, {J}_{12}, {K}_{5})
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[K,1])]*r[I][7][8,0]*r[J][0][12,0]*r[K][27][5,0]*t[((I,8),(J,12),(K,5),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[K,0])]*r[I][7][8,0]*r[J][0][12,0]*r[K][45][5,0]*t[((I,8),(J,12),(K,5),)]
                # ({I}_{7}, {J}_{11}, {K}_{5})
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,1],p[K,1])]*r[I][3][7,0]*r[J][4][11,0]*r[K][27][5,0]*t[((I,7),(J,11),(K,5),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,1],p[K,0])]*r[I][3][7,0]*r[J][4][11,0]*r[K][45][5,0]*t[((I,7),(J,11),(K,5),)]
                # ({I}_{8}, {J}_{11}, {K}_{5})
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,1],p[K,1])]*r[I][7][8,0]*r[J][4][11,0]*r[K][27][5,0]*t[((I,8),(J,11),(K,5),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,1],p[K,0])]*r[I][7][8,0]*r[J][4][11,0]*r[K][45][5,0]*t[((I,8),(J,11),(K,5),)]
                # ({I}_{5}, {J}_{7}, {K}_{12})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[I,1],p[K,0])]*r[I][27][5,0]*r[J][3][7,0]*r[K][0][12,0]*t[((I,5),(J,7),(K,12),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[I,1],p[J,0])]*r[I][45][5,0]*r[J][3][7,0]*r[K][0][12,0]*t[((I,5),(J,7),(K,12),)]
                # ({I}_{5}, {J}_{8}, {K}_{12})
                tu += 1/6*g[dei(p[I,0],p[J,1],p[I,1],p[K,0])]*r[I][27][5,0]*r[J][7][8,0]*r[K][0][12,0]*t[((I,5),(J,8),(K,12),)]
                tu += 1/6*g[dei(p[I,0],p[K,0],p[I,1],p[J,1])]*r[I][45][5,0]*r[J][7][8,0]*r[K][0][12,0]*t[((I,5),(J,8),(K,12),)]
                # ({I}_{5}, {J}_{7}, {K}_{11})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[I,1],p[K,1])]*r[I][27][5,0]*r[J][3][7,0]*r[K][4][11,0]*t[((I,5),(J,7),(K,11),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[I,1],p[J,0])]*r[I][45][5,0]*r[J][3][7,0]*r[K][4][11,0]*t[((I,5),(J,7),(K,11),)]
                # ({I}_{5}, {J}_{8}, {K}_{11})
                tu += 1/6*g[dei(p[I,0],p[J,1],p[I,1],p[K,1])]*r[I][27][5,0]*r[J][7][8,0]*r[K][4][11,0]*t[((I,5),(J,8),(K,11),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[I,1],p[J,1])]*r[I][45][5,0]*r[J][7][8,0]*r[K][4][11,0]*t[((I,5),(J,8),(K,11),)]
                # ({I}_{14}, {J}_{6}, {K}_{12})
                tu += -1/6*g[dei(p[I,0],p[J,0],p[J,0],p[K,0])]*r[I][2][14,0]*r[J][22][6,0]*r[K][0][12,0]*t[((I,14),(J,6),(K,12),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[J,1],p[K,0])]*r[I][2][14,0]*r[J][52][6,0]*r[K][0][12,0]*t[((I,14),(J,6),(K,12),)]
                # ({I}_{13}, {J}_{6}, {K}_{12})
                tu += -1/6*g[dei(p[I,1],p[J,0],p[J,0],p[K,0])]*r[I][6][13,0]*r[J][22][6,0]*r[K][0][12,0]*t[((I,13),(J,6),(K,12),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[J,1],p[K,0])]*r[I][6][13,0]*r[J][52][6,0]*r[K][0][12,0]*t[((I,13),(J,6),(K,12),)]
                # ({I}_{14}, {J}_{6}, {K}_{11})
                tu += -1/6*g[dei(p[I,0],p[J,0],p[J,0],p[K,1])]*r[I][2][14,0]*r[J][22][6,0]*r[K][4][11,0]*t[((I,14),(J,6),(K,11),)]
                tu += -1/6*g[dei(p[I,0],p[J,1],p[J,1],p[K,1])]*r[I][2][14,0]*r[J][52][6,0]*r[K][4][11,0]*t[((I,14),(J,6),(K,11),)]
                # ({I}_{13}, {J}_{6}, {K}_{11})
                tu += -1/6*g[dei(p[I,1],p[J,0],p[J,0],p[K,1])]*r[I][6][13,0]*r[J][22][6,0]*r[K][4][11,0]*t[((I,13),(J,6),(K,11),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[J,1],p[K,1])]*r[I][6][13,0]*r[J][52][6,0]*r[K][4][11,0]*t[((I,13),(J,6),(K,11),)]
                # ({I}_{14}, {J}_{9}, {K}_{4})
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,0],p[K,0])]*r[I][2][14,0]*r[J][1][9,0]*r[K][18][4,0]*t[((I,14),(J,9),(K,4),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,0],p[K,1])]*r[I][2][14,0]*r[J][1][9,0]*r[K][36][4,0]*t[((I,14),(J,9),(K,4),)]
                # ({I}_{14}, {J}_{10}, {K}_{4})
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,1],p[K,0])]*r[I][2][14,0]*r[J][5][10,0]*r[K][18][4,0]*t[((I,14),(J,10),(K,4),)]
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,1],p[K,1])]*r[I][2][14,0]*r[J][5][10,0]*r[K][36][4,0]*t[((I,14),(J,10),(K,4),)]
                # ({I}_{13}, {J}_{9}, {K}_{4})
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,0],p[K,0])]*r[I][6][13,0]*r[J][1][9,0]*r[K][18][4,0]*t[((I,13),(J,9),(K,4),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,0],p[K,1])]*r[I][6][13,0]*r[J][1][9,0]*r[K][36][4,0]*t[((I,13),(J,9),(K,4),)]
                # ({I}_{13}, {J}_{10}, {K}_{4})
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,1],p[K,0])]*r[I][6][13,0]*r[J][5][10,0]*r[K][18][4,0]*t[((I,13),(J,10),(K,4),)]
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,1],p[K,1])]*r[I][6][13,0]*r[J][5][10,0]*r[K][36][4,0]*t[((I,13),(J,10),(K,4),)]
                # ({I}_{6}, {J}_{14}, {K}_{12})
                tu += -1/6*g[dei(p[I,0],p[J,0],p[I,0],p[K,0])]*r[I][22][6,0]*r[J][2][14,0]*r[K][0][12,0]*t[((I,6),(J,14),(K,12),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[I,1],p[K,0])]*r[I][52][6,0]*r[J][2][14,0]*r[K][0][12,0]*t[((I,6),(J,14),(K,12),)]
                # ({I}_{6}, {J}_{13}, {K}_{12})
                tu += -1/6*g[dei(p[I,0],p[J,1],p[I,0],p[K,0])]*r[I][22][6,0]*r[J][6][13,0]*r[K][0][12,0]*t[((I,6),(J,13),(K,12),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[I,1],p[K,0])]*r[I][52][6,0]*r[J][6][13,0]*r[K][0][12,0]*t[((I,6),(J,13),(K,12),)]
                # ({I}_{6}, {J}_{14}, {K}_{11})
                tu += -1/6*g[dei(p[I,0],p[J,0],p[I,0],p[K,1])]*r[I][22][6,0]*r[J][2][14,0]*r[K][4][11,0]*t[((I,6),(J,14),(K,11),)]
                tu += -1/6*g[dei(p[I,1],p[J,0],p[I,1],p[K,1])]*r[I][52][6,0]*r[J][2][14,0]*r[K][4][11,0]*t[((I,6),(J,14),(K,11),)]
                # ({I}_{6}, {J}_{13}, {K}_{11})
                tu += -1/6*g[dei(p[I,0],p[J,1],p[I,0],p[K,1])]*r[I][22][6,0]*r[J][6][13,0]*r[K][4][11,0]*t[((I,6),(J,13),(K,11),)]
                tu += -1/6*g[dei(p[I,1],p[J,1],p[I,1],p[K,1])]*r[I][52][6,0]*r[J][6][13,0]*r[K][4][11,0]*t[((I,6),(J,13),(K,11),)]
                # ({I}_{9}, {J}_{14}, {K}_{4})
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[K,1])]*r[I][1][9,0]*r[J][2][14,0]*r[K][18][4,0]*t[((I,9),(J,14),(K,4),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[K,0])]*r[I][1][9,0]*r[J][2][14,0]*r[K][36][4,0]*t[((I,9),(J,14),(K,4),)]
                # ({I}_{10}, {J}_{14}, {K}_{4})
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[K,1])]*r[I][5][10,0]*r[J][2][14,0]*r[K][18][4,0]*t[((I,10),(J,14),(K,4),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[K,0])]*r[I][5][10,0]*r[J][2][14,0]*r[K][36][4,0]*t[((I,10),(J,14),(K,4),)]
                # ({I}_{9}, {J}_{13}, {K}_{4})
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,1],p[K,1])]*r[I][1][9,0]*r[J][6][13,0]*r[K][18][4,0]*t[((I,9),(J,13),(K,4),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,1],p[K,0])]*r[I][1][9,0]*r[J][6][13,0]*r[K][36][4,0]*t[((I,9),(J,13),(K,4),)]
                # ({I}_{10}, {J}_{13}, {K}_{4})
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,1],p[K,1])]*r[I][5][10,0]*r[J][6][13,0]*r[K][18][4,0]*t[((I,10),(J,13),(K,4),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,1],p[K,0])]*r[I][5][10,0]*r[J][6][13,0]*r[K][36][4,0]*t[((I,10),(J,13),(K,4),)]
                # ({I}_{7}, {J}_{5}, {K}_{12})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[J,1],p[K,0])]*r[I][3][7,0]*r[J][27][5,0]*r[K][0][12,0]*t[((I,7),(J,5),(K,12),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[J,0],p[K,0])]*r[I][3][7,0]*r[J][45][5,0]*r[K][0][12,0]*t[((I,7),(J,5),(K,12),)]
                # ({I}_{8}, {J}_{5}, {K}_{12})
                tu += 1/6*g[dei(p[I,1],p[J,0],p[J,1],p[K,0])]*r[I][7][8,0]*r[J][27][5,0]*r[K][0][12,0]*t[((I,8),(J,5),(K,12),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[J,0],p[K,0])]*r[I][7][8,0]*r[J][45][5,0]*r[K][0][12,0]*t[((I,8),(J,5),(K,12),)]
                # ({I}_{7}, {J}_{5}, {K}_{11})
                tu += 1/6*g[dei(p[I,0],p[J,0],p[J,1],p[K,1])]*r[I][3][7,0]*r[J][27][5,0]*r[K][4][11,0]*t[((I,7),(J,5),(K,11),)]
                tu += 1/6*g[dei(p[I,0],p[J,1],p[J,0],p[K,1])]*r[I][3][7,0]*r[J][45][5,0]*r[K][4][11,0]*t[((I,7),(J,5),(K,11),)]
                # ({I}_{8}, {J}_{5}, {K}_{11})
                tu += 1/6*g[dei(p[I,1],p[J,0],p[J,1],p[K,1])]*r[I][7][8,0]*r[J][27][5,0]*r[K][4][11,0]*t[((I,8),(J,5),(K,11),)]
                tu += 1/6*g[dei(p[I,1],p[J,1],p[J,0],p[K,1])]*r[I][7][8,0]*r[J][45][5,0]*r[K][4][11,0]*t[((I,8),(J,5),(K,11),)]
                # ({I}_{9}, {J}_{7}, {K}_{15})
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,0],p[K,0])]*r[I][1][9,0]*r[J][3][7,0]*r[K][11][15,0]*t[((I,9),(J,7),(K,15),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,0],p[K,1])]*r[I][1][9,0]*r[J][3][7,0]*r[K][41][15,0]*t[((I,9),(J,7),(K,15),)]
                # ({I}_{9}, {J}_{8}, {K}_{15})
                tu += -1/6*g[dei(p[I,0],p[K,0],p[J,1],p[K,0])]*r[I][1][9,0]*r[J][7][8,0]*r[K][11][15,0]*t[((I,9),(J,8),(K,15),)]
                tu += -1/6*g[dei(p[I,0],p[K,1],p[J,1],p[K,1])]*r[I][1][9,0]*r[J][7][8,0]*r[K][41][15,0]*t[((I,9),(J,8),(K,15),)]
                # ({I}_{10}, {J}_{7}, {K}_{15})
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,0],p[K,0])]*r[I][5][10,0]*r[J][3][7,0]*r[K][11][15,0]*t[((I,10),(J,7),(K,15),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,0],p[K,1])]*r[I][5][10,0]*r[J][3][7,0]*r[K][41][15,0]*t[((I,10),(J,7),(K,15),)]
                # ({I}_{10}, {J}_{8}, {K}_{15})
                tu += -1/6*g[dei(p[I,1],p[K,0],p[J,1],p[K,0])]*r[I][5][10,0]*r[J][7][8,0]*r[K][11][15,0]*t[((I,10),(J,8),(K,15),)]
                tu += -1/6*g[dei(p[I,1],p[K,1],p[J,1],p[K,1])]*r[I][5][10,0]*r[J][7][8,0]*r[K][41][15,0]*t[((I,10),(J,8),(K,15),)]
                # ({I}_{7}, {J}_{9}, {K}_{15})
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,0],p[K,0])]*r[I][3][7,0]*r[J][1][9,0]*r[K][11][15,0]*t[((I,7),(J,9),(K,15),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,0],p[K,1])]*r[I][3][7,0]*r[J][1][9,0]*r[K][41][15,0]*t[((I,7),(J,9),(K,15),)]
                # ({I}_{8}, {J}_{9}, {K}_{15})
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,0],p[K,0])]*r[I][7][8,0]*r[J][1][9,0]*r[K][11][15,0]*t[((I,8),(J,9),(K,15),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,0],p[K,1])]*r[I][7][8,0]*r[J][1][9,0]*r[K][41][15,0]*t[((I,8),(J,9),(K,15),)]
                # ({I}_{7}, {J}_{10}, {K}_{15})
                tu += 1/6*g[dei(p[I,0],p[K,0],p[J,1],p[K,0])]*r[I][3][7,0]*r[J][5][10,0]*r[K][11][15,0]*t[((I,7),(J,10),(K,15),)]
                tu += 1/6*g[dei(p[I,0],p[K,1],p[J,1],p[K,1])]*r[I][3][7,0]*r[J][5][10,0]*r[K][41][15,0]*t[((I,7),(J,10),(K,15),)]
                # ({I}_{8}, {J}_{10}, {K}_{15})
                tu += 1/6*g[dei(p[I,1],p[K,0],p[J,1],p[K,0])]*r[I][7][8,0]*r[J][5][10,0]*r[K][11][15,0]*t[((I,8),(J,10),(K,15),)]
                tu += 1/6*g[dei(p[I,1],p[K,1],p[J,1],p[K,1])]*r[I][7][8,0]*r[J][5][10,0]*r[K][41][15,0]*t[((I,8),(J,10),(K,15),)]
                
    for I in range(nc,np):
        if I in {}: continue
        for J in range(nc,np):
            if J in {I}: continue
            for K in range(nc,np):
                if K in {I,J}: continue
                for L in range(nc,np):
                    if L in {I,J,K}: continue
                    # ({I}_{12}, {J}_{12}, {K}_{9}, {L}_{9})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,0])]*r[I][0][12,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][1][9,0]*t[((I,12),(K,9),)]*t[((J,12),(L,9),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,0])]*r[I][0][12,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][1][9,0]*t[((I,12),(K,9),)]*t[((J,12),(L,9),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,0])]*r[I][0][12,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][1][9,0]*t[((I,12),(L,9),)]*t[((J,12),(K,9),)]
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,0])]*r[I][0][12,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][1][9,0]*t[((I,12),(L,9),)]*t[((J,12),(K,9),)]
                    # ({I}_{14}, {J}_{14}, {K}_{7}, {L}_{7})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,0])]*r[I][2][14,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][3][7,0]*t[((I,14),(K,7),)]*t[((J,14),(L,7),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,0])]*r[I][2][14,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][3][7,0]*t[((I,14),(K,7),)]*t[((J,14),(L,7),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,0])]*r[I][2][14,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][3][7,0]*t[((I,14),(L,7),)]*t[((J,14),(K,7),)]
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,0])]*r[I][2][14,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][3][7,0]*t[((I,14),(L,7),)]*t[((J,14),(K,7),)]
                    # ({I}_{12}, {J}_{14}, {K}_{9}, {L}_{7})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,0])]*r[I][0][12,0]*r[J][2][14,0]*r[K][1][9,0]*r[L][3][7,0]*t[((I,12),(K,9),)]*t[((J,14),(L,7),)]
                    # ({I}_{12}, {J}_{12}, {K}_{9}, {L}_{10})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,1])]*r[I][0][12,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][5][10,0]*t[((I,12),(K,9),)]*t[((J,12),(L,10),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,0])]*r[I][0][12,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][5][10,0]*t[((I,12),(K,9),)]*t[((J,12),(L,10),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,1])]*r[I][0][12,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][5][10,0]*t[((I,12),(L,10),)]*t[((J,12),(K,9),)]
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,0])]*r[I][0][12,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][5][10,0]*t[((I,12),(L,10),)]*t[((J,12),(K,9),)]
                    # ({I}_{14}, {J}_{14}, {K}_{7}, {L}_{8})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,1])]*r[I][2][14,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][7][8,0]*t[((I,14),(K,7),)]*t[((J,14),(L,8),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,0])]*r[I][2][14,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][7][8,0]*t[((I,14),(K,7),)]*t[((J,14),(L,8),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,1])]*r[I][2][14,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][7][8,0]*t[((I,14),(L,8),)]*t[((J,14),(K,7),)]
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,0])]*r[I][2][14,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][7][8,0]*t[((I,14),(L,8),)]*t[((J,14),(K,7),)]
                    # ({I}_{12}, {J}_{14}, {K}_{9}, {L}_{8})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,1])]*r[I][0][12,0]*r[J][2][14,0]*r[K][1][9,0]*r[L][7][8,0]*t[((I,12),(K,9),)]*t[((J,14),(L,8),)]
                    # ({I}_{12}, {J}_{12}, {K}_{10}, {L}_{9})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,0])]*r[I][0][12,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][1][9,0]*t[((I,12),(K,10),)]*t[((J,12),(L,9),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,1])]*r[I][0][12,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][1][9,0]*t[((I,12),(K,10),)]*t[((J,12),(L,9),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,0])]*r[I][0][12,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][1][9,0]*t[((I,12),(L,9),)]*t[((J,12),(K,10),)]
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,1])]*r[I][0][12,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][1][9,0]*t[((I,12),(L,9),)]*t[((J,12),(K,10),)]
                    # ({I}_{14}, {J}_{14}, {K}_{8}, {L}_{7})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,0])]*r[I][2][14,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][3][7,0]*t[((I,14),(K,8),)]*t[((J,14),(L,7),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,1])]*r[I][2][14,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][3][7,0]*t[((I,14),(K,8),)]*t[((J,14),(L,7),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,0])]*r[I][2][14,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][3][7,0]*t[((I,14),(L,7),)]*t[((J,14),(K,8),)]
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,1])]*r[I][2][14,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][3][7,0]*t[((I,14),(L,7),)]*t[((J,14),(K,8),)]
                    # ({I}_{12}, {J}_{14}, {K}_{10}, {L}_{7})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,0])]*r[I][0][12,0]*r[J][2][14,0]*r[K][5][10,0]*r[L][3][7,0]*t[((I,12),(K,10),)]*t[((J,14),(L,7),)]
                    # ({I}_{12}, {J}_{12}, {K}_{10}, {L}_{10})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,1])]*r[I][0][12,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][5][10,0]*t[((I,12),(K,10),)]*t[((J,12),(L,10),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,1])]*r[I][0][12,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][5][10,0]*t[((I,12),(K,10),)]*t[((J,12),(L,10),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,1])]*r[I][0][12,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][5][10,0]*t[((I,12),(L,10),)]*t[((J,12),(K,10),)]
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,1])]*r[I][0][12,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][5][10,0]*t[((I,12),(L,10),)]*t[((J,12),(K,10),)]
                    # ({I}_{14}, {J}_{14}, {K}_{8}, {L}_{8})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,1])]*r[I][2][14,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][7][8,0]*t[((I,14),(K,8),)]*t[((J,14),(L,8),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,1])]*r[I][2][14,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][7][8,0]*t[((I,14),(K,8),)]*t[((J,14),(L,8),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,1])]*r[I][2][14,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][7][8,0]*t[((I,14),(L,8),)]*t[((J,14),(K,8),)]
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,1])]*r[I][2][14,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][7][8,0]*t[((I,14),(L,8),)]*t[((J,14),(K,8),)]
                    # ({I}_{12}, {J}_{14}, {K}_{10}, {L}_{8})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,1])]*r[I][0][12,0]*r[J][2][14,0]*r[K][5][10,0]*r[L][7][8,0]*t[((I,12),(K,10),)]*t[((J,14),(L,8),)]
                    # ({I}_{12}, {J}_{11}, {K}_{9}, {L}_{9})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,0])]*r[I][0][12,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][1][9,0]*t[((I,12),(K,9),)]*t[((J,11),(L,9),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,0])]*r[I][0][12,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][1][9,0]*t[((I,12),(K,9),)]*t[((J,11),(L,9),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,0])]*r[I][0][12,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][1][9,0]*t[((I,12),(L,9),)]*t[((J,11),(K,9),)]
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,0])]*r[I][0][12,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][1][9,0]*t[((I,12),(L,9),)]*t[((J,11),(K,9),)]
                    # ({I}_{14}, {J}_{13}, {K}_{7}, {L}_{7})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,0])]*r[I][2][14,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][3][7,0]*t[((I,14),(K,7),)]*t[((J,13),(L,7),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,0])]*r[I][2][14,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][3][7,0]*t[((I,14),(K,7),)]*t[((J,13),(L,7),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,0])]*r[I][2][14,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][3][7,0]*t[((I,14),(L,7),)]*t[((J,13),(K,7),)]
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,0])]*r[I][2][14,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][3][7,0]*t[((I,14),(L,7),)]*t[((J,13),(K,7),)]
                    # ({I}_{12}, {J}_{13}, {K}_{9}, {L}_{7})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,0])]*r[I][0][12,0]*r[J][6][13,0]*r[K][1][9,0]*r[L][3][7,0]*t[((I,12),(K,9),)]*t[((J,13),(L,7),)]
                    # ({I}_{12}, {J}_{11}, {K}_{9}, {L}_{10})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,1])]*r[I][0][12,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][5][10,0]*t[((I,12),(K,9),)]*t[((J,11),(L,10),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,0])]*r[I][0][12,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][5][10,0]*t[((I,12),(K,9),)]*t[((J,11),(L,10),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,1])]*r[I][0][12,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][5][10,0]*t[((I,12),(L,10),)]*t[((J,11),(K,9),)]
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,0])]*r[I][0][12,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][5][10,0]*t[((I,12),(L,10),)]*t[((J,11),(K,9),)]
                    # ({I}_{14}, {J}_{13}, {K}_{7}, {L}_{8})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,1])]*r[I][2][14,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][7][8,0]*t[((I,14),(K,7),)]*t[((J,13),(L,8),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,0])]*r[I][2][14,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][7][8,0]*t[((I,14),(K,7),)]*t[((J,13),(L,8),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,1])]*r[I][2][14,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][7][8,0]*t[((I,14),(L,8),)]*t[((J,13),(K,7),)]
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,0])]*r[I][2][14,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][7][8,0]*t[((I,14),(L,8),)]*t[((J,13),(K,7),)]
                    # ({I}_{12}, {J}_{13}, {K}_{9}, {L}_{8})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,1])]*r[I][0][12,0]*r[J][6][13,0]*r[K][1][9,0]*r[L][7][8,0]*t[((I,12),(K,9),)]*t[((J,13),(L,8),)]
                    # ({I}_{12}, {J}_{11}, {K}_{10}, {L}_{9})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,0])]*r[I][0][12,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][1][9,0]*t[((I,12),(K,10),)]*t[((J,11),(L,9),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,1])]*r[I][0][12,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][1][9,0]*t[((I,12),(K,10),)]*t[((J,11),(L,9),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,0])]*r[I][0][12,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][1][9,0]*t[((I,12),(L,9),)]*t[((J,11),(K,10),)]
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,1])]*r[I][0][12,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][1][9,0]*t[((I,12),(L,9),)]*t[((J,11),(K,10),)]
                    # ({I}_{14}, {J}_{13}, {K}_{8}, {L}_{7})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,0])]*r[I][2][14,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][3][7,0]*t[((I,14),(K,8),)]*t[((J,13),(L,7),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,1])]*r[I][2][14,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][3][7,0]*t[((I,14),(K,8),)]*t[((J,13),(L,7),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,0])]*r[I][2][14,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][3][7,0]*t[((I,14),(L,7),)]*t[((J,13),(K,8),)]
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,1])]*r[I][2][14,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][3][7,0]*t[((I,14),(L,7),)]*t[((J,13),(K,8),)]
                    # ({I}_{12}, {J}_{13}, {K}_{10}, {L}_{7})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,0])]*r[I][0][12,0]*r[J][6][13,0]*r[K][5][10,0]*r[L][3][7,0]*t[((I,12),(K,10),)]*t[((J,13),(L,7),)]
                    # ({I}_{12}, {J}_{11}, {K}_{10}, {L}_{10})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,1])]*r[I][0][12,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][5][10,0]*t[((I,12),(K,10),)]*t[((J,11),(L,10),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,1])]*r[I][0][12,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][5][10,0]*t[((I,12),(K,10),)]*t[((J,11),(L,10),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,1])]*r[I][0][12,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][5][10,0]*t[((I,12),(L,10),)]*t[((J,11),(K,10),)]
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,1])]*r[I][0][12,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][5][10,0]*t[((I,12),(L,10),)]*t[((J,11),(K,10),)]
                    # ({I}_{14}, {J}_{13}, {K}_{8}, {L}_{8})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,1])]*r[I][2][14,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][7][8,0]*t[((I,14),(K,8),)]*t[((J,13),(L,8),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,1])]*r[I][2][14,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][7][8,0]*t[((I,14),(K,8),)]*t[((J,13),(L,8),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,1])]*r[I][2][14,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][7][8,0]*t[((I,14),(L,8),)]*t[((J,13),(K,8),)]
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,1])]*r[I][2][14,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][7][8,0]*t[((I,14),(L,8),)]*t[((J,13),(K,8),)]
                    # ({I}_{12}, {J}_{13}, {K}_{10}, {L}_{8})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,1])]*r[I][0][12,0]*r[J][6][13,0]*r[K][5][10,0]*r[L][7][8,0]*t[((I,12),(K,10),)]*t[((J,13),(L,8),)]
                    # ({I}_{11}, {J}_{12}, {K}_{9}, {L}_{9})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,0])]*r[I][4][11,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][1][9,0]*t[((I,11),(K,9),)]*t[((J,12),(L,9),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,0])]*r[I][4][11,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][1][9,0]*t[((I,11),(K,9),)]*t[((J,12),(L,9),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,0])]*r[I][4][11,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][1][9,0]*t[((I,11),(L,9),)]*t[((J,12),(K,9),)]
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,0])]*r[I][4][11,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][1][9,0]*t[((I,11),(L,9),)]*t[((J,12),(K,9),)]
                    # ({I}_{13}, {J}_{14}, {K}_{7}, {L}_{7})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,0])]*r[I][6][13,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][3][7,0]*t[((I,13),(K,7),)]*t[((J,14),(L,7),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,0])]*r[I][6][13,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][3][7,0]*t[((I,13),(K,7),)]*t[((J,14),(L,7),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,0])]*r[I][6][13,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][3][7,0]*t[((I,13),(L,7),)]*t[((J,14),(K,7),)]
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,0])]*r[I][6][13,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][3][7,0]*t[((I,13),(L,7),)]*t[((J,14),(K,7),)]
                    # ({I}_{11}, {J}_{14}, {K}_{9}, {L}_{7})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,0])]*r[I][4][11,0]*r[J][2][14,0]*r[K][1][9,0]*r[L][3][7,0]*t[((I,11),(K,9),)]*t[((J,14),(L,7),)]
                    # ({I}_{11}, {J}_{12}, {K}_{9}, {L}_{10})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,1])]*r[I][4][11,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][5][10,0]*t[((I,11),(K,9),)]*t[((J,12),(L,10),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,0])]*r[I][4][11,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][5][10,0]*t[((I,11),(K,9),)]*t[((J,12),(L,10),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,1])]*r[I][4][11,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][5][10,0]*t[((I,11),(L,10),)]*t[((J,12),(K,9),)]
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,0])]*r[I][4][11,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][5][10,0]*t[((I,11),(L,10),)]*t[((J,12),(K,9),)]
                    # ({I}_{13}, {J}_{14}, {K}_{7}, {L}_{8})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,1])]*r[I][6][13,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][7][8,0]*t[((I,13),(K,7),)]*t[((J,14),(L,8),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,0])]*r[I][6][13,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][7][8,0]*t[((I,13),(K,7),)]*t[((J,14),(L,8),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,1])]*r[I][6][13,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][7][8,0]*t[((I,13),(L,8),)]*t[((J,14),(K,7),)]
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,0])]*r[I][6][13,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][7][8,0]*t[((I,13),(L,8),)]*t[((J,14),(K,7),)]
                    # ({I}_{11}, {J}_{14}, {K}_{9}, {L}_{8})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,1])]*r[I][4][11,0]*r[J][2][14,0]*r[K][1][9,0]*r[L][7][8,0]*t[((I,11),(K,9),)]*t[((J,14),(L,8),)]
                    # ({I}_{11}, {J}_{12}, {K}_{10}, {L}_{9})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,0])]*r[I][4][11,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][1][9,0]*t[((I,11),(K,10),)]*t[((J,12),(L,9),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,1])]*r[I][4][11,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][1][9,0]*t[((I,11),(K,10),)]*t[((J,12),(L,9),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,0])]*r[I][4][11,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][1][9,0]*t[((I,11),(L,9),)]*t[((J,12),(K,10),)]
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,1])]*r[I][4][11,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][1][9,0]*t[((I,11),(L,9),)]*t[((J,12),(K,10),)]
                    # ({I}_{13}, {J}_{14}, {K}_{8}, {L}_{7})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,0])]*r[I][6][13,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][3][7,0]*t[((I,13),(K,8),)]*t[((J,14),(L,7),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,1])]*r[I][6][13,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][3][7,0]*t[((I,13),(K,8),)]*t[((J,14),(L,7),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,0])]*r[I][6][13,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][3][7,0]*t[((I,13),(L,7),)]*t[((J,14),(K,8),)]
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,1])]*r[I][6][13,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][3][7,0]*t[((I,13),(L,7),)]*t[((J,14),(K,8),)]
                    # ({I}_{11}, {J}_{14}, {K}_{10}, {L}_{7})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,0])]*r[I][4][11,0]*r[J][2][14,0]*r[K][5][10,0]*r[L][3][7,0]*t[((I,11),(K,10),)]*t[((J,14),(L,7),)]
                    # ({I}_{11}, {J}_{12}, {K}_{10}, {L}_{10})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,1])]*r[I][4][11,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][5][10,0]*t[((I,11),(K,10),)]*t[((J,12),(L,10),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,1])]*r[I][4][11,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][5][10,0]*t[((I,11),(K,10),)]*t[((J,12),(L,10),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,1])]*r[I][4][11,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][5][10,0]*t[((I,11),(L,10),)]*t[((J,12),(K,10),)]
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,1])]*r[I][4][11,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][5][10,0]*t[((I,11),(L,10),)]*t[((J,12),(K,10),)]
                    # ({I}_{13}, {J}_{14}, {K}_{8}, {L}_{8})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,1])]*r[I][6][13,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][7][8,0]*t[((I,13),(K,8),)]*t[((J,14),(L,8),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,1])]*r[I][6][13,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][7][8,0]*t[((I,13),(K,8),)]*t[((J,14),(L,8),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,1])]*r[I][6][13,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][7][8,0]*t[((I,13),(L,8),)]*t[((J,14),(K,8),)]
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,1])]*r[I][6][13,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][7][8,0]*t[((I,13),(L,8),)]*t[((J,14),(K,8),)]
                    # ({I}_{11}, {J}_{14}, {K}_{10}, {L}_{8})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,1])]*r[I][4][11,0]*r[J][2][14,0]*r[K][5][10,0]*r[L][7][8,0]*t[((I,11),(K,10),)]*t[((J,14),(L,8),)]
                    # ({I}_{11}, {J}_{11}, {K}_{9}, {L}_{9})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,0])]*r[I][4][11,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][1][9,0]*t[((I,11),(K,9),)]*t[((J,11),(L,9),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,0])]*r[I][4][11,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][1][9,0]*t[((I,11),(K,9),)]*t[((J,11),(L,9),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,0])]*r[I][4][11,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][1][9,0]*t[((I,11),(L,9),)]*t[((J,11),(K,9),)]
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,0])]*r[I][4][11,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][1][9,0]*t[((I,11),(L,9),)]*t[((J,11),(K,9),)]
                    # ({I}_{13}, {J}_{13}, {K}_{7}, {L}_{7})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,0])]*r[I][6][13,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][3][7,0]*t[((I,13),(K,7),)]*t[((J,13),(L,7),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,0])]*r[I][6][13,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][3][7,0]*t[((I,13),(K,7),)]*t[((J,13),(L,7),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,0])]*r[I][6][13,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][3][7,0]*t[((I,13),(L,7),)]*t[((J,13),(K,7),)]
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,0])]*r[I][6][13,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][3][7,0]*t[((I,13),(L,7),)]*t[((J,13),(K,7),)]
                    # ({I}_{11}, {J}_{13}, {K}_{9}, {L}_{7})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,0])]*r[I][4][11,0]*r[J][6][13,0]*r[K][1][9,0]*r[L][3][7,0]*t[((I,11),(K,9),)]*t[((J,13),(L,7),)]
                    # ({I}_{11}, {J}_{11}, {K}_{9}, {L}_{10})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,1])]*r[I][4][11,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][5][10,0]*t[((I,11),(K,9),)]*t[((J,11),(L,10),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,0])]*r[I][4][11,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][5][10,0]*t[((I,11),(K,9),)]*t[((J,11),(L,10),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,1])]*r[I][4][11,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][5][10,0]*t[((I,11),(L,10),)]*t[((J,11),(K,9),)]
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,0])]*r[I][4][11,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][5][10,0]*t[((I,11),(L,10),)]*t[((J,11),(K,9),)]
                    # ({I}_{13}, {J}_{13}, {K}_{7}, {L}_{8})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,1])]*r[I][6][13,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][7][8,0]*t[((I,13),(K,7),)]*t[((J,13),(L,8),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,0])]*r[I][6][13,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][7][8,0]*t[((I,13),(K,7),)]*t[((J,13),(L,8),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,1])]*r[I][6][13,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][7][8,0]*t[((I,13),(L,8),)]*t[((J,13),(K,7),)]
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,0])]*r[I][6][13,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][7][8,0]*t[((I,13),(L,8),)]*t[((J,13),(K,7),)]
                    # ({I}_{11}, {J}_{13}, {K}_{9}, {L}_{8})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,1])]*r[I][4][11,0]*r[J][6][13,0]*r[K][1][9,0]*r[L][7][8,0]*t[((I,11),(K,9),)]*t[((J,13),(L,8),)]
                    # ({I}_{11}, {J}_{11}, {K}_{10}, {L}_{9})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,0])]*r[I][4][11,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][1][9,0]*t[((I,11),(K,10),)]*t[((J,11),(L,9),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,1])]*r[I][4][11,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][1][9,0]*t[((I,11),(K,10),)]*t[((J,11),(L,9),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,0])]*r[I][4][11,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][1][9,0]*t[((I,11),(L,9),)]*t[((J,11),(K,10),)]
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,1])]*r[I][4][11,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][1][9,0]*t[((I,11),(L,9),)]*t[((J,11),(K,10),)]
                    # ({I}_{13}, {J}_{13}, {K}_{8}, {L}_{7})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,0])]*r[I][6][13,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][3][7,0]*t[((I,13),(K,8),)]*t[((J,13),(L,7),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,1])]*r[I][6][13,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][3][7,0]*t[((I,13),(K,8),)]*t[((J,13),(L,7),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,0])]*r[I][6][13,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][3][7,0]*t[((I,13),(L,7),)]*t[((J,13),(K,8),)]
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,1])]*r[I][6][13,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][3][7,0]*t[((I,13),(L,7),)]*t[((J,13),(K,8),)]
                    # ({I}_{11}, {J}_{13}, {K}_{10}, {L}_{7})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,0])]*r[I][4][11,0]*r[J][6][13,0]*r[K][5][10,0]*r[L][3][7,0]*t[((I,11),(K,10),)]*t[((J,13),(L,7),)]
                    # ({I}_{11}, {J}_{11}, {K}_{10}, {L}_{10})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,1])]*r[I][4][11,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][5][10,0]*t[((I,11),(K,10),)]*t[((J,11),(L,10),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,1])]*r[I][4][11,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][5][10,0]*t[((I,11),(K,10),)]*t[((J,11),(L,10),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,1])]*r[I][4][11,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][5][10,0]*t[((I,11),(L,10),)]*t[((J,11),(K,10),)]
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,1])]*r[I][4][11,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][5][10,0]*t[((I,11),(L,10),)]*t[((J,11),(K,10),)]
                    # ({I}_{13}, {J}_{13}, {K}_{8}, {L}_{8})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,1])]*r[I][6][13,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][7][8,0]*t[((I,13),(K,8),)]*t[((J,13),(L,8),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,1])]*r[I][6][13,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][7][8,0]*t[((I,13),(K,8),)]*t[((J,13),(L,8),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,1])]*r[I][6][13,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][7][8,0]*t[((I,13),(L,8),)]*t[((J,13),(K,8),)]
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,1])]*r[I][6][13,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][7][8,0]*t[((I,13),(L,8),)]*t[((J,13),(K,8),)]
                    # ({I}_{11}, {J}_{13}, {K}_{10}, {L}_{8})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,1])]*r[I][4][11,0]*r[J][6][13,0]*r[K][5][10,0]*r[L][7][8,0]*t[((I,11),(K,10),)]*t[((J,13),(L,8),)]
                    # ({I}_{12}, {J}_{14}, {K}_{7}, {L}_{9})
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,0])]*r[I][0][12,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][1][9,0]*t[((I,12),(L,9),)]*t[((J,14),(K,7),)]
                    # ({I}_{12}, {J}_{14}, {K}_{8}, {L}_{9})
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,1])]*r[I][0][12,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][1][9,0]*t[((I,12),(L,9),)]*t[((J,14),(K,8),)]
                    # ({I}_{12}, {J}_{14}, {K}_{7}, {L}_{10})
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,0])]*r[I][0][12,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][5][10,0]*t[((I,12),(L,10),)]*t[((J,14),(K,7),)]
                    # ({I}_{12}, {J}_{14}, {K}_{8}, {L}_{10})
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,1])]*r[I][0][12,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][5][10,0]*t[((I,12),(L,10),)]*t[((J,14),(K,8),)]
                    # ({I}_{12}, {J}_{13}, {K}_{7}, {L}_{9})
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,0])]*r[I][0][12,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][1][9,0]*t[((I,12),(L,9),)]*t[((J,13),(K,7),)]
                    # ({I}_{12}, {J}_{13}, {K}_{8}, {L}_{9})
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,1])]*r[I][0][12,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][1][9,0]*t[((I,12),(L,9),)]*t[((J,13),(K,8),)]
                    # ({I}_{12}, {J}_{13}, {K}_{7}, {L}_{10})
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,0])]*r[I][0][12,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][5][10,0]*t[((I,12),(L,10),)]*t[((J,13),(K,7),)]
                    # ({I}_{12}, {J}_{13}, {K}_{8}, {L}_{10})
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,1])]*r[I][0][12,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][5][10,0]*t[((I,12),(L,10),)]*t[((J,13),(K,8),)]
                    # ({I}_{11}, {J}_{14}, {K}_{7}, {L}_{9})
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,0])]*r[I][4][11,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][1][9,0]*t[((I,11),(L,9),)]*t[((J,14),(K,7),)]
                    # ({I}_{11}, {J}_{14}, {K}_{8}, {L}_{9})
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,1])]*r[I][4][11,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][1][9,0]*t[((I,11),(L,9),)]*t[((J,14),(K,8),)]
                    # ({I}_{11}, {J}_{14}, {K}_{7}, {L}_{10})
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,0])]*r[I][4][11,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][5][10,0]*t[((I,11),(L,10),)]*t[((J,14),(K,7),)]
                    # ({I}_{11}, {J}_{14}, {K}_{8}, {L}_{10})
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,1])]*r[I][4][11,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][5][10,0]*t[((I,11),(L,10),)]*t[((J,14),(K,8),)]
                    # ({I}_{11}, {J}_{13}, {K}_{7}, {L}_{9})
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,0])]*r[I][4][11,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][1][9,0]*t[((I,11),(L,9),)]*t[((J,13),(K,7),)]
                    # ({I}_{11}, {J}_{13}, {K}_{8}, {L}_{9})
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,1])]*r[I][4][11,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][1][9,0]*t[((I,11),(L,9),)]*t[((J,13),(K,8),)]
                    # ({I}_{11}, {J}_{13}, {K}_{7}, {L}_{10})
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,0])]*r[I][4][11,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][5][10,0]*t[((I,11),(L,10),)]*t[((J,13),(K,7),)]
                    # ({I}_{11}, {J}_{13}, {K}_{8}, {L}_{10})
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,1])]*r[I][4][11,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][5][10,0]*t[((I,11),(L,10),)]*t[((J,13),(K,8),)]
                    # ({I}_{12}, {J}_{9}, {K}_{12}, {L}_{9})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,12),(J,9),)]*t[((K,12),(L,9),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,12),(J,9),)]*t[((K,12),(L,9),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,12),(L,9),)]*t[((J,9),(K,12),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,12),(L,9),)]*t[((J,9),(K,12),)]
                    # ({I}_{14}, {J}_{7}, {K}_{14}, {L}_{7})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,14),(J,7),)]*t[((K,14),(L,7),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,14),(J,7),)]*t[((K,14),(L,7),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,14),(L,7),)]*t[((J,7),(K,14),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,14),(L,7),)]*t[((J,7),(K,14),)]
                    # ({I}_{12}, {J}_{9}, {K}_{14}, {L}_{7})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,12),(J,9),)]*t[((K,14),(L,7),)]
                    # ({I}_{12}, {J}_{9}, {K}_{12}, {L}_{10})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,12),(J,9),)]*t[((K,12),(L,10),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,12),(J,9),)]*t[((K,12),(L,10),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,12),(L,10),)]*t[((J,9),(K,12),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,12),(L,10),)]*t[((J,9),(K,12),)]
                    # ({I}_{14}, {J}_{7}, {K}_{14}, {L}_{8})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,14),(J,7),)]*t[((K,14),(L,8),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,14),(J,7),)]*t[((K,14),(L,8),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,14),(L,8),)]*t[((J,7),(K,14),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,14),(L,8),)]*t[((J,7),(K,14),)]
                    # ({I}_{12}, {J}_{9}, {K}_{14}, {L}_{8})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,12),(J,9),)]*t[((K,14),(L,8),)]
                    # ({I}_{12}, {J}_{10}, {K}_{12}, {L}_{9})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,12),(J,10),)]*t[((K,12),(L,9),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,12),(J,10),)]*t[((K,12),(L,9),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,12),(L,9),)]*t[((J,10),(K,12),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,12),(L,9),)]*t[((J,10),(K,12),)]
                    # ({I}_{14}, {J}_{8}, {K}_{14}, {L}_{7})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,14),(J,8),)]*t[((K,14),(L,7),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,14),(J,8),)]*t[((K,14),(L,7),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,14),(L,7),)]*t[((J,8),(K,14),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,14),(L,7),)]*t[((J,8),(K,14),)]
                    # ({I}_{12}, {J}_{10}, {K}_{14}, {L}_{7})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,12),(J,10),)]*t[((K,14),(L,7),)]
                    # ({I}_{12}, {J}_{10}, {K}_{12}, {L}_{10})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,12),(J,10),)]*t[((K,12),(L,10),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,12),(J,10),)]*t[((K,12),(L,10),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,12),(L,10),)]*t[((J,10),(K,12),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,12),(L,10),)]*t[((J,10),(K,12),)]
                    # ({I}_{14}, {J}_{8}, {K}_{14}, {L}_{8})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,14),(J,8),)]*t[((K,14),(L,8),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,14),(J,8),)]*t[((K,14),(L,8),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,14),(L,8),)]*t[((J,8),(K,14),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,14),(L,8),)]*t[((J,8),(K,14),)]
                    # ({I}_{12}, {J}_{10}, {K}_{14}, {L}_{8})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,12),(J,10),)]*t[((K,14),(L,8),)]
                    # ({I}_{12}, {J}_{9}, {K}_{11}, {L}_{9})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,12),(J,9),)]*t[((K,11),(L,9),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,12),(J,9),)]*t[((K,11),(L,9),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,12),(L,9),)]*t[((J,9),(K,11),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,12),(L,9),)]*t[((J,9),(K,11),)]
                    # ({I}_{14}, {J}_{7}, {K}_{13}, {L}_{7})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,14),(J,7),)]*t[((K,13),(L,7),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,14),(J,7),)]*t[((K,13),(L,7),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,14),(L,7),)]*t[((J,7),(K,13),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,14),(L,7),)]*t[((J,7),(K,13),)]
                    # ({I}_{12}, {J}_{9}, {K}_{13}, {L}_{7})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,12),(J,9),)]*t[((K,13),(L,7),)]
                    # ({I}_{12}, {J}_{9}, {K}_{11}, {L}_{10})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,12),(J,9),)]*t[((K,11),(L,10),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,12),(J,9),)]*t[((K,11),(L,10),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,12),(L,10),)]*t[((J,9),(K,11),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,12),(L,10),)]*t[((J,9),(K,11),)]
                    # ({I}_{14}, {J}_{7}, {K}_{13}, {L}_{8})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,14),(J,7),)]*t[((K,13),(L,8),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,14),(J,7),)]*t[((K,13),(L,8),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,14),(L,8),)]*t[((J,7),(K,13),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,14),(L,8),)]*t[((J,7),(K,13),)]
                    # ({I}_{12}, {J}_{9}, {K}_{13}, {L}_{8})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,12),(J,9),)]*t[((K,13),(L,8),)]
                    # ({I}_{12}, {J}_{10}, {K}_{11}, {L}_{9})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,12),(J,10),)]*t[((K,11),(L,9),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,12),(J,10),)]*t[((K,11),(L,9),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,12),(L,9),)]*t[((J,10),(K,11),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,12),(L,9),)]*t[((J,10),(K,11),)]
                    # ({I}_{14}, {J}_{8}, {K}_{13}, {L}_{7})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,14),(J,8),)]*t[((K,13),(L,7),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,14),(J,8),)]*t[((K,13),(L,7),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,14),(L,7),)]*t[((J,8),(K,13),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,14),(L,7),)]*t[((J,8),(K,13),)]
                    # ({I}_{12}, {J}_{10}, {K}_{13}, {L}_{7})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,12),(J,10),)]*t[((K,13),(L,7),)]
                    # ({I}_{12}, {J}_{10}, {K}_{11}, {L}_{10})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,12),(J,10),)]*t[((K,11),(L,10),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,12),(J,10),)]*t[((K,11),(L,10),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,12),(L,10),)]*t[((J,10),(K,11),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,12),(L,10),)]*t[((J,10),(K,11),)]
                    # ({I}_{14}, {J}_{8}, {K}_{13}, {L}_{8})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,14),(J,8),)]*t[((K,13),(L,8),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,14),(J,8),)]*t[((K,13),(L,8),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,14),(L,8),)]*t[((J,8),(K,13),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,14),(L,8),)]*t[((J,8),(K,13),)]
                    # ({I}_{12}, {J}_{10}, {K}_{13}, {L}_{8})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,12),(J,10),)]*t[((K,13),(L,8),)]
                    # ({I}_{11}, {J}_{9}, {K}_{12}, {L}_{9})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,11),(J,9),)]*t[((K,12),(L,9),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,11),(J,9),)]*t[((K,12),(L,9),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,11),(L,9),)]*t[((J,9),(K,12),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,11),(L,9),)]*t[((J,9),(K,12),)]
                    # ({I}_{13}, {J}_{7}, {K}_{14}, {L}_{7})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,13),(J,7),)]*t[((K,14),(L,7),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,13),(J,7),)]*t[((K,14),(L,7),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,13),(L,7),)]*t[((J,7),(K,14),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,13),(L,7),)]*t[((J,7),(K,14),)]
                    # ({I}_{11}, {J}_{9}, {K}_{14}, {L}_{7})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,11),(J,9),)]*t[((K,14),(L,7),)]
                    # ({I}_{11}, {J}_{9}, {K}_{12}, {L}_{10})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,11),(J,9),)]*t[((K,12),(L,10),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,11),(J,9),)]*t[((K,12),(L,10),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,11),(L,10),)]*t[((J,9),(K,12),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,11),(L,10),)]*t[((J,9),(K,12),)]
                    # ({I}_{13}, {J}_{7}, {K}_{14}, {L}_{8})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,13),(J,7),)]*t[((K,14),(L,8),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,13),(J,7),)]*t[((K,14),(L,8),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,13),(L,8),)]*t[((J,7),(K,14),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,13),(L,8),)]*t[((J,7),(K,14),)]
                    # ({I}_{11}, {J}_{9}, {K}_{14}, {L}_{8})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,11),(J,9),)]*t[((K,14),(L,8),)]
                    # ({I}_{11}, {J}_{10}, {K}_{12}, {L}_{9})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,11),(J,10),)]*t[((K,12),(L,9),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,11),(J,10),)]*t[((K,12),(L,9),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,11),(L,9),)]*t[((J,10),(K,12),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,11),(L,9),)]*t[((J,10),(K,12),)]
                    # ({I}_{13}, {J}_{8}, {K}_{14}, {L}_{7})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,13),(J,8),)]*t[((K,14),(L,7),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,13),(J,8),)]*t[((K,14),(L,7),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,13),(L,7),)]*t[((J,8),(K,14),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,13),(L,7),)]*t[((J,8),(K,14),)]
                    # ({I}_{11}, {J}_{10}, {K}_{14}, {L}_{7})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,11),(J,10),)]*t[((K,14),(L,7),)]
                    # ({I}_{11}, {J}_{10}, {K}_{12}, {L}_{10})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,11),(J,10),)]*t[((K,12),(L,10),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,11),(J,10),)]*t[((K,12),(L,10),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,11),(L,10),)]*t[((J,10),(K,12),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,11),(L,10),)]*t[((J,10),(K,12),)]
                    # ({I}_{13}, {J}_{8}, {K}_{14}, {L}_{8})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,13),(J,8),)]*t[((K,14),(L,8),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,13),(J,8),)]*t[((K,14),(L,8),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,13),(L,8),)]*t[((J,8),(K,14),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,13),(L,8),)]*t[((J,8),(K,14),)]
                    # ({I}_{11}, {J}_{10}, {K}_{14}, {L}_{8})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,11),(J,10),)]*t[((K,14),(L,8),)]
                    # ({I}_{11}, {J}_{9}, {K}_{11}, {L}_{9})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,11),(J,9),)]*t[((K,11),(L,9),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,11),(J,9),)]*t[((K,11),(L,9),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,11),(L,9),)]*t[((J,9),(K,11),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,11),(L,9),)]*t[((J,9),(K,11),)]
                    # ({I}_{13}, {J}_{7}, {K}_{13}, {L}_{7})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,13),(J,7),)]*t[((K,13),(L,7),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,13),(J,7),)]*t[((K,13),(L,7),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,13),(L,7),)]*t[((J,7),(K,13),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,13),(L,7),)]*t[((J,7),(K,13),)]
                    # ({I}_{11}, {J}_{9}, {K}_{13}, {L}_{7})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,11),(J,9),)]*t[((K,13),(L,7),)]
                    # ({I}_{11}, {J}_{9}, {K}_{11}, {L}_{10})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,11),(J,9),)]*t[((K,11),(L,10),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,11),(J,9),)]*t[((K,11),(L,10),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,11),(L,10),)]*t[((J,9),(K,11),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,11),(L,10),)]*t[((J,9),(K,11),)]
                    # ({I}_{13}, {J}_{7}, {K}_{13}, {L}_{8})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,13),(J,7),)]*t[((K,13),(L,8),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,13),(J,7),)]*t[((K,13),(L,8),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,13),(L,8),)]*t[((J,7),(K,13),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,13),(L,8),)]*t[((J,7),(K,13),)]
                    # ({I}_{11}, {J}_{9}, {K}_{13}, {L}_{8})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,11),(J,9),)]*t[((K,13),(L,8),)]
                    # ({I}_{11}, {J}_{10}, {K}_{11}, {L}_{9})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,11),(J,10),)]*t[((K,11),(L,9),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,11),(J,10),)]*t[((K,11),(L,9),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,11),(L,9),)]*t[((J,10),(K,11),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,11),(L,9),)]*t[((J,10),(K,11),)]
                    # ({I}_{13}, {J}_{8}, {K}_{13}, {L}_{7})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,13),(J,8),)]*t[((K,13),(L,7),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,13),(J,8),)]*t[((K,13),(L,7),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,13),(L,7),)]*t[((J,8),(K,13),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,13),(L,7),)]*t[((J,8),(K,13),)]
                    # ({I}_{11}, {J}_{10}, {K}_{13}, {L}_{7})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,11),(J,10),)]*t[((K,13),(L,7),)]
                    # ({I}_{11}, {J}_{10}, {K}_{11}, {L}_{10})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,11),(J,10),)]*t[((K,11),(L,10),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,11),(J,10),)]*t[((K,11),(L,10),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,11),(L,10),)]*t[((J,10),(K,11),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,11),(L,10),)]*t[((J,10),(K,11),)]
                    # ({I}_{13}, {J}_{8}, {K}_{13}, {L}_{8})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,13),(J,8),)]*t[((K,13),(L,8),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,13),(J,8),)]*t[((K,13),(L,8),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,13),(L,8),)]*t[((J,8),(K,13),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,13),(L,8),)]*t[((J,8),(K,13),)]
                    # ({I}_{11}, {J}_{10}, {K}_{13}, {L}_{8})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,11),(J,10),)]*t[((K,13),(L,8),)]
                    # ({I}_{12}, {J}_{7}, {K}_{14}, {L}_{9})
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,0])]*r[I][0][12,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][1][9,0]*t[((I,12),(L,9),)]*t[((J,7),(K,14),)]
                    # ({I}_{12}, {J}_{8}, {K}_{14}, {L}_{9})
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,0])]*r[I][0][12,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][1][9,0]*t[((I,12),(L,9),)]*t[((J,8),(K,14),)]
                    # ({I}_{12}, {J}_{7}, {K}_{14}, {L}_{10})
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,0])]*r[I][0][12,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][5][10,0]*t[((I,12),(L,10),)]*t[((J,7),(K,14),)]
                    # ({I}_{12}, {J}_{8}, {K}_{14}, {L}_{10})
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,0])]*r[I][0][12,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][5][10,0]*t[((I,12),(L,10),)]*t[((J,8),(K,14),)]
                    # ({I}_{12}, {J}_{7}, {K}_{13}, {L}_{9})
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,1])]*r[I][0][12,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][1][9,0]*t[((I,12),(L,9),)]*t[((J,7),(K,13),)]
                    # ({I}_{12}, {J}_{8}, {K}_{13}, {L}_{9})
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,1])]*r[I][0][12,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][1][9,0]*t[((I,12),(L,9),)]*t[((J,8),(K,13),)]
                    # ({I}_{12}, {J}_{7}, {K}_{13}, {L}_{10})
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,1])]*r[I][0][12,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][5][10,0]*t[((I,12),(L,10),)]*t[((J,7),(K,13),)]
                    # ({I}_{12}, {J}_{8}, {K}_{13}, {L}_{10})
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,1])]*r[I][0][12,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][5][10,0]*t[((I,12),(L,10),)]*t[((J,8),(K,13),)]
                    # ({I}_{11}, {J}_{7}, {K}_{14}, {L}_{9})
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,0])]*r[I][4][11,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][1][9,0]*t[((I,11),(L,9),)]*t[((J,7),(K,14),)]
                    # ({I}_{11}, {J}_{8}, {K}_{14}, {L}_{9})
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,0])]*r[I][4][11,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][1][9,0]*t[((I,11),(L,9),)]*t[((J,8),(K,14),)]
                    # ({I}_{11}, {J}_{7}, {K}_{14}, {L}_{10})
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,0])]*r[I][4][11,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][5][10,0]*t[((I,11),(L,10),)]*t[((J,7),(K,14),)]
                    # ({I}_{11}, {J}_{8}, {K}_{14}, {L}_{10})
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,0])]*r[I][4][11,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][5][10,0]*t[((I,11),(L,10),)]*t[((J,8),(K,14),)]
                    # ({I}_{11}, {J}_{7}, {K}_{13}, {L}_{9})
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,1])]*r[I][4][11,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][1][9,0]*t[((I,11),(L,9),)]*t[((J,7),(K,13),)]
                    # ({I}_{11}, {J}_{8}, {K}_{13}, {L}_{9})
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,1])]*r[I][4][11,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][1][9,0]*t[((I,11),(L,9),)]*t[((J,8),(K,13),)]
                    # ({I}_{11}, {J}_{7}, {K}_{13}, {L}_{10})
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,1])]*r[I][4][11,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][5][10,0]*t[((I,11),(L,10),)]*t[((J,7),(K,13),)]
                    # ({I}_{11}, {J}_{8}, {K}_{13}, {L}_{10})
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,1])]*r[I][4][11,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][5][10,0]*t[((I,11),(L,10),)]*t[((J,8),(K,13),)]
                    # ({I}_{12}, {J}_{9}, {K}_{9}, {L}_{12})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,12),(J,9),)]*t[((K,9),(L,12),)]
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,12),(J,9),)]*t[((K,9),(L,12),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,12),(K,9),)]*t[((J,9),(L,12),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,12),(K,9),)]*t[((J,9),(L,12),)]
                    # ({I}_{14}, {J}_{7}, {K}_{7}, {L}_{14})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,14),(J,7),)]*t[((K,7),(L,14),)]
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,14),(J,7),)]*t[((K,7),(L,14),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,14),(K,7),)]*t[((J,7),(L,14),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,14),(K,7),)]*t[((J,7),(L,14),)]
                    # ({I}_{12}, {J}_{9}, {K}_{7}, {L}_{14})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,12),(J,9),)]*t[((K,7),(L,14),)]
                    # ({I}_{12}, {J}_{9}, {K}_{10}, {L}_{12})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,12),(J,9),)]*t[((K,10),(L,12),)]
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,12),(J,9),)]*t[((K,10),(L,12),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,12),(K,10),)]*t[((J,9),(L,12),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,12),(K,10),)]*t[((J,9),(L,12),)]
                    # ({I}_{14}, {J}_{7}, {K}_{8}, {L}_{14})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,14),(J,7),)]*t[((K,8),(L,14),)]
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,14),(J,7),)]*t[((K,8),(L,14),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,14),(K,8),)]*t[((J,7),(L,14),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,14),(K,8),)]*t[((J,7),(L,14),)]
                    # ({I}_{12}, {J}_{9}, {K}_{8}, {L}_{14})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,0])]*r[I][0][12,0]*r[J][1][9,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,12),(J,9),)]*t[((K,8),(L,14),)]
                    # ({I}_{12}, {J}_{10}, {K}_{9}, {L}_{12})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,12),(J,10),)]*t[((K,9),(L,12),)]
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,12),(J,10),)]*t[((K,9),(L,12),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,12),(K,9),)]*t[((J,10),(L,12),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,12),(K,9),)]*t[((J,10),(L,12),)]
                    # ({I}_{14}, {J}_{8}, {K}_{7}, {L}_{14})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,14),(J,8),)]*t[((K,7),(L,14),)]
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,14),(J,8),)]*t[((K,7),(L,14),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,14),(K,7),)]*t[((J,8),(L,14),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,14),(K,7),)]*t[((J,8),(L,14),)]
                    # ({I}_{12}, {J}_{10}, {K}_{7}, {L}_{14})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,12),(J,10),)]*t[((K,7),(L,14),)]
                    # ({I}_{12}, {J}_{10}, {K}_{10}, {L}_{12})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,12),(J,10),)]*t[((K,10),(L,12),)]
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,12),(J,10),)]*t[((K,10),(L,12),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,12),(K,10),)]*t[((J,10),(L,12),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,12),(K,10),)]*t[((J,10),(L,12),)]
                    # ({I}_{14}, {J}_{8}, {K}_{8}, {L}_{14})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,14),(J,8),)]*t[((K,8),(L,14),)]
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,14),(J,8),)]*t[((K,8),(L,14),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,14),(K,8),)]*t[((J,8),(L,14),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,14),(K,8),)]*t[((J,8),(L,14),)]
                    # ({I}_{12}, {J}_{10}, {K}_{8}, {L}_{14})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,0])]*r[I][0][12,0]*r[J][5][10,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,12),(J,10),)]*t[((K,8),(L,14),)]
                    # ({I}_{12}, {J}_{9}, {K}_{9}, {L}_{11})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,12),(J,9),)]*t[((K,9),(L,11),)]
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,12),(J,9),)]*t[((K,9),(L,11),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,12),(K,9),)]*t[((J,9),(L,11),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,12),(K,9),)]*t[((J,9),(L,11),)]
                    # ({I}_{14}, {J}_{7}, {K}_{7}, {L}_{13})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,14),(J,7),)]*t[((K,7),(L,13),)]
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,14),(J,7),)]*t[((K,7),(L,13),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,14),(K,7),)]*t[((J,7),(L,13),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,14),(K,7),)]*t[((J,7),(L,13),)]
                    # ({I}_{12}, {J}_{9}, {K}_{7}, {L}_{13})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,12),(J,9),)]*t[((K,7),(L,13),)]
                    # ({I}_{12}, {J}_{9}, {K}_{10}, {L}_{11})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,12),(J,9),)]*t[((K,10),(L,11),)]
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,12),(J,9),)]*t[((K,10),(L,11),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,12),(K,10),)]*t[((J,9),(L,11),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,12),(K,10),)]*t[((J,9),(L,11),)]
                    # ({I}_{14}, {J}_{7}, {K}_{8}, {L}_{13})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,14),(J,7),)]*t[((K,8),(L,13),)]
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,14),(J,7),)]*t[((K,8),(L,13),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,14),(K,8),)]*t[((J,7),(L,13),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,14),(K,8),)]*t[((J,7),(L,13),)]
                    # ({I}_{12}, {J}_{9}, {K}_{8}, {L}_{13})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,1])]*r[I][0][12,0]*r[J][1][9,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,12),(J,9),)]*t[((K,8),(L,13),)]
                    # ({I}_{12}, {J}_{10}, {K}_{9}, {L}_{11})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,12),(J,10),)]*t[((K,9),(L,11),)]
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,12),(J,10),)]*t[((K,9),(L,11),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,12),(K,9),)]*t[((J,10),(L,11),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,12),(K,9),)]*t[((J,10),(L,11),)]
                    # ({I}_{14}, {J}_{8}, {K}_{7}, {L}_{13})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,14),(J,8),)]*t[((K,7),(L,13),)]
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,14),(J,8),)]*t[((K,7),(L,13),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,14),(K,7),)]*t[((J,8),(L,13),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,14),(K,7),)]*t[((J,8),(L,13),)]
                    # ({I}_{12}, {J}_{10}, {K}_{7}, {L}_{13})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,12),(J,10),)]*t[((K,7),(L,13),)]
                    # ({I}_{12}, {J}_{10}, {K}_{10}, {L}_{11})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,12),(J,10),)]*t[((K,10),(L,11),)]
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,12),(J,10),)]*t[((K,10),(L,11),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,12),(K,10),)]*t[((J,10),(L,11),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,12),(K,10),)]*t[((J,10),(L,11),)]
                    # ({I}_{14}, {J}_{8}, {K}_{8}, {L}_{13})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,14),(J,8),)]*t[((K,8),(L,13),)]
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,14),(J,8),)]*t[((K,8),(L,13),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,14),(K,8),)]*t[((J,8),(L,13),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,14),(K,8),)]*t[((J,8),(L,13),)]
                    # ({I}_{12}, {J}_{10}, {K}_{8}, {L}_{13})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,1])]*r[I][0][12,0]*r[J][5][10,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,12),(J,10),)]*t[((K,8),(L,13),)]
                    # ({I}_{11}, {J}_{9}, {K}_{9}, {L}_{12})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,11),(J,9),)]*t[((K,9),(L,12),)]
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,11),(J,9),)]*t[((K,9),(L,12),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,11),(K,9),)]*t[((J,9),(L,12),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,11),(K,9),)]*t[((J,9),(L,12),)]
                    # ({I}_{13}, {J}_{7}, {K}_{7}, {L}_{14})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,13),(J,7),)]*t[((K,7),(L,14),)]
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,13),(J,7),)]*t[((K,7),(L,14),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,13),(K,7),)]*t[((J,7),(L,14),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,13),(K,7),)]*t[((J,7),(L,14),)]
                    # ({I}_{11}, {J}_{9}, {K}_{7}, {L}_{14})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,11),(J,9),)]*t[((K,7),(L,14),)]
                    # ({I}_{11}, {J}_{9}, {K}_{10}, {L}_{12})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,11),(J,9),)]*t[((K,10),(L,12),)]
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,11),(J,9),)]*t[((K,10),(L,12),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,11),(K,10),)]*t[((J,9),(L,12),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,11),(K,10),)]*t[((J,9),(L,12),)]
                    # ({I}_{13}, {J}_{7}, {K}_{8}, {L}_{14})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,13),(J,7),)]*t[((K,8),(L,14),)]
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,13),(J,7),)]*t[((K,8),(L,14),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,13),(K,8),)]*t[((J,7),(L,14),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,13),(K,8),)]*t[((J,7),(L,14),)]
                    # ({I}_{11}, {J}_{9}, {K}_{8}, {L}_{14})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,0])]*r[I][4][11,0]*r[J][1][9,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,11),(J,9),)]*t[((K,8),(L,14),)]
                    # ({I}_{11}, {J}_{10}, {K}_{9}, {L}_{12})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,11),(J,10),)]*t[((K,9),(L,12),)]
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,11),(J,10),)]*t[((K,9),(L,12),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,11),(K,9),)]*t[((J,10),(L,12),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,11),(K,9),)]*t[((J,10),(L,12),)]
                    # ({I}_{13}, {J}_{8}, {K}_{7}, {L}_{14})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,13),(J,8),)]*t[((K,7),(L,14),)]
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,13),(J,8),)]*t[((K,7),(L,14),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,13),(K,7),)]*t[((J,8),(L,14),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,13),(K,7),)]*t[((J,8),(L,14),)]
                    # ({I}_{11}, {J}_{10}, {K}_{7}, {L}_{14})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,11),(J,10),)]*t[((K,7),(L,14),)]
                    # ({I}_{11}, {J}_{10}, {K}_{10}, {L}_{12})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,11),(J,10),)]*t[((K,10),(L,12),)]
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,11),(J,10),)]*t[((K,10),(L,12),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,11),(K,10),)]*t[((J,10),(L,12),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,11),(K,10),)]*t[((J,10),(L,12),)]
                    # ({I}_{13}, {J}_{8}, {K}_{8}, {L}_{14})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,13),(J,8),)]*t[((K,8),(L,14),)]
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,13),(J,8),)]*t[((K,8),(L,14),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,13),(K,8),)]*t[((J,8),(L,14),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,13),(K,8),)]*t[((J,8),(L,14),)]
                    # ({I}_{11}, {J}_{10}, {K}_{8}, {L}_{14})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,0])]*r[I][4][11,0]*r[J][5][10,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,11),(J,10),)]*t[((K,8),(L,14),)]
                    # ({I}_{11}, {J}_{9}, {K}_{9}, {L}_{11})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,11),(J,9),)]*t[((K,9),(L,11),)]
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,11),(J,9),)]*t[((K,9),(L,11),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,11),(K,9),)]*t[((J,9),(L,11),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,11),(K,9),)]*t[((J,9),(L,11),)]
                    # ({I}_{13}, {J}_{7}, {K}_{7}, {L}_{13})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,13),(J,7),)]*t[((K,7),(L,13),)]
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,13),(J,7),)]*t[((K,7),(L,13),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,13),(K,7),)]*t[((J,7),(L,13),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,13),(K,7),)]*t[((J,7),(L,13),)]
                    # ({I}_{11}, {J}_{9}, {K}_{7}, {L}_{13})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,11),(J,9),)]*t[((K,7),(L,13),)]
                    # ({I}_{11}, {J}_{9}, {K}_{10}, {L}_{11})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,11),(J,9),)]*t[((K,10),(L,11),)]
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,11),(J,9),)]*t[((K,10),(L,11),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,11),(K,10),)]*t[((J,9),(L,11),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,11),(K,10),)]*t[((J,9),(L,11),)]
                    # ({I}_{13}, {J}_{7}, {K}_{8}, {L}_{13})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,13),(J,7),)]*t[((K,8),(L,13),)]
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,13),(J,7),)]*t[((K,8),(L,13),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,13),(K,8),)]*t[((J,7),(L,13),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,13),(K,8),)]*t[((J,7),(L,13),)]
                    # ({I}_{11}, {J}_{9}, {K}_{8}, {L}_{13})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,1])]*r[I][4][11,0]*r[J][1][9,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,11),(J,9),)]*t[((K,8),(L,13),)]
                    # ({I}_{11}, {J}_{10}, {K}_{9}, {L}_{11})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,11),(J,10),)]*t[((K,9),(L,11),)]
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,11),(J,10),)]*t[((K,9),(L,11),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,11),(K,9),)]*t[((J,10),(L,11),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,11),(K,9),)]*t[((J,10),(L,11),)]
                    # ({I}_{13}, {J}_{8}, {K}_{7}, {L}_{13})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,13),(J,8),)]*t[((K,7),(L,13),)]
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,13),(J,8),)]*t[((K,7),(L,13),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,13),(K,7),)]*t[((J,8),(L,13),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,13),(K,7),)]*t[((J,8),(L,13),)]
                    # ({I}_{11}, {J}_{10}, {K}_{7}, {L}_{13})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,11),(J,10),)]*t[((K,7),(L,13),)]
                    # ({I}_{11}, {J}_{10}, {K}_{10}, {L}_{11})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,11),(J,10),)]*t[((K,10),(L,11),)]
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,11),(J,10),)]*t[((K,10),(L,11),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,11),(K,10),)]*t[((J,10),(L,11),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,11),(K,10),)]*t[((J,10),(L,11),)]
                    # ({I}_{13}, {J}_{8}, {K}_{8}, {L}_{13})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,13),(J,8),)]*t[((K,8),(L,13),)]
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,13),(J,8),)]*t[((K,8),(L,13),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,13),(K,8),)]*t[((J,8),(L,13),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,13),(K,8),)]*t[((J,8),(L,13),)]
                    # ({I}_{11}, {J}_{10}, {K}_{8}, {L}_{13})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,1])]*r[I][4][11,0]*r[J][5][10,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,11),(J,10),)]*t[((K,8),(L,13),)]
                    # ({I}_{12}, {J}_{7}, {K}_{9}, {L}_{14})
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,0])]*r[I][0][12,0]*r[J][3][7,0]*r[K][1][9,0]*r[L][2][14,0]*t[((I,12),(K,9),)]*t[((J,7),(L,14),)]
                    # ({I}_{12}, {J}_{8}, {K}_{9}, {L}_{14})
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,0])]*r[I][0][12,0]*r[J][7][8,0]*r[K][1][9,0]*r[L][2][14,0]*t[((I,12),(K,9),)]*t[((J,8),(L,14),)]
                    # ({I}_{12}, {J}_{7}, {K}_{10}, {L}_{14})
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,0])]*r[I][0][12,0]*r[J][3][7,0]*r[K][5][10,0]*r[L][2][14,0]*t[((I,12),(K,10),)]*t[((J,7),(L,14),)]
                    # ({I}_{12}, {J}_{8}, {K}_{10}, {L}_{14})
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,0])]*r[I][0][12,0]*r[J][7][8,0]*r[K][5][10,0]*r[L][2][14,0]*t[((I,12),(K,10),)]*t[((J,8),(L,14),)]
                    # ({I}_{12}, {J}_{7}, {K}_{9}, {L}_{13})
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,1])]*r[I][0][12,0]*r[J][3][7,0]*r[K][1][9,0]*r[L][6][13,0]*t[((I,12),(K,9),)]*t[((J,7),(L,13),)]
                    # ({I}_{12}, {J}_{8}, {K}_{9}, {L}_{13})
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,1])]*r[I][0][12,0]*r[J][7][8,0]*r[K][1][9,0]*r[L][6][13,0]*t[((I,12),(K,9),)]*t[((J,8),(L,13),)]
                    # ({I}_{12}, {J}_{7}, {K}_{10}, {L}_{13})
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,1])]*r[I][0][12,0]*r[J][3][7,0]*r[K][5][10,0]*r[L][6][13,0]*t[((I,12),(K,10),)]*t[((J,7),(L,13),)]
                    # ({I}_{12}, {J}_{8}, {K}_{10}, {L}_{13})
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,1])]*r[I][0][12,0]*r[J][7][8,0]*r[K][5][10,0]*r[L][6][13,0]*t[((I,12),(K,10),)]*t[((J,8),(L,13),)]
                    # ({I}_{11}, {J}_{7}, {K}_{9}, {L}_{14})
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,0])]*r[I][4][11,0]*r[J][3][7,0]*r[K][1][9,0]*r[L][2][14,0]*t[((I,11),(K,9),)]*t[((J,7),(L,14),)]
                    # ({I}_{11}, {J}_{8}, {K}_{9}, {L}_{14})
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,0])]*r[I][4][11,0]*r[J][7][8,0]*r[K][1][9,0]*r[L][2][14,0]*t[((I,11),(K,9),)]*t[((J,8),(L,14),)]
                    # ({I}_{11}, {J}_{7}, {K}_{10}, {L}_{14})
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,0])]*r[I][4][11,0]*r[J][3][7,0]*r[K][5][10,0]*r[L][2][14,0]*t[((I,11),(K,10),)]*t[((J,7),(L,14),)]
                    # ({I}_{11}, {J}_{8}, {K}_{10}, {L}_{14})
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,0])]*r[I][4][11,0]*r[J][7][8,0]*r[K][5][10,0]*r[L][2][14,0]*t[((I,11),(K,10),)]*t[((J,8),(L,14),)]
                    # ({I}_{11}, {J}_{7}, {K}_{9}, {L}_{13})
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,1])]*r[I][4][11,0]*r[J][3][7,0]*r[K][1][9,0]*r[L][6][13,0]*t[((I,11),(K,9),)]*t[((J,7),(L,13),)]
                    # ({I}_{11}, {J}_{8}, {K}_{9}, {L}_{13})
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,1])]*r[I][4][11,0]*r[J][7][8,0]*r[K][1][9,0]*r[L][6][13,0]*t[((I,11),(K,9),)]*t[((J,8),(L,13),)]
                    # ({I}_{11}, {J}_{7}, {K}_{10}, {L}_{13})
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,1])]*r[I][4][11,0]*r[J][3][7,0]*r[K][5][10,0]*r[L][6][13,0]*t[((I,11),(K,10),)]*t[((J,7),(L,13),)]
                    # ({I}_{11}, {J}_{8}, {K}_{10}, {L}_{13})
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,1])]*r[I][4][11,0]*r[J][7][8,0]*r[K][5][10,0]*r[L][6][13,0]*t[((I,11),(K,10),)]*t[((J,8),(L,13),)]
                    # ({I}_{14}, {J}_{12}, {K}_{9}, {L}_{7})
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,0])]*r[I][2][14,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][3][7,0]*t[((I,14),(L,7),)]*t[((J,12),(K,9),)]
                    # ({I}_{14}, {J}_{12}, {K}_{9}, {L}_{8})
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,0])]*r[I][2][14,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][7][8,0]*t[((I,14),(L,8),)]*t[((J,12),(K,9),)]
                    # ({I}_{14}, {J}_{12}, {K}_{10}, {L}_{7})
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,1])]*r[I][2][14,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][3][7,0]*t[((I,14),(L,7),)]*t[((J,12),(K,10),)]
                    # ({I}_{14}, {J}_{12}, {K}_{10}, {L}_{8})
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,1])]*r[I][2][14,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][7][8,0]*t[((I,14),(L,8),)]*t[((J,12),(K,10),)]
                    # ({I}_{13}, {J}_{12}, {K}_{9}, {L}_{7})
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,0])]*r[I][6][13,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][3][7,0]*t[((I,13),(L,7),)]*t[((J,12),(K,9),)]
                    # ({I}_{13}, {J}_{12}, {K}_{9}, {L}_{8})
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,0])]*r[I][6][13,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][7][8,0]*t[((I,13),(L,8),)]*t[((J,12),(K,9),)]
                    # ({I}_{13}, {J}_{12}, {K}_{10}, {L}_{7})
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,1])]*r[I][6][13,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][3][7,0]*t[((I,13),(L,7),)]*t[((J,12),(K,10),)]
                    # ({I}_{13}, {J}_{12}, {K}_{10}, {L}_{8})
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,1])]*r[I][6][13,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][7][8,0]*t[((I,13),(L,8),)]*t[((J,12),(K,10),)]
                    # ({I}_{14}, {J}_{11}, {K}_{9}, {L}_{7})
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,0])]*r[I][2][14,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][3][7,0]*t[((I,14),(L,7),)]*t[((J,11),(K,9),)]
                    # ({I}_{14}, {J}_{11}, {K}_{9}, {L}_{8})
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,0])]*r[I][2][14,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][7][8,0]*t[((I,14),(L,8),)]*t[((J,11),(K,9),)]
                    # ({I}_{14}, {J}_{11}, {K}_{10}, {L}_{7})
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,1])]*r[I][2][14,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][3][7,0]*t[((I,14),(L,7),)]*t[((J,11),(K,10),)]
                    # ({I}_{14}, {J}_{11}, {K}_{10}, {L}_{8})
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,1])]*r[I][2][14,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][7][8,0]*t[((I,14),(L,8),)]*t[((J,11),(K,10),)]
                    # ({I}_{13}, {J}_{11}, {K}_{9}, {L}_{7})
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,0])]*r[I][6][13,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][3][7,0]*t[((I,13),(L,7),)]*t[((J,11),(K,9),)]
                    # ({I}_{13}, {J}_{11}, {K}_{9}, {L}_{8})
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,0])]*r[I][6][13,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][7][8,0]*t[((I,13),(L,8),)]*t[((J,11),(K,9),)]
                    # ({I}_{13}, {J}_{11}, {K}_{10}, {L}_{7})
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,1])]*r[I][6][13,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][3][7,0]*t[((I,13),(L,7),)]*t[((J,11),(K,10),)]
                    # ({I}_{13}, {J}_{11}, {K}_{10}, {L}_{8})
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,1])]*r[I][6][13,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][7][8,0]*t[((I,13),(L,8),)]*t[((J,11),(K,10),)]
                    # ({I}_{14}, {J}_{12}, {K}_{7}, {L}_{9})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,0])]*r[I][2][14,0]*r[J][0][12,0]*r[K][3][7,0]*r[L][1][9,0]*t[((I,14),(K,7),)]*t[((J,12),(L,9),)]
                    # ({I}_{14}, {J}_{12}, {K}_{8}, {L}_{9})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,0])]*r[I][2][14,0]*r[J][0][12,0]*r[K][7][8,0]*r[L][1][9,0]*t[((I,14),(K,8),)]*t[((J,12),(L,9),)]
                    # ({I}_{14}, {J}_{12}, {K}_{7}, {L}_{10})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,1])]*r[I][2][14,0]*r[J][0][12,0]*r[K][3][7,0]*r[L][5][10,0]*t[((I,14),(K,7),)]*t[((J,12),(L,10),)]
                    # ({I}_{14}, {J}_{12}, {K}_{8}, {L}_{10})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,1])]*r[I][2][14,0]*r[J][0][12,0]*r[K][7][8,0]*r[L][5][10,0]*t[((I,14),(K,8),)]*t[((J,12),(L,10),)]
                    # ({I}_{13}, {J}_{12}, {K}_{7}, {L}_{9})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,0])]*r[I][6][13,0]*r[J][0][12,0]*r[K][3][7,0]*r[L][1][9,0]*t[((I,13),(K,7),)]*t[((J,12),(L,9),)]
                    # ({I}_{13}, {J}_{12}, {K}_{8}, {L}_{9})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,0])]*r[I][6][13,0]*r[J][0][12,0]*r[K][7][8,0]*r[L][1][9,0]*t[((I,13),(K,8),)]*t[((J,12),(L,9),)]
                    # ({I}_{13}, {J}_{12}, {K}_{7}, {L}_{10})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,1])]*r[I][6][13,0]*r[J][0][12,0]*r[K][3][7,0]*r[L][5][10,0]*t[((I,13),(K,7),)]*t[((J,12),(L,10),)]
                    # ({I}_{13}, {J}_{12}, {K}_{8}, {L}_{10})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,1])]*r[I][6][13,0]*r[J][0][12,0]*r[K][7][8,0]*r[L][5][10,0]*t[((I,13),(K,8),)]*t[((J,12),(L,10),)]
                    # ({I}_{14}, {J}_{11}, {K}_{7}, {L}_{9})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,0])]*r[I][2][14,0]*r[J][4][11,0]*r[K][3][7,0]*r[L][1][9,0]*t[((I,14),(K,7),)]*t[((J,11),(L,9),)]
                    # ({I}_{14}, {J}_{11}, {K}_{8}, {L}_{9})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,0])]*r[I][2][14,0]*r[J][4][11,0]*r[K][7][8,0]*r[L][1][9,0]*t[((I,14),(K,8),)]*t[((J,11),(L,9),)]
                    # ({I}_{14}, {J}_{11}, {K}_{7}, {L}_{10})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,1])]*r[I][2][14,0]*r[J][4][11,0]*r[K][3][7,0]*r[L][5][10,0]*t[((I,14),(K,7),)]*t[((J,11),(L,10),)]
                    # ({I}_{14}, {J}_{11}, {K}_{8}, {L}_{10})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,1])]*r[I][2][14,0]*r[J][4][11,0]*r[K][7][8,0]*r[L][5][10,0]*t[((I,14),(K,8),)]*t[((J,11),(L,10),)]
                    # ({I}_{13}, {J}_{11}, {K}_{7}, {L}_{9})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,0])]*r[I][6][13,0]*r[J][4][11,0]*r[K][3][7,0]*r[L][1][9,0]*t[((I,13),(K,7),)]*t[((J,11),(L,9),)]
                    # ({I}_{13}, {J}_{11}, {K}_{8}, {L}_{9})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,0])]*r[I][6][13,0]*r[J][4][11,0]*r[K][7][8,0]*r[L][1][9,0]*t[((I,13),(K,8),)]*t[((J,11),(L,9),)]
                    # ({I}_{13}, {J}_{11}, {K}_{7}, {L}_{10})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,1])]*r[I][6][13,0]*r[J][4][11,0]*r[K][3][7,0]*r[L][5][10,0]*t[((I,13),(K,7),)]*t[((J,11),(L,10),)]
                    # ({I}_{13}, {J}_{11}, {K}_{8}, {L}_{10})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,1])]*r[I][6][13,0]*r[J][4][11,0]*r[K][7][8,0]*r[L][5][10,0]*t[((I,13),(K,8),)]*t[((J,11),(L,10),)]
                    # ({I}_{9}, {J}_{12}, {K}_{12}, {L}_{9})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,9),(J,12),)]*t[((K,12),(L,9),)]
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,9),(J,12),)]*t[((K,12),(L,9),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,9),(K,12),)]*t[((J,12),(L,9),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,9),(K,12),)]*t[((J,12),(L,9),)]
                    # ({I}_{7}, {J}_{14}, {K}_{14}, {L}_{7})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,7),(J,14),)]*t[((K,14),(L,7),)]
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,7),(J,14),)]*t[((K,14),(L,7),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,7),(K,14),)]*t[((J,14),(L,7),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,7),(K,14),)]*t[((J,14),(L,7),)]
                    # ({I}_{9}, {J}_{12}, {K}_{14}, {L}_{7})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,9),(J,12),)]*t[((K,14),(L,7),)]
                    # ({I}_{9}, {J}_{12}, {K}_{12}, {L}_{10})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,9),(J,12),)]*t[((K,12),(L,10),)]
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,9),(J,12),)]*t[((K,12),(L,10),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,9),(K,12),)]*t[((J,12),(L,10),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,9),(K,12),)]*t[((J,12),(L,10),)]
                    # ({I}_{7}, {J}_{14}, {K}_{14}, {L}_{8})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,7),(J,14),)]*t[((K,14),(L,8),)]
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,7),(J,14),)]*t[((K,14),(L,8),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,7),(K,14),)]*t[((J,14),(L,8),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,7),(K,14),)]*t[((J,14),(L,8),)]
                    # ({I}_{9}, {J}_{12}, {K}_{14}, {L}_{8})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,9),(J,12),)]*t[((K,14),(L,8),)]
                    # ({I}_{10}, {J}_{12}, {K}_{12}, {L}_{9})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,10),(J,12),)]*t[((K,12),(L,9),)]
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,10),(J,12),)]*t[((K,12),(L,9),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,10),(K,12),)]*t[((J,12),(L,9),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,10),(K,12),)]*t[((J,12),(L,9),)]
                    # ({I}_{8}, {J}_{14}, {K}_{14}, {L}_{7})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,8),(J,14),)]*t[((K,14),(L,7),)]
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,8),(J,14),)]*t[((K,14),(L,7),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,8),(K,14),)]*t[((J,14),(L,7),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,8),(K,14),)]*t[((J,14),(L,7),)]
                    # ({I}_{10}, {J}_{12}, {K}_{14}, {L}_{7})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,10),(J,12),)]*t[((K,14),(L,7),)]
                    # ({I}_{10}, {J}_{12}, {K}_{12}, {L}_{10})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,10),(J,12),)]*t[((K,12),(L,10),)]
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,10),(J,12),)]*t[((K,12),(L,10),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,10),(K,12),)]*t[((J,12),(L,10),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,10),(K,12),)]*t[((J,12),(L,10),)]
                    # ({I}_{8}, {J}_{14}, {K}_{14}, {L}_{8})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,8),(J,14),)]*t[((K,14),(L,8),)]
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,8),(J,14),)]*t[((K,14),(L,8),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,8),(K,14),)]*t[((J,14),(L,8),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,8),(K,14),)]*t[((J,14),(L,8),)]
                    # ({I}_{10}, {J}_{12}, {K}_{14}, {L}_{8})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,10),(J,12),)]*t[((K,14),(L,8),)]
                    # ({I}_{9}, {J}_{12}, {K}_{11}, {L}_{9})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,9),(J,12),)]*t[((K,11),(L,9),)]
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,9),(J,12),)]*t[((K,11),(L,9),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,9),(K,11),)]*t[((J,12),(L,9),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,9),(K,11),)]*t[((J,12),(L,9),)]
                    # ({I}_{7}, {J}_{14}, {K}_{13}, {L}_{7})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,7),(J,14),)]*t[((K,13),(L,7),)]
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,7),(J,14),)]*t[((K,13),(L,7),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,7),(K,13),)]*t[((J,14),(L,7),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,7),(K,13),)]*t[((J,14),(L,7),)]
                    # ({I}_{9}, {J}_{12}, {K}_{13}, {L}_{7})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,9),(J,12),)]*t[((K,13),(L,7),)]
                    # ({I}_{9}, {J}_{12}, {K}_{11}, {L}_{10})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,9),(J,12),)]*t[((K,11),(L,10),)]
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,9),(J,12),)]*t[((K,11),(L,10),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,9),(K,11),)]*t[((J,12),(L,10),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,9),(K,11),)]*t[((J,12),(L,10),)]
                    # ({I}_{7}, {J}_{14}, {K}_{13}, {L}_{8})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,7),(J,14),)]*t[((K,13),(L,8),)]
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,7),(J,14),)]*t[((K,13),(L,8),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,7),(K,13),)]*t[((J,14),(L,8),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,7),(K,13),)]*t[((J,14),(L,8),)]
                    # ({I}_{9}, {J}_{12}, {K}_{13}, {L}_{8})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,9),(J,12),)]*t[((K,13),(L,8),)]
                    # ({I}_{10}, {J}_{12}, {K}_{11}, {L}_{9})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,10),(J,12),)]*t[((K,11),(L,9),)]
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,10),(J,12),)]*t[((K,11),(L,9),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,10),(K,11),)]*t[((J,12),(L,9),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,10),(K,11),)]*t[((J,12),(L,9),)]
                    # ({I}_{8}, {J}_{14}, {K}_{13}, {L}_{7})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,8),(J,14),)]*t[((K,13),(L,7),)]
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,8),(J,14),)]*t[((K,13),(L,7),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,8),(K,13),)]*t[((J,14),(L,7),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,8),(K,13),)]*t[((J,14),(L,7),)]
                    # ({I}_{10}, {J}_{12}, {K}_{13}, {L}_{7})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,10),(J,12),)]*t[((K,13),(L,7),)]
                    # ({I}_{10}, {J}_{12}, {K}_{11}, {L}_{10})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,10),(J,12),)]*t[((K,11),(L,10),)]
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,10),(J,12),)]*t[((K,11),(L,10),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,10),(K,11),)]*t[((J,12),(L,10),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,10),(K,11),)]*t[((J,12),(L,10),)]
                    # ({I}_{8}, {J}_{14}, {K}_{13}, {L}_{8})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,8),(J,14),)]*t[((K,13),(L,8),)]
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,8),(J,14),)]*t[((K,13),(L,8),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,8),(K,13),)]*t[((J,14),(L,8),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,8),(K,13),)]*t[((J,14),(L,8),)]
                    # ({I}_{10}, {J}_{12}, {K}_{13}, {L}_{8})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,10),(J,12),)]*t[((K,13),(L,8),)]
                    # ({I}_{9}, {J}_{11}, {K}_{12}, {L}_{9})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,9),(J,11),)]*t[((K,12),(L,9),)]
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,9),(J,11),)]*t[((K,12),(L,9),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,9),(K,12),)]*t[((J,11),(L,9),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,9),(K,12),)]*t[((J,11),(L,9),)]
                    # ({I}_{7}, {J}_{13}, {K}_{14}, {L}_{7})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,7),(J,13),)]*t[((K,14),(L,7),)]
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,7),(J,13),)]*t[((K,14),(L,7),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,7),(K,14),)]*t[((J,13),(L,7),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,7),(K,14),)]*t[((J,13),(L,7),)]
                    # ({I}_{9}, {J}_{11}, {K}_{14}, {L}_{7})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,9),(J,11),)]*t[((K,14),(L,7),)]
                    # ({I}_{9}, {J}_{11}, {K}_{12}, {L}_{10})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,9),(J,11),)]*t[((K,12),(L,10),)]
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,9),(J,11),)]*t[((K,12),(L,10),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,9),(K,12),)]*t[((J,11),(L,10),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,9),(K,12),)]*t[((J,11),(L,10),)]
                    # ({I}_{7}, {J}_{13}, {K}_{14}, {L}_{8})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,7),(J,13),)]*t[((K,14),(L,8),)]
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,7),(J,13),)]*t[((K,14),(L,8),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,7),(K,14),)]*t[((J,13),(L,8),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,7),(K,14),)]*t[((J,13),(L,8),)]
                    # ({I}_{9}, {J}_{11}, {K}_{14}, {L}_{8})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,9),(J,11),)]*t[((K,14),(L,8),)]
                    # ({I}_{10}, {J}_{11}, {K}_{12}, {L}_{9})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,10),(J,11),)]*t[((K,12),(L,9),)]
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,10),(J,11),)]*t[((K,12),(L,9),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,10),(K,12),)]*t[((J,11),(L,9),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,10),(K,12),)]*t[((J,11),(L,9),)]
                    # ({I}_{8}, {J}_{13}, {K}_{14}, {L}_{7})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,8),(J,13),)]*t[((K,14),(L,7),)]
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,8),(J,13),)]*t[((K,14),(L,7),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,8),(K,14),)]*t[((J,13),(L,7),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,8),(K,14),)]*t[((J,13),(L,7),)]
                    # ({I}_{10}, {J}_{11}, {K}_{14}, {L}_{7})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][2][14,0]*r[L][3][7,0]*t[((I,10),(J,11),)]*t[((K,14),(L,7),)]
                    # ({I}_{10}, {J}_{11}, {K}_{12}, {L}_{10})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,10),(J,11),)]*t[((K,12),(L,10),)]
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,10),(J,11),)]*t[((K,12),(L,10),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,10),(K,12),)]*t[((J,11),(L,10),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,10),(K,12),)]*t[((J,11),(L,10),)]
                    # ({I}_{8}, {J}_{13}, {K}_{14}, {L}_{8})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,8),(J,13),)]*t[((K,14),(L,8),)]
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,8),(J,13),)]*t[((K,14),(L,8),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,8),(K,14),)]*t[((J,13),(L,8),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,8),(K,14),)]*t[((J,13),(L,8),)]
                    # ({I}_{10}, {J}_{11}, {K}_{14}, {L}_{8})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][2][14,0]*r[L][7][8,0]*t[((I,10),(J,11),)]*t[((K,14),(L,8),)]
                    # ({I}_{9}, {J}_{11}, {K}_{11}, {L}_{9})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,9),(J,11),)]*t[((K,11),(L,9),)]
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,9),(J,11),)]*t[((K,11),(L,9),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,9),(K,11),)]*t[((J,11),(L,9),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,9),(K,11),)]*t[((J,11),(L,9),)]
                    # ({I}_{7}, {J}_{13}, {K}_{13}, {L}_{7})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,7),(J,13),)]*t[((K,13),(L,7),)]
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,7),(J,13),)]*t[((K,13),(L,7),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,7),(K,13),)]*t[((J,13),(L,7),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,7),(K,13),)]*t[((J,13),(L,7),)]
                    # ({I}_{9}, {J}_{11}, {K}_{13}, {L}_{7})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,9),(J,11),)]*t[((K,13),(L,7),)]
                    # ({I}_{9}, {J}_{11}, {K}_{11}, {L}_{10})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,9),(J,11),)]*t[((K,11),(L,10),)]
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,9),(J,11),)]*t[((K,11),(L,10),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,9),(K,11),)]*t[((J,11),(L,10),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,9),(K,11),)]*t[((J,11),(L,10),)]
                    # ({I}_{7}, {J}_{13}, {K}_{13}, {L}_{8})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,7),(J,13),)]*t[((K,13),(L,8),)]
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,7),(J,13),)]*t[((K,13),(L,8),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,7),(K,13),)]*t[((J,13),(L,8),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,7),(K,13),)]*t[((J,13),(L,8),)]
                    # ({I}_{9}, {J}_{11}, {K}_{13}, {L}_{8})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,9),(J,11),)]*t[((K,13),(L,8),)]
                    # ({I}_{10}, {J}_{11}, {K}_{11}, {L}_{9})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,10),(J,11),)]*t[((K,11),(L,9),)]
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,10),(J,11),)]*t[((K,11),(L,9),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,10),(K,11),)]*t[((J,11),(L,9),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,10),(K,11),)]*t[((J,11),(L,9),)]
                    # ({I}_{8}, {J}_{13}, {K}_{13}, {L}_{7})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,8),(J,13),)]*t[((K,13),(L,7),)]
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,8),(J,13),)]*t[((K,13),(L,7),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,8),(K,13),)]*t[((J,13),(L,7),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,8),(K,13),)]*t[((J,13),(L,7),)]
                    # ({I}_{10}, {J}_{11}, {K}_{13}, {L}_{7})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][6][13,0]*r[L][3][7,0]*t[((I,10),(J,11),)]*t[((K,13),(L,7),)]
                    # ({I}_{10}, {J}_{11}, {K}_{11}, {L}_{10})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,10),(J,11),)]*t[((K,11),(L,10),)]
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,10),(J,11),)]*t[((K,11),(L,10),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,10),(K,11),)]*t[((J,11),(L,10),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,10),(K,11),)]*t[((J,11),(L,10),)]
                    # ({I}_{8}, {J}_{13}, {K}_{13}, {L}_{8})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,8),(J,13),)]*t[((K,13),(L,8),)]
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,8),(J,13),)]*t[((K,13),(L,8),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,8),(K,13),)]*t[((J,13),(L,8),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,8),(K,13),)]*t[((J,13),(L,8),)]
                    # ({I}_{10}, {J}_{11}, {K}_{13}, {L}_{8})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][6][13,0]*r[L][7][8,0]*t[((I,10),(J,11),)]*t[((K,13),(L,8),)]
                    # ({I}_{7}, {J}_{12}, {K}_{14}, {L}_{9})
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,0])]*r[I][3][7,0]*r[J][0][12,0]*r[K][2][14,0]*r[L][1][9,0]*t[((I,7),(K,14),)]*t[((J,12),(L,9),)]
                    # ({I}_{8}, {J}_{12}, {K}_{14}, {L}_{9})
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,0])]*r[I][7][8,0]*r[J][0][12,0]*r[K][2][14,0]*r[L][1][9,0]*t[((I,8),(K,14),)]*t[((J,12),(L,9),)]
                    # ({I}_{7}, {J}_{12}, {K}_{14}, {L}_{10})
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,1])]*r[I][3][7,0]*r[J][0][12,0]*r[K][2][14,0]*r[L][5][10,0]*t[((I,7),(K,14),)]*t[((J,12),(L,10),)]
                    # ({I}_{8}, {J}_{12}, {K}_{14}, {L}_{10})
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,1])]*r[I][7][8,0]*r[J][0][12,0]*r[K][2][14,0]*r[L][5][10,0]*t[((I,8),(K,14),)]*t[((J,12),(L,10),)]
                    # ({I}_{7}, {J}_{12}, {K}_{13}, {L}_{9})
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,0])]*r[I][3][7,0]*r[J][0][12,0]*r[K][6][13,0]*r[L][1][9,0]*t[((I,7),(K,13),)]*t[((J,12),(L,9),)]
                    # ({I}_{8}, {J}_{12}, {K}_{13}, {L}_{9})
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,0])]*r[I][7][8,0]*r[J][0][12,0]*r[K][6][13,0]*r[L][1][9,0]*t[((I,8),(K,13),)]*t[((J,12),(L,9),)]
                    # ({I}_{7}, {J}_{12}, {K}_{13}, {L}_{10})
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,1])]*r[I][3][7,0]*r[J][0][12,0]*r[K][6][13,0]*r[L][5][10,0]*t[((I,7),(K,13),)]*t[((J,12),(L,10),)]
                    # ({I}_{8}, {J}_{12}, {K}_{13}, {L}_{10})
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,1])]*r[I][7][8,0]*r[J][0][12,0]*r[K][6][13,0]*r[L][5][10,0]*t[((I,8),(K,13),)]*t[((J,12),(L,10),)]
                    # ({I}_{7}, {J}_{11}, {K}_{14}, {L}_{9})
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,0])]*r[I][3][7,0]*r[J][4][11,0]*r[K][2][14,0]*r[L][1][9,0]*t[((I,7),(K,14),)]*t[((J,11),(L,9),)]
                    # ({I}_{8}, {J}_{11}, {K}_{14}, {L}_{9})
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,0])]*r[I][7][8,0]*r[J][4][11,0]*r[K][2][14,0]*r[L][1][9,0]*t[((I,8),(K,14),)]*t[((J,11),(L,9),)]
                    # ({I}_{7}, {J}_{11}, {K}_{14}, {L}_{10})
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,1])]*r[I][3][7,0]*r[J][4][11,0]*r[K][2][14,0]*r[L][5][10,0]*t[((I,7),(K,14),)]*t[((J,11),(L,10),)]
                    # ({I}_{8}, {J}_{11}, {K}_{14}, {L}_{10})
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,1])]*r[I][7][8,0]*r[J][4][11,0]*r[K][2][14,0]*r[L][5][10,0]*t[((I,8),(K,14),)]*t[((J,11),(L,10),)]
                    # ({I}_{7}, {J}_{11}, {K}_{13}, {L}_{9})
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,0])]*r[I][3][7,0]*r[J][4][11,0]*r[K][6][13,0]*r[L][1][9,0]*t[((I,7),(K,13),)]*t[((J,11),(L,9),)]
                    # ({I}_{8}, {J}_{11}, {K}_{13}, {L}_{9})
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,0])]*r[I][7][8,0]*r[J][4][11,0]*r[K][6][13,0]*r[L][1][9,0]*t[((I,8),(K,13),)]*t[((J,11),(L,9),)]
                    # ({I}_{7}, {J}_{11}, {K}_{13}, {L}_{10})
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,1])]*r[I][3][7,0]*r[J][4][11,0]*r[K][6][13,0]*r[L][5][10,0]*t[((I,7),(K,13),)]*t[((J,11),(L,10),)]
                    # ({I}_{8}, {J}_{11}, {K}_{13}, {L}_{10})
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,1])]*r[I][7][8,0]*r[J][4][11,0]*r[K][6][13,0]*r[L][5][10,0]*t[((I,8),(K,13),)]*t[((J,11),(L,10),)]
                    # ({I}_{9}, {J}_{12}, {K}_{9}, {L}_{12})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,9),(J,12),)]*t[((K,9),(L,12),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,9),(J,12),)]*t[((K,9),(L,12),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,9),(L,12),)]*t[((J,12),(K,9),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,9),(L,12),)]*t[((J,12),(K,9),)]
                    # ({I}_{7}, {J}_{14}, {K}_{7}, {L}_{14})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,7),(J,14),)]*t[((K,7),(L,14),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,7),(J,14),)]*t[((K,7),(L,14),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,7),(L,14),)]*t[((J,14),(K,7),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,7),(L,14),)]*t[((J,14),(K,7),)]
                    # ({I}_{9}, {J}_{12}, {K}_{7}, {L}_{14})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,9),(J,12),)]*t[((K,7),(L,14),)]
                    # ({I}_{9}, {J}_{12}, {K}_{10}, {L}_{12})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,9),(J,12),)]*t[((K,10),(L,12),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,9),(J,12),)]*t[((K,10),(L,12),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,9),(L,12),)]*t[((J,12),(K,10),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,9),(L,12),)]*t[((J,12),(K,10),)]
                    # ({I}_{7}, {J}_{14}, {K}_{8}, {L}_{14})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,7),(J,14),)]*t[((K,8),(L,14),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,7),(J,14),)]*t[((K,8),(L,14),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,7),(L,14),)]*t[((J,14),(K,8),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,7),(L,14),)]*t[((J,14),(K,8),)]
                    # ({I}_{9}, {J}_{12}, {K}_{8}, {L}_{14})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,9),(J,12),)]*t[((K,8),(L,14),)]
                    # ({I}_{10}, {J}_{12}, {K}_{9}, {L}_{12})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,10),(J,12),)]*t[((K,9),(L,12),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,10),(J,12),)]*t[((K,9),(L,12),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,10),(L,12),)]*t[((J,12),(K,9),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,10),(L,12),)]*t[((J,12),(K,9),)]
                    # ({I}_{8}, {J}_{14}, {K}_{7}, {L}_{14})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,8),(J,14),)]*t[((K,7),(L,14),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,8),(J,14),)]*t[((K,7),(L,14),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,8),(L,14),)]*t[((J,14),(K,7),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,8),(L,14),)]*t[((J,14),(K,7),)]
                    # ({I}_{10}, {J}_{12}, {K}_{7}, {L}_{14})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,10),(J,12),)]*t[((K,7),(L,14),)]
                    # ({I}_{10}, {J}_{12}, {K}_{10}, {L}_{12})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,10),(J,12),)]*t[((K,10),(L,12),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,10),(J,12),)]*t[((K,10),(L,12),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,10),(L,12),)]*t[((J,12),(K,10),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,10),(L,12),)]*t[((J,12),(K,10),)]
                    # ({I}_{8}, {J}_{14}, {K}_{8}, {L}_{14})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,8),(J,14),)]*t[((K,8),(L,14),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,8),(J,14),)]*t[((K,8),(L,14),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,8),(L,14),)]*t[((J,14),(K,8),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,8),(L,14),)]*t[((J,14),(K,8),)]
                    # ({I}_{10}, {J}_{12}, {K}_{8}, {L}_{14})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,10),(J,12),)]*t[((K,8),(L,14),)]
                    # ({I}_{9}, {J}_{12}, {K}_{9}, {L}_{11})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,9),(J,12),)]*t[((K,9),(L,11),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,9),(J,12),)]*t[((K,9),(L,11),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,9),(L,11),)]*t[((J,12),(K,9),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,0])]*r[I][1][9,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,9),(L,11),)]*t[((J,12),(K,9),)]
                    # ({I}_{7}, {J}_{14}, {K}_{7}, {L}_{13})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,7),(J,14),)]*t[((K,7),(L,13),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,7),(J,14),)]*t[((K,7),(L,13),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,7),(L,13),)]*t[((J,14),(K,7),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,7),(L,13),)]*t[((J,14),(K,7),)]
                    # ({I}_{9}, {J}_{12}, {K}_{7}, {L}_{13})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,9),(J,12),)]*t[((K,7),(L,13),)]
                    # ({I}_{9}, {J}_{12}, {K}_{10}, {L}_{11})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,9),(J,12),)]*t[((K,10),(L,11),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,9),(J,12),)]*t[((K,10),(L,11),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,9),(L,11),)]*t[((J,12),(K,10),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,9),(L,11),)]*t[((J,12),(K,10),)]
                    # ({I}_{7}, {J}_{14}, {K}_{8}, {L}_{13})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,7),(J,14),)]*t[((K,8),(L,13),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,7),(J,14),)]*t[((K,8),(L,13),)]
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,7),(L,13),)]*t[((J,14),(K,8),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,7),(L,13),)]*t[((J,14),(K,8),)]
                    # ({I}_{9}, {J}_{12}, {K}_{8}, {L}_{13})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,1])]*r[I][1][9,0]*r[J][0][12,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,9),(J,12),)]*t[((K,8),(L,13),)]
                    # ({I}_{10}, {J}_{12}, {K}_{9}, {L}_{11})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,10),(J,12),)]*t[((K,9),(L,11),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,10),(J,12),)]*t[((K,9),(L,11),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,10),(L,11),)]*t[((J,12),(K,9),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,0])]*r[I][5][10,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,10),(L,11),)]*t[((J,12),(K,9),)]
                    # ({I}_{8}, {J}_{14}, {K}_{7}, {L}_{13})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,8),(J,14),)]*t[((K,7),(L,13),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,8),(J,14),)]*t[((K,7),(L,13),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,8),(L,13),)]*t[((J,14),(K,7),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,8),(L,13),)]*t[((J,14),(K,7),)]
                    # ({I}_{10}, {J}_{12}, {K}_{7}, {L}_{13})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,10),(J,12),)]*t[((K,7),(L,13),)]
                    # ({I}_{10}, {J}_{12}, {K}_{10}, {L}_{11})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,10),(J,12),)]*t[((K,10),(L,11),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,10),(J,12),)]*t[((K,10),(L,11),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,10),(L,11),)]*t[((J,12),(K,10),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,10),(L,11),)]*t[((J,12),(K,10),)]
                    # ({I}_{8}, {J}_{14}, {K}_{8}, {L}_{13})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,8),(J,14),)]*t[((K,8),(L,13),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,8),(J,14),)]*t[((K,8),(L,13),)]
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,8),(L,13),)]*t[((J,14),(K,8),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,8),(L,13),)]*t[((J,14),(K,8),)]
                    # ({I}_{10}, {J}_{12}, {K}_{8}, {L}_{13})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,1])]*r[I][5][10,0]*r[J][0][12,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,10),(J,12),)]*t[((K,8),(L,13),)]
                    # ({I}_{9}, {J}_{11}, {K}_{9}, {L}_{12})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,9),(J,11),)]*t[((K,9),(L,12),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,9),(J,11),)]*t[((K,9),(L,12),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,9),(L,12),)]*t[((J,11),(K,9),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,9),(L,12),)]*t[((J,11),(K,9),)]
                    # ({I}_{7}, {J}_{13}, {K}_{7}, {L}_{14})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,7),(J,13),)]*t[((K,7),(L,14),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,7),(J,13),)]*t[((K,7),(L,14),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,7),(L,14),)]*t[((J,13),(K,7),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,7),(L,14),)]*t[((J,13),(K,7),)]
                    # ({I}_{9}, {J}_{11}, {K}_{7}, {L}_{14})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,9),(J,11),)]*t[((K,7),(L,14),)]
                    # ({I}_{9}, {J}_{11}, {K}_{10}, {L}_{12})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,9),(J,11),)]*t[((K,10),(L,12),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,9),(J,11),)]*t[((K,10),(L,12),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,9),(L,12),)]*t[((J,11),(K,10),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,9),(L,12),)]*t[((J,11),(K,10),)]
                    # ({I}_{7}, {J}_{13}, {K}_{8}, {L}_{14})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,7),(J,13),)]*t[((K,8),(L,14),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,7),(J,13),)]*t[((K,8),(L,14),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,7),(L,14),)]*t[((J,13),(K,8),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,7),(L,14),)]*t[((J,13),(K,8),)]
                    # ({I}_{9}, {J}_{11}, {K}_{8}, {L}_{14})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,9),(J,11),)]*t[((K,8),(L,14),)]
                    # ({I}_{10}, {J}_{11}, {K}_{9}, {L}_{12})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,10),(J,11),)]*t[((K,9),(L,12),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,10),(J,11),)]*t[((K,9),(L,12),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,10),(L,12),)]*t[((J,11),(K,9),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,10),(L,12),)]*t[((J,11),(K,9),)]
                    # ({I}_{8}, {J}_{13}, {K}_{7}, {L}_{14})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,8),(J,13),)]*t[((K,7),(L,14),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,8),(J,13),)]*t[((K,7),(L,14),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,8),(L,14),)]*t[((J,13),(K,7),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,8),(L,14),)]*t[((J,13),(K,7),)]
                    # ({I}_{10}, {J}_{11}, {K}_{7}, {L}_{14})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][3][7,0]*r[L][2][14,0]*t[((I,10),(J,11),)]*t[((K,7),(L,14),)]
                    # ({I}_{10}, {J}_{11}, {K}_{10}, {L}_{12})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,10),(J,11),)]*t[((K,10),(L,12),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,10),(J,11),)]*t[((K,10),(L,12),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,10),(L,12),)]*t[((J,11),(K,10),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,10),(L,12),)]*t[((J,11),(K,10),)]
                    # ({I}_{8}, {J}_{13}, {K}_{8}, {L}_{14})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,8),(J,13),)]*t[((K,8),(L,14),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,8),(J,13),)]*t[((K,8),(L,14),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,8),(L,14),)]*t[((J,13),(K,8),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,8),(L,14),)]*t[((J,13),(K,8),)]
                    # ({I}_{10}, {J}_{11}, {K}_{8}, {L}_{14})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][7][8,0]*r[L][2][14,0]*t[((I,10),(J,11),)]*t[((K,8),(L,14),)]
                    # ({I}_{9}, {J}_{11}, {K}_{9}, {L}_{11})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,9),(J,11),)]*t[((K,9),(L,11),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,9),(J,11),)]*t[((K,9),(L,11),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,9),(L,11),)]*t[((J,11),(K,9),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,0])]*r[I][1][9,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,9),(L,11),)]*t[((J,11),(K,9),)]
                    # ({I}_{7}, {J}_{13}, {K}_{7}, {L}_{13})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,7),(J,13),)]*t[((K,7),(L,13),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,7),(J,13),)]*t[((K,7),(L,13),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,7),(L,13),)]*t[((J,13),(K,7),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,7),(L,13),)]*t[((J,13),(K,7),)]
                    # ({I}_{9}, {J}_{11}, {K}_{7}, {L}_{13})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,9),(J,11),)]*t[((K,7),(L,13),)]
                    # ({I}_{9}, {J}_{11}, {K}_{10}, {L}_{11})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,9),(J,11),)]*t[((K,10),(L,11),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,9),(J,11),)]*t[((K,10),(L,11),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,9),(L,11),)]*t[((J,11),(K,10),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,9),(L,11),)]*t[((J,11),(K,10),)]
                    # ({I}_{7}, {J}_{13}, {K}_{8}, {L}_{13})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,7),(J,13),)]*t[((K,8),(L,13),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,7),(J,13),)]*t[((K,8),(L,13),)]
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,7),(L,13),)]*t[((J,13),(K,8),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,7),(L,13),)]*t[((J,13),(K,8),)]
                    # ({I}_{9}, {J}_{11}, {K}_{8}, {L}_{13})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,1])]*r[I][1][9,0]*r[J][4][11,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,9),(J,11),)]*t[((K,8),(L,13),)]
                    # ({I}_{10}, {J}_{11}, {K}_{9}, {L}_{11})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,10),(J,11),)]*t[((K,9),(L,11),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,10),(J,11),)]*t[((K,9),(L,11),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,10),(L,11),)]*t[((J,11),(K,9),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,0])]*r[I][5][10,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,10),(L,11),)]*t[((J,11),(K,9),)]
                    # ({I}_{8}, {J}_{13}, {K}_{7}, {L}_{13})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,8),(J,13),)]*t[((K,7),(L,13),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,8),(J,13),)]*t[((K,7),(L,13),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,8),(L,13),)]*t[((J,13),(K,7),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,8),(L,13),)]*t[((J,13),(K,7),)]
                    # ({I}_{10}, {J}_{11}, {K}_{7}, {L}_{13})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][3][7,0]*r[L][6][13,0]*t[((I,10),(J,11),)]*t[((K,7),(L,13),)]
                    # ({I}_{10}, {J}_{11}, {K}_{10}, {L}_{11})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,10),(J,11),)]*t[((K,10),(L,11),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,10),(J,11),)]*t[((K,10),(L,11),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,10),(L,11),)]*t[((J,11),(K,10),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,10),(L,11),)]*t[((J,11),(K,10),)]
                    # ({I}_{8}, {J}_{13}, {K}_{8}, {L}_{13})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,8),(J,13),)]*t[((K,8),(L,13),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,8),(J,13),)]*t[((K,8),(L,13),)]
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,8),(L,13),)]*t[((J,13),(K,8),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,8),(L,13),)]*t[((J,13),(K,8),)]
                    # ({I}_{10}, {J}_{11}, {K}_{8}, {L}_{13})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,1])]*r[I][5][10,0]*r[J][4][11,0]*r[K][7][8,0]*r[L][6][13,0]*t[((I,10),(J,11),)]*t[((K,8),(L,13),)]
                    # ({I}_{7}, {J}_{12}, {K}_{9}, {L}_{14})
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,0])]*r[I][3][7,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][2][14,0]*t[((I,7),(L,14),)]*t[((J,12),(K,9),)]
                    # ({I}_{8}, {J}_{12}, {K}_{9}, {L}_{14})
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,0])]*r[I][7][8,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][2][14,0]*t[((I,8),(L,14),)]*t[((J,12),(K,9),)]
                    # ({I}_{7}, {J}_{12}, {K}_{10}, {L}_{14})
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,1])]*r[I][3][7,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][2][14,0]*t[((I,7),(L,14),)]*t[((J,12),(K,10),)]
                    # ({I}_{8}, {J}_{12}, {K}_{10}, {L}_{14})
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,1])]*r[I][7][8,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][2][14,0]*t[((I,8),(L,14),)]*t[((J,12),(K,10),)]
                    # ({I}_{7}, {J}_{12}, {K}_{9}, {L}_{13})
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,0])]*r[I][3][7,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][6][13,0]*t[((I,7),(L,13),)]*t[((J,12),(K,9),)]
                    # ({I}_{8}, {J}_{12}, {K}_{9}, {L}_{13})
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,0])]*r[I][7][8,0]*r[J][0][12,0]*r[K][1][9,0]*r[L][6][13,0]*t[((I,8),(L,13),)]*t[((J,12),(K,9),)]
                    # ({I}_{7}, {J}_{12}, {K}_{10}, {L}_{13})
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,1])]*r[I][3][7,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][6][13,0]*t[((I,7),(L,13),)]*t[((J,12),(K,10),)]
                    # ({I}_{8}, {J}_{12}, {K}_{10}, {L}_{13})
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,1])]*r[I][7][8,0]*r[J][0][12,0]*r[K][5][10,0]*r[L][6][13,0]*t[((I,8),(L,13),)]*t[((J,12),(K,10),)]
                    # ({I}_{7}, {J}_{11}, {K}_{9}, {L}_{14})
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,0])]*r[I][3][7,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][2][14,0]*t[((I,7),(L,14),)]*t[((J,11),(K,9),)]
                    # ({I}_{8}, {J}_{11}, {K}_{9}, {L}_{14})
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,0])]*r[I][7][8,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][2][14,0]*t[((I,8),(L,14),)]*t[((J,11),(K,9),)]
                    # ({I}_{7}, {J}_{11}, {K}_{10}, {L}_{14})
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,1])]*r[I][3][7,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][2][14,0]*t[((I,7),(L,14),)]*t[((J,11),(K,10),)]
                    # ({I}_{8}, {J}_{11}, {K}_{10}, {L}_{14})
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,1])]*r[I][7][8,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][2][14,0]*t[((I,8),(L,14),)]*t[((J,11),(K,10),)]
                    # ({I}_{7}, {J}_{11}, {K}_{9}, {L}_{13})
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,0])]*r[I][3][7,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][6][13,0]*t[((I,7),(L,13),)]*t[((J,11),(K,9),)]
                    # ({I}_{8}, {J}_{11}, {K}_{9}, {L}_{13})
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,0])]*r[I][7][8,0]*r[J][4][11,0]*r[K][1][9,0]*r[L][6][13,0]*t[((I,8),(L,13),)]*t[((J,11),(K,9),)]
                    # ({I}_{7}, {J}_{11}, {K}_{10}, {L}_{13})
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,1])]*r[I][3][7,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][6][13,0]*t[((I,7),(L,13),)]*t[((J,11),(K,10),)]
                    # ({I}_{8}, {J}_{11}, {K}_{10}, {L}_{13})
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,1])]*r[I][7][8,0]*r[J][4][11,0]*r[K][5][10,0]*r[L][6][13,0]*t[((I,8),(L,13),)]*t[((J,11),(K,10),)]
                    # ({I}_{14}, {J}_{9}, {K}_{12}, {L}_{7})
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,0])]*r[I][2][14,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][3][7,0]*t[((I,14),(L,7),)]*t[((J,9),(K,12),)]
                    # ({I}_{14}, {J}_{9}, {K}_{12}, {L}_{8})
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,0])]*r[I][2][14,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][7][8,0]*t[((I,14),(L,8),)]*t[((J,9),(K,12),)]
                    # ({I}_{14}, {J}_{10}, {K}_{12}, {L}_{7})
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,0])]*r[I][2][14,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][3][7,0]*t[((I,14),(L,7),)]*t[((J,10),(K,12),)]
                    # ({I}_{14}, {J}_{10}, {K}_{12}, {L}_{8})
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,0])]*r[I][2][14,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][7][8,0]*t[((I,14),(L,8),)]*t[((J,10),(K,12),)]
                    # ({I}_{13}, {J}_{9}, {K}_{12}, {L}_{7})
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,0])]*r[I][6][13,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][3][7,0]*t[((I,13),(L,7),)]*t[((J,9),(K,12),)]
                    # ({I}_{13}, {J}_{9}, {K}_{12}, {L}_{8})
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,0])]*r[I][6][13,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][7][8,0]*t[((I,13),(L,8),)]*t[((J,9),(K,12),)]
                    # ({I}_{13}, {J}_{10}, {K}_{12}, {L}_{7})
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,0])]*r[I][6][13,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][3][7,0]*t[((I,13),(L,7),)]*t[((J,10),(K,12),)]
                    # ({I}_{13}, {J}_{10}, {K}_{12}, {L}_{8})
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,0])]*r[I][6][13,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][7][8,0]*t[((I,13),(L,8),)]*t[((J,10),(K,12),)]
                    # ({I}_{14}, {J}_{9}, {K}_{11}, {L}_{7})
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,1])]*r[I][2][14,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][3][7,0]*t[((I,14),(L,7),)]*t[((J,9),(K,11),)]
                    # ({I}_{14}, {J}_{9}, {K}_{11}, {L}_{8})
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,1])]*r[I][2][14,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][7][8,0]*t[((I,14),(L,8),)]*t[((J,9),(K,11),)]
                    # ({I}_{14}, {J}_{10}, {K}_{11}, {L}_{7})
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,1])]*r[I][2][14,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][3][7,0]*t[((I,14),(L,7),)]*t[((J,10),(K,11),)]
                    # ({I}_{14}, {J}_{10}, {K}_{11}, {L}_{8})
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,1])]*r[I][2][14,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][7][8,0]*t[((I,14),(L,8),)]*t[((J,10),(K,11),)]
                    # ({I}_{13}, {J}_{9}, {K}_{11}, {L}_{7})
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,1])]*r[I][6][13,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][3][7,0]*t[((I,13),(L,7),)]*t[((J,9),(K,11),)]
                    # ({I}_{13}, {J}_{9}, {K}_{11}, {L}_{8})
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,1])]*r[I][6][13,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][7][8,0]*t[((I,13),(L,8),)]*t[((J,9),(K,11),)]
                    # ({I}_{13}, {J}_{10}, {K}_{11}, {L}_{7})
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,1])]*r[I][6][13,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][3][7,0]*t[((I,13),(L,7),)]*t[((J,10),(K,11),)]
                    # ({I}_{13}, {J}_{10}, {K}_{11}, {L}_{8})
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,1])]*r[I][6][13,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][7][8,0]*t[((I,13),(L,8),)]*t[((J,10),(K,11),)]
                    # ({I}_{14}, {J}_{7}, {K}_{12}, {L}_{9})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,14),(J,7),)]*t[((K,12),(L,9),)]
                    # ({I}_{14}, {J}_{8}, {K}_{12}, {L}_{9})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,14),(J,8),)]*t[((K,12),(L,9),)]
                    # ({I}_{14}, {J}_{7}, {K}_{12}, {L}_{10})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,14),(J,7),)]*t[((K,12),(L,10),)]
                    # ({I}_{14}, {J}_{8}, {K}_{12}, {L}_{10})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,14),(J,8),)]*t[((K,12),(L,10),)]
                    # ({I}_{13}, {J}_{7}, {K}_{12}, {L}_{9})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,13),(J,7),)]*t[((K,12),(L,9),)]
                    # ({I}_{13}, {J}_{8}, {K}_{12}, {L}_{9})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,13),(J,8),)]*t[((K,12),(L,9),)]
                    # ({I}_{13}, {J}_{7}, {K}_{12}, {L}_{10})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,13),(J,7),)]*t[((K,12),(L,10),)]
                    # ({I}_{13}, {J}_{8}, {K}_{12}, {L}_{10})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,13),(J,8),)]*t[((K,12),(L,10),)]
                    # ({I}_{14}, {J}_{7}, {K}_{11}, {L}_{9})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,14),(J,7),)]*t[((K,11),(L,9),)]
                    # ({I}_{14}, {J}_{8}, {K}_{11}, {L}_{9})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,14),(J,8),)]*t[((K,11),(L,9),)]
                    # ({I}_{14}, {J}_{7}, {K}_{11}, {L}_{10})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,14),(J,7),)]*t[((K,11),(L,10),)]
                    # ({I}_{14}, {J}_{8}, {K}_{11}, {L}_{10})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,14),(J,8),)]*t[((K,11),(L,10),)]
                    # ({I}_{13}, {J}_{7}, {K}_{11}, {L}_{9})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,13),(J,7),)]*t[((K,11),(L,9),)]
                    # ({I}_{13}, {J}_{8}, {K}_{11}, {L}_{9})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,13),(J,8),)]*t[((K,11),(L,9),)]
                    # ({I}_{13}, {J}_{7}, {K}_{11}, {L}_{10})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,13),(J,7),)]*t[((K,11),(L,10),)]
                    # ({I}_{13}, {J}_{8}, {K}_{11}, {L}_{10})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,13),(J,8),)]*t[((K,11),(L,10),)]
                    # ({I}_{9}, {J}_{14}, {K}_{12}, {L}_{7})
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,0])]*r[I][1][9,0]*r[J][2][14,0]*r[K][0][12,0]*r[L][3][7,0]*t[((I,9),(K,12),)]*t[((J,14),(L,7),)]
                    # ({I}_{9}, {J}_{14}, {K}_{12}, {L}_{8})
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,1])]*r[I][1][9,0]*r[J][2][14,0]*r[K][0][12,0]*r[L][7][8,0]*t[((I,9),(K,12),)]*t[((J,14),(L,8),)]
                    # ({I}_{10}, {J}_{14}, {K}_{12}, {L}_{7})
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,0])]*r[I][5][10,0]*r[J][2][14,0]*r[K][0][12,0]*r[L][3][7,0]*t[((I,10),(K,12),)]*t[((J,14),(L,7),)]
                    # ({I}_{10}, {J}_{14}, {K}_{12}, {L}_{8})
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,1])]*r[I][5][10,0]*r[J][2][14,0]*r[K][0][12,0]*r[L][7][8,0]*t[((I,10),(K,12),)]*t[((J,14),(L,8),)]
                    # ({I}_{9}, {J}_{13}, {K}_{12}, {L}_{7})
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,0])]*r[I][1][9,0]*r[J][6][13,0]*r[K][0][12,0]*r[L][3][7,0]*t[((I,9),(K,12),)]*t[((J,13),(L,7),)]
                    # ({I}_{9}, {J}_{13}, {K}_{12}, {L}_{8})
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,1])]*r[I][1][9,0]*r[J][6][13,0]*r[K][0][12,0]*r[L][7][8,0]*t[((I,9),(K,12),)]*t[((J,13),(L,8),)]
                    # ({I}_{10}, {J}_{13}, {K}_{12}, {L}_{7})
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,0])]*r[I][5][10,0]*r[J][6][13,0]*r[K][0][12,0]*r[L][3][7,0]*t[((I,10),(K,12),)]*t[((J,13),(L,7),)]
                    # ({I}_{10}, {J}_{13}, {K}_{12}, {L}_{8})
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,1])]*r[I][5][10,0]*r[J][6][13,0]*r[K][0][12,0]*r[L][7][8,0]*t[((I,10),(K,12),)]*t[((J,13),(L,8),)]
                    # ({I}_{9}, {J}_{14}, {K}_{11}, {L}_{7})
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,0])]*r[I][1][9,0]*r[J][2][14,0]*r[K][4][11,0]*r[L][3][7,0]*t[((I,9),(K,11),)]*t[((J,14),(L,7),)]
                    # ({I}_{9}, {J}_{14}, {K}_{11}, {L}_{8})
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,1])]*r[I][1][9,0]*r[J][2][14,0]*r[K][4][11,0]*r[L][7][8,0]*t[((I,9),(K,11),)]*t[((J,14),(L,8),)]
                    # ({I}_{10}, {J}_{14}, {K}_{11}, {L}_{7})
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,0])]*r[I][5][10,0]*r[J][2][14,0]*r[K][4][11,0]*r[L][3][7,0]*t[((I,10),(K,11),)]*t[((J,14),(L,7),)]
                    # ({I}_{10}, {J}_{14}, {K}_{11}, {L}_{8})
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,1])]*r[I][5][10,0]*r[J][2][14,0]*r[K][4][11,0]*r[L][7][8,0]*t[((I,10),(K,11),)]*t[((J,14),(L,8),)]
                    # ({I}_{9}, {J}_{13}, {K}_{11}, {L}_{7})
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,0])]*r[I][1][9,0]*r[J][6][13,0]*r[K][4][11,0]*r[L][3][7,0]*t[((I,9),(K,11),)]*t[((J,13),(L,7),)]
                    # ({I}_{9}, {J}_{13}, {K}_{11}, {L}_{8})
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,1])]*r[I][1][9,0]*r[J][6][13,0]*r[K][4][11,0]*r[L][7][8,0]*t[((I,9),(K,11),)]*t[((J,13),(L,8),)]
                    # ({I}_{10}, {J}_{13}, {K}_{11}, {L}_{7})
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,0])]*r[I][5][10,0]*r[J][6][13,0]*r[K][4][11,0]*r[L][3][7,0]*t[((I,10),(K,11),)]*t[((J,13),(L,7),)]
                    # ({I}_{10}, {J}_{13}, {K}_{11}, {L}_{8})
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,1])]*r[I][5][10,0]*r[J][6][13,0]*r[K][4][11,0]*r[L][7][8,0]*t[((I,10),(K,11),)]*t[((J,13),(L,8),)]
                    # ({I}_{7}, {J}_{14}, {K}_{12}, {L}_{9})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,7),(J,14),)]*t[((K,12),(L,9),)]
                    # ({I}_{8}, {J}_{14}, {K}_{12}, {L}_{9})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,8),(J,14),)]*t[((K,12),(L,9),)]
                    # ({I}_{7}, {J}_{14}, {K}_{12}, {L}_{10})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,7),(J,14),)]*t[((K,12),(L,10),)]
                    # ({I}_{8}, {J}_{14}, {K}_{12}, {L}_{10})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,8),(J,14),)]*t[((K,12),(L,10),)]
                    # ({I}_{7}, {J}_{13}, {K}_{12}, {L}_{9})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,7),(J,13),)]*t[((K,12),(L,9),)]
                    # ({I}_{8}, {J}_{13}, {K}_{12}, {L}_{9})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][0][12,0]*r[L][1][9,0]*t[((I,8),(J,13),)]*t[((K,12),(L,9),)]
                    # ({I}_{7}, {J}_{13}, {K}_{12}, {L}_{10})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,7),(J,13),)]*t[((K,12),(L,10),)]
                    # ({I}_{8}, {J}_{13}, {K}_{12}, {L}_{10})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][0][12,0]*r[L][5][10,0]*t[((I,8),(J,13),)]*t[((K,12),(L,10),)]
                    # ({I}_{7}, {J}_{14}, {K}_{11}, {L}_{9})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,7),(J,14),)]*t[((K,11),(L,9),)]
                    # ({I}_{8}, {J}_{14}, {K}_{11}, {L}_{9})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,8),(J,14),)]*t[((K,11),(L,9),)]
                    # ({I}_{7}, {J}_{14}, {K}_{11}, {L}_{10})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,7),(J,14),)]*t[((K,11),(L,10),)]
                    # ({I}_{8}, {J}_{14}, {K}_{11}, {L}_{10})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,8),(J,14),)]*t[((K,11),(L,10),)]
                    # ({I}_{7}, {J}_{13}, {K}_{11}, {L}_{9})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,7),(J,13),)]*t[((K,11),(L,9),)]
                    # ({I}_{8}, {J}_{13}, {K}_{11}, {L}_{9})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][4][11,0]*r[L][1][9,0]*t[((I,8),(J,13),)]*t[((K,11),(L,9),)]
                    # ({I}_{7}, {J}_{13}, {K}_{11}, {L}_{10})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,7),(J,13),)]*t[((K,11),(L,10),)]
                    # ({I}_{8}, {J}_{13}, {K}_{11}, {L}_{10})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][4][11,0]*r[L][5][10,0]*t[((I,8),(J,13),)]*t[((K,11),(L,10),)]
                    # ({I}_{9}, {J}_{9}, {K}_{12}, {L}_{12})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,0])]*r[I][1][9,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][0][12,0]*t[((I,9),(K,12),)]*t[((J,9),(L,12),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,0])]*r[I][1][9,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][0][12,0]*t[((I,9),(K,12),)]*t[((J,9),(L,12),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,0])]*r[I][1][9,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][0][12,0]*t[((I,9),(L,12),)]*t[((J,9),(K,12),)]
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,0])]*r[I][1][9,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][0][12,0]*t[((I,9),(L,12),)]*t[((J,9),(K,12),)]
                    # ({I}_{7}, {J}_{7}, {K}_{14}, {L}_{14})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,0])]*r[I][3][7,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][2][14,0]*t[((I,7),(K,14),)]*t[((J,7),(L,14),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,0])]*r[I][3][7,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][2][14,0]*t[((I,7),(K,14),)]*t[((J,7),(L,14),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,0])]*r[I][3][7,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][2][14,0]*t[((I,7),(L,14),)]*t[((J,7),(K,14),)]
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,0])]*r[I][3][7,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][2][14,0]*t[((I,7),(L,14),)]*t[((J,7),(K,14),)]
                    # ({I}_{9}, {J}_{7}, {K}_{12}, {L}_{14})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,0])]*r[I][1][9,0]*r[J][3][7,0]*r[K][0][12,0]*r[L][2][14,0]*t[((I,9),(K,12),)]*t[((J,7),(L,14),)]
                    # ({I}_{9}, {J}_{10}, {K}_{12}, {L}_{12})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,0])]*r[I][1][9,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][0][12,0]*t[((I,9),(K,12),)]*t[((J,10),(L,12),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,0])]*r[I][1][9,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][0][12,0]*t[((I,9),(K,12),)]*t[((J,10),(L,12),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,0])]*r[I][1][9,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][0][12,0]*t[((I,9),(L,12),)]*t[((J,10),(K,12),)]
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,0])]*r[I][1][9,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][0][12,0]*t[((I,9),(L,12),)]*t[((J,10),(K,12),)]
                    # ({I}_{7}, {J}_{8}, {K}_{14}, {L}_{14})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,0])]*r[I][3][7,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][2][14,0]*t[((I,7),(K,14),)]*t[((J,8),(L,14),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,0])]*r[I][3][7,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][2][14,0]*t[((I,7),(K,14),)]*t[((J,8),(L,14),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,0])]*r[I][3][7,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][2][14,0]*t[((I,7),(L,14),)]*t[((J,8),(K,14),)]
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,0])]*r[I][3][7,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][2][14,0]*t[((I,7),(L,14),)]*t[((J,8),(K,14),)]
                    # ({I}_{9}, {J}_{8}, {K}_{12}, {L}_{14})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,0])]*r[I][1][9,0]*r[J][7][8,0]*r[K][0][12,0]*r[L][2][14,0]*t[((I,9),(K,12),)]*t[((J,8),(L,14),)]
                    # ({I}_{10}, {J}_{9}, {K}_{12}, {L}_{12})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,0])]*r[I][5][10,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][0][12,0]*t[((I,10),(K,12),)]*t[((J,9),(L,12),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,0])]*r[I][5][10,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][0][12,0]*t[((I,10),(K,12),)]*t[((J,9),(L,12),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,0])]*r[I][5][10,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][0][12,0]*t[((I,10),(L,12),)]*t[((J,9),(K,12),)]
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,0])]*r[I][5][10,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][0][12,0]*t[((I,10),(L,12),)]*t[((J,9),(K,12),)]
                    # ({I}_{8}, {J}_{7}, {K}_{14}, {L}_{14})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,0])]*r[I][7][8,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][2][14,0]*t[((I,8),(K,14),)]*t[((J,7),(L,14),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,0])]*r[I][7][8,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][2][14,0]*t[((I,8),(K,14),)]*t[((J,7),(L,14),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,0])]*r[I][7][8,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][2][14,0]*t[((I,8),(L,14),)]*t[((J,7),(K,14),)]
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,0])]*r[I][7][8,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][2][14,0]*t[((I,8),(L,14),)]*t[((J,7),(K,14),)]
                    # ({I}_{10}, {J}_{7}, {K}_{12}, {L}_{14})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,0])]*r[I][5][10,0]*r[J][3][7,0]*r[K][0][12,0]*r[L][2][14,0]*t[((I,10),(K,12),)]*t[((J,7),(L,14),)]
                    # ({I}_{10}, {J}_{10}, {K}_{12}, {L}_{12})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,0])]*r[I][5][10,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][0][12,0]*t[((I,10),(K,12),)]*t[((J,10),(L,12),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,0])]*r[I][5][10,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][0][12,0]*t[((I,10),(K,12),)]*t[((J,10),(L,12),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,0])]*r[I][5][10,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][0][12,0]*t[((I,10),(L,12),)]*t[((J,10),(K,12),)]
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,0])]*r[I][5][10,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][0][12,0]*t[((I,10),(L,12),)]*t[((J,10),(K,12),)]
                    # ({I}_{8}, {J}_{8}, {K}_{14}, {L}_{14})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,0])]*r[I][7][8,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][2][14,0]*t[((I,8),(K,14),)]*t[((J,8),(L,14),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,0])]*r[I][7][8,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][2][14,0]*t[((I,8),(K,14),)]*t[((J,8),(L,14),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,0])]*r[I][7][8,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][2][14,0]*t[((I,8),(L,14),)]*t[((J,8),(K,14),)]
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,0])]*r[I][7][8,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][2][14,0]*t[((I,8),(L,14),)]*t[((J,8),(K,14),)]
                    # ({I}_{10}, {J}_{8}, {K}_{12}, {L}_{14})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,0])]*r[I][5][10,0]*r[J][7][8,0]*r[K][0][12,0]*r[L][2][14,0]*t[((I,10),(K,12),)]*t[((J,8),(L,14),)]
                    # ({I}_{9}, {J}_{9}, {K}_{12}, {L}_{11})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,1])]*r[I][1][9,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][4][11,0]*t[((I,9),(K,12),)]*t[((J,9),(L,11),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,0])]*r[I][1][9,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][4][11,0]*t[((I,9),(K,12),)]*t[((J,9),(L,11),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,1])]*r[I][1][9,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][4][11,0]*t[((I,9),(L,11),)]*t[((J,9),(K,12),)]
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,0])]*r[I][1][9,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][4][11,0]*t[((I,9),(L,11),)]*t[((J,9),(K,12),)]
                    # ({I}_{7}, {J}_{7}, {K}_{14}, {L}_{13})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,1])]*r[I][3][7,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][6][13,0]*t[((I,7),(K,14),)]*t[((J,7),(L,13),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,0])]*r[I][3][7,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][6][13,0]*t[((I,7),(K,14),)]*t[((J,7),(L,13),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,1])]*r[I][3][7,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][6][13,0]*t[((I,7),(L,13),)]*t[((J,7),(K,14),)]
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,0])]*r[I][3][7,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][6][13,0]*t[((I,7),(L,13),)]*t[((J,7),(K,14),)]
                    # ({I}_{9}, {J}_{7}, {K}_{12}, {L}_{13})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,1])]*r[I][1][9,0]*r[J][3][7,0]*r[K][0][12,0]*r[L][6][13,0]*t[((I,9),(K,12),)]*t[((J,7),(L,13),)]
                    # ({I}_{9}, {J}_{10}, {K}_{12}, {L}_{11})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,1])]*r[I][1][9,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][4][11,0]*t[((I,9),(K,12),)]*t[((J,10),(L,11),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,0])]*r[I][1][9,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][4][11,0]*t[((I,9),(K,12),)]*t[((J,10),(L,11),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,1])]*r[I][1][9,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][4][11,0]*t[((I,9),(L,11),)]*t[((J,10),(K,12),)]
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,0])]*r[I][1][9,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][4][11,0]*t[((I,9),(L,11),)]*t[((J,10),(K,12),)]
                    # ({I}_{7}, {J}_{8}, {K}_{14}, {L}_{13})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,1])]*r[I][3][7,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][6][13,0]*t[((I,7),(K,14),)]*t[((J,8),(L,13),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,0])]*r[I][3][7,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][6][13,0]*t[((I,7),(K,14),)]*t[((J,8),(L,13),)]
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,1])]*r[I][3][7,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][6][13,0]*t[((I,7),(L,13),)]*t[((J,8),(K,14),)]
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,0])]*r[I][3][7,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][6][13,0]*t[((I,7),(L,13),)]*t[((J,8),(K,14),)]
                    # ({I}_{9}, {J}_{8}, {K}_{12}, {L}_{13})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,1])]*r[I][1][9,0]*r[J][7][8,0]*r[K][0][12,0]*r[L][6][13,0]*t[((I,9),(K,12),)]*t[((J,8),(L,13),)]
                    # ({I}_{10}, {J}_{9}, {K}_{12}, {L}_{11})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,1])]*r[I][5][10,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][4][11,0]*t[((I,10),(K,12),)]*t[((J,9),(L,11),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,0])]*r[I][5][10,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][4][11,0]*t[((I,10),(K,12),)]*t[((J,9),(L,11),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,1])]*r[I][5][10,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][4][11,0]*t[((I,10),(L,11),)]*t[((J,9),(K,12),)]
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,0])]*r[I][5][10,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][4][11,0]*t[((I,10),(L,11),)]*t[((J,9),(K,12),)]
                    # ({I}_{8}, {J}_{7}, {K}_{14}, {L}_{13})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,1])]*r[I][7][8,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][6][13,0]*t[((I,8),(K,14),)]*t[((J,7),(L,13),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,0])]*r[I][7][8,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][6][13,0]*t[((I,8),(K,14),)]*t[((J,7),(L,13),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,1])]*r[I][7][8,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][6][13,0]*t[((I,8),(L,13),)]*t[((J,7),(K,14),)]
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,0])]*r[I][7][8,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][6][13,0]*t[((I,8),(L,13),)]*t[((J,7),(K,14),)]
                    # ({I}_{10}, {J}_{7}, {K}_{12}, {L}_{13})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,1])]*r[I][5][10,0]*r[J][3][7,0]*r[K][0][12,0]*r[L][6][13,0]*t[((I,10),(K,12),)]*t[((J,7),(L,13),)]
                    # ({I}_{10}, {J}_{10}, {K}_{12}, {L}_{11})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,1])]*r[I][5][10,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][4][11,0]*t[((I,10),(K,12),)]*t[((J,10),(L,11),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,0])]*r[I][5][10,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][4][11,0]*t[((I,10),(K,12),)]*t[((J,10),(L,11),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,1])]*r[I][5][10,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][4][11,0]*t[((I,10),(L,11),)]*t[((J,10),(K,12),)]
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,0])]*r[I][5][10,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][4][11,0]*t[((I,10),(L,11),)]*t[((J,10),(K,12),)]
                    # ({I}_{8}, {J}_{8}, {K}_{14}, {L}_{13})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,1])]*r[I][7][8,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][6][13,0]*t[((I,8),(K,14),)]*t[((J,8),(L,13),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,0])]*r[I][7][8,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][6][13,0]*t[((I,8),(K,14),)]*t[((J,8),(L,13),)]
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,1])]*r[I][7][8,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][6][13,0]*t[((I,8),(L,13),)]*t[((J,8),(K,14),)]
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,0])]*r[I][7][8,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][6][13,0]*t[((I,8),(L,13),)]*t[((J,8),(K,14),)]
                    # ({I}_{10}, {J}_{8}, {K}_{12}, {L}_{13})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,1])]*r[I][5][10,0]*r[J][7][8,0]*r[K][0][12,0]*r[L][6][13,0]*t[((I,10),(K,12),)]*t[((J,8),(L,13),)]
                    # ({I}_{9}, {J}_{9}, {K}_{11}, {L}_{12})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,0])]*r[I][1][9,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][0][12,0]*t[((I,9),(K,11),)]*t[((J,9),(L,12),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,1])]*r[I][1][9,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][0][12,0]*t[((I,9),(K,11),)]*t[((J,9),(L,12),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,0])]*r[I][1][9,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][0][12,0]*t[((I,9),(L,12),)]*t[((J,9),(K,11),)]
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,1])]*r[I][1][9,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][0][12,0]*t[((I,9),(L,12),)]*t[((J,9),(K,11),)]
                    # ({I}_{7}, {J}_{7}, {K}_{13}, {L}_{14})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,0])]*r[I][3][7,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][2][14,0]*t[((I,7),(K,13),)]*t[((J,7),(L,14),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,1])]*r[I][3][7,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][2][14,0]*t[((I,7),(K,13),)]*t[((J,7),(L,14),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,0])]*r[I][3][7,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][2][14,0]*t[((I,7),(L,14),)]*t[((J,7),(K,13),)]
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,1])]*r[I][3][7,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][2][14,0]*t[((I,7),(L,14),)]*t[((J,7),(K,13),)]
                    # ({I}_{9}, {J}_{7}, {K}_{11}, {L}_{14})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,0])]*r[I][1][9,0]*r[J][3][7,0]*r[K][4][11,0]*r[L][2][14,0]*t[((I,9),(K,11),)]*t[((J,7),(L,14),)]
                    # ({I}_{9}, {J}_{10}, {K}_{11}, {L}_{12})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,0])]*r[I][1][9,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][0][12,0]*t[((I,9),(K,11),)]*t[((J,10),(L,12),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,1])]*r[I][1][9,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][0][12,0]*t[((I,9),(K,11),)]*t[((J,10),(L,12),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,0])]*r[I][1][9,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][0][12,0]*t[((I,9),(L,12),)]*t[((J,10),(K,11),)]
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,1])]*r[I][1][9,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][0][12,0]*t[((I,9),(L,12),)]*t[((J,10),(K,11),)]
                    # ({I}_{7}, {J}_{8}, {K}_{13}, {L}_{14})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,0])]*r[I][3][7,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][2][14,0]*t[((I,7),(K,13),)]*t[((J,8),(L,14),)]
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,1])]*r[I][3][7,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][2][14,0]*t[((I,7),(K,13),)]*t[((J,8),(L,14),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,0])]*r[I][3][7,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][2][14,0]*t[((I,7),(L,14),)]*t[((J,8),(K,13),)]
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,1])]*r[I][3][7,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][2][14,0]*t[((I,7),(L,14),)]*t[((J,8),(K,13),)]
                    # ({I}_{9}, {J}_{8}, {K}_{11}, {L}_{14})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,0])]*r[I][1][9,0]*r[J][7][8,0]*r[K][4][11,0]*r[L][2][14,0]*t[((I,9),(K,11),)]*t[((J,8),(L,14),)]
                    # ({I}_{10}, {J}_{9}, {K}_{11}, {L}_{12})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,0])]*r[I][5][10,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][0][12,0]*t[((I,10),(K,11),)]*t[((J,9),(L,12),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,1])]*r[I][5][10,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][0][12,0]*t[((I,10),(K,11),)]*t[((J,9),(L,12),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,0])]*r[I][5][10,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][0][12,0]*t[((I,10),(L,12),)]*t[((J,9),(K,11),)]
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,1])]*r[I][5][10,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][0][12,0]*t[((I,10),(L,12),)]*t[((J,9),(K,11),)]
                    # ({I}_{8}, {J}_{7}, {K}_{13}, {L}_{14})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,0])]*r[I][7][8,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][2][14,0]*t[((I,8),(K,13),)]*t[((J,7),(L,14),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,1])]*r[I][7][8,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][2][14,0]*t[((I,8),(K,13),)]*t[((J,7),(L,14),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,0])]*r[I][7][8,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][2][14,0]*t[((I,8),(L,14),)]*t[((J,7),(K,13),)]
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,1])]*r[I][7][8,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][2][14,0]*t[((I,8),(L,14),)]*t[((J,7),(K,13),)]
                    # ({I}_{10}, {J}_{7}, {K}_{11}, {L}_{14})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,0])]*r[I][5][10,0]*r[J][3][7,0]*r[K][4][11,0]*r[L][2][14,0]*t[((I,10),(K,11),)]*t[((J,7),(L,14),)]
                    # ({I}_{10}, {J}_{10}, {K}_{11}, {L}_{12})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,0])]*r[I][5][10,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][0][12,0]*t[((I,10),(K,11),)]*t[((J,10),(L,12),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,1])]*r[I][5][10,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][0][12,0]*t[((I,10),(K,11),)]*t[((J,10),(L,12),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,0])]*r[I][5][10,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][0][12,0]*t[((I,10),(L,12),)]*t[((J,10),(K,11),)]
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,1])]*r[I][5][10,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][0][12,0]*t[((I,10),(L,12),)]*t[((J,10),(K,11),)]
                    # ({I}_{8}, {J}_{8}, {K}_{13}, {L}_{14})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,0])]*r[I][7][8,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][2][14,0]*t[((I,8),(K,13),)]*t[((J,8),(L,14),)]
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,1])]*r[I][7][8,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][2][14,0]*t[((I,8),(K,13),)]*t[((J,8),(L,14),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,0])]*r[I][7][8,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][2][14,0]*t[((I,8),(L,14),)]*t[((J,8),(K,13),)]
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,1])]*r[I][7][8,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][2][14,0]*t[((I,8),(L,14),)]*t[((J,8),(K,13),)]
                    # ({I}_{10}, {J}_{8}, {K}_{11}, {L}_{14})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,0])]*r[I][5][10,0]*r[J][7][8,0]*r[K][4][11,0]*r[L][2][14,0]*t[((I,10),(K,11),)]*t[((J,8),(L,14),)]
                    # ({I}_{9}, {J}_{9}, {K}_{11}, {L}_{11})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,1])]*r[I][1][9,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][4][11,0]*t[((I,9),(K,11),)]*t[((J,9),(L,11),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,1])]*r[I][1][9,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][4][11,0]*t[((I,9),(K,11),)]*t[((J,9),(L,11),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,1])]*r[I][1][9,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][4][11,0]*t[((I,9),(L,11),)]*t[((J,9),(K,11),)]
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,1])]*r[I][1][9,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][4][11,0]*t[((I,9),(L,11),)]*t[((J,9),(K,11),)]
                    # ({I}_{7}, {J}_{7}, {K}_{13}, {L}_{13})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,1])]*r[I][3][7,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][6][13,0]*t[((I,7),(K,13),)]*t[((J,7),(L,13),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,1])]*r[I][3][7,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][6][13,0]*t[((I,7),(K,13),)]*t[((J,7),(L,13),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,1])]*r[I][3][7,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][6][13,0]*t[((I,7),(L,13),)]*t[((J,7),(K,13),)]
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,1])]*r[I][3][7,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][6][13,0]*t[((I,7),(L,13),)]*t[((J,7),(K,13),)]
                    # ({I}_{9}, {J}_{7}, {K}_{11}, {L}_{13})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,1])]*r[I][1][9,0]*r[J][3][7,0]*r[K][4][11,0]*r[L][6][13,0]*t[((I,9),(K,11),)]*t[((J,7),(L,13),)]
                    # ({I}_{9}, {J}_{10}, {K}_{11}, {L}_{11})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,1])]*r[I][1][9,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][4][11,0]*t[((I,9),(K,11),)]*t[((J,10),(L,11),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,1])]*r[I][1][9,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][4][11,0]*t[((I,9),(K,11),)]*t[((J,10),(L,11),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,1])]*r[I][1][9,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][4][11,0]*t[((I,9),(L,11),)]*t[((J,10),(K,11),)]
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,1])]*r[I][1][9,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][4][11,0]*t[((I,9),(L,11),)]*t[((J,10),(K,11),)]
                    # ({I}_{7}, {J}_{8}, {K}_{13}, {L}_{13})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,1])]*r[I][3][7,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][6][13,0]*t[((I,7),(K,13),)]*t[((J,8),(L,13),)]
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,1])]*r[I][3][7,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][6][13,0]*t[((I,7),(K,13),)]*t[((J,8),(L,13),)]
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,1])]*r[I][3][7,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][6][13,0]*t[((I,7),(L,13),)]*t[((J,8),(K,13),)]
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,1])]*r[I][3][7,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][6][13,0]*t[((I,7),(L,13),)]*t[((J,8),(K,13),)]
                    # ({I}_{9}, {J}_{8}, {K}_{11}, {L}_{13})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,1])]*r[I][1][9,0]*r[J][7][8,0]*r[K][4][11,0]*r[L][6][13,0]*t[((I,9),(K,11),)]*t[((J,8),(L,13),)]
                    # ({I}_{10}, {J}_{9}, {K}_{11}, {L}_{11})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,1])]*r[I][5][10,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][4][11,0]*t[((I,10),(K,11),)]*t[((J,9),(L,11),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,1])]*r[I][5][10,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][4][11,0]*t[((I,10),(K,11),)]*t[((J,9),(L,11),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,1])]*r[I][5][10,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][4][11,0]*t[((I,10),(L,11),)]*t[((J,9),(K,11),)]
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,1])]*r[I][5][10,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][4][11,0]*t[((I,10),(L,11),)]*t[((J,9),(K,11),)]
                    # ({I}_{8}, {J}_{7}, {K}_{13}, {L}_{13})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,1])]*r[I][7][8,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][6][13,0]*t[((I,8),(K,13),)]*t[((J,7),(L,13),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,1])]*r[I][7][8,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][6][13,0]*t[((I,8),(K,13),)]*t[((J,7),(L,13),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,1])]*r[I][7][8,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][6][13,0]*t[((I,8),(L,13),)]*t[((J,7),(K,13),)]
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,1])]*r[I][7][8,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][6][13,0]*t[((I,8),(L,13),)]*t[((J,7),(K,13),)]
                    # ({I}_{10}, {J}_{7}, {K}_{11}, {L}_{13})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,1])]*r[I][5][10,0]*r[J][3][7,0]*r[K][4][11,0]*r[L][6][13,0]*t[((I,10),(K,11),)]*t[((J,7),(L,13),)]
                    # ({I}_{10}, {J}_{10}, {K}_{11}, {L}_{11})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,1])]*r[I][5][10,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][4][11,0]*t[((I,10),(K,11),)]*t[((J,10),(L,11),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,1])]*r[I][5][10,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][4][11,0]*t[((I,10),(K,11),)]*t[((J,10),(L,11),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,1])]*r[I][5][10,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][4][11,0]*t[((I,10),(L,11),)]*t[((J,10),(K,11),)]
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,1])]*r[I][5][10,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][4][11,0]*t[((I,10),(L,11),)]*t[((J,10),(K,11),)]
                    # ({I}_{8}, {J}_{8}, {K}_{13}, {L}_{13})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,1])]*r[I][7][8,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][6][13,0]*t[((I,8),(K,13),)]*t[((J,8),(L,13),)]
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,1])]*r[I][7][8,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][6][13,0]*t[((I,8),(K,13),)]*t[((J,8),(L,13),)]
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,1])]*r[I][7][8,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][6][13,0]*t[((I,8),(L,13),)]*t[((J,8),(K,13),)]
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,1])]*r[I][7][8,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][6][13,0]*t[((I,8),(L,13),)]*t[((J,8),(K,13),)]
                    # ({I}_{10}, {J}_{8}, {K}_{11}, {L}_{13})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,1])]*r[I][5][10,0]*r[J][7][8,0]*r[K][4][11,0]*r[L][6][13,0]*t[((I,10),(K,11),)]*t[((J,8),(L,13),)]
                    # ({I}_{7}, {J}_{9}, {K}_{12}, {L}_{14})
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,0])]*r[I][3][7,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][2][14,0]*t[((I,7),(L,14),)]*t[((J,9),(K,12),)]
                    # ({I}_{8}, {J}_{9}, {K}_{12}, {L}_{14})
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,0])]*r[I][7][8,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][2][14,0]*t[((I,8),(L,14),)]*t[((J,9),(K,12),)]
                    # ({I}_{7}, {J}_{10}, {K}_{12}, {L}_{14})
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,0])]*r[I][3][7,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][2][14,0]*t[((I,7),(L,14),)]*t[((J,10),(K,12),)]
                    # ({I}_{8}, {J}_{10}, {K}_{12}, {L}_{14})
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,0])]*r[I][7][8,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][2][14,0]*t[((I,8),(L,14),)]*t[((J,10),(K,12),)]
                    # ({I}_{7}, {J}_{9}, {K}_{12}, {L}_{13})
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,0])]*r[I][3][7,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][6][13,0]*t[((I,7),(L,13),)]*t[((J,9),(K,12),)]
                    # ({I}_{8}, {J}_{9}, {K}_{12}, {L}_{13})
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,0])]*r[I][7][8,0]*r[J][1][9,0]*r[K][0][12,0]*r[L][6][13,0]*t[((I,8),(L,13),)]*t[((J,9),(K,12),)]
                    # ({I}_{7}, {J}_{10}, {K}_{12}, {L}_{13})
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,0])]*r[I][3][7,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][6][13,0]*t[((I,7),(L,13),)]*t[((J,10),(K,12),)]
                    # ({I}_{8}, {J}_{10}, {K}_{12}, {L}_{13})
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,0])]*r[I][7][8,0]*r[J][5][10,0]*r[K][0][12,0]*r[L][6][13,0]*t[((I,8),(L,13),)]*t[((J,10),(K,12),)]
                    # ({I}_{7}, {J}_{9}, {K}_{11}, {L}_{14})
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,1])]*r[I][3][7,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][2][14,0]*t[((I,7),(L,14),)]*t[((J,9),(K,11),)]
                    # ({I}_{8}, {J}_{9}, {K}_{11}, {L}_{14})
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,1])]*r[I][7][8,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][2][14,0]*t[((I,8),(L,14),)]*t[((J,9),(K,11),)]
                    # ({I}_{7}, {J}_{10}, {K}_{11}, {L}_{14})
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,1])]*r[I][3][7,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][2][14,0]*t[((I,7),(L,14),)]*t[((J,10),(K,11),)]
                    # ({I}_{8}, {J}_{10}, {K}_{11}, {L}_{14})
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,1])]*r[I][7][8,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][2][14,0]*t[((I,8),(L,14),)]*t[((J,10),(K,11),)]
                    # ({I}_{7}, {J}_{9}, {K}_{11}, {L}_{13})
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,1])]*r[I][3][7,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][6][13,0]*t[((I,7),(L,13),)]*t[((J,9),(K,11),)]
                    # ({I}_{8}, {J}_{9}, {K}_{11}, {L}_{13})
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,1])]*r[I][7][8,0]*r[J][1][9,0]*r[K][4][11,0]*r[L][6][13,0]*t[((I,8),(L,13),)]*t[((J,9),(K,11),)]
                    # ({I}_{7}, {J}_{10}, {K}_{11}, {L}_{13})
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,1])]*r[I][3][7,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][6][13,0]*t[((I,7),(L,13),)]*t[((J,10),(K,11),)]
                    # ({I}_{8}, {J}_{10}, {K}_{11}, {L}_{13})
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,1])]*r[I][7][8,0]*r[J][5][10,0]*r[K][4][11,0]*r[L][6][13,0]*t[((I,8),(L,13),)]*t[((J,10),(K,11),)]
                    # ({I}_{14}, {J}_{9}, {K}_{7}, {L}_{12})
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,0])]*r[I][2][14,0]*r[J][1][9,0]*r[K][3][7,0]*r[L][0][12,0]*t[((I,14),(K,7),)]*t[((J,9),(L,12),)]
                    # ({I}_{14}, {J}_{9}, {K}_{8}, {L}_{12})
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,0])]*r[I][2][14,0]*r[J][1][9,0]*r[K][7][8,0]*r[L][0][12,0]*t[((I,14),(K,8),)]*t[((J,9),(L,12),)]
                    # ({I}_{14}, {J}_{10}, {K}_{7}, {L}_{12})
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,0])]*r[I][2][14,0]*r[J][5][10,0]*r[K][3][7,0]*r[L][0][12,0]*t[((I,14),(K,7),)]*t[((J,10),(L,12),)]
                    # ({I}_{14}, {J}_{10}, {K}_{8}, {L}_{12})
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,0])]*r[I][2][14,0]*r[J][5][10,0]*r[K][7][8,0]*r[L][0][12,0]*t[((I,14),(K,8),)]*t[((J,10),(L,12),)]
                    # ({I}_{13}, {J}_{9}, {K}_{7}, {L}_{12})
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,0])]*r[I][6][13,0]*r[J][1][9,0]*r[K][3][7,0]*r[L][0][12,0]*t[((I,13),(K,7),)]*t[((J,9),(L,12),)]
                    # ({I}_{13}, {J}_{9}, {K}_{8}, {L}_{12})
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,0])]*r[I][6][13,0]*r[J][1][9,0]*r[K][7][8,0]*r[L][0][12,0]*t[((I,13),(K,8),)]*t[((J,9),(L,12),)]
                    # ({I}_{13}, {J}_{10}, {K}_{7}, {L}_{12})
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,0])]*r[I][6][13,0]*r[J][5][10,0]*r[K][3][7,0]*r[L][0][12,0]*t[((I,13),(K,7),)]*t[((J,10),(L,12),)]
                    # ({I}_{13}, {J}_{10}, {K}_{8}, {L}_{12})
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,0])]*r[I][6][13,0]*r[J][5][10,0]*r[K][7][8,0]*r[L][0][12,0]*t[((I,13),(K,8),)]*t[((J,10),(L,12),)]
                    # ({I}_{14}, {J}_{9}, {K}_{7}, {L}_{11})
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,1])]*r[I][2][14,0]*r[J][1][9,0]*r[K][3][7,0]*r[L][4][11,0]*t[((I,14),(K,7),)]*t[((J,9),(L,11),)]
                    # ({I}_{14}, {J}_{9}, {K}_{8}, {L}_{11})
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,1])]*r[I][2][14,0]*r[J][1][9,0]*r[K][7][8,0]*r[L][4][11,0]*t[((I,14),(K,8),)]*t[((J,9),(L,11),)]
                    # ({I}_{14}, {J}_{10}, {K}_{7}, {L}_{11})
                    tu += -1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,1])]*r[I][2][14,0]*r[J][5][10,0]*r[K][3][7,0]*r[L][4][11,0]*t[((I,14),(K,7),)]*t[((J,10),(L,11),)]
                    # ({I}_{14}, {J}_{10}, {K}_{8}, {L}_{11})
                    tu += -1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,1])]*r[I][2][14,0]*r[J][5][10,0]*r[K][7][8,0]*r[L][4][11,0]*t[((I,14),(K,8),)]*t[((J,10),(L,11),)]
                    # ({I}_{13}, {J}_{9}, {K}_{7}, {L}_{11})
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,1])]*r[I][6][13,0]*r[J][1][9,0]*r[K][3][7,0]*r[L][4][11,0]*t[((I,13),(K,7),)]*t[((J,9),(L,11),)]
                    # ({I}_{13}, {J}_{9}, {K}_{8}, {L}_{11})
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,1])]*r[I][6][13,0]*r[J][1][9,0]*r[K][7][8,0]*r[L][4][11,0]*t[((I,13),(K,8),)]*t[((J,9),(L,11),)]
                    # ({I}_{13}, {J}_{10}, {K}_{7}, {L}_{11})
                    tu += -1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,1])]*r[I][6][13,0]*r[J][5][10,0]*r[K][3][7,0]*r[L][4][11,0]*t[((I,13),(K,7),)]*t[((J,10),(L,11),)]
                    # ({I}_{13}, {J}_{10}, {K}_{8}, {L}_{11})
                    tu += -1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,1])]*r[I][6][13,0]*r[J][5][10,0]*r[K][7][8,0]*r[L][4][11,0]*t[((I,13),(K,8),)]*t[((J,10),(L,11),)]
                    # ({I}_{14}, {J}_{7}, {K}_{9}, {L}_{12})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,14),(J,7),)]*t[((K,9),(L,12),)]
                    # ({I}_{14}, {J}_{8}, {K}_{9}, {L}_{12})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,14),(J,8),)]*t[((K,9),(L,12),)]
                    # ({I}_{14}, {J}_{7}, {K}_{10}, {L}_{12})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,0])]*r[I][2][14,0]*r[J][3][7,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,14),(J,7),)]*t[((K,10),(L,12),)]
                    # ({I}_{14}, {J}_{8}, {K}_{10}, {L}_{12})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,0])]*r[I][2][14,0]*r[J][7][8,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,14),(J,8),)]*t[((K,10),(L,12),)]
                    # ({I}_{13}, {J}_{7}, {K}_{9}, {L}_{12})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,13),(J,7),)]*t[((K,9),(L,12),)]
                    # ({I}_{13}, {J}_{8}, {K}_{9}, {L}_{12})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,13),(J,8),)]*t[((K,9),(L,12),)]
                    # ({I}_{13}, {J}_{7}, {K}_{10}, {L}_{12})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,0])]*r[I][6][13,0]*r[J][3][7,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,13),(J,7),)]*t[((K,10),(L,12),)]
                    # ({I}_{13}, {J}_{8}, {K}_{10}, {L}_{12})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,0])]*r[I][6][13,0]*r[J][7][8,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,13),(J,8),)]*t[((K,10),(L,12),)]
                    # ({I}_{14}, {J}_{7}, {K}_{9}, {L}_{11})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,14),(J,7),)]*t[((K,9),(L,11),)]
                    # ({I}_{14}, {J}_{8}, {K}_{9}, {L}_{11})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,14),(J,8),)]*t[((K,9),(L,11),)]
                    # ({I}_{14}, {J}_{7}, {K}_{10}, {L}_{11})
                    tu += -1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,1])]*r[I][2][14,0]*r[J][3][7,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,14),(J,7),)]*t[((K,10),(L,11),)]
                    # ({I}_{14}, {J}_{8}, {K}_{10}, {L}_{11})
                    tu += -1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,1])]*r[I][2][14,0]*r[J][7][8,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,14),(J,8),)]*t[((K,10),(L,11),)]
                    # ({I}_{13}, {J}_{7}, {K}_{9}, {L}_{11})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,13),(J,7),)]*t[((K,9),(L,11),)]
                    # ({I}_{13}, {J}_{8}, {K}_{9}, {L}_{11})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,13),(J,8),)]*t[((K,9),(L,11),)]
                    # ({I}_{13}, {J}_{7}, {K}_{10}, {L}_{11})
                    tu += -1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,1])]*r[I][6][13,0]*r[J][3][7,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,13),(J,7),)]*t[((K,10),(L,11),)]
                    # ({I}_{13}, {J}_{8}, {K}_{10}, {L}_{11})
                    tu += -1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,1])]*r[I][6][13,0]*r[J][7][8,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,13),(J,8),)]*t[((K,10),(L,11),)]
                    # ({I}_{9}, {J}_{14}, {K}_{7}, {L}_{12})
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,0])]*r[I][1][9,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][0][12,0]*t[((I,9),(L,12),)]*t[((J,14),(K,7),)]
                    # ({I}_{9}, {J}_{14}, {K}_{8}, {L}_{12})
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,1])]*r[I][1][9,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][0][12,0]*t[((I,9),(L,12),)]*t[((J,14),(K,8),)]
                    # ({I}_{10}, {J}_{14}, {K}_{7}, {L}_{12})
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,0])]*r[I][5][10,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][0][12,0]*t[((I,10),(L,12),)]*t[((J,14),(K,7),)]
                    # ({I}_{10}, {J}_{14}, {K}_{8}, {L}_{12})
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,1])]*r[I][5][10,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][0][12,0]*t[((I,10),(L,12),)]*t[((J,14),(K,8),)]
                    # ({I}_{9}, {J}_{13}, {K}_{7}, {L}_{12})
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,0])]*r[I][1][9,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][0][12,0]*t[((I,9),(L,12),)]*t[((J,13),(K,7),)]
                    # ({I}_{9}, {J}_{13}, {K}_{8}, {L}_{12})
                    tu += -1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,1])]*r[I][1][9,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][0][12,0]*t[((I,9),(L,12),)]*t[((J,13),(K,8),)]
                    # ({I}_{10}, {J}_{13}, {K}_{7}, {L}_{12})
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,0])]*r[I][5][10,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][0][12,0]*t[((I,10),(L,12),)]*t[((J,13),(K,7),)]
                    # ({I}_{10}, {J}_{13}, {K}_{8}, {L}_{12})
                    tu += -1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,1])]*r[I][5][10,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][0][12,0]*t[((I,10),(L,12),)]*t[((J,13),(K,8),)]
                    # ({I}_{9}, {J}_{14}, {K}_{7}, {L}_{11})
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,0])]*r[I][1][9,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][4][11,0]*t[((I,9),(L,11),)]*t[((J,14),(K,7),)]
                    # ({I}_{9}, {J}_{14}, {K}_{8}, {L}_{11})
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,1])]*r[I][1][9,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][4][11,0]*t[((I,9),(L,11),)]*t[((J,14),(K,8),)]
                    # ({I}_{10}, {J}_{14}, {K}_{7}, {L}_{11})
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,0])]*r[I][5][10,0]*r[J][2][14,0]*r[K][3][7,0]*r[L][4][11,0]*t[((I,10),(L,11),)]*t[((J,14),(K,7),)]
                    # ({I}_{10}, {J}_{14}, {K}_{8}, {L}_{11})
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,1])]*r[I][5][10,0]*r[J][2][14,0]*r[K][7][8,0]*r[L][4][11,0]*t[((I,10),(L,11),)]*t[((J,14),(K,8),)]
                    # ({I}_{9}, {J}_{13}, {K}_{7}, {L}_{11})
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,0])]*r[I][1][9,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][4][11,0]*t[((I,9),(L,11),)]*t[((J,13),(K,7),)]
                    # ({I}_{9}, {J}_{13}, {K}_{8}, {L}_{11})
                    tu += -1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,1])]*r[I][1][9,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][4][11,0]*t[((I,9),(L,11),)]*t[((J,13),(K,8),)]
                    # ({I}_{10}, {J}_{13}, {K}_{7}, {L}_{11})
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,0])]*r[I][5][10,0]*r[J][6][13,0]*r[K][3][7,0]*r[L][4][11,0]*t[((I,10),(L,11),)]*t[((J,13),(K,7),)]
                    # ({I}_{10}, {J}_{13}, {K}_{8}, {L}_{11})
                    tu += -1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,1])]*r[I][5][10,0]*r[J][6][13,0]*r[K][7][8,0]*r[L][4][11,0]*t[((I,10),(L,11),)]*t[((J,13),(K,8),)]
                    # ({I}_{7}, {J}_{14}, {K}_{9}, {L}_{12})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,7),(J,14),)]*t[((K,9),(L,12),)]
                    # ({I}_{8}, {J}_{14}, {K}_{9}, {L}_{12})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,8),(J,14),)]*t[((K,9),(L,12),)]
                    # ({I}_{7}, {J}_{14}, {K}_{10}, {L}_{12})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,0])]*r[I][3][7,0]*r[J][2][14,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,7),(J,14),)]*t[((K,10),(L,12),)]
                    # ({I}_{8}, {J}_{14}, {K}_{10}, {L}_{12})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,0])]*r[I][7][8,0]*r[J][2][14,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,8),(J,14),)]*t[((K,10),(L,12),)]
                    # ({I}_{7}, {J}_{13}, {K}_{9}, {L}_{12})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,7),(J,13),)]*t[((K,9),(L,12),)]
                    # ({I}_{8}, {J}_{13}, {K}_{9}, {L}_{12})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][1][9,0]*r[L][0][12,0]*t[((I,8),(J,13),)]*t[((K,9),(L,12),)]
                    # ({I}_{7}, {J}_{13}, {K}_{10}, {L}_{12})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,0])]*r[I][3][7,0]*r[J][6][13,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,7),(J,13),)]*t[((K,10),(L,12),)]
                    # ({I}_{8}, {J}_{13}, {K}_{10}, {L}_{12})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,0])]*r[I][7][8,0]*r[J][6][13,0]*r[K][5][10,0]*r[L][0][12,0]*t[((I,8),(J,13),)]*t[((K,10),(L,12),)]
                    # ({I}_{7}, {J}_{14}, {K}_{9}, {L}_{11})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,0],p[L,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,7),(J,14),)]*t[((K,9),(L,11),)]
                    # ({I}_{8}, {J}_{14}, {K}_{9}, {L}_{11})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,0],p[L,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,8),(J,14),)]*t[((K,9),(L,11),)]
                    # ({I}_{7}, {J}_{14}, {K}_{10}, {L}_{11})
                    tu += 1/24*g[dei(p[I,0],p[J,0],p[K,1],p[L,1])]*r[I][3][7,0]*r[J][2][14,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,7),(J,14),)]*t[((K,10),(L,11),)]
                    # ({I}_{8}, {J}_{14}, {K}_{10}, {L}_{11})
                    tu += 1/24*g[dei(p[I,1],p[J,0],p[K,1],p[L,1])]*r[I][7][8,0]*r[J][2][14,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,8),(J,14),)]*t[((K,10),(L,11),)]
                    # ({I}_{7}, {J}_{13}, {K}_{9}, {L}_{11})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,0],p[L,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,7),(J,13),)]*t[((K,9),(L,11),)]
                    # ({I}_{8}, {J}_{13}, {K}_{9}, {L}_{11})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,0],p[L,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][1][9,0]*r[L][4][11,0]*t[((I,8),(J,13),)]*t[((K,9),(L,11),)]
                    # ({I}_{7}, {J}_{13}, {K}_{10}, {L}_{11})
                    tu += 1/24*g[dei(p[I,0],p[J,1],p[K,1],p[L,1])]*r[I][3][7,0]*r[J][6][13,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,7),(J,13),)]*t[((K,10),(L,11),)]
                    # ({I}_{8}, {J}_{13}, {K}_{10}, {L}_{11})
                    tu += 1/24*g[dei(p[I,1],p[J,1],p[K,1],p[L,1])]*r[I][7][8,0]*r[J][6][13,0]*r[K][5][10,0]*r[L][4][11,0]*t[((I,8),(J,13),)]*t[((K,10),(L,11),)]
                    # ({I}_{9}, {J}_{7}, {K}_{14}, {L}_{12})
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,0])]*r[I][1][9,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][0][12,0]*t[((I,9),(L,12),)]*t[((J,7),(K,14),)]
                    # ({I}_{9}, {J}_{8}, {K}_{14}, {L}_{12})
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,0])]*r[I][1][9,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][0][12,0]*t[((I,9),(L,12),)]*t[((J,8),(K,14),)]
                    # ({I}_{10}, {J}_{7}, {K}_{14}, {L}_{12})
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,0])]*r[I][5][10,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][0][12,0]*t[((I,10),(L,12),)]*t[((J,7),(K,14),)]
                    # ({I}_{10}, {J}_{8}, {K}_{14}, {L}_{12})
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,0])]*r[I][5][10,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][0][12,0]*t[((I,10),(L,12),)]*t[((J,8),(K,14),)]
                    # ({I}_{9}, {J}_{7}, {K}_{13}, {L}_{12})
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,0],p[K,1])]*r[I][1][9,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][0][12,0]*t[((I,9),(L,12),)]*t[((J,7),(K,13),)]
                    # ({I}_{9}, {J}_{8}, {K}_{13}, {L}_{12})
                    tu += 1/24*g[dei(p[I,0],p[L,0],p[J,1],p[K,1])]*r[I][1][9,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][0][12,0]*t[((I,9),(L,12),)]*t[((J,8),(K,13),)]
                    # ({I}_{10}, {J}_{7}, {K}_{13}, {L}_{12})
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,0],p[K,1])]*r[I][5][10,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][0][12,0]*t[((I,10),(L,12),)]*t[((J,7),(K,13),)]
                    # ({I}_{10}, {J}_{8}, {K}_{13}, {L}_{12})
                    tu += 1/24*g[dei(p[I,1],p[L,0],p[J,1],p[K,1])]*r[I][5][10,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][0][12,0]*t[((I,10),(L,12),)]*t[((J,8),(K,13),)]
                    # ({I}_{9}, {J}_{7}, {K}_{14}, {L}_{11})
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,0])]*r[I][1][9,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][4][11,0]*t[((I,9),(L,11),)]*t[((J,7),(K,14),)]
                    # ({I}_{9}, {J}_{8}, {K}_{14}, {L}_{11})
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,0])]*r[I][1][9,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][4][11,0]*t[((I,9),(L,11),)]*t[((J,8),(K,14),)]
                    # ({I}_{10}, {J}_{7}, {K}_{14}, {L}_{11})
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,0])]*r[I][5][10,0]*r[J][3][7,0]*r[K][2][14,0]*r[L][4][11,0]*t[((I,10),(L,11),)]*t[((J,7),(K,14),)]
                    # ({I}_{10}, {J}_{8}, {K}_{14}, {L}_{11})
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,0])]*r[I][5][10,0]*r[J][7][8,0]*r[K][2][14,0]*r[L][4][11,0]*t[((I,10),(L,11),)]*t[((J,8),(K,14),)]
                    # ({I}_{9}, {J}_{7}, {K}_{13}, {L}_{11})
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,0],p[K,1])]*r[I][1][9,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][4][11,0]*t[((I,9),(L,11),)]*t[((J,7),(K,13),)]
                    # ({I}_{9}, {J}_{8}, {K}_{13}, {L}_{11})
                    tu += 1/24*g[dei(p[I,0],p[L,1],p[J,1],p[K,1])]*r[I][1][9,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][4][11,0]*t[((I,9),(L,11),)]*t[((J,8),(K,13),)]
                    # ({I}_{10}, {J}_{7}, {K}_{13}, {L}_{11})
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,0],p[K,1])]*r[I][5][10,0]*r[J][3][7,0]*r[K][6][13,0]*r[L][4][11,0]*t[((I,10),(L,11),)]*t[((J,7),(K,13),)]
                    # ({I}_{10}, {J}_{8}, {K}_{13}, {L}_{11})
                    tu += 1/24*g[dei(p[I,1],p[L,1],p[J,1],p[K,1])]*r[I][5][10,0]*r[J][7][8,0]*r[K][6][13,0]*r[L][4][11,0]*t[((I,10),(L,11),)]*t[((J,8),(K,13),)]
                    # ({I}_{7}, {J}_{9}, {K}_{14}, {L}_{12})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,0])]*r[I][3][7,0]*r[J][1][9,0]*r[K][2][14,0]*r[L][0][12,0]*t[((I,7),(K,14),)]*t[((J,9),(L,12),)]
                    # ({I}_{8}, {J}_{9}, {K}_{14}, {L}_{12})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,0])]*r[I][7][8,0]*r[J][1][9,0]*r[K][2][14,0]*r[L][0][12,0]*t[((I,8),(K,14),)]*t[((J,9),(L,12),)]
                    # ({I}_{7}, {J}_{10}, {K}_{14}, {L}_{12})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,0])]*r[I][3][7,0]*r[J][5][10,0]*r[K][2][14,0]*r[L][0][12,0]*t[((I,7),(K,14),)]*t[((J,10),(L,12),)]
                    # ({I}_{8}, {J}_{10}, {K}_{14}, {L}_{12})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,0])]*r[I][7][8,0]*r[J][5][10,0]*r[K][2][14,0]*r[L][0][12,0]*t[((I,8),(K,14),)]*t[((J,10),(L,12),)]
                    # ({I}_{7}, {J}_{9}, {K}_{13}, {L}_{12})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,0])]*r[I][3][7,0]*r[J][1][9,0]*r[K][6][13,0]*r[L][0][12,0]*t[((I,7),(K,13),)]*t[((J,9),(L,12),)]
                    # ({I}_{8}, {J}_{9}, {K}_{13}, {L}_{12})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,0])]*r[I][7][8,0]*r[J][1][9,0]*r[K][6][13,0]*r[L][0][12,0]*t[((I,8),(K,13),)]*t[((J,9),(L,12),)]
                    # ({I}_{7}, {J}_{10}, {K}_{13}, {L}_{12})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,0])]*r[I][3][7,0]*r[J][5][10,0]*r[K][6][13,0]*r[L][0][12,0]*t[((I,7),(K,13),)]*t[((J,10),(L,12),)]
                    # ({I}_{8}, {J}_{10}, {K}_{13}, {L}_{12})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,0])]*r[I][7][8,0]*r[J][5][10,0]*r[K][6][13,0]*r[L][0][12,0]*t[((I,8),(K,13),)]*t[((J,10),(L,12),)]
                    # ({I}_{7}, {J}_{9}, {K}_{14}, {L}_{11})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,0],p[L,1])]*r[I][3][7,0]*r[J][1][9,0]*r[K][2][14,0]*r[L][4][11,0]*t[((I,7),(K,14),)]*t[((J,9),(L,11),)]
                    # ({I}_{8}, {J}_{9}, {K}_{14}, {L}_{11})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,0],p[L,1])]*r[I][7][8,0]*r[J][1][9,0]*r[K][2][14,0]*r[L][4][11,0]*t[((I,8),(K,14),)]*t[((J,9),(L,11),)]
                    # ({I}_{7}, {J}_{10}, {K}_{14}, {L}_{11})
                    tu += 1/24*g[dei(p[I,0],p[K,0],p[J,1],p[L,1])]*r[I][3][7,0]*r[J][5][10,0]*r[K][2][14,0]*r[L][4][11,0]*t[((I,7),(K,14),)]*t[((J,10),(L,11),)]
                    # ({I}_{8}, {J}_{10}, {K}_{14}, {L}_{11})
                    tu += 1/24*g[dei(p[I,1],p[K,0],p[J,1],p[L,1])]*r[I][7][8,0]*r[J][5][10,0]*r[K][2][14,0]*r[L][4][11,0]*t[((I,8),(K,14),)]*t[((J,10),(L,11),)]
                    # ({I}_{7}, {J}_{9}, {K}_{13}, {L}_{11})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,0],p[L,1])]*r[I][3][7,0]*r[J][1][9,0]*r[K][6][13,0]*r[L][4][11,0]*t[((I,7),(K,13),)]*t[((J,9),(L,11),)]
                    # ({I}_{8}, {J}_{9}, {K}_{13}, {L}_{11})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,0],p[L,1])]*r[I][7][8,0]*r[J][1][9,0]*r[K][6][13,0]*r[L][4][11,0]*t[((I,8),(K,13),)]*t[((J,9),(L,11),)]
                    # ({I}_{7}, {J}_{10}, {K}_{13}, {L}_{11})
                    tu += 1/24*g[dei(p[I,0],p[K,1],p[J,1],p[L,1])]*r[I][3][7,0]*r[J][5][10,0]*r[K][6][13,0]*r[L][4][11,0]*t[((I,7),(K,13),)]*t[((J,10),(L,11),)]
                    # ({I}_{8}, {J}_{10}, {K}_{13}, {L}_{11})
                    tu += 1/24*g[dei(p[I,1],p[K,1],p[J,1],p[L,1])]*r[I][7][8,0]*r[J][5][10,0]*r[K][6][13,0]*r[L][4][11,0]*t[((I,8),(K,13),)]*t[((J,10),(L,11),)]
                    
    td[u] = tu

    return td
    

